V381A · Mid-pool flip-and-rolling · first motion study

The agreed illustration: two freestyle swimmers approach in open water,
flip and roll, meet sole-to-sole, extend from that mutual podaling, and
continue swimming. Both bodies remain visible through the meeting.

This is an editable visual choreography for examination. It reads no
resolver and displays no private carrying. Body rotation is continuous;
the second swimmer is a separately rotating body, never a reflected copy.
The animation is not a claim that a swimming manoeuvre establishes the
resolver's exact number-to-geometry correspondence.

View the finished 12-second MP4 in an ordinary video player.

To examine and revise the 3D source:
  1. Install Node.js if it is not already available.
  2. In this folder run: node serve.mjs
  3. Open http://127.0.0.1:3811 in a browser.
  4. Use Play/Pause and the scrub control to examine the motion.

scene.js contains the body meshes, continuous poses, camera, and water.
index.html contains the captions and viewer. Rendering the MP4 uses
render.mjs, Playwright with Chromium, and ffmpeg. The render is 1280×720,
30 frames per second, 12 seconds, silent H.264. Pass --preview to render
only the pose-check frames. The viewer has no external network requests.

For rendering, install the optional dependencies with:
  npm install playwright @sparticuz/chromium
Then run: node render.mjs
prepare-browser.mjs prepares the portable local rendering browser if the
normal Playwright browser is unavailable. Video captions are composited
by ffmpeg, separately from the motion.

Three.js 0.186.1 is included in vendor/ under its MIT license.
DejaVu Sans is included for captions under its license in vendor/.
Source reference: Natural Illustrating §4.9, corus/main,
Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md.

First experiment approved in the V381A illustrating session, 2026-10-03.
