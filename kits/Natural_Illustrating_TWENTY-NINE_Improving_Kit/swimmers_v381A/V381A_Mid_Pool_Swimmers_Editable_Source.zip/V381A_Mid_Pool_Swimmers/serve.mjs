import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript'};
http.createServer((req,res)=>{const p=new URL(req.url,'http://localhost').pathname;const file=path.join(root,p==='/'?'index.html':decodeURIComponent(p));if(!file.startsWith(root)){res.writeHead(403);res.end();return;}fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);res.end();return;}res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});res.end(data);});}).listen(3811,'127.0.0.1',()=>console.log('Open http://127.0.0.1:3811 to examine the motion.'));
