import * as THREE from './vendor/three.module.js';

// A visual choreography for discussion. No resolver or private carrying is read.
const capture = new URLSearchParams(location.search).has('capture');
document.body.classList.toggle('capture',capture);
const DURATION=12;
const scene=new THREE.Scene();
scene.background=new THREE.Color('#073c4b');
scene.fog=new THREE.FogExp2('#073c4b',.027);
const camera=new THREE.PerspectiveCamera(34,innerWidth/innerHeight,.05,100);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true});
renderer.setSize(innerWidth,innerHeight);
renderer.setPixelRatio(1);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.35;
document.body.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight('#d9fbff','#154359',2.1));
const key=new THREE.DirectionalLight('#e5feff',3.4);key.position.set(-2,7,5);scene.add(key);
const rim=new THREE.DirectionalLight('#52c9e1',2.8);rim.position.set(0,4,-6);scene.add(rim);
const fill=new THREE.DirectionalLight('#b4f1ed',1.0);fill.position.set(3,-3,5);scene.add(fill);
const V=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
const ramp=(t,a,b)=>smooth((t-a)/(b-a));
const mix=(a,b,u)=>a+(b-a)*u;
const blend=(a,b,u)=>a.clone().lerp(b,u);
const Z=V(0,0,1), X=V(1,0,0), Y=V(0,1,0);
const sphereGeo=new THREE.SphereGeometry(1,24,16);
const boneGeo=new THREE.CylinderGeometry(1,1,1,18,1);
const materials={};
const material=(color,extra={})=>new THREE.MeshPhysicalMaterial({color,roughness:.47,metalness:0,clearcoat:.2,clearcoatRoughness:.5,...extra});
function ellipsoid(parent,mat,pos,scale){const m=new THREE.Mesh(sphereGeo,mat);m.position.copy(pos);m.scale.copy(scale);parent.add(m);return m;}
function bone(parent,mat,r1,r2){const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r2,r1,1,16,1),mat);parent.add(mesh);return mesh;}
function setBone(mesh,a,b){const d=b.clone().sub(a);mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.scale.set(1,d.length(),1);mesh.quaternion.setFromUnitVectors(Y,d.normalize());}
function solveElbow(shoulder,wrist,side){
  const a=.335,b=.315,dv=wrist.clone().sub(shoulder),d=Math.min(dv.length(),a+b-.002),n=dv.normalize();
  const x=(a*a-b*b+d*d)/(2*d),h=Math.sqrt(Math.max(0,a*a-x*x));
  let off=V(0,.25,side*.95);off.addScaledVector(n,-off.dot(n)).normalize();
  return shoulder.clone().addScaledVector(n,x).addScaledVector(off,h);
}
function makeSwimmer(color,skinColor,side){
  const root=new THREE.Group();scene.add(root);
  const skin=material(skinColor),suit=material(color,{roughness:.37}),goggle=material('#244651',{roughness:.25,metalness:.16}),lens=material('#8fdbe6',{roughness:.1,metalness:.22});
  ellipsoid(root,skin,V(.09,0,0),V(.26,.145,.20));
  ellipsoid(root,suit,V(-.025,.005,0),V(.195,.157,.218));
  const upper=new THREE.Group();root.add(upper);
  ellipsoid(upper,skin,V(.28,0,0),V(.255,.146,.20));
  ellipsoid(upper,skin,V(.48,.008,0),V(.255,.177,.252));
  ellipsoid(upper,skin,V(.70,-.001,0),V(.115,.075,.092));
  // Slight chest and back shaping makes the body's continuous orientation readable.
  for(const s of [-1,1])ellipsoid(upper,skin,V(.515,-.096,s*.105),V(.155,.09,.12));
  const head=new THREE.Group();head.position.set(.91,0,0);upper.add(head);
  ellipsoid(head,skin,V(.02,0,0),V(.168,.128,.121));
  ellipsoid(head,suit,V(.066,.026,0),V(.130,.119,.125));
  ellipsoid(head,skin,V(-.012,-.13,0),V(.049,.037,.025));
  ellipsoid(head,skin,V(-.055,-.085,0),V(.071,.058,.066));
  for(const s of [-1,1]){
    ellipsoid(head,skin,V(-.026,.002,s*.12),V(.035,.043,.019));
    ellipsoid(head,goggle,V(.027,-.116,s*.061),V(.052,.028,.042));
    ellipsoid(head,lens,V(.027,-.139,s*.061),V(.043,.009,.034));
  }
  const arms=[],legs=[];
  for(const s of [-1,1]){
    const shoulder=V(.582,0,s*.222);
    const arm={s,shoulder,upper:bone(upper,skin,.067,.054),fore:bone(upper,skin,.052,.034),elbow:ellipsoid(upper,skin,V(),V(.056,.056,.056)),hand:ellipsoid(upper,skin,V(),V(.088,.027,.043)),thumb:ellipsoid(upper,skin,V(),V(.049,.022,.025))};
    ellipsoid(upper,skin,shoulder,V(.099,.078,.077));arms.push(arm);
    const hip=V(-.063,0,s*.126);
    const foot=new THREE.Group();root.add(foot);
    const footMesh=ellipsoid(foot,skin,V(),V(.166,.052,.065));
    // Separate toes, kept on the same physical foot throughout the turn.
    for(let j=0;j<4;j++)ellipsoid(foot,skin,V(-.143,-.006,(j-1.5)*.027),V(.028,.042,.016));
    const leg={s,hip,thigh:bone(root,skin,.107,.071),calf:bone(root,skin,.074,.040),knee:ellipsoid(root,skin,V(),V(.075,.075,.075)),ankle:ellipsoid(root,skin,V(),V(.047,.047,.047)),shorts:bone(root,suit,.112,.095),foot,footMesh};
    legs.push(leg);
  }
  return {root,upper,head,arms,legs,side};
}
const swimmers=[makeSwimmer('#1b9298','#d4aa8b',-1),makeSwimmer('#d47e53','#b18a70',1)];

// Water's light and suspended specks supply depth without a wall or a turning mark.
let seed=381;
function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
const particleCount=185,particleData=new Float32Array(particleCount*3),originalParticles=[];
for(let i=0;i<particleCount;i++){const p=V((rnd()-.5)*28,(rnd()-.5)*13,(rnd()-.5)*24);originalParticles.push(p);particleData.set(p.toArray(),i*3);}
const particleGeometry=new THREE.BufferGeometry();particleGeometry.setAttribute('position',new THREE.BufferAttribute(particleData,3));
const particles=new THREE.Points(particleGeometry,new THREE.PointsMaterial({color:'#9bd9df',size:.024,transparent:true,opacity:.26,depthWrite:false}));scene.add(particles);
const beamGroup=new THREE.Group();scene.add(beamGroup);
for(let i=0;i<6;i++){
  const m=new THREE.Mesh(new THREE.ConeGeometry(.43,12,4,1,true),new THREE.MeshBasicMaterial({color:'#91d9dd',transparent:true,opacity:.024,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));
  m.position.set(-8+i*3.1,1,-6-i*.28);m.rotation.z=-.24;m.rotation.x=.1;beamGroup.add(m);
}
beamGroup.visible=false;
const waterBackdrop=new THREE.Mesh(new THREE.PlaneGeometry(90,50),new THREE.ShaderMaterial({
  depthWrite:false,
  uniforms:{motion:{value:0}},
  vertexShader:'varying vec2 uvWater; void main(){uvWater=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
  fragmentShader:'varying vec2 uvWater; uniform float motion; void main(){float g=smoothstep(0.05,0.95,uvWater.y);vec3 c=mix(vec3(0.020,0.13,0.18),vec3(0.10,0.34,0.38),g);float glow=exp(-8.0*pow(uvWater.x-0.26,2.0))*smoothstep(0.25,1.0,uvWater.y);float drift=sin(uvWater.x*22.0+uvWater.y*9.0+motion*0.15)*sin(uvWater.y*13.0-motion*0.12);c+=vec3(0.024,0.065,0.068)*glow+c*drift*0.035;gl_FragColor=vec4(c,1.0);}'
}));waterBackdrop.position.z=-28;scene.add(waterBackdrop);
const bubbleGeo=new THREE.SphereGeometry(1,8,6),bubbleMaterial=new THREE.MeshPhysicalMaterial({color:'#c8f5f5',transparent:true,opacity:.25,roughness:.18,metalness:.04,depthWrite:false});
const bubbles=[];for(let i=0;i<28;i++){const b=new THREE.Mesh(bubbleGeo,bubbleMaterial);b.scale.setScalar(.012+rnd()*.014);scene.add(b);bubbles.push({mesh:b,k:rnd(),y:rnd()});}

function pose(sw,t){
  const side=sw.side,flip=ramp(t,3.05,5.22),tuck=ramp(t,2.9,4.02)*(1-ramp(t,4.04,5.19)),plant=ramp(t,4.03,5.22),push=ramp(t,5.28,6.15),roll=ramp(t,6.24,7.83);
  let distance;
  if(t<3.05) distance=mix(3.95,1.44,ramp(t,0,3.05));
  else if(t<5.22)distance=mix(1.44,.657,ramp(t,3.05,5.22));
  else if(t<6.15)distance=mix(.657,.977,push);
  else distance=mix(.977,4.54,ramp(t,6.15,12));
  const floatY=.055*Math.sin(t*2.0)*(1-ramp(t,2.9,4.3)) + .035*Math.sin(t*1.8)*ramp(t,8,9.2);
  sw.root.position.set(side*distance,-.09+floatY,0);
  const base=new THREE.Quaternion().setFromAxisAngle(Y,side===1?Math.PI:0);
  const flipQ=new THREE.Quaternion().setFromAxisAngle(Z,-Math.PI*flip);
  const rollQ=new THREE.Quaternion().setFromAxisAngle(X,Math.PI*roll);
  sw.root.quaternion.copy(base).multiply(flipQ).multiply(rollQ);
  sw.upper.rotation.z=-.31*tuck;
  sw.head.rotation.z=-.22*tuck;
  const swimBefore=1-ramp(t,2.55,3.48),swimAfter=ramp(t,8.02,9.28),swimWeight=Math.max(swimBefore,swimAfter),streamline=ramp(t,4.25,5.20);
  for(const arm of sw.arms){
    const s=arm.s,phi=t*2.42+(s===1?Math.PI:0)+(side===1?.38:0);
    const stroke=V(.582+.57*Math.cos(phi),-.18*Math.sin(phi),s*(.22+.09*Math.sin(phi)*Math.sin(phi)));
    const compact=V(.09,-.09,s*.25);
    const straight=V(1.197,-.005,s*.076);
    let wrist=blend(compact,straight,streamline).lerp(stroke,swimWeight);
    // Clamp to a consistent reach so the body turns instead of stretching into a reflection.
    const delta=wrist.clone().sub(arm.shoulder);if(delta.length()>.646)wrist.copy(arm.shoulder).addScaledVector(delta.normalize(),.646);
    const elbow=solveElbow(arm.shoulder,wrist,s);
    setBone(arm.upper,arm.shoulder,elbow);setBone(arm.fore,elbow,wrist);arm.elbow.position.copy(elbow);
    const forward=wrist.clone().sub(elbow).normalize();arm.hand.position.copy(wrist).addScaledVector(forward,.077);arm.hand.quaternion.setFromUnitVectors(X,forward);arm.thumb.position.copy(arm.hand.position).add(V(0,-.01,s*.037));arm.thumb.quaternion.copy(arm.hand.quaternion);
  }
  for(const leg of sw.legs){
    const s=leg.s,kick=Math.sin(t*6.2+(s===1?Math.PI:0)+side*.22)*(.035+.055*swimWeight);
    const freeKnee=V(-.487,-.013+kick*.30,s*.127),freeAnkle=V(-.918,kick,s*.116);
    const tuckKnee=V(.237,-.292,s*.166),tuckAnkle=V(-.033,-.493,s*.158);
    const plantKnee=V(mix(-.300,-.487,push),mix(-.340,-.013,push),s*.139),plantAnkle=V(mix(-.590,-.910,push),0,s*.116);
    let knee=blend(freeKnee,tuckKnee,ramp(t,2.9,4.02)).lerp(plantKnee,plant);
    let ankle=blend(freeAnkle,tuckAnkle,ramp(t,2.9,4.02)).lerp(plantAnkle,plant);
    const resume=ramp(t,6.3,8.20);knee.lerp(freeKnee,resume);ankle.lerp(freeAnkle,resume);
    setBone(leg.thigh,leg.hip,knee);setBone(leg.calf,knee,ankle);leg.knee.position.copy(knee);leg.ankle.position.copy(ankle);
    setBone(leg.shorts,leg.hip,blend(leg.hip,knee,.46));
    const footPlant=plant*(1-ramp(t,6.2,7.25));
    leg.foot.quaternion.setFromAxisAngle(Z,Math.PI*.5*footPlant);
    leg.foot.position.copy(ankle).add(V(mix(-.118,-.015,footPlant),mix(-.01,-.130,footPlant),0));
  }
}
function setCaption(t){
  const entries=[['Arriving','Both carrying their swimming into the meeting',0],['Flip-and-rolling','Both bodies turning continuously',2.90],['Mutual podaling','Feet meeting · both extending through the meeting',5.14],['Releasing','Both rolling into their next swimming',6.30]];
  let i=0;for(let j=1;j<entries.length;j++)if(t>=entries[j][2])i=j;
  document.getElementById('phase').textContent=entries[i][0];document.getElementById('detail').textContent=entries[i][1];
  const edge=t-entries[i][2];document.querySelector('.caption').style.opacity=i===0?1:mix(.4,1,ramp(edge,0,.28));
}
export function setTime(t){
  t=clamp(t,0,DURATION);for(const sw of swimmers)pose(sw,t);
  const focus=ramp(t,2.40,4.95)*(1-ramp(t,6.6,9.9));
  camera.position.set(mix(1.6,1.0,focus),mix(2.8,1.9,focus),mix(12.3,6.3,focus));camera.lookAt(0,-.1,0);
  const arr=particleGeometry.attributes.position.array;for(let i=0;i<particleCount;i++){const p=originalParticles[i];arr[i*3]=p.x+.06*Math.sin(t*.33+i);arr[i*3+1]=p.y+t*.025;arr[i*3+2]=p.z;}particleGeometry.attributes.position.needsUpdate=true;
  beamGroup.position.x=.12*Math.sin(t*.18);
  waterBackdrop.material.uniforms.motion.value=t;
  scene.updateMatrixWorld(true);
  for(let i=0;i<bubbles.length;i++){const b=bubbles[i],sw=swimmers[i%2],age=(t*.17+b.k)%1;const p=sw.upper.localToWorld(V(.91,.015,0));b.mesh.position.copy(p).add(V(sw.side*age*.40,age*.55,-.04+Math.sin(i)*.12));b.mesh.material=bubbleMaterial;b.mesh.visible=t<3.3||t>8.6;}
  setCaption(t);renderer.render(scene,camera);document.getElementById('scrub').value=t;
}
window.setTime=setTime;window.sceneReady=true;window.duration=DURATION;
window.inspectPose=(t)=>{setTime(t);return swimmers.map(sw=>({hip:sw.root.position.toArray(),feet:sw.legs.map(l=>l.foot.getWorldPosition(V()).toArray()),quaternion:sw.root.quaternion.toArray()}));};
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);setTime(clockTime);});
let playing=!capture,clockTime=0,last=performance.now();
const play=document.getElementById('play'),scrub=document.getElementById('scrub');
play.onclick=()=>{if(clockTime>=DURATION)clockTime=0;playing=!playing;play.textContent=playing?'Pause':'Play';last=performance.now();};
scrub.oninput=()=>{clockTime=+scrub.value;playing=false;play.textContent='Play';setTime(clockTime);};
function animate(now){if(playing){clockTime=Math.min(DURATION,clockTime+(now-last)/1000);setTime(clockTime);if(clockTime>=DURATION){playing=false;play.textContent='Replay';}}last=now;if(!capture)requestAnimationFrame(animate);}
setTime(0);if(!capture)requestAnimationFrame(animate);
