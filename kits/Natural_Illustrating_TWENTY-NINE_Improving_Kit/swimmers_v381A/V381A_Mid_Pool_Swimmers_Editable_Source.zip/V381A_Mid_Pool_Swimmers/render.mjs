import {createRequire} from 'node:module';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {prepareBrowser} from './prepare-browser.mjs';
const require=createRequire(import.meta.url);
const playwrightPath=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright';
const {chromium}=require(playwrightPath);
const dir=path.dirname(fileURLToPath(import.meta.url));
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css'};
const server=http.createServer((req,res)=>{const u=new URL(req.url,'http://127.0.0.1'),f=path.join(dir,u.pathname==='/'?'index.html':decodeURIComponent(u.pathname));if(!f.startsWith(dir)){res.writeHead(403);res.end();return;}fs.readFile(f,(e,data)=>{if(e){res.writeHead(404);res.end();return;}res.writeHead(200,{'Content-Type':mime[path.extname(f)]||'application/octet-stream'});res.end(data);});});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
let executablePath=chromium.executablePath(),browserArgs=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage','--hide-scrollbars'];
let renderEnv=process.env;
if(!fs.existsSync(executablePath)){const pkg=require('@sparticuz/chromium'),portable=pkg.default||pkg,prepared=await prepareBrowser();executablePath=prepared.exe;browserArgs=[...portable.args,...browserArgs];renderEnv={...process.env,FONTCONFIG_PATH:path.join(prepared.runtime,'fonts'),LD_LIBRARY_PATH:prepared.runtime+(process.env.LD_LIBRARY_PATH?':'+process.env.LD_LIBRARY_PATH:'')};}
const browser=await chromium.launch({headless:true,executablePath,args:browserArgs,env:renderEnv});
const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto(`http://127.0.0.1:${port}/?capture=1`,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.sceneReady===true);await page.evaluate(()=>document.fonts.ready);
const qa=path.join(dir,'qa');fs.mkdirSync(qa,{recursive:true});
const times=[0,2.9,3.8,4.5,5.25,5.75,6.1,6.7,7.6,9.3,12];
const diagnostics=[];
for(const t of times){const d=await page.evaluate(t=>window.inspectPose(t),t);diagnostics.push({time:t,pose:d});await page.screenshot({path:path.join(qa,`pose_${t.toFixed(2).replace('.','_')}.png`)});}
fs.writeFileSync(path.join(qa,'pose_check.json'),JSON.stringify({errors,diagnostics},null,2));
console.log('Preview frames captured; page errors:',errors.length);
if(errors.length)throw new Error(errors.join('; '));
if(process.argv.includes('--preview')){await browser.close();server.close();process.exit(0);}
const output=path.join(dir,'V381A_Mid_Pool_Flip_Turning_First_Study.mp4');
const fps=30,total=12*fps;
const font=path.join(dir,'vendor','StudySans.ttf');
const title=`drawtext=fontfile=${font}:text='Mid-pool flip-and-rolling':fontsize=23:fontcolor=0xeaf7f6:x=44:y=36`;
const phases=[['Arriving','lt(t,2.9)'],['Flip-and-rolling','gte(t,2.9)*lt(t,5.14)'],['Mutual podaling','gte(t,5.14)*lt(t,6.3)'],['Releasing','gte(t,6.3)']].map(([text,enable])=>`drawtext=fontfile=${font}:text='${text}':fontsize=26:fontcolor=0xeaf7f6:x=44:y=h-73:enable='${enable}'`);
const overlay=[title,...phases,`drawtext=fontfile=${font}:text='V381A  /  FIRST MOTION STUDY':fontsize=11:fontcolor=0xa4c9ce:x=w-tw-42:y=h-48`].join(',');
await page.evaluate(()=>{for(const c of ['.heading','.caption','.note'])document.querySelector(c).style.display='none';});
const ff=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0','-an','-vf',overlay,'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',output],{stdio:['pipe','inherit','inherit']});
const done=new Promise((resolve,reject)=>{ff.on('error',reject);ff.on('close',code=>code===0?resolve():reject(new Error('ffmpeg exit '+code)));});
for(let f=0;f<total;f++){await page.evaluate(t=>window.setTime(t),f/fps);const jpg=await page.screenshot({type:'jpeg',quality:94});if(!ff.stdin.write(jpg))await new Promise(r=>ff.stdin.once('drain',r));if(f%60===0)console.log(`Rendered ${f}/${total} frames`);}
ff.stdin.end();await done;await browser.close();server.close();console.log('Video completed:',output);
