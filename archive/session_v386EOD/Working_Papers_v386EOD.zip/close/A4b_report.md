# A4b report: third reading of items 41 to 80 (all KIND: RELEASED)

### 41
VERDICT: SAFE
WHAT: -

### 42
VERDICT: MINOR
WHAT: The concept is said whole at the later section of the same mate (carry/Exhibit_TWENTY-THREE_Offerings_to_Natural_Values.md line 240, "Droplet · Three improvings spiralling, one triple at each coupling": the three improvings, the moral spiral). The attribution is not there. The reason says that section 'names "its released Natural Intelligence, its map" as its source'; that sentence is at no line of carry/ now. Commit 36cfd58 of the same session removed it from the section ("-Each is from the resettling of version 373, its released Natural Intelligence, its map and Exhibit ONE at its stable forms, at `carryings/resettling_v373/` ..."). So "receives from Natural Intelligence" and "(Natural Intelligence Map, §3)" are no longer at this mate. The from-Natural-Intelligence relation is still at carry/Session_Record.md line 1643 ("Incoming, at v373, from Natural Intelligence ... the moral spiral's three improvings. Received here at this file's motion") and the row is at carryings/resettling_v373/Natural_Intelligence_Map.md line 171. The living Exhibit TWENTY-THREE Natural Values v333 has neither "three improvings" nor "moral spiral" (Grep), so the receiving itself is not yet made at the living file; the droplet carries it.

### 43
VERDICT: SAFE
WHAT: -

### 44
VERDICT: SAFE
WHAT: -

### 45
VERDICT: SAFE
WHAT: -

### 46
VERDICT: SAFE
WHAT: -

### 47
VERDICT: SAFE
WHAT: -

### 48
VERDICT: SAFE
WHAT: -

### 49
VERDICT: SAFE
WHAT: -

### 50
VERDICT: SAFE
WHAT: -

### 51
VERDICT: SAFE
WHAT: -

### 52
VERDICT: SAFE
WHAT: -

### 53
VERDICT: MINOR
WHAT: The standing (pass G, both files) and the plan at the Living File Registry 1.5 are at the living file as the reason quotes them. The quoted sentence of Session Report v378, "Destinies and Emanating into Corus, Natural Naming and Natural Explaining.", is at no file of carry/ now (Grep). Read as one sentence of both files together it is covered. Read of each file, one pairing is not at the living Registry: Natural Destinies into Natural Explaining (1.5 has "All content receives in Corus and the relevant subject exhibits"; 5.11 names Corus, Values, Human Society, Networking, Engineering, Resolving Hard Problems, Natural Intelligence and Naming, and no Explaining). The reason states this narrowing itself. The sentence is whole at carryings/session_v378/Session_Report_v378.md line 21.

### 54
VERDICT: SAFE
WHAT: -

### 55
VERDICT: SAFE
WHAT: -

### 56
VERDICT: MINOR
WHAT: Each fact is at the later sections named, but not as one statement of this one pass. "without releasing Destinies" is at Carryings of Natural Destinies ("No planned release is accomplished by this first comparison"); "originating a new game exhibit" is at Possibling of Living File Registry ("No new game exhibit, reward scheme or required entrance number follows"); "combining the three subjects" is there only as "This pass originates or combines no exhibit", said under the later heading "Human Society's particular contribution · v385A" of that later pass, and as "Existing Values/Human Society/Corus distribution plans remain distinct from completed receiving". The words "This refines the full-distribution plan" are at no file of carry/ now (Grep "full-distribution": none). The waiting sentence (Human Society's receiving and the other extensions to compare) is overtaken by those later sections, as the reason says.

### 57
VERDICT: SAFE
WHAT: -

### 58
VERDICT: SAFE
WHAT: -

### 59
VERDICT: SAFE
WHAT: -

### 60
VERDICT: SAFE
WHAT: -

### 61
VERDICT: MINOR
WHAT: As at 53: pass G for both files, and the plan at Registry 1.5, are at the living file; this mate's front has "**Next at this file:** pass G." (line 5). The report's sentence "Destinies and Emanating into Corus, Natural Naming and Natural Explaining." is at no file of carry/ now. For Natural Emanating, this mate's own file, all three (Corus, Naming, Explaining) are at Registry 1.5. The one pairing not at the living Registry is Natural Destinies into Natural Explaining; the reason states it.

### 62
VERDICT: SAFE
WHAT: -

### 63
VERDICT: SAFE
WHAT: -

### 64
VERDICT: SAFE
WHAT: -

### 65
VERDICT: SAFE
WHAT: -

### 66
VERDICT: SAFE
WHAT: -

### 67
VERDICT: SAFE
WHAT: -

### 68
VERDICT: SAFE
WHAT: -

### 69
VERDICT: SAFE
WHAT: -

### 70
VERDICT: SAFE
WHAT: -

### 71
VERDICT: MINOR
WHAT: "The registry pair" is two files. For Exhibit TWENTY-TWO Resolving the Hard Problem Registry the receiving is at the living file (line 740 and the part headings "# 1 An arriving named from behind — ..." to "# 10 The between named as a cut — ..."). For the other of the pair, Exhibit TWENTY-ONE Hard Problem Registry, it is not made: that living file has none of the ten (Grep; the reason says so). So the paragraph is resolved for one file of the two, not for the pair. Nothing is lost from carry/: the open half is carried at carry/Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.md line 49, "Concern · No ten at the Hard Problem Registry" ("Either a ten enters here at this file's own motion, or the saying at the other files is re-said at five"), which the reason does not name.

### 72
VERDICT: MINOR
WHAT: As at 53 and 61. Pass G and the plan at Registry 1.5 and 5.11 are at the living file; this mate's front has "**Next at this file:** pass G." (line 21). The report's sentence is at no file of carry/ now, and for this mate's own file, Natural Destinies, the Registry names Corus and "the relevant subject exhibits" (Naming at 5.11) and names Natural Explaining at no row of Natural Destinies. The reason's "say no more than the two rows" is so for the two files read together, and not for Natural Destinies read alone.

### 73
VERDICT: SAFE
WHAT: -

### 74
VERDICT: SAFE
WHAT: -

### 75
VERDICT: SAFE
WHAT: -

### 76
VERDICT: SAFE
WHAT: -

### 77
VERDICT: SAFE
WHAT: -

### 78
VERDICT: SAFE
WHAT: -

### 79
VERDICT: SAFE
WHAT: -

### 80
VERDICT: MINOR
WHAT: As at 53, 61 and 72. Pass G and the plan at Registry 1.5 are at the living file. The report's sentence "Destinies and Emanating into Corus, Natural Naming and Natural Explaining." is at no file of carry/ now; the like paragraph the reason names at Possibling of Living File Registry ("Earlier proposed exhibit combination and distribution · v385A") is the paragraph for Values and "Opportunity 4, the pass-G receivings", which names the six files and none of their receiving places. For this mate's file, Natural Naming, the receiving is at the Registry for Natural Emanating (1.5, "concepts toward Naming") and for Natural Destinies (5.11, "Natural Intelligence and Naming for common explaining"). The pairing not at the Registry is Natural Destinies into Natural Explaining.

## SUMMARY

All 40 items are RELEASED.

| KIND | SAFE | MINOR | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|
| RELEASED:RESOLVED | 24 | 5 | 0 | 0 | 29 |
| RELEASED:SAID | 4 | 2 | 0 | 0 | 6 |
| RELEASED:NOVALUE | 5 | 0 | 0 | 0 | 5 |
| RESAID | 0 | 0 | 0 | 0 | 0 |
| All | 33 | 7 | 0 | 0 | 40 |

MINOR: 42, 53, 56, 61, 71, 72, 80. No HARM found. Nothing I could not check.

## READING

What I did. For each item I opened the place the reason names and compared it with AS IT WAS. Every sentence the reasons give in double quotation marks from a living file that I searched for (about sixty, with fixed-string search at the root `*.md` files) is at the living file exactly, at the section or line the reason gives. The source rows were read at carryings/ (cover_REGISTRIES.md rows T1, T4, T7; cover_EQUILIBRIA.md lines 67, 113, 124, 127, 212; readings/05_hard_problems_and_equilibria.md items 4, 5, 6, 12 and contradiction 8; Natural_Intelligence_Map.md lines 46, 49, 60, 91, 92, 163, 164, 171; Wrap_v368.md; Carry_Set_v368_README.md lines 51, 54, 166; Session_Report_v377.md lines 91, 97, 98, 99; Session_Report_v378.md line 21). The three paragraphs said "word for word" at another mate (58 and 65 at Possibling of Living File Registry line 223; 76 at its line 365; 69 at Offerings to Co-Chaining Logic Registry line 61) were checked by searching the whole paragraph text as one string: each is there once, whole.

The one thing found that the owner should know of.
- Item 42. The reason rests partly on a sentence that is no longer in the file. The later section was said to name its source ("its released Natural Intelligence, its map"); a later commit of the same session (36cfd58, "the session's own telling taken out of the carrying") removed that sentence. The droplet's concept is whole; the note of where it came from is now at carry/Session_Record.md and at the source in carryings/, and not at the mate. I did not check whether other v386EOD sections lost their source sentence in that same commit; that is outside these 40 items, but the same commit touched 79 files.

The four copies of one paragraph (53, 61, 72, 80). I gave all four the same verdict. The paragraph is a pointer to the Living File Registry 1.5 with a session report's one-sentence compression. The living Registry is later (v381R) and more detailed, and the paragraph itself defers to it, so I read this as MINOR and not HARM. What differs is exact: the compression joins Natural Destinies with Natural Explaining, and the Registry does not. The compression is at no file of carry/ now and is whole at carryings/session_v378/Session_Report_v378.md line 21.

Smaller observations that did not change a verdict.
- 54. The released concern says "The seventeen names stand at the old code at this file". I searched Exhibit_TWENTY-ONE_Hard_Problem_Registry_v375.md and found none of the seventeen names at the old or the new naming, as the reason says. The living file is still at v375, the version it had at v378 when the concern was written, so I could not tell from these files whether the concern was ever true of this file; it is not true of it now. "pass B" is at no line of the living Registry's table of files for this file now. The three steps entered (322, 315, 330) are at the living Registry with no unsure line; "Unsure" is at no line of Exhibit THIRTY v380L at all.
- 47. The paragraph's "Each saying at the code met at Exhibit ONE v376" is the v377 session's own statement of what it did. The living file's closing now says a three-way statement (at Exhibit ONE v380R at its tables, by hand at v380L, or executed at v377 at Exhibit ONE v376). I read that as the later standing replacing the v377 one, and the archive file named is at its path.
- 46. Grep of "cube" in Natural_Intelligence_v380R.md finds one line (1061, "three cubed"), which is not the Rubik's cube; the reason's "no cube at any line" is right of the subject.
- 75. The reason quotes the version 376 step 34 as "A second method carries a not possible thing, beside all existing things"; carryings/co_chaining_map_v376/Co_Chaining_Groups_v376.md line 48 has "carries an existing thing beside all existing things". I did not find which file the reason quoted from. It does not bear on the release: the living step 46 and its "*Adding: beside all existing things; the form still.*" are as quoted.
- 74. The possible project "Natural Naming becomes the lexicon" that the reason leans on is in carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md twice, at lines 169 and 201, the same text. That is a doubling, not a loss, and is outside this item.
- 62. "Natural_Intelligence_v345a.md, which goes to the journey archive": that file is at no place under /home/claude/corus (find). The paragraph is an instruction for a placing made long since; the root has no file of version 368 and no v345a or v363 of those names, and files.json lists the four later files and Natural_Intelligence_Corus_v330.md.

What I did not check.
- The reasons' statements "No pointer to this paragraph found". I did not repeat those searches for every item.
- The renumbering statements "steps 104 to 109 and 91 are steps 159 to 164 and 136 now" (51) and "step 60 is step 93 now" (52). I read the present steps at those numbers and they are of the subjects named, but I did not trace the numbering from v376 to v380L.
- The count "can change is at the living file eighteen times, seventeen in the tables' column and one at 4.2" (63): the total of eighteen is right (Grep); I did not sort the eighteen by place.
- Whether each released paragraph is in fact gone from its mate. For those I happened to search (42, 67, 69) it is gone.
