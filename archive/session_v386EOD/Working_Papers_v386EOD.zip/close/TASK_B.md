# Task: a third reading of older paragraphs that were said again or released (the whole remaining set)

Read COMMON.md, then TASK_A34.md, and do what TASK_A34.md says for the sample file your message names, with these three differences:

1. One more verdict: **PERSON'S WORDS**. Use it when the original paragraph quotes the person's own words (often called "the self", "the lead", "the expedition's self", or shown as an unpunctuated quotation) or says the person said or asked a thing, and the new paragraph no longer has those quoted words or no longer says whose they are, while every claim is otherwise whole. If a claim is also lost or changed, the verdict is HARM.
2. For HARM, add a line `LOST: <the exact clause or sentence of AS IT WAS that is gone or changed>`.
3. Check quotations in at most two items in three; put your effort on laying each pair side by side claim by claim.

Report form, one block for each item, with the item's own number:
```
### <number>
VERDICT: <SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK>
WHAT: <for MINOR, PERSON'S WORDS or HARM: exactly what; otherwise a dash>
LOST: <for HARM alone; otherwise a dash>
```
Then `## SUMMARY` with counts, and `## READING`. Final message: the path of your report and the counts with the numbers of the HARM and PERSON'S WORDS items.
