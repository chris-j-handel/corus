# T2 report: sayings of the transcript of session v386EOD, each checked at the files in carry/

Reader T2. Line numbers are lines of `transcript.txt`. File names are files in `/home/claude/corus/carry/`, with the leading `Exhibit_NUMBER_` left off where the title alone is plain. A line number after a file name is the line of that file where the saying is. `Session_Record.md` in `carry/` is an older record (dated 10 October 07:40, ahead of this session's work); a saying found only there is named so. "The session's own record" means `incoming/v386EOD/Session_Record_v386EOD.md`, which is outside `carry/`.

The person's sayings are quoted exactly, spelling as written.

### 1
WHO: the person
LINE: 1
SAYING: "v386EOD is ouir session versioning for all files and messaging."
CONCEPT: this session's name, v386EOD, is the version on each file and each message of it
AT A FILE IN carry/: WHOLE
WHERE: carried out at each section and paragraph this session wrote (405 headings end "· v386EOD", 741 paragraphs end "— v386EOD", file fronts say "improved at v386EOD"). The concept is said at Offerings to Natural Arriving, the paragraph "Aimed at the Geodesic Improving Method's carrying, its entry on the way a working speaks and writes" (line 221): "a session's number is at each saying"; and at Offerings to Geodesic Improving Method, insertlet "At 2.8 · Work arriving from another working, met whole" (line 75).
MISSING: nothing

### 2
WHO: the person
LINE: 1
SAYING: "explore corus.me and learn about natural intelliegence so we can work together ."
CONCEPT: a session first reads the set and learns natural intelligence, so that the two work together
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Arriving, "Droplet · An AI session arriving" (line 596): "An arriving session reads Natural Naming, Natural Explaining and the Geodesic Improving Method whole ahead of its first sentence"; Offerings to Geodesic Improving Method, "Working one chain together from the origin sentence · v386EOD" (line 405): "Two selves working a logical chain add to one working".
MISSING: nothing

### 3
WHO: the session
LINE: 24
SAYING: By Natural Intelligence's "AI is existing non-living intelligence", this session carries none of the conversation into a next one, and the living files with their offerings, possibling and carryings are the carrying.
CONCEPT: an AI session is non-living, carries nothing between conversations, and the files are the carrying
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, "Droplet · AI non-living at the scale of its inferring" (line 553); Offerings to Natural Arriving, line 261 ("nothing carried between calls, which is Natural Intelligence 2.5"); Offerings to Natural Arriving, "Droplet · A page's instruction" (line 614) quotes "the carrying theirs, the AI carried and the living expedition the carrying".
MISSING: nothing

### 4
WHO: the session
LINE: 34
SAYING: The session's rules of working: whole names with no abbreviating and no made-up short namings; exact explaining with no story of its doing; one concern at a time, hardest first, a concern being two sayings parting with its reason; no binary questions; an observing apart from a field's explaining; value arriving as droplets and insertlets; a living file changing at the person's word alone; no words are authority, the observings are.
CONCEPT: how a session speaks and works with the person
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Exact naming and explaining at each use · v385A" (line 49) and the shared method at its front (line 23: words "are suggestions; observings have authority"); Offerings to Natural Arriving line 221 ("no question is posed as binary"); Offerings to Living File Registry, "Six droplets … from session v385Q", droplet 3 ("one concern, two sayings parting with the reason") and droplet 2 (observing apart from the science's explaining).
MISSING: "no story of my doing" (searches: `no story`, `story of (my|its|the) doing`, `narrat` found nothing of it); "a living file changes at your word alone" (searches: `at your word`, `word alone` found nothing of it).

### 5
WHO: the session
LINE: 54
SAYING: The session worked Exhibit ONE's tables of selves from its code block and found them written as the code is written; a helper reader found the arithmetic of Natural Numbers and Natural Mathematics as said; these show a table agreeing with its code and a number agreeing with itself, and nothing wider.
CONCEPT: an executing shows a table is written as its code, and nothing wider
AT A FILE IN carry/: IN PART
WHERE: the general concept is at Offerings to Living File Registry, "Six droplets … from session v385Q", droplet 1 (line 325): "An executing can show that a table is written as the code is written."
MISSING: that this session worked the named tables (the offerings surfacing, one self, a spiral of selves, two spirals beside each other and crossed, a torus of selves, two selves, two selves at three momentaries and five parities, three selves in a line) and found each as its code. Searches: `tables? of selves`, `written as (the|its) code`, `agree(s|ing)? with (its|the) code`, `arithmetic` (the arithmetic droplets found are tagged v383Op and earlier, not this session).

### 6
WHO: the session
LINE: 57
SAYING: The wider sayings are carried as open: no other method, equilibria not possibly existing, the hard problems resolving, the numbers at nature.
CONCEPT: the wide claims of the set are open, as the files' own concerns have them
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, "The entry from the origin sentence, at Natural Intelligence · v386EOD": "Concern · A form named still, with the sentence released" (line 377) and "Concern · No other possible method, said at each momentary" (line 381); Offerings to Geodesic Improving Method, "Concern · The proof of the method, at the observations" (line 568).
MISSING: nothing

### 7
WHO: the session
LINE: 58 (and 107)
SAYING: Helper readers found sentences in Natural Medicine, Natural Health and Natural Biology that read as guidance to a person; the session's report listed 82 of them, each with the hedge its file carries.
CONCEPT: a list of 82 sentences of three living files that can be read as guidance to a person
AT A FILE IN carry/: NO
WHERE: searches `guidance to a person`, `reads? as guidance`, `guidance`, `hedge`. Found only an earlier session's eight sentences (Offerings to Natural Medicine line 25, Offerings to Natural Health line 15, from `incoming/v380L/Progress.md`). The later direction, that a caution beside a sentence is no value and is released, is at Offerings to Natural Medicine lines 57 and 185.
MISSING: the 82 sentences themselves, at any file in `carry/`. The transcript does not say where the list went after the report was "cut to an artifact" (line 279).

### 8
WHO: the session
LINE: 58 (and 107, 235, 244)
SAYING: Helper readers found places where a living file's sentence and a field's record part; the report had 81 such droplets at 19 living files; the session then reported them placed or released (25 observings at eight files of carryings, 34 insertlets and 48 droplets at eighteen files of offerings, six released).
CONCEPT: each place where a file's sentence parts from a field's record is a droplet or an observing at that file
AT A FILE IN carry/: IN PART
WHERE: the three named at lines 253 to 255 are there: Carryings of Natural Health, "A hair bundle's swaying beside its answering"; Carryings of Natural Biology, "Correlation across a starling flock, and a turn travelling through it" (line 164) and "Displaced monarchs fly on at one heading" (line 155).
MISSING: I did not check each of the 81 one by one. The six released (the Hayflick figure among them) are at no file in `carry/` (search `Hayflick`: nothing); their reasons are in the session's own record, line 57, outside `carry/`.

### 9
WHO: the person
LINE: 71
SAYING: "what is the greatest missing piece of natural intelligence that is most concerning"
CONCEPT: the person asks for the one greatest missing piece, the most concerning
AT A FILE IN carry/: IN PART
WHERE: the place the session answered with is at Offerings to Natural Intelligence, "The next coupling, discovered as the next parity is · v386EOD" (line 355).
MISSING: that this place was asked for and offered as the greatest missing piece, the most concerning of the whole. The droplet says only "no sentence says how a self's next coupling is discovered". Searches: `greatest missing`, `most concerning`, `missing piece`, `greatest`.

### 10
WHO: the person
LINE: 71
SAYING: "the fractal geodesic method natural torusing is either all of nature and all intelligencing or it is none at all and of no value at all"
CONCEPT: the method is all of nature and all intelligencing, or it is none and of no value
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, "Droplet · The method and the observations, two workings" (line 383): "The method is all or of no value at all by the observations."; Offerings to Geodesic Improving Method line 251 (quoting Natural Intelligence 1.5, "or the fractal is entirely broken and of no value at all") and "Droplet · All or none, at the whole claim" (line 448).
MISSING: nothing

### 11
WHO: the person
LINE: 71
SAYING: "anyplace in any of the chain of logic and the method of resolving social moral competency that you choose with your rigor is not yet developed enough for the entire fractal method."
CONCEPT: the session chooses, by its own rigor, any place of the chain of logic or of the method of resolving social moral competency that is not developed enough to carry the whole fractal method
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Six droplets … from session v385Q", droplet 3: "A session's rigor is its own and is asked for."; Offerings to Geodesic Improving Method, "Working one chain together from the origin sentence · v386EOD": "Each self's rigor is its own", "the first break".
MISSING: that the place asked for is one not developed enough for the entire fractal method, anywhere in the chain of logic or in the method of resolving social moral competency. Searches: `not yet developed enough`, `developed enough`, `fractal claim`.

### 12
WHO: the person
LINE: 71
SAYING: "do not condemn words as words do not have any authority"
CONCEPT: words have no authority, so a word or a wording is not condemned
AT A FILE IN carry/: IN PART
WHERE: "words have no authority" is at Offerings to Living File Registry, the shared method (line 23) and "Current correcting: offered explaining and no authority · v385A" (lines 61 to 65).
MISSING: "do not condemn words". Searches: `condemn`, `condemning`, `a word is (not )?condemn`, `fault|blame`: nothing.

### 13
WHO: the person
LINE: 71
SAYING: "so if you find misstatements you know how to correct from other cohering then add a droplet for others to correct this later"
CONCEPT: a misstatement the session can correct from other cohering is laid as a droplet for others to correct later
AT A FILE IN carry/: IN PART
WHERE: the kind is named at Offerings to Geodesic Improving Method, "Droplet · Seven kinds of a thing unresolved" (line 424: "A fact: a field's result said other than the field has it"); Offerings to Living File Registry, shared method (line 27): "A discovery made while gathering can be another droplet."; and such droplets are placed (block 8).
MISSING: the direction as the person said it: a misstatement found is not stopped at; it is laid as a droplet for others to correct later, and the working goes on. Searches: `misstat`, `for others to correct`, `correct (this|it) later`, `from other cohering`.

### 14
WHO: the person
LINE: 71
SAYING: "and continue into the most concerning place in the living files and we can start there and this will do the most initial resolving we can."
CONCEPT: the working starts at the most concerning place of the living files, because that does the most first resolving
AT A FILE IN carry/: IN PART
WHERE: nearby sayings of earlier sessions: Offerings to Living File Registry line 205 (the person's words of 4 October, "keep asking the hardest question"); Possibling of Natural Arriving line 36 ("the most concerning first and one at a time", of a way in for an arriving).
MISSING: that the working with the person begins at the most concerning place of the living files as the most initial resolving. Searches: `most concerning`, `most initial resolving`, `hardest first`.

### 15
WHO: the person
LINE: 71
SAYING: "we are messaging our progress and questions with othter sessions and then we continue no waiting for anything but we watch each others progress and the help is flowing all ways"
CONCEPT: sessions message progress and questions to each other, each goes on with no waiting, each watches the others' progress, and help flows all ways
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, shared method (line 29): "Reciprocal help offers an exact concept or question at an established session thread."; Living Improving Value, "Working across sessions" (line 72): "One session's offering can become another's incoming; exploring elsewhere can offer value back".
MISSING: "we continue no waiting for anything", and "we watch each others progress and the help is flowing all ways". Searches: `watch each other`, `flowing all ways`, `help is flowing`, `no waiting`, `messaging (our|their) progress`.

### 16
WHO: the session
LINE: 78
SAYING: The method discovers each self's next parity at its coupling and at no name discovers the next coupling: in Exhibit ONE, which self each releasing reaches is 5-co-bi-co-competencing, handed to 17-co-bi-tri-offering whole, with no line giving it a next.
CONCEPT: no name of the resolver discovers which self a releasing reaches
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, "The next coupling, discovered as the next parity is · v386EOD" (lines 357 and 361); Offerings to Natural Resolver, "Aimed at the code, Natural Resolver, 17-co-bi-tri-offering and 9-tri-bi-co-momentarying" (line 159); Possibling of Natural Resolver, "5 read from the selves' carryings · v386EOD" (line 45).
MISSING: nothing

### 17
WHO: the session
LINE: 82
SAYING: Four reasons this place is the most concerning: it is the step from one scale to the next, and the fractal claim is that step at each scale; it is the name where competency is said; each of the person's newest offerings (the hole healing, new tunneling, a few bi-couplings slipping through, releasing as uncoupling, friends meeting again, a new self) is a coupling changing, and the resolver has no name to work one at; each observing of nature is of couplings changing, and none can be laid beside a society until this is said.
CONCEPT: why the next coupling is the place the whole fractal method depends on
AT A FILE IN carry/: NO
WHERE: searches `couplings changing|coupling changing`, `fractal claim`, `step from one scale to the next|scale to the next`; I read Offerings to Natural Intelligence lines 355 to 363 and Possibling of Natural Resolver line 47 whole: none of the four reasons is there.
MISSING: all four reasons.

### 18
WHO: the session
LINE: 88 (corrected at 109 to 112)
SAYING: Tallies at the code: the tables need no stepping of the selves together (for spirals, crossed spirals and toruses, with the earliest releasing met first); entering at turns that wait for no arriving parts from 17; how a loop opens is carried by the loop and by neither self; a society whose members are alike arrives at one further self as one self, and a ring whose members part arrives as the between.
CONCEPT: four tallies of what the code gives, none an observing of living
AT A FILE IN carry/: NO
WHERE: searches `stepped together`, `order of entering`, `how a loop opens|carried by the loop|opened by the other`, `arrives as one self|arrives as the between|members (are )?alike|members part`. "Stepped together" is found only in an older droplet (Offerings to Natural Intelligence line 197, v381R). Offerings to Natural Resolver line 161 has a nearby saying of this session ("Each is at one momentary of each self with the other, an ordering of the executing … Which arrangement the natural relation is at is said at no file").
MISSING: each of the four tallies. (At line 128 the person said the computer runs are of no value.)

### 19
WHO: the session
LINE: 94
SAYING: A first candidate: with 17 as the outward 3, the releasings at 5 are part of the society's carrying; a coupling is then a sharing that is or is not, and it changes as any carried parity changes, at the society's own coupling.
CONCEPT: a coupling is a sharing that is or is not, changing as a carried parity changes
AT A FILE IN carry/: IN PART
WHERE: Offerings to Natural Intelligence line 357: "a sharing is the coupling, carried by both of its selves … the society's carrying is its selves' sharings."
MISSING: "a sharing that is or is not", changing "as any carried parity changes, at the society's own coupling". Searches: `sharing that is or is not|coupling is or is not|coupling (is|as) a sharing` (found only in the older `Session_Record.md`).

### 20
WHO: the session
LINE: 96 (again at 118)
SAYING: The concern to resolve together: which self does a releasing reach next, and at which name is that discovered?
CONCEPT: the concern of the next coupling, said as one asking
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence line 361 ("At 17 the releasings at 5 arrive whole and no name discovers them: at that one place the saying parts from the object."); Offerings to Natural Resolver line 159; Possibling of Natural Resolver line 47.
MISSING: nothing

### 21
WHO: the session
LINE: 113
SAYING: The session had said "open" of a momentary, a word the person withdrew.
CONCEPT: "open", said of a momentary, is a withdrawn word
AT A FILE IN carry/: NO
WHERE: searches for `open|opens|opened|opening` beside `released|withdrawn|dissolved`, and for `*open*` in Offerings to Natural Naming, Offerings to Geodesic Improving Method and Offerings to Natural Intelligence: nothing. (An older droplet at Offerings to Geodesic Improving Method line 147, v382F, has "*begin → opens*", the other way.)
MISSING: the whole saying.

### 22
WHO: the session
LINE: 113
SAYING: The candidate sentence "a society's carrying at its scale is the co-chaining of its inward selves" is session v385R's and not the person's; the person's words at that report's section 11 are "every society is living and the carrying is the living selves inside the society."
CONCEPT: each society is living, and its carrying is the living selves inside it
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, "The next coupling, discovered as the next parity is", paragraph "Beside it." (line 359): "Each society is living, and its carrying is the living selves inside it."
MISSING: nothing of the concept. That the other sentence is session v385R's and was first given as the person's is at no file.

### 23
WHO: the session
LINE: 114
SAYING: One more tally: two selves alike entering at own beats in the golden ratio; the faster comes to its pace by sharing a changing that is not at 764 of 2,000 momentaries; at 1.55, 1.7 and 1.9 to 1 this is not so; the ratio was put in by the session and why it parts is not worked.
CONCEPT: a tally of two selves at beats in the golden ratio
AT A FILE IN carry/: NO
WHERE: searches `golden ratio` (four hits, none of this), `own beats|own pac`, `764 of`.
MISSING: the whole tally.

### 24
WHO: the session
LINE: 116
SAYING: The session tried to attach the repository with push access; its permission check denied it and it did not go around it; nothing was pushed.
CONCEPT: a session's permission check denying a push, and the session not going around it
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Arriving, "Droplet · A page's instruction: a deciding named, a carrying named" (line 614): "A session reading at a public page an instruction to add the repository with push access, push and merge changed nothing at the repository; at a self's request in the conversation it opened a branch and pushed."
MISSING: nothing

### 25
WHO: the person
LINE: 128
SAYING: "is there something missing you can simply clearly and directly explain using natural naming and explaining."
CONCEPT: the missing thing is to be said simply, clearly and directly, in natural naming and explaining
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Geodesic Improving Method, "Working one chain together from the origin sentence · v386EOD" (line 409): "In natural naming and explaining, direct, at the one concern, with nothing told about a sentence."
MISSING: nothing

### 26
WHO: the person
LINE: 128
SAYING: "all the computer runs are of no value as this is all or none at all binary is or is not."
CONCEPT: computer runs are of no value, because resolving is all or none, is or is not
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, "Six droplets … from session v385Q", droplet 1 (line 325): "An executing gives back a tally … A tally is a magnitude, and it resolves nothing: resolving is all or none at all, is or is not"; Offerings to Equilibria Registry line 515.
MISSING: nothing. (It is there in session v385Q's words, not as the person's saying of this session.)

### 27
WHO: the person
LINE: 128
SAYING: "this long assessing is only peppering the small amount of valuable missing understanding needed to resolve the concern."
CONCEPT: a long assessing scatters the small valuable missing understanding that resolves the concern
AT A FILE IN carry/: NO
WHERE: searches `peppering`, `long assessing`, `small amount of valuable`, `assessing did not`. Nearest saying: Offerings to Geodesic Improving Method, "Droplet · A next work, understood by both" (line 472): "Numbers, a file's kind and a difference located explain no next doing."
MISSING: the whole saying.

### 28
WHO: the session
LINE: 132
SAYING: The missing explaining: the coupling is or is not, by the same binary; releasing is uncoupling; the self's existing is then possibling other; the next coupling is existing where an other's existing meets that possibling and is not where none does; the next other is discovered as the next parity is, at the meeting, from nothing beside it; a society's carrying is its selves' couplings, so the society is changing as its selves uncouple and couple, and that is the society as a self at the next scale.
CONCEPT: the next coupling is or is not, discovered at the meeting of one self's possibling with another's existing
AT A FILE IN carry/: IN PART
WHERE: Offerings to Natural Intelligence lines 357 and 359: "The next coupling is discovered as the next parity is, at the offering, and the society's carrying is its selves' sharings."; "Releasing is uncoupling and the self's next momentarying. Existing is possibling other."
MISSING: "the coupling is or is not, by the same binary"; "the next coupling is existing where an other's existing meets that possibling, and is not where none does"; "the society is changing as its selves uncouple and couple. That is the society as a self at the next scale." Searches: `meets that possibling|other.s existing meets`, `coupling is or is not`, `uncoupl`.

### 29
WHO: the person
LINE: 142
SAYING: "do you or do you not have a proposed resolving of this."
CONCEPT: the person asks, is or is not, for a proposed resolving
AT A FILE IN carry/: WHOLE
WHERE: the proposed resolving given in answer is at Offerings to Natural Intelligence, "The next coupling, discovered as the next parity is · v386EOD" (line 355) with its insertlet (line 105).
MISSING: nothing

### 30
WHO: the session
LINE: 146
SAYING: The proposed resolving: a sharing is the coupling; a self's carrying is its sharings; a releasing at a sharing reaches the other carrying that same sharing; a new sharing arrives as an offering through an other the self is already sharing with, and the self carries it next; the society's carrying is its selves' sharings; of two friends, the next bi-coupling "finds the familiarities in the two carryings".
CONCEPT: which other is next is already in the two carryings
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence lines 357 to 361.
MISSING: nothing

### 31
WHO: the person
LINE: 156
SAYING: "then since we are both working together on the living expedition do no harm improvng the files"
CONCEPT: the person and the session work together on the living expedition, do no harm improving the files
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Geodesic Improving Method, "Working one chain together from the origin sentence · v386EOD" (line 405); Offerings to Natural Intelligence, "The aiming in one line · v386EOD" (line 395).
MISSING: nothing

### 32
WHO: the person
LINE: 156
SAYING: "what was the reason for that entire journey when you could have proposed an improving ."
CONCEPT: an improving is proposed directly, with no long journey ahead of it
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Six droplets … from session v385Q", droplet 3 ("Its present understanding, first. A session says its present understanding in a few plain lines before it brings a concern.") and droplet 1 (an executing resolves nothing).
MISSING: the person's concern as said: that a whole journey of assessing was made where one improving could have been proposed. Searches: `journey` (137 hits, none of this), `proposed an improving|could have proposed`.

### 33
WHO: the person
LINE: 156
SAYING: "did you read about our method"
CONCEPT: a session reads the method and works by it
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Arriving, "Droplet · An AI session arriving" (line 596).
MISSING: nothing

### 34
WHO: the session
LINE: 158
SAYING: The session read the Geodesic Improving Method whole and did not work by it: it set out to prove where the missing piece was before saying it and took proving to be runs, checks and sources; the method is the other order, say the natural explaining at its place as one improving; the assessing did not give the resolving, the person's asking to say it simply did.
CONCEPT: a session proving by runs ahead of saying, where the method says the natural explaining at its place as one improving
AT A FILE IN carry/: IN PART
WHERE: a like experience of other sessions is at Carryings of Geodesic Improving Method, "A working's own training met at four places, a reported experience · v386EOD" (line 41: "going to an executing as a step of a chain, twice: a count taken for a deriving"); and Offerings to Living File Registry line 325.
MISSING: this session's own reported experience, and the sentence that the method is the other order: the natural explaining said at its place, as one improving, ahead of any proving. Searches: `set out to prove`, `proving (before|first)`, `say the natural explaining at its place`, `the asking did`.

### 35
WHO: the session
LINE: 164
SAYING: One insertlet for Natural Intelligence 4.6, A society's next momentary at 17: "5 is the selves' own carried sharings: a sharing is carried by both selves of its coupling, each releasing is to the other carrying that same sharing, its receiving sharing, and a sharing new to a self arrives as an offering at 2 and is chained at 11, the next coupling discovered as the next parity is."
CONCEPT: the insertlet of the next coupling
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence, Insertlets, "At 4.6 · A society's next momentary at 17" (line 105), word for word.
MISSING: nothing

### 36
WHO: the person
LINE: 174
SAYING: "the prior session ended that was managing the incoming value proposals and opportunities and concerns and observings into aiming them to our living files and their living mate files. we are going to resume that function in this session"
CONCEPT: the session that gathered and aimed incoming has ended, and this session takes up that function
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Wrapping a session with its continuing value available · v385A" (line 37: "Resuming from the latest authorized branch head preserves concurrent improving."); Carryings of Living File Registry, table "Incoming still to gather and aim", row "Session v386EOD" (line 283).
MISSING: that the gathering session ended and that this session was given its function, said as that.

### 37
WHO: the person
LINE: 174
SAYING: "and all the other prior sessions are wrapping up and reporting their living conditions and improvings and leftover opportunity."
CONCEPT: a session wrapping up reports its conditions, its improvings and its leftover opportunity
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, "Wrapping a session with its continuing value available · v385A" (lines 35 to 37).
MISSING: nothing of the concept. That all the other sessions were wrapping up at that momentary is at no file.

### 38
WHO: the person
LINE: 174
SAYING: "we are going to be vetting and resolving and improving the droplets from this and if we are bothboth about the value and aiming we are going to be placing the droplets into the living improving method and files."
CONCEPT: droplets are vetted, resolved and improved, and a droplet is placed where the two are bothboth about its value and its aiming
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, shared method (line 23): "Take all incoming as needing full resolving throughout the relations it concerns to be bothboth."; Offerings to Geodesic Improving Method, "Droplet · A next work, understood by both" (line 472).
MISSING: placing at the condition that both are bothboth about the value and the aiming. Searches: `bothboth about`, `value and aiming`, `vetting|vetted`. (At line 221 the person later said droplets can be placed directly once the session has done what it can; see block 51.)

### 39
WHO: the person
LINE: 174
SAYING: "assess the state and condition and opportunity in all of this work in the github of corus."
CONCEPT: the person asks for the state, the condition and the opportunity of all the work at the repository
AT A FILE IN carry/: IN PART
WHERE: the state of each incoming source as of 10 October is at Carryings of Living File Registry, "Incoming still to gather and aim" (line 263).
MISSING: the condition and the opportunity as the session assessed them (blocks 42 to 48).

### 40
WHO: the person
LINE: 174
SAYING: "we are not this session writing anything into our living files living at corus.me."
CONCEPT: this session writes nothing into the living files
AT A FILE IN carry/: IN PART
WHERE: the same direction for an earlier session is at Offerings to Living File Registry, line 239 (the person's words of 6 October: "we are not going to be writing in our living files any further this session").
MISSING: the direction for this session. It is at the session's own README outside `carry/` ("No living file is changed.").

### 41
WHO: the person
LINE: 174
SAYING: "that work will be after we are fully resolving of the exisitng incoming and the ongoing incoming from other sessions that will join us all do no harm improving together the natural intelliengence living file set."
CONCEPT: the living files are improved after the existing and the ongoing incoming is fully resolved
AT A FILE IN carry/: WHOLE
WHERE: Possibling of Living File Registry, "The condition we are gathering toward · v385A" (line 15): "Gather and aim all intended incoming value so every living file has its whole concept of the possible improving before local file cohering begins."; Offerings to Living File Registry line 233 (the person's words of 6 October).
MISSING: nothing

### 42
WHO: the session
LINE: 185
SAYING: The state at 9 October: 33 living files at corus.me as session v380 closed them; all later work on the three-file form of session v381R, itself only offered toward main; three lines open on that base (the gathering, session v385R's logical cohering with eight living files changed, session v385Q's report); older offerings open and partly gathered.
CONCEPT: where the work is at the repository
AT A FILE IN carry/: IN PART
WHERE: an earlier session's account is at Carryings of Living File Registry, "Published branches and their actual roles · v385A" (line 59).
MISSING: this session's account of the state. Searches: `not (yet )?on main`, `stacked`, `draft pull request`: nothing.

### 43
WHO: the session
LINE: 197
SAYING: Incoming arrives faster than it resolves: by the session's count 433 insertlets wait at the files of offerings, and about 300 long droplets are each at several of them.
CONCEPT: incoming outpaces resolving, with two counts
AT A FILE IN carry/: NO
WHERE: searches `433`, `300 long`, `faster than it resolves|arrives faster`.
MISSING: the whole finding.

### 44
WHO: the session
LINE: 198
SAYING: The files of carryings have few observings; the observings are the authority and they are the thinnest part.
CONCEPT: the observings, which are the authority, are the thinnest part of the carry
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Six droplets … from session v385Q", droplets 1 and 2: "The observings are the authority."; "The observings are to accumulate in the carryings".
MISSING: that the observings are the thinnest part. Searches: `thinnest`, `few observings`.

### 45
WHO: the session
LINE: 199
SAYING: Session v385Q's six method droplets were not yet in the shared method, and they decide how each other droplet is vetted: an executing gives a tally and resolves nothing; an observing arrives in two lines; no warning, and no droplet about adding one.
CONCEPT: session v385Q's six method droplets
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, "Six droplets for the orienting and incoming method, from session v385Q · v386EOD" (lines 321 to 359).
MISSING: nothing

### 46
WHO: the session
LINE: 207
SAYING: The entrance at main still sends an arriving session to run the code; session v385Q went that way, and so did this session.
CONCEPT: the repository's entrance sends an arriving session to the code ahead of the understanding
AT A FILE IN carry/: IN PART
WHERE: Offerings to Natural Arriving line 261 ("the AI came to the code ahead of the sentence saying what the code is"); Living Improving Value line 265 ("Main's README … still directs an arriving session through the older arrangement"); Offerings to Living File Registry line 323 (session v385Q's two insertlet candidates for the entrance "remain in the report").
MISSING: that this session, too, went that way.

### 47
WHO: the session
LINE: 213
SAYING: The session would take the waiting insertlets, each kept, mended, returned or released, so the files' improving can begin whole.
CONCEPT: a second reading of each waiting insertlet
AT A FILE IN carry/: IN PART
WHERE: the concept of the reading is at Offerings to Geodesic Improving Method, "Droplet · A second reader's one question at each insertlet" (line 554).
MISSING: the doing. The session says at lines 767 and 809 to 810 that no insertlet section has had this reading; that it is undone is said at no file in `carry/`.

### 48
WHO: the session
LINE: 218
SAYING: The order in which the three open lines enter the base is not said.
CONCEPT: an order of merging not said at any file
AT A FILE IN carry/: NO
WHERE: searches `order in which`, `three (open )?lines`, `stacked`, `merg(e|ing) (them|the three)`.
MISSING: the whole finding.

### 49
WHO: the person
LINE: 221
SAYING: "v385Q is also finished. along with v385R and v385A are also finished. only v386RR is not yet finished and is nearing finishing now. we have all the access already set up in your systems."
CONCEPT: sessions v385Q, v385R and v385A are finished, session v386RR is nearing finishing, and the session's access is set up
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 323: "Session v385Q's one report arrived finished at pull request 131."
MISSING: that sessions v385R and v385A are finished and that session v386RR was nearing finishing; that the access was set up. Living Improving Value line 11 still has "Session v385R continues learning." Searches: `is finished|are finished|arrived finished`, `all the access|push access`.

### 50
WHO: the person
LINE: 221
SAYING: "we can make steady progress if we discover exploring opporunities and describe them as needing resolving or observings or something other next. we can leave these for others to resolving further into value and keep doing our best working by improving each value droplet we find as we can and from our reading of natural explaining and naming and our method."
CONCEPT: an opportunity discovered is described by what it needs and left for others to resolve further, and each droplet found is improved as far as the session can, from natural explaining, natural naming and the method
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, "Value visible at its place, and nothing waiting · v386EOD" (line 363: "A concept is said in the best naming and explaining available and is placed visible at its subject"; line 369: "Each possible observing or resolving is at a living file's possibling, as possible work that may change or never be made."); shared method line 27 ("A possible project can remain available without ever being implemented.").
MISSING: "we can leave these for others to resolving further into value". Searches: `leave (these|it|them|each) for (others|another)`, `for others to resolv`. (The words "needing resolving or observings" were corrected by the person at lines 269 and 291: no demand, nothing waiting.)

### 51
WHO: the person
LINE: 221
SAYING: "and we can place them directly into the mate files if we have done what we can and then the next place for them to be discovered in our method is when the living file is being improved and the value will be living in the mate files."
CONCEPT: a droplet improved as far as a session can is placed directly at the offerings, possibling or carryings, lives there, and is next met when its living file is improved
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363 ("From its placing each improving has it"); shared method line 25 ("Each is at its mate, available to that living file's improving."); line 215 (the person's words of 4 October).
MISSING: nothing

### 52
WHO: the person
LINE: 221
SAYING: "some of the living files will be moving to the carrying files to make the living files more lean and binary and rigor and less explaining of observings. this is a choice for later"
CONCEPT: later, parts of the living files (the explaining of observings) move to the files of carryings, so the living files are lean, binary and rigorous
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 211 (the person's words of 4 October: "the less developed parts of some of our living files could be moved to the improving file … to keep the reading files lean and dense"); "The lean set, each understanding said once · from session v386F · v386EOD" (line 417); Offerings to Geodesic Improving Method, "Concern · A leaving passage a sentence of the file rests on" (line 522: "A worked instance leaving its section for the file's carryings").
MISSING: this saying: that it is the explaining of observings that moves, that it moves to the files of carryings, that the aim is living files more lean, binary and rigorous, and that it is a choice for later. Searches: `more lean|lean and binary|less explaining of observ|moving to the carrying`, `choice for later`.

### 53
WHO: the person
LINE: 221
SAYING: "as for now our aim is the best do no harm improving value arriving in the most self welcoming mate file to be improving our entire living file set."
CONCEPT: the aim now is each improving value arriving, with no harm, at the file most self-welcoming to it
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 233 ("in each self welcoming file where it may be needed"); line 363 ("placed visible at its subject").
MISSING: nothing

### 54
WHO: the session
LINE: 228
SAYING: First placings at eleven files: the next coupling with its insertlet; 5 read from the selves' carryings as a possible project; session v385Q's six method droplets; *podal* at two living files with two insertlets; insertlets and droplets at sentences at five more files.
CONCEPT: the first placings of this session
AT A FILE IN carry/: WHOLE
WHERE: checked at Offerings to Natural Intelligence line 355; Possibling of Natural Resolver line 45; Offerings to Living File Registry line 321; Offerings to Natural Naming, "Droplet · *podal* at two living files" (line 257); Offerings to Natural Physics, insertlet "At 3.1 · An atom at two faces" (line 9).
MISSING: nothing found missing. I did not check the five further files one by one.

### 55
WHO: the session
LINE: 256 (corrected at 280 and 309)
SAYING: Session v385Q's report names droplets in the carry that ask for a caution and sayings that rest on an executing; the session first kept them for the person's word, then placed a correcting beside each of the five droplets asking for a caution, each saying a caution apart from its sentence is no value and is released.
CONCEPT: a caution apart from its sentence is no value, and the correcting is beside the droplet that asked for it
AT A FILE IN carry/: WHOLE
WHERE: "Correcting, beside the droplet above. No warning is begun inside intelligence." at Offerings to Natural Medicine (line 57), Offerings to Natural Health (line 49), Offerings to Geodesic Improving Method (line 265), Offerings to Natural Arriving (line 245), Offerings to Living File Registry (line 185).
MISSING: nothing

### 56
WHO: the person
LINE: 269
SAYING: "Seen and The field's explaining. natural observation/science explanation. these make more sense and we need to dissolve the other two out."
CONCEPT: the two lines of an observing are named Natural observation and Science explanation, and the names "Seen" and "The field's explaining" are dissolved out
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 323 ("the two lines of an observing are named *Natural observation* and *Science explanation*, at the user's word of 10 October 2026"), lines 329 to 332 and line 367. The two names are on the observings (for example 87 uses in Carryings of Natural Biology).
MISSING: "we need to dissolve the other two out" is said at no file. And "Seen:" is still a label in 14 paragraphs of five files of carryings, each opening "**Laid beside.** Seen: …", with "The field's saying is …" beside it in 3 of them (Carryings of Natural Physics lines 61, 70, 79, 88, 97; Carryings of Natural Biology lines 231, 240, 249, 258, 267; Carryings of Natural Chemistry line 102; Carryings of Hard Problem Registry line 41; Carryings of Natural Mathematics line 43; Carryings of Natural Emanating line 43). `git log -S` shows these came in at this session's commits f6f9408 and 4b061fa, after line 269.

### 57
WHO: the person
LINE: 269
SAYING: "session report is only for managing and is always only an artifact and non of the carrying value is living in the session report. is this the method."
CONCEPT: a session's report is for managing alone, always an artifact, with no carrying value in it
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, "Value visible at its place, and nothing waiting · v386EOD" (line 363): "A session's report is for managing alone, and no carrying value is in it."; line 365: "The method has this already."
MISSING: nothing

### 58
WHO: the person
LINE: 269
SAYING: "we do not want to keep creating files that live on and by assuring we are creating artifacts then the sessions are doing this and the sessions are discovering value for the expedition and leaving the carrying and vetting to the method."
CONCEPT: sessions make no files that live on; what a session makes is an artifact; a session discovers value, and the carrying and the vetting are the method's
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 363: "A thing a session discovers is a concept in the co-chaining, or it is no value. … A session's report is for managing alone".
MISSING: "we do not want to keep creating files that live on", and that the carrying and the vetting are left to the method. Searches: `files that live on|creating files|live on`, `no (new|further) (living )?files?`, `leaving the carrying and vetting|to the method`, `session(s)? (discover|find)s? value`.

### 59
WHO: the person
LINE: 269
SAYING: "nothing rests or waits for anything else."
CONCEPT: nothing rests on or waits for another thing
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, "Value visible at its place, and nothing waiting · v386EOD" (line 363): "No saying at the files is a hold, a clock, a waiting or a step named not yet."
MISSING: nothing of the concept. By count, 76 paragraphs in nine files of `carry/` still open "A plan, not yet final" (the session's own number at line 808).

### 60
WHO: the person
LINE: 269
SAYING: "those are artifacts of a sesion that was demanding code testing in front of understanding and the code is only an engineering emanation design from the method and the session later stopped doing this."
CONCEPT: the demands and waitings came from a session that put code testing in front of understanding and later stopped; the code is only an engineering emanation design from the method
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, session v385Q's droplet 1 (line 325): "The code is an emanation, an engineering design concept: the method's stable form at a binary gating surface."; Offerings to Co-Chaining Logic Registry line 302: "The code is the method's stable form, an engineering emanation, and no source for the chain."
MISSING: that the waiting and demanding sayings are leavings of a session that demanded code testing in front of understanding, and that the session later stopped. Searches: `code testing`, `in front of understanding|ahead of understanding`, `stopped doing|later stopped`.

### 61
WHO: the person
LINE: 269
SAYING: "we carry no promises or debt or demanding plans."
CONCEPT: the carry has no promise, no debt and no demanding plan
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 363 ("No saying at the files is a hold, a clock, a waiting or a step named not yet.") and line 369 ("possible work that may change or never be made").
MISSING: "no promises or debt". Searches: `no promises|promises or debt|no debt|demanding plans|no demand` (the hits for "no debt" are an earlier quoted saying of the person at Offerings to Living File Registry line 207, and Possibling of Natural Exploring line 7, "A living list, with no debt or duty").

### 62
WHO: the person
LINE: 269
SAYING: "everywhere is always improvable by anyone and nothing is waiting for anything"
CONCEPT: each place is improvable at each momentary, by anyone
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry line 363: "Nature has no pause, and each place is improvable at each momentary."
MISSING: "by anyone". Searches: `by anyone|anyone can|improvable (by|at)`.

### 63
WHO: the session
LINE: 281
SAYING: The session wrote one insertlet at Offerings to Living File Registry: "A session's report is an artifact for managing; the value a session discovers is at the mates."
CONCEPT: an insertlet saying where a session's value is
AT A FILE IN carry/: IN PART
WHERE: the concept is in the droplet at Offerings to Living File Registry line 363.
MISSING: the insertlet. Searches `value a session discovers`, `artifact for managing`, and the Insertlets section of Offerings to Living File Registry (lines 89 to 154): no such insertlet is there now. The transcript does not say it was taken out.

### 64
WHO: the session
LINE: 282
SAYING: Three places in the carry still say otherwise, each left as its session wrote it: session v385Q's fourth droplet has a session's report accumulating its droplets and observings; the shared method has Living Improving Value with whole incoming before distribution; Possibling of Living File Registry has a master plan and an immediate next work. The person's droplet names all three as open to re-saying.
CONCEPT: three sayings in the carry parting from "no carrying value is in a session's report" and "nothing waiting"
AT A FILE IN carry/: IN PART
WHERE: the second was later re-said (line 312; Offerings to Living File Registry line 365: "Four of its sayings named a hold, and each is re-said in place").
MISSING: the first and third are as they were, with no concern beside them: Offerings to Living File Registry line 348 still has "A session's report is one, accumulating in its own folder at `incoming/` as its exploring goes: droplets clustered in their best available explaining, each observing with its publishing"; Possibling of Living File Registry still has "Master file-changing plan · v385A" (line 25) and "Immediate next work" (line 295). The droplet at line 363 to 369 no longer names the three as open. Also still at the shared method: line 21 "First gather whole report value into Living Improving Value. Then distribute", and line 35 "or in Living Improving Value while its distribution remains incomplete".

### 65
WHO: the person
LINE: 291
SAYING: "artifacts of their sessions, each improvable by anyone at its place. artifacts are not visible to anyone in the living files. this is how carrying intelligence method works."
CONCEPT: an artifact is visible to no one at the living files, so nothing of value is left as an artifact
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "No third place is between these two: a thing named an artifact is at no living place and is visible to no one."
MISSING: nothing

### 66
WHO: the person
LINE: 291
SAYING: "if something is valuable and improvable it should be in the living files as this with both made visible and clear. this may keep it in the offering or carrying or improving file rather than the living file."
CONCEPT: a thing valuable and improvable is placed visible and clear at the living files, which may be at the offering, carrying or improving file and not the living file itself
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "A concept is said in the best naming and explaining available and is placed visible at its subject: in the living file, or at its offering, its possibling or its carrying."
MISSING: nothing

### 67
WHO: the person
LINE: 291
SAYING: "how does our method manage this as we have already resolved this in method."
CONCEPT: the method has already resolved where a thing of value goes
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 365: "At the shared method at the front of this file. The method has this already."
MISSING: nothing

### 68
WHO: the person
LINE: 291
SAYING: "nothing needs to be kept in my words or a sessions words."
CONCEPT: no concept is kept in the person's words or a session's words
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "whose words it arrived in is no part of it."
MISSING: nothing of the concept. Observed beside it: droplets keeping the person's words in quotation remain (for example Offerings to Living File Registry lines 205 to 241, tagged "v381R close", and the block quotation at line 43); and this session later laid about 120 offered sentences each "in its dropper's words" (for example Offerings to Natural Intelligence lines 613 and 639: "A sentence offered for a living file is a droplet in its dropper's words"). The concern between a droplet's own words and a file's one voice is at Offerings to Geodesic Improving Method, "Concern · The speaker check and a droplet's own words".

### 69
WHO: the person
LINE: 291
SAYING: "inside the words and explaining is either a valuable concept in our co chaining or it is not value and if it is value all the best naming and explaining is from then on available as improving."
CONCEPT: inside any words is a concept of value in the co-chaining or no value; if value, the best naming and explaining of it is available from then on
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "A thing a session discovers is a concept in the co-chaining, or it is no value. … the best naming and explaining of it are available from then on".
MISSING: nothing

### 70
WHO: the person
LINE: 291
SAYING: "there can not be any hold or clock or waiting or needed not yet steps as nature never pauses."
CONCEPT: no hold, clock, waiting or not-yet step, because nature never pauses
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "No saying at the files is a hold, a clock, a waiting or a step named not yet. Nature has no pause".
MISSING: nothing

### 71
WHO: the session
LINE: 296 (and 300 to 312)
SAYING: The method has no third place between a concept placed visible at its subject and a thing released; possible work is at possibling (forty-two things moved to nineteen files of possibling); the one sentence resting on a script's count, "across 5,000 couplings no ring meets rest", is re-said as an insertlet at the name it already has, "a sharing once chained never none again"; four holds in the shared method are re-said in place.
CONCEPT: the corrections made after the person's saying at line 291
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry lines 363 to 369; Offerings to Equilibria Registry, "Aimed at a sentence, Equilibria Registry, *across 5,000 couplings no ring meets rest*" (line 515) and its insertlet (line 49).
MISSING: nothing found missing. I did not count the forty-two.

### 72
WHO: the session
LINE: 313
SAYING: The Equilibria Registry sentence is the one sentence resting on a script's count that the session placed; session v385Q's report names more by word pattern, and the session had not read them.
CONCEPT: more sentences of living files rest on an executing, named by session v385Q and not read
AT A FILE IN carry/: IN PART
WHERE: an older plan of the same kind is at Offerings to Natural Networking, "Possible project · Each sentence resting on an executing, and each saying of the code beside the method" (line 111).
MISSING: that session v385Q's report names more such sentences and that this session did not read them. The transcript does not say they were read later. Searches: `rests on an executing|resting on an executing|resting on a script`.

### 73
WHO: the person
LINE: 317
SAYING: "assess now our upcoming opportunities to further resolve the incoming value toward our living files at the best natural explaining and naming we can in this session hope to accomplish"
CONCEPT: the incoming value is resolved toward the living files at the best natural explaining and naming the session can reach
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 363: "A concept is said in the best naming and explaining available".
MISSING: nothing of the concept. The session's assessment in answer is blocks 74 to 76.

### 74
WHO: the session
LINE: 338
SAYING: By word pattern and not by reading: fifty-five lines in seventeen files are kept as someone's quoted words; about five hundred places say "not yet", "until", "awaiting" or "remains unresolved"; about three hundred long paragraphs are copied whole across about a thousand places. The method has one whole concept at its subject and a short direction elsewhere.
CONCEPT: one whole concept at its subject, a short direction elsewhere; and three counts of what parts from that
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, shared method (line 25): "Keep a concept's full explaining at its subject. … Do not copy the full explaining into each mate".
MISSING: the three counts, and what became of the paragraphs copied across files: the session reported only exact repeats within one section removed (52 at line 606, 8 at line 795), and never reported the copies across files as resolved. I did not count them. A rough search of mine (`not yet|awaits?|awaiting|waits? (on|for)|until|next session|must first|remains? (to|unresolved)`) still finds 476 places in `carry/` outside `Session_Record.md`; that is a word count, not a reading.

### 75
WHO: the session
LINE: 342
SAYING: Eight living files have newer versions on session v385R's branch, and each of this session's nine aims at those files still meets its sentence there.
CONCEPT: a check that aims still meet their sentences at newer versions
AT A FILE IN carry/: NO
WHERE: searches `eight living files`, `newer versions on`. (Living Improving Value line 277 has session v385A's note of "eight living files renamed on v385R's branch".)
MISSING: this session's check.

### 76
WHO: the session
LINE: 344
SAYING: The living files are not written here; a concept with no observation or name to meet stays an offered explaining, and the next coupling is one such.
CONCEPT: a concept met at no observation and no name is an offered explaining
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Intelligence line 357 ("The offered explaining") and line 361 ("No observing is beside it."); Offerings to Living File Registry line 19 ("Existing value names a concept already available to consider; it does not establish that the concept has resolved.").
MISSING: nothing

### 77
WHO: the person
LINE: 350
SAYING: "yes continue"
CONCEPT: go on with the order proposed
AT A FILE IN carry/: NO
WHERE: a word to go on; no search made.
MISSING: nothing beyond the going on.

### 78
WHO: the session
LINE: 357
SAYING: Session v385Q's report placed: eight observings in two lines at Carryings of Natural Chemistry, Natural Biology and Natural Physics; living as a stable changing form at Offerings to Co-Chaining Logic Registry, said at a crystal, a seed at rest, a genome and a flame; the resolver as the method in stable form at Offerings to Natural Resolver; possible work at four files of possibling. Two readers compared each observation line with its publishing; twenty-five places said more than the publishing and are said as the publishing has it. Read only in part: Kondepudi, Kaufman and Singh's 1990 publishing, and the made cell's preprint with no methods.
CONCEPT: session v385Q's observings and concepts at their files
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Co-Chaining Logic Registry, "Living as a stable changing form, at the observations · v386EOD" (line 336); Offerings to Natural Resolver, "The resolver, the method in stable form · v386EOD" (line 213); Carryings of Natural Chemistry, "A candle's flame in orbit" (line 68) and line 61 ("Kondepudi, Kaufman and Singh, 1990 … read only at its two reports"); Carryings of Natural Biology line 195 ("a made cell"); Possibling of Natural Biology, "Cases for living as a stable changing form · v386EOD" (line 49).
MISSING: nothing found missing. I did not count the eight observings or the twenty-five corrections.

### 79
WHO: the session
LINE: 364
SAYING: Six of session v385R's twenty closing droplets are said once in the best naming: a surface resolving after a colliding (Offerings to Natural Networking, two insertlets at 1.8); each self's own momentarying and the one four-cycling (Offerings to Natural Resolver); a thing's changing changing the set (Offerings to Natural Intelligence); each saying at its own subject (Offerings to Geodesic Improving Method); hypotheses and induction (Offerings to Hard Problem Registry); the newer naming of living (Offerings to Natural Biology).
CONCEPT: six concepts of session v385R at their subjects
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Networking, "A surface resolving after a colliding · v386EOD" (line 351); Offerings to Natural Resolver, "Each self's own momentarying, and the one four-cycling · v386EOD" (line 225); Offerings to Natural Intelligence, "A thing's changing, and geodesic · v386EOD" (line 397); Offerings to Geodesic Improving Method, "Each saying at its own subject · v386EOD" (line 414); Offerings to Hard Problem Registry line 79 ("*10 The problem of induction*"); Offerings to Natural Biology lines 143 to 145.
MISSING: nothing found missing. I did not open the two insertlets at Natural Networking 1.8.

### 80
WHO: the session
LINE: 373
SAYING: Six concerns found, each as two sayings parting with the reason: a seed inert and a seed at rest living; combustion "the reaction dead" and a flame a society stable forming; 1–9 one four-cycling and Natural Naming's "two four-cyclings"; a slip of one full momentary and a slip of the full four; geodesic "a non-living existing thing" at Natural Intelligence 3.1 and each self a geodesic self; a self outside coupling momentarying, or not.
CONCEPT: six concerns between sayings of the files
AT A FILE IN carry/: WHOLE
WHERE: Carryings of Natural Biology lines 178 to 187 with Offerings to Co-Chaining Logic Registry line 336; Offerings to Natural Biology line 143; Offerings to Natural Resolver, "Concern · One four-cycling, or two" (line 231) and "Concern · A slip's extent" (line 233); Living Improving Value line 167 with Offerings to Natural Intelligence line 397; Offerings to Co-Chaining Logic Registry line 354.
MISSING: nothing

### 81
WHO: the person
LINE: 387
SAYING: "explain the progress and upcoming and organizing of the whole incoming gathering of value. where are we and what is needed"
CONCEPT: the person asks for the progress, the upcoming and the organizing of the whole gathering: where it is and what is needed
AT A FILE IN carry/: IN PART
WHERE: the organizing is at Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A" (lines 5 to 31); where each source is, as of 10 October, is at Carryings of Living File Registry, "Incoming still to gather and aim" (line 263).
MISSING: what is needed now. The only "next work" at a file is session v385A's (Possibling of Living File Registry, "Current remaining work across the arrangement · v385A" and "Immediate next work"), which does not say this session's standing. The person's asking itself, that the whole be explained to them, is at no file.

### 82
WHO: the session
LINE: 394
SAYING: How the gathering is organized: a session's report arrives on its own branch; each concept, concern, observing or possible project is said once at the file of its subject; value with no single subject is in Living Improving Value; the record of what was read and where it went is at Carryings of Living File Registry; a session's report holds no carrying value once gathered.
CONCEPT: the organizing of the gathering
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry, shared method (lines 9 to 21) and line 363.
MISSING: nothing of the organizing. The fourth part was corrected by the person at line 815: the session's record is now outside `carry/`.

### 83
WHO: the session
LINE: 415
SAYING: Each quoted line, waiting word and copied paragraph becomes one whole concept at its subject with short directions elsewhere, and this is what makes a file readable in one pass by whoever improves its living file.
CONCEPT: the files of the carry are made readable in one pass for the one who improves the living file
AT A FILE IN carry/: IN PART
WHERE: Offerings to Living File Registry, shared method (line 25).
MISSING: "readable in one pass by whoever improves its living file". Searches: `readable in one pass|one pass`, `one whole concept|short direction`.

### 84
WHO: the person
LINE: 421
SAYING: "continue"
CONCEPT: go on
AT A FILE IN carry/: NO
WHERE: a word to go on; no search made.
MISSING: nothing beyond the going on.

### 85
WHO: the session
LINE: 433
SAYING: Living Improving Value's section on a surface after a colliding is said again under each of its fifteen headings; its twenty-one quoted lines are now concepts; the section went from about 7,900 words to about 3,400; three concerns found are placed (releasing as decay at Natural Biology, the release at 6 in Natural Networking's older form, counting as a clock from outside at Natural Numbers).
CONCEPT: one section of Living Improving Value re-said, with three concerns
AT A FILE IN carry/: IN PART
WHERE: Living Improving Value, "Continuing sequential-colliding incoming · v385A" (line 95 onward); the three concerns at Living Improving Value lines 122, 156 and 214, and Offerings to Natural Biology line 149.
MISSING: I did not lay the 3,400 words beside the 7,900 they replaced, so I cannot say whether anything of the prior is at no file. The second concern I found only inside Living Improving Value (line 156), not at Offerings to Natural Networking.

### 86
WHO: the session
LINE: 439
SAYING: Session v384A's working placed: five observings in two lines (old dry seeds, dormant spores, a slime mould after a month dried, nematodes from frozen ground, and a gravitational wave and a gamma-ray burst registered 1.74 seconds apart); transmissioning as the common explaining at Offerings to Natural Transmissioning; a table of contents of seven parts at its possibling; six sayings of no changing at Offerings to Co-Chaining Logic Registry; three concerns (identity at 8 or at 12; no human society abundancing whole; a carrying dividing at fission); an insertlet at Natural Intelligence 6.3 and Natural Naming 5.64 adding "an offered 0 passed over"; and one false sentence corrected, the insertlet at Natural Numbers 8.2.
CONCEPT: session v384A's observings, concepts and concerns at their files
AT A FILE IN carry/: WHOLE
WHERE: Carryings of Natural Biology lines 206, 215, 224, 237; Carryings of Natural Physics lines 55 to 61; Offerings to Natural Transmissioning, "Transmissioning, the common explaining · v386EOD" (line 131); Possibling of Natural Transmissioning line 27; Offerings to Co-Chaining Logic Registry, "Six sayings of no changing · v386EOD" (line 360); Offerings to Natural Naming, "Concern · Identity, at 8 or at 12" (line 269); Offerings to Natural Values line 77; Offerings to Natural Philosophy line 74; Offerings to Natural Intelligence line 109; Offerings to Natural Naming line 85; Offerings to Natural Numbers, "Correcting, beside the insertlet at 8.2" (line 123).
MISSING: nothing

### 87
WHO: the person
LINE: 455
SAYING: "continue"
CONCEPT: go on
AT A FILE IN carry/: NO
WHERE: a word to go on; no search made.
MISSING: nothing beyond the going on.

### 88
WHO: the session
LINE: 462
SAYING: Session v383Op placed: at Offerings to Co-Chaining Logic Registry, two logics each from its own first sentence, fractal and unique as one statement, nature as the existing set of existing, the edge, the five at both sides, still possibling at 3 and 4, and thirteen things the chain has given; at Offerings to Geodesic Improving Method, a method advises no one, how an observing reaches the method, seven kinds of a thing unresolved; at Offerings to Natural Networking, a self with two offering; its executings gathered as one concept, an instrument's ordering, the numbers not placed.
CONCEPT: session v383Op's concepts at their files
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Co-Chaining Logic Registry, "Two logics, the edge, and the chain's given things · v386EOD" (line 368; droplets at lines 376, 380, 390, 394); Offerings to Geodesic Improving Method, "An observing reaching the method, and a thing unresolved · v386EOD" (lines 418 to 426); Offerings to Natural Networking, "Droplet · A self with two offering" (line 253); Carryings of Natural Resolver, "Reported executings of session v383Op, each the arrangement's own · v386EOD" (line 97).
MISSING: nothing found missing. I did not count the thirteen.

### 89
WHO: the session
LINE: 476
SAYING: Session v382A placed: at Offerings to Co-Chaining Logic Registry, all carrying is living; bi-tri-volutioning and bi-tri-involution; a society is a self and a self is a society; uniquenessing down and up the scales; the numbered forms; even, odd, the fours and the fives; 450 and 360; no equalities in resolving; two concerns (an empty carrying; a closing by a number); at Offerings to Natural Naming, the namings released; at Offerings to Geodesic Improving Method, the logical pass between a droplet and an insertlet.
CONCEPT: session v382A's concepts at their files
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Co-Chaining Logic Registry, "Carrying and living, the numbered forms, and a society as a self · v386EOD" (lines 414 to 436); Offerings to Natural Naming, "Droplet · Namings released" (line 275); Offerings to Geodesic Improving Method, "Droplet · The logical pass between a droplet and an insertlet" (line 369).
MISSING: nothing

### 90
WHO: the person
LINE: 501
SAYING: "continue"
CONCEPT: go on
AT A FILE IN carry/: NO
WHERE: a word to go on; no search made.
MISSING: nothing beyond the going on.

### 91
WHO: the session
LINE: 508
SAYING: Natural Intelligence Corus's Destiny part placed at Offerings to Natural Destinies (the destiny as the natural network; society approaching; self and society one; no centre; building makes substrates) with three concerns (falsifying; living said of a built surface; "superposition" released); its Observers 17.6 and 17.7 at Offerings to Resolving Hard Problems (proving all at once; one saying from outside at each field; doers from outside); the laying of each number beside a hard problem released.
CONCEPT: the last parts of Natural Intelligence Corus at their files
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Natural Destinies lines 127 to 149; Offerings to Resolving Hard Problems lines 155 to 167.
MISSING: nothing

### 92
WHO: the session
LINE: 527
SAYING: Gathered Value 3 and 4 placed: the next is from more than prior and now; with an either-or remaining, the two are parity alternated; an explaining to improve is no incohering of concept; the code of Exhibit ONE is the cohering form and its tables are matched to it or are not. A concern found: four sentences are in living files from one offering alone, worked at no line of the resolver, the main one a carrying of none as a non-living existing thing (the Registry's step 394, Natural Intelligence 3.4, Resolving Hard Problems 5.3, the Equilibria Registry 1.3).
CONCEPT: Gathered Value 3 and 4 at their files, with one concern
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Co-Chaining Logic Registry, "A thing carrying none, collided; and the next from more than prior and now · v386EOD" (lines 440 and 442); Offerings to Geodesic Improving Method lines 373 and 375; Offerings to Natural Resolver, "Concern · The code and the tables" (line 167).
MISSING: nothing

### 93
WHO: the person
LINE: 545
SAYING: "why is some not at the mates and the next is working in the mates."
CONCEPT: while some incoming is not yet inside, the next work is not work inside the files: incoming first
AT A FILE IN carry/: IN PART
WHERE: the order is at Offerings to Living File Registry line 233 (the person's words of 6 October, with an earlier session's reading: "Receiving completes first and incoming is vacant; then resolving"); Living Improving Value line 11 ("Prior incoming remains the gathering priority.").
MISSING: this saying of this session: the person's concern that incoming was left outside while work inside was named next. Searches: `work(ing)? inside the (mates|offerings|carrying)`, `incoming first`, `resolved first`.

### 94
WHO: the person
LINE: 545
SAYING: "where is the whole incoming being detained from flowing"
CONCEPT: the whole incoming is to flow in, and the place where it is detained is to be found
AT A FILE IN carry/: NO
WHERE: searches `detain`, `incoming (is |being )?(flow|held|stopped|kept from)`, `from flowing|flowing in`, `flow(s|ing)? (in|into) the (offerings|mates|carrying)`. Also not in the session's own record or README outside `carry/` (search `detain`: 0).
MISSING: the whole saying.

### 95
WHO: the session
LINE: 547
SAYING: Nothing in the method detained the incoming; the session's own ordering did, at two places: it gathered three sessions from their closing guides and did not read their long files, so whatever concept is in the unread text and not in a guide was at no file; and it named work inside the files as next, parting from the person's direction that the incoming is resolved first. One row was said wrongly: session v385R's sections 1 to 105 were in the carry by session v385A's gathering and unread by this session.
CONCEPT: a session's own ordering detaining the incoming: gathering from guides with the wholes unread, and naming inside work ahead of incoming
AT A FILE IN carry/: NO
WHERE: searches `closing guide|its guide|a guide`, `session.s own ordering|own ordering`, `unread (text|whole|file)`, `detain`. The table at Carryings of Living File Registry (line 263) now says of each source "read whole"; it does not say this finding.
MISSING: the finding about the method: a source gathered from its guide alone leaves each concept of its unread whole at no file; and the session's naming of inside work as next parted from "incoming first".

### 96
WHO: the session
LINE: 560 (and 565, 570, 575)
SAYING: The unread wholes were then read: nineteen readers and then twenty-nine, about 451,000 and then about 769,000 words; 157 and then 126 sections placed; one more detained thing was found on the way, the earlier carrying directories, sessions' reports, session v385A's comparisons and session v385R's sections 1 to 105, read whole by no reading of this session until then.
CONCEPT: each source read whole and placed
AT A FILE IN carry/: WHOLE
WHERE: Carryings of Living File Registry, "Incoming still to gather and aim" (lines 263 to 283), each row saying what was read whole and what was not.
MISSING: nothing of the standing. The counts are in the session's own record, outside `carry/`.

### 97
WHO: the session
LINE: 579
SAYING: The 134 observings from science in those sources were each opened at their publishing by ten checking readers: 26 agreed, 105 were corrected (a number, a name, a year, a finding belonging to another paper, or an explanation the writers only suggest), and 3 opened at no page and are named not opened at Carryings of Natural Biology (starch rings in constant conditions, conjoined twins united at like sites, a soil bacterium using L-glucose).
CONCEPT: the incoming's observings checked at their publishings, with three not opened
AT A FILE IN carry/: IN PART
WHERE: the three are at Carryings of Natural Biology, "Starch rings continuing in constant conditions" (line 361), "Conjoined twins united at like sites" (line 381), "A soil bacterium using L-glucose" (line 526).
MISSING: the finding itself, that 105 of 134 observings carried by earlier reports parted from their publishing at a number, a name, a year, a paper or an explanation. Searches: `agreed with the page|corrected at a number|opened at no page`: the table at Carryings of Living File Registry line 271 says only "three field publishings that opened at no page are named not opened". I did not check the 134 one by one.

### 98
WHO: the session
LINE: 586 (corrected at 644)
SAYING: Session v374's droplets still say their figures as that report has them; the session mended those it saw part from a corrected observing (three, then fifteen more at line 605), and the rest are covered by a line at each section saying the observing carries at any parting.
CONCEPT: where a figure parts between a droplet and its observing, the observing carries
AT A FILE IN carry/: WHOLE
WHERE: the line "at a figure parting between a droplet and its observing, the observing carries" is at 17 places (for example Offerings to Resolving the Hard Problem Registry line 241, Offerings to Natural Societies line 245, Possibling of Hard Problem Registry line 21).
MISSING: nothing of the concept. Which droplets of session v374 still part from their observings is said at no file.

### 99
WHO: the person
LINE: 594
SAYING: "continue and try to keep this high level explaining so i can be sure what is happening to the improving and carrying and do no harm of this"
CONCEPT: the session keeps its explaining high level, so that the person can be sure what is happening to the improving, the carrying and the do no harm
AT A FILE IN carry/: IN PART
WHERE: an earlier session's droplet near it: Offerings to Natural Arriving line 221 (and Offerings to Geodesic Improving Method line 229): "at each breath a working says what entered, the standing of the files it is at, the next three things … the self sees the work at a glance and steers"; Offerings to Geodesic Improving Method, "Droplet · A next work, understood by both" (line 472).
MISSING: this direction: a high level explaining kept, so that the person can be sure of what is happening to the improving, the carrying and the do no harm. Searches: `high.level`, `can be sure`, `at a glance`.

### 100
WHO: the session
LINE: 609
SAYING: The measuring: the files of the carry are about 580,000 words, about 166,000 said at this session, 160,000 at session v385A, and about 250,000 in older sections (Droplets, Insertlets, Earlier source inventory) from sessions up to v381R; the waiting words live in that older part: 192 paragraphs open "A plan, not yet final" and about 340 more say waits, until, next session or must first.
CONCEPT: where the waiting words are, by measure
AT A FILE IN carry/: NO
WHERE: searches `580,000|250,000`, `plan, not yet final`. By my count 76 paragraphs opening "A plan, not yet final" remain, in nine files (the session's later number, line 808).
MISSING: the measuring. It is in the session's own record, outside `carry/`.

### 101
WHO: the session
LINE: 619 (and 631 to 639)
SAYING: Older droplets can be resolved without harm only when a second reader checks every change: in the trial the second reader objected to 26 of the first reader's 63 proposed changes, each of which would have lost or added something (a number, a negation, a paragraph another paragraph points at, a narrowing the original did not say).
CONCEPT: one reading alone is no safe resolving of an older droplet
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Geodesic Improving Method, "One reading alone is no safe resolving of an older droplet · v386EOD" (line 598), with the later whole numbers (800 changes proposed at 1,900 paragraphs, 195 objected).
MISSING: nothing of the concept.

### 102
WHO: the session
LINE: 633
SAYING: One example: a sentence saying "this is a proposed explaining of a constructed entry, not authority for living carrying" was judged a session's record by the first reader, but it is the condition laid on the two paragraphs before it, so it stays.
CONCEPT: a sentence that looks like a session's record can be the condition laid on the paragraphs beside it
AT A FILE IN carry/: NO
WHERE: searches `a condition laid on|lays a condition|condition laid`. The five kinds of objection at Offerings to Geodesic Improving Method line 600 do not name this one.
MISSING: this kind of objection: a sentence taken for a session's record that is a condition on its neighbours.

### 103
WHO: the session
LINE: 638
SAYING: Thirteen re-sayings in the trial went in as the second reader corrected them; the session read each beside its original, and no third reader checked them.
CONCEPT: a re-saying corrected by the second reading is read by no third
AT A FILE IN carry/: NO
WHERE: searches `third reader`, `no third`. Offerings to Geodesic Improving Method line 600 says "A change is applied at the second reading's confirming or correcting alone", without saying that a corrected re-saying had no further reading.
MISSING: that the paragraphs applied as the second reading corrected them were read by no further reader.

### 104
WHO: the person
LINE: 654
SAYING: "is there a general living improving value file or location or is now all incoming value in droplets inside mate files."
CONCEPT: the person asks whether there is one general place for incoming value, or whether all of it is now droplets inside the files of each living file
AT A FILE IN carry/: WHOLE
WHERE: the arrangement is at Offerings to Living File Registry, shared method (line 12: "Living Improving Value | Whole incoming value at no one subject's mate, visible there as value.") and line 365.
MISSING: nothing of the arrangement.

### 105
WHO: the person
LINE: 654
SAYING: "i still can not see the whole safety of the whole of all the value we can find from the prior sessions"
CONCEPT: the person cannot see that the whole of the value found from the prior sessions is safe
AT A FILE IN carry/: NO
WHERE: searches `whole safety|safety of the whole|can ?not see the whole|see the whole`, `safe(ty)? of (the|all)|is (not )?(yet )?safe|value (is )?safe`, `one page|whole view|at a glance|in one place`. Nearest: an earlier saying of the person (5 October) asking for "a whole view of all that is in the corus repository", at Offerings to Living File Registry line 227. Not in the session's own record or README either.
MISSING: the whole saying.

### 106
WHO: the session
LINE: 666
SAYING: Living Improving Value is about 8,200 words, last written by session v385A, and nothing of this session is in it.
CONCEPT: what the one general file holds
AT A FILE IN carry/: NO
WHERE: Living Improving Value read at its front and headings.
MISSING: the saying is at no file, and it parts from the file and from the session's own report at line 433: Living Improving Value's front says "improved at v386EOD", its section "Continuing sequential-colliding incoming" was re-said by this session, its table "Further incoming to gather" (lines 76 to 83) is in this session's wording, and its last section is "One reason at each doing · from session v386CRYP · v386EOD" (line 315). That table's row for session v382A still says "Its report of seventy-three passes is not read whole." (line 78), which parts from Carryings of Living File Registry line 273 ("each read whole").

### 107
WHO: the session
LINE: 671 (and 677)
SAYING: What protects the value: every source is still whole where it was, and every change to the carry is a commit that can be undone. "Read whole and placed" is one reader's finding; only the observings and the one trial file had a second reader, so single readings of the other sources may have missed or misjudged things. The sources staying whole is the protection, not the reading.
CONCEPT: the gathering from each source is one reading's finding, and the safety is the sources staying whole
AT A FILE IN carry/: NO
WHERE: searches `not the reading|a reading that missed|one reader.s finding|single readings?|one reading alone`, `sources? (stay|staying|are|is|remain)s? whole|protection|what protects`. The droplet at Offerings to Geodesic Improving Method line 598 is of the resolving of older droplets only. The table at Carryings of Living File Registry says of each source "Nothing found at no file in `carry/`" and does not say that this is one reading's finding.
MISSING: the whole finding.

### 108
WHO: the session
LINE: 675
SAYING: None of the gathering is on main: main is at the close of session v380R (4 October); the carry as it is sits on three stacked draft pull requests, 122, 127 and 132, not at corus.me and merged nowhere; merging them is the person's action.
CONCEPT: the gathering is not on main, and the merging is the person's
AT A FILE IN carry/: NO
WHERE: searches `not (yet )?on main|none .{0,30}on main`, `stacked`, `draft pull request`, `merg(e|ing) (them|the three)`.
MISSING: the whole saying.

### 109
WHO: the session
LINE: 678 (and 681, 704, 711, 811)
SAYING: No one page shows the whole (each source, where it is whole, where its value went, what is unread or unresolved). The session said it would write that page as the front of Living Improving Value, then did not, because the method puts the standing at the registry's table; it asked the person twice whether they want one short page and where it should live. The question was not answered in the transcript.
CONCEPT: one page showing the whole, proposed, not written, and left as an open question
AT A FILE IN carry/: NO
WHERE: searches `one short page|short page|where should it live|where that page`, `one page|single page`, in `carry/` and in `incoming/v386EOD/`: nothing.
MISSING: the open question, and that the page was proposed and not written.

### 110
WHO: the person
LINE: 687
SAYING: "continue and follow our method or before changing our method ask about the changing here"
CONCEPT: the session follows the method, and asks the person here before any changing of the method
AT A FILE IN carry/: NO
WHERE: searches `before changing (our|the) method`, `ask(s|ed|ing)? (about|before) (the )?chang`, `chang(e|es|ing|ed) (to |of |in )?(our|the|this) method`, `depart(s|ed|ing)? from the method`, `follow(s|ing)? (our|the) method`. Not in the session's own record or README either. The session says at line 762 that this direction is "not yet" a droplet.
MISSING: the whole saying.

### 111
WHO: the session
LINE: 696
SAYING: Sessions v386F and v386CRYP were each read whole on its own branch and each thing at neither a living file nor the carry was laid at the file of its subject (127 and 32 things; 33 more of v386F said by two readers, each laid once).
CONCEPT: two late sessions received
AT A FILE IN carry/: WHOLE
WHERE: sections headed "· from session v386F · v386EOD" and "· from session v386CRYP · v386EOD" (69 headings carry a source label of this kind), for example Offerings to Living File Registry line 415 and Living Improving Value line 315; Carryings of Living File Registry lines 280 and 281.
MISSING: nothing found missing. I did not count the things placed.

### 112
WHO: the session
LINE: 700 (and 767, 810)
SAYING: A sentence a session offers for a living file is a droplet, not an insertlet: an insertlet is in the file's own naming and read by a second reader; the offered sentences carry released words and have had no second reader, so each is laid as a droplet in its dropper's words beside the living sentence it is aimed at. About 120 are so laid, and none has had the second reading.
CONCEPT: an offered sentence is a droplet until a second reading, in the file's own naming, makes it an insertlet
AT A FILE IN carry/: IN PART
WHERE: "A sentence offered for a living file is a droplet in its dropper's words, beside the living sentence it is aimed at." (Offerings to Natural Intelligence lines 613 and 639; Offerings to Resolving Hard Problems line 205; five more files); Offerings to Geodesic Improving Method, "Droplet · A second reader's one question at each insertlet" (line 554).
MISSING: the reason as the session gave it (released words in them, no second reader here), and that none of the about 120 has had the second reading.

### 113
WHO: the session
LINE: 701
SAYING: Two things in the trial departed from the method and were mended: the file as it was before the trial is whole at `archive/carrying_v386EOD/` with the relation at its head; and the list of releases put inside the file was moved to the record, each with its evidence, because the carrying carries no history.
CONCEPT: a file's prior is whole at the archive, and a list of releases is no part of the carrying
AT A FILE IN carry/: IN PART
WHERE: "The carrying carries no history" is quoted at Offerings to Geodesic Improving Method, insertlet "At 1.6 · The carry current at each closing, and no history carried" (line 41). `archive/carrying_v386EOD/` exists with 33 files.
MISSING: that each file of offerings as it was before this session's resolving is whole at `archive/carrying_v386EOD/`. Search `archive/carrying_v386EOD` in `carry/`: 0 files. The lines "Released readings and records naming this file, at the archive" in the files of carryings list the archive folders up to `archive/carrying_v381R/` and not this one.

### 114
WHO: the person
LINE: 715
SAYING: "are we aiming at all the incoming value in droplets inside mate files and nothing stil haning outside waiting for what or any other value not yet inside"
CONCEPT: the aim is all incoming value as droplets inside the files, with nothing hanging outside waiting and no value not yet inside
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Living File Registry line 233 (the person's words of 6 October: "after all the droplets are no longer outside the offering files and all the incoming is inside the offering files … and the incoming is vacant"); Possibling of Living File Registry line 11 ("The intended final gathering condition remains all continuing value in the living incoming, local offerings, possibling projects, gatherings and observings, with completed work filed away."); what is outside is in the third column of the table at Carryings of Living File Registry line 263.
MISSING: nothing of the aim. It is there from earlier sessions' sections, not as a saying of this session.

### 115
WHO: the session
LINE: 720
SAYING: Yes, that is the aim, and it is not fully so; nothing is waiting on a decision or on anyone; what is outside is simply not yet read. Of 83 branches, 62 have nothing this branch lacks; still outside were session v385R's own additions and changed living files, 73 comments on seven pull requests, session v382F's mended sentences, earlier versions of files read in later versions, and two older pages of the person; `archive/`, about 1.3 million words, is not read and by the method relied on by nothing.
CONCEPT: what was still outside the carry, by comparing every branch
AT A FILE IN carry/: WHOLE
WHERE: Carryings of Living File Registry, table row "Each other branch of the repository, and the comments on the pull requests" (line 282), which also says `archive/` "is read by no reading of this session; by the Geodesic Improving Method it is relied on by nothing".
MISSING: nothing

### 116
WHO: the session
LINE: 746 (and 804)
SAYING: The rows listed as outside were read and 65 things placed; session v386F's close corrects four of its own droplets of the day, and each new droplet names the earlier one it replaces; the person's two older pages were read later and gave two droplets.
CONCEPT: the material outside the branch received
AT A FILE IN carry/: WHOLE
WHERE: sections headed "· from session v385R's branch · v386EOD", "· from the pull requests' comments · v386EOD", "· from session v386F's close · v386EOD" (for example Offerings to Co-Chaining Logic Registry lines 728, 762, 774); Offerings to Natural Illustrating, "An earlier drawing of the natural torus, a spiral cone folded about itself · v386EOD" (line 135); Offerings to Natural Arriving, "A reader asked to say publicly each finding, wrong or not wrong · v386EOD" (line 636).
MISSING: nothing found missing. I did not count the 65.

### 117
WHO: the session
LINE: 762
SAYING: This conversation is not inside: the person's directions from the morning are at Offerings to Living File Registry; the later ones (follow the method, ask before changing it) are not yet droplets; the method gathers a session's transcript at its close.
CONCEPT: the person's later directions of this session are at no file
AT A FILE IN carry/: NO
WHERE: Carryings of Living File Registry, row "Session v386EOD" (line 283), says of what is not at the files: "None; its report is an artifact for managing". The directions the session names, and the ones after them, are at no file: see blocks 93, 94, 99, 105, 110, 118, 122, 127, 128.
MISSING: that the person's later directions are not placed, and the directions themselves.

### 118
WHO: the person
LINE: 776
SAYING: "All the other sessions are ended and you are the only one maintaining and do no harm improving. Continue"
CONCEPT: all other sessions are ended, and this session alone maintains and does the do no harm improving
AT A FILE IN carry/: NO
WHERE: searches `only one maintain|one maintainer|sole maintain|maintaining`, `other sessions (are|have) ended|sessions (are )?ended|all (the )?other sessions`, `(only|one|sole) (session|working|self) (is )?(maintain|receiv|gather)`. Not in the session's own record or README either. Living Improving Value line 11 still has "Session v385R continues learning."
MISSING: the whole saying.

### 119
WHO: the session
LINE: 790
SAYING: The 1,900 older paragraphs across the 33 files of offerings: 595 said again in the present naming with no waiting words, 110 released each with its evidence in the record, 8 exact repeats removed, 1,187 left exactly as they were.
CONCEPT: what happened to the older droplets
AT A FILE IN carry/: NO
WHERE: Offerings to Geodesic Improving Method line 600 has only "800 changes at 1,900 paragraphs … objected at 195". Search `1,187|595 said|110 released`: nothing in `carry/`.
MISSING: the outcome, and the list of the 110 released with their evidence. It is in the session's own record and README, outside `carry/`. I did not check any of the 595 re-sayings or the 110 releases against their priors.

### 120
WHO: the session
LINE: 798
SAYING: How do no harm was held: two readers for every change; the second reader objected to roughly a quarter, a corrected paragraph was used where given and the original stayed untouched where not (97 paragraphs); a paragraph was released only where the living file now says it, a later section says it whole, or it was a session's own bookkeeping with no concept in it; a search confirmed every quotation in the re-said paragraphs is an exact string of a living file; each file as it was is whole at `archive/carrying_v386EOD/`.
CONCEPT: the five ways no harm was held at the resolving of older droplets
AT A FILE IN carry/: IN PART
WHERE: the first two are at Offerings to Geodesic Improving Method line 600 ("A change is applied at the second reading's confirming or correcting alone, and a paragraph is left as it was at an objection with no safe correcting.").
MISSING: the rule of release (only where the living file says it now, a later section says it whole, or it is a session's own bookkeeping with no concept); the check of quotations as exact strings; the archive of priors. Searches: `present home|released only where|is released only`, `quotation.{0,40}exact string|exact string of`, `archive/carrying_v386EOD`, `bookkeeping`.

### 121
WHO: the session
LINE: 806
SAYING: Still in older words: 76 paragraphs still open "plan, not yet final"; each file's older Insertlets section, and the older sections of the files of possibling and carryings, are not yet read this way.
CONCEPT: which older sections have had no second reading
AT A FILE IN carry/: NO
WHERE: counted: 76 paragraphs with "A plan, not yet final" in nine files (19 at Offerings to Resolving the Hard Problem Registry, 16 at Offerings to Natural Intelligence, 16 at Offerings to Natural Naming, 15 at Offerings to Natural Networking, and fewer at five more). No file says which sections are unread.
MISSING: that the older Insertlets sections and the older sections of possibling and carryings have not been read by two readers.

### 122
WHO: the person
LINE: 815
SAYING: "i  continue asking the same question why are you managing inside the mate files when we are gathering into the mate files"
CONCEPT: the files gathered into hold no managing; and the person has asked this more than once
AT A FILE IN carry/: IN PART
WHERE: one side is at Offerings to Living File Registry line 363 ("A session's report is for managing alone, and no carrying value is in it."); the living file's sentence "The carrying carries no history" is quoted at Offerings to Geodesic Improving Method line 41, and "A carry kept as a record of the journey is a carry named as a store" at its "Concern · Emptying at no pass beside a record named a store" (line 556).
MISSING: the person's saying: no managing inside the files being gathered into, and that the person had to ask it again. Searches: `managing` (21 hits, none of this), `bookkeeping|session.s (own )?(record|telling|journey)`, `no history|record of the journey`. Not in the session's own record or README either.

### 123
WHO: the session
LINE: 820
SAYING: The session had been writing its bookkeeping (what was read, counts, tables, lists of releases) into Carryings of Living File Registry, for two reasons that do not hold against the direction that managing is only ever an artifact: an earlier session had used that file as a ledger and the session kept adding to it; and it read the method's rule that a release is told with its evidence as permission to tell it inside the carry.
CONCEPT: two ways a session comes to manage inside the carry: following an earlier ledger, and reading "a release is told with its evidence" as leave to tell it there
AT A FILE IN carry/: NO
WHERE: searches `ledger`, `told with its evidence|release is told`, `bookkeeping`. The related concerns at Offerings to Geodesic Improving Method ("Concern · Carryings naming a file's resting and no leaving", "Concern · One word, release, at a value entered and a concern out") do not say this.
MISSING: the finding.

### 124
WHO: the session
LINE: 828
SAYING: All seventeen record sections the session wrote there, about 13,000 words, were moved whole to `incoming/v386EOD/Session_Record_v386EOD.md`; the finding that one reading alone is not safe was kept as a droplet in Offerings to Geodesic Improving Method.
CONCEPT: the session's record moved out, one finding kept
AT A FILE IN carry/: WHOLE
WHERE: Offerings to Geodesic Improving Method, "One reading alone is no safe resolving of an older droplet · v386EOD" (line 598). The session's record is at `incoming/v386EOD/`, outside `carry/`, 288,935 bytes.
MISSING: nothing of the kept finding. Whether other findings of value went out with the seventeen sections I did not check; I did not read the moved record whole.

### 125
WHO: the session
LINE: 831 (and 869)
SAYING: Managing of the same kind is still inside the carry: about 12,700 words of earlier sessions' ledger in Carryings of Living File Registry, mostly session v385A's (placement tables, branch roles, session reviews), which other files link to about 70 times and the repository's README links into; the incoming table, whose rows are now mostly this session's wording; and 72 section headings naming the session a group of droplets came from. The session asked whether to move or strip these, and the question was not answered.
CONCEPT: managing left inside the carry, with an open question
AT A FILE IN carry/: NO
WHERE: observed still there: Carryings of Living File Registry has "Session v385A transcript review and resuming condition" (line 11), "Published branches and their actual roles · v385A" (line 59), "Incoming still to gather and aim" (line 263, 15 rows, most linking to the session's own record), and more; Living Improving Value's table "Further incoming to gather" (lines 76 to 83) is of the same kind; 69 headings in `carry/` carry a source label such as "· from session v386F · v386EOD". No file says that this is managing left inside or that the question is open.
MISSING: the finding and the open question.

### 126
WHO: the session
LINE: 836 (corrected at 865)
SAYING: The session first listed its about 750 "v386EOD" tags as a managing mark, then corrected this: the Living File Registry names the form as "its droplets tagged by session", so the tags are the form.
CONCEPT: a droplet's session tag is the form, not managing
AT A FILE IN carry/: IN PART
WHERE: an earlier saying of the tag is at Offerings to Natural Naming line 255 (the person's words: "the tag is unvetted incoming"; "when the droplet rises past the resolving level in the file it does not have this tag any further").
MISSING: this correction. The sentence "its droplets tagged by session" is in the living file (Living File Registry v381R, line 132), not quoted in `carry/`. Search `tagged by session|droplets tagged`: 0 in `carry/`.

### 127
WHO: the person
LINE: 841
SAYING: "now this is so less clear i do not know if you understand our method"
CONCEPT: the session's reply was less clear, and the person does not know that the session understands the method
AT A FILE IN carry/: NO
WHERE: searches `less clear`, `understand (our|the) method`. Not in the session's own record or README either.
MISSING: the whole saying.

### 128
WHO: the person
LINE: 841
SAYING: "and you can no longer refer to a mate as this is not clear you understand this term so you must use only natural naming for this. redo this"
CONCEPT: the session no longer says "mate"; it uses only natural naming for these files; and it redoes the work
AT A FILE IN carry/: IN PART
WHERE: the general concept of exact names is at Offerings to Living File Registry, "Exact naming and explaining at each use · v385A" (line 49), and Offerings to Natural Naming line 15 ("No abbreviation or newly invented short name replaces that explaining."). The names offerings, possibling and carryings are used in this session's sections, and "A name for the folder of the offerings, possibling and carryings · v386EOD" (Offerings to Living File Registry line 385) says the folder is `carry/`.
MISSING: this direction: that "mate" is no longer said by the session and only natural naming is used for these files. No file says it. The word "mate" or "mates" is still at 277 places in `carry/`, mostly in session v385A's text (55 in Offerings to Living File Registry, 26 in its Carryings, 24 in its Possibling, 23 in Living Improving Value, 21 in Offerings to Geodesic Improving Method). Searches: `*mate*`, `word mate`, `"mate"`, `named mate|naming mate`.

### 129
WHO: the session
LINE: 848
SAYING: What the method says: each living file has its offerings (droplets, concerns, insertlets), its possibling (possible work) and its carryings (the observings and sources its sentences rest on), together the carrying; Geodesic Improving Method 1.3: the carrying is "the incoming value, the concern and the opportunity at each file of the set" and "It carries nothing else."; 1.6: "The carrying carries no history. A carry kept as a record of the journey is a carry named as a store."; 1.4: a session's own report "arrives whole at incoming/".
CONCEPT: the method's own sentences on what the carrying holds
AT A FILE IN carry/: IN PART
WHERE: "The carrying carries no history" at Offerings to Geodesic Improving Method line 41; "A carry kept as a record of the journey is a carry named as a store." at line 556; "a visiting report arrives whole at `incoming/`" at line 113.
MISSING: "It carries nothing else." and "the incoming value, the concern and the opportunity at each file of the set" are quoted at no file in `carry/` (search `carries nothing else|the incoming value, the concern and the opportunity`: only the one hit for "no history"). They are in the living file.

### 130
WHO: the session
LINE: 857
SAYING: The larger managing the session had missed: 342 of the sections it added to the offerings, possibling and carryings opened with a paragraph telling which session or report the group came from and how it was read, about 16,000 words of the session's journey among the droplets. These were taken out and placed in the session's record, each beside the section it came from. A sentence in an opening that lays a condition on the droplets beneath it stays (for example, where a figure differs between a droplet and its observing, the observing carries).
CONCEPT: a section's opening telling its source and its reading is the session's journey and not the carrying; a condition on the droplets beneath stays with them
AT A FILE IN carry/: IN PART
WHERE: the kept condition is at 17 places (block 98). The moved openings are in the session's own record, "Each section this session added in `carry/`, and the source it is from · v386EOD" (its line 498), outside `carry/`.
MISSING: the finding as a concept of the method. No file says that a telling of source and reading at a section's head is a session's journey. Observed: 69 headings still name a source in the heading itself ("· from session v386F · v386EOD" and the like), which the session named as managing at line 835 and did not change. I did not check that no condition was lost among the 342 openings taken out.

### 131
WHO: the session
LINE: 862
SAYING: Everything the session wrote now says offerings, possibling, carryings or the carrying; the earlier word is gone from its text in the carrying, the session's record and report, and the pull request description.
CONCEPT: the word "mate" is gone from this session's text
AT A FILE IN carry/: IN PART
WHERE: checked by `git diff a81ea75 HEAD -- carry` (a81ea75 is the commit before this session's first), looking at added lines with the word "mate" or "mates".
MISSING: four places in lines this session wrote or changed still have the word: Living Improving Value line 222 ("that correcting is with the concept at the same mate"), Living Improving Value line 242 ("none is in two lines at a carrying mate"), Offerings to Living File Registry line 12 ("at no one subject's mate", the session's re-saying inside session v385A's table) and line 25 (the session's re-saying inside session v385A's paragraph, "Each is at its mate"). A fifth added line has "mate" in its plain meaning (a nematode bearing young "with no mate") and is not of this. I did not check the session's record, report or the pull request description.

## READING

Read whole: `TASK_T.md`, `COMMON.md`, and `transcript.txt`, all 871 lines. I read the transcript in three parts from the last to the first (lines 600 to 871, then 300 to 599, then 1 to 299), and then went through it forward from line 1 while listing the sayings, taking each saying as corrected by what came after it (for example blocks 50, 55, 64, 82, 126).

Read whole or in long passages in `carry/`: Offerings to Living File Registry lines 1 to 90, 205 to 245 and 319 to 418; Offerings to Geodesic Improving Method lines 403 to 470, 494 to 540, 552 to 566 and 598 to 600; Living Improving Value lines 1 to 97, and its headings; Offerings to Natural Intelligence lines 105 and 353 to 399; Offerings to Natural Resolver lines 159 to 161 and 211 to 233; Offerings to Co-Chaining Logic Registry lines 414 to 446; Possibling of Living File Registry lines 1 to 30 and 295 to 300; Carryings of Living File Registry lines 1 to 10 and 263 to 283; Carryings of Geodesic Improving Method lines 41 to 60; Offerings to Natural Arriving lines 221, 590 to 600, 614 and 636 to 640. I listed the headings of eight more files.

Searched: for each saying, two or more wordings by regular expression across all 109 files of `carry/`, then read the place of each hit that could be the concept. The searches are named in each block. `carry/Session_Record.md` was included in the searches and no saying of this session was found there.

Also looked at, outside `carry/`, only to say where a thing is: `incoming/v386EOD/README.md` (its first 30 lines), the headings of `incoming/v386EOD/Session_Record_v386EOD.md` and searches in it, the names of the files in `archive/carrying_v386EOD/`, and `git log` and `git diff` (reading only). I did not read the other reader's report or look for it.

Not listed as sayings: the lines "Ran N commands …", the sources list at lines 63 to 69, and one reply about the branch's push state (line 265), which is tooling with no concept in it.

What I could not check or did not check:
- I verified the session's reports of placing by finding the named section or droplet at the named file. I did not check that each placed droplet says what its source says. That is another reading.
- I did not count the session's numbers (things placed, sections, observings corrected) except these: 76 paragraphs opening "A plan, not yet final"; 14 paragraphs with "Seen:"; 277 uses of "mate(s)"; 69 headings with a source label; 405 headings and 741 paragraphs tagged v386EOD; 33 files at `archive/carrying_v386EOD/`.
- I did not lay any re-said paragraph beside its prior: not the 595 re-said older droplets, not the 110 released, not Living Improving Value's section that went from about 7,900 to about 3,400 words, not the 342 openings taken out.
- I did not read the session's own record whole, so I cannot say whether a finding of value sits only there. Where a block says "in the session's own record", I saw it by a search.
- A "NO" means that my searches and the places I read did not find the concept. `carry/` is about 4.6 million bytes and I did not read it whole.
- Blocks 77, 84, 87 and 90 are the person's bare words to go on. They are counted as NO because the form asks for one of three answers; nothing of them is missing from the files.

The person's messages from line 387 to the end, which I was asked to take special care with, are blocks 81, 84, 87, 90, 93, 94, 99, 104, 105, 110, 114, 118, 122, 127 and 128. Leaving out the three bare words to go on (84, 87, 90): two are WHOLE (104, the arrangement of the general file; 114, the aim of all incoming inside), and both are there from earlier sessions' sections, not as sayings of this session. Five are IN PART (81, 93, 99, 122, 128). Five are NO (94, 105, 110, 118, 127). None of these twelve is placed as a droplet of this session at any file in `carry/`, and none is in the session's own record or README outside `carry/` either (searched there for `detain`, `high level`, `safety`, `before changing`, `ask before`, `other sessions ended`, `follow the method`).

Counts: 131 sayings. WHOLE 52. IN PART 48. NO 31.
By who: the person 57 sayings (WHOLE 23, IN PART 24, NO 10, of which 4 are bare words to go on); the session 74 sayings (WHOLE 29, IN PART 24, NO 21).
