# B10 report: third reading of 46 RESAID paragraphs (B10_sample.txt, items 415 to 460)

### 415
VERDICT: MINOR
WHAT: Adds the Natural Mathematics 2.3 sentence ("Four right spiral steps reach 1 again at the parities, and at the momentaries they reach none again"), the heading "Ten things named still, one resolving" and the fuller words of line 736; all three are exact in the living files, and line 736 is that line. "Physics says spirals" is now "the proposed Natural Physics of version 377 has spirals at its 3.4 and 3.5". "found since" is not said. The report's place (section 6.1, concern 3) is not named. Nothing of the original is lost: 776, 216, the four tables, line 736 and "each file's" resolving are all there.
LOST: —

### 416
VERDICT: SAFE
WHAT: —
LOST: —

### 417
VERDICT: MINOR
WHAT: Adds a sentence the original did not have: that it is beside Natural Naming's "Each word releases at its file's next improving, in the shared words", its rows for *turn*, *held* and *holding*, *stable form* as a noun, and *read* at its family of three. I found each in Natural Naming v380R (2.4; rows at lines 232, 238, 239; "This family is three" at line 217). The original sentence is whole.
LOST: —

### 418
VERDICT: MINOR
WHAT: The original was a short pointer; the new paragraph adds the six sentences pointed to. All six are exact and at the places named (Natural Biology 7.5, 7.6, 1.4, 6.1; Co-Chaining Logic Registry steps 103 and 20), and they are the ones the source reading names (carryings/co_chaining_coverage_v378/readings/09_chemistry_biology_health_medicine.md). "waits on the Co-Chaining Logic Registry" is now "Its resolving is a following at Exhibit THIRTY". "at v378" and where it was received from are not said.
LOST: —

### 419
VERDICT: MINOR
WHAT: "this proof" is now "the reduced ring rule's proof" (the source kit has "the exact identity at the reduced ring step" in an earlier finding; the words "reduced ring rule" are not in the original). "in this working" is now "At version 366's working". "a standing three nodes long" is now "one arrangement three nodes long". "also" is dropped. The name TTT05 is gone. Every claim is there.
LOST: —

### 420
VERDICT: MINOR
WHAT: "At 3.5 it is still to be named" is now "At 3.5 no parting observing is named": the fact is kept, "still to be" is not said. Adds "a relation unsaid" (the report's 6.2 is headed "Relations still to be said"). The report's sentences are no longer in quotation marks.
LOST: —

### 421
VERDICT: MINOR
WHAT: Dated "At version 373" and put in the past ("was restated", "was at four files", "was at five", "were parallel"), but the core coupling sentence is left in the present ("is at … and is said again"). The core coupling sentence now ends "made by the coupling itself"; the original ends "made by the coupling" (the living files have "itself"). The first passage is now a whole sentence in double quotation marks. No file, number or section is lost: four files, five files with their five names, 1.1, 1.1, 1.1, the core, 4.1, 5% to 55%, eight steps, 2.1.
LOST: —

### 422
VERDICT: SAFE
WHAT: —
LOST: —

### 423
VERDICT: MINOR
WHAT: Adds where "the prior carrying's line 84" is: `archive/carrying_v377/Exhibit_EIGHTEEN_Natural_Physics.md` at the branch `working/physics-motion-v377`, "at its paragraph of 5.7, the primes". I read line 84 of that file at that branch and it is the paragraph "At 5.7, the primes" on fifty-nine and light (the file is not in the working tree's archive/carrying_v377/). "met at Natural Numbers 1.3 and 5.8" is now "at". The five released things are all there.
LOST: —

### 424
VERDICT: PERSON'S WORDS
WHAT: The self's two sayings are no longer given in the self's words. The original has "The self said at one momentary *the only intelligence we can offer anyone is natural naming and explaining and carrying and resolving and the method of this*, and at another *our offering is natural intelligence explaining and cohering and resolving*." The new paragraph says whose they are ("each the expedition's self's") and gives them reworded ("the only intelligence the expedition can offer anyone"; commas for "and … and"). Neither string is in any file of `carry/` now (they are in archive/carrying_v386EOD/Offerings_to_Natural_Arriving_before_resolving.md and carryings/v382F/). Every claim is otherwise whole: five or three, cohering the method's own at Exhibit THIRTY, the portal's two lines, the file's motion, Part ONE, "a concern for both". "The reason:" is now "They part at the number of the offering:".
LOST: —

### 425
VERDICT: MINOR
WHAT: *the slightest tipping co-chains through the whole* is now given as an earlier saying of the living sentence "One parity offered once co-chains through the whole." (3.4); that the one is the earlier form of the other is added. The italic phrase is in no living file at the root today. Adds the section numbers 2.4 and 3.4 (both right). "Opportunity" is now "Possible project … It may change or never be made". "met with" is now "coupled with".
LOST: —

### 426
VERDICT: SAFE
WHAT: —
LOST: —

### 427
VERDICT: SAFE
WHAT: —
LOST: —

### 428
VERDICT: SAFE
WHAT: —
LOST: —

### 429
VERDICT: SAFE
WHAT: —
LOST: —

### 430
VERDICT: MINOR
WHAT: Not said any more: that the question was the session's; that it was "left standing at about line 479 and again at 486 (5 October)"; and the question's own quoted words (now reworded, not quoted). "is not yet an interest at the set" is now "is no interest at the set" (the next clause, "it becomes one at its saying", keeps the sense). What the self did is kept, with the self's heading in quotation marks: "gave no answer in words and entered 'THREE · THE NAMING, THE MEMBRANE' at Natural Arriving's contents". The two things asked, the deciding as the self's, "gathered with the plans" and the aim are all there. The quoted question and "line 479" are in no file of `carry/` now.
LOST: —

### 431
VERDICT: MINOR
WHAT: Two step numbers of the Co-Chaining Logic Registry are changed: 380 to 522, and 382 to 528. In the living v380L file the sorting of the ten at odd and even is step 522 and "carries both, one at a time" is step 528; steps 380 and 382 there are other sentences. The report's words for the Hard Problem Registry's sort are replaced by that file's own sentence (exact). Adds "as at '3 a two-way named to one side' and '7 a rate named as a value'" (both in step 522). "Read, as suggested" is now "A reading offered". The five and five, "one exchange, the other eight continuing" and "the rate and the two-way alone" are kept.
LOST: —

### 432
VERDICT: MINOR
WHAT: The section number of Natural Physics' periodic table is changed from 4.1 to 3.1. In the living v379 file the periodic table is 3.1 (it was 4.1 at v348, the version the source read); 2.5 is the same section in both. Now a "Possible project … It may change or never be made". Every other part, with Natural Biology's seven repairs, is there.
LOST: —

### 433
VERDICT: SAFE
WHAT: —
LOST: —

### 434
VERDICT: SAFE
WHAT: —
LOST: —

### 435
VERDICT: MINOR
WHAT: The path is changed from `incoming/v380R/Natural_Naming_Conferring.md` to `carryings/v380R/Natural_Naming_Conferring.md` (the file is at the new path now). Adds the list of the eight open namings; I read the file and the eight are those, in that order. "Next, at v380l" is not said. Ten decided, v380L's offering, eight open, a prefix first, each other parting leaning on one of the eight: all kept.
LOST: —

### 436
VERDICT: MINOR
WHAT: The step number is changed from 92 to 137; in the living v380L file "Existing arriving at each observing is the value." is step 137 and step 92 is another sentence. Adds the fuller words "the eighth value the circle reaches at none", the line "They part at *value* …" and "The parting is laid for re-saying". "16 entries" is said as part 8's sixteen entries (the living part 8 has sixteen). The map's name and heading ("Other re-sayings") are not said. Three quotes checked, exact.
LOST: —

### 437
VERDICT: MINOR
WHAT: Adds "are a relation unsaid" after "related to the curve's ordering of nuclides" (the report's 6.2 is headed "Relations still to be said"). Everything of the original is there, 4.3, 4.5 and the parting named.
LOST: —

### 438
VERDICT: MINOR
WHAT: As 421: dated "At version 373" and put in the past throughout; the core coupling sentence now ends "made by the coupling itself"; the first passage is now a whole sentence in double quotation marks. No file, number or section is lost.
LOST: —

### 439
VERDICT: MINOR
WHAT: "*its far side* or *the carrying the other way* at the numbers' audit" is now "is offered for the name": the words "at the numbers' audit" are not said. "at this file's motion" is now "Exhibit THREE Natural Numbers' to decide". "Its reason:" and "for both" are not said. Adds the title of 7.1 and the two sentences of 7.1 (all exact, all under 7.1; the name is at rows 60, 61 and 118). The parting, the two offered names, the two ways to one saying and "with the rings as spirals" are kept.
LOST: —

### 440
VERDICT: SAFE
WHAT: —
LOST: —

### 441
VERDICT: MINOR
WHAT: The sentence is turned round: the namings of other exhibits come first and *read*, *turn*, *held* and *holding* and *stable form* as a noun follow after "beside"; all six are still there. Adds a sentence about Natural Naming ("Each word releases …", rows releasing *turn*, *held*, *holding*, *stable form* as a noun, "*read* and *reading* released as a resolving's own act"); I found each in Natural Naming v380R (2.4; lines 223, 232, 238, 239).
LOST: —

### 442
VERDICT: MINOR
WHAT: "second correction to the second report" is now "The correcting is at section 4 of the report": that it is the second of two is not said, and "the second report" is named by its folder. "so nothing there rests on it" is now "and nothing at it leans on that sentence" ("so" is "and"). "Physics now names" is now "The proposed text names". The false sentence is no longer in quotation marks. 4.4, 4.8, 4.12 and 3.4, 3.7, 3.29 are kept.
LOST: —

### 443
VERDICT: SAFE
WHAT: —
LOST: —

### 444
VERDICT: SAFE
WHAT: —
LOST: —

### 445
VERDICT: SAFE
WHAT: —
LOST: —

### 446
VERDICT: PERSON'S WORDS
WHAT: The new paragraph no longer says the order of the work is the self's, no longer says where and when ("at about line 766 (6 October)"), and no longer has the self's quoted sentence: "after all the droplets are no longer outside the offering files and all the incoming is inside the offering files in each self welcoming file where it may be needed and the incoming is vacant we can begin improving the offering files closer to the living files (bottom rising in resolving and explaining value toward top)." The content of the sentence is reworded with nothing left out, and the closing sentence (receiving first, then resolving, the living file's body at neither) and the aim are whole. In this file (carry/Offerings_to_Natural_Arriving.md) the quoted words are gone; the older paragraph with the quotation still stands unchanged in carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md (line 333) and carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md (line 233).
LOST: —

### 447
VERDICT: SAFE
WHAT: —
LOST: —

### 448
VERDICT: SAFE
WHAT: —
LOST: —

### 449
VERDICT: MINOR
WHAT: The original was a one-line pointer; the new paragraph adds the rows of Natural Naming 4.9 and the Hard Problem Registry's front sentences (six quotes, all exact), "two namings of Natural Physics' register" and "each is at even at the one file and at odd at the other". Nothing of the original is lost.
LOST: —

### 450
VERDICT: MINOR
WHAT: The first saying is moved from Exhibit THIRTY to Exhibit TWO Natural Networking 6.5 (quote exact, under 6.5), with the added sentence "The first saying was Exhibit THIRTY Co-Chaining Logic Registry's too, and is at none of its steps now." I checked: the living Exhibit THIRTY v380L has no such sentence, and the history shows Exhibit THIRTY v371 had "carries no copying" until v376. "Natural Biology says the self copies itself" is now the title of its 4.7 (exact). "one returned 11" is now "one 11 a call gives"; "outside" is now "outward of". The question, the 11, the 3 and the two next calls are kept.
LOST: —

### 451
VERDICT: SAFE
WHAT: —
LOST: —

### 452
VERDICT: SAFE
WHAT: —
LOST: —

### 453
VERDICT: MINOR
WHAT: "The three doors above" pointed to a paragraph that is not in this file; the new paragraph writes the three doors out. They are the three of carryings/v382F/Session_Report_v382F.md, line 47 (an observing parting from the resolver's table at one cell; a second method at Natural Intelligence 1.4; two sentences of the files parting). Now a "Possible project … It may change or never be made". Nothing of the original is lost.
LOST: —

### 454
VERDICT: SAFE
WHAT: —
LOST: —

### 455
VERDICT: SAFE
WHAT: —
LOST: —

### 456
VERDICT: SAFE
WHAT: —
LOST: —

### 457
VERDICT: HARM
WHAT: The original is a row of the co-chaining map (cover_EQUILIBRIA.md, Table B, row G5) and says four things: the Living Ghost Registry's ten holdings; that no step of the Co-Chaining Logic Registry has them, standing MISSING; that this is the map's item 49, with *holdings* an old name; and that steps S36a–c are proposed for it. The new paragraph keeps the first and the old name and makes a naming concern of them. It no longer says there is no step, no longer says MISSING, no longer names item 49, and no longer names S36a–c. Also "the ten things named still" is now "the ten named still" (the living Natural Naming 6.3 has the second). The two quotes are exact (Living Ghost Registry 2.3; Natural Naming 6.3). In the same carry file the neighbouring rows of the same table (for example row G1, line 49) still stand in their old form with "MISSING" and their proposed step.
LOST: No step; MISSING. "This is item 49. …" → S36a–c.

### 458
VERDICT: MINOR
WHAT: "the standing rule sets bi-tunnelling across society" is now "the kit's rule setting bi-tunnelling across society" (in the source kit, "The standing rule" is the name of its section 2.1). "standing at v359 as at v333" is now "the words at version 359 as at version 333". Adds that the kit of Exhibits ONE and TWO at version 365 carried these. All six improvings and "nine places" are kept.
LOST: —

### 459
VERDICT: SAFE
WHAT: —
LOST: —

### 460
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

All 46 items are KIND: RESAID. There is no RELEASED item in this sample.

| Verdict | RESAID | RELEASED |
|---|---|---|
| SAFE | 21 | 0 |
| MINOR | 22 | 0 |
| PERSON'S WORDS | 2 | 0 |
| HARM | 1 | 0 |
| COULD NOT CHECK | 0 | 0 |
| Total | 46 | 0 |

- SAFE: 416, 422, 426, 427, 428, 429, 433, 434, 440, 443, 444, 445, 447, 448, 451, 452, 454, 455, 456, 459, 460.
- MINOR: 415, 417, 418, 419, 420, 421, 423, 425, 430, 431, 432, 435, 436, 437, 438, 439, 441, 442, 449, 450, 453, 458.
- PERSON'S WORDS: 424, 446.
- HARM: 457.

## READING

What I did.
- I laid each AS IT WAS beside its AS IT IS NOW and went through it clause by clause: each claim, relation, condition, negation, number, section number, named file and attribution.
- Presence: for all 46 I searched the named file in /home/claude/corus/carry/ for the whole new paragraph. Each is there, word for word as the sample has it.
- Quotations: 18 of the 46 items have sentences in double quotation marks (48 quoted strings). I looked up every one in the `*.md` files at the repository root. All 48 are exact. For the quotes that carry a section, step or line number I also checked the place (415, 418, 425, 431, 436, 439, 440, 449, 450, 452, 455, 457): all right. The other 28 items have no double-quoted sentence.
- Where a new paragraph says more than the old one, or changes a number, I opened the source: carryings/natural_physics_v377/README.md (415, 416, 420, 423, 437, 442, 459); the branch `working/physics-motion-v377` by `git show` (423); carryings/co_chaining_coverage_v378 (418); carryings/v368_sources (419, 429, 458); carryings/co_chaining_map_v376 (436, 457); carryings/resettling_v373 and Natural Physics v348 by `git show` (432); carryings/v380R/Natural_Naming_Conferring.md (435); carryings/rings_are_spirals_v377 (439); carryings/physics_for_other_files_v377 (442, 460); carryings/v382F and archive/carrying_v386EOD (453); git history of Exhibit THIRTY (450). Every addition I list is in its source. I found none made up.

What I did not check.
- Whether the original paragraphs were true. For 421, 422, 426, 427, 428, 433, 434, 438, 443 to 448, 451, 452, 454 to 456 I compared the two texts (and the living files for quotes) and did not open the source of the old paragraph.
- In 421 and 438 I did not count the "four files" and "five" in any version of the files; I only saw that the numbers and names are unchanged.
- In 452 I did not open the review of 30 September to read "441 less n".

How I drew the lines.
- Bracketed source names, "re-aimed from …" notes, "A plan, not yet final, gathered here at v381R", "at v378" and closing tags are not counted as claims, as the task says.
- PERSON'S WORDS (424, 446): the self's own quoted words are gone and every claim is whole. In 424 the attribution is kept and the words are gone from all of `carry/`. In 446 the attribution, the place and date, and the words are gone from this file, but the same older paragraph still stands with the quotation in two other carry files.
- 430 is the nearest MINOR to these. The quoted words there are the session's question, not the self's, so it is not PERSON'S WORDS; what the self did, and the self's heading, are kept. But the asker, the two line numbers, the date and the question's own words are gone. I counted the line numbers and date as a pointer to a source, like a report name. If they are counted as numbers of the original, 430 is HARM, with LOST: "The session's question left standing at about line 479 and again at 486 (5 October)".
- 439 is the other near one. "at the numbers' audit" and "at this file's motion" name the occasion; the new paragraph says only that it is Natural Numbers' to decide. I counted an occasion phrase as wording. If it is counted as a condition, 439 is HARM, with LOST: "*its far side* or *the carrying the other way* at the numbers' audit".
- HARM (457) is given because findings of the map are gone, not only wording: no step, MISSING, item 49, and the proposed S36a–c.
- A changed section or step number is MINOR where the new number is the place in the living file today and nothing else changes (431, 432, 436). In each the original's number is not kept beside the new one.
- "still to be named" said as a flat present (420) is MINOR: the fact is kept, the expectation is not said.
- A new sentence that the original did not have, or sentences written out where the original only pointed, is MINOR when I found it in its source (415, 417, 418, 423, 425, 435, 437, 441, 449, 450, 453).
- A dated past tense where the original's own tag already gave the version (422, 428, 434, 447) is SAFE. 421 and 438 are MINOR because a quoted passage is also changed by one word ("itself").
- "Possible project … It may change or never be made" on an original that was a plan, an opportunity or a proposed placing (425, 427, 432, 445, 453) is not counted against it.
- 429: "its folded sections" is now "Equilibria Definitions' folded sections". The source (Carry_Set_v368_README.md, line 141) says "Equilibria Definitions' 1,594 folded sections", so the reading is right and I left it SAFE.

Other things seen.
- No new paragraph denies anything in its original.
- The same original sentence ("Across the set, each file releases …") is resaid three ways: unchanged with "It is aimed at the set" (433, 444, 451), with a sentence about Natural Naming added (417), and turned round with another such sentence (441).
- The same original (the ten files prior to momentarying) has one new paragraph, word for word the same, in nine carry files (422, 447). The common-method original has two new paragraphs that differ only in tense at one sentence (421, 438).
- Paragraphs titled "Concern ·" and "Possible project ·" stand inside the Offerings files, where the sample found them.
