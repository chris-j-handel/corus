# Task: a third reading of older paragraphs that were said again or released

Read COMMON.md first.

Your task names a sample file. Each item is one paragraph from an older section named `## Droplets` of a file `carry/…Offerings_to_….md`. The session either replaced it with a new paragraph (KIND: RESAID) or removed it (KIND: RELEASED), after two readers. You are a third, independent reader.

For RESAID: lay AS IT WAS beside AS IT IS NOW.
- Is each claim, relation, condition, negation, number, named place and attribution of AS IT WAS in AS IT IS NOW, at the same strength? (A session's label such as "A plan, not yet final, gathered here at v381R" or a report name is not a claim.)
- Does AS IT IS NOW add, narrow, widen or deny anything?
- Each sentence in double quotation marks in AS IT IS NOW is claimed to be an exact sentence of a living file: check two or three of them with Grep in the `*.md` files at /home/claude/corus (not in subfolders).
- Open the file in /home/claude/corus/carry/ and confirm the new paragraph is there now (search for its bold title; small wording such as the name used for the three files may differ).
For RELEASED: the reason says a living file now says it, or a later section says it whole, or it was a session's own bookkeeping. Open the place named and check that the whole of what AS IT WAS says is really there, or really is bookkeeping with no concept in it.

Your report: one block for each item:
```
### <number>
VERDICT: <SAFE | MINOR | HARM | COULD NOT CHECK>
WHAT: <for MINOR or HARM: exactly what is lost, added, changed or misquoted; otherwise a dash>
```
MINOR means a wording or emphasis difference with no relation, condition, number or negation lost. HARM means something of the original is lost, changed, or wrongly released.
Then `## SUMMARY` with counts of each verdict by KIND, and `## READING`. Final message: the path of your report and the counts.
