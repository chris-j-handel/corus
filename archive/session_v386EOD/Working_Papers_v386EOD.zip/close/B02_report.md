# B02 report: a third reading of items 47 to 92 (46 items, each KIND: RESAID)

### 47
VERDICT: SAFE
WHAT: —
LOST: —

### 48
VERDICT: MINOR
WHAT: The two step numbers are changed, 54 to 81 and 139 to 226. I checked both: the registry as it was when the v376 map was made (commit 8e24fa8) had "six one-way steps forward" at 54 and "each face one way" at 139; the living Exhibit THIRTY v380L has them at 81 and 226. The second quotation now reads "each facing one way", the living file's wording, where the original had "each face one way". The closing sentence "The parting is laid for re-saying" stands for the source heading "Other re-sayings". Nothing else differs.
LOST: —

### 49
VERDICT: MINOR
WHAT: "The parting observing is still to be named" is now "No observing parting the reading is named": the sense that it is yet to be named is dropped. "a relation unsaid" is added; it matches the report's 6.2 heading, "Relations still to be said".
LOST: —

### 50
VERDICT: MINOR
WHAT: "Natural Physics 4.1" is now "Natural Physics' 3.1". I checked: at the version the v373 reading read (v348) the periodic table was at 4.1; in the living Natural Physics v379 it is at 3.1, and 3.1 has "a turn stands at 60". The number follows the living file. "its one home is Natural Chemistry" is now said as work that "may change or never be made".
LOST: —

### 51
VERDICT: MINOR
WHAT: The status word "learned" is dropped. In the passage, "the sections that meet the thing arriving" is now "the sections coupling with the thing arriving", and "what it carries in" / "what it releases back" are now "the thing it carries in" / "the thing it releases back". The label "Aimed at a file" is dropped. Every claim is there.
LOST: —

### 52
VERDICT: SAFE
WHAT: —
LOST: —

### 53
VERDICT: SAFE
WHAT: —
LOST: —

### 54
VERDICT: SAFE
WHAT: —
LOST: —

### 55
VERDICT: SAFE
WHAT: —
LOST: —

### 56
VERDICT: SAFE
WHAT: —
LOST: —

### 57
VERDICT: SAFE
WHAT: —
LOST: —

### 58
VERDICT: MINOR
WHAT: The status "laid ready" is dropped, and the line that was laid ready is re-worded: "this file is the door of a question about living together" is now "An interest in a question about living together opens at it", and "in front of the set" is now "ahead of the set". "Its standing TWENTY-THREE v333 58" is now "At version 333 they are 58" (the released words; the v381F report's Finding 6 has 58 per thousand at TWENTY-THREE). Added: "each a version" after the 4 loopings (Finding 18 counts loopings as versions) and "at Natural Intelligence" for the far side (the v381F table has it so). No number or relation is lost.
LOST: —

### 59
VERDICT: SAFE
WHAT: —
LOST: —

### 60
VERDICT: SAFE
WHAT: —
LOST: —

### 61
VERDICT: SAFE
WHAT: —
LOST: —

### 62
VERDICT: HARM
WHAT: The original's named place and the word of its negation are changed. "Natural Intelligence 6.6 already carries the cube's three conservings, none of them a total" is now "Natural Mathematics 3.6 has the cube's three conservings, 'none of them a size'". I checked the living files: Natural Intelligence v380R has no cube at 6.6 (6.6 is "One form at each scale, our now"); Natural Mathematics v380L 3.6 has "three conservings, two totals modulo three and modulo two and one parity, none of them a size". The history shows the sentence "none of them a total" left Natural Intelligence at v373, entered Natural Mathematics at v378, and was re-said there as "a size" at v380L. So the new paragraph follows the living files as they are now, but what the original recorded (the place 6.6 of Natural Intelligence, and "a total") is no longer in the paragraph, and "a total" and "a size" are two different things in this file set. Also dropped: "already", and "so the note dissolves into those two" (the new paragraph keeps only "Carried on from this is the join at Natural Exploring alone"). All else is there, and the two Natural Exploring 5.4 quotations are exact.
LOST: Natural Intelligence 6.6 already carries the cube's three conservings, none of them a total, and Equilibria Definitions v363 its corner and edge parities, so the note dissolves into those two

### 63
VERDICT: SAFE
WHAT: —
LOST: —

### 64
VERDICT: SAFE
WHAT: —
LOST: —

### 65
VERDICT: MINOR
WHAT: Two things. (1) "Natural Intelligence 6.6 already carries the cube at its own reaching" is now "Natural Mathematics 3.6 has the cube at its own reaching", with an exact quotation of Natural Mathematics 3.6. The living Natural Intelligence has no cube at 6.6 and the living Natural Mathematics has it at 3.6 (see item 62), so the place follows the living files; "already" is dropped. (2) "The exclusion" is now "The exclusion of equilibria", in the title too. The words "of equilibria" are not in the original, and I did not find "exclusion of equilibria" in the source (`Kit_Rings_in_Motion_v366.md` says "the session's exclusion" and "the exclusion"). No claim word of the original is otherwise changed.
LOST: —

### 66
VERDICT: SAFE
WHAT: —
LOST: —

### 67
VERDICT: MINOR
WHAT: The new paragraph is much longer than the original and adds: the Natural Numbers quotation, "an odd centre squared less one, the product of its prior and next", Natural Chemistry having the word at one place, the Natural Naming row for *face* and the sentence "A seam is a name changing at its number", and the reading that the compound is "a number-word with no sense at the resolver". Each addition is in the fuller v380R entry at `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 47, and the two quotations are exact. The status "Ready, at v380R" is dropped; the item is now a Concern. The original's three claims (one naming; *seam-product* or the field's own word; Natural Numbers decides) are there.
LOST: —

### 68
VERDICT: SAFE
WHAT: —
LOST: —

### 69
VERDICT: SAFE
WHAT: —
LOST: —

### 70
VERDICT: PERSON'S WORDS
WHAT: The original quotes the person: 'The self said at about line 854 (6 October) ... "we are not going to be writing in our living files any further this session as the method of dropletting is working and gathering droplets all across our files will be valuable as the improving passes will all be similar familiar method working."' The transcript `carryings/v381R/Session_Transcript_v381R.txt` line 854 has these as the person's words. The new paragraph has no quotation and does not say who said it; the content is re-told as "Session v381R writes no further in the living files: ...". Every claim is otherwise whole.
LOST: —

### 71
VERDICT: SAFE
WHAT: —
LOST: —

### 72
VERDICT: MINOR
WHAT: "The namings held for both to agree" is now "The namings open for both to agree". "It releases the single naming closing at all or none at all" is now "The settling of these namings releases the single naming ...": the pronoun is given a referent. The source table (`Carry_Set_v368_README.md`, place 6, column "What it releases") has the place, the namings, as what releases, so the reading agrees with the source; "the settling of" is the session's wording.
LOST: —

### 73
VERDICT: MINOR
WHAT: The rank "Open, hardest first, 2" is dropped. Added: two quotations (both exact in the living files) and the sentence "Natural Naming has one name of 1 to 8 by its four-cycle, and Resolving the Hard Problem Registry two names eight apart", which is the session's own reading of the two living files and is not in the original. The original's claim (4.9 against the seating eight apart, parting at six of the ten) is there.
LOST: —

### 74
VERDICT: SAFE
WHAT: —
LOST: —

### 75
VERDICT: SAFE
WHAT: —
LOST: —

### 76
VERDICT: SAFE
WHAT: —
LOST: —

### 77
VERDICT: MINOR
WHAT: The date "at v380" is dropped. Added: three exact quotations of Natural Naming 5.48, and a sentence on the offered saying ("the two in arriving at bi-tri-bi and bi-co-bi, and the two different out tri-bi-co, the possibling next, and co-bi-tri, the next existing: 9 and 17, momentarying the carrying of each releasing to its arriving, and entraining the releasing"). That sentence is not in the original; it is in the fuller v380 concern at `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 109. The original's claims (the two out at 9 and 17, or at 12 at 0 and 9 as 5.48 says; waiting on a following at Exhibit ONE) are there.
LOST: —

### 78
VERDICT: MINOR
WHAT: The original's first label, "For the site, the README or incoming's README, re-aimed from this file", is dropped. The new paragraph keeps only the second label's aim, "Natural Arriving's Part EIGHT and at the site's top", so the README and incoming's README are no longer named as a place it is for, and it is no longer said to be re-aimed from this file. The content of the re-saying and its address are whole.
LOST: —

### 79
VERDICT: MINOR
WHAT: The two paths are changed from `incoming/...` to `carryings/...`. I checked: `incoming/natural_physics_v377/` is not there now, and `carryings/natural_physics_v377/` and `carryings/review_natural_physics_v377/README.md` are. The label "Next at this file, at v378's receiving" is dropped. "is met at the proposal" is now "answered at the proposal". The condition and the six listed things are whole.
LOST: —

### 80
VERDICT: SAFE
WHAT: —
LOST: —

### 81
VERDICT: MINOR
WHAT: The original gives the passage as "The session's observing at about line 852 (6 October)" and quotes it. The new paragraph says the same content plainly, with no quotation and no word that it was the session's observing. (Transcript line 852 is the working session's own note, not the person's, so this is not the person's words.) "the files they were really for" is now "the files they were for". The label "Aimed at a word" is dropped. Every number and relation is there.
LOST: —

### 82
VERDICT: SAFE
WHAT: —
LOST: —

### 83
VERDICT: MINOR
WHAT: The mark "(new)" after "releasing one number" is dropped. Nothing else differs.
LOST: —

### 84
VERDICT: MINOR
WHAT: The step numbers are changed, "38 to 44 and 131 to 134" to "42 to 48 and 143 to 146". I checked: the registry at the close of v377 (commit 3673fbb) had these sentences at 38 to 44 and 131 to 134, and the living Exhibit THIRTY v380L has the same sentences at 42 to 48 and 143 to 146. "its concern 2 ... its concern 6" and "the carrying's concerns" are now "these offerings' concern 2 ... concern 6" in the file (the sample has "this mate's"). Nothing else differs.
LOST: —

### 85
VERDICT: MINOR
WHAT: The step numbers are changed, "46, 55, 58, 141, 146" to "70, 82, 91, 250 and 263". I checked each against the registry as it was when the v376 map was made (commit 8e24fa8) and the living Exhibit THIRTY v380L: each new number has the same sentence, re-said at 250 and 263. Added: the section addresses 1.5 and 3.3 and the whole sentence that has "two and one half momentaries", exact in the living Equilibria Registry.
LOST: —

### 86
VERDICT: MINOR
WHAT: The step numbers are changed, "42, 44" to 63 and 65. I checked: the registry at the time of the v376 map had these two sentences at 42 and 44, and the living Exhibit THIRTY v380L has them, word for word, at 63 and 65. The quotations of 7.5 are exact. Nothing else differs.
LOST: —

### 87
VERDICT: SAFE
WHAT: —
LOST: —

### 88
VERDICT: MINOR
WHAT: "with opposite signs and meet at 0" is now "with opposite parities and are at 0 together": "signs" is now "parities". The label "Marking for the next session" is dropped; "for both" is kept. The studies, numbers and what each was read at are whole.
LOST: —

### 89
VERDICT: SAFE
WHAT: —
LOST: —

### 90
VERDICT: SAFE
WHAT: —
LOST: —

### 91
VERDICT: MINOR
WHAT: "releases 4.1's periodic table" is now "releasing the periodic table of its 3.1". As at item 50, the periodic table was at 4.1 in the version the v373 reading read and is at 3.1 in the living Natural Physics v379; 2.5 is the same section in both, and it is left at 2.5. Nothing else differs.
LOST: —

### 92
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

All 46 items are KIND: RESAID. There are no RELEASED items in this sample.

| Verdict | RESAID | RELEASED |
|---|---|---|
| SAFE | 25 | 0 |
| MINOR | 19 | 0 |
| PERSON'S WORDS | 1 | 0 |
| HARM | 1 | 0 |
| COULD NOT CHECK | 0 | 0 |
| Total | 46 | 0 |

- HARM: 62
- PERSON'S WORDS: 70
- MINOR: 48, 49, 50, 51, 58, 65, 67, 72, 73, 77, 78, 79, 81, 83, 84, 85, 86, 88, 91
- SAFE: 47, 52, 53, 54, 55, 56, 57, 59, 60, 61, 63, 64, 66, 68, 69, 71, 74, 75, 76, 80, 82, 87, 89, 90, 92

## READING

**Presence.** Each of the 46 new paragraphs is in its file under `carry/` now, word for word as the sample gives it, followed by " — v386EOD". The one difference is item 84, where the file has "these offerings'" at the three places the sample has "this mate's".

**How I read.** I laid each pair side by side, claim by claim. Where the new paragraph changed a number or a place, I opened the source or the history to see whether the new one points at the same thing. I treated the session's labels ("A plan, not yet final, gathered here at v381R", "Returned to the droplets by a second reader at v381R", "re-aimed from ... at v381R") and report names as no claim.

**Quotations.** I checked quotations in 16 of the 46 items (47, 48, 54, 55, 58, 59, 62, 65, 67, 73, 77, 80, 85, 86, 90, 92). Each double-quoted sentence I checked is in a living file at the root, at the section the paragraph names. In 48 the quotation follows the living file's wording ("each facing one way"), not the old map's.

**The one HARM, item 62.** The session moved the paragraph's reference from Natural Intelligence 6.6 to Natural Mathematics 3.6 and changed "none of them a total" to "none of them a size". Both changes match the living files as they are today: the cube left Natural Intelligence at v373 and Natural Mathematics now says "a size". I still give HARM because the word of a negation and a named place of the original are changed, and the original's record is not kept anywhere in the new paragraph. If the audit counts a paragraph brought up to the living files as no harm, this item is the one to look at again.

**Addresses brought up to the living files (nine items, given MINOR).** In 48, 84, 85 and 86 the registry's step numbers are changed; in 50 and 91 a Natural Physics section number is changed (4.1 to 3.1); in 79 two folder paths are changed (`incoming/` to `carryings/`); in 65 the place is changed from Natural Intelligence 6.6 to Natural Mathematics 3.6. I checked every one against the older version in the history and the living file, and each new address has the same sentence or section. I gave MINOR and not SAFE because a number or place of the original is no longer in the paragraph. Item 62 has the same kind of change plus a changed word, hence HARM there.

**Additions (items 65, 67, 73, 77).** In 67 and 77 the new paragraph is fuller than the original, and the added matter is in the earlier, fuller entries under `archive/carrying_v381R/`. In 73 one added sentence is the session's own reading of two living files. In 65 the words "of equilibria" are added to "the exclusion"; I did not find that phrase in the source.

**Person's words.** Only item 70 quotes the person, and its quotation and its "The self said" are gone. Item 81's quotation is the working session's own note (transcript line 852), so I gave it MINOR for the lost attribution, not PERSON'S WORDS. The italic passages in 51 and 58 are from the v381F report, not the person.

**Not checked.** I did not check whether the older sources themselves were right, nor whether the things the paragraphs describe are still true of the living files, beyond the addresses named above. I did not check quotations in the other 30 items.
