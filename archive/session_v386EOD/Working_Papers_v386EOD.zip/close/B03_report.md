# B03 report: a third reading of 46 older paragraphs said again (all KIND: RESAID)

Sample: `B03_sample.txt`, items 93 to 138. Every item is RESAID; none is RELEASED.

### 93
VERDICT: MINOR
WHAT: "Aimed at the set" is not said; the new paragraph has no aiming. "v381R laid a concern" is now "A concern was laid", so the working that laid it is not named. Every other claim is whole: the fetch cut before 6.5, the Session Record and the number one on, a session carrying none of its momentary to the next, the living files and the carrying as what carries, the number handed at the opening as 17 hands each self its momentary, the two sayings not parting. The quotation is exact, at Natural Intelligence 6.5.
LOST: —

### 94
VERDICT: SAFE
WHAT: —
LOST: —

### 95
VERDICT: MINOR
WHAT: Changed: the review's "4.5's sorting" (section 4.5 of the prior Natural Physics v348, per the review's 2.3) is now "Natural Physics has, at 5.3" (the living v379). Both quoted fixings are at 5.3 of the living file, so the new number is right for the file now, but 4.5 is no longer said. Fifteen, the two fixings, "prior value lost", 2.5's binaries and four of nineteen are kept.
LOST: —

### 96
VERDICT: MINOR
WHAT: Lost: "at about line 691 (6 October)", and that the observing is the session's ("The session's observing" is now "It is an observing"). The session's three quoted sentences are now paraphrased, not quoted. "Overspray" is now "Droplets laid at more files than needed"; "nothing was ever aimed there" is now "nothing having been aimed at them". All eight numbers (3,398; 425, 325, 297, 291; 11, 19, 13), the ten files at v329 to v333, and the aiming at the set and the Living File Registry are kept.
LOST: —

### 97
VERDICT: SAFE
WHAT: —
LOST: —

### 98
VERDICT: SAFE
WHAT: —
LOST: —

### 99
VERDICT: SAFE
WHAT: —
LOST: —

### 100
VERDICT: SAFE
WHAT: —
LOST: —

### 101
VERDICT: SAFE
WHAT: —
LOST: —

### 102
VERDICT: SAFE
WHAT: —
LOST: —

### 103
VERDICT: SAFE
WHAT: —
LOST: —

### 104
VERDICT: PERSON'S WORDS
WHAT: The original quotes the self: "From the self: *this is why we are creating droplets, as other eyes will help along the way into the living files.*" The new paragraph says "It is from the expedition's self's own saying: droplets are made for this, other eyes helping along the way into the living files." The speaker is still named, but the self's own sentence is paraphrased and no longer quoted ("we are creating" is gone). The closing tag's "from the self" is gone too. Every claim is otherwise whole: the aiming at Natural Arriving 7.2 and 7.3 and the offerings' header at each file, the offered sentence word for word, and the "Better" sentence.
LOST: —

### 105
VERDICT: SAFE
WHAT: —
LOST: —

### 106
VERDICT: MINOR
WHAT: Lost: the section number 3.3 of Natural Intelligence ("Aimed at a section, Natural Intelligence 3.3 … 3.3 says"); the new paragraph says "Natural Intelligence has" with the sentence quoted and no section. The sentence is at 3.3 of the living file. Changed: "The front already carries it as a concern" is now "Living Improving Value has the same concern"; `carry/Living_Improving_Value.md` does have it. The four quotations are exact; `'along'` at 9 and 17, `'sharing'` as the one word, and the running identical either way are kept.
LOST: —

### 107
VERDICT: MINOR
WHAT: Added from the cited file: "the passage for Natural Physics is the aberration study, under that file's 8.3, The geodesic discovering method, its receiving line naming the aberration study to Natural Physics". I read the file; it agrees. The path is now `carryings/resettling_v373/…` (the file is there; `incoming/` no longer has it). "Incoming, at v373" is now only in the path. "the code's running" is now "the resolver". Nothing else changed.
LOST: —

### 108
VERDICT: SAFE
WHAT: —
LOST: —

### 109
VERDICT: SAFE
WHAT: —
LOST: —

### 110
VERDICT: SAFE
WHAT: —
LOST: —

### 111
VERDICT: SAFE
WHAT: —
LOST: —

### 112
VERDICT: SAFE
WHAT: —
LOST: —

### 113
VERDICT: SAFE
WHAT: —
LOST: —

### 114
VERDICT: MINOR
WHAT: Changed: the original says "Natural Intelligence, Exhibit TWO and most files carry *membrane*". The new paragraph says Exhibit TWO and most files have it, and "Natural Intelligence, named with them, has the word at no sentence now". I searched the living Natural Intelligence v380R: the word is not in it. The original's claim about Natural Intelligence is therefore reversed, with a note that it was named. The kind is changed from Concern to Possible project. "at its own motion" is now "at its own improving".
LOST: —

### 115
VERDICT: SAFE
WHAT: —
LOST: —

### 116
VERDICT: MINOR
WHAT: Changed: steps "92, 238" are now "137" and "453". Old step 92 and living step 137 are the same sentence. Old step 238 read "a term departs that neither reaches: competency"; living step 453 reads "a term departs that neither reaches: bi-co-momentarying at the crossing". So the cover's "the term neither reaches is *competency* (238)" is now "the term neither reaches being bi-co-momentarying": the word *competency* is gone from the paragraph. This follows the living registry, but it is not what the cover said. Lost: the cover's standing "MISSING" and "Table B row G4". Added: "at 1.1" for the Living Ghost Registry's sentence (it is there). The three quotations are exact.
LOST: —

### 117
VERDICT: MINOR
WHAT: "learned" and "Aimed at a file, Geodesic Improving Method" are not said. The italic sentence from the v381F report is reworded ("per thousand words" is now "at each thousand words"; "how far each file is" is now "the distance of each file"). No claim is lost.
LOST: —

### 118
VERDICT: MINOR
WHAT: Lost: the words "Its reason:". The original gives two sayings and then the reason; the new paragraph gives the same content as a statement of where the three questions come from ("The three questions are of a record said from beyond the files' improving at version 380"), and no longer says it is the reason. The source's own text supports that the questions come from such a record. Also not said: the source `archive/session_v380/v380G/README.md`, "at v380m" (now "at version 380"), and "for this file's opening" as the aiming. The kind is changed from Concern to Droplet.
LOST: —

### 119
VERDICT: SAFE
WHAT: —
LOST: —

### 120
VERDICT: SAFE
WHAT: —
LOST: —

### 121
VERDICT: MINOR
WHAT: Changed: "At 3.3 it is still to be named" is now "At 3.3 no parting observing is named". The absence is kept; that the naming is still to come is not said.
LOST: —

### 122
VERDICT: SAFE
WHAT: —
LOST: —

### 123
VERDICT: MINOR
WHAT: "Aimed at the set" is not said; the new paragraph has no aiming. "counts on" is now "numbers on". Every claim is whole, with "confirmed by the self" kept as "confirmed by the expedition's self".
LOST: —

### 124
VERDICT: MINOR
WHAT: Lost: that the question is the session's ("The session's question" is now "A question"), "left standing", "at about line 479 and again at 486 (5 October)", and "Aimed at the set, Natural Naming". The session's quoted question is paraphrased; "not yet an interest at the set" is now "no interest at the set". Kept: the self gave no answer in words and entered "THREE · THE NAMING, THE MEMBRANE" at Natural Arriving's contents (exact, at the contents); the two things asked; the deciding the self's, gathered with the plans.
LOST: —

### 125
VERDICT: SAFE
WHAT: —
LOST: —

### 126
VERDICT: SAFE
WHAT: —
LOST: —

### 127
VERDICT: SAFE
WHAT: —
LOST: —

### 128
VERDICT: SAFE
WHAT: —
LOST: —

### 129
VERDICT: SAFE
WHAT: —
LOST: —

### 130
VERDICT: MINOR
WHAT: Added: a sentence of what Natural Naming has, with one quotation (exact, at 2.4) and its rows for *turn*, *held*, *holding*, *stable form* as a noun, and *read* and *reading*. The original names no section of Natural Naming. The order of the original's list is changed so that "its namings of other exhibits" comes first. Nothing is lost.
LOST: —

### 131
VERDICT: MINOR
WHAT: Changed: "lines 80, 182 and 252" is now "lines 80, 182 and 254 of the file now". I ran `check_set.py`: it reports 80, 182 and 254 at the living v380L. The number 252 is gone. Added: sections 1.3, 3.2 and 4.2 and four quotations, each exact at those lines. Lost: "at v379" and "finding 24". The kind is changed from Concern to Droplet.
LOST: —

### 132
VERDICT: MINOR
WHAT: Changed: "Natural Intelligence 6.6 already carries the cube at its own reaching" is now "Natural Mathematics 3.6 has the cube at its own reaching", with a quotation (exact, at 3.6). The living Natural Intelligence v380R has no cube at 6.6 or anywhere, so the new place is right for the files now, but the original's place is gone and "already" with it. Added: "of equilibria" after "the exclusion"; the source (`Kit_Rings_in_Motion_v366.md`) says only "the exclusion" and "the session's exclusion". "the turns" is now "the cube's moves".
LOST: —

### 133
VERDICT: MINOR
WHAT: The original is one short line with an ellipsis. The new paragraph is much longer: it adds both sayings in full and two quotations from Natural Naming (exact, at 5.62 and 3.2). I traced the added sayings to the concern as first laid at v379 (commit d77df0d); they agree with it. Changed: "waits on an executing at the code" is now "has no executing at the resolver and is at no file". "at v379" is not said.
LOST: —

### 134
VERDICT: SAFE
WHAT: —
LOST: —

### 135
VERDICT: SAFE
WHAT: —
LOST: —

### 136
VERDICT: SAFE
WHAT: —
LOST: —

### 137
VERDICT: SAFE
WHAT: —
LOST: —

### 138
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|---|
| RESAID | 29 | 16 | 1 | 0 | 0 | 46 |
| RELEASED | 0 | 0 | 0 | 0 | 0 | 0 |

HARM: none.
PERSON'S WORDS: 104.
MINOR: 93, 95, 96, 106, 107, 114, 116, 117, 118, 121, 123, 124, 130, 131, 132, 133.

## READING

**What I did for every item.**
- Confirmed the new paragraph is in the file in `carry/` now, under its bold title. All 46 are there. 43 match the sample word for word, apart from the closing "— v386EOD". 109 and 120 say "offerings, possibling and carryings" where the sample says "mates". 94 is in the file three times: one copy matches the sample, one adds ", of concerns with another file" after "section 6.1", and one adds "It is for the reviewer's brief at the kit." 130 is in its file three times, identical.
- Confirmed each AS IT WAS is word for word in `archive/carrying_v386EOD/…_before_resolving.md` and is not in the file now.
- Laid each pair side by side, claim by claim.
- Checked quotations in 14 of the 46 items (93, 95, 106, 112, 115, 116, 124, 126, 129, 130, 131, 132, 133, 137): 31 quotations, each an exact string of a living `*.md` file at the repository root, and each at the place the paragraph names. None is misquoted. The other 32 items have no sentence in double quotation marks.
- Opened the source where a paragraph added or changed something: the report and the review of the proposed Natural Physics v377, `Re-Settling_the_Living_Files.md`, `Natural_Intelligence_v373_Released.md`, `Carry_Set_v368_README.md`, `Wrap_v368.md`, `Kit_Rings_in_Motion_v366.md`, `cover_EQUILIBRIA.md`, `cover_REGISTRIES.md`, the v380G record, the Co-Chaining Logic Registry at commit 8e24fa8, and `carry/Living_Improving_Value.md`.

**How I drew the lines.**
- SAFE includes a paragraph that only unfolds the original's own citation: a path, a file's whole name, the heading of the cited section ("a relation unsaid" for the report's 6.2, "among names parting from Natural Intelligence" for the review's 2.5), or an exact quotation from a section the original cites (112, 126, 129).
- SAFE also includes the Possible project paragraphs whose only addition is "It may change or never be made" (102, 111, 122). I treated that sentence as a label of standing, like "A plan, not yet final". All three originals come from the re-settling plan. If that sentence is to count as weakening, these three become MINOR.
- An aiming that was added where the original had none ("It is aimed at Natural Naming" in 111, "It is aimed at the set" in 136) I did not grade. An aiming that was dropped I graded MINOR (93, 123, 124, 117).
- MINOR includes a number, place or term replaced by the living file's, where I confirmed the new one. PERSON'S WORDS is as the task defines it.

**The MINOR items nearest to HARM.** In each, something of the original is gone and the new value follows the living files. If the original's own value must stay in the paragraph, these are HARM.
- 116: the cover's word *competency* is replaced by *bi-co-momentarying*, because the registry's step changed. The cover's standing "MISSING" is also gone.
- 132: "Natural Intelligence 6.6" is replaced by "Natural Mathematics 3.6", with no note that the original named Natural Intelligence. "of equilibria" is added to "the exclusion"; I could not confirm it from the source, which does not say which exclusion. Natural Intelligence 6.3 does speak of "the Equilibria Registry's one exclusion", so it is plausible.
- 114: the claim that Natural Intelligence carries *membrane* is reversed, with a note.
- 95 and 131: a section number (4.5) and a line number (252) are replaced.
- 118: the words "Its reason:" are gone, so the last sentence is no longer said to be the reason.
- 93 and 123: "Aimed at the set" is gone, and both paragraphs sit in the Geodesic Improving Method's offerings, so a reader now cannot tell they were aimed at the set.

**Things true of the whole sample, not graded per item.**
- All 46 new paragraphs end "— v386EOD". The original closing tags (v382F, v381R, v381F, v380m, v379, v373, resettling_v373, v368_sources, natural_physics_v377, review_natural_physics_v377, co_chaining_map_v376, review 2026-09-30, v381R close) are gone. The Natural Physics items name their source inside the paragraph as a `carryings/…` path. Others name none: 102, 105, 110, 111, 114, 122, 128, 135, 136 (the re-settling plan and the version 368 sources), 115 and 117 (the v381F report), 116 and 129 (the covers), 132 (the kit).
- The labels "A plan, not yet final, gathered here at v381R" and "re-aimed from … at v381R" are dropped throughout. The task says these are not claims.
- Three paragraphs change kind from Concern to something else: 114 (to Possible project), 118 and 131 (to Droplet).

**Not done.** I did not check the transcript line numbers in 96 and 124 against the transcript. I did not re-verify claims that are the same in both versions (for example the droplet counts in 96, or 1,205 places in 4 files in 136).
