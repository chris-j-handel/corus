# Task: paragraphs that were in `carry/` before the session and were changed or removed by one reader alone

Read COMMON.md first.

`A2_changed.txt` lists paragraphs that were in a file of `carry/` before session v386EOD and are no longer there word for word after the named commit. No second reader checked these changes.

For each item: run `git -C /home/claude/corus show <COMMIT> -- <FILE>` and read the change around that paragraph. Decide what happened to it:
- REWORDED: replaced by a new paragraph at the same place. Lay the two side by side: is each claim, condition, negation, number and named place of AS IT WAS in the new paragraph at the same strength? Was anything added?
- MOVED: the same text is now at another place or file (find it with Grep in /home/claude/corus/carry/).
- REMOVED: gone with nothing in its place. Is what it said at another place (find it), or lost?
Then check the file as it is now (`/home/claude/corus/<FILE>`): is the replacement still there?

Your report: one block for each item:
```
### <number>
WHAT HAPPENED: <REWORDED | MOVED | REMOVED>
NOW: <the paragraph that replaced it, or where it moved, or "nothing">
LOST OR ADDED: <exactly what; or "nothing found">
VERDICT: <SAFE | MINOR | HARM>
```
Then `## SUMMARY` with counts and the most serious, and `## READING`. Final message: the path of your report and the counts.
