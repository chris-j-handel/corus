# B09 report: a third reading of 46 older paragraphs said again (all KIND: RESAID)

Sample: `B09_sample.txt`, items 369 to 414. Every item is RESAID; none is RELEASED.

### 369
VERDICT: SAFE
WHAT: —
LOST: —

### 370
VERDICT: MINOR
WHAT: Lost: that the three names are from the review of the proposed Natural Physics v377, at its section 2.5 (headed there "Names parting from Natural Intelligence"); the new paragraph names the proposed text and not the review. Added: the living Natural Physics v379 has *tipping* at the title of 2.3 and at 2.4, and *participant* at two sentences; the four quotations are exact (2.3 title, 2.4, 1.1, 1.2). Kept: *tipping* for the changing at 12 is a name at no line of Natural Intelligence (I searched the living v380R: no "tipping"); *participant* and *member* for *self* at the proposal.
LOST: —

### 371
VERDICT: SAFE
WHAT: —
LOST: —

### 372
VERDICT: SAFE
WHAT: —
LOST: —

### 373
VERDICT: HARM
WHAT: Lost: the last sentence of the original, about Natural Intelligence 8.7's sentence paragraph. Changed: "Natural Intelligence 8.6" is now "Natural Intelligence 5.4". What I found beside it: the re-settling draft of v373 (the source) has both sentences; the 8.6 of Natural Intelligence at v373 was "Two methods parting at the precise place" and the living v380R has "5.4 Two methods parting at the now", so the new number fits the file now. The living v380R has no 8.7 and no paragraph on a sentence, so the lost sentence describes a release that the living file shows already made. The lost sentence is at no other paragraph of `carry/` (searched "8.7", "Explaining 2.1", "sentence paragraph"). The session's record has a like entry for a different, released paragraph ("Natural Intelligence has no 8.7"), not for this one.
LOST: Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there. (Also changed: "to Natural Intelligence 8.6 or Natural Philosophy".)

### 374
VERDICT: SAFE
WHAT: —
LOST: —

### 375
VERDICT: SAFE
WHAT: —
LOST: —

### 376
VERDICT: SAFE
WHAT: —
LOST: —

### 377
VERDICT: MINOR
WHAT: Changed: "the completing and the parity both at 12 and 4" and "the middle and the rate both at 13 and 5" are now said without "both" (the first as a quotation plus "the completing at 12 and 4"; the third as "the middle and the rate at 13 and 5", which can be read as one at each number). "this file's the front sort" is now "Its front". "the Equilibria Registry's carrying, concern 5" is now "concern 5 at Offerings to Equilibria Registry" (concern 5 is there, line 63). All seats, pairs and the settling are kept; the three quotations are exact (line 740 and the front).
LOST: —

### 378
VERDICT: MINOR
WHAT: Lost: whose question it is and where it is. The original says "The session's question left standing at about line 479 and again at 486 (5 October)" and gives the question inside quotation marks; the new paragraph says "A question", with no session, no line, no date, no "again", and the question re-worded as statements. Changed: "is not yet an interest at the set" is now "is no interest at the set" (the next clause, "it becomes one", is kept). The quoted words are the session's, not the person's (`carryings/v381R/Session_Transcript_v381R.txt` line 479 is the session speaking), so this is not PERSON'S WORDS. What the person did is kept with its attribution and its quoted heading: "The expedition's self gave no answer in words and carried it into Natural Arriving's contents as "THREE · THE NAMING, THE MEMBRANE"". The two things asked, the deciding being the self's, and the aim at the set and Natural Naming are kept. See READING.
LOST: —

### 379
VERDICT: MINOR
WHAT: Lost: "found beside the register, carried in the second report". Added: seven quotations placing the two-way and the rate at each file (all exact; Natural Naming 4.9, the front of Resolving the Hard Problem Registry, Natural Physics 5.11), and the sentence "each is at even at the one file and at odd at the other". "5.11's pairs paragraph rests on the second file's faces, and says so" is kept as the living 5.11 leaning on them and the proposed text of v377 naming that file.
LOST: —

### 380
VERDICT: SAFE
WHAT: —
LOST: —

### 381
VERDICT: MINOR
WHAT: Lost: "line 178" (the quoted sentence is still at line 178 of the living file, in 2.6). Changed: the form, from a word aimed at with its replacement (*released across* → *shared across*) to a concern of two sayings parting, with "*Shared across* is offered at the first saying". "Natural Naming at v380R" is now two exact quotations from Natural Naming 3.2. Nothing else differs.
LOST: —

### 382
VERDICT: SAFE
WHAT: —
LOST: —

### 383
VERDICT: MINOR
WHAT: Lost: the status "laid ready", and the ready sentence as a sentence (it is re-worded and no longer in italics; "its motion is in front of the set" is now "its motion is ahead of the set"). Changed: "Its standing *FIFTEEN v329 50*" is now "At version 329 its released words are 50 in each thousand" (the v381F report's table of doors gives "FIFTEEN v329 50" among released words a thousand, so the reading is right). Added: "at Natural Intelligence" for the far side (right by `Loopings.tsv`), and "its versions numbered at the repository's history" for the loopings (right by Finding 18: "Natural Emanating 8 and 4"). Every number is kept.
LOST: —

### 384
VERDICT: SAFE
WHAT: —
LOST: —

### 385
VERDICT: SAFE
WHAT: —
LOST: —

### 386
VERDICT: SAFE
WHAT: —
LOST: —

### 387
VERDICT: SAFE
WHAT: —
LOST: —

### 388
VERDICT: SAFE
WHAT: —
LOST: —

### 389
VERDICT: SAFE
WHAT: —
LOST: —

### 390
VERDICT: MINOR
WHAT: Changed: the step number "252" is now "step 538". I compared the registry the map was read against (commit 8e24fa8, step 252) with the living v380L (step 538): the step's text is the same, word for word, so the new number is right for the file now. Changed: "See P7" is now P7's own sentence written out, "as a step following step 538 and re-saying the first"; it is word for word P7 of `carryings/co_chaining_map_v376/cover_REGISTRIES.md`. The label P7 and the map's heading "Other re-sayings" are gone. Both quotations are exact (*The given*; step 538).
LOST: —

### 391
VERDICT: MINOR
WHAT: Added: four of the seven namings are now said as parted by Natural Naming at "Four pairs are two concepts at two names, the meaning changing on transposing" (exact, at 4.6; the four pairs there are these four). With that, "bi-co-podaling or transmissioning" and "floating neutral or floating neutralling" are now joined by "and", and "three sets of four boundings" is now "the eight bi-couplings and the four boundings, of three sets of four boundings". Changed: "It releases the single naming closing at all or none at all" is now "The agreeing of each gives the single naming, at all or none at all" ("closing" is gone). "held" is now "open"; "The ten is settled" is now "The ten were agreed". The three namings still open and the ten at v368 are kept.
LOST: —

### 392
VERDICT: MINOR
WHAT: Changed: the review's section numbers "4.1's", "4.3's" and "5.10's" (sections of the prior v348) are now "at 3.1", "at 3.5" and "at 3.2" of the living Natural Physics v379. The three quotations are exact and are at 3.1, 3.5 and 3.2 of the living file, so the new numbers are right for the file now, but the prior's numbers are gone. Added: that the living file has the three. Kept: item 10 of the review's 2.3, a prior value lost at the proposal, minor; 114, 120 and 126; Natural Biology's five-level table.
LOST: —

### 393
VERDICT: MINOR
WHAT: Changed: the two paths `incoming/rings_are_spirals_v377/` and `incoming/physics_for_other_files_v377/` are now `carryings/…` (both folders are at `carryings/` now and not at `incoming/`). "That session received the first at its commit 059e022" is now "the first received at commit 059e022", with no receiver named. The branch, both commits, two corrections, seven findings at 2.1 to 2.4, 3, 4 and 5, and "its subtitle says six" are kept.
LOST: —

### 394
VERDICT: SAFE
WHAT: —
LOST: —

### 395
VERDICT: SAFE
WHAT: —
LOST: —

### 396
VERDICT: SAFE
WHAT: —
LOST: —

### 397
VERDICT: SAFE
WHAT: —
LOST: —

### 398
VERDICT: MINOR
WHAT: Changed: inside what the v365 scripts are reported to do, "the surfaced signs" is now "the surfaced parities", "run" is now "executed", "the returned carrying" is now "the carrying given back", and the tense is now past with "At version 365" added. "held for both to agree" is now "is for both to agree". Added: "v3621" is now "Exhibit ONE Natural Resolver's version 3621" (other paragraphs of `carry/` say "ONE v3621"). Every script name, the seven checks, the six connectors, the ten internal positions, the twelve identifiers, the seventeen positions and the proposals 2003 and 2195 are kept.
LOST: —

### 399
VERDICT: HARM
WHAT: The same original and the same new paragraph as 373, at Offerings to Natural Intelligence Corus. Lost: the last sentence, about Natural Intelligence 8.7's sentence paragraph. Changed: "Natural Intelligence 8.6" is now "Natural Intelligence 5.4". The same findings as at 373 hold: 5.4 fits the living file now; the living v380R has no 8.7 and no paragraph on a sentence; the lost sentence is at no other paragraph of `carry/`.
LOST: Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there. (Also changed: "to Natural Intelligence 8.6 or Natural Philosophy".)

### 400
VERDICT: SAFE
WHAT: —
LOST: —

### 401
VERDICT: SAFE
WHAT: —
LOST: —

### 402
VERDICT: SAFE
WHAT: —
LOST: —

### 403
VERDICT: MINOR
WHAT: The same original as 392 (with its re-aiming label), said again a second time in the same file under a different title. Changed: the review's "4.1's", "4.3's" and "5.10's" (the prior v348) are now "at 3.1", "at 3.5" and "at 3.2" of the living v379; the three quotations are exact and at those sections, so the new numbers are right for the file now, but the prior's numbers are gone. Added: that the living file has the three. Kept: item 10 of the review's 2.3, lost at the proposal, minor; 114, 120 and 126.
LOST: —

### 404
VERDICT: SAFE
WHAT: —
LOST: —

### 405
VERDICT: SAFE
WHAT: —
LOST: —

### 406
VERDICT: MINOR
WHAT: Lost: "for the reviewer's brief at the kit", which stood inside the re-aiming label and said what the paragraph was for. The 54 items, the *v314* routing notes, the writer catches, and the carrying for a value and the archive for a record are kept.
LOST: —

### 407
VERDICT: MINOR
WHAT: Changed: "a saying at 7.7 yet computed" is now "A saying is offered at Exhibit THREE Natural Numbers' 7.7 … It is at no sentence of 7.7, and it is computed at no place." The denial "at no sentence of 7.7" is new; it is true of the living v380L (7.7 has no "one tunneling"; `carryings/v380L/Gathered_Value_4.md` says the saying was entered at that section and taken out again). Lost: the label "closing account". The saying, the two primes, and the waiting on the crossings computed before it is said are kept.
LOST: —

### 408
VERDICT: SAFE
WHAT: —
LOST: —

### 409
VERDICT: SAFE
WHAT: —
LOST: —

### 410
VERDICT: HARM
WHAT: Lost: the standing the map gave the sentence, "OPEN — 184 Unsure" (the map's standing OPEN, which its key gives as resting only on a step carrying an unsure line, with step 184 named), and the row "Table B row G2". The new paragraph says instead "It rests at … step 311 … and step 310", with no open and no unsure. Changed: "Steps 185; 184" are now 311 and 310; I compared the registry of commit 8e24fa8 (steps 184 and 185) with the living v380L (310 and 311): the two steps' texts are the same, so the numbers are right for the file now. What I found beside it: at commit 8e24fa8 step 184 had the line "Unsure: the scientific method named a method beside the one method …"; the living step 310 has an adding line and no unsure line. So the standing that is gone was true of the registry the map read and is not true of the living registry; the new paragraph still reports what the map of v376 has (explored steps 3 to 6, entering 1 to 8) and leaves the map's standing out. Kept: explored steps 3 to 6; entering 1 to 8; *membrane* an old word. The four quoted strings are exact (Living Ghost Registry 1.1; steps 311 and 310).
LOST: Steps 185; 184; OPEN — 184 Unsure;

### 411
VERDICT: SAFE
WHAT: —
LOST: —

### 412
VERDICT: SAFE
WHAT: —
LOST: —

### 413
VERDICT: SAFE
WHAT: —
LOST: —

### 414
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|---|
| RESAID | 29 | 14 | 0 | 3 | 0 | 46 |
| RELEASED | 0 | 0 | 0 | 0 | 0 | 0 |

HARM: 373, 399, 410.
PERSON'S WORDS: none.
MINOR: 370, 377, 378, 379, 381, 383, 390, 391, 392, 393, 398, 403, 406, 407.

## READING

**What I did for every item.**
- Laid AS IT WAS beside AS IT IS NOW clause by clause: each number, section, named file, list member, condition and negation.
- Confirmed the new paragraph is in the named file in `carry/` now. 44 of 46 are there word for word as the sample has them. 387 differs in the name used for the three files ("These offerings' concern 7" where the sample has "This mate's concern 7"); 404 has *standing* in italics. Each new paragraph in the file ends "— v386EOD", which the sample does not show.
- Confirmed each AS IT WAS is word for word in `archive/carrying_v386EOD/…_before_resolving.md` and is no longer in the file now (46 of 46).
- Quotations: 17 of the 46 items have sentences in double quotation marks (46 quoted strings). I ran one exact-string search of all of them against the living `*.md` files at the repository root: each is there, none misquoted. For each I also read which section it is at; every section the new paragraphs name is right (among them Natural Physics 2.3, 2.4, 3.1, 3.2, 3.5, 5.11; Natural Naming 3.2, 4.6, 4.9; Natural Intelligence 1.4, 2.2, 4.7, 4.10; Geodesic Improving Method 2.6, 4.2; Living File Registry 3.3; Equilibria Registry 1.2; Natural Exploring 4.6, 7.3; registry steps 310, 311, 538).
- Where a new paragraph changed a number or added content, I opened the source the original names: the review and the report of the proposed Natural Physics v377, `cover_REGISTRIES.md` and `cover_EQUILIBRIA.md`, the session reports of v377 and v381F with `Loopings.tsv`, the re-settling draft of v373, the v368 carry set README, the v381R transcript, the v380L gathered value, and the registry at commit 8e24fa8.

**How I drew the lines.**
- SAFE includes a paragraph that only unfolds the original's own citation: a file's whole name, a path, the heading of the cited section, "Possible project … It may change or never be made" for a plan or a line of the re-settling draft (a first draft, so the strength is the same).
- MINOR includes a locator changed to follow the living file where I confirmed the new one (390, 392, 393, 403), a locator or provenance phrase dropped with the claim it located whole (370, 378, 379, 381, 406), a status label dropped (383), content added from the living file or the cited source that agrees with it (370, 379, 383, 391, 407), and a word replaced inside reported content (377, 398).
- HARM is a whole sentence or a standing of the original that has no counterpart in the new paragraph. All three are of one kind: the thing lost was true when written and the living files have since moved (Natural Intelligence has no 8.7; step 310 has no unsure line). I graded them HARM because the paragraph no longer says them and no record for these three paragraphs says they were let go; a reader who counts a standing overtaken by the living file as MINOR would re-grade all three to MINOR. 373 and 399 are one paragraph at two files, so the three HARM are two distinct losses.

**PERSON'S WORDS.** None in this sample. The nearest is 378: a quoted question turned into unattributed statements, with its line numbers and date gone. The quoted words there are the session's own (transcript line 479), and what the person did is kept with attribution, so I graded it MINOR. If attribution to a session is to count as it does for the person, 378 is the item to re-grade. In 407 the saying is the person's by `carryings/v380L/Gathered_Value_4.md` ("2856, person"), but neither the original paragraph nor the new one says so, and the saying itself is kept.

**Things true of the whole sample, not graded per item.**
- The original closing tags (review_natural_physics_v377, natural_physics_v377, session_v377, session_v378, resettling_v373, v368_sources, co_chaining_map_v376, v377 to v383Op) and the report citations in parentheses are gone from every item. In the Natural Physics items the source is named inside the new paragraph; in others (for example 372, 374, 394, 395, 396, 397, 400, 409, 412) no source is named. The task says a report name is not a claim, so I did not grade this.
- The labels "A plan, not yet final, gathered here at v381R", "re-aimed from … at v381R" and "Concern, at v37x" are dropped throughout; I treated them as session labels.
- Several new paragraphs are word for word at more than one file of `carry/` (373/399 at three, 382 at nine, 394 at twelve, 395 and 397 and 400 at four, 396 at three, 379 at two).

**Not done.** I did not re-verify claims that are the same in both versions (for example the word counts in 369, the likeness numbers in 386, the 1,205 places in 397, the commits in 393) against anything but the source each names where I opened it. I did not check whether the three HARM losses are recorded in some other artifact beyond a search of `carry/` and of `incoming/v386EOD/Session_Record_v386EOD.md` for "8.7", "sentence paragraph" and "Unsure".
