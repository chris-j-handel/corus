# B11 report: third reading of 43 older paragraphs said again (items 461 to 503)

All 43 items are KIND: RESAID. Items 474 to 503 are from `carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md`.
Each AS IT IS NOW paragraph was found whole, character for character, in the file named for it under /home/claude/corus/carry/.

### 461
VERDICT: MINOR
WHAT: The place the proposed file was brought to is changed from `incoming/natural_physics_v377/…_proposed.md` to `carryings/natural_physics_v377/…_proposed.md`. I checked: the file is at the `carryings/` path now and no `incoming/natural_physics_v377` exists. "against the prior at v348's forty sections and 20,973 words" is now "Natural Physics at version 348 has forty sections and 20,973 words": the word "prior" and the comparing "against" are not said. Branch, pull request 106, e85b7c0, five parts, forty-nine sections, 19,824 words and the five part names are all there.
LOST: —

### 462
VERDICT: SAFE
WHAT: —
LOST: —

### 463
VERDICT: SAFE
WHAT: —
LOST: —

### 464
VERDICT: SAFE
WHAT: —
LOST: —

### 465
VERDICT: SAFE
WHAT: —
LOST: —

### 466
VERDICT: MINOR
WHAT: The standing "Ready, at v379" is not said; the paragraph is now a possible project ending "It may change or never be made." "waits on the references … at Natural Illustrating" is now "Each was said from no reference read, and each enters with its reference", with Natural Illustrating named for Huygens' clocks alone. Added: which reference is beside which observing, and "a flow lifting grains from its bed". Huygens' clocks, the field's entrainment at sediment, "each reference first" are all there.
LOST: —

### 467
VERDICT: SAFE
WHAT: —
LOST: —

### 468
VERDICT: MINOR
WHAT: The finding is in the present tense in AS IT WAS ("is restated in nearly every file") and is now dated and past ("At version 373 the common method was restated"). The core coupling sentence gains the word "itself" at its end, which is how the four living files have it. Every count (5% to 55%, four files, five files), every file name and section (7.2, 1.1, 1.1, 1.1, 4.1, 2.1) is there.
LOST: —

### 469
VERDICT: MINOR
WHAT: A named place is changed. AS IT WAS: "Natural Intelligence 6.6 already carries the cube at its own reaching". AS IT IS NOW: "Natural Mathematics 3.6 has the cube at its own reaching", with a quoted sentence. I checked: `Natural_Intelligence_v380R.md` has no cube now, and `Exhibit_FOUR_Natural_Mathematics_v380L.md` has the quoted sentence inside its 3.6. So the new place is true now and the old place is no longer said. Also "the turns" is now "the cube's moves". Three books, the threes and twos, one twelfth, "never four", "beside it as a field instance and not beneath it as a proof" are all there.
LOST: —

### 470
VERDICT: SAFE
WHAT: —
LOST: —

### 471
VERDICT: SAFE
WHAT: —
LOST: —

### 472
VERDICT: MINOR
WHAT: The three step numbers are changed: step 68 to step 80, step 69 to step 81 (twice), step 65 to step 76, and the steps are now said to be Exhibit THIRTY Co-Chaining Logic Registry's. I checked `Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md`: its steps 80, 81 and 76 say the going into 4, the self's stepping 1, 3, 5, 7 with the other's 2, 4, 6, 8, and the podal nine less; its steps 68, 69 and 65 now say other things. "The lead suggested 6 and 5 are coming down to 4" is now "A suggestion of the expedition's self has 6 and 5 coming down to 4": whose it is, is still said; the word "are" is gone. The name of the report and its section 3.3 are not said.
LOST: —

### 473
VERDICT: SAFE
WHAT: —
LOST: —

### 474
VERDICT: MINOR
WHAT: A change of standing, not of content. AS IT WAS is a "Correcting droplet" in the imperative: "Re-say not-self as other wherever the actual relation calls for that correcting." AS IT IS NOW is a "Possible project" that ends "It may change or never be made." The correcting itself and its condition are whole ("at each place of a living file the relation itself asks for that correcting, and at no other place"). Added: that Natural Resolver has no *not-self* (I checked: none), and three living files that have the earlier word.
LOST: —

### 475
VERDICT: MINOR
WHAT: "Their actual relation remains to explain at Natural Resolver" is now "The relation of the three rectangles to the podals is said at no living file": Natural Resolver is no longer said as the place of the explaining. "Their earlier naming as an open part supplies no completed local resolving" is not said in its own words; a sentence of Natural Illustrating naming them open is quoted in its place. "Concern from session v378" is now "Droplet", with no session named.
LOST: —

### 476
VERDICT: SAFE
WHAT: —
LOST: —

### 477
VERDICT: SAFE
WHAT: —
LOST: —

### 478
VERDICT: HARM
WHAT: The paragraph had two things and now has one. The first, the table of each name whole with its two sayings (each row carries each relation, or a table of columns and shorter rows), is not in AS IT IS NOW. Only the last clause, the prefix column, is said again, as the two columns of *Twelve forms*. I did not find the lost clause elsewhere in `carry/`: a later-kept paragraph of the same section (v380h) and a section of Possibling of Natural Resolver speak of a column arrangement, but neither has "each row carries each relation" beside "shorter rows". The living file's table "Each name and its relations" is at rows of relation now. "Concern" is now "Droplet".
LOST: the table of each name whole, its rows carried again — each row carries each relation, or a table of columns and shorter rows

### 479
VERDICT: SAFE
WHAT: —
LOST: —

### 480
VERDICT: SAFE
WHAT: —
LOST: —

### 481
VERDICT: SAFE
WHAT: —
LOST: —

### 482
VERDICT: MINOR
WHAT: Nothing is lost. What the concern decides is widened: AS IT WAS has "the entry's row and the next prior at three rows"; AS IT IS NOW adds "the second of the five dimensions and the windings". Both added things are in the fuller earlier form of this concern at `archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md`.
LOST: —

### 483
VERDICT: MINOR
WHAT: "each form said once as a master pattern" is now "each form can be said once by that, as one pattern for matching": the word "master" is gone. "waits on" the four places is now "Four places part": that the saying waits on them is not said. The four places (now at 3 or 12, the possible at two names, three betweens, a carrying at 8 and 16) are all there. "Concern" is now "Droplet".
LOST: —

### 484
VERDICT: MINOR
WHAT: The concern's own name, "co arriving and carrying, tri releasing, bi the between", is said in the living table's words: co "received", tri "given on". "carrying" is not said of co, and "bi the between" is now inside the first of the two sayings ("with each even name the between") and not ahead of both. The two sayings of tri are both there.
LOST: —

### 485
VERDICT: MINOR
WHAT: "three workings combined at one going" is now "Three sayings are offered as of one relation". "five places not yet said at one" is now "Five places part". AS IT WAS says the six-forward comparison "is separate from this unresolved relation"; AS IT IS NOW counts chaining six forward as the fifth of the five places and calls it "a possible project apart". The link to Possibling of Co-Chaining Logic Registry is kept. "Concern" is now "Droplet".
LOST: —

### 486
VERDICT: SAFE
WHAT: —
LOST: —

### 487
VERDICT: SAFE
WHAT: —
LOST: —

### 488
VERDICT: SAFE
WHAT: —
LOST: —

### 489
VERDICT: SAFE
WHAT: —
LOST: —

### 490
VERDICT: SAFE
WHAT: —
LOST: —

### 491
VERDICT: SAFE
WHAT: —
LOST: —

### 492
VERDICT: SAFE
WHAT: —
LOST: —

### 493
VERDICT: SAFE
WHAT: —
LOST: —

### 494
VERDICT: MINOR
WHAT: The second sentence of AS IT WAS, a pointer, is gone: "The separate three-row comparison is in Possibling of Natural Resolver" with its link. That section is still in `carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md` ("The three proposed torus row comparisons · v385A"); only the pointing to it is gone. "remains to explain" is now a possible project ending "It may change or never be made." The row released at each name, with each name's across or along at the table that was numbered 3 (the seventeen names, whose column is now quoted), is there.
LOST: —

### 495
VERDICT: MINOR
WHAT: Half of the paragraph is not in AS IT IS NOW: "the rows of 1 and 8" and "1 and 8 across or along at 4 beside 3". It is not lost from the file: a later section of the same file has it whole, "Concern · One and eight across and along at one file" (in the section "Co-momentarying at 9 and at 3; … · v386EOD"). The other half, the next prior at 9, 11 and 15 beside bi-tri-bi and bi-co-bi, is all there. "Concern" is now "Droplet".
LOST: —

### 496
VERDICT: SAFE
WHAT: —
LOST: —

### 497
VERDICT: HARM
WHAT: Two sentences are gone and the person's words are no longer the person's. (1) "One more from that archive, entry 76: the parting at even spirals is withdrawn, and the entry yet laying it as one parting new is read with that." is in no part of AS IT IS NOW, and I found "even spirals" in no file of `carry/`. (2) The pointer "Its entry as it was is at `archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md`, entry 41" is gone. (3) AS IT WAS quotes in italics "The session's saying *the intelligence is in the co-chaining of releasings and bi-tunneling of arrivings*"; the archive entry 41 has it as what "The session said". AS IT IS NOW has "One saying has the intelligence in the co-chaining of releasings and the bi-tunneling of arrivings": the words are there, not marked as quoted, and whose they are is not said. The names 11 and 10 at tri and bi, and 9 and 17 said *along* at the resolver's list, are there. "Concern" is now "Droplet".
LOST: One more from that archive, entry 76: the parting at even spirals is withdrawn, and the entry yet laying it as one parting new is read with that. Also: Its entry as it was is at `archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md`, entry 41. Also the attribution "The session's saying".

### 498
VERDICT: HARM
WHAT: Of the things written two ways, two are gone and a number is gone. Gone: "a dash none released at one table and no partner at another"; "*hand at the names* at two forms"; the number "eleven tables" (two tables are named now, Ten roots and Fives, with no count); and "with the working v380L's finding beside it". Changed: "a released 0 *is not* at one table and 0 at three" is now *is not* at two tables and 0 at five tables named one by one; I checked that the living file now has "*is not*: 0 shared" at those two tables. The living file now has no "hand at the names", and its one use of a dash is "A dash: no partner among the twelve"; AS IT IS NOW does not say that these two were mended, it only leaves them out. The torus at a carrying of none, its two rows, and q one more than four times p are there. Added: "a construction at its own condition, classifying no living by its number".
LOST: a dash none released at one table and no partner at another; *hand at the names* at two forms. Also "at eleven tables". Also "with the working v380L's finding beside it". Also the counts in "a released 0 *is not* at one table and 0 at three".

### 499
VERDICT: MINOR
WHAT: Who the concern is for, "for both and for Natural Naming's conferring", is not said. "*odd, co*, the self's prefix" is now the living cell "odd, opening co, the self's span again, the next 1". Two of the twelve namings are said by the living file's present labels: "the self's three faces" is now "the self as three", "parity's face" is now "parity's unit square". All twelve are there, and "One move" at 2, 4, 6 and 8 beside the table at 1 to 4. "Concern" is now "Droplet".
LOST: —

### 500
VERDICT: MINOR
WHAT: "the inward face is that concern, met next" is now "no line has a sharing as a self inward": that it is to be met next is not said, and "concern" is now "asking". The two code names are said as the names now (`_17_social_self_offering` as 17-co-bi-tri-offering, `_9` as 9-tri-bi-co-momentarying, 4-other-self-sharing as 4-bi-co-bi-sharing). "a carrying entry is itself a carrying" is now "each sharing of a carrying itself a carrying". "the next scale" is now "the next scale outward". Added: a cell of the living table "Each name, three scales" for 4 inward. The quoted first concern is the v372 record's own, not the person's (I read it at `carry/Session_Record.md` and at `carryings/resettling_v373/Exhibit_ONE_at_its_Stable_Forms.md`).
LOST: —

### 501
VERDICT: HARM
WHAT: AS IT WAS has four things that still reach; AS IT IS NOW has two of them. Gone: the co and bi spelling of each full name by front addition with the whole seventeen shown; and the label's one relation word putting 5 to 12 at other and 13 to 17 at social. I found neither in any file of `carry/` ("front addition" is in none). Of the two kept: "one station at its two turns" is now "one place of a podaling at its going out and its coming again"; "with no contact added" is now "a number beside a number giving no coupling", which is not the same saying; "carries at depth two or three" is now "at two prefixes or at three".
LOST: the co and bi spelling of each full name, by front addition, with the whole seventeen shown. Also: the label's one relation word puts 5 to 12 at other and 13 to 17 at social, the position parts them, and the full ordered prefix travels beside it. Changed: "with no contact added"; "at depth two or three".

### 502
VERDICT: MINOR
WHAT: The pointer to Carryings of Natural Resolver is gone: "The [earlier reported pairs and rule checks] preserve their particular counts and conditions". That section is still in `carry/Exhibit_ONE_Carryings_of_Natural_Resolver.md` ("Reported code comparisons from session v383Op · v385A"). The proposed relation, steps 655 and 656, "said of the whole pattern at once", and "not established by those counts alone" (now "an executing's numbers alone give no deriving") are there. Added: the conditions on p and q and the first momentaries 3p − 1 and 3p − 3, which the carryings section and the two steps have.
LOST: —

### 503
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

All 43 items are KIND: RESAID. There are no RELEASED items in this sample.

| Verdict | RESAID | RELEASED |
|---|---|---|
| SAFE | 23 | 0 |
| MINOR | 16 | 0 |
| PERSON'S WORDS | 0 | 0 |
| HARM | 4 | 0 |
| COULD NOT CHECK | 0 | 0 |

- SAFE: 462, 463, 464, 465, 467, 470, 471, 473, 476, 477, 479, 480, 481, 486, 487, 488, 489, 490, 491, 492, 493, 496, 503
- MINOR: 461, 466, 468, 469, 472, 474, 475, 482, 483, 484, 485, 494, 495, 499, 500, 502
- HARM: 478, 497, 498, 501
- PERSON'S WORDS alone: none. Item 497 has the person's words losing their attribution as well as two sentences lost, so it is HARM by the task's rule.

## READING

**What I did.** I laid each AS IT WAS beside its AS IT IS NOW clause by clause. For the thirty items of Offerings to Natural Resolver I also read the section as it was at commit a81ea75 (the commit ahead of the session) and the fuller earlier form of the same concerns at `archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md`, because most of those AS IT WAS lines are one-line shortenings of longer concerns. I read the sources for the other thirteen at `carryings/` (the review and the report of Natural Physics v377, the resettling of v373, the reports of sessions v377 and v378, the two kits of v368). I edited nothing in the repository.

**Where each new paragraph is.** Each of the 43 is whole in its file under `carry/` now.

**Quotations.** The task asks for quotations in at most two items in three. One mechanical search ran over every double-quoted string of all 43 items against the `*.md` files at the repository root: every one is found as written. That search proves little for the very short ones ("0", "Root", "Names", "Side", "Fives", "9 less"). By hand I checked the place named for the quotation, the row, step or section, at twelve items: 469, 472, 477, 480, 482, 490, 495, 496, 497, 498, 499, 502. Each is at the place the paragraph says.

**The four harms are all one kind.** At 478, 497, 498 and 501 the older paragraph gathered several separate things and the new paragraph says some of them again and leaves the others out, with no word that anything was left out. These are counted by the session as "said again", not as "released", so the session's record of releases (`incoming/v386EOD/Session_Record_v386EOD.md`) gives no reason for them. For each of the four I searched every file of `carry/` for words of the lost clause ("shorter rows", "even spirals", "hand at the names", "eleven tables", "front addition", "relation word") and found none; at 478 two other places speak of a column arrangement without the lost clause's two sayings. The older paragraphs are whole at `archive/carrying_v386EOD/Exhibit_ONE_Offerings_to_Natural_Resolver_before_resolving.md`.

**One item is near that kind and I gave it MINOR.** At 495 half of the paragraph is left out, and I found that half whole at a later section of the same file. If the rule is that a claim absent from the paragraph is HARM wherever else it is, 495 is HARM.

**One item changes a standing.** At 474 an instruction to correct ("Re-say not-self as other…") is now a possible project that "may change or never be made". No relation, condition or number is lost, so I gave MINOR; a reader holding to "at the same strength" could give HARM.

**Places and numbers brought to now.** At 461, 469 and 472 a path, a file and section, and three step numbers are changed to where the thing is now. I checked each new place and each is right. The old place is not said beside the new one, so the record of where it was is gone from the paragraph.

**Pointers.** At 494 and 502 a link to another file in `carry/` is gone; the section pointed at still exists. At 485 and 503 the pointer is kept.

**Concern said as Droplet.** Seventeen of the thirty Natural Resolver items opened with "Concern" and now open with "Droplet" (475, 478, 479, 483, 485, 486, 487, 489, 490, 491, 492, 493, 495, 496, 497, 499, 500). The session keeps "Concern" for the items it can say as "Two sayings part" between sentences of living files. In each of these the open thing is still said as open ("said at no file", "followed at no file", "Either … or …"). I did not count the change of the word as a loss, and I name it here because it is a change of kind at many paragraphs.

**Additions.** Almost every new Natural Resolver paragraph is far longer than its AS IT WAS. The added matter is of two sorts: quoted cells of the living file, and detail from the fuller earlier concerns. Where I compared added detail with the fuller earlier concern (477, 479, 482, 484, 485, 487, 489, 490, 495) it agrees with it. At 476 one added word differs: the fuller earlier concern has "a join carried forty-five degrees a facing" and the new paragraph has "a sharing carried forty-five degrees a facing"; this clause is not in AS IT WAS, so it does not change the verdict. I did not check every added sentence. Four stated absences I did check in `Exhibit_ONE_Natural_Resolver_v380R.md`: no *not-self*, no golden rectangle, no *bi-co-podaling*, no *bi-co-momentary*: each holds.

**The person's words.** Only 472 and 497 have, in AS IT WAS itself, a saying marked as the person's. At 472 whose it is, is kept. At 497 it is not. The fuller earlier concerns show that several other AS IT WAS lines carry the person's phrases unmarked (at 479, 483, 484, 486, 487, 489); AS IT WAS itself neither quotes nor attributes them, so I gave no PERSON'S WORDS verdict there. The new paragraphs say these as "offered" or "one saying", with no one named.

**Not checked.** Whether the two things left out at 498 (the dash, *hand at the names*) were left out because the living file was mended: the living file has no "hand at the names" now, and I did not follow the dash through each table. At 502 the added words "a torus of two odd numbers" I did not find in the carryings section I read.
