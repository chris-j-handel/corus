# R01 report: third reading of 35 released paragraphs (R01_sample.txt)

All 35 items are KIND: RELEASED (10 SAID, 20 RESOLVED, 5 NOVALUE). The files were read as they are now at commit e71034d; the text before the session was read with `git show a81ea75:…` (the last commit before v386EOD).

### 1
VERDICT: SAFE
WHAT: —
LOST: —

### 2
VERDICT: SAFE
WHAT: —
LOST: —

### 3
VERDICT: SAFE
WHAT: —
LOST: —

### 4
VERDICT: SAFE
WHAT: —
LOST: —

### 5
VERDICT: SAFE
WHAT: —
LOST: —

### 6
VERDICT: SAFE
WHAT: —
LOST: —

### 7
VERDICT: SAFE
WHAT: —
LOST: —

### 8
VERDICT: PERSON'S WORDS
WHAT: The paragraph says the reading at Natural Intelligence 4.10 is of "the lead's words on natural intelligence in the between", "read, as suggested". It does not quote the lead's words; it says they are the lead's. The work it asks is done: 4.10 has "a nothing and no location, existing as the universe exists, as its things exist" and "no existing thing" is at no line of 4.10. But 4.10 does not say the reading came from the lead, and no paragraph of carry/Offerings_to_Natural_Intelligence.md says it now. What is still in carry/: Session_Record.md line 2010 has the words themselves in italics under "Arrived:" (not named as the lead's), and Offerings to Equilibria Registry line 275 has "The between. Read, as suggested: …" and line 271 has part of the same saying as "the lead's words".
LOST: —

### 9
VERDICT: SAFE
WHAT: —
LOST: —

### 10
VERDICT: SAFE
WHAT: —
LOST: —

### 11
VERDICT: SAFE
WHAT: —
LOST: —

### 12
VERDICT: HARM
WHAT: The reason shows that the names in the paragraph are gone (Part Eleven, the old steps 9 and 21, F41 and F67 as roots, Part 7). It does not show the concern answered. The Registry still has seventeen unsure lines, so it still has open steps. The two droplets the reason points to ("The chain from the origin sentence", "Six places at the file's own form") are about Natural Intelligence's own sentences, not about whether Natural Intelligence needs a Registry step that is open. Kept in the mate: "a step open is said open" (line 141) and "the open steps said open" with "that Registry's Part Eleven" (line 143). Not kept at any place in carry/*.md or the living files: the question whether a step the white paper needs waits on an open one, and that F41 and F67 were carried as open roots. Both copies of the paragraph that the mate had before the session (lines 153 and 191 then) are gone; the text is whole in archive/carrying_v386EOD/Offerings_to_Natural_Intelligence_before_resolving.md and in carryings/resettling_v373/Re-Settling_the_Living_Files.md line 289.
LOST: "the carrying carries F41 and F67 as open roots" and "whether any step the white paper needs waits on one of them is met at Part 7's writing."

### 13
VERDICT: SAFE
WHAT: —
LOST: —

### 14
VERDICT: SAFE
WHAT: —
LOST: —

### 15
VERDICT: SAFE
WHAT: —
LOST: —

### 16
VERDICT: MINOR
WHAT: The three improvings are whole in the later section ("generosity, curiosity and gratitude … cheaper, faster and better … The three are the moral spiral"). But the reason says that section "opens with its source 'its released Natural Intelligence, its map'". That opening sentence is not in the file now: commit 36cfd58 removed it after the release (it is there at 6911ea1 and e021b16). So the later section no longer says the passage came from Natural Intelligence. That it did is still said once in carry/, at Session_Record.md line 1643 under "Exhibit TWENTY-THREE Natural Values" ("Incoming, at v373, from Natural Intelligence … the moral spiral's three improvings").
LOST: —

### 17
VERDICT: SAFE
WHAT: —
LOST: —

### 18
VERDICT: SAFE
WHAT: —
LOST: —

### 19
VERDICT: SAFE
WHAT: —
LOST: —

### 20
VERDICT: SAFE
WHAT: —
LOST: —

### 21
VERDICT: SAFE
WHAT: —
LOST: —

### 22
VERDICT: SAFE
WHAT: —
LOST: —

### 23
VERDICT: SAFE
WHAT: —
LOST: —

### 24
VERDICT: SAFE
WHAT: —
LOST: —

### 25
VERDICT: SAFE
WHAT: —
LOST: —

### 26
VERDICT: MINOR
WHAT: The content is in the later droplet ("The ambient is the transmissioning."). But the reason says the section "says each is from the resettling of version 373, 'its released Natural Intelligence, its map'". That sentence is not in the file now (removed by commit 36cfd58; present at 6911ea1). So "receives from Natural Intelligence" is said at no place in carry/*.md now: Session_Record.md has no such line under "Exhibit SIX Natural Transmissioning", and both copies of the paragraph (with and without the re-aiming note) are released. The relation stays only in the source, carryings/resettling_v373/Natural_Intelligence_Map.md line 169 and Natural_Intelligence_v373_Released.md line 548. The same kind of paragraph was kept at other mates (Natural Physics lines 444 and 530, Natural Numbers line 103, Geodesic Improving Method line 267, Natural Networking lines 129 and 221).
LOST: —

### 27
VERDICT: SAFE
WHAT: —
LOST: —

### 28
VERDICT: SAFE
WHAT: —
LOST: —

### 29
VERDICT: SAFE
WHAT: —
LOST: —

### 30
VERDICT: MINOR
WHAT: The six words of the passage are whole in the later droplet. Not said there or anywhere in the mate now: "2.6" and "near" (the old section number and the map's sort of the passage), and that the passage is Natural Intelligence's. The reason relies on the section's opening ("from the resettling of version 373, its released Natural Intelligence, its map and Exhibit ONE at its stable forms"), which commit 36cfd58 removed after the release. Session_Record.md line 1643 still says the three improvings came to Natural Values from Natural Intelligence.
LOST: —

### 31
VERDICT: MINOR
WHAT: The paragraph has Destinies and Emanating together going "into Corus, Natural Naming and Natural Explaining". The living Registry 1.5 names Naming and Explaining for Natural Emanating only ("concepts toward Naming, craft toward Explaining"); for Natural Destinies it has "Corus and the relevant subject exhibits", and its 5.11 names Naming but not Explaining. So Natural Explaining as a receiving file of Natural Destinies is not said now. The reason states this narrowing itself. "pass G" for both files is at 1.1.
LOST: —

### 32
VERDICT: SAFE
WHAT: —
LOST: —

### 33
VERDICT: SAFE
WHAT: —
LOST: —

### 34
VERDICT: SAFE
WHAT: —
LOST: —

### 35
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|---|
| RELEASED:SAID | 7 | 3 | 0 | 0 | 0 | 10 |
| RELEASED:RESOLVED | 17 | 1 | 1 | 1 | 0 | 20 |
| RELEASED:NOVALUE | 5 | 0 | 0 | 0 | 0 | 5 |
| RESAID | 0 | 0 | 0 | 0 | 0 | 0 |
| All | 29 | 4 | 1 | 1 | 0 | 35 |

HARM: 12. PERSON'S WORDS: 8. MINOR: 16, 26, 30, 31.

## READING

What I did.
- For each item I opened the place the reason names and laid the paragraph beside it claim by claim.
- Word for word (compared by script, less the re-aiming note and the closing tag): item 1 at Offerings to Natural Resolver line 207; items 6, 29 and 35 at Offerings to Co-Chaining Logic Registry line 61 under its heading at line 59; item 19 at Possibling of Living File Registry line 223; item 21 at the same file line 191; item 34 at Possibling of Natural Networking line 17. All identical.
- Quotations of living files checked with Grep in 18 items (2, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 20, 25, 27, 28, 31, 32, 33). Every quotation I checked is exact at the file and the section or step the reason names. I did not check the quotations in item 4 beyond the headings and "Natural intelligence is that co-competencing", nor those in item 24 beyond the search for the old names.
- For the rows of the co-chaining map (15, 18, 20, 25, 28) I read the row in carryings/co_chaining_map_v376/ and the steps of Exhibit THIRTY v380L the reason names (2, 3, 43, 47, 88, 122, 187, 257, 310, 312, 314, 347, 521, 602). None of them has an unsure line. The file has seventeen unsure lines, all at other steps.
- For each item I searched carry/*.md now for the paragraph's own text. Results worth knowing are below.

The one finding that touches more than one item.
- Items 16, 26 and 30 were released because a later v386EOD section says them, and each reason quotes that section's opening sentence naming its source ("Each is from the resettling of version 373, its released Natural Intelligence, its map …"). A later commit of the same session, 36cfd58 ("the session's own telling taken out of the carrying"), removed that opening sentence from both sections. The droplets are still there; the sentence that carried the origin is not. So the reasons describe a state of the files that no longer holds. I gave MINOR, following the earlier readers' line that a lost "received from …" is minor. If the file a passage came from counts as a relation, 26 is HARM (LOST: "receives from Natural Intelligence"), since nothing in carry/ says it now; 16 and 30 are covered by Session_Record.md line 1643.

How I drew the lines.
- Item 12 is HARM because a question that still has an object was removed on the ground that its numbering is old. If a concern counts as resolved once the particular steps it names no longer exist, it is SAFE. I could not establish that the old open steps and roots were closed; the reason shows only that their names are gone.
- Item 8 is PERSON'S WORDS under the rule "says the person said … a thing". The paragraph quotes no words of the person; it names them as the lead's. If the verdict is meant only for quoted words, item 8 is SAFE.
- Item 10 has the person's unpunctuated words ("the man is in the river …"). They are whole in the living Equilibria Registry 2.2, in italics after "Suggested at v377:". The paragraph itself said "as suggested" and did not name the lead, so nothing of the attribution is weaker. SAFE. The exact words are in no file of carry/ now (Session_Record.md line 2012 has them in paraphrase); they are in the living file.
- A paragraph released as resolved or bookkeeping while a twin of it stays is SAFE: item 4 (same text still at Offerings to Natural Intelligence line 175 and Offerings to Natural Intelligence Corus line 85), item 9 (line 149 of the same mate still has "nothing leaves Natural Intelligence before it is carried near", and the living Registry 5.3 has "A passage crossing into another file arrives whole before its prior wording releases"), item 27 (the same row is now "Possible project · Exhibit ONE's *Returning and releasing; The code at its names* explaining" at line 117 of the mate, with all four things named).
- Section and step numbers that the living file has since renumbered (item 10: steps 125, 126, 284 are 135, 136, 390 now; item 18; item 20) are not counted as lost.

Other things seen.
- Item 15: the Registry now names exclusivity at step 88 as "One side's momentaries alone, each number one side's". No step says in those words that the universe named as one thing beside its things is exclusivity (the map's proposed S2); that tie is at the Equilibria Registry's own 1.1. Step 2's unsure line is gone and steps 3 and 47 say the rest, so I gave SAFE.
- Item 7: "read at four readings apart" is said in no file of carry/ now. It is the subtitle of carryings/review_natural_physics_v377/README.md. I counted the heading as bookkeeping.
- Item 33: "holding" is at 63 lines of the Hard Problem Registry v375, each a plain word in the fields' own text; "ten holdings" is at no line of either file of the pair. The reason's search result ("none") is true of Resolving the Hard Problem Registry only.
- Items 6, 29 and 35: the same paragraph is still, word for word, in three other mates (Resolving Hard Problems line 83, Natural Naming line 384, Natural Intelligence Corus line 361). The Carryings of Living File Registry already named the Co-Chaining Logic Registry mate as the concept's place before the session (line 23 at a81ea75).
- Items 16 and 26 against the kept ones: paragraphs of the form "X receives from Natural Intelligence: …" were released at Natural Values, Natural Transmissioning and Natural Explaining and kept at Natural Physics, Natural Numbers, Geodesic Improving Method and Natural Networking.
- The paragraph numbers in the sample ("paragraph 238 of its older Droplets section") do not match the paragraph order at a81ea75; I found each paragraph by its text.
- Every released paragraph I looked for is in archive/carrying_v386EOD/…_before_resolving.md or in its source under carryings/. I checked this for item 12 only by search; for the others I relied on the source files the reasons name, which I opened for items 2, 5, 7, 10, 11, 12, 15, 16, 18, 20, 22, 25, 26, 28, 30, 31, 33.

What I did not check.
- Whether the original paragraphs were true.
- Whether "no paragraph points at it" holds, except by my own searches for items 12, 15, 17, 18, 20, 25, 28 and 32.
- The site's pages named in the reason of item 7.
