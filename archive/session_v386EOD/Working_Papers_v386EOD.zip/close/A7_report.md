# A7 report: observings, each laid beside its publishing

Source of entries: `A7_sample.txt` (18 entries). Nothing under /home/claude/corus was edited.

## How the pages were read

- Every page was opened with the web fetch tool. That tool hands the page to a small reading model and returns its answers; it would not return passages longer than about 125 characters verbatim. So the quotes below are short pieces the tool returned, and long passages were checked by pointed questions, not by my reading the raw page.
- Where I say something is absent from a page (entries 8 and 14), I asked twice in separate fetches and got the same answer both times. It is still the tool's reading, not a raw-text search.
- Direct download (curl) was refused by the network gateway, so no raw PDF text was read.
- Statements the entries themselves label "as the field's account has it" are not claimed to be on the linked page. I did not count them against the entry; I list them under NOTE so it is plain they were not checked against a publishing.
- Extra addresses that did not open, none of them needed for a verdict: OpenAlex with an author query (rate limited, 429), PubMed search (429), pnas.org (fetch error), thelancet.com (fetch error), biorxiv.org article-info (fetch error).
- I added a NOTE line to some blocks; it is not in the task's format but holds things the three fields have no place for.

---

### 1
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text (the linked teaching copy, PDF)
NOTE: Page gives the field as "roughly 2104.88 gauss" (entry: "near 2105"). 984 turns, 0.020-in. Nb-25% Zr wire, spot welding, NMR, 21 and 37 days, 144,500 ± 16,300 and 119,450 ± 8,700 years, Collins about 250 years, spot-weld resistance, creep with two microinches, Kim-Hempstead-Strnad all found. The closing sentence on Cooper pairs and cuprates is labelled field's account and is not on the page. The entry's remark about the publisher's page was not checked.

### 2
VERDICT: PARTS
WHAT: One wording-level departure. Entry: "about 12 hours in buffer and about 1 hour in serum for one part in two of a single hand to convert". Page: "considerable racemization observed after incubation of enantiomerically pure 1 in buffer solution (τ1/2 = 12 h)" and "as well as in serum (τ1/2 = 1 h)". The page gives a racemization half-life and does not say that half of one hand converts in that time; that reading is the entry's. All else matched: Blaschke 1979 ("In 1979, Blaschke et al. discovered that the enantiomers of 1 display different biological properties"; "only the (S)-enantiomer of 1 is responsible for the teratogenic side effects"), "no teratogenicity was observed for (R)-1 in animal experiments", 20% ee to "up to 98% ee", 62.5 ± 1.6 against 348.9 ± 2.9 and 344.9 ± 3.0 µg/mL, "thalidomide paradox", "we disclose a hypothesis", "(R/S)-heterodimeric form", "removed from biological processes", Scientific Reports 8, 17131, 2018.
REACHED: full text
NOTE: The page also reports enrichment runs in DMSO/water, ethanol and CHCl3/EtOH, beside the water and buffer the entry names. No in-vivo test is reported, as the entry says.

### 3
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text (arXiv PDF) and the arXiv abstract page
NOTE: Found: "On 11 July 2017, at ~22:34 UT", "at a radial distance of 22 Earth radii in the magnetotail", "super-Alfvenic electron jets reaching 20,000 km/s", "accumulated over four 30ms electron DFs", minimum density 0.03 cm-3, rate "~0.1-0.2", "up to three successive times by the reconnection electric field", "despite the presence of turbulence near the reconnection site, the key electron dynamics appears to be largely laminar", "quite similar to those predicted earlier", "we here find more than one crescent", differences "remain to be understood ... such as the energy width of the electron crescents". The Science printing was not opened by me either.

### 4
VERDICT: PARTS
WHAT: One wording-level departure. Entry: "does not depend on the number of cell divisions". Page: "it does not depend on cell division, on time since fertilization or on a counting mechanism involving the sequential modification of DNA". The page says "cell division", not "the number of cell divisions". All else on the page matched: "The Xenopus embryo undergoes 12 rapid synchronous cleavages followed by a period of slower asynchronous divisions", Newport and Kirschner, 1982, Cell 30(3), 675-86.
REACHED: a secondary page (a database page carrying excerpts of the abstract)
NOTE: The Hara, Tydeman and Kirschner citation has no link in the entry. Its title, authors, 1980 and PNAS 77(1) matched a Crossref record (pages 462-466); its own pages were not opened. The statements on the oscillation continuing with no nucleus, the nuclear-to-cytoplasm ratio and the opening of transcription are labelled field's account and are not on the linked page.

### 5
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text
NOTE: Found: 919 and 1114; "Sometime between 1716 and 1735, and again in 1844-1847"; "transplanted stocks of this bamboo in England, Alabama, and Russia"; "a seeding cycle of about 120 years"; "These range from 3 to 120 years; most are between 15 and 60 years"; Chiba 1923 and "all flowered in the 1960s"; Guadua trinii in "optimal conditions of an arboretum and in the dismal conditions of a city park", "in perfect synchrony with each other and their siblings back home 30 years later"; Chusquea abietifolia "taken from Jamaica to England in the 1880s"; both quoted explanations; "probably untestable in most contemporary habitats". The PDF's text layer has scanning errors (for example "barnbusoides").

### 6
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: abstract only (Du Toit and colleagues, in the linked index record); title and citation only (Vatanen and colleagues; the linked record's abstract field is empty)
NOTE: Du Toit: 640, at least 4 and under 11 months, 60 months, 530, 13.7% and 1.9% (P<0.001), 98, 1 to 4 mm, 35.3% and 10.6% (P=0.004), IgG4, NEJM 372, 803-813 all found. Vatanen: title, 2016, Cell 165, 842-853 and the five named authors found. The 222 infants, the three countries, Bacteroides, and the lipopolysaccharide account are labelled field's account and could not be checked on the linked record.

### 7
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: abstract only (an index record)
NOTE: Found: "excised fruits (siliques) of different ages of Arabidopsis thaliana", "in a solidified mineral salt medium supplemented with vitamins, myo-inositol, and 3% sucrose", the three embryo stages, abscisic acid, and the three quoted phrases. The record lists no volume (the entry marks volume 89 as field's account) and its page field is garbled, showing a start page of 766. The record's keywords belong to a different article.

### 8
VERDICT: PARTS
WHAT: (a) Entry: "undated lesson". Page: "Copyright © 2021 University of Waterloo" (twice), and "Written by Martin Laforest and John Donohue". (b) Entry: "is absorbed with probability 1 − cos²θ". Page gives only the passing probability ("the probability of being transmitted is:" cos²θ) and puts the other as a question: "What is the probability that the photon is absorbed by the polarizer?" No absorption formula is stated. (c) Entry: "is never split". Page's words: "light is made up of indivisible "chunks" – photons" and "Photons are indivisible units of light"; the two outcomes are "The photon goes through;" or "The photon is absorbed." The page does not say "never split".
REACHED: full text
NOTE: Matched: Malus' law (I_out = I_in cos²θ; "when we have many photons at the same time, we must get Malus' law back"); the first rule quoted exactly. The second rule on the page reads "The act of measuring the superposition will collapse it and change the state"; the entry's "forces it into one definite state" is a paraphrase (page also has "once it is measured, it is definitely either horizontal or vertical").

### 9
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: a secondary page (an encyclopedia page; a physicist's blog account of Taylor's paper; Taylor's paper not opened)
NOTE: Encyclopedia: Lenard 1902 and intensity, "qualitative rather than quantitative", threshold frequency, linear rise, "less than 10−9 second", Millikan at 1914 in the text with 1914 and 1916 papers in the list, Einstein 1905, "all of the energy from one photon is absorbed ... or none at all" all found. The sentence "doubling the intensity of the light doubled the number of electrons emitted from the surface" sits in the Lenard paragraph without naming him and carries a citation-needed tag. Blog: smoked glass screens, "3 months", the quoted sentence, and Proc. Camb. Phil. Soc. 15 (1909), 114 found. The blog does not say in so many words that the plates summed the light and registered no single arrivals; its words are "each having been exposed to the same amount of total light" and "there were not any detectors sensitive enough to detect individual photons". The blog cites the paper's title as "Interference fringes with weak light" while its own heading says "feeble light".

### 10
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: abstract only (both publishings)
NOTE: Tong: "diploid snowflake yeast ... under selection for larger multicellular size", "within the first 50 days", "persisted for the next 950 days", "nearly 5,000 generations", "in 10 replicate populations", "larger, longer cells that yield larger clusters", Nature 639, 691-699. Oud: haploid, "two independent evolution experiments", "fewer than 500 generations", "a stretch of eight adenosines in ACE2", both ACE2 quotes, "slow-sedimenting cell clusters that consisted of just a few cells", diploid reconstruction found. The linked Oud record carries no author names; the seven authors were confirmed at a Crossref record. The linked record's page field reads first_page "E4223", last_page "31".

### 11
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text (the preprint's version 4 address)
NOTE: Found: "two separate bipolar spindles", "the two genomes remain spatially separate throughout the first mitosis", "became rapidly mixed in the subsequent developmental stages", imaging "from the zygote to the eight-cell stage", "two cell embryos with one or two bi-nucleated blastomeres", "phenocopying frequently observed errors in human embryonic development in IVF clinics". The fetch returned the body without the page header, so title and authors (Reichmann first of ten) were confirmed at a Crossref record; "version 4" rests on the address alone. The opening clause (second polar body, protamines, demethylation, genome opening at two cells and four to eight) is labelled field's account and is not on the page.

### 12
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: abstract only (Bianchi and colleagues, at an index page); full text (Nozawa and colleagues)
NOTE: Bianchi: Folr4 renamed Juno, "Izumo1 is an essential sperm cell-surface protein", "Rapid shedding of Juno from the oolemma after fertilization", "suggests a mechanism for the membrane block to polyspermy", four authors, Nature 508, 483-487. Nozawa: exons 2-14, no spikes on injected heads, "WT 12.0 ± 5.68 spikes ... KO 2.75 ± 0.65 spikes", "delayed ... by ~1 h", "not sterile", "WT 8.9 pups vs. KO 2.3 pups", "WT 7.6% vs. KO 82.4% at 50 × 10^3/ml", "≥3PN; 24/90", "the long-sought sperm-borne oocyte activation factor", "the PMBP plays a more critical role than ZPBP in vivo". The page shows the author list shortened; the five named authors that it shows match.

### 13
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text (Nature paper); abstract only (the follow-up, at a university repository)
NOTE: Nature: Wales, 2 September 1933, 0.01% to 47.2%, 282,541, 7 years, "3.5 percentage points (95% confidence interval (CI) = 0.6–7.1", "20.0% (95% CI = 6.5–33.4)", "stronger among women than men", "natural experiment", the two mechanisms, "suggestive only", Nature 641, 438-446. Follow-up: Xie, Eyting, Bommer, Ahmed, Geldsetzer, 2025, Cell 188, 7049-7064, mild cognitive impairment, deaths due to dementia, and the quoted conclusion found.

### 14
VERDICT: PARTS
WHAT: Entry, in the observation cited to Ettenberg and colleagues: "with nuclear spins 1 for lithium-6 and 3/2 for lithium-7". The Ettenberg paper states no spin values; its only words on it are "The number of neutrons in the atomic nuclei of Li-6 and Li-7 are different and hence so are their nuclear spin properties." The values are in the second linked paper (Zadeh-Haghighi and Simon): "which carry different nuclear spin angular momentum, I_6=1 and I_7=3/2, respectively."
REACHED: full text (both publishings)
NOTE: Matched in Ettenberg: male Sprague-Dawley rats, 2.0 mEq/kg daily in a mash, ketamine 25.0 mg/kg, first trial alike, the quoted fourth-trial sentence (exact, ending "compared to either Li-7 and Li."), mechanism "remains unclear", six authors, volume 190, 172875. The page says "80 adult male Sprague-Dawley rats" with two lost; 78 is what the group sizes add to, I did not get a sentence stating 78. Matched in Zadeh-Haghighi and Simon: "here we propose", flavin semiquinone and superoxide as "the naturally occurring RP", entangled electron spins, recombination, "one potential experimental test of our hypothesis", Scientific Reports 11, 12121.

### 15
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: abstract only (Monden and Smits 2017, in the linked index record); full text (Monden, Pison and Smits 2021)
NOTE: 2017: 90 surveys, 30 countries, 1 685 110 and 56 597, 1995 to 2014, "rate ratio 5·0, 95% CI 4·5-5·6" for neonatal mortality, 213·0 and 63·5 in 2009-14, one-fifth, and the quoted sentence found. 2021: 9.1 to 12.0, the two periods, the six regional rates, the Pison quote, and "also the increasing age at birth has contributed to increased twinning rates in high income countries" found. The entry's "about 1.66 million" is the table's figure (1,663 thousand twin deliveries); the page's running text says "about 1.6 million twin pairs each year". The N-IUSSP summary (ratio 1.7 by twelve months, gone after six years) has no link, the entry says it was not opened, and I did not check it.

### 16
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: a secondary page (four encyclopedia pages; no publishing is named)
NOTE: Found: "providing a new copy of the survival of motor neuron (SMN) gene that produces the SMN protein", AAV9 capsids with an SMN1 transgene, one-time infusion into a vein, "children aged less than two years of age", bi-allelic mutations; islets from a deceased donor's pancreas, infused through the portal vein into the liver, type 1 diabetes; lipid nanoparticles, dendritic cells, translation in the cytoplasm, "do not affect the body's genomic DNA", "within a few days"; "receptor-mediated endocytosis", acid endosomes and release of RNA. The opening list of living things medicine delivers and "about a hundred nanometres" are labelled field's account: the nanoparticle page gives "an average diameter between 10 and 1000 nanometers" and the mRNA vaccine page gives no size. The first page now also describes an intrathecal form for people aged two years and older, which the entry does not mention.

### 17
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: full text
NOTE: The four steps are given on the page as two short code routines (send, recv), not as prose; the order the entry gives is the order of the code. All quoted sentences found exactly, with "(C) 2004 DJG" and the title. The page's text does not name the institution; that comes from the address.

### 18
VERDICT: AS THE PAGE HAS IT
WHAT: -
REACHED: a secondary page (a textbook page, for Borthwick and colleagues 1952; the paper itself not opened); full text (Kok, Forbush and McGloin 1970)
NOTE: Textbook: "they respond only to the final exposure", "If it is red, they germinate; if it is far-red, they remain dormant", the 1952 citation, and both phytochrome sentences found. Kok: spinach chloroplasts, "the yield of the third flash is high and exceeds that of the fourth flash", "The cycle of four", "three to four cycles", four + charges, "The S4+ state produces O2 and returns to the ground state", independent units, "after 10min dark 45 per cent of the traps are in the So state, 55 per cent in the S, state", 5 per cent double hits and 10 per cent misses, Joliot's view that "after long darkness all traps deactivate to the ground state", volume 11, 457-475. Joliot, Barbieri and Chabaud 1969 is in its reference list and was not opened.

---

## SUMMARY

- Entries: 18
- AS THE PAGE HAS IT: 14 (entries 1, 3, 5, 6, 7, 9, 10, 11, 12, 13, 15, 16, 17, 18)
- PARTS: 4 (entries 2, 4, 8, 14)
- NOT OPENED: 0

What the four PARTS are:
- 8: three things. "undated" against a page that carries "Copyright © 2021"; an absorption probability 1 − cos²θ that the page leaves as a question; "never split" where the page says "indivisible".
- 14: lithium nuclear spin values 1 and 3/2 placed with a paper that does not state them; they are in the entry's second linked paper.
- 2: a racemization half-life restated as half of one hand converting, which the page does not say.
- 4: "cell division" on the page became "the number of cell divisions".

No wrong number, name, year, organism or material was found in any of the 18 entries. Entries 2 and 4 are wording-level; 8 and 14 put on a page something that page does not carry.

Limits of this check:
- All reading was through the fetch tool's small model, with short quotes only.
- By level reached: full text for 1, 2, 3, 5, 8, 11, 13 (Nature paper), 14, 17, and for one of the two publishings in 12, 15, 18; abstract only for 6 (Du Toit), 7, 10, and one publishing each in 12, 13, 15; title and citation only for Vatanen in 6; secondary pages for 4, 9, 16 and the Borthwick part of 18.
- Statements labelled "as the field's account has it" (in entries 1, 4, 6, 7, 11, 15, 16) were not checked against any publishing.
- Unlinked citations not opened: Hara 1980 own pages (4), Taylor 1909 (9), N-IUSSP summary (15), Borthwick 1952 and Joliot 1969 (18), Science printings (3, 11).
