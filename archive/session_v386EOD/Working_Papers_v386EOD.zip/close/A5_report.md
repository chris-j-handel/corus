# A5 report: 22 sampled sections, each paragraph laid beside its source

Sample: `A5_sample.txt`, 22 items, 40 bold-titled paragraphs read (item 3 has 21 such paragraphs; the first six were read, as the task says).

How to read the verdicts:
- One verdict for each paragraph. Where only one sentence or clause of a paragraph fails, the paragraph still takes the failing verdict and WHAT says "in part" and names the sentence.
- Every sentence in double quotation marks in the 40 paragraphs (73 quotations) was checked by script as an exact string of a `*.md` file at the repository root. All 73 are exact. No QUOTE WRONG.
- A NOTE line under a FAITHFUL verdict names something a reader of the audit should know that does not change the verdict.
- Paths are under /home/claude/corus/ .

---

### 1.1
TITLE: Droplet · Carrying along at the bi-moral co-agency sentence.
VERDICT: STRONGER
WHAT: The paragraph ends "the sentence carries whole as it is" and says flatly "The sentence says no releasing". The source leaves it open. `carryings/v382F/Session_Report_v382F.md` line 93: "The fresh reader at this session's motion read it as a possible saying of 9's prior word. Read again: the self's own carrying, 3 to 11, is along at an odd name, and the sentence **may be sound as it is; is or is not at the sentence**, outside the eleven." The hedge ("may be", "is or is not") is dropped. The rest (the self's own carrying, 3 to 11, along at an odd name) is in the source.

### 2.1
TITLE: Droplet · A page's instruction: a deciding named, a carrying named.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source is `carryings/v381R/README.md` line 57 ("At the session's standing") and finding 7 (line 49); the push and the open pull request are at `Session_Transcript_v381R.txt` about lines 397 to 425. The source ends "the parting is said as a concern below"; the paragraph is filed as a Droplet.

### 3.1
TITLE: Concern · A molecule sensing, and a non-living thing carrying none.
VERDICT: NOT FOUND
WHAT: In part. The parting itself is not in the source. No file under `carryings/` says that Natural Medicine's "it senses, the side-effecting its sensing" parts from Natural Intelligence's "carrying none of the prior", and none says a molecule "carries no sensing". The nearest passage, `carryings/genome_duplication_v374/Session_Report_v374_Part_Two.md` line 397, words it the other way round for the molecule: "A known shape sent as a probe **is the sensor**, a non-living stable form arriving; the living society is the sensationer". The paragraph's last clause is in the source at the same line: "The shape delivers only shape, so all that follows it is the society's own turning, side effects included." The source does say, of non-living chemical societies (line 299), "The field's *quorum sensing* where no sensing is possible", which is the nearest ground for "carries no sensing", said there of another subject.

### 3.2
TITLE: Droplet · Pharmacology at two explainings.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: Part Two lines 325 to 326. The source has "the receptor is a living self's own membrane"; the paragraph has "a living self's own between". Natural Naming's released-words table maps *membrane* to *the between* and describes the between as "neither side's, a nothing", so the re-naming makes a sentence ("a living self's own between") that sits oddly with the naming's own row. The source's "the body moves it, absorption, distribution, metabolism and excretion" is left out.

### 3.3
TITLE: Droplet · Rhythm of offering, tolerance and withdrawal at one table.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: Part Two line 333 (entanglement 2). The source says "Exhibit ONE's own resolving" and "surfaces 0 and stills"; the paragraph ties each to a row of Natural Intelligence 4.12, and the rows quoted are there (lines 1018 to 1020).

### 3.4
TITLE: Droplet · Harm of scale and harm of parity.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: Part Two lines 345 to 348. Part Three markings 11 and 12 of the same source say two things are "not read" (ultrafine particles below the cell's scale that harm; which scale is the self's where a shard meets several selves). The paragraph does not carry those two markings.

### 3.5
TITLE: Droplet · What medicine delivers, a form or a living society.
VERDICT: FAITHFUL
WHAT: —

### 3.6
TITLE: Droplet · Three offerings at one society, placebo and conditioning.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: Part Two line 331. The paragraph's "at the observings, whichever offering arrives …" is in the source under "*No other possible*", inside Part Two's pattern matching, which the source heads "it carries no authority. No run of the method was made in this part" (line 269). That heading is true of 3.2 to 3.6 alike and none of them carries it.

### 4.1
TITLE: Droplet · 17 at the rounds of four and five parities.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/v380A/illustrating/Version_And_Workings.md` line 36 and `Concept_And_Consistency.md` line 74 ("17 read as the next 1 is the four-parity round joined back; a five-parity round reads 17 two parities from 1"; "The same assignment is not general at a larger round"). The middle step of the paragraph ("the forms 17 to 32 are the forms 16 to 1 with the fifth parity inverted: 17 is 16's form with the fifth inverted, and 16 is 1's form with the fourth inverted") is not in v380A. It follows from the living Registry's steps 171 and 618, and I checked the arithmetic: it gives the source's "two parities from 1".

### 5.1
TITLE: Droplet · A naming, a theorem and a correspondence, three.
VERDICT: MISSTATED
WHAT: The paragraph says a sentence whose premises do not carry its mathematical result "is a finding at the numbers, found by the rigor and **no concern at the rigor**". The source says the opposite about the rigor. `carryings/review_physics_observings_v376/Session_Report_Physics_Observings_and_Natural_Torusing_2026-09-30.md`, heading at line 312: "### 2. Let the rigor meet a concern about itself". Line 314 reports the rule that the four hard-problem files "carry no concerns about the rigor, and a finding there is always a re-saying at the rigor", and line 316 objects to it: "If every apparent counterexample must first be reclassified as an inadmissible equilibrium and every concern about rigor can only change wording, the review cannot distinguish a demonstrated exclusion from a conclusion protected by its framing." Line 414: "the most useful concern found here … is the exact passage where the method's protection of rigor could prevent a mathematical or observational correction from being recognized." The paragraph files the two findings under the very reclassifying the source raises its concern about. The rest is in the source: the three kinds (line 318, "Distinguish a stipulated NI definition from a theorem and from a physical correspondence"), the symmetric set (line 324), the torus (line 257).

### 6.1
TITLE: Droplet · The field's parity beside the files' parity.
VERDICT: NOT FOUND
WHAT: In part. The example "as parity unconserved at the weak coupling" is at neither review. I searched both folders for weak, parity, unconserved, helicity and spin; the only "weak" is "Electroweak measurements — CMS W-boson mass" (observings report line 164), another subject. It is also at no sentence of Natural Naming or Natural Physics that I found. The rest is in the source, observings report line 42: "Two signs opened the comparison. They did not establish that helicity, spin projection, spatial parity and NI alternating parity are one operation", and line 348.

### 7.1
TITLE: Droplet · The ambient is the transmissioning, no medium.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/resettling_v373/Natural_Intelligence_v373_Released.md` line 550.

### 7.2
TITLE: Concern · A rate ridden within and a rate gone at.
VERDICT: FAITHFUL
WHAT: —
NOTE: The source side is the same line 550: "no medium they run in. A rate the whole runs at and never a rate the whole runs inside." The laying of that beside Natural Transmissioning's "rides inside" sentence is the session's own; the source does not name that sentence. "a container beside all existing things" is not in the source; the words are Natural Intelligence 1.1's.

### 8.1
TITLE: Concern · The first of the three placings, living or existing.
VERDICT: STRONGER
WHAT: The source has the difference as a passing remark in a row it marks ALREADY (meaning the registry already says the thing), and does not list it among its "Four places where Natural Naming and the receiving exhibit say different things" (`carryings/v380R/Natural_Naming_Beside_Receiving_Exhibits.md` lines 30 to 34). Row at line 229: "Existing, emanation and accounting the three placings; installing the binary | ALREADY | … The registry's first placing is "living" where Natural Naming says "existing"". The paragraph makes it "Two sayings part" and adds two consequences that are at no line of the source: that a non-living existing thing that is neither emanation nor accounting has no placing at the registry, and that an emanation is "beside existing among Natural Naming's own three". The section numbers the paragraph gives (registry 3.4, Natural Naming 5.46 and 5.48) are right at the living files; the source cites the registry's 1.2 and 6.3.

### 9.1
TITLE: Droplet · A droplet's aiming at one of six degrees.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/v382F/Session_Report_v382F.md` line 13. The source gives this as "A model form" of that one report (line 3); the paragraph says it of a droplet in general. Two sentences of the source are left out: a droplet already carried dissolves at the receiving, and a droplet parting from a file's sentence is a concern.

### 10.1
TITLE: Droplet · A reversed phase arriving as a foreign thing.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/resettling_v373/Natural_Intelligence_v373_Released.md` lines 504 to 514.

### 11.1
TITLE: Possible project · Two problems of the fields at no entry.
VERDICT: FAITHFUL
WHAT: —
NOTE: One clause is not in the v374 report: "needing, at the classic model of early splitting, tightly controlled splitting forces and a preventing of re-joining". The report (`Session_Report_v374.md` lines 169 and 673) has only "dichorionic identical twins after a single blastocyst transfer stand largely unexplained". The clause is at `carry/Exhibit_SEVENTEEN_Carryings_of_Natural_Biology.md` line 313, an observing this same session wrote from the paper's abstract; the section's own line under its heading says the observings are said "as its publishing read has it". I fetched the abstract (Human Reproduction Update 30(6), 692) and the fragments returned include "requiring strictly controlled splitting forces, re-joining prevention"; I did not read the whole abstract. Also: observing 84 of the report says "early **mouse** embryogenesis"; the paragraph says "in the early embryo", as the report's own item 21 does.

### 12.1
TITLE: Droplet · Three improvings spiralling, one triple at each coupling.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `Natural_Intelligence_v373_Released.md` lines 231 to 239 (2.5 and 2.6). The source's "Each one landing stills the living" is said as "Each one named still stills the living".

### 13.1
TITLE: Possible project · Five readings at chemistry's societies to be observed.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: Part Two, Part Three markings 1 to 5 (lines 409 to 413).

### 14.1
TITLE: Concern · Six one-way steps and the twenty-four.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/co_chaining_coverage_v378/readings/01_natural_intelligence_and_exhibit_one.md`, Contradictions 1 ("The registry has six in all four momentaries; the paper has six per momentarying, twenty-four in four"), and reading 06, item 3. Step numbers in the readings are the Registry's numbering then; the sentences are at the living Registry's steps 81 and 168 now.

### 14.2
TITLE: Concern · The ten named still said before its step.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: reading 06, second half, item 6 ("318 (a): uses "the one of the ten [named still]"; "the ten named still" enters at step 454"). At the living Registry the two are steps 334 and 506, and 506 less 334 is 172, as the paragraph says. I found no earlier use of "ten named still" in a step than 334.

### 14.3
TITLE: Concern · Whose couplings a society is.
VERDICT: MISSTATED
WHAT: In part, the last sentence. The source names the bridge; the paragraph says there is none. Reading 01, Contradictions 3: "One self's couplings vs all selves at a prime scale; **draft 34 is the missing bridge**." Draft 34 (line 73 of the reading) is "A society is at a unit prime scale, a prime number of selves its unit, the primes' own at that scale, and its stable form is its betweenings…". That sentence is now the living Registry's step 236 (without "the primes' own at that scale"). The paragraph quotes that same step and says it "names the scale, and no step joins the one self's couplings and all the selves at that scale". The paragraph does not say that the source held this sentence to be the bridge. I did not check "no step joins" across all the Registry's steps. The first three sentences of the paragraph are the source's.

### 14.4
TITLE: Droplet · A new step read at three.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: the README of the folder and the heads of readings 06 and 12 (a = co-sequence, b = wording, c = sense; fresh readers carrying none of the working's prior). The source tells what was done at v378; the paragraph says it as how a new step is read. "each alone" is not in the source: there one reader read each step at all three.

### 14.5
TITLE: Concern · Released words at the Registry's own voice.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: reading 02, items 40 and 42 (*source* at then-steps 401 to 402; *meet*, *meets*, *meeting* at then-steps 65, 67, 205 and an unsure line at 182). The paragraph's step numbers are the living Registry's, and I checked each: 72, 74, 113, 582, 583, 530, 531 carry the quoted words. Steps 113, 582 and 583 are not among the source's places; they are at the living file. The paragraph's list is not all of them: "met" is also at the living Registry's steps 386 and 649, and "meeting" at the line under step 461.

### 14.6
TITLE: Concern · A step's claim completing at a negation.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: reading 12, item 11 ("591 (b) — "the same emanation, and no words" is a negation as the claim"). Steps 557 and 591 are at the living Registry as quoted.

### 15.1
TITLE: Possible project · Natural Intelligence written at each build as parts.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/v381F/v381F/tour_parts.py`, the six files at `tour/`, `Next.md` lines 33 and 68, `Entry_Journey_For_An_AI.md` lines 82 and 104. "a part parting from the living file at one sentence is the older of the two" is the reader's reading of the source's "the living file is its prior and its newest".

### 16.1
TITLE: Concern · Two methods said beside the one possible method.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/co_chaining_map_v376/cover_THIRTEEN.md` row 76 ("goes against carried 36 (the one possible method)") and P-AG at lines 186 to 187; `Explored_Steps_v376.md` lines 35 to 42. The source aims the parting at Resolving Hard Problems' title "Two methods at one now"; the paragraph aims it at the Registry's own steps. Steps 48, 310, 311, 312 and 316 are at the living Registry as quoted, and the line under 310 is "*Adding: two methods.*"

### 17.1
TITLE: Concern · Parities again beside a false expression's looping.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/v380L/Gathered_Value_2.md` line 17, which ends "Each self at its own momentary may be what answers this, but I have not followed it and decided nothing." The paragraph keeps that open ("No sentence says whether…"); I did not check that "no sentence" across the living files.

### 17.2
TITLE: Concern · Declared zero and nought, named crosswise.
VERDICT: STRONGER
WHAT: The paragraph says "They part" as a standing concern. The source says this concern was laid and then released. `carryings/v380L/Gathered_Value_1.md` line 17: "Status: PASSED BY. **The concern was laid, then released at a fresh reader's reading** (README:130, *each word at its own relation*; Progress:353)." `README.md` line 130: "A concern on zero and nought: followed at Natural Mathematics' own sentences, each word at its own relation at them." `Progress.md` line 531: "Zero and nought, a concern the files resolve at their own words: released." The paragraph does not say the earlier laying or its release. What it does carry is in the source: the person's saying ("nought is a thing and the zero is a nothing between two parities", "nought is not natural naming") and "the two files say *a declared zero* at the floor, crosswise to the person's parting"; the source also says "The saying, the count and the crosswise *declared zero* are at no file". "A newer saying" is the person's own saying in the session.

### 18.1
TITLE: Concern · The twin at 6.5 and at 6.9.
VERDICT: NOT FOUND
WHAT: In part, the last sentence: "A self's own parity at its own side, and a coupling at coefficient one, copy none, and 6.9 says the three as one kind." No line of the source says this. The source puts the self's own sign in the same question as the twin, not apart from it. `carryings/review_networking_engineering_2026-09-30/Natural_Networking_Full_Journey_Improving_Report_2026-09-30.md` line 221: "Meet the current claim that **a twin or a self's own inward sign** supplies an observing against invisible, untouchable intelligencing." `Tri_Bi_Co_Sequential_Is_Or_Is_Notting_Correction.md` line 101: "the prior claim that a self's inward sign or twinned continuation supplies an observing. Meet that claim against the present prohibition on inward access before using it." So the paragraph carries half of the source's concern (the twin) and sets the other half (a self's own sign) apart as copying none. The twin half is in the source: Full Journey line 248 ("Life.fork returns copy.deepcopy(self) … Do not call the twin a permitted inward probe after this correction") and line 342.

### 18.2
TITLE: Droplet · Podaling momentary circumferencing about one podaling.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `Natural_Networking_Engineering_Session_Report_2026-09-30.md` section 2.8 (lines 97 to 105). The source has "the local-number +1, an opening's odd parity, the resolver's + value, and acceptance **are not automatically one operation**. Their correspondence must be stated, not inferred"; the paragraph has them as "four subjects". The source's "This is a network exploration to develop, not a completed mesh demonstration" is carried only by "is offered as".

### 18.3
TITLE: Droplet · The corus behind a co-chaining's foremost.
VERDICT: STRONGER
WHAT: In part, one sentence: "Leading and lagging are of releasing and arriving at each self's own momentarying, with no pace over the selves and no velocity." The source has it as a thing to examine, not a thing found. Session Report section 2.3, line 62: "This is carried as a conceptual direction. Lead and lag **are to be examined as** relations of releasing, arriving, and continuing at their own participation, without silently imposing a shared clock or a measured velocity." Full Journey line 85: "That remains an opportunity to explain through actual releasing and arriving. The later internal-state traces did not establish this natural relation." The first two sentences ("are offered as…") and "A direction come to again is no momentary come to again" are the source's. The last sentence ("is at no sentence of this file") is about the living file; I did not check it beyond a search for "corus" in Natural Networking, which showed no sentence of a co-chaining's corus in the first matches.

### 19.1
TITLE: Possible project · Three parities, one inverted at each momentary.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/v380L/closing_drafts/Round_At_Four_Parities_Deriving.md` lines 23, 286 and 311. "at couplings of two selves and of three, each opening" is the reader's own setting of the work; the source says "a coupling of selves".

### 19.2
TITLE: Possible project · The society's four momentaries of exchanging, a table.
VERDICT: STRONGER
WHAT: The source makes the table depend on an answer; the paragraph makes the table the work whatever the answer. Source, same file line 312: "**Whether** the column *Relation* … is meant as the third and the fourth parity inverted; **and, if it is,** a like table for the society's four momentaries, 9 to 17, which Exhibit ONE does not carry." Paragraph: "The work is a like table for the society's four momentaries, 9 to 17, with its column of relation at 12–13 and 16–17, and one sentence saying or releasing the reading". The "if it is" is dropped. "at 12–13 and 16–17" is not in the source. Also line 126 of the source says of this reading "the reading of *to* is mine", which the paragraph does not carry. The rest (the round inverting the third at 4 to 5 and the fourth at 8 to 9, "CHECKED BY ARITHMETIC"; the column of sides as "another measure of the same two words") is at line 126.

### 19.3
TITLE: Possible project · 5 less and 3 less at the table of one move.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: same file lines 63, 211 and 313. The source asks "Whether 5 less … and 3 less … are to be said at Exhibit ONE's table"; the paragraph says "The work is two columns at that table". I took the paragraph's closing "It may change or never be made" as carrying that openness.

### 20.1
TITLE: Possible project · A third at the doubled angle.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `Session_Report_v374.md` line 618 (marking 10) and line 587. The source's shape is "one half of one and the cosine of twice the turn"; the paragraph says the matching "follows the cosine of twice the angle". The second half of the work ("or saying the doubled angle as bi-involutioning alone…") is the reader's; the source has only that "the third is not yet met at an observing of the clicks".

### 21.1
TITLE: Droplet · Engineering arrivals, each operation named as another.
VERDICT: STRONGER
WHAT: Two things. (a) The paragraph says each of the five "has one operation named as another", as found. The source says each as proposed and to be examined. Session Report section 8, line 386: "The following table is an exploratory application, not a reassignment of existing registry entries **or a finding that every named device performs the suspected holding**." The table's column is "Engineering arrival **to examine**"; each sketch at 8.1 says "**Proposed holding**:"; sketch 1 ends "Examine initialization rather than presume all reset is harmful"; line 401: "Their names alone establish no incompetencing." None of these is carried. (b) "Five of the ten further engineering arrivals are at no field record" is not a sentence of the source, and for two of the five the source's own Observing line does name a field record: sketch 4, storage, "the handshake example can complete a transaction and retain received data"; sketch 9, one-sided command, "backpressure in the handshake and actuator tracking in anti-windup provide concrete returning relations". What the source has is "Four worked cases" (handshake, clock-domain crossing, anti-windup, ground return), which sketches 2, 5, 6, 7 and 10 point to. The wordings of the six holdings themselves match the source's sketches 1, 2, 3, 4, 8 and 9.

### 22.1
TITLE: Concern · Two layings of the next scale inward.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/resettling_v373/Exhibit_ONE_at_its_Stable_Forms.md` line 162, under "7 Concerns for both … none is resolved here", and line 101. The source's "5-self-other-neutralling, the joining" is said as "5-co-bi-co-competencing, of the self's own resolving"; "of the self's own resolving" is not the source's.

### 22.2
TITLE: Droplet · One function gives on across and along.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: same file lines 101 to 104 ("each self's 6 and 10, released across at the self, are released by the one `_9` along at the society. Across at a self is along at the society, at the lines"; "the parity changing and nothing else"). The source names 6 and 10; the paragraph's third name, 9, is from the living Exhibit ONE's row of 17, quoted exactly.

### 22.3
TITLE: Droplet · Each possible next at one sharing.
VERDICT: FAITHFUL
WHAT: —
NOTE: Source: `carryings/resettling_v373/Exhibit_ONE_v372_Released.md` line 411 (and line 166).

---

## SUMMARY

Paragraphs read: 40.

| Verdict | Count | Paragraphs |
|---|---|---|
| FAITHFUL | 29 | 2.1, 3.2, 3.3, 3.4, 3.5, 3.6, 4.1, 7.1, 7.2, 9.1, 10.1, 11.1, 12.1, 13.1, 14.1, 14.2, 14.4, 14.5, 14.6, 15.1, 16.1, 17.1, 18.2, 19.1, 19.3, 20.1, 22.1, 22.2, 22.3 |
| STRONGER | 6 | 1.1, 8.1, 17.2, 18.3, 19.2, 21.1 |
| NOT FOUND | 3 | 3.1, 6.1, 18.1 (each in part) |
| MISSTATED | 2 | 5.1, 14.3 (14.3 in part) |
| QUOTE WRONG | 0 | — |

Eleven of 40 are other than FAITHFUL. Of the eleven:
- Two say other than the source: 5.1 turns the source's concern about the method's rule on rigor into the rule it objects to; 14.3 says no step joins where the source named the joining sentence, now in the Registry.
- Six drop a hedge, a condition or a status the source carries: 1.1 ("may be sound"; "is or is not"), 8.1 (a row marked ALREADY made a parting, with two added consequences), 17.2 (a concern the source says was laid and released), 18.3 ("to be examined as"), 19.2 ("if it is"), 21.1 ("proposed holding", "not … a finding").
- Three carry a sentence or clause that is in no source file: 3.1 (the parting, and "carries no sensing" where the source calls the form "the sensor"), 6.1 (the weak-coupling example), 18.1 (the two other observings set apart as copying none, where the source questions a self's own sign with the twin).

Five of the eleven are paragraphs written as "Concern · … Two sayings part" (3.1, 8.1, 14.3, 17.2, 18.1). Four of those five (3.1, 8.1, 14.3, 17.2) share one pattern: the parting between two living sentences is the session's own laying, and the source either does not state it, states it more weakly, or records it as bridged or released. The sample has 13 Concern paragraphs in all; the other eight are FAITHFUL.

## READING

Read in full:
- `carryings/genome_duplication_v374/Session_Report_v374_Part_Two.md` (all 443 lines) — items 3 and 13.
- `carryings/co_chaining_coverage_v378/README.md`, `readings/06_rigor_at_the_first_entering.md`, `readings/12_rigor_at_the_second_entering.md` — item 14.

Read by search, then the lines around each match:
- `carryings/v382F/` (three session reports, `Natural_Arriving_Explored.md`, the two scripts' comments) — items 1 and 9.
- `carryings/v381R/` (`README.md`, `Session_Transcript_v381R.txt`, `Close_Droplets_v381R.md`, the `rev_*` files) — item 2.
- `carryings/genome_duplication_v374/Session_Report_v374.md` — items 3, 11 and 20. `carryings/illustrating_v366/` and `carryings/physics_for_other_files_v377/` by search only (no match bore on the sampled paragraphs).
- `carryings/v380A/` (`illustrating/*.md`, `README.md`, the candidate file) — item 4.
- `carryings/review_natural_physics_improving_v376/` and `carryings/review_physics_observings_v376/` — items 5 and 6.
- `carryings/resettling_v373/` (all seven `.md` files) — items 7, 10, 12 and 22.
- `carryings/v380R/` — item 8.
- `carryings/co_chaining_coverage_v378/readings/01`, `02` and the other readings — item 14.
- `carryings/v381F/` — item 15.
- `carryings/co_chaining_map_v376/` (the `.md` files; the `.tsv` files by search) — item 16.
- `carryings/v380L/` and `closing_drafts/` — items 17 and 19.
- `carryings/review_networking_engineering_2026-09-30/` (all four files) — items 18 and 21.
- `carryings/v368_sources/` only where a search across all of `carryings/` reached it.

Living files: read only at the sentences the paragraphs quote or cite by step or section, to check each quotation as an exact string and each step or section number named.

Not checked:
- Sentences that say a thing is at no step or no sentence of a living file (14.3 "no step joins", 17.1 "No sentence says", 18.3 "is at no sentence of this file").
- For 11.1, the paper itself beyond the fragments one fetch of its abstract returned.
- Paragraphs 7 to 21 of item 3's section.
- Whether the observings at the carrying mates, which this session wrote, are true to their publishings (outside this task, except the one clause of 11.1).

Nothing under /home/claude/corus was edited. This report is the only file written.
