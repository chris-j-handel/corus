# Task: sections the session added, each laid beside its source

Read COMMON.md first.

Your task names a sample file. Each item names a file in `carry/`, the heading of a section the session added to it, and the source the session said it took the section from, with the source's path on disk (under /home/claude/corus/). The session's readers read the source and wrote the section "in the naming now", in new words, with one reader and no second reader. The risk is a paragraph that says something its source does not say, says it more strongly, drops a condition, or invents.

For each item:
1. Open the file in /home/claude/corus/carry/ and find the section (search for the first words of the heading; the heading may differ by a few words). Read each paragraph in it that opens with a bold title (`**Droplet · …**`, `**Concern · …**`, `**Possible project · …**`).
2. For each such paragraph (at most six for one section; take the first six), find its content in the source path. Sources may be long: search for the paragraph's distinctive terms, then read around the matches.
3. Judge each paragraph: FAITHFUL (the source says this, at this strength), NOT FOUND (you could not find it in the source after real searching), STRONGER (the source says it with a hedge, a condition or as a question, and the paragraph drops that), MISSTATED (the source says otherwise; say how), QUOTE WRONG (a sentence in double quotation marks said to be a living file's is not an exact string of a `*.md` file at /home/claude/corus).

Your report: one block for each paragraph read:
```
### <item number>.<paragraph number>
TITLE: <the paragraph's bold title>
VERDICT: <FAITHFUL | NOT FOUND | STRONGER | MISSTATED | QUOTE WRONG>
WHAT: <for anything but FAITHFUL: exactly what, with the source's own words and where in the source; otherwise a dash>
```
Then `## SUMMARY` with the count of each verdict, and `## READING` (which sources you read in full, which by search). Final message: the path of your report and the counts.
