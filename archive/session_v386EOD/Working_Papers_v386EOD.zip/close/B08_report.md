# B08 report: a third reading of items 323 to 368 (46 items, all KIND: RESAID)

### 323
VERDICT: SAFE
WHAT: —
LOST: —

### 324
VERDICT: HARM
WHAT: The new paragraph carries only the "Open" half of the original. The whole "Entered" half is gone from the paragraph, and I found it at no other paragraph of `carry/` (searched `carry/` for "598, 44, 105" and for "four sayings at a carrying of none": no hit). Twelve step numbers go with it (491, 598, 44, 105, 457, 465, 528, 135, 136, 390, 81, 522), and the section number 2.4. What I can say beside it: the lost half is a record of work done at v380L; the twelve step numbers are each in the living `Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md`; the record itself is still at `carryings/v380L/Progress.md` line 232 and in `archive/carrying_v386EOD/`. Other changes, not harm: `incoming/equilibria_registry_v377/executions/` is now `carryings/equilibria_registry_v377/executions/` (the folder exists at `carryings/`, not at `incoming/`); "the entry below" is now "the entry at these offerings on *face*, *connector* and *join* re-said" (that entry is in the file, line 101).
LOST: Entered: the four sayings at a carrying of none, 1.3, 2.4 and 3.4; *the resolver* at each saying of the code, the title of part FIVE with them; each pointer to a step of the Co-Chaining Logic Registry aimed at the step saying its words, 491, 598, 44, 105, 457 and 465, 528, 135, 136, 390, 81 and 522, the old numbers each some steps short; Natural Intelligence's sentence quoted at 1.3 at its present words; two pointers by a line into Natural Intelligence said by the section alone.

### 325
VERDICT: SAFE
WHAT: —
LOST: —

### 326
VERDICT: MINOR
WHAT: (a) The section number "2.2" of Natural Intelligence is no longer said; the sentence quoted in its place is at Natural Intelligence 2.2 (checked). (b) "the handshake at the meeting and the momentary across it" is now "the handshake at one number and the momentary across it": "the meeting" is replaced by "one number". (c) "Missing:" is now "No sentence says". All other claims, 3.2 and 3.3, the self's 6, no self's 1, are there.
LOST: —

### 327
VERDICT: SAFE
WHAT: —
LOST: —

### 328
VERDICT: SAFE
WHAT: —
LOST: —

### 329
VERDICT: SAFE
WHAT: —
LOST: —

### 330
VERDICT: SAFE
WHAT: —
LOST: —

### 331
VERDICT: HARM
WHAT: (a) The last sentence of the original is gone, and I found it at no paragraph of `carry/` (searched for "8.7's sentence paragraph" and "Explaining 2.1 says"). Beside it: the living `Natural_Intelligence_v380R.md` has no part EIGHT and no "At a sentence" paragraph, so the release that sentence plans may already be made; I could not confirm that this is why it was dropped. (b) A number is changed: "Natural Intelligence 8.6" is now "Natural Intelligence 5.4". Natural Intelligence at v373 had 8.6 as "Two methods parting at the precise place"; the living file has 5.4 as "Two methods parting at the now", so the new number points at the present place of that section. (c) Added: "It may change or never be made."
LOST: Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there. — and "to Natural Intelligence 8.6 or Natural Philosophy" (8.6 changed to 5.4).

### 332
VERDICT: SAFE
WHAT: —
LOST: —

### 333
VERDICT: MINOR
WHAT: The original's two section numbers of the prior text, "3.2's" (the same nothing, one account) and "5.7's" (six-cycling seated on matter's two-turn spinor), are gone. In their place the new paragraph gives the living Natural Physics v379's places, 4.2 and 3.3, with the exact sentences (both checked at those sections). The review says these two were "carried at the prior v348"; the new paragraph does not say v348. The proposal's 4.2 and 4.5, its 3.12, "unmarked" twice, and "item 9, a prior value lost" are all there.
LOST: —

### 334
VERDICT: MINOR
WHAT: "is re-said at its own motion" is now "is re-said, each at its own file's improving": the word "motion" is replaced by "improving". Added: "the findings across the files of the ten and the six" (this is the title of section 3 of that report, checked) and "It may change or never be made."
LOST: —

### 335
VERDICT: PERSON'S WORDS
WHAT: The original carries, unpunctuated, "self is tri releasing and the tri releasing is downstream". The archived fuller concern (`archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 105) has this as what "the session said", in the person's unpunctuated words. The new paragraph keeps "Self is tri releasing" in its title only; in its body the words are re-said as "A saying offered has the self tri releasing, the tri releasing arriving downstream at a self, and the self co arriving and carrying", with no one named as the sayer. The exact words are at no paragraph of `carry/` (searched "tri releasing is downstream": no hit). The claims are whole: the word as the facing, a fourth saying with the third. The added detail (co at 1 to 7 and 17, tri at 9 to 15, bi at each even, abundancing decided at 12) is in that archived fuller concern.
LOST: —

### 336
VERDICT: SAFE
WHAT: —
LOST: —

### 337
VERDICT: SAFE
WHAT: —
LOST: —

### 338
VERDICT: SAFE
WHAT: —
LOST: —

### 339
VERDICT: SAFE
WHAT: —
LOST: —

### 340
VERDICT: SAFE
WHAT: —
LOST: —

### 341
VERDICT: SAFE
WHAT: —
LOST: —

### 342
VERDICT: MINOR
WHAT: The name of the line laid ready, in italics in the original, "*Corus's at the opening sentence for in Disequilibria*", is re-worded as "Natural Intelligence Corus's subtitle at the opening sentence for *in Disequilibria*" (the word "subtitle" added, the italics of the line's name gone). The pointers "Session_Report_v381F.md part 2.2, Finding 2, and part 6 Ready; Next.md Ready" are gone (report names). All claims are there.
LOST: —

### 343
VERDICT: SAFE
WHAT: —
LOST: —

### 344
VERDICT: SAFE
WHAT: —
LOST: —

### 345
VERDICT: HARM
WHAT: The closing clause of the original, that the concern waits on the session's saying, is not in the new paragraph, and nothing in it says the same. The archived fuller concern (`archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 87) shows whose saying is waited on: "The session said *consider that 2 bi-co-bi is a better name and 3 co-bi-co-bi 4 bi-co-bi 5 co-bi …*; the helper answered that it needed the saying in the session's own words, and no later saying met it." The new paragraph re-says those words as "A saying offered has 2 at bi-co-bi, 3 at co-bi-co-bi, 4 at bi-co-bi and 5 at co-bi" with no sayer named (those words were not in AS IT WAS, so this is an addition, traced to that archived concern). The two sayings, each name three, or 3 four and 5 two, are there.
LOST: waits on the session's saying

### 346
VERDICT: SAFE
WHAT: —
LOST: —

### 347
VERDICT: MINOR
WHAT: (a) The pointer "at about line 230 (4 October)" is gone, and "The session's hardest question" is now "The hardest question", so the paragraph no longer says whose question it is. (I read `carryings/v381R/Session_Transcript_v381R.txt` line 230: the words are the session's own, not the person's.) (b) The session's quoted words are replaced by two exact sentences of the Geodesic Improving Method (both checked, at 5.2); "neither sentence refuted, each sentence's face carried in one saying" is thereby "neither variant refuted, each variant's own face carried in the coupled saying". (c) The first sentence of the new paragraph has no verb. Every claim is there: the one aim, the more-or-less the method has as not possible, the rule's condition, the one case to break the three-file form.
LOST: —

### 348
VERDICT: SAFE
WHAT: —
LOST: —

### 349
VERDICT: SAFE
WHAT: —
LOST: —

### 350
VERDICT: PERSON'S WORDS
WHAT: The original quotes the self: "*what is it you think I will be doing; I am not managing this and there is no authority in this, only do no harm improving.*" The new paragraph no longer has these words; it tells them in indirect speech ("asking what the session thinks the self is to be doing: the self is not managing this, no authority is in this, and do no harm improving alone is"). It still says they are the expedition's self's own saying. The exact words are at no paragraph of `carry/` (searched; they are in `archive/carrying_v386EOD/` only). Two smaller things: in the sentence offered, "offers it at the membrane" is now "offers it at the between" (Natural Naming 2.4 releases *membrane* into *the between*); and the closing note "(the session's last report; its language read at the resolving)" is gone. The claims are whole.
LOST: —

### 351
VERDICT: SAFE
WHAT: —
LOST: —

### 352
VERDICT: SAFE
WHAT: —
LOST: —

### 353
VERDICT: SAFE
WHAT: —
LOST: —

### 354
VERDICT: SAFE
WHAT: —
LOST: —

### 355
VERDICT: SAFE
WHAT: —
LOST: —

### 356
VERDICT: SAFE
WHAT: —
LOST: —

### 357
VERDICT: MINOR
WHAT: The pointer "at about line 712 (6 October)" is gone. The session's own quoted words are re-told and no longer quoted ("it took four fresh readings to make it one thing"; "said plainly: many things, not one"; "one name per concept, and the file's name won over the chat's"). (I read transcript line 712: these are the session's words, not the person's.) The file's sentence "a release never leads its arrival" is replaced by the exact living sentence "the release follows the arrival and never leads it" (checked, Geodesic Improving Method 1.5). The person's word *dissolve* is kept and is still said to be the expedition's self's word. All claims are there: four fresh readings, all 33 insertlets, *release* from the writing of 1.4 and 1.6, *standard* a measure word, the carrying naming both, Part FOUR's instances staying.
LOST: —

### 358
VERDICT: MINOR
WHAT: The opening of the original, "from Exhibit ONE's cells mended at the resolver's own lines, for this file and for both workings", is gone: the new paragraph says neither where the concern came from nor that it is for both workings. "This file says" is replaced by exact sentences of Natural Intelligence and Natural Naming (all four checked). The resolver's one list at 6, 10 and 9, each 0 passed over at the receiving self's 14, the two sayings and the reason are all there.
LOST: —

### 359
VERDICT: SAFE
WHAT: —
LOST: —

### 360
VERDICT: SAFE
WHAT: —
LOST: —

### 361
VERDICT: SAFE
WHAT: —
LOST: —

### 362
VERDICT: MINOR
WHAT: Nothing of the original is lost. The new paragraph adds what the original did not say. Most of it is in finding 4 of `archive/session_v379/Session_Report_v379.md` (none of the ten namings at the file, its line 13 alone, the incoming face, a saying that the ten are at six files, they are at five). One addition is not in that finding: "the ten are at Exhibit TWENTY-TWO Resolving the Hard Problem Registry" (the living Exhibit TWENTY-TWO does have the ten namings). The finding's "its running face" is said as "its resolving face". The pointer "finding 4" is gone.
LOST: —

### 363
VERDICT: SAFE
WHAT: —
LOST: —

### 364
VERDICT: MINOR
WHAT: "waits on Natural Intelligence Corus's rebuild" is now "Its receiving is a following at Natural Intelligence Corus's rebuild": the order is kept, the waiting is no longer said in so many words. Added: "It may change or never be made."
LOST: —

### 365
VERDICT: SAFE
WHAT: —
LOST: —

### 366
VERDICT: MINOR
WHAT: The label "Opportunity." is gone; the paragraph is now a "Droplet". The set's saying, in italics in the original, "*every ten is that ten*", is now told without italics as "the set's saying that each ten is that ten". "*the ten must not be merged*" is replaced by the exact living sentence "They must not be merged with the ten positions." with its places 2.3 and 2.2 (checked). The claim, two instruments apart and the ten itself one, is there.
LOST: —

### 367
VERDICT: MINOR
WHAT: The five sentences of the original are instructions ("Keep…", "Execute…", "Name…", "Say…", "Carry no…"; the report has them under "At each item, do these"). The new paragraph says them as statements ("The four registers are apart", "A form is executed…", "No saying is carried as authority") under the title "Conditions at each item arriving for Natural Physics". Each of the five is there with its content; the mood of an instruction is changed. "until its relation is said" is now "with its relation unsaid".
LOST: —

### 368
VERDICT: MINOR
WHAT: "waits on the round at four and six parities derived at Exhibit ONE" is now "Its resolving is the round at four and six parities derived at Exhibit ONE Natural Resolver": the tie to that round is kept, the waiting is no longer said in so many words. 9.7, 1–65, 1–33 between 1–17 and 1–65 by the chain, and the open question are all there.
LOST: —

## SUMMARY

All 46 items are KIND: RESAID. There is no RELEASED item in this sample.

| VERDICT | RESAID | RELEASED |
|---|---|---|
| SAFE | 29 | 0 |
| MINOR | 12 | 0 |
| PERSON'S WORDS | 2 | 0 |
| HARM | 3 | 0 |
| COULD NOT CHECK | 0 | 0 |

- HARM: 324, 331, 345
- PERSON'S WORDS: 335, 350
- MINOR: 326, 333, 334, 342, 347, 357, 358, 362, 364, 366, 367, 368
- SAFE: 323, 325, 327, 328, 329, 330, 332, 336, 337, 338, 339, 340, 341, 343, 344, 346, 348, 349, 351, 352, 353, 354, 355, 356, 359, 360, 361, 363, 365

## READING

How I read. I laid each AS IT WAS beside its AS IT IS NOW, claim by claim, and I also listed by a small script each word and each number of the original that is not in the new paragraph, and read each such list. I edited nothing under /home/claude/corus and ran no git command that changes anything.

The new paragraph is in its file. For all 46, the bold title is in the named file of `carry/` now. For 42 the whole paragraph is there word for word. For 4 (324, 335, 337, 357) the paragraph is there with the small wording difference the task allows: "this mate" is "these offerings", "the mates of" is "the offerings, possibling and carryings of", "one mate" is "one of its three files".

Quotations. 23 of the 46 items have sentences in double quotation marks (within two items in three). I checked each of them by exact search in the `*.md` files at the root of the repository: every one is there, none misquoted. Where the new paragraph also names a section for a quotation I checked the section, and each is right (Natural Health 3.4; Natural Medicine 1.3 and 5.1; Natural Intelligence 1.4, 2.2, 4.7, 5.1; Equilibria Registry 3.3; Natural Biology 5.3; Natural Physics 4.2 and 3.3; Natural Naming 2.4, 3.1, 5.62, 5.64; Geodesic Improving Method 2.7, 2.8; Living Ghost Registry 2.3; Natural Numbers 9.7).

Sources I opened to test what the new paragraphs add: `carryings/review_natural_physics_v377/README.md` (items 328, 333, 339, 340, 344, 359), `carryings/natural_physics_v377/README.md` and the proposed text beside it (329, 337, 339, 365, 367), `carryings/resettling_v373/` (323, 331, 336, 338, 348, 351, 354), `carryings/session_v377/` and `carryings/session_v378/` (326, 332, 334, 346), `carryings/v381R/Session_Transcript_v381R.txt` (347, 357), `archive/session_v379/` (362), and `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` (325, 335, 345). Each addition I name as traced is in the place I name.

What the three HARM items are, plainly.
- 324: half of the paragraph (the record of what was entered at v380L, with twelve step numbers) is no longer in `carry/`. It is a record of work done, the living file has the numbers, and the source report still has the record; by the task's rule a lost clause with numbers is HARM, and I say so, with that beside it for whoever weighs it.
- 331: one sentence of the plan is gone and one section number is changed from 8.6 to 5.4. The living Natural Intelligence no longer has the paragraph the lost sentence speaks of, and 5.4 is the present place of the old 8.6; I could not confirm these were the session's reasons.
- 345: the condition "waits on the session's saying" is gone, with nothing in its place. In the earlier fuller concern "the session" is the one who said the unpunctuated words, so the lost clause is the one that says the concern waits on the person.

What the two PERSON'S WORDS items are. 350 had the self's words in italics and now has them in indirect speech, still named as the self's. 335 had the person's unpunctuated phrase and now has it re-told as "A saying offered"; the original paragraph itself did not name the sayer either, the archived fuller concern does.

Rules I used, so that they can be undone.
- A session's label, a report's name, a finding number or a line number inside a report or transcript, dropped: not a claim. Where a line number and a date into a transcript were dropped together with the session's own quoted words (347, 357) I marked MINOR and said so.
- A section number of an older version of a living file replaced by the living file's present place, or by the exact sentence at that place, each checked: MINOR, with the numbers named (326, 333). A stricter reader may call these HARM, since a number of the original is no longer said.
- Words that Natural Naming 2.4 releases, changed to the word it gives (*sign* to *parity*, *neighbour*, *run*, *every* to *each*, *membrane* to *the between*): not a change of claim (360, 361, 338, 350).
- "It may change or never be made", on each paragraph that was "A plan, not yet final": taken as the same strength as the old label.
- A present-tense finding of v373 said in the past "at version 373" (338): not a change; the original's own tag dates it, and its "Natural Intelligence 7.2" is a v373 number.

What I did not check. I did not re-verify the facts the original and the new paragraph both state alike (for example the word counts and percentages of 348, the line numbers inside Natural Intelligence Corus of 354, the fifty-one records of 344); I checked only that they are said the same. For 331 and 324 I did not establish why the session dropped what it dropped.
