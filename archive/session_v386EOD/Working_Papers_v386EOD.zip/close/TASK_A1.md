# Task: one section of Living Improving Value, as it was and as it is

Read COMMON.md first.

`LIV_before.md` is `carry/Living_Improving_Value.md` as it was before the session re-said one long section of it (a gathering about a living network surface after a colliding; fifteen headings). `LIV_now.md` is the file now. One reader alone re-said that section, from about 7,900 words to about 3,400, with no second reader. The original words were quoted lines from the person and from a session.

1. Find the re-said section in both files (the headings are the same in both).
2. Under each of its headings, lay BEFORE beside NOW. List every concept, relation, condition, negation, number, example and named place that BEFORE has and NOW does not have, or has weaker, narrower or changed. Also list anything NOW has that BEFORE does not.
3. For each loss, search the other files in /home/claude/corus/carry/ to see whether the lost thing is said at another file (the session said it placed the concepts at `carry/Exhibit_TWO_Offerings_to_Natural_Networking.md` and elsewhere).

Your report: one block for each heading:
```
### <heading>
LOST: <each thing BEFORE has and NOW lacks, quoted from BEFORE; or "nothing found">
AT ANOTHER FILE: <for each lost thing, the file and place where it is said, or "at no file found">
CHANGED OR ADDED: <each thing NOW says differently or adds; or "nothing found">
VERDICT: <SAFE | MINOR | HARM>
```
Then `## SUMMARY` with the count of each verdict and the most serious losses, and `## READING`. Final message: the path of your report and the counts.
