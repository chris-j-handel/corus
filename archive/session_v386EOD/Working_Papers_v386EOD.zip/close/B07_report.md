# B07 report: third reading of items 277 to 322 (46 items, all KIND: RESAID)

Every new paragraph was found in its named file under `/home/claude/corus/carry/`, in the section `## Droplets`, by its bold title. 44 are there word for word with ` — v386EOD` after them; 309 and 315 differ only in the name used for the three files ("these offerings" for "this mate"; "offerings, possibling and carryings" for "mates").

### 277
VERDICT: SAFE
WHAT: —
LOST: —

### 278
VERDICT: SAFE
WHAT: —
LOST: —

### 279
VERDICT: MINOR
WHAT: The old step numbers 139 and 141 are said as steps 226 and 250 of the living Exhibit THIRTY, with the two step sentences quoted. I checked the map: at the v376 registry (commit e0ba214) step 139 is "Six connectors, four across at 2, 6, 10 and 14…" and step 141 is "One entry, six connectors and ten faces are the seventeen names…"; these are the living 226 and 250. "connectors … not faces" is said as "names between selves … none of its ten within one self". Added: that the two pairs are the file's parts 1 and 2 (true at the living TWENTY-TWO headings). No claim lost.
LOST: —

### 280
VERDICT: SAFE
WHAT: —
LOST: —

### 281
VERDICT: SAFE
WHAT: —
LOST: —

### 282
VERDICT: SAFE
WHAT: —
LOST: —

### 283
VERDICT: SAFE
WHAT: —
LOST: —

### 284
VERDICT: SAFE
WHAT: —
LOST: —

### 285
VERDICT: MINOR
WHAT: "at TWENTY-SEVEN 7.10" is said as "at the registry's 7.10" in a sentence that has just named two registries; which registry is meant is no longer said in the sentence itself. Nothing else differs.
LOST: —

### 286
VERDICT: MINOR
WHAT: "at v378" (when the two arrived) is not said; "at none yet" is "at none". The folder is named at `carryings/` where the original had `incoming/` (the folder is at `carryings/` now). All claims are there.
LOST: —

### 287
VERDICT: SAFE
WHAT: —
LOST: —

### 288
VERDICT: MINOR
WHAT: Wording alone. "Reconnection with no crescent is to be met at Eriksson and colleagues' event" is said "is unread at"; "A second next observing is named:" is cut to "A second:"; "unsaid" is added to "three relations". Every relation, name and condition of the source's 6.2 is there.
LOST: —

### 289
VERDICT: MINOR
WHAT: "The session specifies two alternate routes…" is now said as what Exhibit TWENTY-NINE has at 2.9 (the living file does have both sentences there). That the session specified it, and the report it is in (Session_Report_v366 §4), are no longer said. All claims are there.
LOST: —

### 290
VERDICT: SAFE
WHAT: —
LOST: —

### 291
VERDICT: MINOR
WHAT: The source "at v378, from incoming/review_networking_engineering" is no longer named; the naming is "A naming offered". Much is added (bi-tri-volutioning at the entry side, tri-bi-co-momentarying at the resolving side, natural torusing, the Registry's sentence); I found the added matter in the fuller earlier concern at `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 57. "a decision at 4.18's one name" is said as "They part at one name for the one method" with 4.18 quoted. Nothing of the original is lost.
LOST: —

### 292
VERDICT: SAFE
WHAT: —
LOST: —

### 293
VERDICT: SAFE
WHAT: —
LOST: —

### 294
VERDICT: SAFE
WHAT: —
LOST: —

### 295
VERDICT: SAFE
WHAT: —
LOST: —

### 296
VERDICT: MINOR
WHAT: The line numbers "176 (three), 178 (two) and on" are said as "three in the first paragraph of its 2.6 and two in the second". I counted in the living file: lines 176 and 178 are those two paragraphs, with 3 and 2 sayings, 12 in all. The line numbers themselves are no longer in the paragraph. All else is there.
LOST: —

### 297
VERDICT: MINOR
WHAT: Step 183 is said as step 309 of the living Exhibit THIRTY (the same sentence; I checked both versions). The labels S42a and S42b are replaced by the two proposed steps' own sentences, which match `cover_EQUILIBRIA.md` lines 199 and 200. "MISSING" is said "at no step". No claim lost.
LOST: —

### 298
VERDICT: SAFE
WHAT: —
LOST: —

### 299
VERDICT: MINOR
WHAT: "Returned to the droplets by a second reader at v381R" is no longer said; in its place is "It is no insertlet:" with the same reason. The title of 3.2, "Five dimensions, each binary in its two directions", is no longer said (3.2 is). The saying and the reason are whole.
LOST: —

### 300
VERDICT: MINOR
WHAT: "Opportunity 3" and "(Session_Report_v378.md, section 3, The opportunities, in order.)" are gone, so the paragraph no longer says this was the third of seven opportunities that session set in order. The content of the opportunity is whole.
LOST: —

### 301
VERDICT: SAFE
WHAT: —
LOST: —

### 302
VERDICT: SAFE
WHAT: —
LOST: —

### 303
VERDICT: SAFE
WHAT: —
LOST: —

### 304
VERDICT: SAFE
WHAT: —
LOST: —

### 305
VERDICT: HARM
WHAT: The words "laid ready" are gone, and the sentence that was laid ready (in italics in the original, the line Session_Report_v381F and Next.md give as Ready) is no longer there in its own words: it is paraphrased, with "the door of a question about living together" said as "An interest in a question about living together opens at it". The paragraph no longer says a line stands ready for this file. Also changed in wording: "its far side *5.4 …*, sound" is "It opens from and arrives back at Natural Intelligence 5.4 … soundly" (the source's column is "far side in Natural Intelligence", so the file named is right); "its loopings *3 under five titles*" is "Its versions are 3 under five titles". The numbers 50 to 60, 60, v329, 3, five titles, +0.71, 130 to 5, 6 and 18 are all there.
LOST: laid ready: *this file is the door of a question about living together, and its released-word load, 50 to 60 per thousand, and its front's form are the first things that interest meets; its motion is in front of the set for that interest.*

### 306
VERDICT: HARM
WHAT: "waits on the session" is gone: the paragraph no longer says whose deciding the word waits on. Added in its place: "One working chose is-next-existing." (this is in the fuller earlier concern at `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 79, "Its reason: one working chose"). "at v379" is also not said. The two words and their parting are there, with more detail than the original had.
LOST: waits on the session

### 307
VERDICT: MINOR
WHAT: The quotation and its place, "The session said at about line 379 (5 October)", are gone; the same content is said in the paragraph's own words, and "The plan is session v381R's" keeps the session as its source. I read line 379 of `carryings/v381R/Session_Transcript_v381R.txt`: it is the assistant's reply, not the person's words, so this is not PERSON'S WORDS. Each claim is there (carries the tags at each motion; does not today, the done in prose; one line, file, sentence, tags; the whole scoreboard; the record's own work; undecided; with the discovery economy).
LOST: —

### 308
VERDICT: HARM
WHAT: Everything said of the carrying's front is gone. The original was aimed at two places, the carrying's front and the Method's 2.8; the new paragraph has 2.8 alone. Gone: what the front says, and the count of the front's forms, 52. The Method's 268 and *met* 52, *carried* 45, *taken* 24, *placed* 10 are there. I searched the whole carry file for "arrived is its standing" and "52 such": neither is in it.
LOST: The front says *Arriving, Improving, Living* at its three steps and then *arrived is its standing* … The front carries 52 such forms

### 309
VERDICT: MINOR
WHAT: "at v380" is not said; "or abundancing at 12 alone" is "or abundancing at 12, each sharing's changing, with the offered saying a second relation". Much is added (the three places quoted, tri at 9 and 11, co at 17 and 3); the added matter is in the fuller earlier concern at `archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md` line 103. Nothing of the original is lost.
LOST: —

### 310
VERDICT: MINOR
WHAT: The review's "2.6 and 3.4's Bell relation" (sections of the prior v348) is said as "Natural Physics has its Bell relation at 2.7 and at 4.4". I checked the living v379: the relation is at 2.7 (line 172) and 4.4 (line 304), and the quoted sentence is at 4.4. The numbers 2.6 and 3.4 are no longer in the paragraph. "keeps only the field's exclusion as its own result" is said "as the field's own result"; the proposed text's 4.4 step 6 reads that way. Nothing else differs.
LOST: —

### 311
VERDICT: MINOR
WHAT: The review's "3.6's sub-atomic ghost list" (a section of the prior v348) is said as "Natural Physics has, at 4.6". I checked the living v379: both quoted sentences are in 4.6. The number 3.6 is no longer in the paragraph. Nothing else differs.
LOST: —

### 312
VERDICT: SAFE
WHAT: —
LOST: —

### 313
VERDICT: SAFE
WHAT: —
LOST: —

### 314
VERDICT: SAFE
WHAT: —
LOST: —

### 315
VERDICT: MINOR
WHAT: "this file keeps its side at the section named" is said "the proposed text has its side at the section named": the thing that has its side is changed from "this file" to the proposed text. The seams, sections and names are all there.
LOST: —

### 316
VERDICT: SAFE
WHAT: —
LOST: —

### 317
VERDICT: MINOR
WHAT: The original was a quotation of Session Report v377 with that version's step number and names. The new paragraph has no quotation marks, says step 380 as step 522, and says the six names at their living spellings (2-bi-co-bi-offering for 2-bi-co-offering, 6-bi-co-bi-moralizing for 6-bi-moralizing, 5-co-bi-co-competencing for 5-co-competencing, 4-bi-co-bi-sharing for 4-bi-co-sharing, 3-co-bi-co-sharing for 3-co-bi-sharing, 1-co-bi-tri-offering for 1-co-bi-offering). I checked: a note in `carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md` says "380 at 522"; the new spellings are in Natural Intelligence, Exhibit ONE and Natural Naming, and the old are in none of them. The numbers, the pairs 2 and 6, and "three are not" are there.
LOST: —

### 318
VERDICT: MINOR
WHAT: "the handshake at the meeting" is said "the handshake at one number". The rest is whole, with the two living sentences quoted (both found, at Natural Intelligence 2.2 and TWENTY-EIGHT 3.3).
LOST: —

### 319
VERDICT: SAFE
WHAT: —
LOST: —

### 320
VERDICT: HARM
WHAT: Three things of the original row are not in the new paragraph. (1) The order of the four joint forms, (+,+)→(−,+)→(−,−)→(+,−), is "the four joint forms round". (2) "40 has no Unsure line, but it builds on 38 (Unsure: odd and even enter at one to nine)" is "step 58 building on step 52": the Unsure line is gone. (3) "Old code: +/− pairs, 'changing of two signs'" is gone. What I found beside this: the sign order is in another paragraph of the same carry file (line 73, a Concern on the order of the four joint forms); the +/− finding is in an older paragraph still in the file (line 203, "Old code still in TWENTY-EIGHT"); the living step 52 has no Unsure line and no "odd"/"even" now; "changing of two signs" is not in the living TWENTY-EIGHT now, and the +/− line is. The step numbers 26, 37, 40, 38 and 142 are said as 37, 51, 58, 52 and 254; I checked each against the v376 registry and each is the same step.
LOST: the four joint forms (+,+)→(−,+)→(−,−)→(+,−) round … 40 has no Unsure line, but it builds on 38 (Unsure: odd and even enter at one to nine). Old code: +/− pairs, 'changing of two signs'

### 321
VERDICT: SAFE
WHAT: —
LOST: —

### 322
VERDICT: MINOR
WHAT: "from the session" is not said, so the paragraph no longer says where the concern came from; "at v380l" is not said. "no negation anywhere" is "at each sentence, with no negation". "for this file's conferring" is "the conferring of Natural Naming's names" ("names" is added). The measure, 729 and one in 39, the five phrases, and the archive path are there. I could not find out whether "the session" here means the person; the original has no quoted words of the person.
LOST: —

## SUMMARY

All 46 items are KIND: RESAID. None is RELEASED.

| Verdict | RESAID | RELEASED |
|---|---|---|
| SAFE | 24 | 0 |
| MINOR | 18 | 0 |
| PERSON'S WORDS | 0 | 0 |
| HARM | 4 | 0 |
| COULD NOT CHECK | 0 | 0 |

- SAFE: 277, 278, 280, 281, 282, 283, 284, 287, 290, 292, 293, 294, 295, 298, 301, 302, 303, 304, 312, 313, 314, 316, 319, 321.
- MINOR: 279, 285, 286, 288, 289, 291, 296, 297, 299, 300, 307, 309, 310, 311, 315, 317, 318, 322.
- HARM: 305, 306, 308, 320.
- PERSON'S WORDS: none.

## READING

**How I read.** I laid each pair side by side, claim by claim. For the originals that name a source I opened the source: the review and the report of Natural Physics v377, `cover_EQUILIBRIA.md` and `cover_REGISTRIES.md`, Re-Settling the Living Files, the Natural Intelligence Map, the Resolver Chat, Session Reports v366, v377, v378 and v381F, the kit's TTT09, the v381R transcript, and the before-resolving copies in `archive/carrying_v386EOD/`. I did not edit anything under `/home/claude/corus`.

**The four HARM items, weighed.**
- 308 is the plainest loss: a number (the front's 52 forms) and what the front says are gone, and they are nowhere else in that carry file.
- 320 drops three parts of a table row. Two of them are still findable in other paragraphs of the same file, and one (the Unsure line) is no longer true of the living registry. The +/− finding is still true of the living TWENTY-EIGHT 1.5.
- 306 loses three words, "waits on the session", which say whose deciding it is.
- 305 loses the standing "laid ready" and the laid sentence's own wording; its numbers are all kept. Item 313, from the same session report, keeps "Laid ready at the file's carrying", so the loss at 305 is not the session's general way.

**Numbers re-said to the living files (279, 297, 310, 311, 317, 320).** In these the session replaced an old step or section number with the living one. I checked every one and each points to the same sentence. I marked them MINOR, not SAFE, because the original number is no longer in the paragraph.

**The person's words.** No original in this sample quotes the person or says the person said a thing, so I gave no PERSON'S WORDS verdict. Three things near it that the owner may want to know:
- 291: the source the original named, the networking-engineering review, says "Chris names the method … tri-bi-co-sequential is-or-is-notting". Neither the original paragraph nor the new one says whose naming it is; the new one says "A naming offered".
- 306 and 309: the originals were short pointers ending in "…". The new paragraphs were filled out from fuller earlier concerns in `archive/carrying_v381R/`. Those fuller concerns do quote unpunctuated words under "The session said" (*is-now-advancing or is-still-possibling (this means is not advancing so the binary logic)*; *the names do not show tri arriving. this is social abundancing*). The new paragraphs took the content and say "A saying offered has"; the quoted words and whose they are did not come with it. They were not in the original paragraph either, so by the task's rule this is not PERSON'S WORDS.
- 307: "The session said" there is the assistant's reply at line 379 of the transcript; I read it.
- 322: "from the session" is dropped; I could not tell whether it means the person.

**Source pointers dropped.** In these items the report name and section the original gave is no longer in the paragraph, and nothing else in the paragraph says where it came from: 278, 282, 289, 290, 300, 303, 304, 305, 312, 313, 317, 318, 319. By the task's rule a report name is not a claim, so this alone did not change a verdict.

**Duplicate.** The new paragraph of 301 is in the carry file twice, at lines 169 and 201, word for word. The before-resolving file had the original twice too (lines 173 and 215, one of them re-aimed from Exhibit TWENTY-SIX), so each was re-said to the same words.

**Quotations.** 21 of the 46 new paragraphs have sentences in double quotation marks, 40 quoted strings in all. A search for each exact string in the `*.md` files at the repository root found every one. By hand I checked the place named for the quotations in 278, 279, 280, 289, 290, 291, 293, 296, 297, 306, 309, 310, 311, 313, 318 and 320: each is at the section or step the paragraph names. I found no misquotation.

**Not checked.** I did not check whether the living files' sections say what the paragraphs claim beyond the quoted sentences and the places named above (for example the content of Living Ghost Registry 7.10 in 285, or whether Natural Naming releases *floor* in 293). I did not check the truth of any claim, only whether the new paragraph says what the old one said.
