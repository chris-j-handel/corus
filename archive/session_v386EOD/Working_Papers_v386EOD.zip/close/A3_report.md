# A3 report: a third reading of 60 older paragraphs said again (all KIND: RESAID)

Sample: `A3_sample.txt`, items 1 to 60. Every item is RESAID; none is RELEASED.

### 1
VERDICT: SAFE
WHAT: —

### 2
VERDICT: SAFE
WHAT: —

### 3
VERDICT: MINOR
WHAT: Lost: the place of this item in the session v378 report's list "Open, hardest first", where it was number 2. Added: one worked example of the six partings (*an opening named as a place*, with both seatings quoted); both quotations are exact and at the places named (Natural Naming 4.9; Resolving the Hard Problem Registry, "Ten things named still, one resolving"). "Parting at six of the ten" is kept.

### 4
VERDICT: SAFE
WHAT: —

### 5
VERDICT: MINOR
WHAT: Changed: "Natural Physics 3.6" is now "Natural Physics, at 4.6"; the two quoted sentences are at 4.6 of the living v379, so the new number is right for the file now. Changed: "Natural Physics 1.1 says the difference among societies is scale alone" (present tense, the third saying of the contradiction) is now "At version 348 Natural Physics' 1.1 had …"; I confirmed the v348 text has it at 1.1 and the living v379 1.1 does not. The contradiction is now stated between two sayings, with the third as a dated note.

### 6
VERDICT: SAFE
WHAT: —

### 7
VERDICT: MINOR
WHAT: Changed: "this one could not" (the session tagged v382F) is now "one such session could not merge", and the paragraph's closing tag is now v386EOD, so which session could not merge is no longer said. Added: "the link" is now "the AI link".

### 8
VERDICT: SAFE
WHAT: —

### 9
VERDICT: MINOR
WHAT: Lost: the status "laid ready", and the exact wording of the sentence that was laid ready (it is re-worded, no longer in italics as a ready sentence). "NINE v329 52" is now "52 at version 329" among the released words a thousand; the v381F report's table confirms 52 is that file's released words per thousand at v329. All other numbers and section names are kept; both quoted section titles are exact.

### 10
VERDICT: MINOR
WHAT: Changed: the review's "2.7's" (a section of the prior v348) is now "Natural Physics has, at 2.6" (the living v379); both quoted phrases are in the living 2.6, so the new number is right for the file now, but the paragraph no longer says the value was at the prior's 2.7. Added: "general relativity's success" (it is in the living sentence).

### 11
VERDICT: SAFE
WHAT: —

### 12
VERDICT: MINOR
WHAT: Changed: the step numbers. "Steps 5, 18, 44, 97" is now "6, 25, 65 and 144", and "carried by 5, 44 and 97" is now "6, 65 and 144". I compared the 264-step registry the map was read against (commit 8e24fa8) with the living v380L: each old step's text is the new step's text, so the renumbering is right. Added: the proposed step S25 written out (word for word from `cover_EQUILIBRIA.md`), the section number 2.2, and the fuller quotations (exact, at 2.2).

### 13
VERDICT: MINOR
WHAT: Lost: two quoted sentences, "The Equilibria Registry v377 replaces v375 on its branch, in passes. Nothing is at corus.me until the lead decides." The paragraph now says the front "entered" at version 377 with no "on its branch" and no "until the lead decides". These are the branch standing of v377; the living v380L at the root has that subtitle, five parts and thirty-two sections (I counted). See READING for why this is MINOR and not HARM.

### 14
VERDICT: SAFE
WHAT: —

### 15
VERDICT: SAFE
WHAT: —

### 16
VERDICT: MINOR
WHAT: Changed: "(5.12)" is now "at 5.11". The living Living File Registry v381R has "5.11 Destinies and the expedition continuing" and 5.12 is Transmissioning, societies and human society, so 5.11 is right for the file now, but the number of the original is changed. Lost: the status "laid ready" and the exact wording of the ready sentence. Added: two glosses, "the section it opens from and arrives back at" for the far side and "its versions" for the loopings (both agree with the v381F report). "FOURTEEN v333 55" is now "At version 333 they are 55" (released words per thousand; confirmed in the v381F table).

### 17
VERDICT: MINOR
WHAT: Changed: "the local sign/carry continuation to discover", which the source gives in italics as Exhibit ONE v3621's own phrase, is now "the local continuation of parity and carry, to discover": *sign* is replaced by *parity* inside a phrase reported from another file. Added: "At version 365" as the date of "the living TWO is v359" (the source file is named v365; the living file is v371 now).

### 18
VERDICT: MINOR
WHAT: Lost: "Opportunity 1", its place as first in the session v378 report's "opportunities, in order". Changed: "the review's section 2 met first" is now "section 2 of the review coupled with first"; "its carrying names each pass" is now "The file's offerings, possibling and carryings name each pass" (the sample says "The file's mates").

### 19
VERDICT: SAFE
WHAT: —

### 20
VERDICT: SAFE
WHAT: —

### 21
VERDICT: SAFE
WHAT: —

### 22
VERDICT: MINOR
WHAT: Lost: "(OPEN)" after "the set rests on 2". In the map OPEN means the item rests only on a step with an Unsure line. Step 2 of the living v380L has no Unsure line (the v376 step 2 had one), so the standing no longer holds, but the paragraph does not say it was open. Added: the proposed step S45 written out (it matches `cover_EQUILIBRIA.md`), the section numbers 5.1 and 5.5, and the fuller quotations (exact, at 5.1 and 5.5).

### 23
VERDICT: SAFE
WHAT: —

### 24
VERDICT: SAFE
WHAT: —

### 25
VERDICT: SAFE
WHAT: —

### 26
VERDICT: MINOR
WHAT: Changed: the review's "3.7's diamond form" (a section of the prior v348) is now "Natural Physics has, at 4.7" (the living v379); both quoted phrases are in the living 4.7, so the number is right for the file now, but the paragraph no longer says the value was at the prior's 3.7.

### 27
VERDICT: MINOR
WHAT: Lost: "for both". Added: almost all of the paragraph. The original was one line ("the ten at two seatings — one seating of the ten; with the first"); the new paragraph names the two seatings (Natural Naming 4.9, one name of 1 to 8; Equilibria Registry 3.3, five places with two at each) and a third pairing from Natural Illustrating 2.7. The three quotations are exact and at those sections, and finding 10 of the session v379 report names the same three files. "With the first" is unfolded as the first concern of the same section (4.9's table and Resolving the Hard Problem Registry at different faces); the earlier file confirms that is the first paragraph.

### 28
VERDICT: MINOR
WHAT: Changed: "The core says …" is now two located quotations, one "at its opening" and one "at its imaginable extensions"; both are exact and at those places, and neither is in the section headed "The core". Lost: the source folder `incoming/co_chaining_coverage_v378/` and "the living files read against the co-chaining". "For both" and "entered at version 378" are kept.

### 29
VERDICT: SAFE
WHAT: —

### 30
VERDICT: SAFE
WHAT: —

### 31
VERDICT: SAFE
WHAT: —

### 32
VERDICT: MINOR
WHAT: Lost: "Arrived at v377" (the paragraph now has no version for the arriving), the source `incoming/cohering_ten_and_six_v377/README.md`, sections 5 and 6, and the branch name `working/equilibria-registry-v377`. Every claim about the two registries, the code, the ghost and Living File Registry 4.7 is kept.

### 33
VERDICT: HARM
WHAT: Lost: the attribution and the quotation. The original says this is "a correction the self gave the session at about line 90 (4 October), when the session had drafted a portal", and gives the self's words inside quotation marks. The new paragraph gives the same content as plain statements with no speaker, no quotation marks, no line and no date; "we" and "our method" are gone. The meaning of each clause is kept, and the two closing sentences about a name are kept. The words remain in `carryings/v381R/` but the paragraph no longer points there.

### 34
VERDICT: SAFE
WHAT: —

### 35
VERDICT: HARM
WHAT: Lost: the attribution and the quotation. The original says "The self said the standard every file is read against, at about line 147 (4 October)" and quotes the self; the new paragraph states the standard with no speaker, no quotation marks, no line and no date. Changed: "all the sentences before it" is now "all the sentences ahead of it" in the title and the second sentence; "ahead of" can be read as "after". The first sentence still says "all prior sentences".

### 36
VERDICT: SAFE
WHAT: —

### 37
VERDICT: MINOR
WHAT: Changed: *count* is now *number* ("A count said with its script is a finding" becomes "A number said with its script is a finding"). Lost: the label "learned" and the exact wording of the two italic sentences from the v381F report, which are now paraphrased; "Aimed at a file, Geodesic Improving Method" is no longer said in the paragraph.

### 38
VERDICT: SAFE
WHAT: —

### 39
VERDICT: SAFE
WHAT: —

### 40
VERDICT: SAFE
WHAT: —

### 41
VERDICT: MINOR
WHAT: Changed: "The parting observing is still to be named" is now "No observing parting the reading is named"; the "still to be" is gone. "Count" is now "number" ("fourfold count").

### 42
VERDICT: SAFE
WHAT: —

### 43
VERDICT: SAFE
WHAT: —

### 44
VERDICT: MINOR
WHAT: Changed: "Natural Physics 4.1" is now "Natural Physics' 3.1"; the turn at 60 is at 3.1 of the living v379, so the number is right for the file now. Changed in strength: "its one home is Natural Chemistry" is now "The work is its one home at … Natural Chemistry. It may change or never be made." (The source is a first-draft plan.)

### 45
VERDICT: SAFE
WHAT: —

### 46
VERDICT: SAFE
WHAT: —

### 47
VERDICT: MINOR
WHAT: Changed in strength: "to be read whole" is now "The work is the source read whole. It may change or never be made."

### 48
VERDICT: MINOR
WHAT: Changed: the step numbers. "49, 178–179, 210–211" is now "75, 299, 300, 372 and 374"; "34" is now 46; "42/44" is now 63 and 65. I compared old and new step texts and each corresponds. Lost: two of the three quoted fragments of the registry sentence ("each momentary a fractal universe" and "a universe named as an existing thing is exclusivity"); they are later clauses of the same living sentence at 1.2 whose opening clause is still quoted. Added: the proposed step S7 written out (it matches `cover_EQUILIBRIA.md`, with "of each size" released).

### 49
VERDICT: SAFE
WHAT: —

### 50
VERDICT: HARM
WHAT: Lost: two of the three things the original says. (1) "Natural Intelligence 1.3: Bi-inversioning co-recursioning turning about an empty centre, with the sign at the odd and the coming home at the even, which 6.10 sets the other way: a parting inside the file", with 6.10's "one running, and the odd co-sequencing's empty centre". (2) "1.5 is the source of ONE's two depth-one boundings word for word, bi_arriving bounded from the other-self and bi_offering bounded from society". Only "Odd carries bi-exchanging, the bi- at the odd against the standing rule" is said again. The section numbers 1.3, 1.5 and 6.10 are also gone; the two quotations in the new paragraph are exact, at 2.1 of the living file, with no section named. I searched the files in `carry/` for the lost words ("depth-one", "bi_arriving", "coming home", "sets the other way") and did not find these claims anywhere; the session's record does not list them as released. The living v380R has no 6.10.

### 51
VERDICT: MINOR
WHAT: Added: "The three doors above" is unfolded into the three doors themselves. The text matches session v382F's report (its "breaker's three doors"), except "a second method, met at 1.4" is now "coupled with Natural Intelligence's 1.4" (v382F's exploring file confirms the 1.4 is Natural Intelligence's).

### 52
VERDICT: SAFE
WHAT: —

### 53
VERDICT: SAFE
WHAT: —

### 54
VERDICT: SAFE
WHAT: —

### 55
VERDICT: SAFE
WHAT: —

### 56
VERDICT: SAFE
WHAT: —

### 57
VERDICT: MINOR
WHAT: Changed: "For the Wick rotation it is still to be named" is now "For the Wick rotation no parting observing is named"; the "still to be" is gone.

### 58
VERDICT: MINOR
WHAT: Lost: "Returned to the droplets by a second reader at v381R". The new paragraph says "It is no insertlet" and gives the same reason, but not who returned it or when.

### 59
VERDICT: MINOR
WHAT: Lost: that this is "the session's observing at about line 691 (6 October)", and the quotation marks; the session's quoted words are paraphrased. Changed: "Overspray does not reach them" is now "Droplets laid at more files than needed reach none of the ten", a gloss of *overspray* that the original does not give. All numbers (3,398; 425, 325, 297, 291; 11, 19, 13; versions 329 to 333) are kept.

### 60
VERDICT: MINOR
WHAT: Lost: "as 4.5 now says *given on at 9's line*", the support for the second alternative, with its section number (the living Natural Intelligence 4.5 no longer has those words; I searched). Lost: "a concern for both", the line numbers 963 and 965 (the quotations are still at those lines), and the word "generic". Exhibit ONE's row of 5 is now quoted from "the releasings" on, without the cell "co-competencing" the original gives ahead of it.

## SUMMARY

| KIND | SAFE | MINOR | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|
| RESAID | 32 | 25 | 3 | 0 | 60 |
| RELEASED | 0 | 0 | 0 | 0 | 0 |

HARM: 33, 35, 50.
MINOR: 3, 5, 7, 9, 10, 12, 13, 16, 17, 18, 22, 26, 27, 28, 32, 37, 41, 44, 47, 48, 51, 57, 58, 59, 60.

## READING

**What I did for every item.**
- Confirmed the new paragraph is in the file in `carry/` now. All 60 are there under their bold titles. 57 match the sample word for word; 18, 24 and 27 differ only in the name used for the three files ("these offerings" or "offerings, possibling and carryings" where the sample says "mate" or "mates").
- Confirmed each AS IT WAS is word for word in the file as it was (`archive/carrying_v386EOD/…_before_resolving.md`) and is no longer in the file now.
- Checked every sentence in double quotation marks, not two or three: 58 quotations across 22 items, each an exact string of a living `*.md` file at the repository root. None is misquoted. I also checked the section each is said to be at; all are where the paragraph says.
- Where a new paragraph changed a number or added content, I opened the source the original names (the review and the report of the proposed Natural Physics v377, `cover_EQUILIBRIA.md`, the session reports of v377, v378, v379, v381F and v382F, the re-settling draft, the version 368 sources) and the living file.

**How I drew the lines.**
- SAFE includes paragraphs that only unfold the original's own citation: a path, a file's whole name, the heading of the cited section (for example "the field's record said wrongly, with the record beside it" for the review's 2.1).
- MINOR includes three kinds of change that go beyond wording, each stated in WHAT so they can be re-graded:
  - **A number changed to follow the living file now** (5, 10, 12, 16, 26, 44, 48). In each I confirmed the new number against the living file or, for the registry steps, against the old and new step texts. None is wrong. The original's number is nonetheless gone.
  - **A standing of an earlier moment dropped** (13, 22, 60, and "laid ready" in 9 and 16, a rank in 3 and 18). In 13, 22 and 60 I confirmed the standing no longer holds at the living files. Item 13 is the closest to HARM: two whole quoted sentences, one a condition on the lead's deciding, are not carried.
  - **Content added from the cited source** (3, 12, 22, 27, 48, 51). Each addition agrees with its source.
- HARM is kept for a claim or an attribution of the original that is absent and that I could not show to follow from the living files: the self's own quoted words turned into unattributed statements (33, 35), and two of three claims dropped with no record (50).
- Item 59 has the same pattern as 33 and 35 but the speaker is a session, not the self; I graded it MINOR. If attribution to a session is to count the same, it is a fourth HARM.

**Things true of the whole sample, not graded per item.**
- Every one of the 60 new paragraphs ends "— v386EOD". The original closing tags (resettling_v373, v368_sources, session_v377, session_v378, natural_physics_v377, review_natural_physics_v377, co_chaining_map_v376, v377, v378, v380R, v381F, v381R, v382F and others) are gone. In the Natural Physics items the source is named inside the new paragraph; in many others (for example 6, 11, 17, 20, 29, 31, 36, 38, 40, 44) no source is named at all. The task says a report name is not a claim, so I did not grade this, but a reader of the file now cannot tell from the tag which session a paragraph is from.
- The labels "A plan, not yet final, gathered here at v381R" and "re-aimed from … at v381R" are dropped throughout; I treated them as session labels.
- The closing sentence "It may change or never be made" is on every Possible project (1, 6, 7, 18, 40, 44, 47, 51, 55). I counted it as a change of strength only where the original states the thing as settled or required (44, 47).
- Several words are replaced consistently: *count* by *number*, *met* by *coupled with*, *runs* by *executes*, *before* by *ahead of*, *sign* by *parity*. I flagged these only where the word sits inside something reported from another source (17, 37) or could reverse the sense (35).

**Not done.** I did not re-verify claims that are identical in both versions (for example the eleven line numbers in 53, or the counts in 31 and 59) beyond what is stated above. I did check that the three "at no step" sayings (12, 22, 48) still hold at the living Co-Chaining Logic Registry by search; they do.
