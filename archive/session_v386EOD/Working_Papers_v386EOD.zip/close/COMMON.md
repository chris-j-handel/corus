# What every reader here needs to know

The repository at /home/claude/corus holds a file set called natural intelligence.
- The **living files** are the `*.md` files at the repository root (for example `Natural_Intelligence_v380R.md`, `Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md`). No one edits them here.
- The folder `carry/` holds, for each living file, three files named by their titles: **Offerings to …** (droplets, concerns, insertlets), **Possibling of …** (possible work), **Carryings of …** (observings and gatherings). There is also `carry/Living_Improving_Value.md`.
- `carryings/`, `incoming/` and `archive/` hold sources: earlier sessions' reports and earlier versions.
- One working session, tagged v386EOD, added many sections to the files in `carry/` and changed or removed some older paragraphs there. The person who owns the file set is concerned that this session harmed the files. Your reading is part of an independent audit of that.

Rules for you:
- Do not edit anything under /home/claude/corus. Do not run git commands that change anything (reading with `git show`, `git log`, `git diff` is fine).
- You write exactly one file, your report, at the path your task names.
- Be strict and plain. Say only what you read. If you could not check something, say so. Never guess.
- Every path named with no leading slash in your task is under /tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/close/ .
