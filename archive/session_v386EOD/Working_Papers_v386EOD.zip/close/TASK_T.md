# Task: read the session's transcript whole and find value that is at no file in `carry/`

Read COMMON.md first.

`transcript.txt` is the whole conversation of session v386EOD between the person and the session, as the person saw it (871 lines; the person's messages are the short plain paragraphs, often lower-case and unpunctuated; the session's replies end with "— v386EOD").

1. Read it whole, **from its last message back to its first**, then once forward again so a saying corrected later is taken as corrected.
2. List every thing of value said in it. Most important are the **person's own messages**: each direction about how the work is done, each concept, each naming, each concern, each correction, each wish. Take every person message and list each separate saying in it. Also list findings the session reported that are of value to the file set (a concept, a concern between two files, an observing, a finding about the method), and anything the session said it would do or had found that may never have been placed.
3. For each, check by searching and reading the files in /home/claude/corus/carry/ (use Grep with two or three wordings, then read the place) whether that saying is at a file there: whole, in part, or at no file. A saying counts as there only if the concept is said, not merely a similar word.
4. Do not judge whether a saying is right. Do not leave out a saying because it seems small.

Your report, plain text, one block for each saying, in the order of the transcript:

```
### <number>
WHO: <the person | the session>
LINE: <line number in transcript.txt>
SAYING: <for the person, the exact words quoted; for the session, the finding in one plain sentence>
CONCEPT: <the one thing it says, in a plain clause>
AT A FILE IN carry/: <WHOLE | IN PART | NO>
WHERE: <file name and heading or bold title where it is; or the searches you made that found nothing>
MISSING: <for IN PART or NO: exactly what is at no file>
```

End with a section `## READING`: what you read whole, what you searched, and anything you could not check. Then, as your final message, return only: the path of your report, the number of sayings, and the numbers WHOLE, IN PART and NO.
