# B04 report: third reading of items 139 to 184 (46 items, all KIND: RESAID)

Every new paragraph was found in the file its item names, whole and word for word, with one small difference: item 171 in the file ends "at these offerings of corusing the reach and torusing the gather" where the sample has "at this mate of".

### 139
VERDICT: HARM
WHAT: Three clauses of AS IT WAS are not in AS IT IS NOW. The new paragraph quotes only the first sentence of the living file's paragraph. Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 142 does carry the first two in its own words ("a telling built on past it or a caption changed over it carries the departure on"; "A pace running simple and sequential is whole: one useful explaining and its next relation can be a complete pass, and breadth carries no clarity of its own"), but the new paragraph neither quotes nor points to them. "account for actual outputs when asked" I found in no form in the new paragraph. Also gone: "Carried to the Geodesic Improving Method with the Method Improving Value findings already aimed there." Also changed in strength: "newer ... does not by itself decide improvement" is now the living file's "decides nothing". The original's "the one piece the carry does not yet carry" is now told as the living file having the sentence, which is true (line 142). The three quotations are exact.
LOST: "building further on a superseded mapping or merely correcting its caption does not carry"; "keep the pace simple and sequential: one useful explaining and its next drawing relation can be a complete pass, and breadth does not substitute for clarity"; "account for actual outputs when asked"

### 140
VERDICT: SAFE
WHAT: —
LOST: —

### 141
VERDICT: SAFE
WHAT: —
LOST: —

### 142
VERDICT: HARM
WHAT: AS IT WAS says the two address schemes are "both at the earlier names". AS IT IS NOW says "each scheme at the names now". The condition is turned to its contrary; the new paragraph tells the present living files (both quotations are exact, at Natural Naming 4.9 and Equilibria Registry 3.2) and no longer tells what the version 373 source told. The source sentence is at carryings/resettling_v373/Natural_Naming_at_Exhibit_ONE.md line 194. I could not establish from the files which names are "the earlier names", so I cannot say the new condition is true or false, only that it differs. The rest (two schemes, one home at one scheme at the version 372 faces) is kept, and the section named in the Possibling of Living File Registry exists and has the one-home proposal.
LOST: "both at the earlier names"

### 143
VERDICT: SAFE
WHAT: —
LOST: —

### 144
VERDICT: SAFE
WHAT: —
LOST: —

### 145
VERDICT: SAFE
WHAT: —
LOST: —

### 146
VERDICT: SAFE
WHAT: —
LOST: —

### 147
VERDICT: MINOR
WHAT: "meet the sign changing at the connectors" is now "couple with the parity changing at the connectors". *Sign* into *parity* is Natural Naming 2.4's own release. "meet" into "couple with" is a relation word changed, and I found no release of *meet* in Natural Naming. Also "returned from the image" is now "read from the image", and "so its five centres and two axes stand as numbers" is now "and with that its five centres and two axes as numbers".
LOST: —

### 148
VERDICT: SAFE
WHAT: —
LOST: —

### 149
VERDICT: SAFE
WHAT: —
LOST: —

### 150
VERDICT: SAFE
WHAT: —
LOST: —

### 151
VERDICT: SAFE
WHAT: —
LOST: —

### 152
VERDICT: SAFE
WHAT: —
LOST: —

### 153
VERDICT: SAFE
WHAT: —
LOST: —

### 154
VERDICT: MINOR
WHAT: "the set rests on 2 (OPEN)" is now "the set rests on its step 2"; the mark "(OPEN)", which in cover_EQUILIBRIA.md means the step carried an Unsure line, is not kept. Step 2 of the living Exhibit THIRTY shows no Unsure line now. Added: the text of the proposed step, which AS IT WAS only pointed to as "→ S26"; it is word for word S26 at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md line 171. Both quotations are exact, at Equilibria Registry 2.3.
LOST: —

### 155
VERDICT: SAFE
WHAT: —
LOST: —

### 156
VERDICT: HARM
WHAT: The aim is gone. AS IT WAS opens "Aimed at the set:"; AS IT IS NOW has no aim, and it stands in the Offerings to the Geodesic Improving Method, so it now reads as that file's alone. Items 178 and 180 of this sample keep "It is aimed at the set."; this one does not. Every other claim is whole, and "Offering runs first" is exact at Natural Explaining 1.3.
LOST: "Aimed at the set:"

### 157
VERDICT: MINOR
WHAT: "Step 185" is now "step 311". Checked: the sentence quoted is step 311 of the living Exhibit THIRTY, and step 185 there is now another sentence, so the new number is the true one. Added: the text of the proposed step, which AS IT WAS only pointed to as "→ S41"; it is word for word S41 at cover_EQUILIBRIA.md line 198. Both quotations are exact.
LOST: —

### 158
VERDICT: MINOR
WHAT: "The register's counts ... count from its fifty rows" is now "The register's numbers ... are each numbered from its fifty rows". Wording only; each number and section is kept.
LOST: —

### 159
VERDICT: MINOR
WHAT: The place in the report's order, "section 5 item 1, open, hardest first", is not kept: the new paragraph no longer shows this was the first, the hardest, of the open ones. "two different pairs" is now "two pairs". The question "is that both, one at a time?" is the session's question brought to the lead (Session_Report_v377.md, section 7 item 8), not the lead's own words, and the new paragraph keeps it as open at the expedition's self.
LOST: —

### 160
VERDICT: SAFE
WHAT: —
LOST: —

### 161
VERDICT: SAFE
WHAT: —
LOST: —

### 162
VERDICT: SAFE
WHAT: —
LOST: —

### 163
VERDICT: MINOR
WHAT: "3.6's sub-atomic ghost list" is now "Natural Physics has, at 4.6". Checked: both quotations are exact and sit in 4.6 of Exhibit_EIGHTEEN_Natural_Physics_v379.md; the review's 3.6 was the section of the prior version. The number changed and the new one is true of the living file.
LOST: —

### 164
VERDICT: SAFE
WHAT: —
LOST: —

### 165
VERDICT: MINOR
WHAT: The place in the report's order, "Opportunity 3" of "The opportunities, in order", is not kept. Item 183 of this sample keeps its own ("the second of the opportunities in order"); this one does not.
LOST: —

### 166
VERDICT: SAFE
WHAT: —
LOST: —

### 167
VERDICT: SAFE
WHAT: —
LOST: —

### 168
VERDICT: SAFE
WHAT: —
LOST: —

### 169
VERDICT: HARM
WHAT: The first of the two claims is not in AS IT IS NOW; the new paragraph tells only the order of the four joint forms. What I found beside it: the living Equilibria Registry's ring table now says "moving one self on at each second momentary" (Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md line 227), so the parting the lost claim told is met at the living file; and an older paragraph still in the same carry file (line 77, tagged v378) says the same parting. The new paragraph says neither. For the second claim, "Lines 123 and 327" are now "1.5" and "5.2"; all three quotations are exact and sit in those sections and in Natural Intelligence 2.4.
LOST: "The rows at lines 214 to 219 run the odd spiral's zero one self each momentary; at the code it moves one self at each second momentary, as Resolving Hard Problems 4.4 says."

### 170
VERDICT: SAFE
WHAT: —
LOST: —

### 171
VERDICT: MINOR
WHAT: "Ready, at v380R" is not kept; it is now a Concern. Added: what the five sayings say (torusing in and out at the odd, corusing in and out at the even), "8 and 16 the two torusings", and the reading that they part "at the parity of torusing and of corusing". Checked against Natural Naming 3.6 and 3.2: the three quotations are exact and the added reading agrees with those sections.
LOST: —

### 172
VERDICT: MINOR
WHAT: The place "5.x, line 391" is not kept; the new paragraph names the file only. The sentence is still at line 391, in section 5.3, of the living Geodesic Improving Method. Both quotations are exact.
LOST: —

### 173
VERDICT: SAFE
WHAT: —
LOST: —

### 174
VERDICT: MINOR
WHAT: Added, none of it in AS IT WAS: "discovering next possible living by", "offered for each living file, Exhibit ONE Natural Resolver's stable forms first", and "is adopted at no living file". Each agrees with carryings/review_networking_engineering_2026-09-30/Tri_Bi_Co_Sequential_Is_Or_Is_Notting_Correction.md line 22, which the new paragraph does not name. Not kept: the place in the report's order, "Open, hardest first, 7". The original does not say whose naming it is, so this is not a case of the person's words lost here; I note only that the source named above says the person names it.
LOST: —

### 175
VERDICT: HARM
WHAT: Two things of the list are gone. AS IT WAS has four words to re-say, "*face*, *connector*, *join* and *the code*"; AS IT IS NOW has three, with no *the code*. AS IT WAS has pointers by line into three files, "Natural Intelligence, Natural Mathematics and the Resolving the Hard Problem Registry"; AS IT IS NOW has two, with no Natural Intelligence. What I found beside it: the living Equilibria Registry (v380L) has no "the code" at all and no pointer by a line into Natural Intelligence, so the two dropped things are no longer in the living file to re-say. The new paragraph does not say so. The three pointers it quotes are exact.
LOST: "and *the code*"; "Natural Intelligence," in "each pointer by line into Natural Intelligence, Natural Mathematics and the Resolving the Hard Problem Registry"

### 176
VERDICT: SAFE
WHAT: —
LOST: —

### 177
VERDICT: SAFE
WHAT: —
LOST: —

### 178
VERDICT: SAFE
WHAT: —
LOST: —

### 179
VERDICT: SAFE
WHAT: —
LOST: —

### 180
VERDICT: SAFE
WHAT: —
LOST: —

### 181
VERDICT: SAFE
WHAT: —
LOST: —

### 182
VERDICT: SAFE
WHAT: —
LOST: —

### 183
VERDICT: SAFE
WHAT: —
LOST: —

### 184
VERDICT: HARM
WHAT: "for both" is gone. AS IT WAS is a concern "for both"; AS IT IS NOW does not say whom it is for. Items 162 and 164 of this sample keep "It is a concern for both."; this one does not. The same new paragraph, without "for both", is also in the Offerings to Natural Numbers and to Natural Physics. Every other claim is whole, and all four quotations are exact, at Natural Physics 3.1, Natural Numbers 7.1 and Natural Chemistry 4.4.
LOST: "for both"

## SUMMARY

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|---|
| RESAID | 30 | 10 | 0 | 6 | 0 | 46 |
| RELEASED | 0 | 0 | 0 | 0 | 0 | 0 |

- HARM: 139, 142, 156, 169, 175, 184
- PERSON'S WORDS: none
- MINOR: 147, 154, 157, 158, 159, 163, 165, 171, 172, 174

The six HARM items are of three sorts, and they do not weigh the same:
- **Something lost that I found nowhere in the new paragraph or said for it:** 139 (three clauses; two of them are in the living file in other words, one is not), 156 (the aim at the set), 184 ("for both").
- **A part dropped that the living file has since met:** 169 (the ring table now says each second momentary) and 175 (the living file has no *the code* and no line pointer into Natural Intelligence). The drop agrees with the living file, but the new paragraph does not say that it dropped anything or why.
- **A condition turned to its contrary:** 142 ("both at the earlier names" now "each scheme at the names now"). I could not check which is true.

## READING

- I laid each pair side by side, claim by claim, and counted as a claim each relation, condition, negation, number, named place, aim and "for whom". I did not count a session's label, a report's name or a file path as a claim.
- I gave HARM wherever a clause of the original is absent from the new paragraph or changed in it, even where the living file now agrees with the drop; I say in WHAT what I found beside it. A reader who counts only losses to the file set would count three of the six (139, 156, 184), with 142 undecided.
- I gave MINOR for a changed word, a changed section or step number that I checked to be true of the living file, a lost place in a report's order, and an addition that I checked against its source.
- No item in this sample quotes the person's own words in AS IT WAS. Three come near and are not such a case: 140 is addressed to the expedition's self, 156 tells that the self released a thing, 159 has the session's question brought to the lead. Each keeps the expedition's self in the new paragraph.
- Quotations: I checked every double-quoted sentence in 18 of the 46 items (139, 142, 151, 153, 154, 156, 157, 159, 161, 163, 164, 166, 169, 170, 171, 172, 175, 184) against the `*.md` files at the repository root. Every one is exact. For the sentences that name a section I also confirmed the section. I did not check the one quotation in 178. The other 27 items have no double-quoted sentence.
- Additions I checked at their source and found true: the review's heading for 141, 173 and 176; the report's headings for 155, 168 and 179; the moved folders for 152 and 160; the four files of version 368 and the new place of the checks for 167; the plan's 1.5 and Natural Intelligence's 1.3 for 149; the two section names of Exhibit ONE at version 372 for 146; the section titles for 145; *middling* and *rating* at Natural Naming 2.4 for 153.
- Not checked: for 147 I did not find the Rings in Motion kit itself, so the original wording there rests on the sample alone. For 142 see above.
- I edited nothing under /home/claude/corus and ran no git command that changes anything. This report is the only file I wrote.
