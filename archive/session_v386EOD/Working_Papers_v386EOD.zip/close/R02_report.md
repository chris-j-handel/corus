# R02 report: third reading of 35 released paragraphs (items 36 to 70)

Sample: R02_sample.txt. Every item is KIND: RELEASED. Nothing under /home/claude/corus was edited; git was read only.

### 36
VERDICT: SAFE
WHAT: —
LOST: —

### 37
VERDICT: SAFE
WHAT: —
LOST: —

### 38
VERDICT: SAFE
WHAT: —
LOST: —

### 39
VERDICT: SAFE
WHAT: —
LOST: —

### 40
VERDICT: MINOR
WHAT: The concept is whole at the named droplet ("The ambient is the transmissioning." at carry/Exhibit_SIX_Offerings_to_Natural_Transmissioning.md line 169). What is not there now is "receives from Natural Intelligence": the reason says the section "says each is from the resettling of version 373, 'its released Natural Intelligence, its map'", but that sentence was taken out of the mate by the later commit 36cfd58, and no line of the mate now names Natural Intelligence or the map as where this came from. Natural Intelligence v380R has "ambient" at no line (checked), so the giving file is told nowhere in the living files or this mate.
LOST: —

### 41
VERDICT: SAFE
WHAT: —
LOST: —

### 42
VERDICT: SAFE
WHAT: —
LOST: —

### 43
VERDICT: SAFE
WHAT: —
LOST: —

### 44
VERDICT: SAFE
WHAT: —
LOST: —

### 45
VERDICT: SAFE
WHAT: —
LOST: —

### 46
VERDICT: SAFE
WHAT: —
LOST: —

### 47
VERDICT: MINOR
WHAT: Two of the three placings are met where the reason says (φ as the rate at Natural Mathematics 2.8; the transmissioning at the mate's droplet). The first, "local and ambient kept at unrelationing, 6.1", is a placing at Natural Intelligence: Natural Intelligence v380R has no "ambient" and no "local and ambient", and no paragraph of any carry file has "local and ambient" now; the content is at Natural Naming 5.41 ("One rate carries the two: unrelationing at the bounding outward, the local, and *uni-versal* at the arriving one on, the ambient") and in the mate's droplet. The reason says this plainly. One statement of the reason is wrong: it says Natural Intelligence v380R has "unrelationing rate" at no line; it is at line 220, section 3.5 ("**φ is the unrelationing rate**"). As at 40, the mate no longer says the droplet is from the map.
LOST: —

### 48
VERDICT: SAFE
WHAT: —
LOST: —

### 49
VERDICT: SAFE
WHAT: —
LOST: —

### 50
VERDICT: SAFE
WHAT: —
LOST: —

### 51
VERDICT: SAFE
WHAT: —
LOST: —

### 52
VERDICT: SAFE
WHAT: —
LOST: —

### 53
VERDICT: SAFE
WHAT: —
LOST: —

### 54
VERDICT: MINOR
WHAT: Released on the session's own judgement that the v385A paragraph misread its source. I read the source (archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md line 29, "The round is not derived, and enters this file at none.") and it does read as "at no place of the file", so the judgement holds as far as I can read. The named places say the deriving is unmade (Possibling line 71, "its deriving from the seventeen names or the resolver's lines is the part unmade"; mate line 307, "none of the round's four parities is a value at a line"). Not at either place in any words: "That scope remains an unresolved concept; it is not a grade or a completed universal derivation" ("not a grade" and "universal" are at neither). The pointer's target, Carryings "The earlier four-parity deriving extent · v385A", is still there and still has "the round was not derived at none".
LOST: —

### 55
VERDICT: SAFE
WHAT: —
LOST: —

### 56
VERDICT: SAFE
WHAT: —
LOST: —

### 57
VERDICT: SAFE
WHAT: —
LOST: —

### 58
VERDICT: MINOR
WHAT: Up by eight and down by eight are at the living tables (Exhibit ONE line 481, "each move 8 up (n + 8), 8 down (n − 8) or 17 less (17 − n)"; line 590; a row "8 up" or "8 down" at each name), and the Equilibria Registry 3.2 column "Odd ascending / even descending" is still there. The living file does not say in words "Those opening at an even name come down by eight": at the two four-cycles opening even it says "going 17 less first", and the 8 down is only readable from the numbers (2-15-7-10, 4-13-5-12).
LOST: —

### 59
VERDICT: SAFE
WHAT: —
LOST: —

### 60
VERDICT: SAFE
WHAT: —
LOST: —

### 61
VERDICT: HARM
WHAT: Two sentences of the paragraph are at none of the three named places. (1) The negation about the torus outputs: the named section "Current correcting beside the older forms · v385A" has only "A released parity and a private living momentary remain distinct subjects", which is weaker and is not about those outputs; "inferab…" is at no line of any carry file, and the nearest sayings are of other subjects (mate line 103, of the v380A proposal, "claims neither universal inference nor its impossibility"; Carryings line 75, "inferred no universal living relation from the counts"). (2) The direction "The concept to follow is which prior distinction the later expression preserves or no longer distinguishes" is at no carry file; the named droplet "A torus coming to one, withdrawn as a break" (mate line 263) gives a later saying on the subject ("A self's prior is whole at its carrying next and its shared changing together") and not the direction. The pointer's target (Carryings "Reported code comparisons from session v383Op · v385A") is whole.
LOST: Those outputs do not identify another self’s private momentary or establish its inferability or impossibility. (Also not there: The concept to follow is which prior distinction the later expression preserves or no longer distinguishes.)

### 62
VERDICT: SAFE
WHAT: —
LOST: —

### 63
VERDICT: MINOR
WHAT: The fact is kept at the paragraph just before it (mate line 147, "In the code one name is a parity in one function and a list in another.") and widened at the named droplet (line 299), and the pointer's target is at Possibling line 33. The standing "remains a naming concern" is said at neither: both are laid as plain droplets.
LOST: —

### 64
VERDICT: SAFE
WHAT: —
LOST: —

### 65
VERDICT: SAFE
WHAT: —
LOST: —

### 66
VERDICT: SAFE
WHAT: —
LOST: —

### 67
VERDICT: PERSON'S WORDS
WHAT: The paragraph says the reading is of "the lead's words on natural intelligence in the between", "as suggested". Natural Intelligence 4.10 has the reading whole ("**The between is its empty centre, a nothing and no location, existing as the universe exists, as its things exist, while the six names between selves are resolving, and the resolver says it at 0**", with "a nothing and no location" kept and "no existing thing" gone), but does not say it is a reading of the lead's words, and this mate now says it nowhere. Session Report v377 itself notes the subject moved (line 28: *natural intelligence is only existing in the between* entered as *the between is existing*). The lead's words are whole, with "Suggested at v377", at the living Equilibria Registry 1.3 (line 76) and at carry/Session_Record.md line 2010; they are not at Natural Intelligence or at either Natural Resolver or Natural Intelligence mate by search.
LOST: —

### 68
VERDICT: SAFE
WHAT: —
LOST: —

### 69
VERDICT: MINOR
WHAT: The named droplets say the parts in the lines' own order (mate line 305: "2, 14, 3, 12, 10, 11 and the next 3, and between selves 10 with 6 and 9, through 5"; line 275: one function gives on at 6, 10 and 9; line 311 and the Co-Chaining mate line 452: the along and then the across, "given at no step"), and the second reader's reason is carried by them. Not at any of them: the count "eight", the walk as one sequence opening at "the self opening carrying, 3", and the step "the society's releasing arriving along at 17 from 9, tri" (17 is in none of the named droplets' orders). These are the parts the second reader had already returned as an order the file does not say.
LOST: —

### 70
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

35 items, all RELEASED.

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | All |
|---|---|---|---|---|---|---|
| RELEASED:RESOLVED | 17 | 2 | 1 | 0 | 0 | 20 |
| RELEASED:SAID | 6 | 4 | 0 | 1 | 0 | 11 |
| RELEASED:NOVALUE | 4 | 0 | 0 | 0 | 0 | 4 |
| All | 27 | 6 | 1 | 1 | 0 | 35 |

- HARM: 61
- PERSON'S WORDS: 67
- MINOR: 40, 47, 54, 58, 63, 69

## READING

How I read. For each item I opened the place the reason names and laid the paragraph beside it claim by claim. I confirmed by search that each of the 35 paragraphs is gone from its mate now. I read the older text of the mates from git (the commits before b0e3658, 8031c4e and 6911ea1) where I needed the paragraph in its place.

What I checked and found as the reason says.
- 36: the living Natural Naming has both quoted sentences (5.62, line 1569; 3.1, line 365). The mate's v385A paragraphs are there (lines 382 and 384), and line 382 has the person's exact correcting, "so odd parity is now changing or still existing", which is the word the paragraph waited on. Paragraph 33 with "v380R's gathered value" is kept (line 151). The paragraph itself did not quote the person.
- 37, 44, 48, 50: the four rows are whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (lines 112, 33, 25, 89). The living Equilibria Registry has no "full carrying", "sign(r", "membrane" or "next discovering" at any line, and has the sentences quoted (lines 533, 86, 68, 235). The version 375 lines 223 and 350 are as quoted. Steps 17, 18, 27, 99, 103, 254, 327, 467 of the Co-Chaining Logic Registry v380L are as quoted with no unsure line under them.
- 43: step 17, 18 and 327 are as quoted, and none of the registry's seventeen unsure lines has "bi and co". "(lead)" in this row is the lead part of the Hard Problem Registry file, a place, not the person: the source table's column gives places ("lead; the whole file"), and the sentence is at the living Hard Problem Registry line 13. So this is not a person's words item.
- 38: the heading had only "*At v378's receiving of the proposal.*" under it and then two paragraphs each titled "Concern, at v378"; it covered nothing ready.
- 39: the root has none of the six files named; the Registry rows and files.json are as quoted; the source table is whole at carryings/v368_sources/Wrap_v368.md lines 9 to 19. "Keep or archive, for you to decide" is answered by the Registry listing Corus as a living file, not by a quoted word of the person.
- 41, 49: both are a session's standing of itself (Session_Report_v377 line 257; Session_Report_v378 section 2); carry/Session_Record.md line 2022 has the merge at pull request 113.
- 42: Natural Naming v380R has neither name at any line; the registry pair has both headings.
- 45: each of the twelve rows and the 4.5 sentence is at Natural Illustrating (lines 348, 567 to 578); the places it names are at their files.
- 46: the three Registry places are as quoted (lines 74, 202, 625).
- 51: Natural Illustrating line 140 and Natural Naming 5.48 line 1383 are as quoted.
- 52, 62: the Co-Chaining mate's two v385A sections (lines 179 to 189) are there and carry the subject, "no two similar things" and the common beat; the Possibling section at line 29 has "it is not a supplied universal pace". At 52 the open "one parity, or two" is said there as a direction ("are not made identical by the word parity"), from the later v385A working.
- 53, 56: the named droplets and concerns are at the lines the reason gives (mate 311, 327; Co-Chaining mate 440, 452, 462; Possibling 73); Resolving Hard Problems line 199 is as quoted.
- 55, 59: each is a pointer, and its target has the content (Carryings lines 43 to 49; Living File Registry mate line 313 to 319).
- 57: the living code has three functions, the third named `_17_co_bi_tri_offering`; the two rows and the two sentences quoted are there; `_17_social…` is at no line.
- 60, 64, 65, 66: these are rows of the "Form | Binary it carries | Natural Intelligence explaining through it" table of carryings/resettling_v373/Exhibit_ONE_at_its_Stable_Forms.md, section 4, whole there (lines 79 to 97). The living Exhibit ONE has the headers quoted. At 60 and 64 the columns "entry, connector or face", "outward or inward", "facing and joining" and "at the code, at the self and at the society" are at no living table: they are released as gone, not as said, which is what the reason states. The Carryings (line 45) record an earlier session counting those words as narrating yet in the table.
- 68: the living table "Co received, tri given on, 8 up" and row 17's sides are as quoted, and the two kept paragraphs are at mate lines 85 and 127.
- 70: the same paragraph, word for word, is at four mates now (Co-Chaining Logic Registry line 61, Natural Naming line 384, Resolving Hard Problems line 83, Natural Intelligence Corus line 361). It is not at Offerings to Natural Intelligence now, where the reason says a copy is.

Things in the reasons that are not so now.
- 40 (and 47): the sentence the reason leans on for where the droplet came from is gone from the mate since commit 36cfd58.
- 47: "unrelationing rate" is at Natural Intelligence v380R line 220.
- 70: no copy at Offerings to Natural Intelligence.

What I did not check.
- The step numbers carried across numberings (37: 37 and 187 said to be 51 and 343; 50: five steps said to be 210, 226, 250, 255, 264). I read the v380L steps and they have no unsure line; I did not find a table that proves the old numbers map to them.
- Paragraphs named only by number in the reasons (13, 22, 33, 38, 70, 90, 91). Where I name a kept paragraph above I found it by its words, not by its number.
- Most of the reasons' "no pointer found" statements. I searched only for 38 and 39.
- Quotations: checked in about twenty of the 35 items, as the task allows; every one I checked is an exact sentence of the file named, apart from the three statements listed above.
