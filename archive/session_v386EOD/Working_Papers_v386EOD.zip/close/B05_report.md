# B05 report: a third reading of 46 older paragraphs said again (all KIND: RESAID)

Sample: `B05_sample.txt`, items 185 to 230. Every item is RESAID; none is RELEASED.

### 185
VERDICT: HARM
WHAT: The last sentence of the original is gone from the new paragraph and from every file in `carry/` (it is still in the source, `carryings/resettling_v373/Re-Settling_the_Living_Files.md`, line 173). Also changed: "Natural Intelligence 8.6" is now "Natural Intelligence 5.4". 8.6 was the v373 number of *Two methods parting at the precise place*; the living Natural Intelligence v380R has "5.4 Two methods parting at the now", so the new number is right for the file now, but the number of the original is changed. Added: "Corus Part 16" is now "Natural Intelligence Corus Part 16" (that file has a Part 16, Natural Writing), and "Exhibit ONE" is "Exhibit ONE Natural Resolver".
LOST: Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there.

### 186
VERDICT: SAFE
WHAT: —
LOST: —

### 187
VERDICT: SAFE
WHAT: —
LOST: —

### 188
VERDICT: MINOR
WHAT: Changed: the original is headed "Concern, where it arrives" (in the source it is one line under "7 Concerns for both"); the new paragraph is a "Possible project" and ends "It may change or never be made". Added: "an entry offered for Natural Engineering", the title of Natural Engineering 2.3 (exact, at 2.3), and "the text carried by selves" as what step 2's rings are (the source's step 2 is titled "The text carried by selves"). Each claim of the original is kept.
LOST: —

### 189
VERDICT: MINOR
WHAT: Lost: the section number "1.1" (the new paragraph says only "the opening section's sentences"); "at v379, for both" as a label. Changed: the whole sentence of Natural Intelligence, given in full in the original, is now two pieces of it; "A set is defined by its existing things", "of the universal set of existing things" and "and no size is its own" are not quoted (the sentence is whole in the living file at 1.1). Natural Naming's sentence is cut to "null and infinity + 1"; the original gave it as ending "and no number names it", which the living Natural Naming does not say at that sentence. Changed: "the two numbers are the sentence's own way of saying no number bounds it" is now "the two say no number bounds the set", so "the two" no longer says it is the two numbers.
LOST: —

### 190
VERDICT: SAFE
WHAT: —
LOST: —

### 191
VERDICT: SAFE
WHAT: —
LOST: —

### 192
VERDICT: SAFE
WHAT: —
LOST: —

### 193
VERDICT: MINOR
WHAT: Changed: "Step 42" is now "step 63". The registry the map was read against (v376) has at 42 the sentence the living v380L has at 63, word for word, so the new number is right for the file now. Added: the section number 1.3 (right), the full sentence of step 63 (exact), and the proposed step S10 written out (it matches `carryings/co_chaining_map_v376/cover_EQUILIBRIA.md`; the map's "(after 80)" is not carried). The label "S10" is not in the new paragraph.
LOST: —

### 194
VERDICT: MINOR
WHAT: Lost: the word "learned:" ahead of the two sentences, and that they were given in italics as sentences of the session's own text; lost "Aimed at a file, Geodesic Improving Method" (the paragraph is in that file's offerings). Each claim and each number (3 to 11, 10 to 14, 9, 2) is kept.
LOST: —

### 195
VERDICT: MINOR
WHAT: Added: "at 2.4" for Natural Naming's row (right: the row is in 2.4), "By session v381F's computing" and "at Natural Intelligence" for the far side (the v381F text says the far side is computed and is a section of Natural Intelligence), "its versions" as a gloss of loopings, and "Exhibit TWENTY-SIX Living File Registry's" for "the Registry's" 4.7 (right: the retitling is at that file's 4.7). Changed: "sound" is now "read as sound"; "laid ready" is now "ready at it is". Nothing of the original is lost.
LOST: —

### 196
VERDICT: MINOR
WHAT: Lost: the section number "3.2" for the twenty-four (the sentence is at 3.2 of the living file), and the place of the item as number 3 in the session v378 report's "Open, hardest first". Added: almost all of the paragraph. The original was one line naming three things; the new paragraph says the third as two quoted sayings and where they part, and names the other two beside it. What is added agrees with the living files (the four ways with joint forms still two, one, one and none at Natural Intelligence 2.4; step 506 of the Co-Chaining Logic Registry; "one twenty-four at both" at 3.2).
LOST: —

### 197
VERDICT: MINOR
WHAT: Not in the new paragraph: the eight earlier names (10-other-surfacing, 11-other-chaining, 12-other-surplusing, 13-social-neutralling, 14-social-crossing, 15-social-corusing, 16-social-torusing, 17-social-abundancing) and the five code names (`bi_co_surfacing`, `co_bi_carrying`, `bi_co_tunneling`, `bi_co_inversioning`, `bi_co_inseparating`). The new paragraph points to "Natural Naming's table of the seventeen names, each with its gathered name and its gathered code name"; I opened that table (living Natural Naming v380R, 3.3) and each of the eight earlier names and five code names is there at its number. So the pairing of each v373 name with its earlier name can be made only by number through the living table; it is no longer said in the paragraph. The eight v373 names and the eight counts (65, 57, 36, 11, 68, 12, 39, 27) are kept. See READING.
LOST: —

### 198
VERDICT: SAFE
WHAT: —
LOST: —

### 199
VERDICT: PERSON'S WORDS
WHAT: The original says "The self said what must happen before an arriving AI meets Exhibit ONE's code, at about line 70 (4 October)" and quotes the self: "this is the flawless experience and immediate understanding of the reasons for the differences between science method explaining and natural intelligence explaining of observings of nature. we need this to happen before the ai starts testing the code in exhibit one and declaring the intelligence missing as the code does nothing." The new paragraph says the same thing in the session's wording, with no quotation and no saying that the self said it. The session's own two quoted phrases are also now unquoted. Every claim is kept (the need, the order observed, the finding read as a refutation, Natural Intelligence 2.5 and 3.3, the portal's work, the open question). The self's words are in no file of `carry/` now; they are still at `carryings/v381R/Session_Transcript_v381R.txt` line 70 and `carryings/v381R/Close_Droplets_v381R.md`.
LOST: —

### 200
VERDICT: MINOR
WHAT: Added: "The proposed Natural Physics of version 377 has, at its 4.11". The original says only "4.11's readings" with the tag v380R. The source is the review of the v377 proposal (section 3, item 4), so the addition is right, but it narrows a bare "4.11" to the proposed text. Each of the three readings and "said at the field's kind or released" is kept.
LOST: —

### 201
VERDICT: SAFE
WHAT: —
LOST: —

### 202
VERDICT: SAFE
WHAT: —
LOST: —

### 203
VERDICT: SAFE
WHAT: —
LOST: —

### 204
VERDICT: SAFE
WHAT: —
LOST: —

### 205
VERDICT: MINOR
WHAT: Changed: "The register's two namings" is now "two of the namings of Natural Physics' register". Added: "the two-way and the rate" (the report says this in the sentence after concern 4 of its 6.1) and "They part at the face of each". The places (Natural Naming 4.9, the Resolving the Hard Problem Registry, the report's 6.1 concern 4, the review's section 3 item 7) are kept.
LOST: —

### 206
VERDICT: SAFE
WHAT: —
LOST: —

### 207
VERDICT: SAFE
WHAT: —
LOST: —

### 208
VERDICT: MINOR
WHAT: Changed: "Steps 13; 212" is now "15 and 379". The v376 registry has at 13 and 212 the sentences the living v380L has at 15 and 379 (15 with one word changed, "changes" to "is changing"), and step 379 has an Unsure line, so the new numbers are right for the file now. Added: the section numbers 2.1 and 3.4 with the full sentences (exact, at those sections), the proposed step S22 written out (it matches `cover_EQUILIBRIA.md`), and "The step may change or never be made". The label "S22" is not in the new paragraph.
LOST: —

### 209
VERDICT: MINOR
WHAT: Lost: "for both" and "finding 10" of v380L. Changed: "waits on Natural Naming's one sense per foundation word" is now "Its resolving is by … *One sense per foundation word*". Added: the two quoted sentences (exact; the first at Natural Numbers 1.4) and "each adding a next".
LOST: —

### 210
VERDICT: MINOR
WHAT: Lost: "v381R found" (the site having no sentence of its own is now said flat, with no session named), and the aim note "For the site, the README or incoming's README, re-aimed from this file". Added: where the two lines and the first sentence are, `carryings/v382F/Session_Report_v382F.md` (they are there, each "in the self's words"), and "It may change or never be made". "In the self's words" is kept as "each in the words of the expedition's self"; the original quoted no words of the self.
LOST: —

### 211
VERDICT: SAFE
WHAT: —
LOST: —

### 212
VERDICT: SAFE
WHAT: —
LOST: —

### 213
VERDICT: SAFE
WHAT: —
LOST: —

### 214
VERDICT: SAFE
WHAT: —
LOST: —

### 215
VERDICT: MINOR
WHAT: Added: almost all of the paragraph. The original was one line ("tri-bi-co-bi-tri — a naming of its own or 9's and 17's names said together"). The added text is from the tour's finding 7 and its note on v380A (`archive/session_v380/v380R/Tour_A_Living_Self_Is_A_Carrying.md`), and the Natural Naming quotation is exact. One added clause is not a whole sentence: "17's name said incoming and 9's name each tri-bi-co" (the tour has "are each tri-bi-co", and a second half the new paragraph leaves out). Lost: "its seventh finding" as a place. Both readings of the original are kept.
LOST: —

### 216
VERDICT: SAFE
WHAT: —
LOST: —

### 217
VERDICT: MINOR
WHAT: Added: almost all of the paragraph. The original was one line with "…" in it. The added text follows an earlier, fuller form of the same concern (`archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md`, line 89), and the Natural Naming quotation is exact. Changed: "waits on Exhibit ONE's carrying naming a place" is now "Its resolving is a place named at Exhibit ONE Natural Resolver's offerings, possibling or carryings". Lost: "at v379" as a label. See READING on the words that earlier form quoted.
LOST: —

### 218
VERDICT: SAFE
WHAT: —
LOST: —

### 219
VERDICT: SAFE
WHAT: —
LOST: —

### 220
VERDICT: MINOR
WHAT: Lost: "Returned to the droplets by a second reader at v381R". The new paragraph says "A row offered" and keeps the reason word for word in substance ("a rule in the form of a row", the three words at the file's own voice, the two terms the file does not carry), but no longer says the row was returned by a second reader. The row's two cells are kept whole.
LOST: —

### 221
VERDICT: SAFE
WHAT: —
LOST: —

### 222
VERDICT: MINOR
WHAT: Lost: "from Exhibit ONE's cells mended at the resolver's own lines, for this file and for both workings" (where the concern came from and whom it is for). Changed: "Its reason: the resolver's lines carry one handling at the three names" is now "They part at the handling at the three names, two at the sentence and one at the resolver's lines". Added: "9 and 17" for the along names and the two exact sentences of Natural Intelligence. Both readings are kept.
LOST: —

### 223
VERDICT: SAFE
WHAT: —
LOST: —

### 224
VERDICT: SAFE
WHAT: —
LOST: —

### 225
VERDICT: SAFE
WHAT: —
LOST: —

### 226
VERDICT: SAFE
WHAT: —
LOST: —

### 227
VERDICT: SAFE
WHAT: —
LOST: —

### 228
VERDICT: MINOR
WHAT: Lost: "v381R found" (the site having no sentence of its own is now said flat, with no session named). Added: where the two lines and the first sentence are, `carryings/v382F/Session_Report_v382F.md` (they are there), and "It may change or never be made". "In the self's words" is kept as "each in the words of the expedition's self"; the original quoted no words of the self. The new paragraph is the same text as item 210's.
LOST: —

### 229
VERDICT: MINOR
WHAT: Lost: the place of the item as number 4 in the session v378 report's "Open, hardest first". Changed: "Open" is now "unresolved". Added: one exact phrase of the Geodesic Improving Method for each of the three partings. Each of the three partings and "the doer open at Natural Intelligence 1.4" is kept.
LOST: —

### 230
VERDICT: MINOR
WHAT: Changed: the review's "3.7's and 5.8's named breaks" (sections of the prior v348) is now "Natural Physics has, at 4.7 … and, at 3.4" (the living v379). Both quoted sentences are in the living v379 at 4.7 (the Wick rotation) and at 3.4 (the light-cone), so the new numbers are right for the file now, but the paragraph no longer says the breaks were at the prior's 3.7 and 5.8. "Prior value lost", the proposal's 3.13 and 4.7, the report's 6.2 and the review's 2.3 item 6 are kept.
LOST: —

## SUMMARY

| KIND | SAFE | MINOR | PERSON'S WORDS | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|---|
| RESAID | 25 | 19 | 1 | 1 | 0 | 46 |
| RELEASED | 0 | 0 | 0 | 0 | 0 | 0 |

HARM: 185.
PERSON'S WORDS: 199.
MINOR: 188, 189, 193, 194, 195, 196, 197, 200, 205, 208, 209, 210, 215, 217, 220, 222, 228, 229, 230.
SAFE: 186, 187, 190, 191, 192, 198, 201, 202, 203, 204, 206, 207, 211, 212, 213, 214, 216, 218, 219, 221, 223, 224, 225, 226, 227.

## READING

What I did.
- I laid AS IT WAS beside AS IT IS NOW for all 46 items, claim by claim.
- I opened each carry file and found each new paragraph. All 46 are there now, inside the section `## Droplets`, each ending "— v386EOD". 43 match the sample to the letter. Items 196, 216 and 217 differ from the sample only where the sample says "this mate's" or "mates" and the file says "these offerings'" or "offerings, possibling and carryings".
- Quotations: 21 of the 46 new paragraphs have text in double quotation marks (188, 189, 191, 193, 195, 196, 203, 206, 208, 209, 211, 213, 215, 217, 220, 221, 222, 224, 226, 229, 230), 41 quotations in all. One script looked each up in the `*.md` files at the root of /home/claude/corus, ignoring italic asterisks. All 41 are found, in the file the paragraph names. For 191, 193, 196, 203, 208, 209, 213 and 230 I also checked the section, step or line number given: all agree. Many are phrases, section titles or parts of a sentence, not whole sentences (for example 188 and 195 are section titles; 189, 206, 221, 224 and 229 are phrases).
- Where a new paragraph says more than the old one, or changes a number, I opened the source: `carryings/resettling_v373/` (185, 188, 197, 201, 225), `carryings/co_chaining_map_v376/cover_EQUILIBRIA.md` and the v376 registry by `git show 8e24fa8` (193, 208), `carryings/v381F/v381F/` (195, 206), `carryings/session_v378/` (196, 229), `carryings/session_v377/` (187, 212), `carryings/natural_physics_v377/` and `carryings/review_natural_physics_v377/` (200, 205, 207, 216, 219, 230), `carryings/review_networking_engineering_2026-09-30/` (198), `carryings/v382F/` (210, 228), `archive/session_v380/v380R/` (215), `archive/carrying_v381R/` (217), `carryings/v381R/` (199). Every addition I list is in its source or in the living file; I found none that is made up.

What I did not check.
- I did not check whether the original paragraphs were true.
- For 186, 190, 192, 202, 204, 211, 214, 218, 221, 223, 224, 226 and 227 I compared the two texts (and the living files, for quotations) and did not open the source the old paragraph came from.
- 209: I did not open the v380L finding 10. 222: I did not open the resolver's lines.

How I drew the lines.
- Source names in brackets, "re-aimed from …" notes, identifiers such as PP07 and TTT09, "A plan, not yet final, gathered here at v381R" and the closing tags are not counted as claims, as the task says.
- 185 is the one HARM: a whole sentence of the plan, a release it names (Natural Intelligence 8.7's sentence paragraph to Explaining 2.1), is in no file of `carry/` now. The living Natural Intelligence v380R has no section with 8.7's title; that may be why it was left out, but the new paragraph does not say so, and the rest of the same plan is kept as a possible project.
- 199 is the one PERSON'S WORDS: the self's two quoted sentences and "The self said" are gone, and every claim is whole.
- 197 is the item nearest to HARM that I gave MINOR. Eight earlier names and five code names are no longer in the paragraph. I gave MINOR because the new paragraph points to the living table that has each of them at its number, and I checked each is there. If a pointer to a living file is not counted as keeping them, 197 is HARM, and its LOST line would be the eight "earlier …" names and the five code names listed under WHAT.
- Section and step numbers changed to the living file's numbering (185: 8.6 to 5.4; 193: 42 to 63; 208: 13 and 212 to 15 and 379; 230: 3.7 and 5.8 to 4.7 and 3.4). In each, the new number is where the living file has the sentence today. I gave MINOR and said so, because the number of the original is changed.
- "For both", a session named as the finder ("v381R found"), a place in a session report's ordered list ("Open, hardest first, 3"), and a status word ("learned", "Returned … by a second reader") are counted MINOR when gone (189, 194, 196, 209, 210, 220, 222, 228, 229).
- Paragraphs that are mostly added text, the original being a short pointer, are MINOR with the source named (196, 215, 217).
- "Possible project … It may change or never be made" on an original that was a plan or an aim is counted SAFE (186, 192, 198, 201, 202, 223, 225); on 188, where the original was headed a concern, MINOR.
- Exhibit numbers and full file names added to a bare file name are not counted as additions.

Other things seen.
- No new paragraph denies anything in its original.
- 217: the earlier, fuller form of this concern (at `archive/carrying_v381R/`) quoted words as "The session said …": *this will also help us describe the bi and tri and co of all the changings and the podaling and looping stories will match up and this will be in natural naming as annotating the forms in exhibit one*. The paragraph the session replaced (AS IT WAS) did not have those words, so nothing was lost at this step; the new paragraph gives them as "A saying offered has …", not as a quotation and with no speaker.
- 187: "as suggested" in the session v377 report marks a suggestion from the lead; the marker is kept in the new paragraph. The original quoted the session's report, not the lead.
- 223: the new paragraph is in `carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md` twice, at lines 169 and 201, the same text. The file before the session (`archive/carrying_v386EOD/…_before_resolving.md`) also had the old paragraph twice, at lines 173 and 215, so the doubling is not new.
- 205: the same file has a second paragraph with the same bold title, at line 142, with other text (it replaces a different older paragraph). The item's paragraph is at line 270.
- 210 and 228: one new text is in two files (`Offerings_to_Natural_Arriving.md` and `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md`). 221 and 224: one original was in two files, and the two new paragraphs differ in wording but not in claims.
