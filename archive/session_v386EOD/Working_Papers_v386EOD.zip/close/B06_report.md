# B06 report: third reading of older Droplets paragraphs said again (items 231 to 276)

Sample file: B06_sample.txt. 46 items, all KIND: RESAID. Nothing under /home/claude/corus was edited.

### 231
VERDICT: SAFE
WHAT: —
LOST: —

### 232
VERDICT: MINOR
WHAT: The original gives the words inside quotation marks with a place, "at about line 860 (6 October)", and the label "Aimed at a section, Geodesic Improving Method". The new paragraph has neither the quotation marks, the line place, nor that label, and says the quoted words again in other words ("it is where overspray earns its keep" is now "droplets laid across more files than needed earn their value at it"; "which is the right form" is now "the right form"). Each claim is there: one reader per released word or dissolved naming with the same eight words, all 33 files, the old resolver names, *ring* said as closure, the five dimensions and the ten, the mechanical pass, the map and no sentence, 84 places, four section titles with line numbers. I read `carryings/v381R/Session_Transcript_v381R.txt` line 860: the quoted words are the session's reply to the person's question at line 854, not the person's own line, so this is not PERSON'S WORDS.
LOST: —

### 233
VERDICT: SAFE
WHAT: —
LOST: —

### 234
VERDICT: MINOR
WHAT: The new paragraph adds a clause the original does not have: "growth halting at motion and light carried as form, an observing from a field said more strongly than the field says it". I found its matter in the earlier form of this concern at `archive/carrying_v381R/Exhibit_SEVENTEEN_Natural_Biology_v380R.md` line 63 ("a plant in wind halts its growing, and a plant the stable form carrying light ... the arrival says it more strongly than the field does"). The original's label "Concern" is now "Droplet", and its source, "from v380G/README.md", is gone. "received at the field's finding of growth changing under mechanical stress, or released; neither chosen" is whole.
LOST: —

### 235
VERDICT: MINOR
WHAT: The original is a quotation of Session Report v377, 3.4, with that report's names. The new paragraph says the six names at the names of the living files now: "5-co-competencing" is "5-co-bi-co-competencing", "12-bi-tri-parity-changing" is "12-bi-tri-bi-entraining", "4-bi-co-sharing" is "4-bi-co-bi-sharing", "6-bi-moralizing" is "6-bi-co-bi-moralizing", "14-bi-tri-moralizing" is "14-bi-tri-bi-moralizing", "3-co-bi-sharing" is "3-co-bi-co-sharing"; "loops" is "four-cyclings". Each number (2, 3, 4, 5, 6, 12, 14, nine less, two steps) is the same. "Of the five pairs of the ten" is added. The report's section number 3.4 is gone. I found the new names in the living files (Natural Naming 4.9, Natural Intelligence, Exhibit ONE) and the old sentence at `carryings/session_v377/` line 148.
LOST: —

### 236
VERDICT: SAFE
WHAT: —
LOST: —

### 237
VERDICT: SAFE
WHAT: —
LOST: —

### 238
VERDICT: SAFE
WHAT: —
LOST: —

### 239
VERDICT: SAFE
WHAT: —
LOST: —

### 240
VERDICT: SAFE
WHAT: —
LOST: —

### 241
VERDICT: SAFE
WHAT: —
LOST: —

### 242
VERDICT: SAFE
WHAT: —
LOST: —

### 243
VERDICT: MINOR
WHAT: The original says where the finding was made and where it is in the report: "section 6.1, found beside the register, carried in the second report". The new paragraph has none of the three; it names the report's folder alone. The claim itself is whole and said more fully: the two files put the two-way and the rate at opposite faces, and 5.11's pairs paragraph leans on the second file's faces and names that file. The new sentence "each is at even at the one file and at odd at the other" is not in the original; I read Natural Naming 4.9 (two-way even, rate odd) and Resolving the Hard Problem Registry line 35 (a rate at the even face of five, a two-way at the odd face of six) and it agrees with them. All eight quotations are in the living files as given.
LOST: —

### 244
VERDICT: SAFE
WHAT: —
LOST: —

### 245
VERDICT: HARM
WHAT: Two of the original's four defects are gone, and the two sections of the garbled sentences have other numbers: "3.7 and 5.4" is now "4.7 and 5.6". What I checked: the original was written of the version 348 text (read from git commit 0eef2d2), where 3.7 is the relativity section and 5.4 the Born section; in the living Natural Physics v379 those subjects are at 4.7 and 5.6. In v379 the doubled "sign-only, sign-only" is at no line, and the register is 5.11 with its contents title and heading alike. So the new paragraph says the defects as they are at v379. I could not check that two garbled sentences are at 4.7 and 5.6 now, the original not saying which sentences. No other paragraph of `carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md` has the two defects that are gone. The source, "Re-Settling the Living Files, §11 Defects", is gone as well. Both quotations at 2.5 are in the living file.
LOST: "5.13's contents title and heading differ; *sign-only, sign-only* (1.2) and two garbled sentences at 3.7 and 5.4."

### 246
VERDICT: SAFE
WHAT: —
LOST: —

### 247
VERDICT: SAFE
WHAT: —
LOST: —

### 248
VERDICT: PERSON'S WORDS
WHAT: The original says "The session said the premise of the resolver: the self carrying was living and parity alternating prior and *must continue this through next*". At `carryings/v380R/For_The_Workings.md` line 61 this is the first of "The session's sayings at this working, each whole", an unpunctuated quotation, and `archive/session_v380/v380L/Session_Transcript_v380L.txt` line 1535 has it as "the premise you gave v380R". The new paragraph says "A premise of the resolver is offered beside it" and no longer says who said it; the italic of *must continue this through next* is gone and the words are changed a little ("alternating prior and must continue" is now "alternating at prior, and must continue"). Each claim is otherwise whole: the two sentences of Natural Intelligence, the one way of sixteen at each of the four joint forms in one going round, the two sayings, and the premise saying must continue. Two labels are gone, "for both" and the source `incoming/v380R/For_The_Workings.md`; "from outside the method" is "from beyond the method".
LOST: —

### 249
VERDICT: MINOR
WHAT: "17-tri-co-offering" is said at its name now, "17-co-bi-tri-offering" (found in Natural Naming). "at Exhibit ONE's code" and "a pacing the code does not carry" are now "At Exhibit ONE Natural Resolver" and "a pacing the resolver does not carry": the word code is gone twice. "said so or released" is now "The execution is said at that need or released". "the proposal" is named as the proposed Natural Physics of version 377; I read that text's 3.4, and it has "The beat and the locking range at close paces are to be executed at each spiral pacing its own". The common beat at Natural Intelligence 3.5 is unchanged.
LOST: —

### 250
VERDICT: SAFE
WHAT: —
LOST: —

### 251
VERDICT: MINOR
WHAT: "Step 44" is now "65". I read both: step 44 of the version 376 registry (git commit of v376) and step 65 of the living Co-Chaining Logic Registry v380L are the same sentence, "Each resolving is all or none at all, of no size beside another resolving." "MISSING" is now "neither saying is at a step". "→ S27" is gone as a key, and S27's own sentence is written whole in its place; I read it at `carryings/co_chaining_map_v376/cover_EQUILIBRIA.md` line 172 and it is the same. The source place, "cover_EQUILIBRIA.md, Table A §2 item 37", is gone, so the new paragraph no longer points to the map. "The step may change or never be made" is added. Both quotations are at Equilibria Registry 2.3.
LOST: —

### 252
VERDICT: SAFE
WHAT: —
LOST: —

### 253
VERDICT: MINOR
WHAT: An emphasis difference: the original has the released things in one list of equal standing; the new paragraph puts "its namings of other exhibits" first and the words after "beside". Two things of Natural Naming are added (a quoted sentence, and rows, with *read* and *reading* "released as a resolving's own act"). The label "(re-aimed from Exhibit TWENTY-TWO Offerings to Resolving the Hard Problem Registry at v381R)" and the source "Wrap_v368.md, §4" are gone. The same new paragraph is three times in `carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md`, word for word, at lines 199, 207 and 211.
LOST: —

### 254
VERDICT: SAFE
WHAT: —
LOST: —

### 255
VERDICT: SAFE
WHAT: —
LOST: —

### 256
VERDICT: SAFE
WHAT: —
LOST: —

### 257
VERDICT: SAFE
WHAT: —
LOST: —

### 258
VERDICT: SAFE
WHAT: —
LOST: —

### 259
VERDICT: SAFE
WHAT: —
LOST: —

### 260
VERDICT: HARM
WHAT: The original names two places that carry the cube's matter and says the note dissolves into them. The new paragraph names neither; it names a third place, Natural Mathematics 3.6, and its words: "none of them a total" is now the quotation "none of them a size", and the corner and edge parities, which the original has at Equilibria Definitions v363, are now "the corners' and the edges' among them" at Natural Mathematics. What I checked: the living Natural Intelligence v380R has the cube at no line of its 6.6; Natural Mathematics v380L 3.6, line 253, has "three conservings, two totals modulo three and modulo two and one parity, none of them a size". So the new paragraph points at where the living files have it now, and the original's places and its "dissolves into those two" are gone. The rest is whole: Natural Exploring 5.4's two sentences (both found there), one twelfth, the twelve parting by three conserved books, three and not four, and the join carried on at Natural Exploring alone. The labels BB05, KK03 and the source file are gone.
LOST: "Natural Intelligence 6.6 already carries the cube's three conservings, none of them a total, and Equilibria Definitions v363 its corner and edge parities, so the note dissolves into those two"

### 261
VERDICT: MINOR
WHAT: "entering waits on the full intake at the form" is now "The work is the entering of each at the full intake at the form alone": a waiting is said as the work, and "alone" is added. The new paragraph parts the nine into "Two tensions changed" (the proton radius and the muon assessment) and "the wider collection" (the other seven); the original says "The changed standings and the wider collection" and then the nine in one list. I found that parting in the earlier form at `archive/carrying_v381R/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v380R.md` line 17. "resolved in part at A, not numbered here" is now "others of those droplets insertlets at these offerings". All nine things, C12 and C17, and the ten screening questions going to Resolving Hard Problems are there.
LOST: —

### 262
VERDICT: SAFE
WHAT: —
LOST: —

### 263
VERDICT: SAFE
WHAT: —
LOST: —

### 264
VERDICT: HARM
WHAT: The original's last sentence is at no place in the new paragraph, and I found it at no other paragraph of the files in `carry/`. One number is changed: "Natural Intelligence 8.6" is now "Natural Intelligence 5.4". What I checked of the number: at version 373, 8.6 is *Two methods parting at the precise place* (`carryings/resettling_v373/Natural_Intelligence_Map.md` line 150), and the living Natural Intelligence v380R has *Two methods parting at the now* at 5.4, so it is the same section at its number now. The living Natural Intelligence has no Part EIGHT. The label "(re-aimed from Exhibit TWENTY Offerings to Natural Naming at v381R)" and the source are gone. The rest is whole.
LOST: "Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there."

### 265
VERDICT: HARM
WHAT: The same original as 264, at another file, with the same loss: the last sentence is gone, and "Natural Intelligence 8.6" is now "Natural Intelligence 5.4" (the same section at its number now, as at 264). "the combined Exploring" is now "the combined Natural Exploring and Geodesic Improving Method"; the plan has "the combined Exploring and Improving Method" (`carryings/resettling_v373/Re-Settling_the_Living_Files.md` lines 91 and 130), so this is the plan's own name said longer. The rest is whole.
LOST: "Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there."

### 266
VERDICT: MINOR
WHAT: Gone: the place inside 2.4, "(the *so-far*, *not-yet* row)"; the section's name, "Released words, each with its carrying"; the label "Returned to the droplets by a second reader at v381R"; and the words "in one insertlet" of the reason. The original's sentence "At the facings of the six names between selves the two are said at prior, now and next" is in the new title alone. The four sayings with their numbers (2 and 14; 6 and 10; 9; 17), the overlap read from one side with no second direction, the rows of *neighbour* and *right*, *left*, and the reason (the first a reading said as a fact; 2 and 14 arriving, 6 and 10 sharing across; 3.1 having 9 and 17) are whole.
LOST: —

### 267
VERDICT: MINOR
WHAT: Added, and not in the original: "the two one", and the sentence "They part at the 0: a between and a changing that is not are two words at one 0." "waits on Natural Naming's one word at 0" is now "The one word at 0 is Exhibit TWENTY Natural Naming's to decide". The source, `incoming/v380R/For_The_Workings.md`, is gone. The two sayings (the between the bi-coupling and the 0 its changing that is not; or 1.4's sentence re-said) are whole, and the quotation is at Natural Numbers 1.4.
LOST: —

### 268
VERDICT: SAFE
WHAT: —
LOST: —

### 269
VERDICT: SAFE
WHAT: —
LOST: —

### 270
VERDICT: SAFE
WHAT: —
LOST: —

### 271
VERDICT: SAFE
WHAT: —
LOST: —

### 272
VERDICT: HARM
WHAT: A clause is turned round. The original says of the two address schemes "both at the earlier names"; the new paragraph says "each scheme at the names now". The original's "the ten's one home carries one scheme at the v372 faces" is now "One home for the ten, at one scheme at the faces of version 372, is the earlier proposal at Possibling of Living File Registry, *Earlier ten-conception gathering and address arrangement*": a home that carries a scheme is said as an earlier proposal. Added, and not in the original: "Natural Naming has one name of 1 to 8 at each, and Exhibit TWENTY-EIGHT Equilibria Registry a name of 2 to 6 with the name eight up". The source, "Natural Naming at Exhibit ONE, §8", is gone; I read it at `carryings/resettling_v373/Natural_Naming_at_Exhibit_ONE.md` line 194, and it is the original word for word. Both quotations are in the living files, at Natural Naming 4.9 and Equilibria Registry 3.2, and the section named is at `carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md` line 349. I did not check whether each scheme is in truth at the names now.
LOST: "both at the earlier names; the ten's one home carries one scheme at the v372 faces."

### 273
VERDICT: SAFE
WHAT: —
LOST: —

### 274
VERDICT: SAFE
WHAT: —
LOST: —

### 275
VERDICT: SAFE
WHAT: —
LOST: —

### 276
VERDICT: SAFE
WHAT: —
LOST: —

## SUMMARY

All 46 items are KIND: RESAID. No item is KIND: RELEASED.

| VERDICT | RESAID | RELEASED |
|---|---|---|
| SAFE | 30 | 0 |
| MINOR | 10 | 0 |
| PERSON'S WORDS | 1 | 0 |
| HARM | 5 | 0 |
| COULD NOT CHECK | 0 | 0 |

- HARM: 245, 260, 264, 265, 272.
- PERSON'S WORDS: 248.
- MINOR: 232, 234, 235, 243, 249, 251, 253, 261, 266, 267.
- SAFE: 231, 233, 236, 237, 238, 239, 240, 241, 242, 244, 246, 247, 250, 252, 254, 255, 256, 257, 258, 259, 262, 263, 268, 269, 270, 271, 273, 274, 275, 276.

## READING

**What I did.** I laid each AS IT WAS beside its AS IT IS NOW, claim by claim. For each item I searched the file named in `carry/` for the new paragraph's bold title.

**The new paragraphs are in the files.** All 46 are there now. 44 are word for word as the sample gives them. Two differ in the name used for the three files and in nothing else: 261 ("at these offerings" in the file, "at this mate" in the sample) and 263 ("Natural Societies' offerings, possibling and carryings" in the file, "Natural Societies' mates" in the sample). The paragraph of 253 is in its file three times.

**Quotations.** 16 items have sentences in double quotation marks in the new paragraph. I checked every quotation of ten of them (236, 243, 245, 247, 251, 254, 255, 260, 267, 272) against the `*.md` files at the repository root: each is there exactly, and each is in the section the paragraph names. I did not check the quotations of 238, 248, 253, 257, 266 and 275.

**The five HARM items are of one kind.** In each, the session said the old paragraph again as the living files are now, and something the original says was dropped or turned on the way.
- 264 and 265 (one original at two files) lose a whole sentence, about Natural Intelligence 8.7 and Natural Explaining 2.1. This is the plainest loss in the sample.
- 245 loses two of four defects. Both are no longer in the living Natural Physics v379, so the record that they were found is what is gone.
- 260 puts a third place (Natural Mathematics 3.6) where the original names two (Natural Intelligence 6.6 and Equilibria Definitions v363). The living files agree with the new place.
- 272 turns "both at the earlier names" into "each scheme at the names now". I did not check which is true of the files today.
The original text of each is in `archive/carrying_v386EOD/`, in the files named `…_before_resolving.md`; I saw that folder and two of its files in search results and did not read them through.

**Numbers and names said at their present form.** Where the same thing has a new number or name in the living files and nothing else is lost, I gave MINOR and said what I checked: 235 (six resolver names), 249 (the name at 17), 251 (step 44 now step 65, the same sentence).

**Source labels.** Many new paragraphs no longer name the report, section or session the original came from (for example 231, 237, 240, 244, 247, 253, 276). The task says a report name is no claim, so this alone did not change a verdict; where it stood with other differences I named it in WHAT. A reader of the new paragraph of 231, 237, 240, 244 or 276 cannot tell from it where the matter came from.

**"It may change or never be made."** Ten items are now titled "Possible project" and end with this sentence (237, 244, 250, 252, 256, 261, 262, 264, 265, 273); 251, titled "Droplet", ends with "The step may change or never be made". Their originals are lines of plans (Re-Settling the Living Files, the carry set of version 368, the co-chaining map), or are labelled "A plan, not yet final". I read the sentence as the session's label for a plan and not as a weakening.

**The person's words.** I looked for them in each item. One item has them: 248. Two others quote a session's or an arrival's words that are not the person's own: 232 (the session's reply, checked in the v381R transcript) and 234 ("The arrival says", a report of another session).

**What I could not check.** At 245, whether two garbled sentences are at 4.7 and 5.6 of the living Natural Physics. At 272, whether each address scheme is at the names now, and the added "1 to 8" and "2 to 6 with the name eight up". At 233 and 271, 246 and 257, I did not open Session_Report_v378.md; the new paragraphs there add nothing to their originals. At 240, 242 and 244 I did not open Carry_Set_v368_README.md, for the same reason.
