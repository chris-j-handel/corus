# A6 report: sections the session added, each laid beside its source

Sample: A6_sample.txt, 22 items, 50 paragraphs read (the first six of a section where it has more).
Every sentence in double quotation marks in these 50 paragraphs was searched as an exact string in the 34 `*.md` files at /home/claude/corus: each one is there (71 quotations, 0 missing). I did not check by script that each is in the very file its paragraph names; at each paragraph where I read the living sentence in its place, it was.
Where a verdict is FAITHFUL and the WHAT line is not a dash, the note says a small thing a reader may want; it does not change the verdict.

### 1.1
TITLE: Droplet · The one move's three and a momentary's order.
VERDICT: FAITHFUL
WHAT: —

### 1.2
TITLE: Droplet · A changing of two at a non-living thing.
VERDICT: FAITHFUL
WHAT: —

### 1.3
TITLE: Droplet · Further places of a released word at the Registry's steps.
VERDICT: NOT FOUND
WHAT: In part. The named source, carryings/v380R/, has one line of this, Natural_Naming_Conferring.md line 23: "*Rest*, *round* and *meet* are among the released words and are yet in the Registry." The paragraph's particulars are in no file of carryings/v380R/: steps 386 and 649, step 308, and the section numbers 2.3 and 2.4 (searched for 386, 649, 308, "rest of two beats"). They are true at the living files: Registry v380L step 386 has "met at its own momentary alone", step 649 "each parting met by one back", step 308 "a rest of two beats at a spiral"; Natural Naming 2.4 has the row "*met*, *meet*, *meeting*" and 2.3's landing row has "*rest*". So nothing is invented, but the particulars are the session's own reading of the living files and not its named source. The source also names *round*, which the paragraph leaves out.

### 2.1
TITLE: Droplet · Three seekings at a field's hard problem.
VERDICT: STRONGER
WHAT: The body is as the source has it (carryings/genome_duplication_v374/Session_Report_v374_Part_Two.md line 373, and the ten items at lines 369 to 391). The last sentence is moved out of its place and widened. The source says, at line 304, of sodium chlorate crystals from a stirred solution (chemistry, "Which hand, from a perfect balance"): "balance is the accounting over momentaries" and "Each sample is all or none; the half across samples is the accounting." The paragraph, in a droplet about pharmacology's hard problems, says "a balance is an accounting over momentaries, and each single case is all or none at all." "Each sample" of one crystallizing has become "each single case", and the solution's balance has become a balance with no subject. In the pharmacology part the source's own all-or-none sentence is narrower, line 326: "Each receptor opens all or none; the graded curve is the accounting over members."

### 3.1
TITLE: Concern · Harm at an emanation's own scale.
VERDICT: FAITHFUL
WHAT: —

### 3.2
TITLE: Droplet · One society as two spirals, of dividing.
VERDICT: STRONGER
WHAT: Source, carryings/v380L/Gathered_Value_1.md line 49: "two spirals crossed are one society; with the crossing join opened they are two beside each other, each self inward carrying its own throughout; *no file says this of dividing; it is my offering*", and "Kind: an idea said once." The paragraph says it as fact, does not carry "it is my offering" or "an idea said once", and adds a clause the source does not have: "no carrying is parted, and each of the two is whole" (searched for "parted", "is whole", "one carrying as two" across carryings/v380L/; the clause is at no file). It does carry "none says them of dividing".

### 3.3
TITLE: Droplet · Shown not possible at prior, at no step.
VERDICT: FAITHFUL
WHAT: — (The source, Gathered_Value_1.md line 45, has only that the parting "is at no step of the Registry". The rest of the paragraph re-says the Equilibria Registry's own sentence, line 140, and the Registry's step 25; the living sentence has "each arriving next is met at its next" and the paragraph has "shown at its next".)

### 3.4
TITLE: Droplet · This file's negating sayings, at five.
VERDICT: FAITHFUL
WHAT: —

### 3.5
TITLE: Droplet · Step 171, the round fixed by its two podals.
VERDICT: FAITHFUL
WHAT: — (The source, closing_drafts/Round_At_Four_Parities_Deriving.md lines 194 to 200, gives 72 placings with 17 less one parity alone and 24 with 9 less as well, "the 24 namings of four parities ... of one round". "Three apart from naming" is 72 over 24, a figure the source does not print. I worked it by arithmetic: 2,688 rounds, 72, 24; three rounds and one round apart from naming. It is right.)

### 3.6
TITLE: Droplet · The fourth parity the span, the four together odd or even.
VERDICT: FAITHFUL
WHAT: —

### 4.1
TITLE: Possible project · Fifteen sentences of Natural Intelligence said again plainly.
VERDICT: FAITHFUL
WHAT: — (The source, carryings/v383Op/Presentation.md, lists the fifteen with no sections. The paragraph's count by section, 1, 1, 3, 2, 4, 3, 1, was checked at Natural_Intelligence_v380R.md: each of the fifteen is in the section the paragraph names.)

### 5.1
TITLE: Droplet · A correction as wide as the claim corrected.
VERDICT: FAITHFUL
WHAT: —

### 6.1
TITLE: Droplet · Two gatherings of the fields' hard problems, neither naming the other.
VERDICT: FAITHFUL
WHAT: — (The source, carryings/v380R/Natural_Naming_Beside_Receiving_Exhibits.md lines 204 to 208, is headed "A helper's reading, unreviewed", and it searched the registries "by several key phrases". I checked its two findings at the living files: none of the eight cluster names and none of the four invisibles is at Exhibit TWENTY-ONE or TWENTY-TWO as a naming, and neither Natural Naming nor Exhibit TWENTY-TWO names the other. "Neither file names the other" is not a sentence of the source; it is true at the files.)

### 7.1
TITLE: Droplet · A resolving followed whole, with the concern it opens.
VERDICT: FAITHFUL
WHAT: — (The source is the person's saying quoted at carryings/v380L/Gathered_Value_1.md line 25, and that file's "an improving followed whole and the concern it relocates said with it". The words "through each sentence it changes at each file, ahead of its offering" are the paragraph's own spelling out; the source has "we can not chase this by only offering partially considered concerns each pass".)

### 8.1
TITLE: Possible project · The rounds followed one scale at a time.
VERDICT: FAITHFUL
WHAT: —

### 8.2
TITLE: Possible project · A 0 followed to its receiver, then whose prior.
VERDICT: FAITHFUL
WHAT: —

### 8.3
TITLE: Possible project · Relations for two opposite rotations through parity's square.
VERDICT: FAITHFUL
WHAT: —

### 9.1
TITLE: Droplet · Readers of one training, agreeing.
VERDICT: FAITHFUL
WHAT: —

### 10.1
TITLE: Concern · A prime's third parting said as a divided number.
VERDICT: FAITHFUL
WHAT: —

### 11.1
TITLE: Droplet · An offering from beyond, a five apart from the six.
VERDICT: STRONGER
WHAT: The case and its line, +, 0, −, +, +, are as the source has them (carryings/v380A/illustrating/Concept_And_Consistency.md line 60; Progress.md line 90). The source says of it: "This is a hand derivation from the twelve cells and the receiving at the next momentary, not a resolver execution. It clarifies the opening needed for the six-form teaching; it asserts no parting of the method." The paragraph carries neither sentence. I followed the case at the resolver's lines in Exhibit_ONE_Natural_Resolver_v380R.md by hand (not executed) and reached the same five, so the figures are right; what is dropped is the source's own word on how the case was reached and what it does not claim.

### 12.1
TITLE: Concern · The number two, completing or an arriving.
VERDICT: FAITHFUL
WHAT: —

### 13.1
TITLE: Droplet · A second reader's one question at each insertlet.
VERDICT: FAITHFUL
WHAT: — (No sentence of carryings/v381R/ states the question or the list. The paragraph gathers them from the form and the reasons of the 129 review blocks in the four rev_*.md files: "is: yes / no", "at: section — beside sentence", and the mends, a sentence, "DISSOLVE at …" or "BACK — …". Each failing it lists is a reason found there, but "a deciding", which I did not find. That BACK is "laid among the raw droplets again" is the paragraph's reading; the source does not say where BACK goes.)

### 13.2
TITLE: Concern · Emptying at no pass beside a record named a store.
VERDICT: FAITHFUL
WHAT: —

### 14.1
TITLE: Concern · The bold of 4.5 beside its own explaining.
VERDICT: FAITHFUL
WHAT: —

### 14.2
TITLE: Concern · An across sharing said as released along.
VERDICT: FAITHFUL
WHAT: —

### 14.3
TITLE: Droplet · All a self chains, named as across alone.
VERDICT: FAITHFUL
WHAT: —

### 14.4
TITLE: Droplet · 9 makes no changing of its own.
VERDICT: FAITHFUL
WHAT: —

### 14.5
TITLE: Droplet · Carrying along said of 9 at two sentences.
VERDICT: FAITHFUL
WHAT: —

### 14.6
TITLE: Droplet · Released said of each giving on, at two sentences.
VERDICT: FAITHFUL
WHAT: —

### 15.1
TITLE: Concern · Competency the floating middle, or each self's own along.
VERDICT: FAITHFUL
WHAT: — (The last clause, that Exhibit EIGHT Natural Exploring has the first saying also, is not in carryings/co_chaining_map_v376/; it is true at Exhibit_EIGHT_Natural_Exploring_v329.md line 145.)

### 16.1
TITLE: Droplet · A re-saying's subject, a paired table, a check's ending.
VERDICT: FAITHFUL
WHAT: —

### 17.1
TITLE: Concern · Bi-co-momentarying at no term, and at 5.
VERDICT: FAITHFUL
WHAT: —

### 17.2
TITLE: Concern · A scale as a reading or an ordering.
VERDICT: STRONGER
WHAT: Source, carryings/co_chaining_coverage_v378/readings/01_natural_intelligence_and_exhibit_one.md line 89, the last of four partings: "4. Minor: Registry 290: "A scale is a reading" vs WP 4.15: "its scales are sequencing, an ordering."" The paragraph says it as a concern of full weight, "Two sayings part", and the source's one word of weight, "Minor", is not carried. Both sentences are as the living files have them.

### 18.1
TITLE: Possible project · The numbers two and four below a living self.
VERDICT: FAITHFUL
WHAT: —

### 19.1
TITLE: Possible project · Two distant selves at one between.
VERDICT: FAITHFUL
WHAT: —

### 20.1
TITLE: Droplet · Four society faces, each from one bounding set aside.
VERDICT: FAITHFUL
WHAT: —

### 20.2
TITLE: Droplet · Abundancing parted from a growth and from a sharing.
VERDICT: FAITHFUL
WHAT: —

### 20.3
TITLE: Droplet · No position owned at a scale, inward or outward.
VERDICT: FAITHFUL
WHAT: —

### 21.1
TITLE: Droplet · Non-living surfaces do not select.
VERDICT: FAITHFUL
WHAT: —

### 21.2
TITLE: Droplet · A between's pace parts the gradual from the sudden.
VERDICT: FAITHFUL
WHAT: —

### 21.3
TITLE: Droplet · A society at its dwell, clusters ahead of a crystal.
VERDICT: MISSTATED
WHAT: One figure. The source, Session_Report_v374_Part_Two.md line 293: "A micelle outlives its members' residence a thousand to a million times". The paragraph: "a society outlasting its members' residence about a thousand times". The paragraph's own spans, taken from the source's C7 (line 39), "within microseconds" beside "milliseconds to seconds", give a thousand to a million, so the paragraph parts from itself as well. The section's opening line says that at a figure parting between a droplet and its observing the observing carries, and the observing at carry/Exhibit_SIXTEEN_Carryings_of_Natural_Chemistry.md line 120 has two relaxation processes with time constants "about three orders of magnitude apart": the figure follows that observing and not the source. Everything else in the paragraph is as the source has it (lines 294 and 308); the source's "the between releasing into the amorphous solid" is left out.

### 21.4
TITLE: Droplet · Merging and ingesting part, and two hands come to one.
VERDICT: FAITHFUL
WHAT: —

### 21.5
TITLE: Droplet · A still droplet, a self offered its own parity.
VERDICT: FAITHFUL
WHAT: —

### 21.6
TITLE: Droplet · Two characters and two forms at non-living societies.
VERDICT: FAITHFUL
WHAT: —

### 22.1
TITLE: Droplet · Bi-tri-involutioning beside the names with no co.
VERDICT: FAITHFUL
WHAT: —

### 22.2
TITLE: Concern · A negation with no fixed thing to be other than.
VERDICT: FAITHFUL
WHAT: —

### 22.3
TITLE: Droplet · A Part Five naming beside its Registry step.
VERDICT: STRONGER
WHAT: Each sentence is in the source at the same words' strength: carryings/v380R/Natural_Naming_Second_Reading.md, "General finding", and Natural_Naming_Value_Sorted.md lines 41 and 43. What is dropped is the standing both files give themselves at their first line: "A second reader's reading, unreviewed", and "one fresh reader's and unreviewed. A sorting for conferring". The general finding rests on 25 sections read, 18 of them of Part Five. The paragraph says a judgement of worth, "adds nothing to the step", "little at a naming of a naming", as plain fact. I could not check a judgement of that kind at the living files, which is why this is marked and 6.1, 22.5 and 22.6, from a source of the same standing, are not.

### 22.4
TITLE: Droplet · Three values beside the purpose, serving it.
VERDICT: STRONGER
WHAT: The same thing as 22.3 and no more. The three values, their sections and their uses are as Natural_Naming_Value_Sorted.md has them under "Beside the purpose, and serving it: an expanding offered". That file is "one fresh reader's and unreviewed. A sorting for conferring", and the paragraph carries neither that nor "an expanding offered".

### 22.5
TITLE: Concern · The 1–17s inward and outward, three parities or four.
VERDICT: FAITHFUL
WHAT: —

### 22.6
TITLE: Concern · A society, the surface of couplings or the selves.
VERDICT: FAITHFUL
WHAT: —

## SUMMARY

Paragraphs read: 50.

- FAITHFUL: 42
- STRONGER: 6 (2.1, 3.2, 11.1, 17.2, 22.3, 22.4)
- NOT FOUND: 1 (1.3, in part)
- MISSTATED: 1 (21.3, one figure)
- QUOTE WRONG: 0

What the eight are, plainly:
- No paragraph in this sample says the opposite of its source, and none carries a sentence I could find at no file at all.
- 1.3 is the one paragraph whose particulars are not in the source the session named; they are true at the living files.
- 21.3 changes one figure, "a thousand to a million times" to "about a thousand times", toward the observing at the carrying mate, and leaves the paragraph's own spans saying the wider figure.
- 2.1 and 3.2 each add or widen a sentence: 2.1 carries a sentence about crystal samples into a droplet about pharmacology as "each single case"; 3.2 adds "no carrying is parted, and each of the two is whole" and drops "it is my offering".
- 11.1, 17.2, 22.3 and 22.4 each say what the source says and drop the source's own word on its standing: "not a resolver execution", "Minor", "unreviewed".

One thing across the sample: four source files in carryings/v380R/ are headed as one reader's or a helper's reading, unreviewed (Natural_Naming_Each_Section_Read.md, Natural_Naming_Value_Sorted.md, Natural_Naming_Second_Reading.md, Natural_Naming_Beside_Receiving_Exhibits.md), and carryings/v380L/closing_drafts/ are headed "A draft for a later working", the resolver followed by hand and never executed. No paragraph of the sample taken from them (6.1, 3.5, 3.6, 14.1 to 14.6, 22.3 to 22.6) carries that standing. I marked only 22.3 and 22.4 for it, because their content is a judgement I could not check; the others say things I checked at the living files or at the resolver's lines.

What I could not check: whether each re-saying "in the naming now" keeps the sense of the older word it replaces (for example "membrane" to "bounding" or "the betweens of cells", "sign" to "parity", "landing" to "a form named still", "returns to the natural surface" to "comes to the surface of the observings" in 2.1). I read these as naming changes and did not judge them.

## READING

Read in full:
- carryings/v380R/The_Universal_Claim.md
- carryings/v380R/Natural_Naming_Conferring.md
- carryings/v380R/Natural_Naming_Value_Sorted.md
- carryings/v380R/Natural_Naming_Second_Reading.md (table cells shown to 1,300 characters)
- carryings/v383Op/Presentation.md
- carryings/v380A/illustrating/Teaching_Exploration.md
- carryings/co_chaining_map_v376/Explored_Steps_v376.md

Read in part, at the passages the paragraphs come from and around them:
- carryings/v380R/: For_The_Workings.md, Natural_Naming_Beside_Receiving_Exhibits.md, Natural_Naming_Each_Section_Read.md, Natural_Naming_Negations_Yet.md, Natural_Naming_Gathering.md, Natural_Networking_From_v380A.md, Natural_Naming_Part_Four_Released.md
- carryings/v380L/: Gathered_Value_1.md, Registry_Negations_Sorted.md (head and tail), Progress.md, README.md, closing_drafts/Round_At_Four_Parities_Deriving.md (lines 1 to 125, 180 to 215, 295 to 312), closing_drafts/Natural_Intelligence_Fifty-Four_Read_By_Hand.md (lines 1 to 60 and its two tables of fourteen), closing_drafts/Registry_Negations_At_The_Purpose.md
- carryings/v380A/illustrating/: Concept_And_Consistency.md (lines 29 to 90), Version_And_Workings.md (lines 30 to 70), Origin_Study.md, Progress.md, Illustrating_Findings.md
- carryings/v383Op/README.md (lines 1 to 60, 81, 112), At_The_Logic.md
- carryings/v382F/Session_Report_v382F_2.md (line 211)
- carryings/v381R/: the four rev_*.md files (form, counts and reasons), Close_Droplets_v381R.md, Session_Transcript_v381R.txt (lines 137 to 164, 905 to 909)
- carryings/genome_duplication_v374/Session_Report_v374_Part_Two.md (lines 23 to 71, 290 to 322, 350 to 432) and Session_Report_v374.md (lines 40, 288 to 294, 377, 581 to 589, 619)
- carryings/review_natural_physics_improving_v376/: fresh_review.md (lines 58, 82, 104), first_section_proposal.md (lines 1 to 20), Improving_Report.md (line 32)
- carryings/cohering_ten_and_six_v377/README.md (lines 40 to 50, 128 to 137, 205 to 220)
- carryings/co_chaining_map_v376/: cover_REGISTRIES.md (line 74 and around), Co_Chaining_Groups_v376.md (lines 240 to 250)
- carryings/co_chaining_coverage_v378/readings/: 01 (lines 79 to 92), 06 (line 33)
- carryings/resettling_v373/Natural_Intelligence_v373_Released.md (lines 622 to 624, 659 to 667, 691, 769)

Searched and not opened further: carryings/review_physics_observings_v376/, carryings/illustrating_v366/, carryings/physics_for_other_files_v377/, carryings/exhibit_one_prefixes_v379/, carryings/equilibria_registry_v377/, carryings/rings_are_spirals_v377/, and the files of each source folder not named above.

Living files opened to check quotations and the places paragraphs name: Natural_Intelligence_v380R.md, Exhibit_ONE_Natural_Resolver_v380R.md (the resolver's block), Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md, Exhibit_TWENTY_Natural_Naming_v380R.md, Exhibit_THREE_Natural_Numbers_v380L.md, Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md, Exhibit_TWENTY-ONE and TWENTY-TWO at v375, Exhibit_EIGHT_Natural_Exploring_v329.md; and carry/Exhibit_SIXTEEN_Carryings_of_Natural_Chemistry.md line 120.

Nothing under /home/claude/corus was edited. Two small scripts and one piece of arithmetic were run from the scratchpad, reading only.
