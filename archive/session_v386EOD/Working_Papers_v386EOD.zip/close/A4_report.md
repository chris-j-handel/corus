# A4 report: third reading of 40 RESAID paragraphs (A4_sample.txt)

### 1
VERDICT: MINOR
WHAT: The section number of the Geodesic Improving Method is changed from 2.3 to 2.5 (the living v380R file has the sentence under 2.5, so the new number is the right one there). The closing sentence "The reason: 2.4 says *one compound alone*" is not said as a reason; its words are inside the quoted sentence and in "They part at a second compound of a still". "already" (both sentences already say) is dropped. The quote now carries ", 5.62", which the living sentence has. Three quotes checked, all exact.

### 2
VERDICT: SAFE
WHAT: —

### 3
VERDICT: SAFE
WHAT: —

### 4
VERDICT: MINOR
WHAT: The older words given for Natural Intelligence ("Right, and not at all; right is no preference among two: it is the one, and left is what the one makes at a face") are replaced by the two sentences the living file has now at 1.5 ("Right, or none at all." and "... and not right is its emanating as a form."). The word "left" of that saying is gone; "opening" is said as "at 1.5"; "already" is dropped. Both quotes checked, exact, under 1.5.

### 5
VERDICT: SAFE
WHAT: —

### 6
VERDICT: MINOR
WHAT: "3.1 here says the three are said of the crossing and of no prefix" is replaced by the living sentence of 3.1, "the three said of the crossing, a resolver name's three prefixes its numbers' words"; the words "of no prefix" are not in the new paragraph (they are not in the living Natural Naming either). "The session said" (v379) is now "A saying offered". "at the code" is now "at the resolver". "Ready, at v379" under "A plan, not yet final" is now "Possible project … It may change or never be made". Quote checked, exact, under 3.1.

### 7
VERDICT: SAFE
WHAT: —

### 8
VERDICT: MINOR
WHAT: Adds a sentence the original did not have: "It is beside Natural Naming's '*co-bi-exchanging* opens co, at the odd, the self's, and *bi-co-exchanging* opens bi, at the even, the other's'". The quote is exact (Natural Naming 4.15). Nothing of the original is lost.

### 9
VERDICT: SAFE
WHAT: —

### 10
VERDICT: MINOR
WHAT: The step number of the Co-Chaining Logic Registry is changed from 368 to 506 (in the living v380L file the sentence is step 506; step 368 there is another sentence). Adds "four at the first and ten at the second" (the original has "counted four or ten" and "two, one, one and none"). "open" (section 5 item 4, open) is not said. Both quotes checked, exact.

### 11
VERDICT: MINOR
WHAT: "Finding 8's four cells" is replaced by "four cells of the Living File Registry's table and its 1.3, each a *standing* parting from the repository"; this is added from the source (Session_Report_v381F, Finding 8 says so) and the name "Finding 8" is gone. "A fresh reader of this session read this report" is now "A fresh reader read that gathering's report". "learned" and "Aimed at a file, Geodesic Improving Method" are not said. Numbers eleven, seventeen, `== 17`, two, eighteen, three hundred, four hundred, five sessions all kept.

### 12
VERDICT: MINOR
WHAT: Adds the sentences the original only pointed to: the Registry's "Each resolving is all or none at all, of no size beside another resolving.", Natural Exploring's 4.6 title and Natural Human Society's 1.5 words, and the line "They part at a size …". All four are the ones the source reading names (carryings/co_chaining_coverage_v378/readings/10_engineering_to_values.md, item H) and all seven quotes are exact in the living files. Not said any more: "for both", "at v378", and that it was received from `incoming/co_chaining_coverage_v378/`. "Entered … at v378" is now "the Registry adds".

### 13
VERDICT: HARM
WHAT: Lost: that the self asked the question, where and when ("The self asked at about line 299 (4 October)"), and the self's own words "what is carry and incoming and how are each separated"; also that the answer was "the session's plain answer". These words are in no file of `carry/` now (they remain in carryings/v381R/Close_Droplets_v381R.md and in archive/carrying_v386EOD/). The quoted "incoming is the door, carry is the mates" is unquoted and reworded ("the entrance"; in the file now "the offerings, possibling and carryings of each living file"). The substance of the answer (mailbox, to-do sorted by file, the hand step, the droplet method, incoming emptying at arrival) is all there.

### 14
VERDICT: MINOR
WHAT: "Returned to the droplets by a second reader at v381R" is now "It is no insertlet"; who returned it and when is not said. The saying, the two reasons, 3.3 and 5.1 are kept. Both quotes checked, exact (3.3 and 5.1 of Natural Intelligence).

### 15
VERDICT: MINOR
WHAT: "At its 4.12, Natural Philosophy names the arrival bearer and bundle": "its" can be read as Natural Philosophy's own 4.12. In the source it is the proposed Natural Physics' 4.12 (Natural Philosophy's own section is 3.29). The original "At 4.12, Philosophy names …" did not have this pronoun. Added "among the corrections at the file past its close" matches the source's section 5 heading.

### 16
VERDICT: MINOR
WHAT: "its reading at a case still to come" is now "its reading at no case": that a reading is expected later is not said. "a relation unsaid" stands for the source heading "Relations still to be said".

### 17
VERDICT: SAFE
WHAT: —

### 18
VERDICT: MINOR
WHAT: "said or released with its reason" is now "It is said at that proposal, or released with its reason": "at that proposal" is added, and the sentence now reads as a statement, where the source lists it under "Open at the carrying". "2.3.2" is said as "its 2.3, item 2", which the review confirms.

### 19
VERDICT: SAFE
WHAT: —

### 20
VERDICT: SAFE
WHAT: —

### 21
VERDICT: SAFE
WHAT: —

### 22
VERDICT: MINOR
WHAT: "Each is to be re-said at its name at the next pass" is now "The work is each of them re-said at its name. It may change or never be made." The time "at the next pass" is lost and the strength is lower (to be done → may never be made). "as this session left them" and "Repeated at section 5 item 9" are not said.

### 23
VERDICT: MINOR
WHAT: "this session" (v381F) is now "a working", with no session named. "learned about working" and "Aimed at a file, Geodesic Improving Method" are not said. "a doer applying from outside" is now in double quotation marks; it is an exact phrase of the living Geodesic Improving Method 2.7. Six, the three places, the reviewer's brief, "none open" and "a deriving" are kept.

### 24
VERDICT: MINOR
WHAT: The section number is changed: the original has the two relations at "3.9" (of the prior version 348, as the review says); the new paragraph has them at Natural Physics "4.9" (the living v379 file has both quoted phrases under 4.9). That the relations were at the prior version 348 is not said. Both quotes checked, exact.

### 25
VERDICT: SAFE
WHAT: —

### 26
VERDICT: SAFE
WHAT: —

### 27
VERDICT: MINOR
WHAT: Much is added to a short pointer: the two full sentences of Equilibria Registry 2.1 (both exact), "No step of … Co-Chaining Logic Registry has …", and the wording of the proposed step (it is the source's S19 word for word, carryings/co_chaining_map_v376/cover_EQUILIBRIA.md line 164), plus "The step may change or never be made". The names "S19", "Table A §2 item 26" and "MISSING" are gone. Nothing of the original's content is denied.

### 28
VERDICT: SAFE
WHAT: —

### 29
VERDICT: MINOR
WHAT: "the observing that would part the reading" is now "the observing parting the reading"; "whose parting observing is still to be named" is now "with no parting observing named"; "not yet said" is now "unsaid". The expectation in "would" and "still to be" is not said. The six sections and the numbers are kept.

### 30
VERDICT: SAFE
WHAT: —

### 31
VERDICT: SAFE
WHAT: —

### 32
VERDICT: MINOR
WHAT: The original is a short pointer with "…". The new paragraph adds the numbers 2, 14 and 17, and 6, 10 and 9, "in one full momentarying of two parities", the resolver surfacing the offerings "at 14 ahead of 12", and a quoted sentence of Natural Naming (exact, at 5.62). These are from the full v379 concern (I found it at archive/carrying_v381R/ and the v379 report), not from the paragraph being resaid. "waits on" is now "Its resolving is"; "the code's order" is now "the resolver's order"; "at v379" is not said.

### 33
VERDICT: SAFE
WHAT: —

### 34
VERDICT: HARM
WHAT: Lost: that this is a saying of the self ("A method saying of the self, at about line 70 (4 October), on how the session is to work a concept") and the self's exact words "work on this aspect and keep asking the hardest question about this concept or implementation." They are replaced by an unattributed description ("A working at one aspect asks the hardest question … again and again"). "the method's own 2.x" is narrowed to "2.5, of its Part TWO" (the living file's 2.5 is "The hardest first, and the hardest question asked plainly"). Note: the original paragraph, word for word, is still in two other files of `carry/` now (Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md line 293, Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md line 205); it is gone from Offerings_to_Natural_Arriving.md.

### 35
VERDICT: MINOR
WHAT: The session's quoted words "this is like the crowded plaza example" are now a paraphrase, "are like the crowded plaza, as said at session v379". "the section on the social membrane, the plaza and the between" is now named as 3.8 "Social membrane, the plaza, sign between" (exact heading of the living file). The transcript's path is not said. The ready sentence is word for word.

### 36
VERDICT: SAFE
WHAT: —

### 37
VERDICT: SAFE
WHAT: —

### 38
VERDICT: SAFE
WHAT: —

### 39
VERDICT: SAFE
WHAT: —

### 40
VERDICT: SAFE
WHAT: —

## SUMMARY

| KIND | SAFE | MINOR | HARM | COULD NOT CHECK | Total |
|---|---|---|---|---|---|
| RESAID | 20 | 18 | 2 | 0 | 40 |
| RELEASED | 0 | 0 | 0 | 0 | 0 |

HARM: 13, 34. MINOR: 1, 4, 6, 8, 10, 11, 12, 14, 15, 16, 18, 22, 23, 24, 27, 29, 32, 35.

## READING

What I did.
- I laid AS IT WAS beside AS IT IS NOW for all 40 items.
- I checked every sentence in double quotation marks in all 40 new paragraphs (26 quotes, in 13 items: 1, 4, 6, 8, 10, 12, 14, 17, 23, 24, 27, 32, 35) against the `*.md` files at the root of /home/claude/corus, ignoring italic asterisks. All 26 are exact. Where the new paragraph names a section or step for a quote I checked it: all agree. Some of them are headings, a subtitle or a phrase inside a sentence, not whole sentences (item 12's Natural Exploring 4.6 is a section title; 17 is the subtitle; 35 is a heading; 14 and 23 are phrases).
- I opened each carry file and found each new paragraph. All 40 are there, inside the section `## Droplets`. Items 13 and 19 differ from the sample only in "the mates" being written "the offerings, possibling and carryings of …".
- Where a new paragraph says more than the old one, I opened the source it came from: carryings/natural_physics_v377/README.md (items 7, 15, 16, 19, 25, 29, 33, 38, 39), carryings/review_natural_physics_v377/README.md (18, 20, 24, 31), carryings/session_v378/Session_Report_v378.md (2, 40), carryings/v381F/v381F/Session_Report_v381F.md (11, 17, 23), carryings/co_chaining_coverage_v378 (12), carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (27), carryings/v368_sources (3, 8, 28, 37), carryings/illustrating_v366 (5, 9), and the pre-session text by `git show` and archive/ (31, 32). Every addition I list is in its source; I found none that is made up.

What I did not check.
- I did not check whether the original paragraphs were true. For items 1, 4, 6, 10, 13, 14, 21, 22, 26, 30, 34, 35 and 36 I compared the two texts (and the living files, for quotes and section numbers) and did not open the original source the old paragraph came from.

How I drew the lines.
- Source names in brackets, "re-aimed from …" notes and the closing tags are not counted as claims, as the task says. I note the fact: in all 40, the paragraph in the file now ends "— v386EOD", where the older one ended with its own tag (for example "— v368_sources", "— session_v378", "— v381F"). The bracketed source (for example "(Wrap_v368.md, §4 …)") is not in the new paragraph of items such as 2, 3, 4, 5, 8, 9, 21, 26, 28, 30, 36, 37; most of the Natural Physics items keep theirs as a `carryings/…` path.
- HARM is given only where the self's own quoted words and the statement that the self said them are gone (13, 34). The teaching of each of those two droplets is whole in the new paragraph; the loss is the attribution and the exact words. If attribution to the self is not counted, both would be MINOR.
- Where a session is no longer named ("the session said", "this session") I gave MINOR (6, 23, 35).
- Four items change a section or step number (1: 2.3 to 2.5; 10: 368 to 506; 24: 3.9 to 4.9; 34: 2.x to 2.5). In each, the new number is where the living file has the sentence today. I gave MINOR and said so, because the number of the original is changed.
- Rewordings of "still to", "not yet" and "would" into flat present forms (16, 29) are MINOR: the fact is kept, the expectation is not said.
- Each "Possible project" ends "It may change or never be made". For originals that were plans or "next" (9, 26, 28, 36) I counted this SAFE; for 22, where the original said "is to be re-said … at the next pass", I gave MINOR.

Other things seen.
- No new paragraph denies anything in its original.
- Items 8, 10, 11, 12, 27 and 32 say more than their originals. In 27 and 32 the original was a short pointer and the new paragraph is mostly added text taken from the source.
- Item 31's paragraph stands three times in the carry file (lines 206, 462, 526), with small differences; the pre-session file also had three near-identical originals, so none was added.
- Items 28 and 37 are the same original sentence in two files; one is now a "Possible project", the other a "Droplet".
- Paragraphs titled "Concern ·" and "Possible project ·" stand inside `## Droplets` in the Offerings files.
- The pre-session Offerings files are kept at archive/carrying_v386EOD/ as `…_before_resolving.md`.
