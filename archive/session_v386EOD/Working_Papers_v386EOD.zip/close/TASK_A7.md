# Task: observings, each laid beside its publishing

Read COMMON.md first.

`A7_sample.txt` lists entries from files `carry/…Carryings_of_….md`. Each has two lines: *Natural observation* (what was observed) and *Science explanation* (the field's own explaining), with links to publishings.

For each entry, open the linked publishing with your web tools (the abstract page or the full text). Check each number, name, year, organism, material and finding in the two lines against the page. If a page will not open, try one other address for the same publishing (the DOI, PubMed, the publisher); if nothing opens, say NOT OPENED.

Your report: one block for each entry:
```
### <number>
VERDICT: <AS THE PAGE HAS IT | PARTS | NOT OPENED>
WHAT: <for PARTS: exactly which number, name or finding parts from the page, with the page's own words; for NOT OPENED: what you tried; otherwise a dash>
REACHED: <abstract only | full text | a secondary page>
```
Then `## SUMMARY` with counts. Final message: the path of your report and the counts.
