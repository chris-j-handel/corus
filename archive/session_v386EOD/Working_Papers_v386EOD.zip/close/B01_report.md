# B01 report: a third reading of 46 older paragraphs said again (sample B01_sample.txt)

All 46 items are KIND: RESAID. Each new paragraph was found in the file named, by its bold title (once each). Two differ from the sample by small wording only: item 19 has "laid at these offerings" in the file where the sample has "laid at this mate"; item 31 has *standing* in italics in the file.

### 1
VERDICT: SAFE
WHAT: -
LOST: -

### 2
VERDICT: SAFE
WHAT: -
LOST: -

### 3
VERDICT: SAFE
WHAT: -
LOST: -

### 4
VERDICT: SAFE
WHAT: -
LOST: -

### 5
VERDICT: SAFE
WHAT: -
LOST: -

### 6
VERDICT: MINOR
WHAT: "No step of the Registry has the three carried as one" names neither of the two registries the paragraph has just named in full; the original's "No step … MISSING" is of the Co-Chaining Logic Registry's steps. "explored Left 3 says the reverse" is now "They part". The original's "Taken as one object" is now the living sentence "Named as one object …" at step 408 (found there).
LOST: -

### 7
VERDICT: MINOR
WHAT: "and now the lockstitch" lost its "now"; "meet and must not be counted into each other" is now "couple and must not be numbered into each other".
LOST: -

### 8
VERDICT: SAFE
WHAT: -
LOST: -

### 9
VERDICT: SAFE
WHAT: -
LOST: -

### 10
VERDICT: SAFE
WHAT: -
LOST: -

### 11
VERDICT: SAFE
WHAT: -
LOST: -

### 12
VERDICT: MINOR
WHAT: "executions and their numbers stand at the Session Record" is now "the numbers of executings are at the Session Record", which can be read as a count of executings and not as the numbers the executions gave. The source (Session_Report_v378.md, section 4, the session's learnings about working) is no longer named.
LOST: -

### 13
VERDICT: HARM
WHAT: The proposal's own sentence is gone, and three of the four evidence quotations from Exhibit ONE's rows are cut short. "The evidence" is no longer said of those rows, and "the row carrying *prior, now and next* at the facings too" lost its "too". The full rows are still in the living Exhibit ONE (rows 2, 6 and 17 of *Prior and next*); the proposal sentence is in no file of carry/ (it is at carryings/v381F/v381F/Next.md, Exploring 6).
LOST: "Proposed: *Natural Naming 2.4's three rows … drafted word for word at prior, now and next.*"; and of the evidence, "2: *the others' across sharings of their prior momentary, arriving now*; 6: *the changing shared, the other's next offering at its 2*; … 17: *the society's next momentary, the next now*" (now only "their prior momentary, arriving now", "the other's next offering", "the next now").

### 14
VERDICT: SAFE
WHAT: -
LOST: -

### 15
VERDICT: SAFE
WHAT: -
LOST: -

### 16
VERDICT: MINOR
WHAT: The first saying is now "One has …" with no owner: the original said the concern is from `incoming/v380A/`, beside "The connectors at a momentary's two parities, a connector cohering method" (the words "a connector cohering method" are gone). "two relations not yet identified as one order" is now "their one order unidentified". "a meaning to meet, not a word replacement" is now "a changing of meaning, and no word replacement".
LOST: -

### 17
VERDICT: SAFE
WHAT: -
LOST: -

### 18
VERDICT: HARM
WHAT: The last sentence of the plan is gone and is in no file of carry/ (it remains only at carryings/resettling_v373/Re-Settling_the_Living_Files.md, line 173). Also the number "Natural Intelligence 8.6" is now "Natural Intelligence 5.4" with nothing saying it was changed; the v373 text's 8.6 was "Two methods parting at the precise place" and the living 5.4 is "Two methods parting at the now", so the new number is the present address of the same section.
LOST: "Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there."; changed: "4.2's truth, science and device paragraph to Natural Intelligence 8.6 or Natural Philosophy".

### 19
VERDICT: MINOR
WHAT: "at Natural Intelligence 4.13's two rings joined" is now "two *spirals coupled across*" (the living 4.13 is now "Spirals, co-spiraling and crossing"; the words "rings joined" are not in it). "Arrived, returned at v377" is gone.
LOST: -

### 20
VERDICT: MINOR
WHAT: "kept as returned numbers" is now "carried as the instrument's numbers", and "returned the same way" is now "given the same way". The finding's own mark, AA04, is gone (3.2 of the kit is still named).
LOST: -

### 21
VERDICT: MINOR
WHAT: Nothing lost. Added, and not in the original paragraph: "re-said at the overlap" after 4.9's windings, and "each facing said at its momentary: the other's prior at the self's now at 2 and 14, the self's now at the other's next at 6 and 10, the next prior at 9 and the next now at 17". The original's "…" between "Exhibit FOUR once" and "the Equilibria Registry once" stood for a quoted clause in the source, not for more files, so no file is dropped.
LOST: -

### 22
VERDICT: MINOR
WHAT: The original's last sentence, "The other file's carrying now holds its side; this file keeps its side at the section named", stood word for word in both Natural Physics' and Natural Philosophy's offerings, so in this file "this file" could be read as Natural Philosophy. The new paragraph settles it the other way: Natural Philosophy's carrying has its side and the proposed Natural Physics has its side at the section named. Which file each section number belongs to (3.x Natural Philosophy, 4.x Natural Physics) agrees with the report's own line 37.
LOST: -

### 23
VERDICT: SAFE
WHAT: -
LOST: -

### 24
VERDICT: SAFE
WHAT: -
LOST: -

### 25
VERDICT: SAFE
WHAT: -
LOST: -

### 26
VERDICT: MINOR
WHAT: The observing was a forecast and is now said as fact: "will show the method working; it will not by itself move the files that need moving most" is now "shows the method working and by itself moves none". "The session's observing at about line 691 (6 October)" is gone, so the date and whose observing it was are no longer said. The quoted words are the session's own (carryings/v381R/Session_Transcript_v381R.txt, line 691), not the person's.
LOST: -

### 27
VERDICT: MINOR
WHAT: "waits on Exhibit ONE's torus of selves at its own numbers, and chaining the prior on said beside involuting" is now "Its resolving is …": the waiting is no longer said.
LOST: -

### 28
VERDICT: MINOR
WHAT: The report's "meeting that registry" and "those meet its next families" are now "coupling with" and "those couple with".
LOST: -

### 29
VERDICT: SAFE
WHAT: -
LOST: -

### 30
VERDICT: SAFE
WHAT: -
LOST: -

### 31
VERDICT: MINOR
WHAT: "Nothing is in the white paper" is now "Nothing is in Natural Intelligence": the name *the white paper* for Natural Intelligence is gone from this paragraph (it is still used elsewhere in the same file). The standing "run" is now "executed", though the paragraph says these are the standings as they were at the proposing. "subtitle" is now "the line under it"; "already carries" is now "had at the proposing".
LOST: -

### 32
VERDICT: MINOR
WHAT: A part was dropped without being said to be released: "exhaustiveness, determinacy, reachability, all or none. Steps 27, 28, 44, 58 carry the parts; MISSING. 'The three conditions and their names are at no step'" → S3a–d. I checked it: the living Co-Chaining Logic Registry now names the three at steps 84, 85 and 86, and Equilibria Registry 1.2 has the three names and "all or none at all", so the finding is met and the dropped words are stale. Steps 96–97 are now given as 143 and 144 (step 144 found as quoted).
LOST: -

### 33
VERDICT: SAFE
WHAT: -
LOST: -

### 34
VERDICT: MINOR
WHAT: Added: "The proposed Natural Physics of version 377 has it … at a cyclic pattern". The review says only that a cyclic pattern with no transport does not keep it; the proposal's own words are "the persistent current at the spiral carrying its pattern whole". "does not keep it" is now "does not carry it".
LOST: -

### 35
VERDICT: SAFE
WHAT: -
LOST: -

### 36
VERDICT: HARM
WHAT: Only Part SEVEN and 6.2's eight clusters remain. The plan's Part FIVE, the rest of Part SIX, Part EIGHT and the closing heading are gone and are in no file of carry/ (they remain at carryings/resettling_v373/Natural_Naming_at_Exhibit_ONE.md and in the archived copy of this file). The living Natural Naming v380R now closes with "THIS IS THE BETWEEN" and its Part EIGHT has no *membrane*, so those two parts look done; I could not confirm Part FIVE or Part SIX done.
LOST: "Part FIVE · Namings: unfoldings carrying *membrane*, the old code's *ages* and *bound*, and 5.44 at the earlier names, re-said at the forms. Part SIX · Gatherings at the resolver's names: 58 earlier names, at 6.2 and 6.4, by the map with their sentences"; "Part EIGHT · The unfolding's releasing: *membrane* at 8.1, 8.3 and 8.6, to *the between*. THIS IS A MEMBRANE, the closing heading, unnumbered: *The between*, or released with the file's closing."

### 37
VERDICT: MINOR
WHAT: The nine earlier names and the seven code names are no longer in the paragraph; it points to the table of Natural Naming 3.3 for them. I checked all nine rows of that table: each earlier name and each code name is there as the original gave it. "735 places" is now quoted as "across the living files", where the original had "across the living files and the carrying". "the map is its next form, the current name first" is now "Between the gathered names and the names now are the names of version 373", which adds that the names now are others than those of version 373 (true of the living table).
LOST: -

### 38
VERDICT: SAFE
WHAT: -
LOST: -

### 39
VERDICT: MINOR
WHAT: "the Geodesic Improving Method 2.3" is now "at 2.5". The quoted sentence is under 2.5 in the living file, so the new number is right for the file as it is; the change is not said.
LOST: -

### 40
VERDICT: SAFE
WHAT: -
LOST: -

### 41
VERDICT: HARM
WHAT: Only the last clause of the finding remains. The finding that the three objects of a naming still are at no step is gone, with its step numbers and the proposed step. It is in no file of carry/, and it is not met: the living Co-Chaining Logic Registry v380L has the word *stability* at no step. (The first quoted sentence, "The stability can change, the form can change, the relation can change", is no longer in the living Equilibria Registry; the second is still at its 2.2 in near words.)
LOST: "'The stability can change, the form can change, the relation can change'; 'places the still … at the stability, the form or the relation'. Steps 97, 99; MISSING. 'The three objects of a naming still are at no step.'" → S24.

### 42
VERDICT: SAFE
WHAT: -
LOST: -

### 43
VERDICT: SAFE
WHAT: -
LOST: -

### 44
VERDICT: MINOR
WHAT: "Each execution the file cites runs again here" is now "is executable again at its report's folder": a thing done is now said as a thing possible. "a run today matches it" is now "the report has a later executing matching it". "its starts" is now "its openings". The path `incoming/physics_at_the_code_v376/` is now `carryings/physics_at_the_code_v376/`, where the file is.
LOST: -

### 45
VERDICT: SAFE
WHAT: -
LOST: -

### 46
VERDICT: MINOR
WHAT: "the kernel's keeping read at a window three nodes long" is now "what the kernel conserves read at a window three nodes long".
LOST: -

## SUMMARY

All 46 items are RESAID; there is no RELEASED item in this sample.

| Verdict | RESAID | RELEASED |
|---|---|---|
| SAFE | 24 | 0 |
| MINOR | 18 | 0 |
| PERSON'S WORDS | 0 | 0 |
| HARM | 4 | 0 |
| COULD NOT CHECK | 0 | 0 |

- HARM: 13, 18, 36, 41.
- PERSON'S WORDS: none. No original paragraph in this sample quotes the person or says the person said or asked a thing. The one long quotation that might have been theirs, in item 26, is the session's own.
- MINOR: 6, 7, 12, 16, 19, 20, 21, 22, 26, 27, 28, 31, 32, 34, 37, 39, 44, 46.

## READING

- **How I read.** Each pair was laid side by side claim by claim: every claim, relation, condition, negation, number, named place and attribution of AS IT WAS was looked for in AS IT IS NOW. A session's label ("A plan, not yet final, gathered here at v381R", "Ready, at v379"), a tag and a report's name were not counted as claims.
- **Where I drew HARM.** HARM is where a claim of the original is not in the new paragraph and I did not find it met in a living file. Where a part was dropped but I found the living file now carrying it whole (items 32 and 37), I gave MINOR and said what I checked. Items 32, 36 and 41 are the same kind of change: a paragraph cut down to one of its parts with nothing saying the rest was released.
- **The four HARM items.** In 18, 36 and 41 the lost words are in no file of carry/ now; they remain in the source carryings and in archive/carrying_v386EOD/*_before_resolving.md. In 13 the lost proposal sentence is likewise only at its source, and the shortened evidence rows are whole in the living Exhibit ONE.
- **Numbers changed to the present address.** Items 18 (8.6 to 5.4), 32 (steps 96–97 to 143 and 144) and 39 (2.3 to 2.5) changed a number without saying so. I checked each against the living file and each new number is where the thing now is. Items 14 and 44 changed `incoming/` to `carryings/` the same way, and the files are there.
- **Things added.** The added sentences in items 4, 8, 15, 23 and 40 are the headings of the review's sections or the proposal's own words, checked at carryings/review_natural_physics_v377/README.md and the proposed text. The additions in items 21 and 34 are not from the original paragraph and are named in their blocks.
- **Quotations.** I checked the double-quoted sentences in 16 of the 46 items (1, 6, 10, 13, 15, 16, 20, 27, 28, 32, 35, 37, 39, 41, 42, 43), 33 quotations in all. Every one is word for word in a living file at the repository root. Where the paragraph names a place, I checked it: all the named places hold. Two notes: in item 10 the words "at no line of the resolver" are in Natural Mathematics, Natural Numbers and Natural Intelligence but not in Natural Naming, which the paragraph (old and new alike) says only "carries" the name; in item 6 the first quotation is at both the opening of part 11 and at 11.1, as said.
- **Not checked.** Item 20's source file Kit_Rings_in_Motion_v366.md was found only as a findings file under carryings/v368_sources/Findings_To_Lay_By_File/; I did not find the AA04 entry itself and compared against the original paragraph alone. For item 36 I did not confirm whether the plan's Part FIVE and Part SIX have since been done in the living Natural Naming.
- **Seen in passing, outside the sample.** carry/Offerings_to_Natural_Intelligence.md line 145 still opens with the label "A plan, not yet final, gathered here at v381R:". I changed nothing in the repository and wrote this one file.
