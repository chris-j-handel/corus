import re, sys
base = "/home/claude/chris-j-handel/corus/"
files = {
 "SEVEN": "Exhibit_SEVEN_Natural_Societies_v373.md",
 "EIGHT": "Exhibit_EIGHT_Natural_Exploring_v329.md",
 "NINE": "Exhibit_NINE_Natural_Human_Society_v329.md",
 "FOURTEEN": "Exhibit_FOURTEEN_Natural_Destinies_v333.md",
 "FIFTEEN": "Exhibit_FIFTEEN_Natural_Emanating_v329.md",
 "TWENTY-THREE": "Exhibit_TWENTY-THREE_Natural_Values_v333.md",
}
def norm(s):
    s = s.replace("*", "").replace("’", "'").replace("‘", "'").replace("`", "")
    s = re.sub(r"\s+", " ", s)
    return s.lower()
texts = {k: norm(open(base + v, encoding="utf-8").read()) for k, v in files.items()}
alltext = " ".join(texts.values())

report = open("/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/reports/Brief_society-cluster_exhibits.md", encoding="utf-8").read()
# split report into sections by exhibit
sections = re.split(r"\n## ", report)
missing = 0; total = 0
for sec in sections[1:]:
    head = sec.split("\n", 1)[0]
    key = None
    for k in files:
        if head.startswith("Exhibit " + k + " "):
            key = k
    quotes = re.findall(r'"([^"\n]{3,})"', sec)
    for q in quotes:
        total += 1
        parts = [p.strip() for p in q.split("...")]
        hay = texts[key] if key else alltext
        ok = all(norm(p).rstrip(".,;:") in hay for p in parts if p)
        if not ok:
            # try whole corpus of the six files
            ok2 = all(norm(p).rstrip(".,;:") in alltext for p in parts if p)
            missing += 1
            print(("OTHER-FILE " if ok2 else "NOT FOUND  ") + (key or head[:20]) + " :: " + q)
print("quotes checked:", total, "flagged:", missing)
