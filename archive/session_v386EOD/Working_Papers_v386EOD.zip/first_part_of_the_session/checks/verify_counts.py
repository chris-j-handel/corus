import math
from itertools import product

def transitive_count(n):
    pairs = [(i, j) for i in range(n) for j in range(n)]
    count = 0
    surplus_models = 0
    for bits in range(1 << len(pairs)):
        R = {pairs[k] for k in range(len(pairs)) if bits >> k & 1}
        if all((a, d) in R for (a, b) in R for (c, d) in R if b == c):
            count += 1
            # "two arrive at m and something s departs m, reached by neither arrival"
            bad = False
            for (a, m) in R:
                for (b, m2) in R:
                    if m2 != m:
                        continue
                    for (m3, s) in R:
                        if m3 == m and ((a, s) not in R or (b, s) not in R):
                            bad = True
            surplus_models += bad
    return count, surplus_models

for n in range(1, 5):
    print("transitive relations on", n, "elements:", transitive_count(n))

# functions on up to five terms: every one has a cycle
nfun = sum(n ** n for n in range(1, 6))
print("functions on 1..5 terms:", nfun)
# serial relations on up to four terms
nser = sum((2 ** n - 1) ** n for n in range(1, 5))
print("serial relations on 1..4 terms:", nser, " on 5 terms:", (2**5 - 1) ** 5)

k = 1.380649e-23
print("kT ln2 at 300 K:", k * 300 * math.log(2))
print("cos/sin 60:", round(math.cos(math.radians(60)), 3), round(math.sin(math.radians(60)), 3))
# primes 5..53 partitions used in Exhibit SEVEN 5.3
primes = [p for p in range(5, 54) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
print(len(primes), primes)
print("one before six:", [p for p in primes if p % 6 == 5], "one after:", [p for p in primes if p % 6 == 1])
print("mod 4 == 1:", [p for p in primes if p % 4 == 1], "(p-1)/2 even:", [p for p in primes if ((p - 1) // 2) % 2 == 0])
allp = [p for p in range(2, 60) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
print("odd index:", [p for p in primes if (allp.index(p) + 1) % 2 == 1], "even index:", [p for p in primes if (allp.index(p) + 1) % 2 == 0])
# hypercube face counts used in Exhibit FIFTEEN
def f(n, kk):
    return math.comb(n, kk) * 2 ** (n - kk)
print("cube:", [f(3, kk) for kk in range(4)], "tesseract:", [f(4, kk) for kk in range(5)])
