# Brief: Exhibit ELEVEN (Natural Medicine) and Exhibit TWENTY-FIVE (Living Society Registry)

Both files were read whole, front to back. Nothing under the corus directory was changed, no script was run, and no network or web was used; the embedded "session/working" instructions were treated as content. The accuracy notes come from my own knowledge without web checks, so I mark confidence where it is not high. ELEVEN runs past your 900-word guide because you asked for thoroughness in item 9.

For context I also read small parts of four other places in the set:
- the two carry notes, `/home/claude/chris-j-handel/corus/carry/Exhibit_ELEVEN_Natural_Medicine.md` and `/home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-FIVE_Living_Society_Registry.md`
- `/home/claude/chris-j-handel/corus/incoming/v380L/Gathered_Value_1.md` (line 13) and `Progress.md` (lines 72, 105)
- sections 7.5 and 7.10 of `/home/claude/chris-j-handel/corus/Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md`
- `released_words.txt` and `retired_sayings.txt` in `/home/claude/chris-j-handel/corus/kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/`

---

## FILE 1. Exhibit ELEVEN, Natural Medicine, v331

`/home/claude/chris-j-handel/corus/Exhibit_ELEVEN_Natural_Medicine_v331.md` (677 lines, about 25,100 words)

### 1. Subject and purpose
This is the framework applied to medicine. Its thesis is that healing is always the body's own "restoration" (a stalled two-way exchange starting up again) and that a treatment can only remove an obstacle. It re-reads a wide range of findings as that one pattern, with HIV persistence and cancer getting most space, and ends by sorting its own claims by how well supported they are.

### 2. Structure
- **Preamble** (three paragraphs): medicine as the "restoration" member of physics, chemistry, biology, medicine.
- **Part One, Restoration (1.1–1.4):** the model (1.1); the body's own restoration, harm and timing (1.2); worked cases from faecal transplant to dialysis (1.3); childbirth (1.4).
- **Part Two, A departure (2.1–2.3):** "compaction", meaning holding a body to a target (2.1); cancer (2.2); tissue turnover and barrier orderings (2.3).
- **Part Three, Departures at a collar (3.1–3.6):**
  - 3.1 HIV, the longest section at about 5,900 words.
  - 3.2 the HIV "reservoir" as an accounting artefact, with leukaemia residual disease as a second case.
  - 3.3 nine tissue surfaces; 3.4 chronic inflammation, diet and sleep; 3.5 the cochlea; 3.6 a muscle-disease gene family and a gene-therapy trial.
- **Part Four (4.1–4.4):** medicine's standing puzzles sorted by type of error (4.1); what medicine files as "not the thing measured" (4.2); the clinical trial (4.3); doses and reference ranges (4.4).
- **Part Five (5.1–5.3) and "The forming that remains":** the file's own evidence ledger, links to Natural Health, three open items.

### 3. Main claims, most important first
- **Healing is the body's.** "healing, when it happens, is the body's own restoration resuming, and intervention supports and does not author it" (1.2).
- **Disease is a "departure".** An exchange stalls at one place, from too much or from too little: "One bound and two ways of missing it" (1.1).
- **The carry model.** Carried-forward material ages out unless it is being used; a carry "kept fresh by copying never releases" (1.1). This one idea is offered for the HIV reservoir, autoreactive B-cell clones and, by another route, cancer.
- **Side effects are the body's reply.** Medicine discards it and then buys tests: "The sensing paid for is the sensing already had and discarded" (1.1).
- **Reversal, not level.** The informative point on a dose-response curve is where the effect reverses. Holding a body to a setpoint or dose-to-level ("compaction") is said to create medicine's chronic problems: "Strip the compaction and the hard problem dissolves" (2.1).
- **HIV (3.1).** "Reservoir", "latency", "sanctuary", "exhaustion" and "escape" are bookkeeping entities ("soldiers"). What exists is "two societies and a nothing between": the cells and the tissue surface, with their exchange broken. The virus particle is a non-living "emanation" and the cell is the actor.
- **HIV tests offered (3.1).** Single-scale treatment hits a ceiling; cell-plus-tissue treatment beats the sum of each alone, or the reading fails.
- **Reservoir numbers depend on the assay.** "A size definable only by choosing" (3.2). The file proposes a per-site "locus reading" and a re-analysis of existing treatment-interruption data, and finds the same pattern in leukaemia residual disease.
- **Cancer (2.2).** A cell's coupling to its tissue collapses at the mitochondrial membrane: "many mutations, one departure, one phenotype". Mutations are a consequence. Restoring the tissue's signal ("coefficient one") is set against killing ("coefficient two").
- **"So three diseases and one restoration" (2.2).** Faecal transplant for C. difficile, HIV remission after marrow transplant, and lupus remission after deep B-cell depletion each replace the surrounding society.
- **Diagnoses as departments.** Many are one process named by department: "The cascade is one and the names are the organs'" (3.4). Five ageing hallmarks are one "thinning" (4.1).
- **Trials and doses (4.3, 4.4).** Fixed dose, summed scale, arm subtraction and filing adverse events as harm discard the patient's own response. Doses, reference intervals and number-needed-to-treat are population averages: "A dose arrives at a self, and a reference arrives from a society".
- **No food "authors" a restoration.** Earlier diet-as-cause claims are withdrawn (1.3, 3.4, 5.1).
- **Self-assessment (5.1).** Only the structural ideas are "understood"; every clinical application is "pattern-matching", "run at no case end to end".

### 4. Terms as this file uses them
- **bi-moral co-agency:** the basic two-way, one-at-a-time, yes/no exchange.
- **beating / living rate:** that exchange running.
- **departure:** the exchange stalled, above or below its range.
- **substrate:** the tissue or level at which it happens.
- **carry:** what is brought forward. **Attentioning** is its ageing, a count climbing to a bound and then release. **Sequencing** is being read or used, which resets it. These replace "conserving/extending".
- **collar:** a crossing point where two societies meet (gut barrier, liver, marrow). **Tunnel:** the gut or blood route.
- **bounded whole / bounded self / bounded zero:** three places a problem can enter.
- **floating neutral, sway:** a balance between two opposed processes with no fixed point. **Compaction:** forcing it to a target.
- **coefficient one / two:** a signal offered that the body takes or not, versus a magnitude driven one-way. **Ingestion / ingression** are the same pair.
- **sensor-sensationer, bi-coupler:** a hypothetical medicine or device that offers a signal and reads the reply.
- **soldier:** an entity defined only by its job in a one-way story. **Ghost:** an observer or thing installed where none exists.
- **emanation:** a non-living form shed by a living society.
- **cell society / surface society:** the cells, and the tissue they form.
- **locus reading; three refusals; holdings** (forced-choosing, value-pinning, line-demanding and others); **clean cut** (a discarded category).
- **Register words:** "Observation", "Reading", "On the form", "re-sees"; "knifed" (tested); "sounded ahead / fitted after" (predicted versus fitted); "nye", "seam", "reaches yet" (open).

### 5. Ties to the resolver and the numbers
- **Seventeen names:** none appear.
- **Resolver:** invoked four times, in older terms.
  - 1.1: a carry "opens by one… returns to nought… separates and leaves at its bound", with attentioning equated to "inseparating" and sequencing to "surfacing".
  - 2.3: "the resolver read through sixteen substrates carves a wave, period ~6.8 substrates".
  - 3.1: "The resolver at gene prime cycles frequency first and position second."
  - 4.3: the resolver in four programming languages, "Seven auditable steps where the others run eight", used to call the medical record a redundant eighth step.
- **Primes:** "gene prime", "tissue prime", "organism prime", "electron-transporting prime", and prime-gap tiers (gap-2/4/6) for organ turnover. The file admits "the numbering is this set's own and not the field's" (2.2).
- **Phi:** a thinning rate of (1/phi)^prime and a ratio of (1/phi)^(prime gap) (3.1), and a restorability threshold of 1/φ³ (1.2). The file admits "no measured biological rate has been shown to *stand* at a (1/phi)^prime" (3.1).
- **24 and 36:** explicitly retracted. "Both are identities, and an identity carries nothing about a cardiolipin or about a cell" (2.2).
- **118:** the periodic table, as an analogy (5.1).
- **17, 59, 60, 440:** absent. 120 appears only as red-cell lifespan.

### 6. Evidence
- **(a) Code or arithmetic:** there is no code and no kit for this file. The only arithmetic is 4! − 1 = 23 and 36 − 6 = 30, used to retract earlier claims. Resolver results are quoted from elsewhere, not reproduced.
- **(b) Published observations:** 21 passages are labelled "Observation", but the file gives no author, journal, year, link or reference list.
  - Concepts named in the file: Warburg effect, Yamanaka factors, Peto's paradox, Easterlin paradox, dodo bird verdict, hygiene hypothesis, hormesis.
  - Studies I can identify from the descriptions (my identification, not the file's): antibiotics blunting flu-vaccine response (Hagan 2019); stromal cells needing to die (Galleu 2017, Pang 2021); CD19 CAR-T in lupus (Mackensen 2022); HIV remissions after wild-type and heterozygous CCR5 donor transplants; HIV integration in BACH2/STAT5B; bacterial persisters; cardiolipin and the NLRP3 inflammasome; the ALCAT1 knockout; the Tanzanian diet-switch trial (2025); cristae potentials (Wolf 2019); the antidepressant placebo trend (Khan 2017); the X-linked myotubular myopathy gene-therapy deaths.
  - The file says three items are second-hand and unchecked: the twin-transplant figure, the DDIT4/ZNF254 cohort, and the diet-trial rates (5.1).
- **(c) Assertion or analogy:** the carry mechanism applied to cells; coefficient one/two; every prime and phi seating; cancer as collapse; virus as emanation; the bi-coupler; the fission/fusion analogy; childbirth "de-synchronization"; and the "13 of 14" organ ordering, where the organs are unlisted and the tiers are the framework's own.

### 7. Vocabulary age
Old throughout; v331 is about fifty versions behind the current v380R.
- **Released words (occurrences):** sign/signs (78), membrane(s) (145), surplus (14), turn(s) (22), run/runs/running (107), hold/held/holding (114), every (50), count(s) (23).
- **Retired sayings:** "co-offering" (10), "not-self" (2).
- **Self-superseded words:** "conserving/extending" is still used at 1.3 and 2.2 although 1.1 says it was replaced.
- **Old resolver words:** surfacing, inseparating, inversioning, bounding-zeroing, a "four-step cycle", figure-8, right turn.
- **Current words:** "parity" appears once; no momentary, abundancing or podaling.
- **Updating needed:** wholesale, and not only wording. Its carry note says the ageing-carry mechanism is "the old code's".

### 8. Open concerns
**Flagged in the file:**
- The compaction reading against dose-to-level drugs (insulin, anticoagulants, levothyroxine, lithium, antiepileptics, immunosuppressants): "stands not-yet" (closing).
- Phi and prime rates are unmeasured.
- "The cochlear membrane's own fatty acid composition stands unpublished" (3.5).
- The childbirth "coordination band" is unresolved (1.4).
- The more-than-additive test is unrun.
- A list of withdrawn claims (5.1): psychiatric aetiologies, omega-3 as antidepressant, food as primary determinant.
- Open seams to Natural Biology.

**Flagged in the carry note (v380R):**
- "Next at this file: none; the sciences paused."
- Fetal cells crossing the placenta contradict "only a sign crosses."
- A backlog of queued material: twin pregnancy, gap junctions and arrhythmia, pacing devices.
- An unfixed concern: "eight sentences… reading as guidance to a person". Three are named (worse-before-better, the 1/φ³ threshold, a diet named as a disease's cause); the full list was lost. The author's recorded instruction is "none of them should read as guidance."

### 9. Accuracy notes

**Wrong or doubtful as stated:**
- **2.3, "The serous membranes… the synovium at each joint, the meninges at the brain".** Synovium and meninges are not serous membranes. A friction rub comes from inflamed surfaces, not "too-thin fluid", and tamponade is a pericardial pressure problem, not "too-thick".
- **2.2, "no exception across the stem cell types: glycolytic metabolism in quiescence, oxidative phosphorylation in activation".** Wrong. Blood stem cells fit, but quiescent muscle and neural stem cells run on oxidative metabolism and shift toward glycolysis on activation. Resting and memory T cells, which 3.1 applies this to ("the glycolytic metabolism running and the mitochondrion holding still"), do the opposite.
- **3.1, "Every one of those is the cell doing with its own machinery…".** Reverse transcription and integration are done by enzymes the virus encodes and carries. Likewise "A particle… does nothing further" overlooks that HIV particles mature enzymatically after budding.
- **3.1, "The copying is integration-driven proliferation into a growth gene".** Overstated. The field attributes most clonal expansion to antigen-driven and homeostatic proliferation.
- **1.3, 2.2, 3.1, stromal cells "cleared the reservoir".** Overstated. 3.1's own wording is "correlated with marked clearance of SIV-positive cells and viral reduction".
- **2.2, "nothing is aimed at the departed carry".** CAR-T cells kill B cells, and transplant conditioning plus donor immunity kill the recipient's blood cells. Two of the three "coefficient-one" examples are intensive killing therapies, which contradicts the file's own "Driving a killing magnitude is coefficient two."
- **2.2, "an antibody that also depletes B cells is followed by relapse near three months".** Doubtful. Depletion and flare usually come later, at roughly 6–12 months (medium confidence).
- **3.1, "Cholesterol departing the membrane… opening the coupling surface".** Unclear. If it means cholesterol loss eases entry, the depletion experiments show the reverse.
- **3.4, "A randomized crossover… Two weeks, and the same rate each way."** The trial this appears to describe used separate groups and a fixed two-week exposure, so equal rates were not measured.
- **3.4, deep sleep.** "cardiolipin remodels and reactive-oxygen-damaged phospholipids clear during the deepest" is unsupported as far as I know, and glymphatic clearance during sleep is contested.
- **3.4, "A dietary ratio departing from the ancestral balance…".** A contested hypothesis stated as fact, and in tension with the ALCAT1 paragraph that follows.
- **2.3, peristalsis.** The item is labelled "*Observation*" but is resolver output.
- **2.3, "thirteen match… zero contradict".** Uncheckable, since the organs are unlisted. "skin 14–21 days" is low; about four weeks is usual.
- **1.4, "by de-synchronization".** Effective labour depends on synchronised contraction. "the baby's conditions only improve" is unsupported.
- **3.6, "three children died of liver failure".** Four died in that programme.
- **4.3, "arriving early, at every participant".** Not every participant gets a rash, and the link between adverse events and survival is inflated by survivorship (immortal-time) bias.
- **Minor:** "share their enzymes" (2.1); leukaemia "sanctuary sites" given as lymph node, spleen and liver (3.2), where classically they are the central nervous system and testes (low confidence).
- **Contested but marked as "reading":** mutations as a consequence of cancer. The pro-resolving mediator literature behind 3.3 is itself disputed.

**Passages a reader might act on:**
- **Treatment generally.** "An intervention… authors nothing" (preamble). Unhedged.
- **Getting worse on treatment.** "Which names the crisis model as a ghost" (1.2). Partly hedged: surgical harm is "a cost, entered and read". The project has flagged this one.
- **A numeric threshold.** "above 1/φ³ of the flank average… the intervention targets the precision at the departed substrate" (1.2). No observation, no hedge. Flagged by the project.
- **Tests, ranges, diagnosis.** Tests are "one-way instruments" (1.1). "The level-instruments are late by construction" (1.2). "the reference range, the normal value, the setpoint" and "the protocol, the prognosis, the stored diagnosis" are listed as installed errors (4.1). "The record is a flow held as a store" (4.3). Unhedged locally.
- **Dose targets.** "titrating to a setpoint forces the tipping rate equal to the dosing rate" (1.1, 2.1). "A level read as a target is the compaction" (4.4). The only hedge is the closing "stands not-yet".
- **Dose.** "the same molecule is medicine or poison by the coefficient of its coupling… the coefficient makes the poison" (4.2). Unhedged; could be read as favouring token dosing.
- **Side effects.** "Side-effecting is co-competencing" (4.2). "The returned sign carries the outcome" (4.3). Hedged by "high-grade events arriving alongside no favourable survival".
- **Stopping medication.** Non-compliance is "the person's own co-offering" (4.2). "the strongest sign a self offers is leaving" (4.3). Unhedged.
- **Cancer.** Chemotherapy is "a capture answering the capture"; the aim is "the co-competency restored rather than the cell killed"; metformin is "the conserving restored at one crossing" (2.2), although a large adjuvant breast-cancer trial of metformin was negative. Hedged by "the direction claimed and never a cure assured".
- **HIV.** "There is no infecting because there is no actor left over after the turn"; "letting the carry stay off-sequencing and age reads nearer the living release" (3.1). Strongly hedged elsewhere:
  - "touches no treatment" (3.1).
  - "on *action* the reading arrives beside the field, not ahead of it" (3.1).
  - "**Does not sustain:** that the ingression did not happen… or that the drugs act by any route other than the enzymes they are built for" (3.2).
- **Stromal-cell infusions.** Called "this file's strongest restoration" (1.3). Unhedged.
- **Childbirth.** "volatility risk is increased by control and decreased by coupling" (1.4). Hedged: "a uterus de-synchronized too far is dysfunctional labor", "conceptual".
- **Diet.** The file withdraws "*eat X to restore the tissue*" (1.3) and says "Nothing here is a food restoring a tissue" (3.4). It still asserts the "ancestral" ratio (3.4, 4.1) and builds 3.5 on omega-3 and hearing.
- **Mental health.** "restoration through breath, vagal coupling, sleep, therapy, mindfulness, and social coupling" (1.3). Benign but unhedged. Psychiatric diagnoses are "a line held as a fact" (4.1). The omega-3 antidepressant claim is withdrawn (5.1).
- **Vaccination.** Only "Antibiotics given before influenza vaccination reduce the antibody response" (1.2). Descriptive; nothing discourages vaccination.
- **Devices and surgery.** No advice; the bi-coupler is hypothetical.
- **Research ethics.** "Further interruptions, samples, consent, and assay development all fall away" (3.2).

There is no general "not medical advice" statement, and the hedges sit far from the passages they qualify.

---

## FILE 2. Exhibit TWENTY-FIVE, Living Society Registry, v347

`/home/claude/chris-j-handel/corus/Exhibit_TWENTY-FIVE_Living_Society_Registry_v347.md` (1,013 lines, about 12,000 words)

### 1. Subject and purpose
This is a registry that re-describes published measurements in one fixed template. Each entry takes a quantity a field reports for a collective (a temperature, rate, constant or count) and argues that no individual member has it: it is a reading of the members' agreement. The entry then records what the field does with the members that disagree. It is the "arrival" half of a pair; observations are first screened at a ten-line "door" in Exhibit TWENTY-SEVEN.

### 2. Structure
- **Part 1, rules (about 2,100 words).** Purpose (1.1); the ten-line pattern and the door (1.2); what stood "upstream" of an observation (1.3); instruments sum (1.4); the template (1.5); order of working (1.6); words for residuals (1.7); stripping agent-words (1.8); empty lines (1.9); seven break conditions (1.11); nye marks (1.12). There is no 1.10.
- **Part 2, 22 entries (2.1–2.22),** each 280–520 words.
- **Part 3,** a worklist of 37 future substrates and a running tally.

**Entry format.** Sixteen fixed labels: Society met; Members met; Upstream (source posited, method run, instrument, inferencing prior); Magnitude read; Members agreeing; Members parting; Any member carrying it; Apex standing; Seam standing; Passing; Words carried; Stripped; Standing in the ten. From 2.6 onward there is also a "Door" line pointing to TWENTY-SEVEN.

**Fields the entries come from:**
- Bioenergetics: mitochondrial temperature.
- Genomics: chromatin domains.
- Physical chemistry and spectroscopy: proton conduction, the water dimer, the hydrogen iodide equilibrium.
- Psychophysics: the detection threshold.
- Quantum field theory: the Unruh effect.
- Nuclear physics: lithium-11.
- Cold-atom physics: Efimov trimers.
- Electrophysiology: the resting potential.
- Cardiology: the sinoatrial node.
- Climate science: the carbon budget.
- Evolutionary biology: the greenish warbler ring species.
- Ecology: trophic efficiency.
- Astrophysics and cosmology: solar neutrinos, the Hubble tension.
- Quantum and statistical physics: single-electron interference, a single-electron Szilard engine, RNA-hairpin pulling.
- Biochemistry: protein melting, single-enzyme turnover.
- Clinical physiology: continuous glucose monitoring.

**How sources are cited.** They are not cited by name, as policy: "No names and no history are carried" (1.12).
- Sources are recognisable only by description, exact figures (for example 369.15 ± 0.65 keV, 1105 ± 10 cm⁻¹, 0.306 ± 0.026 ± 0.024, 67.4 ± 0.5, 73.04 ± 1.04) and an occasional year (1978, 1984, 2002, 2014, 2020, 2023).
- Unverified figures carry "nye": 27 uses across about 13 entries, plus one "for fetch".
- There are no links or reference list. Cross-references are internal, such as "Door. TWENTY-SEVEN 7.8" and "Beside it here: 2.x".

### 3. Main claims
- **Collective quantities are agreement.** "A magnitude read across a society is a reading of the agreement among its members" (1.4). Finer instruments reproduce the same form one level down.
- **Hidden prior commitments.** Every observation arrives with four: the source assumed, the method, what the instrument sums, and what kind of thing was presumed (1.3).
- **Disagreement is filed under absence words.** Leak, futile, dark, noise, baseline, heterogeneity, outlier, drift, error, compensation: the residual "is usually the larger part" (1.7).
- **Matching, not inference.** "There is no inferring here"; "Nothing is inferred from a fill and nothing from an empty" (1.2). Empty lines are recorded as findings.
- **Strip the agent-words.** Published sentences contain "doers", "walls" and "one-ways", to be stripped back to the measurement (1.8).
- **All 22 entries answer "Any member carrying it" with No.**
- **Recurrence is the support.** "Where the same ten fill at substrates that do not cite each other, the pattern stands" (3). The showcase is 2.7 and 2.8: three bodies bound where no two are, in a nucleus and in cold atoms.
- **Each entry is assigned a "holding".** Examples: a rate held as a fixed value (resting potential, Hubble constant, equilibrium constant, enzyme rate constant); a membrane held as a cut (threshold, species boundary, melting point); a magnitude demanded from one vantage (Unruh, solar neutrinos, fasting glucose).
- **Fields have released some fixed things themselves.** The master pacemaker cell, the "solar neutrino problem", the "missing sink".
- **Seven advance break conditions, F1–F7.** F6 is "the check the collection most wants run" (1.11).
- **Strained fits are to be entered too** (final line).

### 4. Terms
- **society / members / grain:** the collective, its units, the scale.
- **magnitude:** the reported quantity.
- **upstream:** the commitments made before measuring.
- **co-competence:** members agreeing. **Residual:** the part that does not agree.
- **apex:** a position no member occupies, such as a mean, midpoint or common period.
- **seam:** where two sides do not relate, with crossings both ways and "no wall".
- **passing:** what arrives is not what left.
- **doers, walls, one-ways; stripped:** agent-words in published sentences, and the same line restated as the measurement.
- **the door:** TWENTY-SEVEN's ten-line screen.
- **nye:** not yet checked.
- **the ten:** used for three different tens, namely the pattern lines (1.2), the door lines, and the ten "holdings" of Exhibit TWENTY-TWO.

### 5. Ties to the resolver and the numbers
There are almost none.
- **Resolver:** one sentence in 1.2 says three door lines ("surplus, bound and reach: the self's own surfacing and inseparating, and the society's torusing… in Exhibit ONE's names") have no line in the pattern yet.
- **Seventeen names, primes, phi, 17, 24, 59, 60, 118, 120, 440:** none.
- **Organising number:** ten. The cross-walk between the three tens sits in TWENTY-SEVEN 7.10, not here.
- **Other numbers:** the fields' own, for example 22.7 and 515 for Efimov scaling.

### 6. Evidence
- **(a) Code or arithmetic:** no code and no kit; only trivial arithmetic (20 mV and 130 mV offsets, "millionfold", 22.7² ≈ 515).
- **(b) Published observations:** all of Part 2. The sources are unnamed; my identifications are:
  - hot mitochondria against the heat-conduction critique (Chrétien 2018; Baffou 2014)
  - single-cell chromatin tracing (Bintu 2018)
  - the water dimer on copper at 6 K (Kumagai 2008)
  - the lithium-11 mass (TITAN 2008)
  - caesium Efimov resonances (Kraemer 2006) and helium trimer imaging (Kunitski 2015)
  - the Global Carbon Budget 2023
  - greenish warbler genomes (Alcaide 2014)
  - trophic efficiency from 48 models (Pauly and Christensen 1995)
  - SNO, Planck 2018 and SH0ES 2022
  - single-electron interference (Tonomura 1989) and the Szilard engine (Koski 2014)
  - RNA pulling (Liphardt 2002)
  - glucose monitoring in healthy adults (Hall 2018)
- **(c) Assertion:** the pattern itself; "All ten stand filled" (18 of 22 entries, with the line-by-line readings held in TWENTY-SEVEN 7.8, not shown); the holding assignments; and the "stripped" restatements, for example "fitness is a population accounting installed as a bird's possession" (2.12).

### 7. Vocabulary age
- **Template labels built on released words:** "source posited", "method run", "held as", "standing", "count".
- **Released words in the text:** sign/signs (22), membrane(s) (26).
- **Retired saying:** the title phrase "living society".
- **Older forms:** the holdings are in the "held as" form (now "named as"); the resolver names are older ("surfacing", "inseparating").
- **"ring":** 13 times, mostly the field's own "ring species".
- **Current words:** no parity, momentary or "the between".
- **Updating needed:** moderate and largely mechanical, since the content is field observations.

### 8. Open concerns
**Flagged in the file:**
- The nye marks and one "for fetch".
- The pattern lacks lines for surplus, bound and reach "until the pattern is widened at a next version" (1.2).
- Entries 2.1–2.5 predate the door.
- Empty lines in 2.1, 2.2, 2.4, 2.5 and 2.15 ("Filled at eight; 3 nye and 6 empty").
- F6 is unrun.
- 37 substrates are "unworked".

**Flagged in the carry note:**
- "Next at this file: none from the code."
- The holdings need renaming.
- 13 "ring" sayings.
- "The technology is all or none" conflicts with a later definition of "technology".

**My observations:**
- 2.1 has "Apex standing. Empty" beside "All ten stand filled". These refer to different tens, which the file does not say.
- Three of the "unworked" substrates in Part 3 already have entries.
- No counter-case can appear here by design. Failures go to TWENTY-SEVEN, so all 22 answering "No" is not independent support.

### 9. Accuracy notes
- **2.3, "Proton mobility, orders of magnitude above any other ion".** Wrong. It is about 5–7 times sodium or potassium and under twice hydroxide.
- **2.3, "Degassing raises the diffusion tenfold".** Stated flatly with no nye. I believe it traces to one group's contested report (medium confidence).
- **2.3, "Water crosses, protons do not, no wall anywhere".** The standard account of aquaporins includes an electrostatic barrier.
- **2.15, "69.6 ± 1.6".** Appears to blend two published red-giant values (69.6 ± 0.8 ± 1.7 and 69.8 ± 0.6 ± 1.6). Minor.
- **2.19, "the first equilibrium measured in both directions at the close of the nineteenth century".** Arguable. Equilibria were approached from both sides in the 1860s; this holds only in the narrower sense of forward and reverse rates both being measured.
- **Could not verify:** "0.76 a year root-mean-square" (2.11); "1978" (2.10).
- **Consistent with what I know:** the figures listed under item 2; 22.7 and 515; −70, −90 and +60 mV; 8.8 ms.

**Health guidance:** none. The nearest is 2.22: "Healthy people reach ranges that name disease and return" and "the set point is the mean installed… the interval is a population's". It describes healthy volunteers and carries "nye at the fractions", but could be misread as saying out-of-range glucose does not matter. Part 3 queues medical substrates ("the tumour margin and the infarct edge", "the population under a dose, a range, or a threshold").

---

## What a collaborator most needs to know
- **Both files are old.** They predate the current vocabulary and resolver by 30–50 versions. For ELEVEN this is substantive: its own carry note says the ageing-carry mechanism is "the old code's", so updating means re-deriving, not swapping words. TWENTY-FIVE needs mostly relabelling, plus an explanation of its three different "tens".
- **Neither names a source.** TWENTY-FIVE does this by policy. Any fact-check starts by re-identifying the study; ELEVEN's 5.1 ledger and TWENTY-FIVE's nye marks are the files' own maps of what was checked.
- **ELEVEN is the sensitive file.** The author has said nothing in it should read as guidance, and the project has an open, unfixed concern about sentences that do. The hedges exist but sit far from the claims, and several biology statements are wrong as stated. A sensible first pass is to fix those facts and move each hedge next to its claim.
- **ELEVEN sets a useful precedent.** It already retracts its own numerology (24, 36) and its food-as-cause claims, and it separates "Observation" from "Reading".
- **The sciences are paused.** The project lists medicine as "paused", with a backlog of incoming material.