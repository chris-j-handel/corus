# Brief: Exhibit THREE (Natural Numbers) and Exhibit FOUR (Natural Mathematics), both v380L

Both files were read whole, front to back (THREE: 1,012 lines including a 441-row table; FOUR: 460 lines), plus both carry files. I checked the arithmetic with my own scripts: 70 grouped checks on THREE's prose, every one of its 441 table rows, and 46 grouped checks on FOUR. **I found no false arithmetic in either file.** Nothing in the repository was changed or run, and I ran no git commands.

- This brief: `/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/reports/Brief_Numbers_and_Mathematics_exhibits.md`
- Check scripts: `/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/work/` (`check_three_prose.py`, `check_three_table.py`, `check_four.py`, `spiral_rule.py`, `released_words.py`)

## Corrections to the background notes you gave me

- **The "seventeen primes" are 2 through 59** (sum 440). The primes 5 through 59 are fifteen and sum to 435. The files now say "added", not "joined".
- **118 is not claimed.** THREE 7.1: "The periodic table's one hundred eighteen elements are a field's own result at the same numeral, and no number of the method."
- **The 4n rule for spirals is about odd numbers, "prime or not"** (THREE 7.2). Primality only removes the intermediate periods.
- **"The right spiral step" has two formulas.** THREE 8.2 gives (x, y) → (y, −x); FOUR 2.4 gives (P, Q) → (−Q, P). These are opposite quarter-turns unless the pair order is swapped. The author's carry notes already list this.
- "Seam" never stands alone in THREE: 24 is "the second seam-face" and "the apex". In THREE, 256 appears only in the table.

---

# EXHIBIT THREE · Natural Numbers

Subtitle: "Co-Sequential Bi-Unrelationing".

## 1. Subject and purpose

A number-by-number account of how the framework reads the integers. Every whole number is the same binary alternation at a different place, related to others only by a few moves: neighbour pairs, mirror pairs on a ring, and cycles among the seventeen resolver names. The file builds a scaffold from the names 1–17, the first seventeen primes and "rings" of 120 and 440, and ends with a table of every number from 0 to 440.

## 2. Structure

| Part | Covers |
|---|---|
| ONE Uni-scaling | Overlapping "momentaries"; the one move and its four-cycles; odd = along, even = across |
| TWO Corusing | A number "coheres" only at an exact identity |
| THREE Unrelationing | Fibonacci, φ, torus windings, recurrences that close |
| FOUR Torusing | Sphere versus torus; 360 and 440 |
| FIVE Uniquenessing | How the seventeen names are numbered; 8, 5, 10, 9, 6 in turn |
| SIX Apexing | "Seam-faces"; 24 as apex; 16 → 48 → 146 → 440 |
| SEVEN Coupling | The seventeen primes; spirals and tori of selves; gaps; noble gases |
| EIGHT Inseparating | Even and odd rings; exclusive-or; "a store" |
| NINE Tunneling | The ring of 440; the 2^k + 1 chain |
| TEN Transmissioning | Rules for matching a science's number to one here |
| ELEVEN Each number | The 0–440 table |

## 3. Main claims, most important first

- Every integer is one form, the alternation, and no scale is privileged. "Numbers are uni-scaling: each number crosses with all numbers arriving as one, and each is the one form once more." (1.1)
- Counting, units and measurement belong to the sciences' instruments; here numbers relate only through the framework's own moves (1.1, 10.1).
- Odd is "along" (self, competency: co- or tri-). Even is "across" (other, morality: bi-). Spans of eight alternate self and society: 1–9, 9–17, 17–25 (1.5).
- One move in three steps (8 up or down, 17 − n, 9 − n) sorts names 1–16 into four four-cycles: 1-9-8-16, 2-15-7-10, 3-11-6-14, 4-13-5-12. Name 17 is outside, "the next momentary's 1" (1.4).
- Neighbours "straddle" a number one short of its square (1.3). At odd centres this gives "seam-faces", (2k + 1)² − 1 = 8 · T_k: 8, 24, 48 … 360, 440 (6.1).
- Only exact identities count. "A magnitude brought near a number by division or by a chosen unit coheres with its own reaching and never with the number" (2.1).
- 440 is the working ring: the first seventeen primes added, 8 × 55, and 21² − 1. Numbers pair "podally", k with 440 − k, about a waist at 220 (2.2, 9.1).
- φ is "the unrelationing rate", locking to no rational; "the resolver carries it at no line" (3.1).
- The primes 2–59 "go out" and are mirrored 61–118 about 60; 24 is the "apex", nine primes below and eight above (6.3, 7.1).
- A spiral of n coupled selves repeats its parities after 4n steps when n is odd and after 2 when even; a p × q torus at q or 4p (7.2). Reported from the code.
- The chain 3, 5, 9, 17, 33, 65 (2^k + 1) gives the "wholes", one for each number k of parities: 1–9 at three, 1–17 at four (9.7).
- Matching numerals prove nothing: "a number agreeing at both sides is a relation only with the form reached at both" (10.1).

## 4. Terms as this file uses them

- **Uni-scaling**: the same form at every number. **Momentary**: an opening and its completing, one odd and one even.
- **Straddle, waist**: the two numbers either side of a centre; the centre.
- **Podal, far side, radius**: k paired with N − k on a ring of N; distance from the waist.
- **Seam-face**: an odd number squared less one. **Apex**: 24.
- **Along / across**: odd / even. **Span**: a run of eight.
- **Corusing / torusing**: a number inward to itself and outward to each place it arrives / the carrying and winding across the numbers (1.8).
- **Coheres**: holds at an exact identity, all or none.
- **Going / returning**: the primes 2–59 / their mirror 61–118.
- **Spiral of selves; like pair**: n selves coupled in a cycle; the one equal-parity adjacent pair an odd cycle must have.
- **A store**: one moment named still. **"In the field's words"**: a result quoted from standard science.
- **"At its own subject"**: equal numerals counting different things.

## 5. Ties to the resolver's names and to physical facts

To the names:
- Prefix follows the number: even → bi; odd → co (1–7, 17) or tri (9–15) (5.2).
- 17 = 1 entry + 6 names between selves (2, 6, 10, 14 across; 9, 17 along) + 10 of the self's own resolving (5.2).
- Ten roots; four repeat eight apart: competencing 5/13, moralizing 6/14, corusing 7/15, torusing 8/16.
- The code's values: "+ and − are the implementing of a parity and 0 the between" (1.4).
- Primes on names by position: 2 at 1, 23 at 9, 59 at 17 (7.7).

To nature:
- Periodic table: 118 = 2 × 59 (7.1, 7.6). Disclaimed.
- Noble gases at 2, 10, 18, 36, 54, 86, 118, stepping by twice 1, 4, 4, 9, 9, 16, 16 (7.6).
- Crystals: unit-coefficient recurrences close only at 1, 2, 3, 4, 6 (3.4).
- The standard map's golden-mean curve (3.3); the Peres–Mermin square (8.5).
- No light or spin here; those are in FOUR 3.1.

## 6. Evidence and checkability

**(a) Plain arithmetic, true (my checks):**
1. Primes 2–59 number seventeen and sum to 440 = 8 × 55 = 21² − 1.
2. Primes 5–59 number fifteen and sum to 435.
3. (2k + 1)² − 1 = 8 · T_k: 0, 8, 24, 48, 80, 120, 168, 224, 288, 360, 440.
4. The four four-cycles close under ±8 and 17 − n; 17 − (n + 8) = 9 − n.
5. 55 = C(11, 2) = T₁₀ = F₁₀; φ³ − 1/φ³ = 4.
6. The unit-coefficient recurrences have periods 1, 2, 2, 4, 3, 6; Fibonacci never closes.
7. Exactly 12 two-colourings of the pairs among five have no one-colour triangle.
8. Doubling mod 17 runs 1, 2, 4, 8, 16, 15, 13, 9, the squares mod 17.
9. 24 × 27 × 32 = 144²; 28² − 24 × 32 = 16.
10. 3 × 16 = 48; 3 × 48 + 2 = 146; 3 × 146 + 2 = 440.
11. Sixteen prime gaps: 1 once, 2 six times, 4 five times, 6 four times.
12. Six prime pairs sum to 60; their distances from 30 sum to 72.
13. 59 × 61 = 60² − 1; 118 × 122 = 120² − 4.
14. Position pairs of the primes sum to 61, 56, 52, 50, 52, 50, 48, 48; with 23, 440.
15. Name-group prime sums 88, 82, 59, 209; four-cycle sums 97, 96, 92, 96.
16. 433, 421, 409, 397 are prime; 437 = 19 × 23.
17. Peres–Mermin: none of 512 assignments meets all six conditions.
18. All 441 table rows are correct in every column and tag.

**(b) False, or true only under an unstated convention.** None false. Convention-dependent:
- 6.3, "the apex of one to fifty-nine's bi-folding" with lengths 24 and 36: those are 0–24 and 24–60. From 1 to 59 they are 23 and 35.
- 7.5, "nought to sixty … thirty-three positions": the 33 run from 2 to 59.
- 7.1, "the primes … return from sixty-one to one hundred eighteen": this is the mirror 120 − p. Only 12 of the 17 mirror values are prime.
- 8.2, "six times has reached all four joint forms": three steps already do.
- 1.3, 6.2: 23 × 25 = 24² − 1 is true at every n ("Each number is a waist alike"), so it does not single out 24.

**(c) Reported as computed at the resolver (not re-run):**
- Odd spiral of n: one like pair; inverted at 2n, repeated at 4n. Odd prime p: 4p, "or at 4 with each self alike, and at none between". Nine selves: 4, 12 or 36.
- Torus p × q, both odd: q when q > 2p, else 4p (3×5 at 12, 3×7 at 7, 5×7 at 20, 17×59 at 59). Either number even: 2, with a 2 × 3 torus "followed by hand".
- Cited to Co-Chaining Logic Registry steps 646–648 and 652–657.
- The spiral periods follow from the file's stated rule (every two steps each self takes its neighbour's parity inverted). I confirmed that consequence, not that the code obeys the rule.

**(d) Number patterns set beside facts of nature:**

| Correspondence | Derivation given? |
|---|---|
| 118 elements = 2 × 59 | No. The file's own admission: "no number of the method" |
| Noble-gas steps as twice squares; 59 = 1 + 2(4 + 9 + 16) | No. Standard chemistry, quoted. That 59 is also the seventeenth prime is coincidence as presented (my judgement) |
| φ as a rate of nature | No. Quoted support is correct; φ is at no line of the code |
| Crystals and recurrences closing at 1, 2, 3, 4, 6 | Yes, a genuine mathematical equivalence |
| Icosahedron's 60 rotations as 24 + 36 | No. Coincidence as presented (my judgement) |
| Seventeen primes on seventeen names | No. The file calls them different subjects. The sums are exact but selected: five of eight "8 up" pairs |

The file never mentions 440 Hz or 360 degrees, and its own rule (10.1) excludes unit-dependent matches.

## 7. Standard mathematics cited

All stated correctly: Brouwer's two-ity (the quotation matches his wording as I know it); Fibonacci and φ; torus windings; Greene's 1979 standard-map value, rightly called computed and unproved; the crystallographic restriction; Euler's formula and twelve pentagons; R(3, 3) = 6; the Paley graph of order 17 with R(4, 4) = 18; the twin prime conjecture; exclusive-or; Peres–Mermin. Fermat numbers are not named; most of the 2^k + 1 chain (9, 33, 65) is not Fermat.

## 8. Vocabulary and finish

The file reads finished: no placeholders, a clean table. The prose is very compressed in places (7.1, 9.7, 9.9). Words that Natural Naming v380R lists as released or under review are still present (my counts): "seam-face(s)" 31; "returning" 15; "run" family 55; "taken" family 28; "nought" 41. Some uses may be permitted exceptions; I did not judge each.

## 9. Open concerns the file itself flags

- φ: "the resolver carries it at no line" (3.1). Primes past 59 are also "at no line of the resolver" (7.1).
- "The seventeen primes, the resolver's seventeen names and its six names between selves are three numbers at three subjects" (7.3).
- "the harmonically momentarying crossings on the surface of natural torusing coupling the two seventeens are the discovering carried next" (7.7).
- A prime pattern must fail at 9, 15 and 25, "or it is oddness's" (10.1).
- "matching numerals alone coupling no relations" (9.7).
- "These are the step's own applications; the resolver runs its names at its own resolving" (8.2).

## 10. Accuracy notes

None found that are wrong. One caution: 7.6 treats 118 as "the table's own result". It is where the seventh period closes and where discovery stands today, not a known end of the elements.

---

# EXHIBIT FOUR · Natural Mathematics

Subtitle: "Each Parity Changing Everything the Other Is Not".

## 1. Subject and purpose

A tour of mainstream mathematics, with a few physics results, read through the framework: every branch is presented as the same two-sided alternation, generated by a sign flip and a quarter-turn. It disputes no theorem. It classifies how mathematics is used, and argues that the sciences' hard problems come from fixing a zero, a unit or a frame from outside.

## 2. Structure

| Part | Covers |
|---|---|
| ONE Floating neutralling | Mathematics as a two-sided coupling; three "neutrals"; three "places" |
| TWO Orthogonalizing | The sign flip and the right spiral step (i); the maps F and G; Gray code; φ |
| THREE Accounting | Involutions and "declared zeros"; steps on a ring; two and three inversions; conservation |
| FOUR Bounding | Independent rates; constructible numbers; the double-angle map |
| FIVE Self-cohering | The "six forward" test; five dimensions; the torus in topology |
| SIX Inseparating | Scientific and "geodesic" method; logic without a completed whole |
| SEVEN Co-offering | Six co-offerings; impossibility theorems; four squares; knots; the Monster |

## 3. Main claims, most important first

- Mathematics is not an abstraction laid over nature. "Numbers, mathematics and logic are nature's own unrelationing binary method." (1.2)
- No established result is contested. "A mathematical form arrives proved, and natural mathematics disproves none." (1.5)
- Each use of mathematics sits in one of three "places": natural (parity, position, ratio), measured (magnitude, the continuum) or formal (axiom systems). "A mathematical form is placed by its use, and never by its symbols." (1.5)
- Every self sets three "neutrals" for itself: its zero, its scale, its orientation. A science fixes one or more from outside, a "floor" (1.4, 6.2).
- Fixing one neutral stops four of six "co-offerings", and a field's hard problems arise there (7.2).
- Two generators: the sign flip (−1) and the right spiral step (i, with i² = −1, i⁴ = 1) (2.2).
- Of the 256 maps on two parities' four joint states, only F(P, Q) = (−Q, P) and its opposite G are one-to-one, change one parity per step and never undo; "they are the only two of the 256 whose square is −1" (2.4).
- With the moment index included a cycle never repeats, so it is a spiral (2.3).
- "An accounting for changing is a move that, taken twice, gives its own arrival again: an involution." A "declared zero" is its fixed set treated as a place (3.1).
- Two successive inversions on different axes make a rotation by twice the angle between them (3.4). Three at once reverse handedness: "the emanating" (3.5).
- "no total is conserved across the surface"; physics' laws are "inward, each an observing's account, none refuted by it" (3.7).
- Truth test: "A false expression cannot complete the six: it fixes, stopping; it loops, giving its own state again; or it forks" (5.1).
- The torus is the one closed orientable surface that carries a flow with no rest point (5.3).
- The scientific and "geodesic" methods are both derivations; one fixes position, scale and orientation, the other floats them (6.1).
- "The changing set of all existing things" is defended against "no set of all sets" by plural logic (6.3).

## 4. Terms as this file uses them

- **Bi-moral co-agency**: a coupling of two sides acting one at a time; the result belongs to neither.
- **Floating / neutralling**: relating across (even) / keeping one's own rate along (odd).
- **Three neutrals**: own zero, own scale, own aim. **Floor**: any of these imposed from outside.
- **Natural / unnatural (measured) / supernatural (formal)**: the three places. The last "names the formal use, no paranormal existing thing".
- **Orthogonalizing**: unrelating two things so neither has a component of the other.
- **Sign flip; right spiral step; joint forms**: −1; i; the four sign combinations of two parities.
- **Accounting**: an involution. **Declared zero**: its fixed set taken as a place.
- **Halfway pairing; fold**: n with the name 4s away; n with 8s + 1 − n.
- **Six forward**: the framework's test of a valid expression.
- **Co-offering**: a directed pairing of two neutrals. **Ten inversions**: the ten transpositions among five.
- **Geodesic method**: the framework's counterpart to the scientific method.

## 5. Ties to the resolver's names and to physical facts

To the names:
- P is the along parity (competency), Q the across (morality); F takes along into across (2.4).
- Eight apart pairs names 1–16 and fixes none; 17 is in no pair (3.2).
- A side's five positions are "five dimensions": self prior, other prior, co-momentarying now, bi-momentarying now, self next (5.2).
- Code behaviour: offerings of one parity surface that parity; + with − gives 0 at 14 (3.7).
- The rings of 440 and 120 and the number 118 do not appear in this file; the seventeen primes appear once, beside the Monster (7.9).

To nature:
- Light: Malus's cos² law as a doubled angle (3.1).
- Spin: a neutron's state changes sign after 360° and returns at 720° (3.1).
- Charge, parity and time reversal each broken in the weak interaction; CPT kept (3.5).
- Surface waves driven at two frequencies (3.3); tuning's comma and the cube puzzle (3.6); a body's "seven holes" (5.3).

## 6. Evidence and checkability

**(a) Plain mathematics, true (my checks):**
1. Of 256 maps exactly two are one-to-one, change one parity per step and never undo.
2. F² = G² = −1 and no other of the 256 squares to −1; F⁴ is the identity.
3. The three-parity reflected cycle flips 0, 1, 0, 2, 0, 1, 0, 2.
4. φ³ = 2 + √5; 1/φ³ = √5 − 2.
5. cos²θ = (1 + cos 2θ)/2.
6. On an even ring k → N − k fixes 0 and N/2; k → k + N/2 fixes none.
7. A step of k round N reaches N/gcd(N, k) stations; two rounds reach mn/gcd(m, n) pairs.
8. (3/2)¹² = 129.746…, over 2⁷ by 531441/524288.
9. Cube: all assemblies divided by reachable positions is exactly 12.
10. 39² − 23 × 55 = 256.
11. cos 36° = φ/2; sin 18° = (√5 − 1)/4.
12. t → 2t/(1 − t²) fixes only 0 and swaps ±√3; a pair 5 and 1 coupled by 2 rotates 22.5°.
13. Three-valued intuitionistic negation: not-not-a is 1, not a.
14. (0, ±1, ±φ) and cyclic orderings give 12 vertices and 30 edges; 1 + 15 + 20 + 24 = 60.
15. Four squares: 8 × the divisor sum (odd n), 24 × the odd-divisor sum (even n), brute-forced to 40.
16. 8 + 16 = 24 quaternion units.
17. Pentagon: each side is parallel to exactly one diagonal, sharing no corner.
18. The Monster's order has fifteen primes: all of 2–59 except 37, 43, 53, plus 71.

**(b) False, or true only under an unstated convention.** None false. Unclear:
- 2.4's F(P, Q) = (−Q, P) against THREE 8.2's (x, y) → (y, −x), which is this file's G.
- 2.4, last paragraph: c, t and r are never defined. 6.1's "(1, 0) to (1, 1)" uses 0 and 1 where parities are + and −.
- 5.1's six "forward recursionings" are not listed.

**(c) Reported from the resolver (not re-run):**
- "Two + offered together at a sharing chained none surface + at 14, as one + does"; offered one after another, the second "carries on, 0" (3.7).
- Which name pairs are the self's ten names and the across ends (3.2).

**(d) Mathematics set beside facts of nature:**

| Correspondence | Derivation given? |
|---|---|
| Malus's law and the neutron's 720° return as two "doublings" (3.1) | No. Physics quoted correctly; the pairing is interpretive |
| C, P, T and CPT beside "three inverted at once" (3.5) | No. Placed side by side |
| Two-frequency surface waves (3.3) | No, and the file limits it: "its condition is parity and coprimality, not primality" |
| Better joint estimates from three means up (3.7) | No. Coincidence at 3 as presented (my judgement) |
| The torus as nature's form (5.3) | The topology is a theorem; the application is asserted |
| A body's seven holes (5.3) | Disclaimed: "neither is the other's number" |
| The Monster's fifteen primes beside the seventeen (7.9) | No. Partial overlap, 14 of 17 plus 71; no claim drawn |

## 7. Standard mathematics cited

All stated correctly as far as I can verify: complex numbers; Gray code; division algebras in dimensions 1, 2, 4, 8; quaternions covering rotations twice; the √5 approximation bound; two reflections as a rotation; the Pythagorean comma; the three-means estimation paradox; constructible numbers; rest points summing to the Euler number; no radical formula at degree five; the continuum hypothesis; both incompleteness theorems; four-square theorems; kissing numbers; fibred knots; the modular group; R(5, 5) between 43 and 46; finite simple groups; the Monster and 196,884. Fermat numbers and Peres–Mermin do not appear here.

## 8. Vocabulary and finish

Parts ONE to SIX read finished. Part SEVEN (7.3–7.9) is largely a catalogue of correct standard results with little stated link back to the framework. Released or under-review words still present (my counts): "floor" 8; "sign" 20, mostly "sign flip"; "kept" family 17; "run" family 36; "taken" family 35; "nought" 28. Some uses may be permitted exceptions; I did not judge each.

## 9. Open concerns the file itself flags

The file flags little; most open items are in the carry file.
- φ is "self-welcoming at the numbers and at no line of the resolver" (2.8).
- The three places "are natural mathematics' own naming and no partition the field makes of itself" (1.5).
- "a trace of phases is no trace of parities" (2.2).
- "the windings' closing and coming close are true at their model, its axes and its time" (4.2).

## 10. Accuracy notes

None found that are wrong. Soft spots:
- 3.1, "a neutron's spin rotated three hundred sixty degrees comes back with its sign reversed": it is the neutron's quantum state whose sign reverses; the spin direction is back after 360°.
- 5.3, "a surface of seven holes … at topology's count": a recreational idealisation, not an established result.
- 6.3, "A logic that admits no completed infinite, intuitionistic logic": rejecting completed infinity is Brouwer's philosophy; the formal logic is neutral on it.
- 7.8's bound of 46 is, to my knowledge, a recent computer-assisted result; I did not re-confirm it or 3.3's fluid-wave citations on the web.

---

# The two carry files (context only)

**carry/Exhibit_THREE_Natural_Numbers.md (v380R).** Next: work out, "each computed before it is said", the crossings that would link the seventeen primes to the seventeen names (7.7); settle "ring" and "the returning" in 7.1, which imply a closed loop although the primes never end; and for each numeral correspondence, state a relation or drop it. Ready to enter: a "golden triangle" passage. The v380L pass had six readers check every number and all 441 rows, with about 160 mends. Open line items: the word "seam-face"; 1.2's "one to nine"; "the apex of one to fifty-nine" using 0–60 lengths; "four, the self's own corus" missing from Exhibit ONE's tables; 7.5's heading; 8.2's "round at three" and "six"; 9.7's "next whole … 1–65". Concerns: "a numeral alone is no correspondence" (the n² − 1 identity "singles out no apex"; "fifty-nine to light"; 118); whether sixty is a position or a between; "0 the between"; "advancing"; "fourteen scales at fourteen primes, the atom at five and the cell at twenty-three", kept or released; some mends read by one reader only.

**carry/Exhibit_FOUR_Natural_Mathematics.md (v380R).** Next: the "doubled turn" material at "An involution is an accounting's still picture", and the concerns below. Ready to enter: a woven-cloth (Chebyshev net) analogy, labelled "Pattern matching, no correspondence shown". The v380L pass had four readers and about 70 mends: "Each number is as said". Open line items: 2.4's undefined c and t and an unclear sentence; the right-spiral-step formula differing from Natural Numbers 8.2; 6.1's inconsistent mapping of standard, law and frame onto orientation, position and scale; 6.1's "(1, 0) to (1, 1)"; 1.3 omitting tri; "floor" as a released word; 5.1's unlisted six; "compact" said twice in 5.3. Concerns: a v376 physics review (a sphere's flow must have a rest point; a torus can have none, "not every flow on it none"); the open task of reading the golden construction into a physical quantity, "never a resemblance made by a rotation or a cut chosen at will"; the golden triangle unnamed at 7.8.

---

# What a collaborator most needs to know

The arithmetic in both files is reliable: I found nothing false in about 116 grouped checks and all 441 table rows, so calculation is not where the risk lies. The risk is in what the numbers are taken to mean. Neither file derives a fact of nature from the resolver: THREE disclaims 118 outright and says the link between the seventeen primes and the seventeen names is still to be found, and FOUR quotes real theorems and experiments accurately but as parallels. The files' own rule is that matching numerals prove nothing, and the author's carry notes list "a numeral alone is no correspondence" as a live concern, so apply that rule yourself, including to selected sums such as those in THREE 7.7. The only number results that come from the code are the spiral and torus periods in THREE 7.2, and the 4n rule there is about odd numbers, not primes. The two files give formulas for "the right spiral step" that are opposite as written, and the vocabulary is mid-migration ("seam-face", "the returning", "floor", "nought", and the run, taken and sign families), so check both against Natural Naming v380R with the author before editing.
