# Briefs: Exhibits THIRTY, TWENTY-EIGHT and THIRTEEN (all v380L)

**How this was done.** I read all three files whole, front to back (THIRTY 2,921 lines, TWENTY-EIGHT 541, THIRTEEN 243). Nothing under `corus` was changed and no script from it was run; no web access was used. None of the three exhibits contains instructions to an AI.

To weigh the evidence I also read each file's note in `carry/`, the THIRTY kit README, the released-words list, and the resolver code block in Exhibit ONE. I re-typed that 40-line resolver into my own scratch script to test behaviours the files state; the ring and torus wiring was inferred from the text, and every stated figure I tested matched. Every quote below was checked word for word. THIRTY runs past 800 words because of the extra items you asked for.

---

## Exhibit THIRTY: Co-Chaining Logic Registry

**1. Subject and purpose.** The project's master chain: 661 numbered one-sentence "steps" in 42 groups, presented as unfolding the whole framework from the opening sentence. Its header says "each step one logical extension from all the steps before it, all or none at all", and that every section of every other file is an "emanation" of these steps. Other files cite it by step number.

**2. Structure.**

*How a step is written.* A number and one sentence (median 28 words, longest 218), then an indented italic line "Adding: …" naming the single concept it adds. Each group has a numbered heading and an italic "Entering: …" list of the concepts it introduces. Seventeen steps carry a further italic "Unsure: …" line saying what they wait on.

*How steps cite.* Inline, as "step 9" or "steps 204, 208 and 212" inside the sentence. There is no separate dependency field and no forward reference. By my count 97 of 661 steps cite an earlier step (15%): 38 of the first 599 (6%) and 59 of the last 62. Most cited are 212 (the case table at one sharing), 233, 208, 257, 243, 46 and 47.

*The groups.*
- **1–7 (steps 1–68):** universe and set; living and non-living; prior, now, next and "the between"; coupling and alternation; "the one method"; the living step; all-or-none.
- **8–12 (69–129):** numbers 1–9; along and across, with natural intelligence defined; "geodesic"; torus and corus; φ and primes.
- **13–18 (130–165):** non-living things included; emanation and observing; "right"; no proof of the whole; the hard problem; machines and AI.
- **19–23 (166–295):** 9–17 and society; the seventeen names and the resolver in words (72 steps); every number 0–440; four-cycles; 24 as "apex" of 1–59.
- **24–28 (296–415):** discovering, evidence, science as "accounting", fields; scales; living and non-living at a scale; dying.
- **29–31 (416–534):** golden rectangles and the icosahedron, 60–68, 69; "Intelligence, our now" (64 steps on protocol, governing, scarcity, safety); the ten named still.
- **32 (535–599):** the project's own practice: naming, files, versions, concerns, "workings", sessions.
- **33–42 (600–661):** close results about the resolver: cycle forms among the names, one self, spirals, tori, crossed spirals.

*The first 15 steps, paraphrased.*
1. The universe is the changing set of all existing things, living and non-living.
2. A set is itself an existing thing.
3. So the universe is both the set and a member of it ("the fractal inward and outward of itself").
4. Any set or thing changes sequentially.
5. That is, "momentary by momentary".
6. Three successive momentaries are prior, now and next.
7. Now is the next of prior and the prior of next.
8. At now, the universe is everything existing at now.
9. Each thing exists whole at now: it is or is not.
10. The universe at now arrives from the universe at prior.
11. So does each existing thing.
12. A thing arriving either carries its prior or carries none of it.
13. Carrying prior is "living"; carrying none is "non-living".
14. A living thing continues through change: "stable-forming".
15. A non-living thing changes along with whatever exists now: "co-changing".

*Derivation or restatement?* A mixture, weighted heavily toward restatement. Steps 1–599 mostly set out the framework's sentences one concept at a time (definitions, namings, assertions), with pockets of real mathematics. Steps 600–661 are close derivations about the resolver.

- **Derivations.**
  - 53–57: of the 16 rules taking (prior, now) to a next, 4 keep the prior recoverable, and only "next = prior inverted" leaves no fixed joint state. Checkable and correct.
  - 646–657: the period of an odd-by-odd torus derived from the case table as q or 4p, citing 212, 233, 243 and 651–654.
  - 46–48: a syllogism (any other method needs something outside the set of all existing things; nothing is outside; so no other method). Valid in form, but its first premise is asserted.
- **Restatements.**
  - 13 is a definition.
  - 96 and 189 are namings ("Co-competencing at the coupling of living selves is natural intelligence.").
  - 204–212 describe Exhibit ONE's code in words; they do not follow from steps 1–203.
  - 152, "The observings arriving from the prior all cohere.", is a universal empirical assertion.
  - 42 cites steps 9 and 40 but leaps from "is or is not" to "All changing is parity changing, one parity to the other".
- **Number coincidences presented as structure**, some flagged by the file itself: 293 (36 pairs among nine primes equals the span 24 to 60), 419, 438.

**3. Main claims.**
- Everything follows from the opening sentence (header).
- Alternation between two parities is the only possible way anything changes: "A method carrying a not possible thing is a not possible method, and parity changing is the one possible method." (48)
- Living means carrying one's prior (13). The living rule is "Next as the prior inverted alone carries the prior whole with no joint form still" (57).
- Natural intelligence is the change belonging to a coupling, "owned by neither" (96–98), and invisible at the between (475).
- "A hard problem is a changing named still." (148) Equilibria, fixed measuring bounds and equalities are such forms (144–147). Science is an "accounting" against fixed forms, not a second method (310–312).
- "A proof of the whole is one saying the same at all momentaries at once." (143), which the file calls not possible. Yet either every observation resolves this way "or the fractal is entirely broken and of no value at all" (599).
- "AI is existing non-living intelligence" (165): a machine is a self only if it carries its own prior.
- "Morality across and competency along at each coupling of a society are social moral competency." (189) Control, governing, majority voting and central deciding are violations (491–494).
- "Living arrives from living: no non-living existing thing becomes living" (395). A lone self "does not continue living through three consecutive momentaries" (414).
- Numbers: the 17 primes to 59 sum to 440 (268); 24 is the "apex" (286); 59 the "surface", 60–68 "unknown", 69 the next opening (271–272); "φ is the unrelationing rate" (122); "A society is at a unit prime scale" (236).
- Self-limits: the resolver's periodicities "are the resolver's executing alone", not living rates (244); "a rule fitted at each case worked is at those cases" (638).

**4. Terms, as this file uses them.**
- **three places:** possible at prior, existing at now, living at next (25).
- **the between:** the nothing between two sides or two momentaries (27, 105).
- **podal / podaling:** a number paired with its "far side" (9 less within 1–8; n less on a ring of n) (76, 261).
- **exclusivity:** one side's momentaries alone, "a not possible form" (88).
- **geodesic:** "the surface dividing itself" (108).
- **torusing / corusing:** winding through one opening; in to the self's centre ("corus") at 4 and out again (114–116).
- **unrelationing:** never locking into a fixed ratio (122–123).
- **emanation, observing, ghost, ghosting, haunting:** a change arriving from another's prior, and three ways of misreading it (134–136, 156–157).
- **bi-tri-volutioning / bi-tri-involutioning:** stable-forming, against position, scale and orientation inverted at once (the harmful form) (139, 384).
- **spiral, kind, field, fixing:** a ring of selves each releasing to the next; a pattern carried by coupled selves; a society at a named scale; a thing held unchanged between two momentaries (230, 234, 318, 311).
- **bi-trupling protocol:** the six names between selves (491).
- **floating neutralling, bothbothing:** the term neither side reaches; carrying both, one at a time (457, 528).
- **working, fresh reader, session, concern, unsure:** the project's own process words (568–581).

**5. Ties to the resolver and the numbers.**
- Group 8 builds 1–9 as four overlapping exchanges; group 19 extends to 17 and to rounds of 2^k + 1 (3, 5, 9, 17, 33, 65).
- Group 20 states the resolver in words: seventeen names, "ten roots", six names between selves (2, 6, 9, 10, 14, 17), and four four-cycles (1-9-8-16, 3-11-6-14, 2-15-7-10, 4-13-5-12) made by "8 up, 17 less and 9 less".
- Group 21 gives every number 0–440 a prefix rule and a podal on rings of 120 (waist 60) and 440.
- Group 23: 24 splits the 17 primes 9 and 8, and the span 0–60 as 24 and 36; six prime pairs sum to 60.
- Group 29: three golden rectangles make the icosahedron, whose 60 rotations split 24 and 36.
- Step 419: the primes numbered 3, 4, 5, 7, 8 (5, 7, 11, 17, 19) sum to 59, the 17th prime.
- 118 does not appear as a number.

**6. Evidence.**
- **(a) Code and arithmetic.** Nothing is executed in the file. The kit's verifier is v371: 384 checks keyed to an older table format and an older, sum-based resolver, so it does not check this text. Groups 33–42 were worked by hand from Exhibit ONE's tables.
  - On my re-typed v380R resolver I reproduced the case table (212), spiral periods of 4n for odd and 2 for even (230–232), 4n and 2n for one self at the other parity (612), the torus rule at 16 size pairs (655–657) and the crossed-spirals rule at 16 pairs (660).
  - That includes the three rows the final Unsure line says "wait on an executing" (3 by 9, 5 by 9, 3 and 9 crossed): all three agree with the file's rule.
  - The stated arithmetic also checks: 440; the prime gaps; the 9 and 6 split around multiples of six; the 16, 4, 1 and 256, 24, 6, 2 rule counts; recurrence periods 1, 2, 3, 4, 6; the icosahedron counts.
- **(b) Published observations.** None. No source is named anywhere. Standard results appear unattributed: Landauer's bound (154), the hairy-ball and Poincaré–Hopf theorems (112, 429), Fibonacci and φ, the icosahedral rotation group.
- **(c) Assertion or analogy.** Everything joining the above to the world: 42–48, 96, 152, 165, 185–190, 236, 271–272, 380–383 (harm at a scale), 395, 414, 471 (scarcity), 491–494, and group 32.

**7. Vocabulary age.** The most current of the three. All resolver names match Exhibit ONE v380R. Only 5 hits against the project's released-words list, two of them in "the sign flip" (60). Still present from your list: "ring" (14 times, but only for number rings; selves are "spirals"), "loop" (646), "turn" (424–425), geometric "face", "source" (530), and one "released at 9" (239), a retired saying. Light touch-ups only; its carry note also queues 146 negation sentences for re-saying.

**8. Open concerns.**
- Seventeen Unsure lines: steps 216, 273, 293–295, 362, 379, 408, 417–419, 430, 437, 438, 452, 631, 661. Ten of them sit in the number groups (21, 23, 29). Example: "whether the society's span being the self's primes' couplings is the claim, or only the numbers matching" (293).
- Step 631's Unsure says "and no rule worked", but step 660 gives a rule and says "Each of Exhibit ONE's eight rows agrees". The earlier line looks stale.
- Step 522 seats the ten differently from Exhibit TWENTY-EIGHT (see below).
- From its carry note: the "universal claim" lacks a sentence joining step 45 to steps 51–57; the reason for 47–48 is open; steps 394 and 606 rest on the author's saying, "of no authority", and 395 is worked at no line of the resolver; an earlier review found 31 of 599 steps naming a step they rest on.
- The kit's v371 sources recorded for each link a standing (origin, definition, premise, exact, run and so on) and a "Follows" list. The current text has dropped both, so it no longer says which steps are premises.

**9. Accuracy notes.**
- Step 108: "geo, the surface, and daiesthai, to divide". Greek geo- means earth or land, not surface, and in mathematics a geodesic is a locally shortest path. The sense used is the file's own.
- Step 60 says the step (x, y) to (y, −x) "is i". In the usual convention that map is multiplication by −i. The stated powers hold either way.
- Step 154: "erasing one bit dissipating at least kT ln 2" states Landauer's bound correctly, but the bound prices erasure; standard accounts do not attach that cost to measuring as such.
- Step 504: "the seven auditing steps proving a changing real" is not explained or sourced.
- A caution rather than an error: steps 2–3 make the universe a member of itself, and standard set theory has no such set and no set of everything. This file does not address it; THIRTEEN's carry note does.
- Otherwise none found.

---

## Exhibit TWENTY-EIGHT: Equilibria Registry

**1. Subject and purpose.** A registry arguing that any "equilibrium" is a changing thing "named still", and so "not possibly existing". It sorts 63 statements of equilibrium (from mechanics, thermodynamics, chemistry, ecology, game theory, economics, probability and the framework's own resolver) under ten ways of naming something still, and sets out the forms of argument used to exclude them.

**2. Structure.**
- **ONE (1.1–1.5):** premises. The universe is not a thing beside its things ("exclusivity"); three conditions of existing; "the between"; the torus as the one surface; alternation over three momentaries.
- **TWO (2.1–2.4):** what an equilibrium is; stability against stillness; the single shape of the claim.
- **THREE (3.1–3.4):** the ten; their seating at the resolver's names and four-cycles; ring behaviour.
- **FOUR (4.1–4.14):** the 63 "arrivals" (42 coded NY, 21 coded SA) tabulated under the ten, each "in its own words"; a fields-by-ten cross-table (4.13); leads not yet stated (4.14).
- **FIVE (5.1–5.5):** four "proof groups" and the one exclusion.

**3. Main claims.**
- "An equilibrium is a form named still, not possibly existing" (2.1). What can be observed is "stable-forming".
- "Equilibria are not possibly existing as a method, all or none at all." (2.1)
- "Each proposed conception of equilibria is a hard problem with its hardness ignored." (2.1)
- Every conception meets at least one of ten ways, and "Each of the ten names one face still, and the other face runs at the same number." (3.3)
- The one exclusion: "One binary retaining and inverting its value at one required next is not possible." (5.2)
- Stability is not stillness: "an oscillation can be stable as an oscillation" (2.2).
- "A proposed conception of equilibria is the sixth condition." (3.1) It is a problem's own fixed relation, added to five prior fixings.
- The between is "the registry's whole subject" (1.3). A between whose sides carry priors is "a living nothing"; otherwise "an existing nothing".
- At the resolver a carrying once chained "is never none again"; to stay unchanged it needs an outside offerer supplying its own parity every turn (5.1).
- Placement is by a conception's stated relation, not its vocabulary: "A matched word places a conception at none of them." (3.2)
- "The scientific method is placed at its fixings" (4.14).

**4. Terms.**
- **conception / arrival:** one stated notion of equilibrium; the NY and SA codes are never expanded.
- **exclusivity:** the universe treated as one thing beside its things (1.1).
- **entering face / surfacing face:** the self's and the other's side of one number (3.3).
- **four-cycling:** a loop of four names made by "eight up" and "17 less" (3.2).
- **protocol of the six connectors:** the six names that join selves (1.3).
- **is-next-existing / is-still-possibling:** a change that happens, or the prior carried on (3.2).
- **colliding:** a thing carrying nothing passing a parity on as it arrives (1.3).
- **proof groups A–D:** incompatible requirements; required case omitted; renewal excluded; required arrival unreachable (5.1).

**5. The ten, and how each is seated.** The file gives no separate definition of each. The name is the definition ("X named as Y" means a changing X treated as a fixed Y), sharpened by its seat and by the rows filed under it. Each pair sits at one number 2–6, at that number's resolver name and the name eight up. The "entering" member is the self's face and the "surfacing" member the other's (3.2–3.3).

| # | Name | Seat | Rows | Examples filed there |
|---|---|---|---|---|
| 1 | an arriving named from behind | 2-bi-co-bi-offering and 10-bi-tri-bi-tunneling, entering | 2 | a conditional probability law held fixed |
| 2 | an opening named as a place | same pair, surfacing | 5 | a fixed point in mechanics; Nash equilibrium |
| 3 | a completing named as a last | 3-co-bi-co-sharing and 11-tri-bi-tri-chaining, entering | 8 | entropy maximum; global minimum; logistic N = K |
| 4 | a carry named as a store | same pair, surfacing | 10 | stationary distributions; Maxwellian; Planck spectrum |
| 5 | a middle named as an end | 4-bi-co-bi-sharing and 12-bi-tri-bi-entraining, entering | 6 | a stable fixed point of a map; a local minimum |
| 6 | a parity named as a magnitude | same pair, surfacing | 9 | rest; zero net force; static equilibrium |
| 7 | a sequencing named to one beat | 5-co-bi-co-competencing and 13-tri-bi-tri-competencing, entering | 5 | market clearing; simultaneous best response; a common clock |
| 8 | a rate named as a value | same pair, surfacing | 5 | chemical equilibrium; detailed balance |
| 9 | a two-way named to one side | 6-bi-co-bi-moralizing and 14-bi-tri-bi-moralizing, entering | 7 | replicator steady state; opposition under reversal |
| 10 | the between named as a cut | same pair, surfacing | 6 | equal temperature across a contact |

The pairs lie on three of the four four-cycles: 3–4 and 9–10 on 3-11-6-14, 5–8 on 4-13-5-12, 1–2 on 2-15-7-10, and none on 1-9-8-16. THIRTY steps 504–523 give the only further gloss: five "along" namings are flow accounting, five "across" are state accounting.

Other number ties: "ten faces and six connectors" plus the entry make seventeen (3.4); 1+3+5 = 9 and 2+4+6 = 12 (3.3); a torus from V − E + F = 0 (1.4); multiples of 5 in 1–441 and "the ring of 440" (1.3). No primes, φ, 24, 59 or 120.

**6. Evidence.**
- **(a) Code and arithmetic.** Seven scripts with stored outputs sit under `incoming/equilibria_registry_v377/executions/` (eq_code, ten_at_the_code, ten_roots_named_still, ten_on_the_four_cycles, the_protocol_between, every_five_every_ten, living_and_existing_nothing). The closing line says they were run at v377 against Exhibit ONE v376, whose function names differ from today's.
  - On my re-typed v380R resolver I reproduced the ring table in 3.4, no ring of 1–7 reaching rest in 5,000 turns, and the group C sequence (0 five times, then −, +, −, +, −).
  - The small proofs in 1.4, 1.5, 5.2 and 5.4 are correct.
- **(b) Published observations.** One outside reference, "NASA/JPL's aberration correction" (4.14), with no document named. The 63 conceptions are textbook-style statements with no sources.
- **(c) Assertion.** The placing of each conception under one of the ten, the passages on the between, and the general claim.
  - Part FIVE gives four argument forms and a few narrow worked cases (a map that never reaches zero in finitely many steps; a fuel cycle balanced only at f = w; resolver cases). It does not show, row by row, which argument excludes which of the 63.
  - Nothing is worked for thermal equilibrium, Nash equilibrium, market clearing or mechanical rest.
  - The file itself limits each proof to "a conception whose complete requirement supplies its premises" (5.1), and the central exclusion presupposes the framework's premise that the quantity inverts at its "required next".

**7. Vocabulary age.** Resolver names are current, but the prose is the oldest of the three.
- 85 hits on the released-words list: "sign/signs" (10 in prose, about 19 more inside quoted rows), "runs/running", "holding", "every", "when".
- From your list: "face/faces" (33), "ring" (16), "connectors" (10), "joins", "returns", "loop".
- Eight NY rows are worded for an older resolver ("fresh carrying", "returned values").
- Thirteen occurrences of "as suggested" or "Suggested at v377" mark passages quoting the author.

Substantial updating needed; its carry note queues exactly that ("the rings as spirals; the released words at their one names; each claim executed at the code").

**8. Open concerns.**
- The file names "concern 7" and "concern 8", both about the between (1.3).
- "The seatings the files gave before meet the resolver's two names at few of the ten." (3.2) THIRTY step 522 and Natural Naming 4.9 put each of the ten at a single name 1–8, agreeing with this file only on #1. Resolving the Hard Problem Registry has a third seating.
- Names 4, 5 and 13 "carry no changing parity at the resolver" (3.2). So #7 and #8 are seated where the resolver has nothing that could be stilled, and #5–#6 half so.
- 4.14 lists leads with no statement yet (null hypotheses, static cosmology, a collection of all sets and others).
- One group D case survives only in the archive with the older resolver.
- Its carry note adds ten numbered concerns. Among them: without "as a method" a specialist "rejects at once" the main claim; the registry's own "same at every momentary" sayings have the form it excludes; and 1.2's "a universe named as an existing thing is exclusivity" sits against THIRTY step 3.

**9. Accuracy notes.** None found in the mathematics. Two cautions:
- The JPL practice in 4.14 is, strictly, the light-time part of the aberration corrections.
- SA16 (detailed balance on a three-state cycle with 2/3 forward and 1/3 back) cannot hold in standard probability, but it is listed as a conception to exclude, not asserted.

---

## Exhibit THIRTEEN: Resolving Hard Problems

**1. Subject and purpose.** A short essay on what the framework means by a "hard problem" and its "resolving". A field gets one when it reads its evidence as a snapshot of now, cut off from the living source that has since moved on. The same evidence, read as living and non-living things taking turns across prior, now and next, is said to yield the field's own next step. The file walks through the resolver name by name, then sorts seven familiar kinds of hard problem by where they fall in that walk-through.

**2. Structure.**
- **ONE (1.1–1.5):** the opening sentence; living and non-living; "bi-momentary" (self on odd numbers, other on even, overlapping); prior, now, next; what a hard problem is.
- **TWO, Prior (2.1–2.3):** the carrying (name 3); records; evidence as something that left its source a turn ago.
- **THREE, Now (3.1–3.4):** offerings at 2; surfacing at 14; the comparison at 12; non-living things as offerings only.
- **FOUR, Next (4.1–4.4):** sharing at 10 and 6, chaining at 11, release at 9, the society's turn at 17; "the living step"; rings of selves ("spirals").
- **FIVE (5.1–5.8):** a four-reading procedure, then seven problem types: two rival accounts, an origin, a measurement, an aggregate, a mind, a boundary, a persistence.
- **SIX (6.1–6.3):** the "geodesic-method" beside the scientific method; social moral competency.

**3. Main claims.**
- "A hard problem arrives where a field reads its observings with the universe as no existing thing" (1.5). Four symptoms: evidence with no living self it left; a now with no prior; one side's turns without the other's; a record with no carrying behind it.
- "Resolving hard problems is social moral competency discovering next living at each coupling" (1.1). The result is not an answer handed over but "the field's own next living" (1.5).
- "Evidence is an emanation arriving: it left a living self at prior and arrives now." (2.3) So evidence shows the source's past: "A measurement read at one momentary is read as the now" (5.4).
- Agreement is all-or-none, never weighed: "Agreeing, one parity; disagreeing, 0; none offered, none." (3.2) "Nothing is counted."
- At 12 a change "is or is not": a match means no change; a mismatch, a cancellation or nothing offered means the prior inverted (3.3).
- "Next as prior inverted is the living step." (4.3)
- Rival accounts such as nature and nurture, or wave and particle: "A field carrying two accounts of one thing is two offerings at one sharing" (5.2). They cancel to 0; the field's next is its own prior inverted, or the question stays open.
- Origin: "Living arrives from living" (5.3). Mind: "A mind is read at its own couplings" (5.6), never at the between.
- "The scientific method accounts true or false against its fixings, a law, a frame and a scale named unchanged between two momentaries" (6.2). The geodesic-method lets them change.
- A society is a self one scale up: "one through nine the self's and nine through seventeen the society's" (6.3).

**4. Terms.**
- **bi-momentary:** the self's momentary and the other's at once, one odd and one even (1.3).
- **co-sequencing:** the two sides carrying on together (1.3).
- **carrying / capacity:** the prior taking part in the present coupling (2.2).
- **record:** a non-living emanation of a carrying (2.2).
- **surfacing:** offerings at one sharing reduced to one parity or 0 (3.2).
- **colliding:** a thing carrying nothing passing on what it is offered (3.3, 5.3).
- **a field's arrival / the four readings:** living and non-living, prior, now, next (5.1).
- **abundancing:** the change made at 12 (3.3, 6.3).
- **geodesic-method:** discovering next from what exists, with nothing held fixed (6.2).

**5. Ties to the resolver and the numbers.** Prior is 3. Now is 2, surfaced at 14 and compared at 12. Next is 11, with 10 and 6 sharing, 9 releasing and 17 the society's turn. 8 and 16 are the "wound" carryings; 4 is a sharing and 7 its parity. Numbers: "Ten positions on six numbers" (1.3); 1–9 and 9–17; sixteen rules, four keeping the prior (4.3). No primes, φ, 24, 59, 60, 120 or 440.

**6. Evidence.**
- **(a) Code and arithmetic.** Nothing is executed in the file and it has no kit. Its resolver statements are checkable, and I reproduced each one:
  - the cases at 14 and 12, including magnitudes reducing to their sign;
  - the one-turn lag between selves A and B (2.3);
  - a lone self inverting every turn (4.3);
  - odd rings repeating at 4n with the pattern inverted at 2n, and even rings at 2 (4.4).

  The 16, 4, 1 count in 4.3 is correct.
- **(b) Published observations.** None; no outside source is cited.
- **(c) Assertion or analogy.** All of Part FIVE (origin, measurement, mind, boundary and the rest mapped onto resolver positions) and Part SIX (the account of the scientific method).

**7. Vocabulary age.** Resolver names are current. Few released words remain: "so" (6), "left" (5), "there" (4), "where" (3), "counted/count" (4), "since", "half", "travelling". "Face" and "joined" survive in the titles of 5.6 and 4.4. Two retired sayings remain: "co-offering" (6.3) and "a living society's" (3.4). Light updating.

**8. Open concerns.** The file flags none. Its carry note lists three:
- About half its sentences are near-copies of Natural Intelligence, to be re-said or cited. My sentence-level check found about 10% verbatim or near-verbatim at v380R, so most of the overlap is paraphrase.
- 5.6's "not a thing" wording for the between is to be re-said.
- 5.3 rests on a saying of the author "of no authority", is "worked at no case", and was read by no second reader.

**9. Accuracy notes.** None found; the counting in 4.3 checks. The description of the scientific method (6.2) and of wave and particle as two rival accounts (5.2) are the framework's own readings.

---

## What a collaborator most needs to know

THIRTY is the spine: other files cite it by step number, and those numbers have shifted between versions (the carry notes still use v376 numbering in places). THIRTEEN is a compact, current re-telling; TWENTY-EIGHT is the least updated, with ten numbered concerns pending. The files do not agree on where "the ten" sit (TWENTY-EIGHT's table, THIRTY step 522 with Natural Naming 4.9, and a third seating in Exhibit TWENTY-TWO), so settle which is current before editing any of them. What is solid is narrow and checkable: the resolver's behaviour and the arithmetic, all of which I could reproduce. The bridge from there to claims about the world (one method, equilibria impossible, living only from living, primes and φ as social structure) rests on assertion, and the project's own notes say so. Supporting code lags the text (THIRTY's kit verifies the v371 registry and an older resolver; TWENTY-EIGHT's scripts call Exhibit ONE v376). And the project's own rule is that no one's word settles a step, the author's included, so changes are expected to arrive as concerns checked against the resolver, the numbers or observations.

---

## Paths

- `/home/claude/chris-j-handel/corus/Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md`
- `/home/claude/chris-j-handel/corus/Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md`
- `/home/claude/chris-j-handel/corus/Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md`
- Carry notes: `/home/claude/chris-j-handel/corus/carry/` (one file per exhibit, same base names without the version)
- THIRTY kit: `/home/claude/chris-j-handel/corus/kits/Co-Chaining_Logic_Registry_THIRTY_Improving_Kit/README.md`
- Released words: `/home/claude/chris-j-handel/corus/kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/released_words.txt`
- TWENTY-EIGHT's scripts and outputs: `/home/claude/chris-j-handel/corus/incoming/equilibria_registry_v377/executions/`
- My scratch checks (outside the repository): `/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/` (`sim.py`, `sim2.py`, `sim3.py`, `stats30.py`, `cites.py`, `released.py`, `overlap.py`, `quotes.py`)