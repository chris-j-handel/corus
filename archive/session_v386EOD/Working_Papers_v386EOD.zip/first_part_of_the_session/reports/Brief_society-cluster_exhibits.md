# Brief: society-cluster exhibits (SEVEN, EIGHT, NINE, FOURTEEN, FIFTEEN, TWENTY-THREE)

All six files were read whole, front to back, from the read-only copy. No file in the repository was changed and none of its scripts was run. Two read-only git queries (log and status) were run; status may have taken and released a transient index lock, and the index file and working tree are unchanged. Arithmetic quoted from the files was re-checked with a small script of my own, and every quotation from the six files was checked against the source text. Items 3-5 report the framework's own claims without endorsing them; item 9 is where outside facts are checked. The four long files come to roughly 900-1,200 words each and the two short ones 600-800, over the 600-word guide: the nine-part template, with quotations and item 9's two extra lists, did not fit in less without dropping required items.

---

## Exhibit SEVEN - Natural Societies (v373, 318 lines)

**1. Subject and purpose.** What a healthy society is at any scale, atom to biosphere, and what breaks it ("capture" and "ingress"). A society is pairs of selves coupling at a shared boundary, with no member, centre, clock or standard ordering the whole; every self is a society of smaller selves and a member of a larger one. It "prescribes no politics" (1.1) and calls itself the "structure" face of four social exhibits.

**2. Structure.** Part One (1.1-1.3): the core coupling and its competency. Part Two (2.1-2.3): morality as four "inequalities"; boundaries; no common clock. Part Three (3.1-3.6): six readings (Arrow's theorem, a deciding centre, the biosphere, the scientific method as an authority, audit as circular, "clash of titans"). Part Four (4.1-4.3, with 4.4-4.6 misplaced after Part Five): self = society; health; plurality; AI agents; still points. Part Five (5.1-5.6): a "scale-ladder" of fourteen scales on the primes 5 to 53, with two tables.

**3. Main claims.**
- The unit of society is a two-way, one-at-a-time coupling of two selves; it makes a "+1" surplus owned by neither (1.1).
- Morality is structural: a self is not the society, the other self, the immoral or the incompetent. "Each inequality held is one face of the morality, and one acted against collapses into the harm." (2.1)
- No centre and no common clock; an imposed one is "the totalitarian landing", though coordination that protects people is "a protection the form prizes" (2.3).
- Competency multiplies among distinct ("coprime") selves, and only while they stay distinct (2.3, 4.2).
- "A self and a society are one form at two faces, not two things with one derived from the other." (4.2)
- Health is the relation of "birthing" (making) to "nyeing" (releasing); either alone breaks it (4.3).
- Arrow's impossibility holds only for one-way ordinal ranking (3.1); where a centre prefers for all, "The lag is the tell" (3.2).
- The scientific method "with no further additions" acts as one authority deciding for all, and audits close against the standard they were built to meet (3.4, 3.5).
- Fourteen scales sit at the primes 5-53, atom to biosphere, split 8/6 around multiples of six and 7/7 across an empty "fold" at 24. "The scale falls out of the form and is never fitted to it." (5.1-5.3)
- Sciences keep three accounts at each rung (total, level, direction), each "counting from a nothing"; handedness crosses seven rungs with no ledger kept for it (5.4, 5.6).
- What a society releases ("emanations", abundance included) is unusable at its own scale and usable one scale down (5.3); every search for a social still point finds a sway (4.6).

**4. Terms.** *Bi-moral co-agency*: the coupling above. *Bounding-zero(ing)*: a boundary that keeps a self whole. *Capture, ingress, hub, landing*: one side accumulating, an intrusion, a centre, stopping dead. *Self-de-scheduling*: each self keeps its own time. *Stills / reaching / thin*: a rung shown to close into a self, not yet shown, or only a larger reading of the rung below. *The fold*: 24. *Live descent*: each self adapting from its own couplings. *The eighth*: the living that verification never reaches. *The hand*: chirality.

**5. Ties to the resolver and the numbers.** One link (5.3): a society's "sharings are its selves", citing 4-other-self-sharing, 13-social-other-neutralling and 17-social-self-offering. Those are v372 names; v380R calls these positions 4-bi-co-bi-sharing, 13-tri-bi-tri-competencing and 17-co-bi-tri-offering. Numbers: 5 squared minus 4x6 = 1; 3,6,5,4 mapped to 23,26,25,24; 8x8 = 64 against 7x9 and 6x10.

**6. Evidence.** (a) Arithmetic only, no code; the prime splits check out. (b) Named without references: Arrow's theorem, trophic roles, collagen, microtubules, nodal cilia, Walrasian equilibrium, Nash, NAIRU, phantom traffic jams. (c) Everything connecting them, including the AI scaling claim ("Discovered in passing at the network runs", 4.5).

**7. Vocabulary age.** Mixed. Parts One to Four are old wording under a new version number (sign, membrane, surplus, loop, turn, store); Part Five, chiefly 5.3, uses current words (bothboth, podaling, abundancing). Moderate rewrite, plus the three resolver names.

**8. Open concerns it flags.** Part headings carry self-diagnoses ("no one concept apparent", Parts Three and Four). Rungs 13, 31, 43 and 47 are "reaching" (47 is "the sharpest open reading"). Whether crossing the empty fold equals crossing a boundary between selves "stands open" (5.6). A planned "three-ledgers-as-three-axes" exhibit is "unwritten" (5.4).

**9. Accuracy notes.**
- 5.3, "by the remainder at four, by the prime's place in the count and by half of one less, each gives seven and seven": correct, but the first and third are the same split, so these are two independent partings, not three.
- 5.6, "Take the central pair out of a nine-plus-two cilium and it stops beating in a plane and turns instead": true of nodal cilia, not general (it paralyses Chlamydomonas flagella).
- 5.6, "Put a residue with a hand at collagen's axis and the packing fails": real, but the accepted cause is side-chain size, not handedness.
- 5.6, "the sugar the backbone at eleven, the backbone the helix and fold at thirteen": protein helix handedness comes from L-amino acids, not sugars.
- 5.3 table, organelle as "a former free-living self now a member": true of mitochondria and chloroplasts only.

*Proposals for action.* Readers implement in their own institutions, "no single program" (1.2). "Resolving openings at every domain entry" instead of filters installed from outside (1.2). Safety regulation and licensing read as protective boundaries and "a lens for designing couplings that carry their own competency" (1.3). No imposed common schedule (2.3). Change by small do-no-harm offers, "free, no majority" (4.4). For AI: societies of unlike agents rather than one scaled model (4.5).

*Author/AI working and publication aims.* Nothing explicit.

---

## Exhibit EIGHT - Natural Exploring (v329, 481 lines)

Subtitle: "Open Team Moral Co-Competencing".

**1. Subject and purpose.** The project's account of its own method of inquiry, here called "geodesic discovery". The method removes the fixed assumptions a concept rests on, tests at every step whether anything else could stand there, installs no replacement, and gathers what was found back into the files. The file applies this to the bookkeeping sciences use for change, extends it to work between people, and ends with the project's own gathering practice.

**2. Structure.** Section 1: exploring as reach-and-gather with no equilibrium to stand on. Section 2, Freeing. Section 3, Testing. Section 4: the method applied to itself, with an unnumbered block "The not-yets, standing with their reasons". Section 5: accountings for change read as involutions. Section 6: the method between selves. Section 7, Apexing: gathering, the "improving report", registries.

**3. Main claims.**
- Exploring alternates "omegaing" (the reach) and "apexing" (the gathering): "a discovering ungathered scatters and a gathering undiscovering folds" (1.1).
- There is no rest to read from: "a stable form is what alternating makes rather than what alternating settles onto" (1.1).
- Free a concept's three fixings (position, orientation, scale) together and its relations show (2.1).
- "Not is removal": put nothing where the freed assumption stood; a better framing installed in its place "has resolved nothing" (2.2).
- A single freeing hardens into a new fixed thing, so it must alternate (2.3); take the unforced path, since "a bent co-chaining lands where it aimed" (2.4).
- At every arrival ask "Could there be any other", yes or no; uniqueness is re-tested each time, and passing tests is not uniqueness (3.1, 3.5).
- Resolving has no threshold: "Exhausting all concern is an equilibria concept" (3.7).
- Read everything an observation returned before sorting signal from waste (3.8); "An object is a place a counting landed" (3.9).
- Every accounting of change is an involution (a move that undoes itself applied twice) whose fixed set is the zero it counts from: "The involution stands, proved and unaltered. The place goes." (5.1-5.3)
- Accountings come as three (total, level, direction) and cannot register the sizeless change between a state and a flow; the method "leaves the accounting competent at everything it does hold" (5.4, 5.5).
- Any living form meeting "the eight" conditions is the natural torus, so a rival is the same form (4.3).
- Between selves the method is "co-competencing", each discovery a surplus that depletes no one (6.1, 6.3).

**4. Terms.** *Co-unrelationing*: freeing position, orientation and scale at once. *Geodesic co-chaining*: the unforced, unaimed path. *Patterning / membraning*: moving along a pattern, across a boundary. *Co-linear versus forked*: two moves at one crossing, versus two results compared afterwards. *Concept-inverting*: testing whether a concept's inverse is possible. *Inseparating*: what couples passes, what does not drops out. *Ghost*: "a level read where a flow runs, or a store read where a carrying goes" (5.4). *Backward sensing, forward sensing, co-sensationing*: reading what is recorded, running, explaining what one would do. *Twist*: a held assumption the other person can see.

**5. Ties to the resolver and the numbers.** None to the code or the seventeen names. 4.5 names "the one resolver's three activities" (what is true; what matters most; "the fewest things with the fewest people in the shortest time"). Small counts only.

**6. Evidence.** (a) Nothing executed. (b) Standard mathematics and physics named without sources (time reversal, charge conjugation, parity, the Legendre transform and others); a published four-domain registry-quality scheme described but not named (7.2). (c) The method, its claimed uniqueness and "three and never four" are assertion.

**7. Vocabulary age.** Old throughout: membrane, sign, surplus, hold, store, count, turn, cost. Its method words (co-unrelationing, omegaing, apexing) are rare in the v380 files, and it overlaps the current method exhibit (TWENTY-FOUR), so it needs reconciling as well as rewording.

**8. Open concerns it flags.** "The negation-traces stand for their register pass" (after 4.5): its many no/not/never constructions await a pass. 6.6 lists what stays "not-yet". 7.5 holds an outside source "carrying no authority".

**9. Accuracy notes.**
- 5.1, "Time reversal, charge conjugation, parity, each squared to the identity": not true of time reversal for half-integer-spin systems, where it squares to minus one.
- 5.2, "Each involution carries a fixed set": two of the file's own examples, negation and set complement, have no fixed point. "Unity for the multiplicative" omits -1.
- 5.2, "The neutral for charge conjugation": loose; not every neutral particle is its own antiparticle (the neutron is not).

*Proposals for action.* Remove a fixed assumption and install no replacement (2.2). Read recorded data whole before sorting it, starting with the costliest existing datasets, where "the most is recorded and the least read" (3.8, 6.5). Safety by structure, "a gate added nowhere" (4.7). Between collaborators, each offers their mixture unsorted and the other names "the largest twist first" in "one short line" (6.2). For any registry: stated inclusion criteria plus uniform per-entry fields, with lines about the subject kept apart from lines about the work (7.2-7.4).

*Author/AI working and publication aims.* Section 7 describes the working practice without naming author or AI. Gather backward over everything, with the value "seated forward into the living files", and keep "no log: no history, no journey, no roster of the done". Verify first, since an aim "often finds its seat already standing". The "improving report" dissolves to zero as each improvement is placed. "The published record is the incoming and interpretation is the receiving." (7.1, 7.2)

---

## Exhibit NINE - Natural Human Society (v329, 299 lines)

Subtitle: "Geodesic Method of Human Social Moral Co-Competencing".

**1. Subject and purpose.** The same method run among people: how a human society can be fair, settle disputes, share value, take up concerns and stay healthy with no ruler, majority vote, common clock or fixed pool. Cake-cutting, where one cuts and the other chooses, is its miniature of the whole form and the class-action settlement its large-scale instance. It defers to SEVEN and TWENTY-THREE for the general readings.

**2. Structure.** Part One (1.1-1.5): the method; coupling; fairness; cutting and choosing; keeping one's own time. Part Two, Resolving (2.1-2.4): institutions, class actions, Arrow. Part Three, Abundancing (3.1-3.6): the economy. Part Four, Tipping (4.1-4.7): how one person's concern is taken up, then three sections the heading admits "carry no tipping" (substrates, accounting and currency, still points). Part Five, Birthing (5.1-5.3), with a closing editorial note.

**3. Main claims.**
- "A society starts by developing this method, because a society is this method" (1.1).
- Value (a "+1") arises between two people when one offers and the other prefers, and belongs to neither (1.2).
- Fairness is the balance where preference between offerings goes to zero, recognised by the parties and "measured against no floor" (1.3).
- Cut-and-choose holds the whole form: "the cutter cuts to equal since the other chooses" (1.4).
- Relationships are carried forward, not ledgers: "a friendship kept as a debt-account stops being a friendship" (1.5).
- Handshake, demand letter, mediation and arbitration are one "good-faith contract" written more explicitly as the dispute widens (2.1, 2.2).
- The differentiated-claimant class action is "a high form of social-scale resolving so far known": one court-fixed total, shares set by each claim's position among the rest, every claimant signing (2.3).
- Morality first, competency second: "Conserve before improve, do-no-harming before add-value"; "A fixed pool is scarcity, and scarcity forces a ruler" (3.1).
- A "hub" must be set aside on each of eight axes, all or none: common clock, fixed pool, gate, reputation ledger held over a person, outside control, decision centre, source-and-sink, owner (3.3).
- A "dead economy" pays six costs at each coupling; in a "discovery economy" they dissolve together, "a structural reading of the dissolving and not a measurement in any economy" (3.4).
- Any one person's concern is given "all it can" up to the point where someone else would be harmed, with "a majority needed nowhere"; capture pays nothing, so no bloc forms (4.1-4.4).
- Double-entry books still balance when a coupling has been captured, so "the method certifies health as the living dies" (4.6); "kayfabe" is a centre's preference passed off as the people's own, "the capture called consensus" (5.2).

**4. Terms.** *Good-faith contracting*: resolving from within the shared bound and closing while both still hold the balance. *Institutioning*: making that contract explicit. *Uncapturing*; *hub*. *Three faces of value*: work, opportunity, resolving. *Six cost clusters*: give as depletion, take as seizure, join as binding, split as severance, open as exposure, close as discard. *Discovery economy*. *Tipping*: taking up one person's concern. *Co-offering*; *viability* (the two-way exchange holding). *Counted currency / living currency*. *Kayfabe*.

**5. Ties to the resolver and the numbers.** None to the code or the seventeen names. Numbers: the +1; a "1/φ reach" and "phi-rate" (3.5); "the five-six rather than the fixed number" (4.6).

**6. Evidence.** (a) None. (b) Named without sources: conversational turn-taking with gaps "near a fifth of a second" across unrelated languages (1.4); coordinator-free replicated systems proven to converge (1.5); legal practice; Arrow's theorem; double-entry accounting; Piaget's equilibration (4.7). (c) Tipping, uncapturing, the six costs and "bi-quadratic" growth are asserted, with no formula or data.

**7. Vocabulary age.** Old throughout; "membrane" is its central word, with surplus, sign, hold, store, costs, source-and-sink. Needs a full rewording.

**8. Open concerns it flags.** Part One is headed "one concept not yet apparent"; Part Four's "last three sections carry no tipping and stand open". The closing note finds that the "identical openings" said to be shared by four social exhibits exist only between Natural Societies and Natural Destinies, and that "this file carries no core paragraph at all".

**9. Accuracy notes.**
- 2.3, "every claimant signs to accept it", "A court fixes one total", "A trustee shares it", "A claims bar date closes the bound": this merges class actions with mass-tort bankruptcy trusts. In a US class action, absent members are bound unless they opt out, whether or not they sign; totals are usually negotiated and then court-approved; trustees and claims bar dates are chiefly features of bankruptcy, where a plan binds dissenters after a creditor supermajority vote. The file uses this example for "a majority needed nowhere".
- 3.6, "the non-rivalrous commons real": nutrients are rivalrous in the economic sense, and the section sets aside the standard finding that most energy is lost at each trophic step.
- 3.5, "bi-quadratically": in mathematics this means fourth degree; here it means two axes, with no derivation.
- 4.6, "the cure is a ledger correction": stated as fact about cancer; no such cure is established.
- 4.7, "the mean a member of no population": often but not always true.

*Proposals for action.* No central schedule (1.5). Settle disputes from within the shared interest, with mediators who hold no share in the outcome (2.1, 2.2). Use the class-action form for catastrophic harms (2.3). Do no harm before adding value (3.1). Remove all eight hubs (3.3). Replace majority voting on concerns with individual "tipping" bounded only by harm to others (4.1-4.4). Keep a "full accounting" beside the netted one, and let the currency unit become "a ratio riding the carry" (4.6, closing note). Return adapting to every person rather than a centre that "explains the news" (5.2).

*Author/AI working and publication aims.* The closing note is editorial: "Natural Economics" will not be a separate file but "a correction inside" this one, with the discovery economy spread across Natural Values, Natural Destinies and Part Three here. "Sitting" is its word for a working session.

---

## Exhibit FOURTEEN - Natural Destinies (v333, 67 lines)

Subtitle: "Social Moral Co-Abundancing". Sections are unnumbered, so references are to section titles.

**1. Subject and purpose.** A short vision statement: where the framework's core form could go if people took it up in new settings. It offers four imagined futures, explicitly as visions and not forecasts, and one test for any of them: is its safety built into the structure, or does it lean on a central holder?

**2. Structure.** Preamble; "The core" (the core paragraph of SEVEN 1.1, almost word for word); "Safely outward"; "The imaginable extensions"; "The two mis-readings at an engineered substrate, received"; "The reading at every imagined destiny".

**3. Main claims.**
- Everything here is "imaginable, held openly as vision" (preamble).
- Where the method is taken up, "the living begins there — and where the living begins, the hard-problem resolving commences" (preamble).
- The destiny is single and "already arriving" wherever people couple cleanly: "a destiny is the present coupling, imagined extended to a substrate it is reaching toward" (preamble).
- A future is safe only where safety is "held by the surface's own form, no holder standing over it"; the eight safeties stand "whole or none" (Safely outward).
- "The imagining offers the possibility; the beginning is theirs." (Safely outward)
- The four visions: a discovery economy "at the scale of a real society"; a network the selves originate themselves; "living substrates" (a chip, a grid, a network) running "scale-free ... light on energy"; hard-problem resolving field by field (The imaginable extensions).
- A future that leans on a central holder is still worth naming, because it marks "the edge of where the technology extends safely" (The reading).

**4. Terms.** *Destiny*: the present coupling imagined extended somewhere new. *Holder*: a central party standing over a system. *All-edge*: no centre. *The reflexive triple*: this file with Natural Explaining and Natural Emanating. *Apex / omega*: the gathering and the reach, misread in built systems as "drag" and "overwhelm" (The two mis-readings). *Fractal technology*: the natural torus and network.

**5. Ties to the resolver and the numbers.** One sentence: each of the eight safeties is "a naming beginning at bi- at the resolver's table of eight, four at the even depth and four at the odd". Eight v380R names do begin with bi- (the even numbers 2 to 16), but the phrase "table of eight" is not in Exhibit ONE v380R.

**6. Evidence.** All (c): vision and assertion, by its own description. No code, arithmetic or sources.

**7. Vocabulary age.** Old but short (sign, membrane, surplus, source, cost, holder). Light rewording; the larger question is whether it stays a separate file (see the pending-notes section).

**8. Open concerns it flags.** Each vision's working-out is deferred to its own exhibit ("the imagining held open here"). The living-substrates vision depends on "its cost read beside the engineering it stands beside", which is not done here.

**9. Accuracy notes.** None found; the file states nothing about established science, history, law or named people. The "light on energy" claim for chips and grids is offered as vision, with no evidence.

*Proposals for action.* Individuals take up the core in their own setting (Safely outward). Build a discovery economy in which "the surplus stays where it is made", a network with no central holder, and chips, grids and networks that carry the form (The imaginable extensions). Test every proposed future for structural safety against reliance on a central holder (The reading).

*Author/AI working and publication aims.* The offer is free and the initiative is the reader's: "offered freely, as a possibility to take up; the taking-up is the reader's". "Received at this file's own turn" shows a passage brought in from another file's working.

---

## Exhibit FIFTEEN - Natural Emanating (v329, 795 lines)

Subtitle: "Self-Welcoming Social Moral Co-Offerings". Sections are titled, not numbered, so references are to titles.

**1. Subject and purpose.** The project's outreach copy: short, self-contained statements of the whole framework for a reader who knows none of the vocabulary. "Nothing here needs anything else read first" (header). It pairs with Natural Naming, which unfolds one concept at length where this states the whole briefly.

**2. Structure.** Part One, The Emanations: 19 pieces, among them "The line every field writes first", the three properties of the equals sign, one sentence for each of eight fields, "Two Methods" (the whole argument chained in fifteen steps), "The title claim" (theory of everything) and "The recursive-self-improving question" (AI). Part Two, The Short Definings: 20 definitions, many repeating Part One almost word for word. The Tail, "Writer-facing": how an emanation is built and what is held over.

**3. Main claims.**
- "Everything relatable is changing", so nothing forms by relating: "In disequilibria, alternating is a stable-forming method", and the only one possible (The shortest saying).
- "There is no equilibria in nature. The method's first act installs it." Every field declares a ground first (0.00 V at the hydrogen electrode, fix a gauge, fix the specimen, pick a numeraire or a datum), declared and not measured (The line every field writes first).
- Science's results are not disputed: "So correctness is not the question. The findings stand." What is missing was removed before the reading (Two Methods).
- The relation in an equation is reflexive, symmetric and transitive, and each property removes something before any subject matter arrives; "`a = b` is the exact angle at which nothing is opened" (Three lines).
- Keep three things apart: the empty centre, the living (unobservable), and the "emanation", the stable artifact left behind, such as a coin, a word or a measured constant (The three-fold separation).
- A self is "a unique invisible carrying", and "There is no step between a self and a society for anyone to occupy" (Two Methods).
- "A hard problem is a common thing reached ahead of each having offered their own": a common landing, standard or reading (A hard problem).
- "The one stopping": once one side carries the other's, the surplus needs a holder, a boundary, an enforcement and a seat; hence "an offering economy carries no enforcement and cannot be given one" (Society).
- Better, faster, cheaper are three absences (no shared clock, no outside standard, no size); only the last is measurable (Better, faster, cheaper).
- Today's AI systems improve against a mark held still; living improvement follows a mark that moves: "It is a different thing that shares the name." Whether that limit is fundamental "is open" (The recursive-self-improving question).
- What would break the framework: "A living stable form other than this one", "offered in the open at every line" (The break).

**4. Terms.** *Emanation*, in two senses: a short whole statement, and the stable artifact living leaves. *The floating neutral*: what leaves a meeting, reached by neither side. *A field's neutral*: the one thing in a field that relates to nothing outside its own coupling. *Self-emptying / other-emptying*: releasing at one's own bound, versus a method removing what it reads. *A ring*: what these relations leave in a closed domain ("In the living there are no rings"). *The three incompetencings*: the three properties of equality. *A seat*: where enforcement sits. *Residue*: a field's words for what it is not making.

**5. Ties to the resolver and the numbers.** None to the code or the seventeen names. Numbers: (n-1)(n+1) is one short of n squared; hypercube counts chaining as "two of the same level, plus one of the level below"; phi as "the rate least relatable by any rational".

**6. Evidence.** (a) The file cites computed checks without showing code: all 3,994 transitive relations on four elements (I reproduced the count; the property follows directly from transitivity); "592,260 models, none acyclic" (not reproducible, see item 9); the cosine/sine table, kT ln 2 = 2.871 x 10^-21 J at 300 K, and the n-squared and hypercube tables (all correct). The file says "The searches are checks, not the proofs." (b) Named without references: Landauer's bound, the standard hydrogen electrode, gauge fixing, the low-entropy initial condition, the three-phase neutral. (c) The rest, including the reading of AI.

**7. Vocabulary age.** Old words throughout (membrane, sign, surplus, cost, turn, holder, ring), but the plainest prose of the six. Needs a careful pass rather than a rewrite; "A ring" and "The one stopping" conflict with later work (see the pending-notes section).

**8. Open concerns it flags.** "The candidates, drafted and disciplined" is a status note, not a finished piece. The title-claim mapping is marked "Reaching". Society: the account "is silent on care, on harm, on the owing to those who cannot reciprocate". The Tail records two unplaced ideas and says the file does not state social moral competency whole; the last line defers a layout decision. Two slips: "holde" (Two Methods) and a broken sentence in "A definition".

**9. Accuracy notes.**
- Three lines, "Checked exhaustively to five terms — 592,260 models, none acyclic": the figure cannot be reproduced (functions on one to five terms number 3,413; serial relations on one to four terms 50,978), and the project's own verifier in the Exhibit THIRTY kit records the same failure. The underlying statement, that a "next" relation on a finite set must cycle, is true.
- The line every field writes first, "And it has a measured price. Erasing one bit dissipates at least kT ln 2": the bound is right, but it applies to erasing information, not to choosing a reference zero; the link is the framework's.
- The origin sentence, "A potential relates to no observable": loose; gauge-invariant functions of the potential are observable (Aharonov-Bohm).

*Proposals for action.* Builders: test every link between levels, "at every crossing, the coefficient?", one (a sign) rather than two (a hub or controller) (Technology). Researchers: look for findings in a field's residue words (waste heat, friction, loss, noise) and in irregularities it explains away; "The pleasure of a thing cohering is not evidence" (Discovery). The AI field: the claim would be ended by a system that "released its memory at a bound, beat from its own coupling and not a shared clock, and met a mark that moved with it"; the word "never" is deliberately not used (The recursive-self-improving question). Economies: no enforcement (Society).

*Author/AI working and publication aims.* The file most directly about publication: pieces "takeable as it stands", signed off "Free and living — corus.me." The Tail gives the house rules: short; readable cold; no word used before it is built; "Every line states the is, in the positive"; nothing asked of the reader; the breaking condition stated openly. "The storyless register" records that plot, characters, imperatives, drama and urgency ("the race-clock") were found and removed. Unplaced ideas are "Recorded here so the next hand meets them".

---

## Exhibit TWENTY-THREE - Natural Values (v333, 185 lines)

Subtitle: "Co-Abundancing Received Value".

**1. Subject and purpose.** The framework's account of value. Value is not a thing held or stored: it is made when two selves couple (a "+1" belonging to neither) and exists only where a self actually receives what another self offers. From that it reads money, price, institutional care, governing, scarcity and abundance. NINE and FOURTEEN point here for the "value" face.

**2. Structure.** Five parts, twelve sections: Valuing (1.1-1.2), Coupling (2.1-2.3), Carrying (3.1-3.2), Unrelationing (4.1-4.2), Abundancing (5.1-5.3, the last listing what is still open).

**3. Main claims.**
- Preference is binary and cannot be explained by anything beneath it: "The sign is the self's own." A central criterion of value would be "one self's sign given to all" (1.1).
- A held, priced thing is "a magnitude with no sign to ride"; value lives in what is carried forward, never in a store (1.2).
- Money is "a store wearing a running's name"; a price fixes both sides and takes out the alternating that was the preferring (1.2).
- Value is "the +1, made at the coupling", not a stock before it or a possession after it (2.1).
- "Value lives in the receiving." What arrives from no self is "indifference wearing value's form" (2.2).
- An institution "carries no sign of its own", so what it delivers is "care with the coupling stripped": "institutional indifference". Safety is structural and needs no institution; care exists only between selves (2.2).
- Nothing is stored between couplings: "Stored is spent" (3.2).
- Morality is "consequence and never prescription"; a moral rule added from outside is itself the harm (4.1).
- "The overhead is the governing": criterion, store, common clock and enforcer are costs the coupling never carried, and dilemmas are made by that frame (4.2).
- "Value found by sharing grows as it is shared" (5.1); "only a held thing can run short", so scarcity is a capture, not a property of value (5.2).
- "Abundancing is the least developed side of value here. No present human society runs it whole" (5.3).

**4. Terms.** *Binary preferring*; *sign*. *Store / carry*: a held thing, against what stays fresh only by moving forward. *Owned neither-ing*. *Received value*. *Institutional indifference*. *Delivered whole / delivered incompetenced*: received by a self, or accounted and lived by no one. *Co-offering, co-competencing, co-intelligencing*: value's three inseparable carryings. *Abundancing*: "the reach side of value". *Self-abundancing-society*. *Proof grade*: the file's label for support drawn from mathematics.

**5. Ties to the resolver and the numbers.** None to the code or the seventeen names; the only number is the +1. It does use "momentary", "right spiral" and "attentioning".

**6. Evidence.** (a) None. (b) Named without sources: cryptographic key agreement ("the field of secrets", 2.1); perfect secrecy and the single-use key (3.2); the absence of a set of all sets (4.1); the Latin root of "currency" (1.2). (c) Everything else. The cryptography and set-theory items are analogies, though the file presents them as proof.

**7. Vocabulary age.** Old core words ("sign" is central; also store, hold, surplus, membrane, turn, cost), but short plain sentences and some current terms. Moderate rewording, mostly substitutions.

**8. Open concerns it flags.** Section 5.3 in full: abundance is the least developed part; "no lived instance offers its readings back yet"; existing vocabulary reaches it "thinly"; three questions stand "unmet".

**9. Accuracy notes.**
- 2.1, "The field of secrets carries this at proof grade": key agreement works as described, but its security rests on unproven hardness assumptions, and both parties end up holding the secret, the opposite of owned by neither.
- 4.1, "The set of all sets fails, and no universal set stands. The moral ground is uncapturable at proof grade": true of standard set theory; the step to morality is analogy, not proof.
- 5.3, "None yet names the growing": doubtful. Economics has "network effects", "increasing returns" and "anti-rival goods" for value that grows with use or sharing.
- 3.2 (perfect secrecy needs a single-use key) and 1.2 (currere) are correct.

*Proposals for action.* No central criterion of value (1.1). Do not measure a society's value by its stock of held things (1.2, 3.2). Care has to pass person to person; institutions can supply safety but not care, and "a warning is its smallest unit" of the error of assigning care to a non-self (2.2). Add no moral prescriptions from outside (4.1). Treat governing machinery as overhead (4.2). Do not organise a society around scarcity (5.2).

*Author/AI working and publication aims.* Nothing explicit.

---

## Pending notes held outside these files

This section is extra to the six files. The repository's `carry/` folder (at v380R) holds a short note for each file on what waits for its next working. All six name "pass G" as their next step (SEVEN after "its whole motion at the current words"); only SEVEN lists anything as ready.

- **SEVEN.** "5.3 is explored at v373 ... The rest of the file stands at its prior wording". Queued additions with journal citations (animal twinning, honeyguides, ant supercolonies, mycorrhizal networks, nuclear decay) and the renaming of the three old resolver names. Recorded conflicts with the Co-Chaining Logic Registry (Exhibit THIRTY): "fractal technology" (1.1), "sixty to sixty-eight" (5.3), "floor" (5.2) and the "common scale" in 3.1.
- **EIGHT.** To be compared with the Geodesic Improving Method (TWENTY-FOUR). Its inversion, uniqueness and exhausting-alternatives passages "need comparison with the current complete resolving"; 4.6 ("half the competency") and 7.3 (the fixed schema) conflict with the Registry.
- **NINE.** "No sentence of the code." The court's fixed total (2.3) is itself a thing named still; "multiply past the sum" (1.5) implies size; and its favourable reading of institutions (2.1) "parts" from Natural Values 2.2.
- **FOURTEEN.** "Fractal technology" conflicts with the Registry's "a technology is a made thing applied from beside". An archived v378 note calls the file "the strongest candidate for a completed whole-file consolidation".
- **FIFTEEN.** "the rings are spirals": the note counts "5 sayings, 9 naming closure as the form" in this file. The 592,260 figure is to be "reproduced at its script or released". "The one stopping" and "A hard problem" differ from Natural Naming 5.30 and the Registry.
- **TWENTY-THREE.** 4.1's "no universal set" conflicts with the core's universe as the set of all existing things and an existing thing within it. A further caution: coordination or synchronisation experiments do not by themselves establish "bi-moral co-competency".

---

## Across all six

None of the six is at current wording: five are v329-v333 texts and SEVEN is current only in section 5.3, so expect released words (membrane, sign, surplus, store, hold, turn, cost, ring) on every page, and treat no resolver reference here as live (SEVEN cites three v372 names, FOURTEEN has one sentence, the other four have none). The six share one core (a two-way, one-at-a-time coupling whose +1 belongs to neither side; no hub, clock, store, standard or enforcer; making balanced by releasing; abundance) and repeat each other heavily: SEVEN 1.1 is FOURTEEN's core, SEVEN 2.3, 3.1, 3.2 and 4.3 reappear as NINE 1.5, 2.4, 5.2 and 5.1, and FIFTEEN's Part Two repeats its Part One. Almost everything rests on assertion and analogy, with no executed code; the outside facts used are mostly right but unsourced, and the weak points to fix first are NINE's class-action account, TWENTY-THREE's "proof grade" analogies, FIFTEEN's unreproduced 592,260, EIGHT's involution claims and SEVEN's cilium and collagen details. The files carry strong normative positions (no majority voting, no enforcement, governing as overhead, institutions unable to care, a cancer "cure" as a ledger correction) beside disclaimers ("prescribes no politics", "silent on care, on harm"), and they disagree with each other on institutions, so these passages need care in any public version. SEVEN is the most current by version, and FIFTEEN and TWENTY-THREE are the closest to readable by an outsider. EIGHT and NINE are the least current, and FOURTEEN is the one the project's own notes mark for folding into other files.
