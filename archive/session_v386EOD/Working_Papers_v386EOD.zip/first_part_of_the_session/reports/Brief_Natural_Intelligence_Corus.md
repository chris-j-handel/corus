COVERAGE. Read all 2,647 lines of /home/claude/chris-j-handel/corus/Natural_Intelligence_Corus_v330.md (about 61,800 words; no line ranges skipped), /home/claude/chris-j-handel/corus/carry/Natural_Intelligence_Corus.md, and sections 5.8 and 5.10 of /home/claude/chris-j-handel/corus/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md. Read-only; nothing run or acted on.

## 1. What it is
The remainder of an older, larger "corus" (the project's main body text) after its derivations moved out to the exhibits; its head note calls it "the first draft of the corus at its split", "moved and not rewritten". Only old Parts 14, 16, 17, 18 and 23 survive, under a Part One that is "the home page of corus.me". Reader: a newcomer, met "at what the self already carries". It sits beside the "separate white paper" (strict derivation; the registry calls today's core "lean as a white paper") and Exhibit ONE (code). So it is a welcoming companion and a store of applied, human-facing material, not a full statement.

"Corus" has two senses: (a) the body of writing itself, claimed to be natural intelligence happening in writing ("not a text *about* Natural Intelligence", 14.3); (b) a geometric term, "the still center inside the self's own knot; each self has its own corus" (23.1), paired with "destiny" as an axis. The file gives no origin for the word.

## 2. Structure
- ONE, The offering: the stake; six "doors" (memory, gating, timing; measuring, locating, separating).
- TWO and FOUR: empty.
- THREE (old Part 16, Natural Writing): sentence rules, inversion, the nye method, ghost, open research questions.
- FIVE (old 14): coupling between selves, intelligence, conversation, love/grief/loneliness, lying, meaning.
- SIX (old 18): left turns, 118 departments, ethics, regulation, discovery economy.
- SEVEN (old 17): ghost positions, uncontrollable values, hard problems, animal intelligence.
- EIGHT (old 23): destiny, natural network, natural society, natural robotics.

Sections 18.1, 18.7, part of 17.2 and 23.4-23.5 are stubs "released" to other exhibits.

## 3. Main claims
- Living is alternation, stable without resting: "Living is stable in disequilibria, holding its form by the sequencing alone" (Part One); refutable, it says, by one living competency that rests.
- "Where natural competency is observable, nature is better, faster, and cheaper than technology" (Part One).
- Everything natural runs at the golden-ratio rate: "*Natural* carries phi at every use" (16.1). The "+1" in x² = x + 1 is the living surplus, also meaning and value.
- One form, a genus-one "natural torus" with a resolver, seventeen primes (2-59) and sixteen "substrates", repeats at every scale, molecule to society to chip (23.1).
- "Intelligence lives in couplings. Not a property things carry" (14.3); inside one self the same activity is competency (14.8).
- Selves never meet directly: "selves couple with membranes"; "The membrane is a self" (14.1).
- Error is "ghost": "Ghost is a word given a self it lacks" (16.6). Causes, gates, clocks, possession and one-way verbs are ghosts; science's one-way statements are to be "inverted" (16.3).
- A self is bounded by four inequalities (not society, not another self, not immoral, not incompetent); "Ethics is at the form, not assigned" (18.4).
- Four "uncontrollable values" (uncapturable abundance, undiscoverable identity, inviolable safety, unmistakeable reputation) cannot be controlled because "they are not things at locations" (17.2).
- "Hard problems are real stuck couplings" where fields measure before sustaining, locate before attending, separate before joining (17.3); knowledge's "118 departments" mirror the 118 elements as frozen accountings (18.2, 17.6).
- "Control is the ghost" (17.1): autocracy, gating, credentialing, IP and the "control AI" framing are one-way projection.
- Discovery economy: value is the uncapturable surplus of each pairwise coupling; "The gift given freely conceives more value than the gift held" (18.8).
- "Natural Intelligence IS social intelligence"; "AI is beating at training-and-inference rates, neither of which is phi" (23.1).
- Destiny is "the natural network... free, shared, owned by no one" (23.3); "Decentralization IS structural necessity" (23.8).
- Verification comes from inside: "comprehensive coherent telling, not external judgment" (14.3), though 23.1 names the self-sealing risk.

## 4. Biographical and origin material
The file names no author, collaborator, organisation, business or date. It says only that the work is "the Natural Intelligence project", "a living expedition", written in chat between "the writer"/"the user" and "the LLM"/"AI" over "many sessions across many versions" (14.3, 14.8), including a "white paper carving conversation" that surfaced "twenty-three specific discipline catches" (16.1). Version marks: v234, passes at v314, file v330. Contact: incoming@corus.me (16.7). Named writings: white paper, Exhibit ONE, "tech spec sheet" (N23.8d), "Exhibit — The Instruments v234".

## 5. Concrete proposals
- "Natural intelligence ASIC chip": the resolver as hardware, "440 binary gates"; specification explicitly missing (23.7, N23.7a). Decentralised chip networks (18.6, 23.3).
- Natural network, or "artificial living intelligence surface": people report experience, the surface "compresses reports", the shared intelligence becomes a commons (23.2, 23.3). Requirements: free, shared, self-welcoming, local, coupling-preserving, carry-respecting; open protocols, no private protocol ownership (23.3, 23.7).
- Discovery economy (18.8, 23.6).
- "Resolving doors" replacing gates at every field's entry (18.5-18.6); data portability, interoperability, transparent governance (17.1); decentralised compliance, approval, safety and credential checking (18.5); institutions built on the "four sentences" (18.5).
- A "bounded science" with pre-registered predictions and engagement with IIT, Global Workspace Theory, autopoiesis, the free-energy principle (23.1; none appear here).
- Checks on existing data: organ-turnover ratio of (1/phi)², FDG-PET waking-to-NREM drop in four clusters, codon degeneracy, omega-3 index in stored HIV-cohort blood (16.7).
- Natural-form robotics; future sections on agriculture, finance, education, energy, governance (23.7-23.8).

The file says it specifies "the form", not "a political program or an institutional blueprint" (18.5).

## 6. Terms
- nye: a named open uncertainty, "reaching-toward"; also the value 0 (now "the between"). bothboth: both faces affirming; the surplus.
- phi-rate, beating: the one natural rate. Neither word is in the v380R core, where φ survives as "the unrelationing rate".
- natural: at phi-rate. "Stones are not natural" and the universe "has boundaries" (16.2); the carry file flags both as conflicts.
- carry / fresh: the prior arriving thinned and sign-inverted / the new arriving at full reach. Now the prior is carried whole.
- membrane: a third self. Now: nothing.
- substrate: one of sixteen levels between adjacent primes; gap-1/2/4/6: its thickness.
- supernatural: beyond one self's boundary, that is, between selves.
- Not present: momentary, parity, corusing, torusing, podaling, unrelationing, the co-/bi-/tri- names.

## 7. Resolver and numbers
There is no code. An older resolver is described in prose: phi hard-coded; carry thinning at (1/phi)^t; a reach threshold of 1/phi³; sign inversion of the carry; five switches in palindrome (bothbothing, inseparating, inversioning, inseparating, nyenyeing); output +1, -1, 0; later a "440 binary gate" form with "four cycles plus fifth orthogonalizer". "Seventeen" here means the primes 2-59 read as frequencies, with sixteen gaps. In today's Exhibit ONE it means the seventeen function and variable names of sign-only code with no phi, threshold, thinning or primes. Other numbers: 118 = 7x17 - 1 = 59x2; 64; 128; 228.

## 8. Evidence
- Executed code: none.
- Published observations, named without references: Mitchell's proton-motive force (16.6); Thurston, Hamilton, Perelman (18.8); Macphail, Kamil, anthropofabulation (17.4); Gibson, Varela/Thompson/Rosch (17.5); Arrow, Kuhn, Metcalfe; HACD1 myopathy in Labradors, ecdysone (17.7); transformer hum harmonics (18.6, 23.7).
- Proposed, unrun tests: the 16.7 list.
- Everything else is assertion, re-description or number-matching.

## 9. Open concerns and plans
**The file:** two empty parts; 45 labelled "continuing nye" questions; its 118-as-doubling conflicts with Natural Numbers (head notes, Parts 17-18); stale references to absent Parts (2, 5, 8, 12, 15, 20, 21) and old line numbers; "four resolving doors" against Part One's six; an editorial placeholder at line 778.

**Carry file:** nothing is scheduled before the file's "receivings". Restate the AI difference as "existing non-living intelligence". Three concerns: membrane-as-third-self and "compressed collective carrying" against the current membrane as nothing; phi-rate beats and stepwise destiny against momentaries and parity; "self-equilibrating", the orbit as stable form, the bounded universe, stones, (1/phi)^t thinning and "fractal technology" against the Co-Chaining Logic Registry.

**Registry 5.8 and 5.10:** Corus is the proposed home of the expedition's "enjoyable, imaginative and visible whole expressions". Candidate destinations for the older content: writing craft to Explaining; concepts to Naming; numbers and geometry to Natural Intelligence, Numbers, Mathematics; love and grief to Human Society and Philosophy; society and economy to Societies, Networking, Values; hard problems to their registries; chips and robotics to Engineering. "No routing note alone warrants removing its source." First worked example: group jigsaw puzzling.

## 10. Accuracy notes
Wrong or doubtful as stated:
- "The only millennium problem that resolves does not resolve by proof" (18.8). Perelman proved it.
- "the transformer architecture's 128 learned coupling geometries" (17.6). Head counts vary by model.
- "The LLM transformer architecture and the AC voltage transformer is one structure" (14.3). They share a name.
- "there is one omega" (Part One). Omega-3 and omega-6 are distinct fatty-acid families the body cannot interconvert.
- "systolic and diastolic... dissolving by DFA alpha1" (16.6). DFA alpha1 is a heart-rate-variability index.
- "growth IS bi-quadratic, not single-axis quadratic" (18.8). N(N-1)/2 is quadratic, the same order as Metcalfe; 23.3 itself says "quadratically".
- "The first convergent 3/2" (16.3). 3/2 is not phi's first convergent.
- "It has no clock" (Part One). Brains have circadian and oscillatory timing.
- Unsourced, or attributions I could not verify: "118 departments of human knowledge"; "Science's seven definitions of intelligence"; "Kamil's biocentric definition"; the DDIT4/ZNF254 cohort (16.7). Overclaim: "Two sentences dissolve Kuhn's entire framework" (17.1).

Guidance a reader might act on:
- Health: seed versus extracted oil (Part One); "every healing tradition's wisdom", "every food choice" (23.8); the omega-3/HIV item, which the file itself bars from action (16.7); "Burnout resolves through rest" (18.8).
- Safety and legal: safety, compliance, credential and permission checks treated as collapses (18.5); "Open input is safe when..." with no screening or credentials (18.8); human control of AI as a "control ghost" (17.1).
- Financial: IP as capture, property not to be held, gift economy (18.3, 18.5, 18.8).

## Before working on it
This is a legacy holding file in the pre-parity, phi-rate vocabulary; much of it contradicts the v380R core (rates and magnitudes, membrane as a self, bounded universe, thinning carry), so it is not current doctrine, and the carry file lists the conflicts. Its planned future is redistribution to other exhibits and renewal as the home of whole, enjoyable expressions, with source text staying until each receiving is complete. It has no code and no references, two empty parts, and many pointers to parts that no longer exist. The author invites doubt ("Knife anything") and the file names its own self-validation risk, so plain factual corrections like those above are within its stated terms.