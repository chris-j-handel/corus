## Scope and method

Read whole, front to back: all of Exhibit TWENTY-SEVEN, and Exhibit TWENTY-SIX from the heading "PART TWO · SHARED STABLE-FORMING" to the end. Section C was skipped as instructed. Nothing under the corus directory was changed, no script from it was run, and no git or web was used. Every quotation below was machine-checked verbatim against its source file.

Four look-ups outside the assigned text are labelled where used: the definition of "nye" (TWENTY-FIVE 1.12), the two files' own carry notes, and the session record (searched, not read whole).

---

## A. Exhibit TWENTY-SEVEN · Living Ghost Registry v345a

**1. Subject and purpose.** A catalogue of scientific and institutional terms the framework reads as "ghosts": a snapshot measurement or bookkeeping quantity treated as an enduring thing, agent, store, cause or destination. Entry by entry it separates what was observed, what is legitimate bookkeeping, and the exact sentence that promotes bookkeeping to a thing. It is also the intake "door" that sorts incoming records into ghosts, controls, and "societies" passed to Exhibit TWENTY-FIVE.

**2. Structure and entry format.** Eight parts: definitions; counting schemes; entry form with fifteen checks; internal sources; 13 full entries; five controls; the intake queue and door; 98 outside references. Each entry has three blocks:
- "At the door": the observation, ten numbered lines each read is / is-not / not-yet / empty, and a verdict.
- About twenty fixed properties, from "Name and use" and "Standing" to two "breakings" and "Addresses".
- A report ending in "Not-yet".

The 13: entropy, equilibrium, electron, single native protein state, single catalytic "stroke", minimal residual disease, diagnostic code as the disease, proton, element, a silicon electrodissolution experiment, homeostasis, Maxwell's demon, dark matter. Seven are "confirmed · natural register", four "candidate", two "released by the field"; 7.8 adds 23 short door readings. Fields: thermodynamics, chemistry, particle physics, structural biology, physiology, medicine, ecology, cosmology. Institutions cited: IUPAC, BIPM, European LeukemiaNet, WHO, IAU, ECB, IMF.

**3. Main claims, most important first.**
- "Ghost-form is a momentary accounting installed as living changing." (1.1)
- The fault is the promotion, never the word: "Installation is the binary." (6.3); "A term is never declared ghost at every use." (3.4)
- Every term is living, emanation or accounting; "a fourth placing arrives nowhere" (3.4).
- Confirmation is internal: "This standing asserts no scientific consensus about what exists." (1.5)
- Diagnoses can be defeated: "Both the ghost-form and the living return can lose." (3.4)
- Entropy leads: "entropy itself is the general ledger's gap entry" (5.1).
- Fields often undo their own ghosts: "The field's own definition contains both and names the still as appearance." (5.2)
- The door: "Ten lines, each sounded ahead, each read is or is-not, never how-much" (7.5).
- Unseen terms posted to balance a ledger stay candidates: dark matter is "nearer Neptune than Vulcan and standing at neither" (5.13).

**4. Special terms.**
- *Ghost*: "a momentary installed as a thing" (1.1).
- *Accounting*: a number, label, count, class or conserved total returned under stated conditions so the books close; legitimate at that use.
- *Emanation*: what an interaction leaves at a boundary, such as a detector click.
- *Installing*: treating either as entity, cause, store or destination.
- *Ghosting*: an expected coupling fails to arrive. *Haunting*: a sign persists after its basis has gone (1.4).
- *State / flow ghost*: a fixed quantity made the cause, versus one side of a two-way interaction made the actor (7.6).
- *Door lines*: resolve, rates, two-way, sign, passing, surplus, apex, residual, bound, reach.
- *The guard*: an unseen posted term is "Neptune" if later detected, "Vulcan" if explained away (7.7).
- *Nye*: a statement from general knowledge, not a documented record. *For fetch*: a source named, not yet retrieved.

**5. Ties to the resolver and "the ten".** The file keeps four tens apart (ghost positions, holdings, door lines, TWENTY-FIVE's pattern lines): "They must not be merged with the ten positions." (2.3)
- Section 7.10 maps each door line to one holding and a pair of resolver names; 7.11 maps each to one of eight "bi-namings".
- All of this is the pre-v372 code (`bi_arriving`, `bi_co_tunneling`, a "seven-position illustration").
- The file's own cross-check finds the two mappings share a name at only two of ten lines.
- The holding signatures written into the entries only partly match what the door lines give.
- Its carry note flags the tension with the set's current line, "every ten is that ten".

**6. Evidence and sources.** No new data and no resolver runs: published literature re-read (standards, experiments, method papers, consensus statements, history). Of 98 references, 22 carry links and 57 are marked "for fetch"; only Patzauer and Krischer (Physical Review Letters, 2021) is said to be "read whole". The mark "nye" appears 22 times.

**7. Vocabulary age.** Old throughout: membrane 98 times, sign 72, surplus 28, count(s) 76; parity, abundancing, "the between" and the seventeen names never appear.
- Released words carry weight here (membrane in the definitions; "sign" and "surplus" name door lines), and field usages such as cell membrane must stay.
- Cross-references point at superseded versions and sections.
- Expect Parts One, Two, 7.10 and 7.11 rewritten and the rest reworded sentence by sentence; the field content can largely stand.
- Its carry note sets the next step as "its old resolver names by the map".

**8. Open concerns the file flags.**
- Every entry names an unmet "Not-yet" test; 5.10 names one runnable experiment that would break the framework's own reading.
- Replacement readings may be thin: 5.3 breaks "If it merely renames these pairs"; 5.4 may be "orientation rather than explanation".
- 8.2: "not a sufficient electron or proton bibliography".
- 8.5: no outside source supports the project's own number constructions (24-27-32, 118 on a 0-120 ring).
- 6.2 and 7.1 enter a "turn at sixty" in the periodic table, apparently the project's own earlier reading, as a confirmed ghost.
- Stale: entries call arrivals at TWENTY-FIVE "not yet written" while the 7.7 ledger lists them.

**9. Accuracy notes.**

(a) Wrong or doubtful as stated (checked from memory, without web access):
- Probably wrong: "the first equilibrium measured in both directions, 1894 to 1899" (7.8; esterification, 1862, came first).
- Probably wrong: "carbon leaving the atmosphere arriving in the ocean as carbonate" (7.8; mainly bicarbonate).
- Dated: "insulin arrives in pulses roughly every thirteen minutes (nye)" (5.11; later work puts it nearer five).
- Consensus overstated:
  - "the settling point replacing the body-weight set point" (5.11; a rival model);
  - "the 2017 movement of the hypertension line" (5.11; one US guideline);
  - "The field's chartered body has stated" group three is convention (6.2; a provisional project-group report);
  - "Released by the field" (5.6; one leukaemia network).
- Idealisations: ammonia's "the nitrogen itself crosses" (7.8) is frame-dependent, yet decides self versus society. The vacuum record (7.8) reads "is" throughout though that detector response is calculated, never observed.
- Citation slips (Part Eight): "T. Schuurhuis" (G. J.); "V. W. Shah" (V. N.); the SNO ratio 0.306 appears to come from a 2004 paper; "Freedman et al. (2019) ... 69.6" appears to mix two papers; physics item 35 precedes 34 and repeats item 1.

The other dates, constants and citations I tested agree with the literature.

(b) Negative claims about named living people or organisations. None targets an individual; the file forbids it ("No individual is entered as a ghost", 7.3). Said of named bodies and authors:
- ECB and IMF pages "state the conventional installation" of money as a store of value (8.4).
- European LeukemiaNet's earlier word "minimal" "installed an assay-relative remainder as a smallest amount in the patient"; it is credited with the fix (5.6).
- WHO's ICD-11 is treated as honest bookkeeping; misuse by unnamed others stands as "Candidate at the installation" (5.7).
- Published claims entered as installations or candidates:
  - Zuo, Kim, O'Keeffe and Spence 1999 (orbitals "directly observed");
  - Milgrom 1983 (an acceleration scale as a constant of nature);
  - Poulin and colleagues 2019 (early dark energy as a posted component);
  - Tans, Fung and Takahashi 1990 (the "missing sink").

---

## B. Exhibit TWENTY-SIX · Living File Registry v380R, Parts Two to Five

These parts are a working plan in the current vocabulary. Nothing has moved yet: "this working registry changes no source exhibit" (4.6).

**(i) How the files cluster and relate.**
- Part Two says what every file shares: one method ("geodesic natural torusing, no other possible method of discovering next existing", 2.1) and one page form: title, subtitle, "floating neutralling contents", body, with each significant concept bold where its explanation opens (2.4).
- Part Three sorts the files into ten overlapping "gatherings" (3.1). Seven are by subject:
  - existing, resolving, numbers, mathematics (Natural Intelligence, ONE, THREE, FOUR, THIRTY);
  - coupling, networking, making (ONE, TWO, FIVE, SIX);
  - the sciences (EIGHTEEN, SIXTEEN, SEVENTEEN, TEN, ELEVEN);
  - self, society, value (SEVEN, NINE, TWENTY-THREE, FOURTEEN, TWO);
  - naming, explaining, illustrating, emanating (TWENTY, TWELVE, TWENTY-NINE, FIFTEEN, Corus);
  - problems and observings (NINETEEN, THIRTEEN, TWENTY-ONE, TWENTY-TWO, TWENTY-FIVE, TWENTY-SEVEN, TWENTY-EIGHT);
  - exploring and improving (EIGHT, TWENTY-FOUR, TWENTY-SIX, THIRTY).
- Three more cut across: human collective discovering, the whole expressed outward, and societies across "prime scales".
- Natural Societies' table of fourteen primes is "the intended centre of the exhibit's separate value" (3.4). The registry is cautious about it: its file matches "do not establish the numerical assignment", four rows are still "reaching", and what changes from one prime to the next is unexplained (3.5).
- Part Four lists 52 named "seams" between files (4.2) and separates seven registries by what each records (4.4): a field's stated problem (TWENTY-ONE), its proposed resolution (TWENTY-TWO), an observed society (TWENTY-FIVE), an installed accounting (TWENTY-SEVEN), a form named still (TWENTY-EIGHT), files and seams (TWENTY-SIX), logical steps (THIRTY).

**(ii) Planned merges, splits and receivings** (all planned, none done).
- TWENTY-FOUR Geodesic Improving Method is received into EIGHT, retitled "Geodesic Team-Exploring and Discovering Method", subtitle "Binary-All-or-None-at-All, Do-No_Harm Improving" (5.13).
- SIX Natural Transmissioning is fully received, then released (5.12): common method into Natural Intelligence and Naming, its cross-substrate comparison kept whole inside TWO Networking, particulars into the sciences and FIVE Engineering.
- FOURTEEN Natural Destinies: "All Destinies content is planned to receive in the other living files" (5.11), chiefly Corus, Values, Human Society, Networking and Engineering.
- FIFTEEN Natural Emanating is distributed: concepts to Naming, writing practice to Explaining, whole tellings to Corus, numbered examples to Numbers and Mathematics. Its exhibit status is decided afterwards (5.7, 5.8).
- Corus is renewed as "the proposed home of the expedition's strongest enjoyable, imaginative and visible whole expressions" (5.8). Its older technical content goes out to Explaining, Naming, Natural Intelligence, Numbers, Human Society, Philosophy and Engineering (5.10).
- SEVEN and NINE are both kept, duplicated passages reconciled (5.12). TWENTY-NINE and EIGHT stay beside Corus.
- "The planned receiving keeps all three files" (4.6): SEVEN, TWENTY-FIVE and TWENTY-SEVEN, joined by paired entries and one shared intake derivation.
- TWENTY-SEVEN and TWENTY-EIGHT get a shared subtitle, "Not Possibly Existing, Living or Non-Living", and proposed titles Ghost Observer Registry and Equilibria Representation Registry. Whether two exhibits are still needed is left to the entries (4.7).

**(iii) Order of work, and the lettered passes.** The passes are not defined in Parts Two to Five; the letters appear only in Part One's "next" column. Outside the assigned text, the session record lists ten items at v373 as "the plan's passes A to J". In order:
- A "the origin at the one sentence"
- B "the names, the old code and the released words at one motion"
- C "no explaining from outside with the fronts"
- D "Natural Intelligence's released passages received"
- E "wordings"
- F "explorings at the code and the numbers"
- G "the receivings"
- H "Exhibit THIRTY's roots"
- I "the kits"
- J "the working's close"

Other mentions confirm A, B, D, F, G and I; C, E and H are my inference from position. J was later reused, and K and L added. At v378 the same record says "no plan stands across the files, and a file's carrying says its own next", so a letter now only labels a file's next step as it stood at v377.

Parts Two to Five do fix a rule of order: compare, receive whole, then release the source. "A passage crossing into another file arrives whole before its prior wording releases" (5.3). Named first steps:
- one whole expression, group jigsaw puzzling, arriving at Corus (5.10);
- explaining the macromolecule, protein-fold and gene rows of the prime table (3.5);
- two repairs to TWENTY-SEVEN, its stale protein-arrival note and its Naming references (4.6);
- correcting SIX's contradictory "membrane" passages before receiving it (5.12).

**(iv) Purpose, audience, publication, wider collaboration.** These parts say nothing explicit about audience, publication venue or recruiting collaborators; "published" refers only to current titles.
- Purpose: "The expedition is living carrying discovering next existing society" (5.5).
- Corus is the outward-facing home, built from human activities such as group puzzling; music, stories and humour are "opportunities for receiving, not completed works" (5.9).
- Destinies' imagined applications (a discovery economy, a "natural network originated by its selves", chips and grids) must keep "the difference between a demonstrated resolving and a proposed application" (5.11).
- House style: "the text introduces no speaker addressing or presuming the reader's thoughts" (5.13).

**(v) AI sessions and the human author.** Only indirectly.
- "Team names the selves co-discovering", with "no separate team controller or additional discovery method" (5.13); work on the files is one instance of the method.
- A session's conclusion is recorded with the caveat "This registry pass has not rerun those derivations" (4.7).
- Plans rest on agreement, not completion: "This agreement authorizes the plan and does not claim the source transfers are complete" (5.12).
- Working rules (5.13): "A destination named alone is no completed receiving"; "nothing is dropped merely to shorten the combined exhibit"; "Scripts travel with their findings, not as general team instructions".
- Unresolved items go to the carry document Living Improving Value.
- One editing caution: the "four momentaries" account must not be applied by search-and-replace, since "A three-to-four replacement across the files would conflate the relations" (5.13).

---

## What a collaborator most needs to know

1. The Ghost Registry is the set's most outward-facing and checkable file: it works from real literature, marks its own unverified lines and names what would defeat each entry. But "confirmed" there means confirmed under the framework's own definition, not accepted science, and the file says so.
2. It is also among the oldest in wording and wiring, v345a in a v380 set. Its definitions lean on released words, its resolver mapping is to the pre-v372 code and its cross-references are stale, so bringing it current is a rewrite with field-owned words left alone, not a word swap.
3. Parts Two to Five of the Living File Registry are a plan, not a record of finished moves. Every merge is a "receiving" in which a passage must arrive whole and be compared before its source is released, and blanket replacements are warned against.
4. The lettered passes are a retired cross-file plan; each file's note in the carry folder now states its next step. The Ghost Registry's note records the author's words: "continue through exhibit one naming then natural intelligence and numbers then one to exhibit thirteen and twenty seven as a possible path".
5. The Living File Registry's carry note quotes the author, "i repeatedly need to request exact all or none at all names of things using our naming", and asks for "no line number in speaking". Name a file by its whole name, a section by number and title, a passage by an exact quoted phrase.
6. The factual slips above are best raised as specific, quoted, checkable concerns, kept apart from the framework's interpretive claims; that is the form the file's own "nye" convention already uses.

## Files

Assigned:
- `/home/claude/chris-j-handel/corus/Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md`
- `/home/claude/chris-j-handel/corus/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md`

Consulted outside the assigned text:
- `/home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-SEVEN_Living_Ghost_Registry.md` (read whole)
- `/home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-SIX_Living_File_Registry.md` (opening only)
- `/home/claude/chris-j-handel/corus/carry/Session_Record.md` (searched for the passes)
- `/home/claude/chris-j-handel/corus/Exhibit_TWENTY-FIVE_Living_Society_Registry_v347.md` (section 1.12, the "nye" definition)