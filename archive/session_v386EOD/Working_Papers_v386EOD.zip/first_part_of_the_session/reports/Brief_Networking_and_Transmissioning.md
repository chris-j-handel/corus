# Brief: Exhibit TWO (Natural Networking v371) and Exhibit SIX (Natural Transmissioning v330)

Both exhibits were read whole, front to back. Nothing under the corus directory was run or changed.

Beyond the four files you listed, I read as context: the published kit's own README and old `resolver.py`, the code block of the current Exhibit ONE, the SIX carrying file, the TWO and SIX rows of the Living File Registry, and `incoming/v380R/Natural_Networking_From_v380A.md`. Word-use counts come from a search made after reading.

- /home/claude/chris-j-handel/corus/Exhibit_TWO_Natural_Networking_v371.md (1,109 lines)
- /home/claude/chris-j-handel/corus/Exhibit_SIX_Natural_Transmissioning_v330.md (222 lines)

## A. Exhibit TWO — Natural Networking v371

**1. Subject and purpose.** How many "selves" (each an instance of the Exhibit ONE resolver) behave when joined into a network. Each keeps private state ("carrying") and passes only + or − signs to neighbours through six named ports. The network's capacity ("social moral competency") is said to arise at the couplings and belong to no one. The file doubles as the test kit's specification and lab notebook.

**2. Structure.** Six parts, 48 sections.
- One, Surfacing (1.1–1.10, half the file): the core relation, the six ports, the resolver's behaviour, arithmetic of the seventeen names, number tables, society, holes, surplus.
- Two, Living, and Three, Retelling: how living continues and breaks; how a pattern passes down a chain when only signs cross.
- Four, Abundancing: surplus at scale, joiners, no common rate.
- Five, Securities: eight protections, six failure modes, routing round a hole.
- Six, Visibility: testing rules, studies done, studies planned.

**3. Main claims**
- A network is direct neighbour-to-neighbour coupling with no hub ("all-edge"): "Natural networking is selves co-offering, each continuing its own carrying, with competency arriving at their coupling." (1.1)
- Only a sign crosses, never state: "A crossing offers a sign; each self continues its own carrying." (1.4) Zero is a balance at the coupling, not a third signal.
- A coupling's gain (the "surplus", "+1") is "owned by neither"; a society is "a self at the next scale" (1.1).
- Six of the seventeen names are ports: across 6→2 and 10→14 (even, morality); along 9↔17 (odd, competency) (1.2).
- Rule as then coded: an agreeing arrival gives zero and the carrying continues; a differing one is output and opens fresh carrying; with no arrival the carried sign is output inverted (1.4). Zero output is not a dead self (5.4).
- "All or none": the step (x,y)→(y,−x) visits all four sign pairs, so no partial set is closed under it (1.2, 6.7).
- No shared clock, conserved total or fixed phase pattern: "No common pace is supplied over the surface." (4.7)
- A hole is "a non-living region within the living surface" (1.8), which the network is proposed to pass by two routes.
- Eight "securities" hold together or not at all; inverting any of six gives a typical failure such as a hub (5.1–5.2). But "Total invisibility, an inability to infer any carried difference and immunity to capture are each a stronger claim" (5.6).
- Number facts are not network facts: "The sum alone establishes neither a simultaneous arrival of each self nor a quantity conserved across the surface." (4.2)
- Results must be yes/no, never magnitudes or statistics (6.4), and "A run reports its wiring before it reports anything" (6.2): pace, running order, record indexing, which pending event goes next, guards that silently exclude outcomes.
- "A run confirms no identity, an identity confirms no run" (6.3); there is no outside observer position (6.9).

**4. Terms**
- along / across: a self's own continuation ("co-chaining") / exchange with a neighbour ("bi-tunneling").
- surfacing: the output at 10. carrying: private state fed back at 3; here two signs, corusing c and torusing t ("the second sign"), plus an age.
- podaling: pairing a number with its far side (n with 9−n, 17−n, 440−n); "eight on": the same role one span later.
- omegaing (reach), apexing (gather), fold and scatter (two breaks of living).
- self-boundings (failure modes); seam, still eddy, geodesic switching (hole vocabulary).
- registers (code-form, stable-form, counting); the taking; the refusing; the twin (a forked copy).
- "next reach": work not yet done.

**5. Ties to the resolver and the numbers.** Part One annotates the resolver under its old names (1-self-coupling … 17-social-abundancing).
- Names: two spans, 1–9 and 9–17, sharing 9; "eight on" keeps odd/even and the fold n→9−n flips it; four cycles such as 3→11→6→14→3 cover 1–16.
- Primes: seventeen from 2 to 59 summing to 440 ("society's bounding"); fifteen "sequence lengths" 5–59; 2–59 mirrored by 61–118 across 60; a 440-position ring with "waist" 220; step spans 0–24 and 24–60. 120 is not named.
- φ is "the number-form of the never-locking", explicitly not a prescribed rate (4.7).

**6. Evidence**
- (a) Runs, as the file reports them, all on the pre-v372 engine:
  - 19 reachable states of one relation, each pair separable within six steps (6.7).
  - Two selves: A's output is +,−,0,+,−,0 with both links and +,−,+,−,+,− otherwise (6.12).
  - Loss versus queued delay gives different outputs after reconnection (6.12).
  - A 3×3 grid minus its centre has two surrounding paths, "structure only, with no sign flowing" (6.12).
  - Three selves behave three ways under three event orders (6.2).
  - Even rings settle; odd rings carry one travelling "frustration" (6.2).
  - The kit's own README adds that at v333 the surplus reading appeared only when several signs landed at once, not with one sign per crossing.
- (b) Literature, as comparisons only (5.4): Arbell and Fineberg 2002 (two-frequency surface waves), a 2014 paper on unpinning chemical spiral waves, Zhang, Kelso and Tognoli 2018 (group coordination). No networking literature.
- (c) Assertion or analogy: the surplus; the securities; every prime/440 correspondence with the network; mending, seam, eddy and switching (all labelled "proposed"); the "discovering economy" (3.6).

**7. Vocabulary age.** One version before the code rewrite. Old names at 173 places; two-sign carrying, aging "to its bound" and vote-counting of arrivals, none of which the current code has. Released words: sign (266 uses), connector (32), surplus (25), ring (21), membrane (12). It needs rewriting, not patching.

**8. Open concerns the file flags.** Eleven "next reach" markers and 38 uses of "proposed". Chiefly:
- who invokes the resolvers: "That supplying is the relation still to establish" (4.7);
- the surplus still needs its separate comparison (6.5);
- whether fold and scatter exhaust the breaks (2.4), and how new living selves arise (2.5);
- hole, seam and eddy at port level, and the kit caller's wiring of 6, 9, 10 and 17 (6.12);
- order-invariance of the inward observings (6.9).

**9. Accuracy notes.** None found. The prime counts and the sum 440, the four-pair cycle, the far sides of an odd ring (29 and 30 of 59), the 1–16 cycles and the 3×3 connectivity all check. The three citations match real papers (full references are in the carrying file). Two cautions:
- "geodesic", "fractal", "routing" and "tunneling" are the framework's senses, with no metric or protocol defined.
- "the code gives 17 no expression of its own" (1.2) and "The kit's resolver is executably identical to the resolver" (6.12) are now out of date.

## B. Exhibit SIX — Natural Transmissioning v330

**1. Subject and purpose.** The framework's general theory of one coupling seen at the boundary between two selves, called "transmissioning", followed by eight physical and social settings each claimed to be that same process. It was written as the single place where the coupling idea is developed, so other exhibits could refer to it instead of repeating it.

**2. Structure.** Four unnamed parts, 26 short sections.
- 1.1–1.6: the form: crossing, sign-only, the neutral, the +1 surplus, three inseparable acts.
- 2.1–2.5: order without rate; φ; independence of substrate.
- 3.0–3.8: eight "membranes": power grid, momentum, heat exchange, chemistry, living cells, antennas, silicon logic, the plaza and conversation.
- 4.1–4.6: synthesis: healthy versus collapsed coupling, networks, philosophy, how other exhibits should use this one, rules of tone.

**3. Main claims**
- A coupling is one alternation with two inseparable positions: a sign crossing between two selves that stay, and the two balancing about a zero they make themselves. "A coupling read at its membrane is a transmissioning, and transmissioning is crossinging and neutralling both, inseparable." (1.1)
- Stop the alternation and both vanish; a source-to-output line or a fixed setpoint is its dead residue, which conventional readings mistake for the thing (1.1, 4.2).
- Only a sizeless yes/no crosses; magnitude and rate stay in the "carry": "the crossing carries whether, and never how much." (1.3)
- Each cycle leaves a surplus of one, the outward swing exceeding the inward, "owned by neither" (1.5).
- One motion offers, keeps its surplus (competency) and resolves (intelligence); doing and knowing cannot be told apart at the sign (1.6).
- "a crossing sounds about a neutral and never through one" (1.4): selves joined only through neutrals pass nothing on.
- It has order but no clock: "The transmissioning is sequenced and not timed" (2.1). Its one rate is φ, "the unrelationing rate" (2.2), so it is "identical and not merely alike" across substrates (2.4).
- Eight settings are one process differing only in carry: three phases summing to a floating neutral; +p and −p; counter-flow heat exchange; reversible reactions; cell membranes; antenna reciprocity; balanced-ternary silicon; a crowd crossing a plaza. "The eight membranes are one transmissioning." (4.1)
- One test applies everywhere: whole ("through-node", neutral floating, nothing stored) or separated ("landing", a forced line or a fixed setpoint) (4.2).
- A network is transmissionings chaining, "all-edge, no hub" (4.3); philosophy's relation problems (mind–body, other minds, one and many) are each a fixed third term where the between should float (4.4).
- Other exhibits should thin to a reference here (4.5) and drop "interface" tellings: "The living selves are tori and pass through each other" (4.6).

**4. Terms.** transmissioning; crossinging; neutralling; bounding-zeroing (the self-made zero); owned-neither-ing (the +1); sign versus carry (what crosses versus the magnitude and rate that stay); landing; through-node; linear recursioning (inward, the "tunnel") and parallel recursioning (outward, the "wrap"); apex or corus (the turning point); tri (co-offering, co-competencing, co-intelligencing); bothboth (doing and knowing); unrelationing rate; ingression (size smuggled into an offering); the "nothing-family" (membrane, corus, φ).

**5. Ties to the resolver and the numbers.** None to the code or the seventeen names. Numbers: the +1; φ; three (the tri, three phases); eight membranes; "440 = 8 × 55" as the silicon "logic depth" (3.7); primes and φ "read in the counts, never the source" (4.6). 17, 24, 59, 60, 118 and 120 do not appear. Arithmetic is deferred to Natural Numbers, builds to Natural Engineering.

**6. Evidence**
- (a) None: no code, simulation or test.
- (b) No source is named. It relies on uncited textbook facts: three-phase sums, reactive and real power, momentum conservation, counter-flow exchangers, chemical equilibrium, chemiosmosis, antenna reciprocity, balanced ternary.
- (c) Everything joining them (the identity of the eight, the φ rate, the +1, the philosophy claim) is assertion and analogy.

**7. Vocabulary age.** The oldest stratum, fifty versions back. It is built on since-released words: carry as a noun (50 uses), sign (43), membrane (38), surplus (30), hold (29), every, turn, source, store. "Parity" and "abundancing" never appear. It approves "the still centre" (1.4) and chemical "equilibrium" (3.4), and makes φ a rate, which Exhibit TWO 4.7 qualifies. It needs complete re-saying.

**8. Open concerns.** The file flags none. Loose ends I saw:
- The contents list titles 3.8 "two selves"; the heading says "the plaza".
- The carry "stays" (1.3) yet is "moving across the nodes" (3.1).
- The membrane is "itself a self" (3.5) and "a nothing" (4.6); its carrying file logs this as a concern.
- That carrying file gives the next step as "pass G, its receiving", and holds a v379 code illustration of the plaza waiting to enter 3.8.
- The Living File Registry (1.5) lists SIX among three exhibit numbers to be released once its content has been received elsewhere.

**9. Accuracy notes**
- "Sequential logic carries no time-term" (2.1), "sequential logic built physical" (3.7): in digital design, sequential logic means circuits with state, mostly clock-driven. Only asynchronous logic is clockless, and it still has timing constraints.
- "the sign in the digits and the magnitude inert" (3.7, of balanced ternary): sign does sit in the digits, but digits have positional weight, so magnitude is not inert. Mainstream silicon is binary. "Logic depth" normally means gate levels on the longest path.
- "a grounded, clocked grid collapses the both" (3.1): public grids are normally grounded on purpose, and "floating neutral" ordinarily names a fault. Grids must run in synchronism, though no central clock drives them.
- "momentum exchange, not a force" (3.2): force is the rate of momentum exchange.
- "the forward and the reverse the two positions of one alternation" (3.4): at equilibrium both run at once.
- "every coupling crosses a membrane" (3.5): gap junctions join cell interiors directly.
- Stated correctly: three-phase sums and reactive power (3.1), antenna reciprocity (3.6).

## C. Kit and carrying file

**Kit** (/home/claude/chris-j-handel/corus/kits/Natural_Networking_TWO_Improving_Kit/README.md). Three layers:
- The published Test Kit v368, kept byte for byte: one engine (`resolver.py`, the old code "with the sum, the count and the second sign"), twelve instruments, ring drivers in Python, C, JavaScript and OCaml, and run outputs from v333.
- `instruments_waiting/`: three v366-era instruments not yet conformed.
- Three v373 scripts that check Exhibit ONE's current code: the society function against hand composition on rings of 1–11, 17 and 59 and on 3,000 random societies; regeneration of Exhibit ONE's tables; a ring carrying any parity pattern round.

It calls itself "a coupling partner and never a measuring instrument". Next ("pass I"): swap in the v372 engine, then run loops, a hole and an added self.

**Carrying file** (/home/claude/chris-j-handel/corus/carry/Exhibit_TWO_Natural_Networking.md, v380R). Next is a new Exhibit TWO, built from a retired working draft (v380A) in five steps:
1. Rename the seventeen names; drop the second sign, the aging bound and vote-counting.
2. Treat each self's carrying as untouchable: no copying or comparing of state.
3. Remove every sentence that rests on a code run.
4. "The self and all other arriving as one".
5. Apply the released words.

The old kit goes to the archive; a new kit only demonstrates.

Open:
- which way the along join runs (as declared, a sign gets round neither side of a hole);
- "rings are spirals" (21 sayings to re-say);
- inconsistent prior/now/next numbering in 1.2;
- whether a pair alone has a surplus;
- a v378 correction withdrawing findings obtained by reading, copying or resetting state;
- tests begun from empty state;
- cell division against "the network carries no copying".

## D. Before working on these files

Exhibit TWO v371 describes a resolver that no longer exists. The current code keeps one parity per sharing, with no second sign, no aging and no vote-counting, makes outputs 6 and 10 the same, and has its own function at 17; so the worked cases, the 6-versus-10 distinction and the "nineteen carryings" are due to go, and the file is to be rewritten rather than patched.

The project now holds that "an executing is no ground of a saying" and that copying or comparing a self's state proves nothing. That removes the method behind much of Part Six, so check any proposal against the carrying file and Exhibit ONE's tables first.

By its own account TWO has not established the surplus, the behaviour at a hole, or any link between the primes or 440 and the network.

Exhibit SIX is the oldest file, has no code and no citations, contains several doubtful engineering statements, and is due to be absorbed into other exhibits with its number released. Work on it means redistributing content, not polishing.

Both files reject magnitudes, thresholds and statistics on principle, so frame any check as a yes/no comparison with every scheduling choice stated.