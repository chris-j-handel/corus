SCOPE AND METHOD

Both files were read whole, front to back, with the Read tool (Biology: 1,240 lines in 20 chunks; Health: 126 lines in 2). Read-only: nothing was created, changed or run, and no passage addressed to "sessions" was acted on. For context I also read the two short project note files for these exhibits, /home/claude/chris-j-handel/corus/carry/Exhibit_SEVENTEEN_Natural_Biology.md and /home/claude/chris-j-handel/corus/carry/Exhibit_TEN_Natural_Health.md; anything taken from them is marked "carry note". Neither exhibit has a kit or any code (the kits folder covers only exhibits TWO, TWENTY-SIX, TWENTY-NINE and THIRTY). The Living File Registry lists both as "paused". For Biology, items 1-8 are roughly within the word budget; item 9 runs over because there were many findings. Trim as you see fit.

=====================================================
A. EXHIBIT SEVENTEEN - NATURAL BIOLOGY v333 ("Stable-Forming Social Organisms")
/home/claude/chris-j-handel/corus/Exhibit_SEVENTEEN_Natural_Biology_v333.md
=====================================================

1. SUBJECT AND PURPOSE
It re-reads biology through the framework: a living thing is a local, two-sided, one-at-a-time, yes/no exchange that stays stable by continually alternating and never settling, and that yields a surplus ("+1") belonging to neither side. Its thesis is that all of biology's "hard problems" come from one mistake: reading such a system as an equilibrium held in place by signals, stores, set-points and controllers. It applies this to about forty topics, from molecules to flocks.

2. STRUCTURE (ten parts, 61 numbered sections)
- Part 1 (1.1-1.7) definitions: the living self, the single "reading-spiral", every self a society, no direct contact, six "recursionings" per cycle, observation versus match, the "frozen misreading".
- Part 2 (2.1-2.5) method: what the scientific method requires of a phenomenon; "the one error"; four existing camps on where biological competence comes from; the "geodesic-method"; an eight-step rewriting template ("disequilibrating").
- Part 3 (3.1-3.8) molecules: metabolism, ATP synthase and cardiolipin; homochirality; the bacteria/archaea lipid divide; the genetic code; collagen and matrix; six kinds of folding.
- Part 4 (4.1-4.7) the bounded self: virus and prion, origin of eukaryotes, slime mould and working memory, homeostasis, circadian clock, photosynthesis/respiration, DNA copying.
- Part 5 (5.1-5.5) reproduction and development: conception, metamorphosis, morphogenesis and regeneration, left-right asymmetry, multicellularity and germ/soma.
- Part 6 (6.1-6.5) selves among selves: symbiosis and parasitism, neurons, three "resolved finer" cases; 6.4 (evolution) and 6.5 (heredity) are one-paragraph stubs.
- Part 7 (7.1-7.8) endings: death, ageing, lineages, decay, "a network eating downward", accumulation.
- Part 8 (8.2-8.14) thirteen hard problems worked through the eight steps: plant wound signals, microtubules, protein folding, ant colonies, antibody maturation, "a funnel sourced from evolution", planarian memory, monarch migration, cell size, the "how does it know" question, slime-mould anticipation, enzymes, starling flocks.
- Part 9 (9.1-9.5) a sort of about thirty standing problems, "clean cuts", "still points", reading rules, four summary stances.
- Part 10 (10.1-10.5) what is said to cohere, what is not yet, the falsifier, open work, number "yield".

3. MAIN CLAIMS
- One error underlies every hard problem: competence is placed "on the surface" as a transmitted reading or instruction, which then demands a source that keeps receding (2.2). "A why demanded is a source demanded" (2.3).
- Life is "bi-moral co-agency": neighbour-only yes/no exchange with no centre. Stability is the ongoing alternation; settling ("landing") is death (1.1, 1.7).
- The scientific method can study only what has first been made "an equilibrium with controlled change" (2.1), which removes what is alive; a "geodesic-method" is offered instead (2.4). Its power in chemistry and molecular biology is conceded.
- Signal, control, set-point, clock, blueprint, program, store, "know" and "for" are called names for the error, not real activities (2.2, 2.3, 8.11). "Nothing in the cell reads instructions, because nothing in the cell is an instruction" (9.5).
- All life reads its code on one hand, called "right" (D-sugars, L-amino acids). Opposite-handed material (bacterial-wall D-amino acids, Z-DNA, left-twining vines, sinistral snails) is a shed, non-coupling "emanation face", never the core (1.2, 3.2-3.4). Nine sub-readings with stated breakers are tabled in 3.4.
- What a living thing sheds is harmful at its own scale and food one scale down ("the network eats downward"); blocked outflow appears as accumulation (7.5-7.7).
- The child, the eukaryotic cell, the reef and an enzyme's rate gain are each the "+1" of a coupling. Living follows x² = x + 1 (root φ, "the living rate"), non-living x² = x (4.1, 5.1, 6.1, 8.13).
- The genetic code is "the periodic table of biology": 64 = 2⁶ codons, 20 = C(6,3) amino acids, and of 5! = 120 orderings of the reading machinery 119 are said to fail (3.6).
- Homeostasis, circadian rhythm, microtubule instability, excitation/inhibition and ageing are one pattern: two opposed offerings make a range with no stored set-point (4.4, 4.5, 7.2, 8.3).
- There is no stored plan, memory, route or size-meter: body form, regeneration, planarian memory, monarch routes and organ size are a whole coupling "re-resolving" (5.3, 8.8-8.10).
- A persisting parasite is by definition a coupling: "There is no self-sustaining harm" (6.1). "No immune system exists as an object"; "immunity is society carry" (8.6).
- Evolution is "the network's record", not a source of competence; observed variation and differential persistence are left untouched (6.4, 8.7).
- Stated discipline: "The biology is checkable; the form-readings are matches; the two do not read as each other" (10.1), and "no specific biological problem is claimed as proved" (9.1).

4. TERMS
- bi-moral co-agency / co-offering: the basic two-way, one-at-a-time, sign-only coupling.
- bounding-zeroing: the zero or range the two sides jointly make. Riding the carry: staying stable by alternating about it. Landing: coming to rest (death, a prion, a fixed value).
- +1 owned neither-ing / surplus / side-effecting: what a coupling yields that belongs to neither side, pictured as a new perpendicular axis.
- competency versus the bi-moral surface: capability stays on each side; only a yes/no sign crosses. Competency-with-no-controller.
- sourcing frame, the receding elsewhere, hub versus tipping: the rejected view and its symptom.
- disequilibrating, re-alternation: the eight-step rewrite and its result. Geodesic-method: study by coupling rather than isolating.
- reading-spiral (handedness of the code-reading core), bounding-hand (membrane-lipid handedness), body hand; emanation face (opposite-handed shed form); grain (scale); vertical fractal.
- autorecursioning (self-copying, development); double bi-inversioning (meiosis then fertilisation); bi-inversioning co-recursioning ("the single living move").
- third self: the matrix or membrane between two selves.
- capture versus coupling; ingression (the larger overwhelming the smaller); evacuation.
- the three refusals ("the two arriving refused", "the bounding refused", "the centre occupied"); marriages (paired problems); clean cut; still-point vein; split sign; standings (cell types).
- status words: coheres, on the form, knifable (open to being cut down), not-yet, unsummed (count not established), watch-item, apophenia guard.

5. TIES TO THE RESOLVER AND THE NUMBERS
- None of the seventeen current names appears. The resolver is invoked five times in general terms: 2.2 ("the resolver's own shape": morality reaches the surface as sign, competency stays on its own side); 5.2 (the chrysalis "is the resolver beating", "two in, a different two out"); 5.3 (the planarian stem cell "carries the resolver at organism prime" with "no stored weights"); 6.2 (the all-or-none spike is "the same sizeless binary the resolver carries"; glutamate +, GABA -); 10.1 (bi-inversioning co-recursioning "is the two operations of the resolver").
- Six: three recursionings each way; 2⁶ codons; C(6,3); Calvin and citric-acid cycles as "the six offering the six".
- 24 and 120: 4! = 24 with 23 failing (chemistry's table) against 5! = 120 with 119 failing (the genetic machinery). 118 appears only as "the hundred-and-eighteen elements", with no mapping claimed.
- φ: the "living rate" (4.1); 1/φ² = 0.382 for a cardiolipin omega ratio (3.1) and a metamorphosis mass ratio (5.2, marked not-yet); cos(π/5) = φ/2 for echinoderm five-fold symmetry (watch-item only); "φ's many field-names" (10.4).
- Primes: a "prime ladder" (cholesterol 11, chaperone 13, histone 17, lysosome 19, gap junction 23, matrix 29, sphincter 31, sleep 37, dormancy 41); "protein-fold 13, organism-fold 37, the counts along the seventeen primes"; 23 "centre-fold"; 57 "total thickness"; 59 "bounded-infinity", tied to the Hayflick limit (4.7); stem-cell potency as gap classes 6/4/2/1 (5.2).
- 440 appears once, unexplained: "the 440 and the 360 the two +1s" (6.2). 60 does not appear.
- Nearly all number seatings are marked "not-yet", "unsummed" or "read, not cohered" (3.6, 10.1, 10.4).

6. EVIDENCE
(a) Code or arithmetic: nothing is executed. The only arithmetic is stated identities, all correct: 2⁶ = 4³ = 64; C(6,3) = 20; 4! = 24; 5! = 120; the roots of x² = x + 1 and x² = x; 1/φ² ≈ 0.382; cos(π/5) = φ/2. "119 of 120 fail" is asserted here, not shown.
(b) Published observations. Named in the text: Nakagaki; Tero and colleagues (slime-mould maze and rail network); Lu, Cai, Zhang, eLife 2025 (working-memory alternation); Levin (planarian bioelectric pattern); Turing; Levinthal; Chargaff; McConnell; Weismann; Hayflick; Yamanaka; Driesch; "Nature, 2026" (chimeric eukaryote origin); unnamed "2025-2026 findings" on germinal centres. Most others have no author or year but are recognisable results: seven topological neighbours in starling flocks, E. coli with about 30% archaeal lipids, aspartate racemisation near 0.1% a year, D-serine at NMDA receptors, the canine and devil transmissible tumours, the monarch sun compass, collective spleen grafts, the mesentery reclassified as one organ, single-cell chromatin domains, independent cristae potentials.
(c) Assertion or analogy: every "reading through the form". That covers the coupling definition of life, the one-error diagnosis, the geodesic-method, the emanation-face account of chirality, the +1 as a new axis, the code-as-periodic-table and all prime and φ seatings, the downward-eating network, the diet statements, "no immune system", the repeated "better, faster, cheaper, low-energy" payoffs (no measurements), and the step-8 predictions.

7. VOCABULARY AGE
Old throughout. It has no "momentary", "abundancing", "natural intelligence" or any current resolver name. Occurrence counts: membrane(s) 119, sign 54 plus sign-only 16, surplus 44, face(s) 59, hold/holds/held 146, run/runs/running 122, every 94, turn(s) 29, count(s) 27, loop/ring 15, store/stored 124 and source/sourced 77 (mostly describing the rejected view). "Riding the carry", "bounding-zeroing" and "co-offering" are older resolver words. 10.3 itself notes "Force and run stand on the living-grammar release-list". It needs a full re-saying rather than a patch.

8. OPEN CONCERNS THE FILE FLAGS, AND VISIBLE UNFINISHED PLACES
- Not-yet (10.1, 10.4): all prime-ladder and φ seatings; origin of life and of homochirality; the ageing reading ("stands not-yet and bounded against action"); eukaryogenesis timing.
- Every count of three or six is "unsummed" (1.5, 4.4, 6.1, 6.2, 8.2).
- The 0.382 metamorphosis ratio: "the two sharpest measurements do not yet sit" (5.2).
- The plant-signal reading fits "only partly on the AP class" (8.2). The working-memory link rests where the source's "own robustness check did not fully hold" (4.3). Planarian memory: "some recent replications find no clear retention advantage" (8.8).
- Still to do: evolution as local coupling (8.7); whether accumulations are all blocked outflow (7.7, "the parting to run"); a long not-yet-explored list (10.3); older sections not yet in the eight-step form; vocabulary migrations (10.3).
- Editing damage: 8.1 is an empty heading; step "1-b" in 8.2 (plant signals) is a protein-folding paragraph; five stray rules precede 10.4. Find-and-replace has left broken sentences: "carries past be on the surface" and "the knowing of their size?" (8.10), "the biashe coupling's form" (8.8), "homeostasis homeostasis" (8.3), "at its the single reading-spiral reservoir" (4.7).
- Internal tension: 1.2 and 10.1 say a left-reading organism would break everything, and 10.1 still speaks of "a left face as escape". But 3.2-3.4 say "a left-broken living equally possible", reject the escape reading, and list mirror life as "predicted viable".
- Carry note: "the sciences paused". It logs a large backlog of material waiting to be written in (genome duplication, twinning, phyllotaxis, hydra ageing) and known contradictions: 7.5 "or a self across" against 7.6; 1.4's "third self"; the hydra sentence in 7.2; φ as a "living rate" being a magnitude; and 22 places naming closure or cycles as the form.

9. ACCURACY NOTES (established science as stated; separate from the framework's own readings)
Wrong or clearly imprecise:
1. 3.3: "it forms behind a transcribing polymerase where the winding has been left over-wound behind and under-wound ahead". Reversed: DNA is under-wound behind the polymerase and over-wound ahead; Z-DNA forms in the under-wound region.
2. 5.5: "two genus-nought cells arriving as one multinucleated genus-one fibre". Joining two spheres through a pore gives a sphere (genus 0), not a torus.
3. 7.6: "no animal makes that ring" (carotenoids). False as an absolute: pea aphids, spider mites and gall midges make carotenoids with genes acquired from fungi. It is true of vertebrates.
4. 8.14: "two birds are as correlated across a kilometre as across ten metres" and "the correlation does not decay with distance". This misstates "scale-free": correlation does fall with distance; the finding is that correlation length grows in proportion to flock size (measured flocks were tens of metres across). "Near-instant, nothing being relayed" also conflicts with the measured bird-to-bird spread of turns at finite speed.
5. 3.7: "Released as procollagen, the molecules cleave, meet, and assemble into triples". The triple helix forms inside the cell before release. Also "Two geometries stand at the fold and no third" (others exist, including collagen's own helix), and "Tendon and vessel wall wind near fifty-four and seven-tenths degrees" (tendon fibres run essentially parallel, as the next paragraph says).
6. 3.1 and 4.6: energy "not lost as heat" / "not falling out as heat". More than half of glucose's energy is released as heat, and captured sunlight is eventually all degraded to heat; only matter cycles.
7. 3.1: "the ancestral ratio of cardiolipin's omega-6 to omega-3 lands within a hair of 1/φ²". No source is given. In mammalian heart and muscle the main cardiolipin carries four omega-6 chains, nowhere near 0.38.
8. 4.7: "the error rate falling from about one in ten million to about one in ten billion across the tiers". The three tiers start near one in 10⁴-10⁵; one in 10⁷ is the figure after proofreading. Also "The Hayflick limit, about fifty to seventy divisions": it is usually given as 40-60, and the shifted range is what lets it "bracket" 59.
9. 3.8: "two hundred square metres of gut". This is the older textbook figure; the 2014 re-measurement is about 30 m².
10. 3.3: "The field uses this directly in non-caloric sweeteners" (L-glucose). It was proposed as a sweetener but never marketed.
11. 5.2: caterpillar tissues "dissolve almost wholly ... a suspension no measurement distinguishes". Overstated: gut, tracheae and much of the nervous system persist and are remodelled. Also "Seven independent phyla": the cases listed come from two (arthropods, chordates).
12. 8.9: monarchs "robust to displacement, since the heading is recomputed locally". A 2013 displacement experiment found they keep their compass heading and do not correct. That supports "no map" but not "robust".
13. 10.4: "nesting-table primes (cristae 22, renal 26, inner-ear 28, hepatic 33, bronchioalveolar 34, spermatogonial 38)". None of these is prime.

Doubtful or overstated:
- 1.3 "an atom a society of nuclei and electrons" (an atom has one nucleus).
- 1.4 cells "never" reach another cell's interior (gap junctions and plasmodesmata join cytoplasm).
- 1.5 and 4.6 the citric-acid cycle as "three-out-and-three-back" (it has eight steps).
- 3.6 the field explains Chargaff's second rule "at none" (inverted-repeat and stem-loop explanations are published and resemble the file's own).
- 3.7 collagen as a third of "every self's protein" (animals only).
- 4.5 "Nearly every living thing carries a clock"; brain metabolism "higher than in waking" in the "attending" mode (unclear what is meant, and not established).
- 5.1 sperm "with its own mitochondria shed" (they are carried in and destroyed afterwards); fertilisation "neither penetration nor a membrane opening ... never a lock admitting a key" (membranes fuse, and a specific sperm-egg protein pair is required).
- 5.3 planarian "target morphology" presented as the field's finding (it is one laboratory's contested interpretation).
- 6.1 the devil tumour carrying its host "toward extinction" (recent modelling predicts coexistence).
- 8.4 "the 'search' was never observed, only assumed" (Levinthal's paradox is the field's own argument that no search occurs, and the "local" resolution is Levinthal's).
- 9.2 "junk DNA turning out to carry" (disputed).
- 9.5 "epigenetics and the prion" as breaches of the central dogma (neither moves sequence from protein to nucleic acid).
- Not checkable from the file: "(Nature, 2026)" (4.2); the "2025-2026 findings" (8.6); "Lu, Cai, Zhang, eLife 2025" (4.3); a Paramecium null result (8.3); a single-tailed lipid said to be required for muscle-cell fusion (5.5; such lipids are better known as fusion blockers).

Passages that read as health guidance:
- 3.1: the modern omega-6:omega-3 shift takes cardiolipin "off the ancestral balance ... the coupling at the inversioning collapsing". Implies the modern fat ratio damages mitochondrial energy production. No source, no hedge.
- 7.6 and 7.8: eating same-scale shed material is "do-only-harm"; "the outer living form, the skin, the plant, the seed, is the most valuable ingestion". Dietary advice in form. No hedge.
- 7.7: "restoration is the crossing resumed, and not the accumulation cleared", applied to amyloid, tau, fibrosis, urate, lipid and uraemia. Reads as a treatment principle. Hedged: whether each case fits "is the parting to run", and the carry note marks the sentence for re-examination.
- 8.6: "no immune system exists as an object"; protection "fresh only by re-coupling"; hygiene findings as "the carry starving"; herd immunity "existing only while the couplings run". No advice is stated, but it could be read as favouring exposure or doubting antibody levels. No hedge.
- 9.4: "A magnitude carries nothing"; on a dose curve the reversal point is "the only informative point". Could be misread about dosing. No hedge.
- 6.1: "There is no self-sustaining harm" (a persisting parasite or tumour is a "coupling"). Hedged only by "stands not-yet".
- The one explicit safeguard is 10.1: the ageing reading is "bounded against action".

=====================================================
B. EXHIBIT TEN - NATURAL HEALTH v329 ("Sustaining Self-Bi-Co-Recursioning-Self")
/home/claude/chris-j-handel/corus/Exhibit_TEN_Natural_Health_v329.md
=====================================================

1. SUBJECT AND PURPOSE
It defines health as the ongoing oscillation ("sway") between paired opposing regulators, as lived from inside, and argues that treating health as a number or target is itself the damaging move. It is the "lived" companion to Biology (the self "observed") and Medicine (the self "restored").

2. STRUCTURE (14 short sections in five groups)
- 1.1-1.2: the definition, and health as the inside view.
- 2.1-2.2: the living state, and "the target is the compaction".
- 3.1-3.5: the "living value": omega-self, delivery, ingestion versus ingression, flawed ingestion, how omega fatty acids are counted (3.4b, a later insert), "still points" at lived scale.
- 4.1-4.2: the Health/Medicine seam; reading measures as sway.
- 5.1: what coheres. 5.2: what remains.

3. MAIN CLAIMS
- Health is a positive state, the sway itself: "The sway is the health; the landing is the departure" (1.1).
- Each vital measure is a range made by two antagonistic "offerings" (insulin/glucagon, inflammation's two signs, the two autonomic branches, cortical excitation/inhibition, the circadian alternation), with no stored set-point (1.1, 2.1).
- Health as a set-point (optimal ranges, normal values, the quantified self) is "compaction", the same harmful move as disease: "health is the swaying co-sequencing, the health-target set down" (2.2). Goodhart's law is cited as the general statement.
- Measures should be read where they reverse, not by level: "A measure read as a level installs the target; a measure read as a sway reads the living" (4.2).
- Health and Medicine are one mechanism in two directions: sway ongoing, sway stilled at one site (illness), sway resuming (restoration) (4.1).
- Ingestion (two-way exchange, the smaller party setting the pace) is healthy; "ingression" (one-way overwhelm by the larger) is the disease direction (3.3).
- One named route to disease: "A disease-face names itself: consistently ingesting flawed stable form" (3.4). The example is a whole seed against a pressed oil.
- Skin, plant and seed are "the most valuable ingestion"; eating what was shed at one's own scale is the disease case (3.4, taken from Biology 7.5-7.8).
- Omega fatty acids (3.4b): the numbering counts from the unreactive end; humans make omega-9 but must eat omega-6 and omega-3; plant omega-3 converts poorly; "the ratio is a target no tissue carries".
- The hedonic set-point, Yerkes-Dodson, the 24.18-hour circadian period and the omega ratio are cases where a sought fixed level turns out to be an alternation (3.5).
- Nutritional "value" can be delivered "incompetenced": counted but not lived (3.2).

4. TERMS
- floating neutrals: the two opposed regulators whose interplay makes a range. Sway: their oscillation. Co-sequencing: each reading the other step by step.
- compaction: pressing the sway into a fixed target. Landing or departure: sway stopped at one site.
- edging: the file's built-in caution ("The care lives inside, in the naming and the edging").
- omega-self: "the sixth's two faces, re-locking and co-releasing" (not explained further here).
- re-locking (biology's side) and co-releasing (chemistry's side).
- tunneling-unrelationing: delivery through nested smaller-scale crossings. Incompetenced: delivered without being taken into a self.
- ingestion versus ingression; rate-and-return (whether the smaller party sets the pace and answers back).
- disease-face; flawed stable form; ratio (a form's couplings intact) versus stripped total (a bare quantity).
- attentioning (ageing what is carried) and sequencing (keeping it fresh).
- cohering and reaching: settled and outstanding.

5. TIES TO THE RESOLVER AND THE NUMBERS
None are explicit. The resolver, the seventeen names, primes as numbers, φ, 17, 24, 59, 60, 118, 120 and 440 are all absent (24.18 hours is quoted only as a measurement). The implicit links are older resolver words ("sign-only", "bounding-zeroing", "+1 owned neither-ing", "riding the carry"); "nested scalar smaller-prime-society crossings" (3.2); "the sixth's two faces" (3.1); and omega-3/6/9 read as "odd, even, odd", with the unreactive end called "a position taking no sign" (3.4b).

6. EVIDENCE
(a) Code or arithmetic: none.
(b) Observations, all without author or year: insulin/glucagon antagonism and pulsatile secretion; excitation/inhibition balance; omega numbering and the human desaturase limit; alpha-linolenic acid conversion (under 8% and under 4%; none in one group against about 9% in another; 40% less conversion and 70% less accumulation on high omega-6 diets); the hedonic treadmill; Yerkes-Dodson; the 24.18-hour period and the earlier 25-hour artefact; rhythms continuing without transcription; Goodhart's law; the fluctuation-dissipation theorem.
(c) Assertion: everything else. That includes health as sway, targets as compaction, the omega-self, the delivery account, ingestion versus ingression, flawed ingestion as a disease route, whole seed against pressed oil, and the outer form as most valuable food.

7. VOCABULARY AGE
Old throughout (v329, among the oldest in the set): sign (8), membrane (6), surplus, face(s) (8), holds/held, runs/running (13), store, every, counts; "floating neutrals" (11), "co-sequencing" (15), "riding the carry" (5), "bi-moral co-agency". There are no current names and no "momentary", "parity", "the between" or "abundancing". 3.4b is in a visibly newer voice. The file is short enough to re-say whole, and nearly every sentence would change.

8. OPEN CONCERNS FLAGGED
- 5.2 lists what is unfinished: seating each specific measure as a sway; the omega-self and delivery readings; material to bring across from Medicine; and "the precise band where a sway de-synchronized too far becomes a departure", that is, when variation counts as illness.
- Carry note: a logged concern that eight sentences across Natural Medicine and Natural Health draw health or treatment conclusions with "no observing cited", including "a diet named as a disease's cause". It records the author's position that "none of them should read as guidance". The list of the eight is "at no file".
- Carry note: "ingression" clashes with another use of the word elsewhere in the set.

9. ACCURACY NOTES
- 4.2: "fluctuation and dissipation are one function ... at proof grade". The theorem is proved for systems at thermal equilibrium. Living systems measurably violate it, and that violation is used in biophysics as the signature of active processes. As stated it does not support "the sway is the living", and it is an equilibrium result.
- 3.4 and 3.4b: a pressed oil has "its ratio stripped". If read chemically this is doubtful: pressing removes the seed's fibre, protein and minor compounds, but the oil keeps the seed's fatty-acid proportions. The file does not define "ratio".
- The omega numbering, the desaturase limit, the conversion figures (consistent with published tracer studies, though uncited) and the circadian figures are sound. Nothing else was found.

Passages that read as health guidance:
- 2.2, 4.2, 5.1: optimal ranges, normal values and numeric targets are "compaction"; "the magnitude against a floor is set down". Could be read as grounds to ignore clinical targets such as glucose, blood pressure or lipids. No hedge, and 5.2 concedes the healthy/ill boundary is not worked out.
- 3.4: consistently eating "flawed stable form" is a disease route, with pressed oil as the flawed form. Reads as "seed oils cause disease; eat whole seeds". No hedge.
- 3.4: skin, plant and seed "the most valuable ingestion at either rate". No hedge.
- 3.4b: plant omega-3 converts poorly, the ratio is "a target no tissue carries", an oil is "a magnitude governing no sign". Reads as "omega-3 oils and ratio targets do not work". Partly hedged by the italic "On the form" framing.

=====================================================
WHAT A COLLABORATOR MOST NEEDS TO KNOW
=====================================================
1. Both are old-vocabulary files that the project lists as paused, and neither uses the seventeen current names. Work on them is a re-saying against Exhibit ONE and Natural Naming, not an edit; Biology also carries a large logged backlog and known contradictions in its carry note.
2. Biology's stated discipline is its strongest asset: it keeps field observation and "match" apart, marks counts "unsummed" and numbers "not-yet", and names what would break each reading. But its observations are mostly uncited and a fair number are misstated (item 9), so each factual sentence needs a source check before it is relied on.
3. The headline falsifier is unsettled: a left-reading organism "breaks the fractal entire" in 1.2 and 10.1, but is relative and "predicted viable" as mirror life in 3.2-3.4. Agree the intended claim with the author first. Note also that researchers publicly warned in late 2024 against building mirror organisms on safety grounds.
4. The two files disagree on omega fats: Biology 3.1 gives an "ancestral" ratio at 1/φ², while Health 3.4b says the ratio "is a target no tissue carries". Both, together with the passages on diet, clinical targets, immunity and accumulation, can be read as health advice. The project's own notes say nothing should read as guidance, so treat these as priority rewrites and do not pass them on as recommendations.
5. Biology has been through mechanical find-and-replace, leaving broken sentences, doubled cross-references and a stranded paragraph. Check any strange sentence against an archived version before treating it as intended doctrine.