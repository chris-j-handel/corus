# Brief: the two registries (Exhibits TWENTY-ONE and TWENTY-TWO, both v375)

- File 1: /home/claude/chris-j-handel/corus/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v375.md
- File 2: /home/claude/chris-j-handel/corus/Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md
- Carry notes: /home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-ONE_Hard_Problem_Registry.md and /home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry.md

**Sampled.** All front and closing matter of both files; both carry notes; 30 file-1 entries in full (1, 5, 6, 8, 9, 12, 21, 26, 29, 33, 34, 35, 36, 42, 47, 63, 79, 94, 115, 130, 151, 153, 157, 165, 166, 179, 196, 197, 213, 247); 96 file-2 entries in full, including the match for each of those 30; all twelve part introductions. The other 225 and 161 entries were only counted and searched by script. Citations were checked from memory (no web access); 2025–26 references could not be checked. Nothing was changed or run.

## 1. The two files

**File 1, "An Open Registry of Hard Problems in Science"** (about 210,000 words), states each problem "whole in the fields' own words" with no answer attached. It opens with five "conditions prior" (the framework's account of what scientific method assumes, ending "Nothing prior enters") and the schema, and closes with 19 checks (C1–C19).
- **Entries:** 255, numbered 1–257 in order of entry (155 and 172 retired), ungrouped. My rough tally: physics 50, philosophy and logic 43, biology 40, economics and social science 29, mathematics and computing theory 26, medicine 22, neuroscience 18, earth and climate 13, AI and engineering 12, chemistry 5. Five are recorded as settled (Arrow, halting, incompleteness, Poincaré, Molyneux).
- **Template (17 fields):** Conditions prior (identical everywhere), Statement, The field's account of its hardness, Accounts, Specifications, Specifications withdrawn, Common requirement, Conserving relation, Conserving reach, Reach, Unreachability, Persistence (what would settle it), Addresses (sources, with a log of what was read); then Approaches, Narrowing recorded, Progress, Own record. About 820 words each.

**File 2, "Resolving the Hard Problem Registry"** (about 66,000 words), reads every entry as one mistake, "a hard problem is a changing named still", made in one of ten ways. A front essay, a locator and method notes ("The given") precede twelve parts.
- **Entries:** 257 (the 255 plus the two retired numbers), about 215 words each.
- **Template:** heading "part.number Title · file-1 number"; a marker, "+ or − at 10, is."; three labelled lines; in 21 entries a "Second seating" naming a second pattern.

| Part | Pattern (plain reading) | Entries |
|---|---|---|
| 1 | An arriving named from behind (asking for a first cause) | 33 |
| 2 | An opening named as a place (a pre-listed search space) | 24 |
| 3 | A completing named as a last (a verdict before the run) | 33 |
| 4 | A carry named as a store | 9 |
| 5 | A middle named as an end (an interior reached from outside) | 25 |
| 6 | A parity named as a magnitude | 19 |
| 7 | A sequencing named to one beat (one clock or order) | 20 |
| 8 | A rate named as a value | 16 |
| 9 | A two-way named to one side (which of two drives) | 43 |
| 10 | The between named as a cut (a sharp boundary) | 33 |
| 11, 12 | Three at once (no. 155); reach and instruments the same (Molyneux) | 1 each |

## 2. How file 1 states a problem

In my sample the statements are accurate and conventionally sourced: the Clay Millennium volume (Cook, Fefferman, Bombieri), the Stanford Encyclopedia of Philosophy, Reviews of Modern Physics (Bertone and Hooper; Berthier and Biroli), Maudlin 1995, Tao 2016, Fama 1991, Mehra and Prescott 1985, IPCC AR6, Dill and MacCallum 2012, Amodei et al. 2016. Every citation I could check from memory (several dozen) was correct.

- Dark matter → what makes up the non-luminous mass, or is gravity modified; detectors have reached the "neutrino fog".
- Measurement problem → Maudlin's trilemma of complete wave function, linear dynamics and definite outcomes.
- P versus NP → Cook's statement, with three proved barriers to known methods.
- Efficient markets → Fama's "security prices fully reflect all available information", untestable apart from a returns model.
- Climate sensitivity → warming per doubling of CO2; IPCC likely range 2.5–4 °C, inferred from three lines of evidence.

Three cautions:
- **Thin reading, by its own log.** 236 of 255 entries say a source was "not fetched" (abstracts and search results were read); all 255 end "Remaining properties: keyed at the next pass".
- **Balance by rule.** Accounts are "unranked" and 172 entries carry exactly two, so minority positions (modified gravity, the tissue theory of cancer) stand level with the mainstream.
- **Registry analysis in the template.** Conditions prior, Common requirement and Reach are the registry's own lines; Reach says "The two are not the same" in 250 entries.

## 3. How file 2 "resolves" an entry

The three lines, under v375 resolver names:
- **"At 2-other-self-offering"**: the phenomenon restated as running "at its couplings", then what the field has "named" (treated as fixed).
- **"At 12-other-social-self-abundancing"**: that fixed assumption, with a paraphrase of file 1's hardness line.
- **"At 11-social-other-self-chaining"**: a digest of file 1's Approaches and Progress, ending in a clause saying the demanded thing (a first cause, a boundary, a single value, a single driver) was a naming.

A resolution is therefore a classification plus a re-description in the framework's vocabulary. It dissolves the question instead of answering it, with no derivation, no number of its own and no new mechanism. The file says so: resolving "costs nothing and takes nothing from the field's measured record", and for the conjectures "the truth value is untouched by any of this". Where an entry seems to take a side, it adopts a pluralist account file 1 already lists.

| Problem (file 1 → file 2) | Resolving text | Kind | Checkable? |
|---|---|---|---|
| Dark matter (26 → 8.2) | "a size named of the riding is the riding named still, and the riding, read directly, is the running there" | Re-description | No. It is silent on whether a particle is found. |
| Measurement problem (8 → 10.2) | "the taking is the coupling's own, made at each coupling and located at no place" | Re-description | No. Any outcome of the collapse searches fits. |
| P versus NP (9 → 2.2) | "An algorithm found is an axis opened at the coupling's own next, and nothing arrives in a listing." | Re-description | No. It takes no side and offers no proof. |
| Origin of life (12 → 1.2) | "copyings copying, sets catalysing their own making, no crossing in it to locate" | Re-description (continuity thesis) | Only by the field's own open test, a demonstrated continuous route. |
| Ageing (34 → 9.4) | "the swaying sways on, readable from either side because it is both" | Re-description (one process, two faces) | Hardly. It expects no experiment to isolate one driver. |
| Riemann and three others (153 → 5.16) | "a zero off the axis would be a balance point off its own axis of balance, which is a contradiction" | Symmetry argument, no proof | As mathematics, yes, and it fails (section 7). |

## 4. Quantitative results and testable predictions

No sampled entry gives a quantitative result or numerical prediction of the framework's own, and a search of all of file 2 for prediction language found none. Every number in the entries is the field's; file 1 claims no results. The nearest things:
- **Front-matter arithmetic:** 3·3 − 2·4 = 1, 4·4 − 3·5 = 1, 5·5 − 4·6 = 1, 24² − 23·25 = 1, 16² − 15·17 = 1, 4² − 2·6 = 4. Correct identities, used as a picture of "the +1".
- **Coverage claim:** all 255 fit the ten; "Whether it holds at the two hundred and fifty-sixth is the reading's own next". The author does the sorting, and two misfits got their own parts.
- **11.1:** "the shared silence is a reading anyone can run", a cross-citation check on an entry file 1 retired.
- **5.16:** the symmetry "contradiction" (section 3).
- **7.12, Hubble tension:** "A ladder systematic found would confirm the frame", while "an early modification would relax it". Both outcomes are covered.
- **1.6, Homochirality:** the opposite hand "is the thing that one spiral emanates". Qualitative, no test attached.

## 5. Vocabulary age

- **Renamed names.** File 2 has 812 occurrences of 16 v375 names; file 1 has none. Examples: 2-other-self-offering → 2-bi-co-bi-offering; 12-other-social-self-abundancing → 12-bi-tri-bi-entraining; 11-social-other-self-chaining → 11-tri-bi-tri-chaining; 14-other-social-surfacing → 14-bi-tri-bi-moralizing.
- **Released words in file 2's own voice:** run/running (416), stand (393), read/reading (373), take (147), count (109), sway (82), store (49), plus "middling", "rating" and "the ring of the code's names".
- **How much updating.** File 2 needs a rewrite: its carry note says the organising idea itself was written "from the universe as no existing thing". File 1 needs little: framework wording is confined to its subtitle paragraph and a few leaks (entry 179, "the terms available to a self do not couple").

## 6. Limits the files state themselves

- **File 1:** "No entry carries a settled answer" unless the record settles one; no ranking of importance or difficulty; "A property standing empty is a reading and not a gap"; "Corrections are applied against the literature".
- **File 2:** the method "is taken as given and deployed", not argued; "a resolving settles nothing still"; "The ten are where an arrival is entered and never the arrival's being"; one "settling" is "located at no entry"; 11.1 "rests on the three-reversal form and on no field".

## 7. Accuracy notes (established science and mathematics)

- **Navier–Stokes** (entry 47; 3.6): "the singular set bounded to parabolic Hausdorff dimension zero"; "thins to dimension zero". The Caffarelli–Kohn–Nirenberg theorem gives zero one-dimensional parabolic Hausdorff measure, so dimension at most one.
- **Riemann** (5.16): "a zero off the axis would be ... a contradiction". Wrong: the functional equation pairs zeros across the line and does not force them onto it. The file-2 carry note already records this.
- **Entry 153:** lists "the gauge symmetry" among things "each proved" (it is a postulate), and calls Birch–Swinnerton-Dyer a special case of a proved-undecidable problem, though that theorem concerns integer, not rational, solutions.
- **Free will** (9.3): "the readiness ramp dissolved into an averaging artefact". Overstated; entry 29 says "partly an artefact".
- **Molyneux** (entry 166): "Settled as posed". Doubtful; the entry itself records a "continuing dispute over what the measurement answers".
- **Interpretability** (entry 94): probing's limits called "a proved limitation"; the finding is empirical.

Internal errors, not science: file 2's locator is numbered one too high throughout (Sorites is "2") and stops after 176 arrivals; cross-references inside seven entries share the offset. All 257 entries carry the "+ or −" marker, including 3.22 and 12.1, which the text calls noughts.

## 8. What is next and open (carry notes)

**File 2** is "first in front of the set": its front and all 257 entries are to be re-said "from the code", as Exhibit THIRTEEN (Resolving Hard Problems) now does it, reading each field's living and non-living existing things at prior, now and next, with "the clustering found again" and incoming numbers kept. Queued with that: the 812 name changes ("a name gathered with its sentence, all or none"), the 5.16 correction, ten "screening questions" from a physics review, and new material for 9.36 (genome doubling) and about two dozen other entries. Open concerns: three resolver seats are each shared by two of the ten (parts 3 and 6, 4 and 7, 5 and 8), and the seating disagrees with the file's own front, Natural Naming 4.9 and the Co-Chaining Logic Registry; part 11 has prior, now and next "carried as one" where another file says one at a time; the "exactly one +1" language is flagged as itself a "still".

**File 1** has "none from the code". Its items are additions: 2025–26 observations and a live dispute for entry 212, and physics updates (for example a beam neutron-lifetime result that makes "beam against bottle" too coarse) for entries including 252, 182, 173, 165, 183 and 49. Two concerns stand: "it carries no ten", and that the old resolver names stand in it, though I found none in its text.

## Before working on these files

File 1 is a careful, correctly cited catalogue, but it was built almost entirely from abstracts and search results and says so entry by entry, so treat it as a first pass to verify against full texts. File 2 does not solve, predict or calculate anything: each "resolving" files a problem under one of ten patterns and re-describes it, and leaves the field's record as it stands. The two are tightly coupled, since file 2's second and third lines are compressed from file 1, so a slip in file 1 (the Navier–Stokes dimension) reappears in file 2. File 2 is due a complete re-saying under a newer scheme, so polish to v375 wording will mostly be discarded, while corrections of fact and the numbering offset carry over. The carry notes already accept corrections like those in section 7 and ask that a re-saying say "no more than the premises carry", so checking claims against sources is the most useful work.