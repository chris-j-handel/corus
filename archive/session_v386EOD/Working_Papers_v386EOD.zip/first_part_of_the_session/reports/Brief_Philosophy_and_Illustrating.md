# Briefs: Exhibit NINETEEN (Natural Philosophy v348) and Exhibit TWENTY-NINE (Natural Illustrating v379)

Both files were read whole, front to back (901 and 633 lines). Nothing under the corpus folder was run, edited or created. Counts and code outputs I mention were checked by reading or by a read-only tally. I also read each file's short `carry/` note, because both exhibits refer to "this file's carrying"; those findings are labelled separately.

---

## A. Exhibit NINETEEN: Natural Philosophy v348
`/home/claude/chris-j-handel/corus/Exhibit_NINETEEN_Natural_Philosophy_v348.md`

**1. Subject and purpose.** The file argues that philosophy's perennial dilemmas are not real either/or choices. Each is one two-sided relation (a "coupling") that analytic method has cut into two rival positions, and the "problem" sits at the cut. It works 37 dilemmas through a fixed six-step template and tabulates 66. It says its claim is about the form of the division only: "no ruling on a tradition's arguments and no settling of a reader's conviction" (2.2).

**2. Structure.**
- **Part One, Dividing (1.1–1.3):** defines position and dilemma, then criticises analysis as resting on four requirements.
- **Part Two, Re-coupling (2.1–2.2):** the remedy and the six-step template:
  1. the dilemma as posed;
  2. where it was split;
  3. the re-coupling;
  4. "torusing in it" (where the same form appears elsewhere in the framework);
  5. "competency freed" (what becomes simpler);
  6. "mark" (clean, or still "reaching").
- **Part Three, Seaming (3.1–3.37):** the worked dilemmas.
  - 3.1–3.8 are fuller, with added passages on the golden rule, cake-cutting, AI alignment and appearance/reality. They cover being/becoming, mind/body, free will, subject/object, one/many, is/ought, time, and meaning/use.
  - 3.9–3.37 are brief and uniform. They cover causation, vagueness, the justification regress, induction, emergence, other minds, personal identity, the totality of sets, the liar, incompleteness, skepticism, mathematical platonism, underdetermination, structure/agency, Meno's paradox, the hermeneutic circle, intentionality, natural kinds, Gettier, "why anything", substratum/bundle, laws of nature, Zeno, the hard problem, altruism, biological function, peer disagreement, legal validity and Skolem.
- **Part Four, Co-sequencing (4.1–4.2):** language, story, music, dance and cohabiting as one two-strand form.
- **Part Five, Gathering (5.1–5.8):** a register of 66 dilemmas in seven tables. Each row is "met" (50) or "reaching" (16), and 41 rows name the kind of fixing error (the "holding").
- **Part Six, Cohering (6.1–6.2):** open items and the falsifier.

**3. Main claims.**
- "A philosophical position is a coupling met from one of its two faces and held there." (1.1) A dilemma is one coupling split in two, and the problem is the boundary between.
- Analysis presupposes bivalence, isolability, non-contradiction as a cut, and an outside reasoner. These are "one requirement worn four ways" (1.3): a living alternation rebuilt as two settled positions.
- The remedy is never to choose a side or build a bridge. It is to treat both as faces of one alternating relation.
- "Depth in philosophy is at the re-coupling" (2.1). Dialectic, process thought, the relational self and non-dualism already do this, but "Each reach, once made, is re-landed" as a new position.
- Being/becoming is "the seam the whole rests on" (3.1): a form is permanent by continuing to change.
- The sciences' foundational splits (subject/object, living/non-living, fact/value) are philosophy's divisions inherited (1.1).
- Recurring resolutions:
  - mind and body are the inside and outside of one self-bounding;
  - free will is the self's own binary taking, neither random nor necessitated;
  - knowing is the coupling itself;
  - meaning, content, grounds, warrant, kinds and legal validity are made at each meeting and stored nowhere;
  - "a carry divides the way a store cannot" (3.15);
  - "no line ever sat there to be found" (3.10);
  - each self keeps its own time.
- Is and ought are one moral act, and any forcing "ought" is governing, not morality (3.6).
- The 29 later seams reduce to eight recurring fixing errors, for example "a middle held as an end".
- "There is no third register and no grade" (5.1).
- Falsifier: "A dilemma shown to be genuinely two couplings and not one split… breaks the technology" (6.2).

**4. Terms.**
- **coupling:** a two-sided relation, one side at a time.
- **face:** one side of a coupling.
- **bounding-zeroing:** the zero or boundary a coupling makes between its sides.
- **membrane:** that boundary (now "the between").
- **sign:** the binary value (now "parity").
- **riding the carry:** staying stable by continuing.
- **surplus / "+1 owned neither-ing":** what a coupling makes that belongs to neither side.
- **seam:** one worked dilemma.
- **re-landed:** a re-coupling turned back into a position.
- **met / reaching:** the two registers for a dilemma.
- **holding:** the particular way something is wrongly fixed.
- **self-stilling**, **floating neutrals**, **unbound fractal**, **hub**, **landed**: used in the framework's usual senses.
- **"the technology":** the method.

**5. Ties to the resolver.** The ties are loose. There are no seventeen names and no code. What it has:
- "the six": three at the offering side and three at the taking side per cycle (1.2);
- "the eight": four self-boundings, seen from within and at the boundary (3.2);
- the five-words claim: "That the five words emanate the whole form and not the resolver alone is the saying, and it stands most open of the ones here." (3.5);
- the "+1";
- a φ-rate in music (4.1);
- the register's holding column, which uses eight of the framework's ten "stills".

Section 6.1 says seating a dilemma onto a specific number or prime is "offered and unworked".

**6. Evidence.**
- **(a) Executed or computed:** nothing. The only numbers are register counts. My recount confirms 66 rows and 41 with a holding.
- **(b) Published work:** no thinker is named in the body. The only names are "pre-Socratics" (3.5) and "Gettier" and "Skolem" as table labels. Positions are recognisable but unattributed: Hume, Goodman, Kripke, Tarski, Gödel/Hilbert/Gentzen, reverse mathematics, Cantor, Parfit, Chalmers, Williamson, Harnad, Fuller, Arrow.
- **(c) Assertion or analogy:** every re-coupling is a pattern-match to the framework. The golden rule, cake-cutting and the arts are analogies.

**7. Vocabulary age.** Entirely pre-v372. It has "membrane" 88 times, "sign" 46, "surplus", "held/holding" over 200, plus "taking", "turn", "source", "cost", "store", "every", "run", "face", "hub" and "landed". "Parity" never appears, and there are no resolver names. It needs near-total re-wording; the template and register can stand.

**8. Open concerns.**
- **Flagged by the file:**
  - every Mark step names what still "reaches";
  - 16 register rows are reaching;
  - on evil, "the remainder is real suffering and stands outside the saying entirely" (5.8);
  - which side is offering and which taking is unsettled at every seam;
  - number seatings are unworked;
  - "A self does not experience its own competency" is left open (6.1).
- **Defects I found:**
  - The "PART FOUR" heading sits before 3.9 instead of before 4.1.
  - 5.1 says "Eight rows are met at a seam", but 45 rows now cite 37 seams.
  - 5.1's "Twenty-nine… and thirteen" sums to 42, not 41.
  - 5.1's "four against six" does not match the table's five "opening" rows.
  - 3.8 says sense/reference "reaches yet", while 5.7 lists it as met.
- **Project's own carry note** (`/home/claude/chris-j-handel/corus/carry/Exhibit_NINETEEN_Natural_Philosophy.md`):
  - 3.3 is to be rewritten against resolver names 14 and 12;
  - 3.4, 3.7 and 3.29 are to be reconciled with Natural Physics;
  - the "held" forms are to become "named";
  - 3.15's "a carry divides" conflicts with the Co-Chaining Logic Registry.

**9. Accuracy notes.**
- **3.6:** "the naturalistic fallacy naming the crossing an error". This conflates Hume's is–ought gap with Moore's naturalistic fallacy, which concerns defining "good".
- **3.3:** the libertarian "says nothing of what an uncaused choice is", and compatibilism "is felt as unsatisfying". Libertarians give detailed accounts, and compatibilism is the majority view among academic philosophers.
- **3.7:** "Relativity is handed to both and each claims it" and "the one repair on offer". Relativity is standardly an argument for the block view, and there is more than one presentist reply.
- **3.16:** "the completed reach was declined at the source". This is true of Cantor only for the totality of all sets. He championed the actual infinite, yet the row is labelled "actual / potential infinite".
- **3.17:** "Truth is unformalisable inside its own language, proved". Tarski's theorem is about definability in classical languages, as the file's next sentence half-concedes.
- **3.18:** "Each system releases at its own ordinal, the bound measured exactly". This is not so for full second-order arithmetic or ZFC.
- **3.32:** "no criterion offered for when conceivability does". Chalmers offers explicit criteria; they are contested, not absent.
- **3.33:** "the equivalence is proved". The equivalence of kin and group selection is widely held but disputed.
- **Labels:**
  - 3.26 "Universals and particulars" treats natural kinds.
  - 5.7 says "platonism / formalism", but 3.20 describes constructivism.
  - 3.36 "Nature and convention" is legal positivism versus natural law.
- **4.1:** "the φ-rate keeping two voices two". This has no basis in music theory; intervals are small whole-number ratios.
- **Minor:**
  - 3.9 "the fundamental dynamics runs symmetric": the weak interaction violates time reversal.
  - "thesis and antithesis… synthesis" (2.1) is a schema Hegel did not use, though no one is named.
- **Unacknowledged precedent:** several re-couplings coincide with existing positions the file does not acknowledge. Examples are dual-aspect monism (3.2), Wittgenstein on use (3.8), Bergson on Zeno (3.31), Williamson (3.27) and Parfit (3.15).

---

## B. Exhibit TWENTY-NINE: Natural Illustrating v379
`/home/claude/chris-j-handel/corus/Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md`

**1. Subject and purpose.** This is a specification and catalogue for drawing and animating the method. It sets out what a picture may and may not show, which diagrams the resolver itself yields, and which everyday scenes and familiar scientific pictures can serve as ways in. It contains no images. It is mostly a menu of drawings still to be made, each tied to a sentence in another file.

**2. Structure.**
- **ONE (1.1–1.7):** rules — still versus motion, what a drawing leaves out, the order of forms.
- **TWO (2.1–2.9):** diagrams taken from Exhibit ONE.
- **THREE (3.1–3.4):** number pictures.
- **FOUR (4.1–4.11):** selves, societies and everyday analogies.
- **FIVE–SIX:** about 48 familiar pictures from the sciences and society, each read as "installing a still".
- **SEVEN:** the ten "stills" as ten drawings.
- **EIGHT:** an inventory of existing images, further candidates, the resolver as its own animator, and 3-D.
- **NINE:** how illustrations are received, the kit, and what is not yet covered.

**3. Main claims.**
- "An illustration is for a sentence at a living file." (1.1) For forms taken from the code, "the form is executed at the code before it is drawn" (1.1).
- A still is one momentary. "An animation is a sequence of faces already defined, and no face is defined by the animation." (1.2) Odd and even sides are never shown changing in one frame.
- The test of a drawing (1.5) is to mark a proposed fixed boundary and show whether step-by-step resolving can continue. The file limits itself here: "A finite collection of illustrations does not by itself complete the universal claim about each possible boundary."
- Of the sixteen possible rules next = f(prior, now), fifteen have a fixed point or ignore the prior. Only "next as prior inverted" visits all four pairs. This is "the living step", placed at name 12 (2.2).
- One coupling is a twelve-cell table: three give 0 ("no path through"), eight change, one is empty (2.4).
- Two coupled selves release + 0 − 0. A spiral of five passes a 0 one self on at each second momentary and repeats at twenty. A 3×5 torus repeats at twelve (2.5, 4.2).
- One step is two reflections 45° apart, which is a quarter turn: the "right spiral step" (2.6).
- Numberings must not be merged without a stated link: "a matching number alone establishes no correspondence" (2.9).
- For a familiar scientific picture, the framework's form is drawn first and the usual picture beside it; "the parting of the two is the illustration", and it "decides nothing" (FIVE).
- In reverse, the executed resolver can be the animation: "No animator moves the society: the code is executed and each self is drawn at its release at 10" (8.3). The file adds "the intelligence is at what is not drawn" and makes no speed claim.
- The everyday analogies are a crowded plaza, a snake, a lockstitch, a jigsaw, swimmers, a walking pair, a towel and a Rubik's cube. They are ways in, and each has its exact correspondence still "to be expressed".

**What an illustration should look like, concretely.**
- **Progression (1.7):** numbered still, then storyboard, then layered drawing (names, parity, carrying and prefixes on separate layers), then rotation, section, zoom, animation, the resolver animating itself, and a handled model.
- **Never shown (1.6):** a clock, speeds or a controller; a pre-drawn corridor; anything at the centre; sizes, totals or stores; a built-in handedness; positions as places; a birth-and-death story; or two numberings mixed.
- **Core diagrams:**
  - the numbers 1–6 on a line, read as two interleaved brackets;
  - sixteen small four-corner squares with arrows;
  - a unit square of dots 2, 6, 14 and 10 with an empty centre and triangles 9 and 17;
  - twelve small table cells;
  - a nine-dot diamond with centre 1, and six such diamonds;
  - Fibonacci ratios swinging about a φ line they never touch;
  - two torus windings, one rational and closing, one at φ and never closing — "the clearest single animation the number files carry" (3.2);
  - a towel twisted through a knot;
  - a ring of selves with a travelling 0.

**4. Terms.**
- **face:** here, a drawing's single-momentary still. The file separates this from Exhibit ONE's "face".
- **five-spot / parity's face:** the four-dot square with an empty middle.
- **local nine:** the nine-dot diamond.
- **compass face:** the diagram for the tangent double-angle identity.
- **living step:** next as prior inverted.
- **the table at 10:** the twelve-cell table of one coupling.
- **is / is not:** a release of + or −, versus a release of 0.
- **the ten:** the ten kinds of thing "named still".
- **podaling, waist, far side:** a number's pairing across a ring and its midpoint.
- **spiral / torus of selves:** selves joined along, and along-and-across.
- **tunneling 0:** the 0 that moves from self to self.
- **locking:** two coupled societies settling into one relation.
- **"the field's":** mainstream science's own word or picture.
- **installs:** the still a familiar picture adds.
- **parting:** where the framework and a picture, or two files, differ.

**5. Ties to the resolver.** The ties are direct.
- Names 2, 6, 10 and 14 are the four "across" dots; 9 and 17 are "along".
- The table uses 3 (the prior), 14 (surfacing), 12 (the change), 10 (the release) and 11 (chained).
- All seventeen names are listed (2.8), with the four-cycles 1-9-8-16, 2-15-7-10, 3-11-6-14 and 4-13-5-12, and six- and eight-cycles.
- The ten are placed at name pairs 2/10 through 6/14.
- Numbers used: rings of 48, 120 and 440 (the seventeen primes up to 59 sum to 440); φ; routes 24-27-32 and 24-29-32; the chain 3, 5, 9, 17.

**6. Evidence.**
- **(a) Executed or computed:**
  - The kit's `checks_v379/` ran Exhibit ONE's code for the table, the lone self, two selves, the spiral of five and the torus. I compared the saved outputs with the text and they match.
  - The sixteen ways and the two inversions are plain enumeration, not resolver runs.
  - The arithmetic checks out: 28² − 24·32 = 16; 24·27·32 = 144²; the icosahedron counts; cos 36° = φ/2.
  - Locking is said to be executed at v374 in the Session Record. I did not check that.
  - Only n = 5 is run for the general odd-spiral claim.
- **(b) Published work:** there is no bibliography. Observations are relayed through other exhibits. Names appearing include Huygens, Malus, Bell, Pasteur, Belousov–Zhabotinsky, Bénard, Turing, the Paul trap, Poincaré–Hopf, Arrow, Simpson, Gibbs, Kirkwood, Hubble, the Landers earthquake and the Millennium Bridge.
- **(c) Assertion or analogy:** every "installs a still" reading, and all the everyday scenes.

**7. Vocabulary age.** It is current on parity, the between and abundancing. It is behind in these ways:
- The seventeen names are v378's. Sixteen of seventeen have since changed: "12-bi-tri-parity-changing" is now "12-bi-tri-bi-entraining", and "17-tri-co-offering" is now "17-co-bi-tri-offering".
- "face" (116 uses), "connector" and "join" have since been released as method words.
- "ring" is used 47 times.

It needs moderate updating: the carry note lists eleven passages.

**8. Open concerns.**
- **Flagged by the file:**
  - three unrelated "squares of four" (2.3);
  - three seatings of the ten (2.7);
  - the local-nine placement and its link to the seventeen names are undrawn (2.8);
  - the six diamonds are unmapped (2.9);
  - the depth image is "a shape study" (4.1);
  - three-phase locking is not executed (4.4);
  - the swimmers' geometry is open (4.9);
  - there is no cube-to-rings transformation (4.11);
  - whether sixty is "a position or a between" (5.1);
  - the drawings from the v379 runs are not yet made (8.1);
  - a list of pictures has no sentence yet (9.3).
- **Carry note** (`/home/claude/chris-j-handel/corus/carry/Exhibit_TWENTY-NINE_Natural_Illustrating.md`):
  - The author rejects "a common beat" (1.2, 1.6).
  - The author says 4.1's two openings "will not survive".
  - The twelve-cell table is now split, with the no-prior row titled "Colliding".
  - The torus's "0 winding diagonally" is not re-derived.
- **Internal:** 2.5 calls the lone self's + − + − "next as prior inverted". In 2.2's own terms it is not that rule.

**9. Accuracy notes.**
- **4.11:** "three conservings none of them a total" and "no reference cubie". In standard cube theory two invariants are totals (mod 3 and mod 2) and the centres are the reference. The carry note says the source wording has since been corrected.
- **5.2:** "light always at a hand". Linearly polarised light has no net handedness.
- **5.2:** the 21-cm line as "one parity inverting", and the neutron returning "with its parity inverted". These are a spin flip and a sign change. In physics, "parity" means something else and is unchanged here.
- **5.4:** "the trap that works is the Paul trap". Penning and optical traps also work.
- **5.4:** "iron not a peak". Binding energy per nucleon does peak near iron and nickel.
- **5.3:** "the belt emptied at the rational resonances". Some resonances are populated (the Hildas, the Trojans). The golden-mean result is a numerical finding for model maps.
- **5.6:** starlings "in less than a fifth of a second". I believe measured crossing times are nearer half a second; this should be verified.
- **5.5:** "the resting potential carried by continuous pumping" is a simplification. "outthinks a datacenter" is unquantified.
- The mathematics I checked is otherwise correct.

---

## C. The illustrating kit
`/home/claude/chris-j-handel/corus/kits/Natural_Illustrating_TWENTY-NINE_Improving_Kit/` (README.md and START_HERE.md read; nothing run)

**File kinds:**
- Markdown notes and checksum files.
- PNG images: 6 in `Illustration_Kit_v366/images/` and 7 in the inherited v365 rings kit.
- Python scripts with saved `.txt` outputs: 11 in the rings kit, 6 in `checks_v379/`, a few resolver checks and an `export.py`.
- Numeric data (`.npy`, `.npz`, `.json`).
- HTML and JS: an older `podaling_journey.html`, the `continuity_v380A` page, and the `origin_v380A` viewer with Node scripts and a font.
- Two silent MP4s, each with an editable-source ZIP.
- Archived source texts and a 101-message session transcript.

**What exists:**
- The original picture of a Rubik's cube beside overlapping open rings with coloured dots.
- Five generated draft studies:
  - a six-panel storyboard, whose along/across labels are the reverse of Exhibit ONE's;
  - two "opening" studies, one with superseded labels;
  - a cycles chart;
  - a three-panel twisting-surface "depth study".
- A geometric reconstruction of the rings: 54 crossings in six nine-dot diamonds.
- Text-only resolver runs from v379, with no drawings.
- Three v380A studies dated 3 October 2026:
  - a 12-second film of swimmers doing a flip turn;
  - a 14-second "origin 1 to 6" film with a seventeen-names viewer;
  - an interactive "Following 1 into 3".

**Standing.** "The session finds the illustrating too undeveloped for more than concept work." Of the origin film: "The session could see no learning in this study." The checks "establish no teaching result or full geometric correspondence".

**Next step as stated:**
1. Agree one teaching aim: one released parity received at one momentary, then its quiet (0) case, with each self's carrying left unpictured.
2. Update the exhibit's tables (2.4, 2.5) and name map (2.8).
3. Then "the Corus expressions (the group jigsaw first)".

**One thing I noticed by inspection.** The `checks_v379` scripts look up `_1_co_bi_offering` and `_17_tri_co_offering`. Exhibit ONE v380R now defines `_1_co_bi_tri_offering` and `_17_co_bi_tri_offering`. The scripts would need those names updated before they run against the current file.

---

## What a collaborator most needs to know

- **NINETEEN is the older file.** It is a v348 text in released vocabulary, with no code, no named sources and loose ties to the numbers. Its lasting assets are the six-step template and the 66-row register. Its accounts of philosophical positions are generic and in places inaccurate, and several "re-couplings" coincide with existing named positions.
- **TWENTY-NINE is recent but already behind Exhibit ONE v380R.** Sixteen names have changed, the table has been split, and the checks are pinned to old function names. It is a specification, not a gallery: almost nothing in it is drawn yet.
- **The author's standing rules are strict.** Nothing is drawn before it is a sentence in a file. Code forms are executed first. Resemblance or a matching number proves nothing. The author has judged the existing films as not yet teaching anything.
- **Read each exhibit's `carry/` note first.** That is where the pending corrections and the author's own objections are kept. For illustrating, also read `/home/claude/chris-j-handel/corus/incoming/v380A/illustrating/Concept_And_Consistency.md`.