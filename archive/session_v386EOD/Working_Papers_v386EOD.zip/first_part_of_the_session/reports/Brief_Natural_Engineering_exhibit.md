## Brief: Exhibit FIVE, Natural Engineering (v345a)

Read in full, front to back: `/home/claude/chris-j-handel/corus/Exhibit_FIVE_Natural_Engineering_v345a.md` (1,927 lines, about 38,000 words, 52 sections, 81 tables, 104 distinct links). Context file read: `/home/claude/chris-j-handel/corus/carry/Exhibit_FIVE_Natural_Engineering.md`. Nothing was written, run or fetched; "checked" below means checked against my own knowledge and arithmetic.

### 1. Subject and purpose
The file applies the framework to engineered systems. It proposes that good design lets two coupled sides alternately offer and receive a direction-only signal, each at its own pace and within its own limits. Engineering losses are to be examined as traces of one side imposing its terms on the other. In practice it is a casebook of about thirty-five technologies, each written up in a fixed five-line form that separates what published sources show from what the framework proposes.

### 2. Structure
- **Part One (1.1–1.16):** core vocabulary and a map from Natural Numbers, then cases: power grid, a balanced-ternary chip, the network (including the site's own file listing), antennas, robot limbs, swarms, tuning by beats, fusion confinement, heat exchange.
- **Part Two (2.1–2.7):** the method (2.1), then language models, fluidic, chemical, silicon and magnetic oscillators, quantum computing, public-key cryptography.
- **Part Three (3.1–3.2):** biosphere heat, flow batteries, chemiosmosis, a proposed nuclear cycle.
- **Part Four (4.1–4.12):** crossings; how the resolver code handles signs, carrying and zero (4.2, 4.10, 4.12); sensing; safety-reporting systems; the hardware–person "bi-coupler"; recovery.
- **Part Five (5.1–5.4):** the five-line entry form, which is the core method; a long desalination case; engineering "hard problems" indexed to Exhibits 21, 22 and 13.
- **Part Six (6.1–6.11):** a five-mark "signature"; rockets, pumps, wave power, electrolysis, energy storage; Landauer and Bennett; biomedical stimulation; superconducting circuits with the 440 arithmetic; transformer-efficiency methods.

### 3. Main claims
- **Design principle:** "In disequilibria, alternating is a stable-forming method." (1.1) "Natural engineering" is "floating neutralling": the zero between two sides moves with their exchange and is not a fixed reference.
- **Diagnosis:** loss traces to "one side taking both turns": "One side's magnitude stands for the other's sign; one pace stands for the other's rate" (5.1).
- **No diagnosis by keyword:** "Setpoint, clock, ground and controller remain the field's own names at their particular arrangements." (5.1)
- **Method:** the five-line entry.
  - Arrangement and goal.
  - The suspected imposed term (the "holding").
  - Residue, with units.
  - An observation of the same service with that term removed.
  - The arrangement offered, with what would break it.
  - Unfilled lines stay visibly unfilled ("So-far carries with not-yet", 5.1).
- **"Whole load surfacing":** model every supply, load and return from the outset. "A receiving carried only as a prescribed demand still needs its own offering expressed." (1.1)
- **Removing a part is not releasing a holding:** "A control's removal leaves the changed arrangement and that function's continuing to express." (4.4)
- **Direction, not size:** a sign gives direction only, and search proceeds by repeated direction-only exchanges (Marco Polo, 2.1; tuning by beats, 1.12).
- **Counts, names and shapes do not transfer:** "a shared count supplies no physical gain or completed design" (6.9).
- **The resolver supplies sign and carrying rules only:** "The absence of a central network command does not make an implementation's timing or memory disappear." (1.7)
- **Code has no authority:** "Running and recording supply no authority over nature or the Numbers–Mathematics explaining." (1.1)
- **Conventional accounts stand:** "Zero in a balanced current sum supplies no additional energy to recover." (4.3) "Dissolving that mechanism does not dissolve the measured heat." (3.1)
- **Three phase-offset units do not guarantee steady output:** the file builds its own counterexample (5.3) and notes that two phases in quadrature also give constant power (4.9).
- **The coupling's surplus is not a quantity:** it belongs to neither side and "carries neither a stored amount nor a score" (1.2).
- **Engineering puzzles are filed under standard misreadings (5.4):** benchmarks, alignment, technical debt, Brooks's law, halting, credit assignment.

### 4. Terms
- **Floating neutral / bounding-zeroing:** the moving zero made by the exchange; each side sets its own limit.
- **Bi-moral (binary) co-agency:** two-way, sign-only, one-at-a-time exchange.
- **Co-offering, co-competencing, co-intelligencing:** the exchange, its jointly owned surplus ("the +1"), and the understanding arising from it; said to be inseparable.
- **Bettering, fastering, cheapering:** the ordinary performance, speed and cost comparison, always at the same service.
- **Holding / incompetencing:** an imposed value, schedule or reference standing in for the other side's response. Value, time and potential are its three kinds; "value-pinning" is a rate held to a value.
- **Residue:** the field's loss words (waste heat, drift, ripple), treated as pointers to a coupling.
- **Co-releasing:** each side dropping its own imposed term.
- **Finding, meeting, following, abundancing:** the four method steps.
- **Transmissioning:** "two staying and one crossing", with a crossing coefficient of two (imposed), one (offered) or zero (absent).
- **Sensing / sensationing:** receiving a change, and offering a sign back.
- **Bi-coupler:** a hardware–person connector with four properties (coupling; receiving and offering; beat between; surround and capture).
- **Bi-co-podaling:** the two path lengths k and N − k to one ring station.
- **Outcome versus carry technology:** a finished result versus what continues into the next exchange.

### 5. Ties to the resolver and the numbers
- **Resolver:** the file never uses the seventeen names. It describes the pre-v372 code.
  - One function takes `co_carrying` and `bi_arriving` and returns surfacing and carrying.
  - Carrying is a tuple (key, corusing, torusing, inseparating) with a limit at four.
  - Operations are `bi_co_inversioning`, `bi_co_tunneling`, `bi_co_surfacing`, `co_bi_carrying`.
  - It speaks of "ONE's ten co-changings" and prefix depths 1, 2, 3, 2, 2, 2, 1.
  - These appear in 2.4, 4.2, 4.10, 4.12 and 6.1. Sections 1.7 and 2.5 treat a clockless balanced-ternary chip as the resolver's hardware form.
- **Numbers:** 440 is "seventeen primes, sixteen crossings". The first seventeen primes do sum to 440 (my check). Also 73 = (59 − 2) + 16, 146 = 2 × 73, 438 = 3 × 146, 360 = 8 × C(10,2), 440 − 360 = 80. All the arithmetic is correct.
- **Status of the mapping:** the engineering correspondence "remains open" (1.2), and the file refuses numerology: "440 Hz in this example names a frequency" (1.12).

### 6. Evidence
**(a) Executed or tested, as the file reports.** The file contains no code blocks, only inline names. All resolver items concern the old code.
- Resolver calls with carrying (0, 1, m, 3) and arriving (0, 1) for m = 1, 7 and −1: the first call surfaces zero; the carrying survives for 1 and 7 and is dropped for −1 (4.2, "ONE's unchanged code").
- Input/output tables derived from the code's clauses: two +1 arrivals at one key surface +1 together, but +1 then 0 when fed in successive calls (4.10).
- A bug in the v333 networking test kit: a completed meeting was returned twice, and reusing its slot altered an earlier return (1.8).
- A run of the site's file selector returned thirty filenames matching `files.json` (1.8).
- Hand calculations: beat tables, closure phase, heat-exchanger effectiveness, a resistor pulsing example, a pumped-hydro model.

**(b) Literature.** Sources are summarised narrowly and, where I could check, accurately. Five are cited at abstract level only (Elbel and Hrnjak, Sakata, Järvinen, Brittain, GPTQ). Examples:
- Seo et al. and Lu et al. on oscillator-controlled inverters; ENTSO-E on the 8 January 2021 grid split.
- Pratt and Williamson; McGeer; Rubenstein et al.; Brooks.
- Vaswani et al.; Shor; Google Quantum AI (2024); NIST FIPS 203 and 205.
- Racker and Stoeckenius; Landauer; Bennett; Onsager.
- Haddad et al. on desalination; Chapman et al. on circulators; SparseGPT and FlashAttention.

**(c) Assertion or analogy only.** Every framework-level claim: that an imposed term causes the residue, that releasing it improves the service, the sign-only connector, the 440 mapping onto hardware, the nuclear cycle, the hard-problem classifications. In nearly every entry the line for "same service with the holding released" is marked unfilled or "not located".

### 7. Vocabulary age
Heavily pre-release.
- "Sign" appears 185 times against "parity" twice; "membrane" 36 times and "the between" never.
- Also present: surplus, ring (26), loop, connector (37), holding/held (121), turn (83), source (115), count (89), taking, every, cost, run.
- Section 5.4 uses the old "held" forms ("a bound held as a last") and v344 section numbers.

It needs a full vocabulary pass and every code sentence re-derived against the current resolver. The cited engineering content should survive largely intact.

### 8. Gaps the file flags
- The 440 mapping onto engineering: "the full consecutive construction remains open" (1.2).
- Grid: the cost attributable to the frequency reference "is unfilled", and there is no same-service comparison (1.3, 1.4).
- No silicon build (1.7); the receipt-identity repair is pending (1.8, 2.5).
- "No continuously returning nuclear design is described here." (3.2)
- No released-holding record was found for the crystalliser (4.5), thermoelectric (6.8), SQUID or circulator (6.9) entries.
- Discrepancies the file found in its desalination sources (5.3): 9.7 against a printed 9.1 kWh/m³; membrane element counts apparently swapped; identical product analyses in two papers.
- Jevons paradox and moral hazard have no registry entry (5.4).
- Detailed traces are said to sit in "Living Improving Value" (the project's carry file), not here.

### 9. Accuracy notes
**Established engineering and science: none found wrong.** The phasor, power, beat, Pythagorean-comma, closure-phase, heat-exchanger, throttling, Landauer, Onsager/Kelvin, fluxoid/Josephson, Arrow, Shor and FIPS statements all hold.

Worth re-checking against the sources:
- "TDS of 264 mg/L and conductivity of 2 µS/cm" (5.3) is an odd pairing for dissolved salts.
- "Three stations, three baselines and four station gains" (1.9) mixes the three-station and four-station constructions.
- The "2026 NAN-C trial" (6.7) and figure-level numbers generally could not be verified offline.
- Several links point to informal mirrors.

**Design and safety, flagged separately:**
- **Grid:** the text contemplates releasing a nominal frequency reference and speaks of a "floating neutral", which in power practice is a fault condition. The hedges are explicit: "The identity alone specifies no change to an earth connection or a protection arrangement." (1.3); "phasor arithmetic and ONE's running supply no physical safety identity" (3.2).
- **Controls:** removing controllers, setpoints or clocks is framed as the "improving opportunity" (2.1), always hedged by the same-service requirement.
- **Biomedical (4.3, 6.7):** defibrillation, ventilation, tremor stimulation, hormone pulsing and light dosing are cited as precedents for a person–hardware connector. No protocol is recommended, and benefit is said to remain unshown.
- **Cryptography (2.7):** no privacy or key-recovery result is claimed: "Calling the public key forward and the private key back supplies no calculation for recovering either from the other."
- **Desalination (5.3):** a specific process is sketched; untested constituents are explicitly not assumed absent.

### Carry file: next and open
Next is rewriting the code sentences once the networking kit's engine is replaced by the v372 code.

Queued additions (seven):
- A "resolver chat" demonstration run on the v373 code, with rings of selves carrying 504 parity patterns.
- A sensor/"sensationer" reading using event cameras, synchronism-check relays and DRAM refresh, which includes a design reading ("sense the dwell before a lock").
- Renaming the ten "named still" at 23 places.
- A rule that any count enters with its script (a quoted "442 of 500" re-ran as 341).
- An outside engineering review supplying records on handshakes, clock-domain crossing, anti-windup and ground return paths, plus its correction that engineering accounts certify "no social protection".
- Robotics accounts from v379.

Open concerns (four):
- 26 "ring" passages to become "spiral".
- Old code names at 4.2, 4.10, 4.12 and 6.1.
- A cross-file conflict over whether co-competencing can be stored or scored.
- Four robotics distinctions.

### What a collaborator most needs to know
This is the set's largest conventional-engineering casebook and its most cautious file: it reports mainstream sources accurately and marks the framework's own proposals as unbuilt and unobserved. Its vocabulary and every statement about the resolver predate the v372 rewrite. The carry file says the current code has "no second sign and no bound", so some code sentences have nothing left to describe and need re-execution, not relabelling. The five-line entry form in 5.1 is the part to preserve, because it is what makes the file checkable. Any rewrite must keep the safety hedges on grid earthing and protection, medical devices and cryptography, which a vocabulary pass could easily strip.