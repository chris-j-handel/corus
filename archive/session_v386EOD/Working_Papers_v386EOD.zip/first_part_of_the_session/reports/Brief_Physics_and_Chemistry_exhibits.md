Both exhibits and the Physics carry file were read whole, front to back; nothing under the corus directory was changed and no script there was run. I also read, for context only, the Chemistry carry file, the kit's released-word list and two review notes in `incoming/`. I had no web access, so accuracy notes rest on my own knowledge.

# 1. Natural Physics

`/home/claude/chris-j-handel/corus/Exhibit_EIGHTEEN_Natural_Physics_v379.md` (about 22,000 words, 5 parts, 40 sections)

**1. Subject and purpose**

The framework applied to physics. It claims every physical observation is one local, binary, one-way-at-a-time "coupling". It says physics' open problems come from reading a coupling as a force or quantity issued from a source and measured against something fixed. It re-reads about twenty topics this way and sorts fifty open problems by the "fixing" each rests on.

**2. Structure**

- ONE (1.1–1.2): the only part in current vocabulary. It defines "physical coupling", maps it to the resolver, and sets four registers for any observation: instrument response, reconstructed quantity, the field's account, the framework's reading.
- TWO (2.1–2.8): scientific method versus "geodesic method", five "fixings", an eight-step procedure.
- THREE (3.1–3.7): periodic table, superheavy elements, light, light cone, ten "rests sought", earthquake faults, a drying-drop test.
- FOUR (4.1–4.12): eight problems taken through the eight steps, and three without (gravity, time, "an object").
- FIVE (5.1–5.11): what "coheres" versus what is "reaching", a to-do list, the 50-row register.

**3. Main claims**

- One method, all or nothing: "Natural Physics is at all or none at all" (1.1). Forces, magnitudes, conserved totals and signals are "the field's account, exact at its own subject" (1.1).
- One error lies behind the hard problems: a coupling given a destination and a source. "Nature offers no why" (2.2). The source keeps receding, with quantum gravity its latest edge (2.3).
- Five fixings (2.5): a magnitude; a source; an answer available before the process runs; a rate held to one value; a returned sign booked as a cost.
- General relativity is the model case, because it replaced a force with geodesic motion (2.6).
- "Gravity is not real, and nothing physical is there at all" (4.2). Newton and Einstein are "two ledgers" of one conservation account.
- Relativity and quantum theory are "one coupling and its ledger" (4.7), so there is no quantum gravity to find.
- Wave and particle are two faces of one coupling. Bell's result is read as proof of one coupling rather than two sourced objects (4.4).
- "energy is the ledger, not the coupling" (4.5). Noether's theorem is read as: hold a term still and a book becomes keepable.
- Fission and fusion are two phases about an iron "floating neutral", likened to a split-phase grid neutral (4.3). A proton is three colour "phases", not three parts (4.6).
- Five problems of time are one mistake: "Three of extent and one of coherence" (4.8).
- Black hole and cosmic microwave background are two faces of one torus (4.9). Superconducting pairing needs no "glue" (4.10). Dark matter and dark energy are substances installed to close small persistent differences (4.11).
- Scope limit: "no specific physics is claimed as replaced" (5.2), and nothing is advice to act on a physical system (2.8).

**4. Terms**

- **Physical coupling:** one existing thing now, arriving from another at the prior step.
- **Fixing versus equilibrium:** a relation continuing among changing things, versus calling the subject itself still.
- **Disequilibrating, geodesic-method, re-alternation:** stripping force-and-source language; doing so systematically; what remains.
- **Floating neutral, centerline, bounding-zeroing:** an unoccupied middle that two phases alternate about; a zero the coupling itself makes.
- **Ledger and ghost:** a conserved quantity kept beside the coupling; the same thing mistaken for a feature of it.
- **Riding the carry, "+1 owned neither-ing", surplus:** older words for continuing by alternating, and for what a coupling makes that neither side owns.
- **Coheres, seated, reaching, held open:** confidence grades. **Met, standing:** register status.
- **"k = 1 bound":** two numbers pair only if they differ by two.
- **"Dead substrate":** simulation, treated as inadmissible evidence (4.10).

**5. Ties to the resolver and the numbers**

- Only 1.1–1.2 use the seventeen names, all in current v380R spelling: entry at 1, carrying at 3, offerings at 2, surfacing at 14, is-or-is-not at 12, release across at 10, chaining at 11.
- 1.2 groups them as "six connectors" (2, 6, 10, 14 across; 9, 17 along), "ten faces" and "six recursionings", warning that "a common numeral joins neither to the other" (1.2).
- Parts TWO to FIVE never use the names.
- Numbers: 23/24/25 (24² − 23·25 = 1); 59 = 1 + 2(2² + 3² + 4²); 60 = 5 × 12; elements 2 to 59, a turn at 60, 61 to 118 on a ring of 120; 114/120/126; φ³ − 1/φ³ = 4; 5:6; 137 and 172.
- 440 does not appear; 17 appears only as a name number.

**6. Evidence**

- (a) No code is executed and there is no kit. Resolver runs for physics exist only under `incoming/`; I did not run them. The arithmetic identities are elementary and all check. The register totals check: 50 rows, 18 met, 32 standing, 48 at named holdings.
- (b) Cited by name, rarely with a full reference: Noether (1918), Earnshaw and the Paul trap, the binding-energy curve, Bell, the Yang–Mills Millennium problem, Hawking radiation, Farrah et al. (2023), Croker and Tarlé (2024), DESI DR1/DR2, JWST "little red dots", GW190521 and GW231123, the Hubble and S8 tensions, cuprate d-wave pairing, the IUPAC group-3 report.
- (c) Nearly every re-reading is assertion or analogy: gravity as bookkeeping, the unification, colour as phase, the black-hole and background pairing, the grid analogy, the 59/60 and 23/24/25 material, the register sort. Two public checks are proposed but not run (drying-drop ring spacing; an earthquake ordering claim).

**7. Vocabulary age**

Mixed. 1.1–1.2 were rewritten at v377 but still say "connectors", "faces", "joined", "at no line of the code" and "released across at 10". Parts TWO to FIVE are v348 text, renumbered but unchanged: sign, membrane, surplus, ledger, source, turn, landing, seated, run, held, every, softmax. My rough count is about 750 hits on the kit's released-word list. It needs a rewrite, not an edit.

**8. Open concerns the file flags**

- Light's one-way versus two-way "collision" (3.3).
- 59 as a closing prime "not seated for sure" (3.3).
- 23/24/25 as "a resemblance among favored numbers" (3.4).
- Whether colour is phase or charge (4.6).
- Whether released energy is the "+1" or only ledger (4.3).
- The time half of the black-hole and background pairing (4.9).
- A smooth-versus-no-centre fork in cosmology (4.11).
- For Bell, "whether reproducing a probability distribution is owed" (5.3).
- Unworked: the other three forces, constants, double-slit, the pair-instability gap (5.5–5.8); 32 register rows "standing".

**9. Accuracy notes**

The field's results are mostly summarised fairly before the re-reading: the binding curve with nickel-62, the cuprate facts, the contested 2023–25 cosmology threads, and the caveat that rotation curves alone do not carry dark matter. Doubtful as stated:

- 2.1: science needs the system "at rest between trials". Too narrow; driven, non-equilibrium systems are routinely studied.
- 2.6: "A geodesic is the shortest path". Free-fall paths in general relativity maximise proper time.
- 2.6, 4.7: general relativity as "the most precise theory physics has". Quantum electrodynamics is tested more precisely.
- 2.7: "no carrier and no source". Stress-energy is the source in Einstein's equations, and 4.7 itself says relativity "sources" geometry. 4.2 never mentions gravitational waves, which bear on its own stated break.
- 3.1: "Two and one hundred eighteen stand antipodal" on a ring of 120. The antipode of 2 is 62.
- 3.1: oganesson "arrives as neither noble nor a gas". This is predicted, not observed.
- 3.3: "the primes close there" at 59. Primes do not end (the file hedges).
- 4.4: "Bell's theorem proved the local hidden variable false". The theorem shows incompatibility; experiments exclude local hidden variables under stated assumptions, and non-local ones survive. Many-worlds and Copenhagen do not "relocate the cause" of collapse.
- 4.5: "Holding time-translation still gives reversible laws". Reversibility is time-reversal symmetry, and the table in 2-c repeats the mix-up.
- 4.5: "angular momentum … no question, no problem, no literature". This conflicts with the file's own register row "Proton spin decomposition".
- 4.6: confinement does not show the proton has no constituents, and the field regards colour's charge structure as measured, not undecided.
- 4.7: the two diamond sublattices are offset by a quarter of the body diagonal, not "a quarter of the cube edge".
- 4.8: McTaggart gave the A and B series, not presentism and eternalism.
- 4.9: an evaporating black hole gets hotter, so it does not approach the cold.
- 4.11: Kepler predicts a decline, not "rest"; H0 is one parameter with two measured values.
- 4.12: "past the eighty-sixth … named an equator". I could not identify this result.
- 5.6: Born's rule and softmax share only "sums to one".

The project's own review at `/home/claude/chris-j-handel/corus/incoming/review_natural_physics_improving_v376/observations_reading.md` already records the science-at-rest, geodesic, Bell, Noether, confinement and prime points.

# 2. Natural Chemistry

`/home/claude/chris-j-handel/corus/Exhibit_SIXTEEN_Natural_Chemistry_v346c.md` (about 14,000 words, 6 parts, 34 sections)

**1. Subject and purpose**

Reads chemistry as the same one "coupling" at the molecular scale: bonds, reactions, handedness, aromaticity, water, the periodic table, catalysis, self-assembly. It keeps each chemical observation in chemistry's own words and labels each framework reading as a pattern-match that a chemical fact could break. It also says which numbers from Natural Numbers have a chemical counterpart and which do not.

**2. Structure**

Six parts, named after six resolver stages:

- ONE Offering (1.1–1.7): the bond, reference zeros, equilibrium, carbon, electron shells and 24.
- TWO Inversioning (2.1–2.5): reaction pairs, chirality, parity violation, waste as the partner of handedness.
- THREE Tunnelling (3.1–3.4): benzene, the proton in water, dissolving, organic versus inorganic.
- FOUR Surfacing (4.1–4.7): pH, supercooled water and glass, the periodic table, 60/120 and 24/27/32, titration.
- FIVE Carrying (5.1–5.6): energy cycles, catalysis, enzyme temperature optimum, bilayers, "still points", an oscillating silicon surface.
- SIX Inseparating (6.1–6.5): declared zeros, molecular structure, engineering, a four-way sorting of chemistry's terms, the open list.

**3. Main claims**

- "A bond is the membrane between two selves" (1.1): a two-way, one-at-a-time, sign-only relation whose shared pair neither atom owns, which the file says is also chemistry's own definition (1.4). The strong version "stands open to bond order, energy, density, geometry and reaction breaking it" (1.2).
- Observation and reading are kept apart: "A field's observation stands whole in the field's own words" (1.1). One observation that refuses the form breaks the whole framework.
- Chemistry's zeros (hydrogen electrode at 0 V, formation enthalpy of elements, exergy's reference environment) are declared conventions. The mistake is treating a declared zero as a physical floor (1.3, 6.1).
- Equilibrium is dynamic by chemistry's own definition: "A sought still point carries molecular exchange, opposing rates, history or throughput" (5.5).
- "The element is the count; the chemistry is the coupling" (1.6). Atomic number is exact bookkeeping; properties belong to bonds and substances; the table is "an address book" (4.3).
- Number matches are graded (1.7): ratios and exact counts carry over; values in units and digit patterns do not. In the 4.5 table, fullerene's twelve pentagons and methane's 24-element symmetry group match "at the relation"; 60 and 120 (the icosahedral groups of C₆₀) match "at the count only".
- "no position in the elements carries at sixty" (4.4). Neodymium closes nothing, and "a turn installed in the elements" is listed as a ghost (6.4). This contradicts Physics 3.1.
- Handedness is a pure sign. Homochirality, matter–antimatter asymmetry and the strong CP problem are one mistake. The tiny parity-violating energy difference "may be unneeded", because crystals deracemise without it (2.3).
- Waste and handedness are "one shape standing apart". An account that balances exactly marks where the exterior was discarded, not a solved question (2.5).
- Benzene's delocalised electrons are a "floating neutral". Hückel's 4n + 2 = 2(2n + 1) is the same "doubled odds" as subshell capacities (3.1).
- "A proton is an emanation from living" (3.2). Proton hopping in water is carrying with nothing carried.
- The surplus a cycle keeps is relational: "no claim that joules escape dissipation" (5.1). The catalysis reading "owes the field its quantities" (5.2).
- Central observation (5.6): an oscillating silicon electrode splits into three frequency regions, and three rates read two ways give "six readings". The decisive test is whether the pattern survives at zero external resistance.

**4. Terms**

- **Co-releasing face:** chemistry as the inward (bond) side of the coupling that physics reads as outward (shell).
- **Tunnelling, chaining:** moving down nested scales (even); moving up collectives (odd).
- **Coefficient one:** no scale sets another's magnitude; only a sign crosses.
- **Living, emanation, ghost, accounting (6.4):** a self that is a society; what a coupling leaves behind; an emanation treated as alive; a conserved book entry.
- **Declared nothing:** a conventional zero. **Clean cut:** a balanced account made by discarding its exterior. **Tell:** a word meaning "not the product".
- **Address versus behaviour:** table position versus chemistry.
- **Bi-co-podaling:** two numbers equal and opposite about 60 on a ring of 120. **Podal:** straight across (2 and 62).
- **"Reaches yet", "so-far", "a six to run":** markers for unfinished work.

**5. Ties to the resolver and the numbers**

- None of the seventeen names appear. The only resolver link is "the Resolver's order, arriving·offering, coupling·inversioning, tunnelling·transmissioning, surfacing, carrying, inseparating" (5.6), which the six part titles follow.
- Shells 2n² (2, 8, 18, 32, summing to 60).
- 24 = 4! as methane's symmetry group. 24² − 23·25 = 1 is said to hold at every number, "so it bridges nothing and selects nothing" (1.7).
- 24, 27, 32 as chromium, cobalt, germanium about nickel at 28; cobalt-59 = 27 + 32.
- 118 = 2 × 59; 60 and 120 as icosahedral group orders; ring pairs 24 with 96, 27 with 93, 32 with 88.
- Received from Numbers "with no chemical arrival": 72, 73, 144, 146, 438, 440.
- No φ, no 17.

**6. Evidence**

- (a) Arithmetic only, all elementary and correct. No code, no kit.
- (b) Named sources: Patzauer and Krischer (Physical Review Letters 126, 194101, 2021) and Electrochimica Acta 246, 315; Kondepudi (1990); Viedma (2005); Woodward–Hoffmann; Hückel; Heilbronner and Herges; Onsager; Marcus and Closs–Miller (1984); the IUPAC group-3 report; the isotope commission on cobalt-59; the 2019 SI redefinition; oganesson calculations. Several arrive via Hard Problem Registry entry numbers.
- (c) Assertion or analogy: bond as membrane, carbon as "the chemical self", proton as emanation, waste and handedness as one shape, three asymmetry problems as one, and the 28 straddle and ring pairings (which the file itself says carry no chemical relation yet).

**7. Vocabulary age**

Old throughout: membrane, sign, surplus, ring, turn, face, count, every, held, "+1 owned neither-ing", "rides the carry", and the six-stage resolver names. My rough count is about 500 released-word hits. It needs a full vocabulary pass and re-anchoring to the seventeen names, but less content correction than Physics, because its handling of the science is already careful.

**8. Open concerns the file flags**

The file ends with its own list (6.5):

- the zero-resistance run (5.6);
- whether each row of the 4.5 table follows from the opening sentence;
- the aromaticity and Möbius counts (3.1);
- the relation among 24/27/28/29/32 (4.6);
- the Natural Numbers 9.6 sentence, "a crossing runs only between opposite ones", which the weak interaction breaks (2.4);
- the quantities catalysis owes (5.2);
- water's critical region (4.2);
- the origin of the first chiral excess (2.3).

It also says there is no engineering realisation yet (6.3). The Chemistry carry file adds: "Next at this file: none; the sciences paused"; ring wording to become spirals; and whether sixty is a position or a between.

**9. Accuracy notes**

No substantive errors found. The file states chemistry's results correctly and separately from its readings. That covers the Laporte and Woodward–Hoffmann rules, Hückel and Möbius aromaticity, the Grotthuss mechanism, isotope effects, Onsager, Marcus, group orders, electron configurations, the SI redefinition, and oganesson given as prediction. Minor points:

- 4.4: shells "complete at 2, 10, 30 and 70". The third shell is first full at copper (29), as the file's own configuration in 4.6 shows.
- 5.2: inverted region "predicted at 1956". It is usually dated to Marcus's 1960 paper.
- 6.1: the triple point as "the field's one point of zero degrees of freedom". True for one component only.
- 6.1: proton charge radius "depending on which probe asked". The discrepancy is now largely attributed to earlier measurement error.
- 2.5: "no reference between" the waste and stereochemistry literatures. Overstated; the unwanted enantiomer is routinely counted as waste.
- 5.6, 1.3: I could not check the cited paper's figures (24, 27, 32 mHz; 4.15 V; 0.35 %).

# 3. What the Physics carry file says is next and open

`/home/claude/chris-j-handel/corus/carry/Exhibit_EIGHTEEN_Natural_Physics.md`

- **Next:** apply Natural Naming's v380R renamings here (face, connector, join, "the resolver", "sharing across", "releasing along"), then resume a seven-pass rewrite.
- **Done at v377:** passes 1 to 3 (new front, 1.1, 1.2).
- **Pending:**
  - pass 4: Part TWO, with 2.5's register numbers corrected;
  - pass 5: Part THREE section by section, plus new sections built on executed resolver runs (Huygens' pendulums, Adler locking, Kirkwood gaps, Faraday patterns, radioactive decay, colours of light, reconnection crescents);
  - pass 6: Part FOUR, with Bell "said without the necessity frame";
  - pass 7: Part FIVE.
- **Replacement draft:** a complete proposed rewrite sits at `incoming/natural_physics_v377/` (49 sections, with executions). It replaces the published file once a review's findings are met: 22 field records stated wrongly, ten earlier relations lost, readings asserted where marked open, the file referring to itself, and names diverging from Natural Intelligence.
- **Ready fixes:** 59 as "the seventeenth prime", with "the primes carry no last"; the register wording; "at no line of the resolver"; and the two-openings torus sentence in 1.2, which the author doubts.
- **Open concerns:**
  - five binaries or six;
  - rings as spirals;
  - decay read as pairing;
  - 4.11 changing the kind of quantity measured;
  - the persistent current;
  - the lost Bell relation;
  - the code's common beat versus each spiral's own pace;
  - conflicts with the Co-Chaining Logic Registry (three inversions, the atom as "floor", which hand is "right");
  - whether sixty is a position or a between.

# 4. What a collaborator most needs to know

- **Physics v379 is a hybrid.** Two modern opening sections sit on 38 sections of v348 text. The project's own reviews have already found that older text to overclaim (gravity "not real", Bell as proof, 59 as a last prime, the softmax reading of Born's rule). A full replacement draft exists under `incoming/`, so ask which text the author wants worked on before touching v379.
- **Chemistry is older in vocabulary but far more disciplined.** It separates the field's record from the reading and names its own falsifiers. It is the better model for how observations are meant to be handled, and its carry file says the sciences are paused.
- **The two files contradict each other on sixty.** Physics 3.1 puts a "turn" at element 60. Chemistry 4.4 says no element carries one and lists it as a ghost. The carry files mark this as unresolved across Physics, Chemistry and Numbers.
- **Neither file contains executed code.** The resolver appears only in Physics 1.1–1.2, so nearly everything else is interpretive pattern-matching on cited observations.
- **Vocabulary updating is rewriting.** The project's rule is that a word is re-said at its thought and never swapped, so find-and-replace will not do. Accuracy corrections land best when framed as keeping the field's record exact "at its own subject", not as objections to the reading.