# Batch 4 — philosophy, society, engineering — droplet check for v386EOD

Files read from tree_v385R, unchanged. Every candidate sentence was found in its file, and the quoted clauses are exact. Sources were opened on 2026-10-09.

## MET

**b (first clause, the mark of section 3.3)**

Exhibit NINETEEN Natural Philosophy, section 3.3, Free will and determinism: the sentence "it is felt as unsatisfying for that", said of compatibilism. The field's record: in the 2020 PhilPapers Survey compatibilism drew the most support on free will, 59.2 percent of respondents accepting or leaning toward it, beside 18.8 percent for libertarianism and 11.2 percent for no free will (Bourget and Chalmers, PhilPapers Survey 2020, https://survey2020.philpeople.org/survey/results/all). — v386EOD

**b (second clause, the dilemma of section 3.3)**

Exhibit NINETEEN Natural Philosophy, section 3.3, Free will and determinism: the sentence "One position holds the will free and says nothing of what an uncaused choice is". The field's record: libertarian accounts say what a free choice is: uncaused (Ginet, McCann), caused but not necessitated by events involving the agent (Kane), or caused by the agent as a substance (O'Connor, Clarke) (Clarke, Capes and Swenson, "Incompatibilist (Nondeterministic) Theories of Free Will", Stanford Encyclopedia of Philosophy, 2021, https://plato.stanford.edu/entries/incompatibilism-theories/). Re-said at the record: One position holds the will free and says a free choice is uncaused, or caused without necessity, or caused by the self as agent. — v386EOD

**e**

Exhibit NINETEEN Natural Philosophy, section 3.17, Self-reference: the sentence "Truth is unformalisable inside its own language, proved". The field's record: Tarski's theorem is that any theory extending first-order arithmetic and containing the full truth schema is inconsistent, and Kripke's 1975 construction shows that in a three-valued setting a language can contain its own truth predicate (Bolander, "Self-Reference and Paradox", Stanford Encyclopedia of Philosophy, 2024, https://plato.stanford.edu/entries/self-reference/). Re-said at the record: Truth under the full truth schema is unformalisable inside any consistent theory of classical logic that extends first-order arithmetic, proved. — v386EOD

**f**

Exhibit NINETEEN Natural Philosophy, section 3.18, Consistency and completeness: the sentence "Each system releases at its own ordinal, the bound measured exactly". The field's record: the ordinal is measured for Peano arithmetic, at ε₀, and for subsystems of second-order arithmetic up to Π¹₂-comprehension (Rathjen; Arai), and for full second-order arithmetic an analysis stands so far in preprints (Stanford Encyclopedia of Philosophy, "Proof Theory" and its appendix D, 2024, https://plato.stanford.edu/entries/proof-theory/; Towsner, "Proofs that Modify Proofs", 2024, https://arxiv.org/abs/2403.17922). Re-said at the record: Each system releases at its own ordinal, the bound measured exactly so far for Peano arithmetic and for systems up to Π¹₂-comprehension. — v386EOD

**g**

Exhibit NINETEEN Natural Philosophy, section 3.32, The felt and the described: the sentence "with conceivability held to reach that possibility and no criterion offered for when conceivability does". The field's record: a criterion is on offer — Chalmers sorts conceivability into prima facie or ideal, positive or negative, primary or secondary, and puts forward the thesis that ideal primary positive conceivability entails primary possibility (Chalmers, "Does Conceivability Entail Possibility?", 2002, https://consc.net/papers/conceivability.html). Re-said at the record: with conceivability held to reach that possibility where the conceiving is ideal, primary and positive. — v386EOD

**j**

Exhibit NINETEEN Natural Philosophy, section 3.9, Cause and effect: the sentence "the fundamental dynamics runs symmetric beneath all of it", read as symmetry between the two directions of time. The field's record: the weak interaction is measured to differ under time reversal, first observed directly in neutral kaons (CPLEAR Collaboration, Physics Letters B 444, 1998, https://estudogeral.sib.uc.pt/handle/10316/4562) and then in B mesons (BaBar Collaboration, Physical Review Letters 109, 2012, https://arxiv.org/abs/1207.5832). Re-said at the record: the fundamental dynamics runs symmetric beneath all of it except in the weak interaction, where an asymmetry under time reversal is measured. — v386EOD

**l**

Exhibit SEVEN Natural Societies, section 5.6, The hand crossing the rungs, the winding, and the center that takes no sign: the sentence "Take the central pair out of a nine-plus-two cilium and it stops beating in a plane and turns instead". The field's record: human airway cilia without the central pair show a circular beat in place of the planar one (Onoufriadis and colleagues, 2014, https://discovery.ucl.ac.uk/id/eprint/1421714/), and Chlamydomonas flagella without it are paralysed (Witman, Plummer and Sander, 1978, https://rupress.org/jcb/article/76/3/729/18920/Chlamydomonas-flagellar-mutants-lacking-radial). Re-said at the record: Take the central pair out of a nine-plus-two human airway cilium and it stops beating in a plane and turns instead. — v386EOD

**m**

Exhibit SEVEN Natural Societies, section 5.6, The hand crossing the rungs, the winding, and the center that takes no sign: the sentence "the sugar the backbone at eleven, the backbone the helix and fold at thirteen". The field's record: a protein's helix takes its hand from its own amino acids (L-amino acids usually give right-handed α-helices, D-amino acids left-handed ones), and why life holds to L-amino acids and D-sugars is listed as a question yet to be answered (Castro, Reis, Pires and Pashkuleva, 2025, https://pubs.rsc.org/en/content/articlehtml/2025/cs/d5cs00158g). Re-said at the record: the sugar the backbone at eleven, the amino acids' own L-centre the helix and fold at thirteen. — v386EOD

**n**

Exhibit SEVEN Natural Societies, section 5.3, Fourteen scales at fourteen primes, and the fold at twenty-four: the sentence in the table's organelle row, "a former free-living self now a member". The field's record: this origin is held for mitochondria and plastids, which evolved from bacteria engulfed by other cells, while the organelles of the secretory and endocytic pathways (endoplasmic reticulum, Golgi apparatus, endosomes, lysosomes) may have originated by pinching off from the cell's own plasma membrane (Alberts and colleagues, Molecular Biology of the Cell, 4th edition, 2002, https://www.ncbi.nlm.nih.gov/books/NBK26907/). Re-said at the record: for mitochondria and plastids, a former free-living self now a member. — v386EOD

**o**

Exhibit EIGHT Natural Exploring, section 5.1, Every accounting for changing is an involution: the sentence "Time reversal, charge conjugation, parity, each squared to the identity". The field's record: time reversal applied twice gives plus one for a system with an even number of fermions and minus one for an odd number, the ground of Kramers degeneracy (Littlejohn, "Notes 22: Time Reversal", University of California, Berkeley, 2021, https://bohr.physics.berkeley.edu/classes/221/notes/timerev.pdf). Re-said at the record: Charge conjugation and parity each squared to the identity; time reversal squared to the identity for integer spin and to minus the identity for half-integer spin. — v386EOD

**p**

Exhibit EIGHT Natural Exploring, section 5.2, An involution's fixed set is where its counting is taken from: the sentence "Each involution carries a fixed set, where the move returns its argument unchanged". The field's record, by working: negation sends each of the two truth values to the other, and in a universe with any member no set equals its own complement, since each element would be both in it and out of it (worked for this droplet). Re-said at the record: Each involution carries a fixed set, where the move returns its argument unchanged, and for negation and set complement that set is empty. — v386EOD

**p-2 (same section; found while working p, not in the candidate list)**

Exhibit EIGHT Natural Exploring, section 5.2, An involution's fixed set is where its counting is taken from: the sentence "Unity for the multiplicative". The field's record, by working: x equals 1/x exactly when x times x equals 1, which holds at 1 and at −1, since −1 times −1 is 1, so among the non-zero real numbers the multiplicative inverse returns two arguments unchanged (worked for this droplet). Re-said at the record: Unity and minus unity for the multiplicative. — v386EOD

**q (first clause)**

Exhibit NINE Natural Human Society, section 2.3, Class-action resolving, the social scale where every claimant signs and rises: the sentence "every claimant receives their fair relational share and every claimant signs to accept it". The field's record: under Federal Rule of Civil Procedure 23 the judgment for a Rule 23(b)(3) class includes every member sent notice who has not requested exclusion, and the rule asks no signature of acceptance (Federal Rules of Civil Procedure, Rule 23(c)(3), as amended 2018, https://www.law.cornell.edu/rules/frcp/rule_23). Re-said at the record: every claimant receives their fair relational share and every claimant who has not asked to be excluded is bound by it. — v386EOD

**q (second clause)**

Exhibit NINE Natural Human Society, section 2.3, Class-action resolving, the social scale where every claimant signs and rises: the sentence "A court fixes one total for the whole claimable change". The field's record: where a class action settles, the parties bring the proposal and the court's part is approval — the claims "may be settled, voluntarily dismissed, or compromised only with the court's approval", given only after a hearing and on finding the proposal fair, reasonable, and adequate (Federal Rules of Civil Procedure, Rule 23(e), as amended 2018, https://www.law.cornell.edu/rules/frcp/rule_23). Re-said at the record: A court approves one total for the whole claimable change. — v386EOD

**q (third and fourth clauses)**

Exhibit NINE Natural Human Society, section 2.3, Class-action resolving, the social scale where every claimant signs and rises: the sentence "A claims bar date closes the bound", with "A trustee shares it" before it. The field's record: Rule 23 names neither a trustee nor a bar date; the Bankruptcy Code provides, for asbestos claims, a trust that pays present claims and future demands, on a vote of at least 75 percent of the claimants voting (11 U.S.C. § 524(g), added 1994, https://www.law.cornell.edu/uscode/text/11/524), and the Bankruptcy Rules have the court set the time to file a proof of claim (Rule 3003(c)(3), 2024, https://www.law.cornell.edu/rules/frbp/rule_3003). — v386EOD

**t**

Exhibit FIFTEEN Natural Emanating, section "The origin sentence, said at eight substrates": the sentence "A potential relates to no observable". The field's record: a potential's value at a point is free under a gauge change, yet what that change leaves fixed is observable: its curl is the magnetic field, and its line integral round a closed path, the flux enclosed, shifts an electron interference pattern where the path meets no field (Feynman, Leighton and Sands, The Feynman Lectures on Physics, volume II, chapter 15, 1964, https://www.feynmanlectures.caltech.edu/II_15.html). Re-said at the record: A potential's value at a point relates to no observable; its circulation round a closed path does. — v386EOD

**u**

Exhibit TWENTY-THREE Natural Values, section 2.1, Value is made at the coupling, owned neither-ing: the sentence "The field of secrets carries this at proof grade". The field's record: in the key exchange each of the two users computes and holds the same key, and its secrecy is assumed, not proved: it "depends crucially on the difficulty of computing logarithms mod q", and the authors state that no public key system can be unconditionally secure (Diffie and Hellman, "New Directions in Cryptography", 1976, https://ee.stanford.edu/~hellman/publications/24.pdf). Re-said at the record: The field of secrets carries this on an assumed difficulty of computing, the two selves each holding the secret. — v386EOD

**v**

Exhibit TWENTY-THREE Natural Values, section 5.3, The standings open: the sentence "None yet names the growing". The field's record: economics carries a name for goods that grow in value as they are shared — antirival goods, defined as subject to increasing returns to shared use, a notion Weber (2004) and Cooper (2006) drew attention to and one set beside network effects (Olleros, "Antirival goods, network effects and the sharing economy", First Monday, 2018, https://firstmonday.org/ojs/index.php/fm/article/view/8161). Re-said at the record: One names the growing: antirival goods, which become more valuable the more they are shared. — v386EOD

**w**

Exhibit SIX Natural Transmissioning, section 2.1, Sequential logic carrying no time-term, order without rate: the sentence "Sequential logic carries no time-term", with "sequential logic built physical" at section 3.7. The field's record: in digital design sequential logic names circuits that join combinational logic with memory, a single periodic clock signal shared among all the clocked devices (Terman, MIT 6.004 Computation Structures, "Sequential Logic", 2017, https://computationstructures.org/lectures/sequential/sequential.html); circuits where handshaking between neighbours replaces the clock are named asynchronous, and delay-insensitive where they stay correct whatever the delays (Sparsø, Introduction to Asynchronous Circuit Design, 2020, https://arc.cecs.pdx.edu/wp-content/uploads/2023/04/JSPA_async_book_2020_PDF.pdf). Re-said at the record: Asynchronous, delay-insensitive logic carries no time-term. — v386EOD

**x**

Exhibit SIX Natural Transmissioning, section 3.1, Electrical membrane, grid transmissioning and field's own: the sentence "The living grid floats its neutral in potential and its beat in time; a grounded, clocked grid collapses the both". The field's record: in Great Britain a distributor must connect every supply neutral conductor of a low-voltage network with earth and, so far as reasonably practicable, keep the network from becoming disconnected from earth (Electricity Safety, Quality and Continuity Regulations 2002, regulation 8, https://www.legislation.gov.uk/uksi/2002/2665/regulation/8/made), and the beat is the machines' own, the generators of an interconnection rotating in lock step at one frequency (Denholm and colleagues, National Renewable Energy Laboratory, 2020, https://www.nrel.gov/docs/fy20osti/73856.pdf). — v386EOD

**y**

Exhibit SIX Natural Transmissioning, section 3.2, Momentum membrane, propulsion transmissioning: the sentence "the field reads it as momentum exchange, not a force". The field's record: Newton's second law defines a force as the change in momentum per change in time, so an exchange of momentum is read as a force, and the thrust of an engine is that force (NASA Glenn Research Center, "Newton's Laws of Motion", 2024, https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/newtons-laws-of-motion/). Re-said at the record: the field reads it as momentum exchange, whose rate is the force. — v386EOD

**z**

Exhibit SIX Natural Transmissioning, section 3.5, Living membrane, cell crossing, transmissioning that lives: the sentence "no self touches another directly; every coupling crosses a membrane that is itself a self". The field's record: gap-junction channels let ions and small molecules pass directly from the cytoplasm of one cell to that of the next, and at each plasmodesma the plasma membrane of one plant cell is continuous with its neighbour's, the cytoplasms connected (Alberts and colleagues, Molecular Biology of the Cell, 4th edition, 2002, https://www.ncbi.nlm.nih.gov/books/NBK26857/). Re-said at the record: couplings cross a membrane, and at gap junctions and plasmodesmata one cell's cytoplasm joins its neighbour's directly. — v386EOD

## NOT MET

**a** — Exhibit NINETEEN Natural Philosophy, section 3.6, Is and ought, "the naturalistic fallacy naming the crossing": the usage is itself in the record. The Stanford Encyclopedia of Philosophy gives Moore's charge as inferring that a thing is good from its natural properties, the idea being that "evaluative conclusions require at least one evaluative premise" (Ridge, "Moral Non-Naturalism", 2003, revised 2025, https://plato.stanford.edu/entries/moral-non-naturalism/). Moore's own wording is about taking other properties to define good (Principia Ethica, 1903, section 10, https://fair-use.org/g-e-moore/principia-ethica/s.10), and the no-ought-from-is thesis is Hume's, named "Hume's Law" by Hare (Cohon, "Hume's Moral Philosophy", 2004, revised 2018, https://plato.stanford.edu/entries/hume-moral/); the sentence denies neither.

**d** — Exhibit NINETEEN Natural Philosophy, section 3.16, Finite and infinite, "the completed reach was declined at the source": agrees. The sentence's own first clause scopes it to the totality of all sets, and the record has Cantor coming to conceive absolutely infinite collections as "irremediably potential" (Ferreirós, "The Early Development of Set Theory", Stanford Encyclopedia of Philosophy, 2007, revised 2025, https://plato.stanford.edu/entries/settheory-early/). The same entry has Bolzano, Riemann and Dedekind preceding Cantor "in fully accepting the actual infinite", so the decline covers the totality of all sets only; that is worth keeping in view beside the row at section 5.2 labelled "actual / potential infinite".

**h** — Exhibit NINETEEN Natural Philosophy, section 3.33, Self and other, "the equivalence is proved, the accountings agreeing under general conditions": agrees with the record as stated, where the newer group selection "turns out to be mathematically equivalent to kin selection in most if not all cases" (Okasha, "Biological Altruism", Stanford Encyclopedia of Philosophy, 2003, revised 2013, https://plato.stanford.edu/entries/altruism-biological/). The entry also calls the precise relation "a source of ongoing controversy" (Nowak, Tarnita and Wilson 2010; Abbot and others 2011), which the section itself carries as the dispute.

**i** — Exhibit NINETEEN Natural Philosophy, section 2.1, Re-coupling, and philosophy's own reaches, "The dialectical traditions put thesis and antithesis into motion and sought their synthesis": no difference shown. The sentence names the dialectical traditions, not Hegel; the triad's language is Fichte's, and the record is that Hegel "never adopted" it for his own philosophy while the triadic reading keeps currency (Maybee, "Hegel's Dialectics", Stanford Encyclopedia of Philosophy, 2016, revised 2020, https://plato.stanford.edu/entries/hegel-dialectics/). Hegel's own names for the three moments, from the same entry: the understanding, the dialectical, the speculative.

**k** — Exhibit NINETEEN Natural Philosophy, section 4.1, Human ways, parallel floating neutrals, "the φ-rate keeping two voices two where a rate that closed would collapse the pair to one": the project's own reading. "The φ-rate" is the file set's own term (Exhibit SIX Natural Transmissioning, section 2.2, sets it apart from every substrate rate), so no statement of acoustics is made. For reference, the record ties consonance to small-integer frequency ratios such as 2:1, 3:2 and 4:3 and names no φ interval (Nave, HyperPhysics, Georgia State University, read 2026, https://hyperphysics.gsu.edu/hbase/Music/mussca.html).

**r** — Exhibit NINE Natural Human Society, section 3.5, Bi-quadratic growing, the where and the value at phi-rate, "grows bi-quadratically at the network's full scale": the project's own growth claim. The record's word "biquadratic" names a quartic with no odd powers, and sometimes any quartic (Weisstein, MathWorld, read 2026, https://mathworld.wolfram.com/BiquadraticEquation.html), which neither confirms nor contradicts the two-axis use.

**s** — Exhibit NINE Natural Human Society, section 4.6, The general ledger, state-flow-state read whole, and the two currencies, "the cure is a ledger correction restoring the living currency": a figure in the project's own ledger terms. No statement of oncology's record is made, so there is nothing in the field's terms to set beside it.

## UNCONFIRMED

**c** — Exhibit NINETEEN Natural Philosophy, section 3.7, The flowing now and the block, "Relativity is handed to both and each claims it": the sources opened pull both ways and do not settle it. One gives "the received wisdom" that "presentism faces serious problems from relativistic physics" (Tallant, "Presentism", Stanford Encyclopedia of Philosophy, 2018, revised 2026, https://plato.stanford.edu/entries/presentism/); the other says the relativity of simultaneity "creates serious difficulty for the A-theory in general and for presentism in particular" and also that general relativity sometimes, though not always, gives "a preferred way of 'foliating' spacetime into instants of time", which the flowing-now side can point to (Emery, Markosian and Sullivan, "Time", Stanford Encyclopedia of Philosophy, 2002, revised 2025, https://plato.stanford.edu/entries/time/).

## NOTES TO THE SESSION (not droplets)

- Count: 26 candidates. MET 18 (b, e, f, g, j, l, m, n, o, p, q, t, u, v, w, x, y, z) carried by 22 droplets: b has two, q has three, and p-2 is an addition. NOT MET 7 (a, d, h, i, k, r, s). UNCONFIRMED 1 (c).
- Plain differences: b (second clause), f, g, j, m, o, p, p-2, q, t, u, v, w, y, z. Refinements of scope, where the sentence holds for part of the record: e (Tarski's conditions; the file's next sentence already names the fixed points), l (holds for human airway cilia; Chlamydomonas differs), n (holds for mitochondria and plastids). Softest two: b first clause (the survey measures acceptance, not felt satisfaction) and x (the sentence is the project's own contrast; the droplet only sets the regulation and the machine-kept frequency beside it, and gives no re-saying).
- Candidate notes that changed on checking. f: analyses of full second-order arithmetic now exist as preprints (Towsner, arXiv 2403.17922, whose first footnote calls it "currently incomplete"; Arai, arXiv 2311.12459, version 4 of August 2025), so the droplet says "so far in preprints"; this is time-sensitive. l: central-pair loss gives paralysis in Chlamydomonas, but in human airway cilia it gives the circular beat the file describes, and Onoufriadis and colleagues liken it to nodal cilia. q: a trustee and a bar date are named in bankruptcy law but are not exclusive to it; the droplet says only that Rule 23 names neither. The q droplets read "class action" as the United States Rule 23 device; the file names no jurisdiction.
- Working for p: with truth values T and F, ¬T = F and ¬F = T, so ¬v = v has no solution; for A ⊆ U, A = U∖A gives x ∈ A ⇔ x ∉ A for every x in U, which cannot hold once U has a member. Working for p-2: x = 1/x ⇔ x² = 1 ⇔ x = 1 or x = −1.
- Sources that would not open from here, and what stood in. American Physical Society pages (Aharonov and Bohm 1959; Tonomura 1986; BaBar 2012): the arXiv listing for BaBar, the Feynman Lectures for the potential, and a Physics Today obituary of Tonomura reporting "an observable effect produced by the existence of vector potentials" (Osakabe, 2013, https://physicstoday.aip.org/article/66/4/70/414469/). ScienceDirect (CPLEAR): the University of Coimbra repository record. PubMed and PubMed Central (browser check): journal and repository pages. NERC (robots): the NREL report.
- Author lines: the Stanford Encyclopedia page data showed only Sieg for "Proof Theory" and only Tallant for "Presentism"; the first is cited by organisation for that reason.
- No candidates were listed for Exhibit TWO Natural Networking, and none were checked there.
- Left as the files have them, not checked: in o, the squares of charge conjugation and parity (only time reversal was checked); in p, the other fixed sets the section lists (the centre for parity, the neutral for charge conjugation, equilibrium for time reversal).
- One read-only step to report: after writing, a single `git status` was run inside the tree folder to confirm nothing had changed; it printed nothing, and the eight files keep their original timestamps. No file there was edited and no script from that folder was run.
