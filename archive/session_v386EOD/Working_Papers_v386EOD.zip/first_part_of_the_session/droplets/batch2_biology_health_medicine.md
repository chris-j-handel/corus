# Droplets, batch 2: biology, health, medicine, and three registry entries

Checked for session v386EOD against the files as they stand in the v385R tree: Exhibit SEVENTEEN Natural Biology (v333), Exhibit TEN Natural Health (v329), Exhibit ELEVEN Natural Medicine (v331), Exhibit TWENTY-FIVE Living Society Registry (v347). Twenty-five lettered candidates, a to y; three of them (f, h, k) carry two sentences each and have a droplet for each, twenty-eight droplets in all. Every quoted clause was matched character for character against its file. The files were read and not changed.

## MET

**a.** Exhibit SEVENTEEN Natural Biology, 3.3 A left face is the emanation face of one right spiral, the sentence "it forms behind a transcribing polymerase where the winding has been left over-wound behind and under-wound ahead". The field's record is that an advancing polymerase leaves positive supercoils, the over-wound side, ahead of it and negative supercoils, the under-wound side, behind it (Liu and Wang 1987, Proceedings of the National Academy of Sciences, https://doi.org/10.1073/pnas.84.20.7024). Re-said at the record: "it forms behind a transcribing polymerase where the winding has been left under-wound behind and over-wound ahead". — v386EOD

**b.** Exhibit SEVENTEEN Natural Biology, 5.5 Multicellularity and the germ-soma split — many selves into one; the carried self and the offered surface, the sentence "two genus-nought cells arriving as one multinucleated genus-one fibre". The field's record is that two sphere-like membranes merged through one opening make a surface that is again a single sphere: Euler characteristic 2 + 2 − 2 = 2, which is genus nought (Bottacchiari and colleagues 2022, Communications Physics, https://arxiv.org/abs/2202.13879). Re-said at the record: "two genus-nought cells arriving as one multinucleated genus-nought fibre". — v386EOD

**c.** Exhibit SEVENTEEN Natural Biology, 7.6 Vertical fractal — a network eating downward, the sentence "Every vertebrate eye sees by retinal, cut from the carotenoid ring, and no animal makes that ring". The field's record is that carotenoids are required in the diet of most animals, and that the pea aphid makes its own, its genome carrying carotenoid-making enzymes from genes that arrived from fungi (Moran and Jarvik 2010, Science, https://doi.org/10.1126/science.1187113). Re-said at the record: "Every vertebrate eye sees by retinal, cut from the carotenoid ring, and most animals do not make that ring". — v386EOD

**d.** Exhibit SEVENTEEN Natural Biology, 8.14 A flock that turns as one with no one turning it, the sentence "two birds are as correlated across a kilometre as across ten metres" and, with it, "the correlation does not decay with distance". The field's record is that, in flocks 9 to 86 metres across, the correlation decays with distance and changes sign at a length that grows with the flock's size, about 0.35 of it (Cavagna and colleagues 2010, Proceedings of the National Academy of Sciences, https://arxiv.org/abs/0911.4393). Re-said at the record: "two birds stay correlated across a distance that grows with the flock's size". — v386EOD

**e.** Exhibit SEVENTEEN Natural Biology, 3.7 Structural-protein surface — a matrix as the third self, the sentence "Released as procollagen, the molecules cleave, meet, and assemble into triples, triples into fibrils banded at sixty-seven nanometres". The field's record is that three chains join into the triple helix inside the cell, in the endoplasmic reticulum, before release; after release the end-pieces are cleaved and the triple-helical molecules assemble into fibrils (Alberts and colleagues 2002, Molecular Biology of the Cell, https://www.ncbi.nlm.nih.gov/books/NBK26810/). Re-said at the record: "Released as procollagen, already assembled into triples, the molecules cleave, meet, and assemble into fibrils banded at sixty-seven nanometres". — v386EOD

**f (3.1).** Exhibit SEVENTEEN Natural Biology, 3.1 Living is metabolic beating — the cell as the engine, the sentence "the surplus returned as coupling and not lost", closing on "not lost as heat". The field's record is that nearly half of the energy that could be had from oxidising glucose or fatty acids is captured in the making of ATP, and the rest is released by the cell as heat (Alberts and colleagues 2002, Molecular Biology of the Cell, https://www.ncbi.nlm.nih.gov/books/NBK26882/). Re-said at the record: "nearly half of the surplus returned as coupling, and the rest released as heat". — v386EOD

**f (4.6).** Exhibit SEVENTEEN Natural Biology, 4.6 Photosynthesis and respiration — the six offering the six, the sentence "the surplus kept as coupling turn to turn, carrying, and not falling out as heat". The field's record is that a cell's respiration captures nearly half of the energy that could be had from oxidising glucose or fatty acids in the making of ATP, and releases the rest as heat (Alberts and colleagues 2002, Molecular Biology of the Cell, https://www.ncbi.nlm.nih.gov/books/NBK26882/). Re-said at the record: "nearly half of the surplus kept as coupling at the cell's respiration, and the rest falling out as heat". — v386EOD

**g.** Exhibit SEVENTEEN Natural Biology, 3.1 Living is metabolic beating — the cell as the engine, the sentence "the ancestral ratio of cardiolipin's omega-6 to omega-3 lands within a hair of 1/φ²". The field's record is that cardiolipin in animal tissues carries eighteen-carbon chains almost exclusively, typically about 80 per cent of them linoleic acid, an omega-6 chain, and is relatively resistant to diet (Christie 2026, LIPID MAPS LipidWeb, https://www.lipidmaps.org/resources/lipidweb/lipidweb_html/lipids/complex/dpg/index.htm); the ratio near 1 is the estimate for the diet humans evolved on (Simopoulos 2002, https://doi.org/10.1016/s0753-3322(02)00253-6), and 1/φ² is 0.382. — v386EOD

**h (first clause).** Exhibit SEVENTEEN Natural Biology, 4.7 DNA replication and repair — the self copying itself, and the protection of the copying, the sentence "falling from about one in ten million to about one in ten billion across the tiers". The field's record across the three tiers is one mismatch in a hundred thousand at the polymerase's selecting, a hundredfold fewer after proofreading and again after mismatch repair, one in a billion (Alberts and colleagues 2002, Molecular Biology of the Cell, Table 5-1, https://www.ncbi.nlm.nih.gov/books/NBK26850/). Re-said at the record: "falling from about one in a hundred thousand to about one in a billion across the tiers". — v386EOD

**h (second clause).** Exhibit SEVENTEEN Natural Biology, 4.7 DNA replication and repair — the self copying itself, and the protection of the copying, the sentence "The Hayflick limit, about fifty to seventy divisions". The field's record at its source is a doubling potential of 50 ± 10, forty to sixty population doublings, for each clonable cell of a human diploid cell strain (Hayflick 1965, Experimental Cell Research 37, page 634, as quoted at BioNumbers entry 105586, https://bionumbers.hms.harvard.edu/bionumber.aspx?id=105586). Re-said at the record: "The Hayflick limit, about forty to sixty divisions". — v386EOD

**i.** Exhibit SEVENTEEN Natural Biology, 3.8 Six physical bi-foldings — where a differential arrives out of plane, the sentence "two hundred square metres of gut in a tube". The field's record, revisiting textbook figures of 260 to 300 square metres, is that the mean total mucosal surface of the digestive tract averages about 32 square metres, about 2 of them the large intestine (Helander and Fändriks 2014, Scandinavian Journal of Gastroenterology, https://doi.org/10.3109/00365521.2014.898326). Re-said at the record: "about thirty-two square metres of gut in a tube". — v386EOD

**j.** Exhibit SEVENTEEN Natural Biology, 3.3 A left face is the emanation face of one right spiral, the sentence "The field uses this directly in non-caloric sweeteners". The field's record is that L-glucose was proposed as a low-calorie sweetener and could not be made cheaply enough for commercial use, as with the other left-handed sugars tried, and that the sugar then developed was D-tagatose (National Aeronautics and Space Administration 2004, Spinoff, "A Natural Way to Stay Sweet", https://spinoff.nasa.gov/Spinoff2004/ch_4.html). Re-said at the record: "The field proposed this directly for non-caloric sweeteners, and L-glucose was not brought to commercial use". — v386EOD

**k (first clause).** Exhibit SEVENTEEN Natural Biology, 5.2 A self recursioning into a new form — development and metamorphosis, the sentence "The caterpillar's tissues dissolve almost wholly (histolysis, a suspension no measurement distinguishes as having been muscle or gut or nerve)". The field's record is that time-lapse X-ray tomography of living chrysalises measures the gut and the tracheal system through the pupal stage, the tracheae visible twelve hours after pupation (Lowe and colleagues 2013, Journal of the Royal Society Interface, https://doi.org/10.1098/rsif.2013.0304), and that a moth keeps an aversion it learned as a caterpillar (Blackiston and colleagues 2008, PLoS ONE, https://doi.org/10.1371/journal.pone.0001736). — v386EOD

**k (second clause).** Exhibit SEVENTEEN Natural Biology, 5.2 A self recursioning into a new form — development and metamorphosis, the sentence "Seven independent phyla carry the same geometry". The field's record places the cases the sentence goes on to list, and the caterpillar before them, in two phyla: the caterpillar, the crustacean and the velvet spider in Arthropoda, and the tadpole and the salmon, as vertebrates, in Chordata (Myers 2001, Animal Diversity Web, University of Michigan Museum of Zoology, https://animaldiversity.org/accounts/Arthropoda/ and https://animaldiversity.org/accounts/Vertebrata/). The list names no case from a third phylum. — v386EOD

**l.** Exhibit SEVENTEEN Natural Biology, 8.9 A butterfly that flies to a place it carries and has never been, the sentence "robust to displacement, since the heading is recomputed locally at each moment, not a fixed path". The field's record is that monarchs displaced 2,500 kilometres to the west continued to fly in the same general southwest direction, a vector strategy and not true navigation (Mouritsen and colleagues 2013, Proceedings of the National Academy of Sciences, https://doi.org/10.1073/pnas.1221701110). Re-said at the record: "not correcting for displacement, since the heading is recomputed locally at each moment, not a fixed path". — v386EOD

**m.** Exhibit SEVENTEEN Natural Biology, 10.4 Deep-math yield, toward the prime ladder, the sentence "nesting-table primes (cristae 22, renal 26, inner-ear 28, hepatic 33, bronchioalveolar 34, spermatogonial 38)". The record of arithmetic is that a prime is a positive integer above 1 with no positive divisors but 1 and itself (Weisstein, MathWorld, read 2026, https://mathworld.wolfram.com/PrimeNumber.html), and computed here 22 = 2 × 11, 26 = 2 × 13, 28 = 2 × 2 × 7, 33 = 3 × 11, 34 = 2 × 17 and 38 = 2 × 19, so none of the six is a prime. — v386EOD

**n.** Exhibit SEVENTEEN Natural Biology, 1.3 Every self is a society of selves, the sentence "an atom a society of nuclei and electrons". The field's record is that an atom consists of one nucleus of positive charge, carrying almost all its mass, and Z electrons determining its size, Z being the proton number (International Union of Pure and Applied Chemistry, Gold Book, entry "atom", read 2026, https://doi.org/10.1351/goldbook.A00493). Re-said at the record: "an atom a society of a nucleus and electrons". — v386EOD

**o.** Exhibit SEVENTEEN Natural Biology, 5.1 Conception — two selves conceiving a third, the sentence "the sperm a stripped fast co-offering with its own mitochondria shed". The field's record is that the sperm carries mitochondria at the midpiece of its tail, powering the flagellum (Alberts and colleagues 2002, Molecular Biology of the Cell, https://www.ncbi.nlm.nih.gov/books/NBK26914/), and that they enter the egg with it, carry a ubiquitin mark, and are destroyed there (Sutovsky and colleagues 1999, Nature, https://doi.org/10.1038/46466). Re-said at the record: "the sperm a stripped fast co-offering whose own mitochondria enter the egg with it and are cleared there". — v386EOD

**p.** Exhibit TEN Natural Health, 4.2 The measures read as sway, the level set down, the sentence "the field's own theorem seats the sway as the living: fluctuation and dissipation are one function". The field's record is that the fluctuation–dissipation theorem belongs to equilibrium thermodynamics, and that at a living hair bundle, spontaneous movement set beside response, the theorem broke down, the cell's energy-consuming elements driving the movement (Martin, Hudspeth and Jülicher 2001, Proceedings of the National Academy of Sciences, https://doi.org/10.1073/pnas.251530598). Re-said at the record: "at equilibrium fluctuation and dissipation are one function, and at a living hair bundle the two were measured to part". — v386EOD

**q.** Exhibit ELEVEN Natural Medicine, 2.3 A body's tissues at the form — turnover, barriers, modes, the sentence "Five locations wrap one coupling", its list of serous membranes closing on "the synovium at each joint, the meninges at the brain". The field's record is that the serous membranes are the pleura, the pericardium and the peritoneum, and that the synovial membrane and the meninges are connective tissue (Betts and colleagues 2022, Anatomy and Physiology 2e, OpenStax, https://openstax.org/books/anatomy-and-physiology-2e/pages/4-1-types-of-tissues). Re-said at the record: "Three locations wrap one coupling — the pericardium at the heart, the pleura at each lung, the peritoneum at the abdominal viscera". — v386EOD

**r.** Exhibit ELEVEN Natural Medicine, 2.2 Cancer as a coupling collapse at a cell's bounding-zeroing, the sentence "The field's observation carries no exception across the stem cell types: glycolytic metabolism in quiescence, oxidative phosphorylation in activation". The field's record carries the reverse at one stem cell type: in passing from quiescence to proliferation, skeletal muscle stem cells switch from fatty acid oxidation to glycolysis (Ryall and colleagues 2015, Cell Stem Cell, https://doi.org/10.1016/j.stem.2014.12.004). Re-said at the record: "The field's observation carries an exception among the stem cell types: skeletal muscle stem cells run fatty acid oxidation in quiescence and glycolysis in activation". — v386EOD

**s.** Exhibit ELEVEN Natural Medicine, 3.1 Two adjacent societies at a gut collar, the sentence "Every one of those is the cell doing with its own machinery what it does with every sequence it carries", the first of those being the integrating. The field's record is that integrase, an enzyme of the virus, helps it integrate its DNA into the DNA of the cell (National Institutes of Health 2025, HIVinfo, "The HIV Life Cycle", https://hivinfo.nih.gov/understanding-hiv/fact-sheets/hiv-life-cycle). Re-said at the record: "Every one of those but the integrating is the cell doing with its own machinery what it does with every sequence it carries". — v386EOD

**t.** Exhibit ELEVEN Natural Medicine, 3.6 Five departures at one collar, arriving at one presentation, the sentence "three children died of liver failure". The field's record is that four dosed participants died, one in the lower dose cohort and three in the higher, all with cholestatic liver failure following the gene therapy at the time of death, the immediate causes including sepsis, gastrointestinal haemorrhage and septic shock (Shieh and colleagues 2023, The Lancet Neurology, https://doi.org/10.1016/S1474-4422(23)00313-7). Re-said at the record: "four children died, each with cholestatic liver failure at the time of death". — v386EOD

**u.** Exhibit ELEVEN Natural Medicine, 2.2 Cancer as a coupling collapse at a cell's bounding-zeroing, the sentence "an antibody that also depletes B cells is followed by relapse near three months". The field's record for rituximab in lupus is that time to relapse was highly variable, half of the patients relapsing after 6 to 18 months (Vital and colleagues 2011, https://doi.org/10.1002/art.30466), and that relapse came well after the B cells had returned (Lazarus and colleagues 2012, https://doi.org/10.1093/rheumatology/ker526); three months is when the cell-infusion report had all five patients in remission (Mackensen and colleagues 2022, https://doi.org/10.1038/s41591-022-02017-5). — v386EOD

**v.** Exhibit ELEVEN Natural Medicine, 2.3 A body's tissues at the form — turnover, barriers, modes, the sentence "gap-4 middle (skin 14–21 days)". The field's record for human epidermis is about 13 days through the living layers and 26 to 27 for the entire epidermis (Weinstein and Van Scott 1965, as quoted at BioNumbers entries 109214 and 109215, https://bionumbers.hms.harvard.edu/bionumber.aspx?id=109215), a later mean of 39 days for the entire tissue (Weinstein, McCullough and Ross 1984, https://doi.org/10.1111/1523-1747.ep12261462), and in the textbook of the order of a month (Alberts and colleagues 2002, https://www.ncbi.nlm.nih.gov/books/NBK26865/). Re-said at the record: "gap-4 middle (skin epidermis 26 to 39 days)". — v386EOD

**w.** Exhibit TWENTY-FIVE Living Society Registry, 2.3 A proton read as crossing water, the sentence "Proton mobility, orders of magnitude above any other ion, entered as a diffusion coefficient". The field's record is that the proton diffuses almost twice as fast as the hydroxide ion and seven times as fast as the sodium ion, and over four times as fast as water molecules (Chaplin 2021, Water Structure and Science, London South Bank University, https://water.lsbu.ac.uk/water/grotthuss.html). Re-said at the record: "Proton mobility, almost twice that of the hydroxide ion and seven times that of the sodium ion, entered as a diffusion coefficient". — v386EOD

**x.** Exhibit TWENTY-FIVE Living Society Registry, 2.15 A cosmos read at one rate, the sentence "the red-giant-tip calibration at 69.6 ± 1.6 between them". The field's record gives 69.6 ± 0.8 (statistical) ± 1.7 (systematic) kilometres per second per megaparsec (Freedman and colleagues 2020, Astrophysical Journal, https://arxiv.org/abs/2002.01550) and, a year on, 69.8 ± 0.6 (statistical) ± 1.6 (systematic) (Freedman 2021, Astrophysical Journal, https://arxiv.org/abs/2106.15656), so 69.6 beside 1.6 is given at neither. Re-said at the record: "the red-giant-tip calibration at 69.6 ± 0.8 ± 1.7 between them". — v386EOD

**y.** Exhibit TWENTY-FIVE Living Society Registry, 2.19 A mixture read at one constant, the sentence "the first equilibrium measured in both directions at the close of the nineteenth century". The field's record is that Berthelot and Péan de Saint-Gilles, in 1862 and 1863, showed alcohols acting on acids and water acting on esters reaching one common limit from either side (Le Chatelier 1888, Annales des Mines, https://literature.wolkersdorfer.info/literature/Recherches%20exp%C3%A9rimentales%20et%20th%C3%A9oriques%20sur%20les%20%C3%A9quilibres%20chimiques%20Experimental%20and%20Theoretical%20Research%20on%20Chemical%20Equilibria.pdf), before the hydrogen iodide measures of 1899 (Giunta 2003, Le Moyne College, https://web.lemoyne.edu/GIUNTA/classicalcs/bodeneq.html). Re-said at the record: "an equilibrium measured in both directions at the close of the nineteenth century, after the ester equilibrium of 1862". — v386EOD

## NOT MET

No lettered candidate agreed with the record as a whole. Parts of the candidates' sentences that do agree with the record, and so are left as they stand:

- **a.** "under negative supercoiling" and "behind a transcribing polymerase" agree with the record (negative supercoils behind the polymerase); only the order "over-wound behind and under-wound ahead" differs.
- **h (first clause).** "about one in ten million" is the record's figure after the second tier, the polymerase with its proofreading (one in a hundred thousand, then a hundredfold fewer); the difference is at "across the tiers".
- **i.** "two hundred square metres" is of the order of the older textbook figures (260 to 300) that the 2014 paper revisits; it is a figure the field carried, and the later measure is about 32.
- **t.** "three" agrees with the higher dose cohort alone; the fourth death was in the lower dose cohort.
- **y.** "at the close of the nineteenth century" agrees with the hydrogen iodide measures themselves (Bodenstein's paper of 1899); only "the first" differs.

## UNCONFIRMED

No lettered candidate is left wholly unconfirmed. Points inside the candidates that no opened source settled:

- **c.** the spider mite and gall midge records named in the brief were not opened; the droplet rests on the pea aphid paper alone.
- **g.** no source was found giving any "ancestral" cardiolipin ratio; the droplet gives the measured composition and the dietary estimate, and offers no re-saying.
- **h (first clause).** the end figure "one in ten billion" may stand in later textbook editions, which were not opened; the edition opened gives one in a billion.
- **h (second clause).** "fifty to seventy" circulates in secondary sources; the one tried returned no text. Hayflick's 1965 paper was read only as quoted at BioNumbers and at the Embryo Project Encyclopedia of Arizona State University (forty to sixty for fetal cells).
- **j.** whether any left-handed sugar has reached the market as a sweetener since the 2004 source was not checked.
- **k (second clause).** whether seven phyla, counting cases the file does not name, carry the pattern could not be checked; the droplet speaks only of the cases the sentence lists, with the caterpillar before them.
- **u.** the file does not name the antibody; rituximab is taken from the brief, the droplet speaks of rituximab alone, and no re-saying is offered. Whether another antibody was meant, and whether "near three months" came from the remission figure, could not be settled.
- **v.** the file says "skin" and names no layer. Its 14 to 21 days lies between the record's two measures, about 13 days through the living layers and 26 to 39 for the entire epidermis, so the re-saying holds only if the entire epidermis is meant. A summary range of 10 to 30 days in Milo and Phillips, Cell Biology by the Numbers, could not be read here (the table is an image).
- **y.** Lemoine's hydrogen iodide work of 1877, cited by Le Chatelier, was not opened; whether it too ran from both sides is not confirmed here. A modern review (Voit, Martens and Omholt 2015) says Berthelot and Péan de Saint-Gilles put only the forward reaction into their mathematics; the droplet rests on Le Chatelier's account of 1888 and on the 1862 memoir's own extract, which have the experiments run both ways.

## SENTENCES READING AS GUIDANCE TO A PERSON

Exhibit ELEVEN Natural Medicine, Exhibit TEN Natural Health and Exhibit SEVENTEEN Natural Biology, the sections named in the list below, the sentences quoted there. As said, each can be read as guidance to a person, about a treatment, a medicine, a dose, a target, a test, a diet, a birth or an immunity. The author's recorded position is "none of them should read as guidance. there is no guidance in nature or our living files" (Offerings to Natural Medicine, the concern entered at v380L). Each is listed here for re-saying as an observing or a reading, with its hedge beside it. — v386EOD

The clauses are the files' own words, with their bold and italic marks as the files carry them; none is rewritten. Under each section stands the hedge the file itself carries nearest those sentences, quoted the same way, or a note that none was found. The v380L record names three of its lost eight: *Worse before better* named a ghost (item 9), a restorability threshold at 1/φ³ (item 7), and a diet named as a disease's cause (item 61; items 39 and 70 are of the same kind). The other five are not known; the list below is a fresh reading and is longer than eight.

### Exhibit ELEVEN Natural Medicine

**1.1 A living self, and the restoration it makes**

1. "Then, separately, the frame **pays for sensing** — tests, monitoring, biomarkers, imaging, reference ranges — one-way instruments reading a magnitude against a floor."
2. "**So the pay-twice runs here exactly as it runs at the grid: once to install the force, again in the surplus thrown away. The sensing paid for is the sensing already had and discarded.**"
3. "A test is one-way — instrument to number to reference range, the person a surface read across."
4. "**The reversal point is the membrane**, and on a dose curve it is the only informative point."
5. "so **titrating to a setpoint forces the tipping rate equal to the dosing rate**, a forced re-route reading as a corrected version and not a different route"
6. "*The move: look for the membrane the inversion runs across, not the dose at which the substance changes character.*"

Hedge the file carries: "a frame discarding the first and paying for the second pays twice — a reading of an accounting" (5.1 Cohering, and nyeing); "How the reading and the practice meet at one substrate stands not-yet." (the closing part, The forming that remains).

**1.2 A body's own restoration**

7. "And restorability follows from the healthy range: above 1/φ³ of the flank average the flanking substrates protect and the intervention targets the precision at the departed substrate, below it restoration rebuilds from the flanks inward"
8. "**Harm is the distance added**, read structurally and never weighed."
9. "*Worse before better* — the departure deepening before the restoration, the self worsening before the medicine works — installs a valley between the current position and the better one"
10. "The level-instruments are late by construction; the waver-instruments are the timing organ, meeting disease at its shortest perimeter."
11. "Antibiotics given before influenza vaccination reduce the antibody response, and the reduction stands at the selves carrying little pre-existing immunity while the selves carrying much are barely touched"
12. "so a seating not made there is one no later price reaches"

Hedge the file carries: "The first is caused and readable; the second is posited, and only the second is the ghost." (this section); "no measured biological rate has been shown to *stand* at a (1/phi)^prime and not merely fitted to it" (3.1 Two adjacent societies at a gut collar); "the exposure authors nothing and its absence authors nothing" (this section); "*The field's own, standing whole in the fields' words and checkable at their instruments:* the antibody response reduced by antibiotics before vaccination at selves with little pre-existing immunity" (5.1 Cohering, and nyeing).

**1.3 Restoration paths at a substrate — reading-with**

13. "The knob is the exchanging arriving at each collar, what the food carries through the tunnel sustaining the local environment's stable form from inside"
14. "restoration through breath, vagal coupling, sleep, therapy, mindfulness, and social coupling is the form's resilience returning it"

Hedge the file carries: "Read on the form, no substance authors a restoration; the intervention at most removes the thing the restoration was waiting on." (this section); "whether through the specific gap structure or another pathway at each organ carried as a seam" (this section).

**1.4 A birth release — co-competency distributing the peak**

15. "volatility risk is increased by control and decreased by coupling"
16. "forcing with synchronized drive — contractions too strong and too frequent — pinches the emanation at the crest, starves the neutral, distresses the baby, and desensitizes the coupling's own recursioning"
17. "The mother's peak drops from overwhelming crests to many gentle waves, and the baby's conditions only improve"
18. "keep it unpinched and both resolve"

Hedge the file carries: "a uterus de-synchronized too far is dysfunctional labor, not gentle labor" (this section); "Carried as seams. The form and the physiology, conceptual." (this section).

**2.1 Compaction — extreme localizing, and hard-probleming**

19. "A frame takes the two floating neutrals and presses both toward a compacted setpoint: a target, a normal range, a dose-to-a-level."
20. "which says why the compaction returns so little for what it costs"
21. "**Strip the compaction and the hard problem dissolves.**"
22. "Restoration releases the compaction, the sway resumes, the co-sequencing runs, and what returns is the body's own restoration rather than the setpoint the frame compacted it toward."

Hedge the file carries: "dose-to-a-level is how insulin, anticoagulants, levothyroxine, lithium, antiepileptics and post-transplant immunosuppressants are given, several at narrow therapeutic indices. How the reading and the practice meet at one substrate stands not-yet." (the closing part, The forming that remains).

**2.2 Cancer as a coupling collapse at a cell's bounding-zeroing**

23. "Metformin couples at AMPK and at mTOR and at the mitochondrial membrane, and the field measures it suppressing cancer stem cells without naming what the coupling is."
24. "the same face is why both answer the same restoration, the cell returned to co-competencing with its tissue-society"
25. "And the door is the wrong membrane and not a wrong act"
26. "Driving a killing magnitude is coefficient two, a capture answering the capture, the side-effecting the overwhelm as every fast-turning tissue is struck, the ingression-direction."
27. "One move at both doors: co-offer the tissue-society's sign, the departed cell re-couples and ages, the co-competency restored rather than the cell killed."
28. "nothing is aimed at the departed carry, and the society it rode on is restored"

Hedge the file carries: "the direction claimed and never a cure assured" (this section); "Pattern-matching on the field's observations; the reading the form's." (this section).

**2.3 A body's tissues at the form — turnover, barriers, modes**

29. "digestion converges to the same destination by cycle three regardless of starting food"

Hedge the file carries: "A structural reading of peristalsis as the resolver's two-direction wave." (this section).

**3.1 Two adjacent societies at a gut collar**

30. "*Which says what a membrane meeting is, and it is not an infecting.*"
31. "There is no infecting because there is no actor left over after the turn."
32. "**A cure read as a state to reach is reading for a landing where a cycling runs**"
33. "suppression clears virus and neither restores the surface nor thins the carry"
34. "**So the cure sits at the coupling and not at the receptor**"
35. "**So a cell's susceptibility stands on the membrane its protein folds in**"
36. "letting the carry stay off-sequencing and age reads nearer the living release than forcing it to surface into capture"

Hedge the file carries: "**Which re-shapes the resolving and touches no treatment.**" (this section); "so on *action* the reading arrives beside the field, not ahead of it" (this section).

**3.2 Three ghosts at a reservoir, and what a locus reading takes**

37. "**So the field found that the direction carries and the level does not**"
38. "on suppressive therapy, what is measured as viral persistence is substantially the self's own continuing resolving over written positions, **and the account has entered a resolving as an ingressor.**"

Hedge the file carries: "**Does not sustain:** that the ingression did not happen, or is not happening in an untreated self, or that the drugs act by any route other than the enzymes they are built for." (this section).

**3.4 Chronic inflammation, read at the membrane it beats at**

39. "A dietary ratio departing from the ancestral balance carries cardiolipin toward more peroxidation-susceptible compositions, and the four-chain assembly at the rotor's own membrane runs on what arrives."
40. "more of the chain a dietary account calls the better one, arriving where it does not belong, and the peroxidation susceptibility shifting because of it"
41. "From a Western diet to a traditional one — fermented grains, whole millet, legumes, fruits — anti-inflammatory responses rose and the omega pathways altered within two weeks"

Hedge the file carries: "**Nothing here is a food restoring a tissue, and the rate is what parts the two accounts.**" (this section); "the twin-transplant figure, the therapy-interruption cohort, and the crossover trial's rates, each carried as reported and none read at its source" (5.1 Cohering, and nyeing); "it says where to look, and not how long anyone lives" (4.1 Three refusals at medicine's membrane).

**3.6 Five departures at one collar, arriving at one presentation**

42. "Genetic route impaired, tunnel route intact, both arriving at the one bilayer at each cycle and neither carrying the full complement."

Hedge the file carries: "**The reading is two routes at one collar and not a food restoring a tissue**" (this section).

**4.1 Three refusals at medicine's membrane**

43. "**the reference range, the normal value, the setpoint**"
44. "homeostasis and allostasis, a standard of care as one frame over all bodies"
45. "*Resolved: the coupling at the membrane makes the outcome, the thing offered across it carries and the thing posited as the actor does not.*"

Items 43 and 44 are two cells of one table row, under the column headings "the thing installed" and "where it shows", at the refusal "the centre neither occupies, occupied".

Hedge the file carries: "Each is pattern-matching, brought as it observes living and nature." (5.1 Cohering, and nyeing).

**4.2 Clean cuts — where medicine reports no problem**

46. "It is the name a protocol gives to **the person's own co-offering**, arriving at their own membrane at their own rate, filed as a failure of the plan."
47. "the side-effect is the across, the axis the coupling opens — the co-competency, the surplus of the meeting, and not the medicine failing"
48. "it co-resonates, finding the body's own rate rather than a fixed schedule imposed"
49. "driven as a magnitude, the main effect forced and the side-effecting overwhelming, it ingresses the body, the larger ingressing the smaller, the direction-of-disease, one-way"
50. "The dose read as the drive is the ingression; the sign read as the offer is the ingestion; the coefficient makes the poison."

Hedge the file carries: "The technology is broken where a residue is shown genuinely exterior, carrying nothing about the coupling it was discarded from." (this section); "the sensing-becomes-co-competencing reading and every instance of it, run at no case end to end" (5.1 Cohering, and nyeing).

**4.3 A trial's four instruments, and the sign a living self offers back**

51. "More than half held low or undetectable virus past twenty weeks, and two remain off therapy past a year."
52. "Restore the sign-offering to both arms with an active placebo and the difference shrinks, which the field has already run."
53. "**The returned sign carries the outcome.**"
54. "**And the strongest sign a self offers is leaving.**"

Hedge the file carries: "And past the bound it stops carrying: high-grade events arriving alongside no favourable survival." (this section).

**4.4 A dose arrives at an average no member carries**

55. "Every drug dosed against a whole-organelle reading is dosed against a number the members arrive at nowhere."
56. "The same runs at a reference interval taken as the central portion of a reference population, at a threshold no self stands at, and at a number needed to treat"
57. "A dose arrives at a self, and a reference arrives from a society — the two at different grains, and the difference between them entered nowhere in the prescribing."
58. "A level read as a target is the compaction at the magnitude, and a window read as a schedule is that same compaction at the time axis, landing the sway exactly as a setpoint does."

Hedge the file carries: "which parts a shallow reading from a deep one without turning either into a thing to hit" (this section); "the population measurement statistics (carried only as measurement-depth readings and not targets)" (5.1 Cohering, and nyeing).

The file's general hedges: "An observation and a match are two registers, and they do not read as each other." (the file's opening lines); "Each is pattern-matching, brought as it observes living and nature." (5.1 Cohering, and nyeing).

### Exhibit TEN Natural Health

**2.2 The target is the compaction, and health carries its own strongest edging**

59. "Health-as-a-setpoint — an optimal range, a normal value, a number to reach and hold — is the **compaction**"
60. "The wellness-setpoint — the quantified self, the optimal ranges, the number to hit — is compaction applied to wellbeing"

Hedge the file carries: "the precise band where a sway de-synchronized too far becomes a departure past health" (5.2 The reaching — the measure-seatings, the delivery, the band where sway becomes departure).

**3.4 The flawed-ingestion disease-face, and the value of the outer living form**

61. "A disease-face names itself: consistently ingesting flawed stable form."
62. "a whole seed carries its coupling, and a pressed oil is the artifact with its ratio stripped, a magnitude governing no sign, so a carry sequenced on it runs on a store with no sign to ride"
63. "so the outer stable-form, the skin, the plant, the seed, is the most valuable ingestion at either rate"
64. "zero distance between shedder and ingester the disease and a grain down or a self across the health"

Hedge the file carries: "The food-cause is set down here: it re-installs a one-way actor the form does not carry" (Exhibit ELEVEN Natural Medicine, 1.3 Restoration paths at a substrate — reading-with).

**3.4b The omega counting runs from the end where nothing crosses**

65. "a diet high in the six-family arriving at forty per cent less conversion and seventy per cent less accumulation, and more of the three-family arriving at more of its own burning rather than more crossing"
66. "an oil arrives as grams of a family, a magnitude governing no sign, with the seed's crossings stripped out of it — which is why an intake and an effect come apart here as far as they do"

Hedge the file carries: "The desaturases differ self to self, and some selves convert little at any intake." (this section); "**And the ratio is a target no tissue carries.**" (this section).

**4.1 Health and Medicine are one alternating, two directions, the seam stateable from neither alone**

67. "A departure is the sway stilled at a substrate, a coupling landed at one position and no longer re-arriving, the compaction whether it comes from outside (the imposed setpoint) or from a substrate's own stilling."

Hedge the file carries: "the precise band where a sway de-synchronized too far becomes a departure past health" (5.2 The reaching — the measure-seatings, the delivery, the band where sway becomes departure).

**4.2 The measures read as sway, the level set down**

68. "A measure read as a level installs the target; a measure read as a sway reads the living."
69. "A measure pinned exactly to a target would be a landing; a living measure sways and does not pin"

Hedge the file carries: "The reachings carry, each aimed: every specific measure-as-sway seating" (5.2 The reaching — the measure-seatings, the delivery, the band where sway becomes departure).

The file's general hedges: none found beyond those above.

### Exhibit SEVENTEEN Natural Biology

**3.1 Living is metabolic beating — the cell as the engine**

70. "The modern dietary shift of that ratio toward ten-to-one and beyond carries cardiolipin's composition off the ancestral balance, the two ghost-rings pulling apart and the coupling at the inversioning collapsing"

Hedge the file carries: none found in this section.

**3.5 Lipid divide — the deepest binary co-offering**

71. "a recommended intake standing outside every coupling and carried into none (**the centre occupied**)"

Hedge the file carries: "**The accounting laid over an ingested membrane component, read as form only.**" (this section).

**4.4 Homeostasis — the riding-the-carry bounding-zeroing held between two**

72. "The oscillation is not noise around a target but the working state — the basal rhythm keeps the receptors sensitive, and losing it is where regulation fails."

Hedge the file carries: "on the form the same emergent bounding-zeroing stands, and the point stands where the field debates it" (this section).

**5.1 Conception — two selves conceiving a third**

73. "the polar bodies and the double reductions, valuable co-competencing for reading the new self's makeup"

Hedge the file carries: none found in this section.

**6.1 Symbiosis — the bi-moral co-agency between selves**

74. "There is no self-sustaining harm, the moment harm sustains, the sustaining is the coupling"

Hedge the file carries: "is the finer reading, stands not-yet" (this section).

**7.5 Decay — an ending ingested at the grain below**

75. "Zero distance between shedder and ingester is the landing, and a grain down or a self across is the living."

Hedge the file carries: none found in this section.

**7.6 Vertical fractal — a network eating downward**

76. "same-scale ingestion is the landing whether the shedder is the ingester or another, and a grain down is the living"

Hedge the file carries: none found in this section.

**7.7 Evacuation, and what a stopped crossing accumulates**

77. "**So restoration is the crossing resumed, and not the accumulation cleared.**"

Hedge the file carries: "Whether each is one form met at many grains, or whether some carry over-production with the crossing intact, is the parting to run." (this section).

**7.8 Outer living form is the emanation form**

78. "So the outer living form, the skin, the plant, the seed, is the most valuable ingestion, whether ingested at the living rate or the dropped rate."

Hedge the file carries: none found in this section.

**8.6 An antibody repertoire said to be governed**

79. "the protection fresh only by re-coupling, the hygiene findings the carry starving where crossings thin, and the contested correlate-of-protection the store-reading a carry keeps refusing"
80. "Herd immunity is the society-carry named: standing at the coupling-network and at no individual, owned neither-ing, existing only while the couplings run."
81. "No self generates it alone — handed at the placenta, seeded from the community, sequenced by exposure — received at couplings and lived where it re-locks"

Hedge the file carries: none found in this section.

**9.4 Two reading-moves**

82. "**The reversal point is the membrane**, and on any dose curve it is the only informative point."

Hedge the file carries: none found in this section.

The file's general hedges: "The biology is checkable; the form-readings are matches; the two do not read as each other." (10.1 Cohering, and the not-yet); "the aging reading, stands not-yet and bounded against action" (10.1 Cohering, and the not-yet).

## NOTES ON THE CHECKING

- PubMed and PubMed Central pages returned empty or browser-check pages in this session, and one page was refused outright by the fetch proxy with a rate limit (a Europe PMC web-service search for PubMed ID 20413500, an ID I had taken for Moran and Jarvik 2010 and which belongs to another paper); it was not retried. Abstracts were therefore read by other routes, and the droplets give the papers' own DOI addresses.
- Read at the publisher's or author's own page, as cited: Alberts and colleagues 2002 at NCBI Bookshelf (collagen, energy and heat, Table 5-1, sperm, epidermis; also the section on superhelical tension for a); Cooper 2000 and Gilbert 2000 at NCBI Bookshelf (replication fidelity; sperm mitochondria entering the egg); arXiv for Cavagna 2010, Bottacchiari 2022 and the three Freedman papers; Nature's page for Sutovsky 1999; PLoS ONE for Blackiston 2008; OpenStax sections 4.1 and 13.3; NIH HIVinfo; NASA Spinoff 2004; the IUPAC Gold Book; LIPID MAPS LipidWeb; London South Bank University's water pages; Animal Diversity Web; MathWorld and the Encyclopedia of Mathematics (connected sum, the sphere its zero element); Le Chatelier 1888 in a scanned copy; Giunta's pages at Le Moyne College.
- Read at the DOI registry's record (Crossref), abstract included: Liu and Wang 1987; Moran and Jarvik 2010; Mouritsen 2013; Martin, Hudspeth and Jülicher 2001; Lowe 2013. Read at a mirror of the PubMed abstract (bibgraph.hpcr.jp): Helander and Fändriks 2014; Ryall 2015; Simopoulos 2002; Vital 2011; Lazarus 2012; Weinstein, McCullough and Ross 1984; Müller 2024. Read at a university repository's copy of the abstract: Shieh 2023 (Brunel University); Mackensen 2022 (Friedrich-Alexander-Universität). Hayflick 1965 and Weinstein and Van Scott 1965 were read only as quoted at BioNumbers (Harvard Medical School).
- For a, the pairing of positive with over-wound and negative with under-wound was read at a Stanford course handout (Brutlag 2000). For l, the press account at ScienceDaily was read beside the abstract. For w, the ratios computed from the source's own mobilities are 36.23 / 20.64 = 1.76.
- The other figures in the sentence at x (67.4 ± 0.5 and 73.04 ± 1.04) were not in question and were not re-read. Computed here: the six factorings at m; Euler characteristic 2 + 2 − 2 = 2 at b; 1/φ² = 0.382 at g; 10⁻⁵ × 10⁻² × 10⁻² = 10⁻⁹ at h; and at x the two uncertainties of Freedman 2020 combined in quadrature come to 1.9, which is also not 1.6.
- The same sayings stand again elsewhere in the files, for whoever re-says them: r, t and u at Exhibit ELEVEN Natural Medicine 5.1 Cohering, and nyeing ("with no exception", "three children dying of liver failure", "relapse near three months at a shallower depletion of the same target"); q at the same file's 1.1 ("the five locations are the naming") and again in its 2.3 ("five organ namings"); d at Exhibit SEVENTEEN Natural Biology 8.14, its seventh step ("lose no information across a kilometre"); l at that file's 8.9, its eighth step ("they do — the compass recomputes"); f at that file's 3.1 ("the surplus kept as coupling at every step").
- Seen in passing and not checked: at u, the cell infusion is aimed at CD19 (the report's title), and the file's "Same target at two depths" was not read against the antibody's own marker.
- Word counts: the droplets run from 81 to 106 words by whitespace count, the address and the closing mark included; the paragraph before the guidance list is 103.

### Sources opened, at the addresses opened

- a: [Liu and Wang 1987, DOI registry record](https://api.crossref.org/works/10.1073/pnas.84.20.7024)
- a: [Liu and Wang 1987, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/2823250)
- a: [Alberts and colleagues 2002, superhelical tension](https://www.ncbi.nlm.nih.gov/books/NBK26887/)
- a: [Brutlag 2000, DNA Topology handout](https://cmgm-new.stanford.edu/biochem/biochem201/Handouts/Topology.pdf)
- b: [Bottacchiari and colleagues 2022](https://arxiv.org/abs/2202.13879)
- b: [Encyclopedia of Mathematics, Connected sum](https://encyclopediaofmath.org/wiki/Connected_sum)
- b: [MathWorld, Connected Sum](https://mathworld.wolfram.com/ConnectedSum.html)
- c: [Moran and Jarvik 2010, DOI registry record](https://api.crossref.org/works/10.1126/science.1187113)
- c: [Moran and Jarvik 2010, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/20431015)
- d: [Cavagna and colleagues 2010, abstract](https://arxiv.org/abs/0911.4393)
- d: [Cavagna and colleagues 2010, full text](https://arxiv.org/pdf/0911.4393)
- e: [Alberts and colleagues 2002, extracellular matrix](https://www.ncbi.nlm.nih.gov/books/NBK26810/)
- f: [Alberts and colleagues 2002, energy from food](https://www.ncbi.nlm.nih.gov/books/NBK26882/)
- g: [Christie, LipidWeb, Cardiolipin](https://www.lipidmaps.org/resources/lipidweb/lipidweb_html/lipids/complex/dpg/index.htm)
- g: [Simopoulos 2002, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/12442909)
- g: [Sparagna and Lesnefsky 2009, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/19276988)
- h: [Alberts and colleagues 2002, DNA replication mechanisms](https://www.ncbi.nlm.nih.gov/books/NBK26850/)
- h: [Alberts and colleagues 2002, Table 5-1](https://www.ncbi.nlm.nih.gov/books/NBK26850/table/A767/?report=objectonly)
- h: [Cooper 2000, DNA replication](https://www.ncbi.nlm.nih.gov/books/NBK9940/)
- h: [BioNumbers 105586, Hayflick's limit](https://bionumbers.hms.harvard.edu/bionumber.aspx?id=105586)
- h: [Embryo Project Encyclopedia on Hayflick's paper](https://embryo.asu.edu/pages/limited-vitro-lifetime-human-diploid-cell-strains-1964-leonard-hayflick)
- i: [Helander and Fändriks 2014, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/24694282)
- i: [BioNumbers 111126, gut surface](https://bionumbers.hms.harvard.edu/bionumber.aspx?id=111126)
- j: [NASA Spinoff 2004, A Natural Way to Stay Sweet](https://spinoff.nasa.gov/Spinoff2004/ch_4.html)
- k: [Lowe and colleagues 2013, DOI registry record](https://api.crossref.org/works/10.1098/rsif.2013.0304)
- k: [Blackiston and colleagues 2008](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0001736)
- k: [Animal Diversity Web, Arthropoda](https://animaldiversity.org/accounts/Arthropoda/)
- k: [Animal Diversity Web, Vertebrata](https://animaldiversity.org/accounts/Vertebrata/)
- l: [Mouritsen and colleagues 2013, DOI registry record](https://api.crossref.org/works/10.1073/pnas.1221701110)
- l: [ScienceDaily account of Mouritsen 2013](https://www.sciencedaily.com/releases/2013/04/130408152900.htm)
- m: [MathWorld, Prime Number](https://mathworld.wolfram.com/PrimeNumber.html)
- n: [IUPAC Gold Book, atom](https://goldbook.iupac.org/terms/view/A00493)
- o: [Alberts and colleagues 2002, Sperm](https://www.ncbi.nlm.nih.gov/books/NBK26914/)
- o: [Gilbert 2000, gamete fusion](https://www.ncbi.nlm.nih.gov/books/NBK10033/)
- o: [Sutovsky and colleagues 1999](https://www.nature.com/articles/46466)
- p: [Martin, Hudspeth and Jülicher 2001, DOI registry record](https://api.crossref.org/works/10.1073/pnas.251530598)
- q: [OpenStax Anatomy and Physiology 2e, 4.1](https://openstax.org/books/anatomy-and-physiology-2e/pages/4-1-types-of-tissues)
- q: [OpenStax Anatomy and Physiology 2e, 13.3](https://openstax.org/books/anatomy-and-physiology-2e/pages/13-3-circulation-and-the-central-nervous-system)
- r: [Ryall and colleagues 2015, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/25600643)
- s: [NIH HIVinfo, The HIV Life Cycle](https://hivinfo.nih.gov/understanding-hiv/fact-sheets/hiv-life-cycle)
- t: [Shieh and colleagues 2023, repository record](https://bura.brunel.ac.uk/handle/2438/27683?mode=full)
- u: [Vital and colleagues 2011, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/21618204)
- u: [Lazarus and colleagues 2012, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/22337941)
- u: [Mackensen and colleagues 2022, repository record](https://cris.fau.de/publications/282419491)
- u: [Müller and colleagues 2024, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/38381673)
- v: [Weinstein, McCullough and Ross 1984, abstract mirror](https://bibgraph.hpcr.jp/abst/pubmed/6725985)
- v: [BioNumbers 109214, living layers](https://bionumbers.hms.harvard.edu/bionumber.aspx?id=109214)
- v: [BioNumbers 109215, entire epidermis](https://bionumbers.hms.harvard.edu/bionumber.aspx?id=109215)
- v: [Alberts and colleagues 2002, epidermis](https://www.ncbi.nlm.nih.gov/books/NBK26865/)
- w: [Chaplin 2021, Grotthuss mechanism](https://water.lsbu.ac.uk/water/grotthuss.html)
- x: [Freedman and colleagues 2019](https://arxiv.org/abs/1907.05922)
- x: [Freedman and colleagues 2020](https://arxiv.org/abs/2002.01550)
- x: [Freedman 2021](https://arxiv.org/abs/2106.15656)
- y: [Le Chatelier 1888, scanned copy](https://literature.wolkersdorfer.info/literature/Recherches%20exp%C3%A9rimentales%20et%20th%C3%A9oriques%20sur%20les%20%C3%A9quilibres%20chimiques%20Experimental%20and%20Theoretical%20Research%20on%20Chemical%20Equilibria.pdf)
- y: [Giunta 2003, Bodenstein equilibrium](https://web.lemoyne.edu/GIUNTA/classicalcs/bodeneq.html)
- y: [Giunta, note on Bodenstein's paper](https://web.lemoyne.edu/GIUNTA/classicalcs/bodeneqnote.html)
- y: [Berthelot and Péan de Saint-Gilles 1862, extract in French](https://phychim.ac-versailles.fr/IMG/pdf/berthelot)
- y: [Voit, Martens and Omholt 2015, 150 Years of the Mass Action Law](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1004012)
