# Droplets, batch 1 — Exhibit EIGHTEEN Natural Physics, Exhibit SIXTEEN Natural Chemistry, Exhibit TWENTY-NINE Natural Illustrating

Session v386EOD. Files read (read-only, unchanged): Exhibit_EIGHTEEN_Natural_Physics_v385R.md, Exhibit_SIXTEEN_Natural_Chemistry_v346c.md, Exhibit_TWENTY-NINE_Natural_Illustrating_v385R.md, Exhibit_THREE_Natural_Numbers_v380L.md (and, for naming only, Exhibit_TWENTY_Natural_Naming_v385R.md and Exhibit_FOUR_Natural_Mathematics_v380L.md).

Result: all 22 candidate sentences were found. 15 MET (droplets below), 7 NOT MET (one of them, d, an internal parting between files), 0 UNCONFIRMED. Every droplet is 93 to 107 words by whitespace count, signature included; each quoted clause was checked by program to be an exact string inside the named section. The notes under the droplets are for the session and are not part of the droplets.

## MET

**a.**

Exhibit EIGHTEEN Natural Physics, 2.6 Geodesic method at physics, general relativity its first case: the sentence "A geodesic is the shortest path between two references on a curved surface". The field's record names a geodesic a path of stationary length, shortest only between near points, and in general relativity, this section's first case, a free body's geodesic through spacetime is the path of locally greatest proper time (Carroll, 1997, Lecture Notes on General Relativity, https://ned.ipac.caltech.edu/level5/March01/Carroll3/Carroll3.html). Re-said at the record: "A geodesic is the straightest path between two references on a curved surface, and in spacetime the path of greatest proper time." — v386EOD

> Note (narrow): on a surface the sentence is the common definition up to the word "locally"; the record parts from it most at general relativity, which the section names its first case. Carroll: timelike geodesics "maximize the proper time", and "every time we say 'maximize' or 'minimize' we should add the modifier 'locally'"; on a sphere both great-circle arcs "are stationary points of the length functional".

**b.**

Exhibit EIGHTEEN Natural Physics, 2.6 Geodesic method at physics, general relativity its first case: the sentence "General relativity's success — the most precise theory physics has". The field's record gives that place to quantum electrodynamics, "the best-tested theory in physics" (Max Planck Society, 2023, https://www.mpg.de/20922980/precise-testing-of-quantum-electrodynamics): the electron's magnetic moment meets its prediction to one part in a trillion (Fan and colleagues, 2023, https://arxiv.org/abs/2209.13084), where general relativity's gravitational-wave prediction is met at the double pulsar to 1.3 parts in ten thousand (Kramer and colleagues, 2021, https://arxiv.org/abs/2112.06795). Re-said at the record: "General relativity's success — a precisely tested theory, quantum electrodynamics the most precise physics has". — v386EOD

> Note: aimed at 2.6; the same phrase stands at 5.1 ("physics's own most precise theory"). The plural at 4.7 is under NOT MET. Also opened: Physics Today (2006), quantum electrodynamics "already the most precisely verified theory in all the natural sciences". For balance: null tests of the equivalence principle, a founding principle general relativity shares with other metric theories, reach 2 × 10⁻¹³ (Will, 2014, Living Reviews in Relativity); the droplet compares predicted numbers with measured ones.

**c.**

Exhibit EIGHTEEN Natural Physics, 3.1 An atom at two faces, and the periodic table a catalog: the sentence "element one hundred eighteen sits formally in that same column and arrives as neither noble nor a gas". The field's record carries this as calculation, with no measurement yet: five atoms of oganesson have been made, half-life under a millisecond, and relativistic calculation gives a melting point near 325 K, a solid at ambient conditions (Smits and colleagues, 2020, Angewandte Chemie, https://mro.massey.ac.nz/handle/10179/70598). Re-said at the record: "element one hundred eighteen sits formally in that same column and is calculated to be neither noble nor a gas." — v386EOD

> Note (narrow): the parting is one of standing, calculation beside observation. Exhibit SIXTEEN Natural Chemistry 4.4 already carries the record's wording ("is predicted to be much more polarizable and reactive and unlikely to be gaseous under ordinary conditions"; "the claim calculation-led, a few short-lived atoms made").

**e.**

Exhibit EIGHTEEN Natural Physics, 4.4 Measurement and Bell's correlations, one coupling at two faces: the sentence "Bell's theorem proved the local hidden variable false". The field's record divides the work: the theorem proves that no theory meeting its locality conditions, with settings chosen independently of the source, can reproduce quantum mechanics' correlations, and experiments find which holds: Aspect's in 1982 and, loopholes closed, Hensen's, Giustina's and Shalm's in 2015 (Myrvold, Genovese and Shimony, 2024, Stanford Encyclopedia of Philosophy, https://plato.stanford.edu/entries/bell-theorem/). Re-said at the record: "Bell's theorem proved the local hidden variable unable to give quantum mechanics' correlations, and the experiments measured those correlations." — v386EOD

> Note: the word "false" here is the file's own, inside the quoted clause. If a droplet without that word is wanted, the next clause of the same sentence can stand in its place: "proved there is no carried source, no stored variable transmitted from the shared origin". The same matter stands at 5.1 ("Bell's theorem establishes there is no local hidden variable"). Record details: Hensen and colleagues (2015), S = 2.42 ± 0.20 over 245 trials at 1.3 km, P = 0.039, "rejection of the local-realist null hypothesis"; the encyclopedia entry keeps the de Broglie–Bohm theory as a working hidden-variables theory that is not local, and names superdeterminism as the remaining way round.

**f.**

Exhibit EIGHTEEN Natural Physics, 4.5 Energy and entropy, two accountings at two fixings: the sentence "Holding time-translation still gives reversible laws". The field's record pairs symmetry under translation in time with the conservation of energy, as this section says at Noether's theorem, and keeps reversibility as another symmetry, reversal of time, listed apart from translation in time (Feynman, Leighton and Sands, 1963, The Feynman Lectures on Physics, volume I, chapter 52, https://www.feynmanlectures.caltech.edu/I_52.html). Re-said at the record: "Holding time-reversal still gives reversible laws; holding a nearness of reading still gives a one-way tally." — v386EOD

> Note: the table three paragraphs on pairs "time-translation" with "the arrow"; the record pairs the arrow with reversal of time (Callender, Stanford Encyclopedia of Philosophy, "Thermodynamic Asymmetry in Time": the puzzle arises from fundamental physics being "time reversal invariant").

**g.**

Exhibit EIGHTEEN Natural Physics, 4.5 Energy and entropy, two accountings at two fixings: the sentence "And momentum, angular momentum, charge and phase-space volume carry no anomaly at all — no question, no problem, no literature". The field's record keeps angular momentum conserved and carries a standing problem at its accounting, the proton spin puzzle: the quarks' spins, as measured since 1988, supply only about a third of the proton's spin, and how the rest is built is still asked (Aidala, Bass, Hasch and Mallot, 2013, https://arxiv.org/abs/1209.2803). This file's register at 5.11 lists "Proton spin decomposition" as standing. — v386EOD

> Note: no "Re-said" line, since the record supplies the angular-momentum part only; the record does not question the conserving itself. Register row as it stands at 5.11: "| Proton spin decomposition | a sign held as a magnitude | standing |". Aidala and colleagues: "How is the spin ½ of the proton built up from the spin and orbital angular momentum of the quarks and gluons inside?"; quark-spin share 0.33 ± 0.03 ± 0.05.

**h.**

Exhibit EIGHTEEN Natural Physics, 4.7 Relativity and quantum, one coupling and its accounting: the sentence "the diamond cubic lattice is two interpenetrating face-centered cubic lattices displaced a quarter of the cube edge". The field's record displaces one lattice from the other by (a/4)(1,1,1) along the cube's body diagonal: a quarter of the edge a along each of the three axes, a length of 0.433 a where a quarter of the edge is 0.25 a (Ungersböck, 2007, Technische Universität Wien, https://iue.tuwien.ac.at/phd/ungersboeck/node27.html). Re-said at the record: "the diamond cubic lattice is two interpenetrating face-centered cubic lattices displaced a quarter of the cube's body diagonal." — v386EOD

> Note: arithmetic. |(a/4)(1,1,1)| = (a/4)·√3 = 0.4330 a; the body diagonal is a·√3 = 1.732 a, and a quarter of it is 0.433 a; a quarter of the edge is 0.250 a. Also opened: Nisoli, Semiconductor Laser Photonics (Cambridge University Press), "displaced from each other along the body diagonal of the cubic cell by one quarter the length of the diagonal"; TU Delft Open Solid State Notes, nearest-neighbour distance √3·a/4.

**k.**

Exhibit EIGHTEEN Natural Physics, 4.11 A slight measured difference, and a substance named to close it: the sentence "Equilibrium expected the rate to fall to rest at the edge (Kepler, a landing toward zero)". The field's record of Kepler's third law gives an orbital speed falling as the inverse square root of distance, zero at no finite radius: 29.8 km/s at Earth and 5.4 km/s at Neptune, thirty times farther (Williams, 2025, NASA Planetary Fact Sheet, https://nssdc.gsfc.nasa.gov/planetary/factsheet/). Re-said at the record: "Equilibrium expected the rate to fall as the inverse square root of distance (Kepler, a decline reaching zero at no edge)." — v386EOD

> Note: arithmetic. T² ∝ r³ gives v = 2πr/T ∝ r^(−1/2); check: 29.8 ÷ √(4515.0 ÷ 149.6) = 29.8 ÷ 5.49 = 5.4 km/s, the listed value for Neptune. For galaxies the field's name for that fall is a "Keplerian" curve, V ∝ R^(−1/2) (Honma and Sofue, 1997); "Few spirals exhibit a true Keplerian decline" (Sofue and Rubin, 2001).

**m.**

Exhibit SIXTEEN Natural Chemistry, 4.4 Elements the doubling face, one recursioning counted one hundred eighteen times: the sentence "and the shells themselves complete at 2, 10, 30 and 70". The field's record of ground-state configurations has the first four shells full first at helium 2, neon 10, copper 29 ([Ar] 3d¹⁰ 4s¹, as this file carries it at 4.6) and ytterbium 70; zinc at 30 adds the second 4s electron, and the capacities sum to 2, 10, 28 and 60 (National Institute of Standards and Technology, 2015, https://www.nist.gov/pml/atomic-reference-data-electronic-structure-calculations/atomic-reference-data-electronic-8). Re-said at the record: "and the shells themselves complete at 2, 10, 29 and 70." — v386EOD

> Note (narrow, one place in four): arithmetic of the capacities: 2, 2 + 8 = 10, 10 + 18 = 28, 28 + 32 = 60. The file's 30 and 70 are the atomic numbers where the regular filling order completes 3d and 4f, zinc and ytterbium; the measured ground states complete the third shell one place sooner, at copper. Listed at the source: Cu [Ar] 3d¹⁰ 4s¹, Zn [Ar] 3d¹⁰ 4s², Pd [Kr] 4d¹⁰, Tm [Xe] 4f¹³ 6s², Yb [Xe] 4f¹⁴ 6s².

**n.**

Exhibit SIXTEEN Natural Chemistry, 5.2 Catalysis competency made at the coupling, carried to its own bound: the sentence "the inverted region, predicted at 1956 and observed at Closs and Miller's rigid donor–acceptor series in 1984". The field's record, in Marcus's own account, has the theory's first papers at 1956 and the inverted region predicted in his 1960 paper, then confirmed in 1984 by Miller, Calcaterra and Closs, "almost 25 years after it was predicted" (Marcus, 1992, Nobel Lecture, https://www.nobelprize.org/uploads/2018/06/marcus-lecture.pdf). Re-said at the record: "the inverted region, predicted at 1960 and observed at Closs and Miller's rigid donor–acceptor series in 1984." — v386EOD

> Note: Marcus's lecture: "Another prediction in the 1960 paper concerned what I termed there the inverted region". Its references: J. Chem. Phys. 24, 966 and 979 (1956); Discussions of the Faraday Society 29, 21 (1960); Miller, Calcaterra and Closs, J. Am. Chem. Soc. 106, 3047 (1984).

**o.**

Exhibit SIXTEEN Natural Chemistry, 6.1 Three declared nothings, and a partition the instrument's own coupling: the sentence "the triple point is the field's one point of zero degrees of freedom". The field's record gives zero degrees of freedom wherever three phases of one component meet, and water carries several such points: ice, liquid and vapour at 273.16 K and 611.657 Pa, and four more along its melting curves, among them ice Ih, ice III and liquid at 251.165 K (International Association for the Properties of Water and Steam, 2011, https://iapws.org/documents/release/MeltSub.download). Re-said at the record: "the triple point is a point of zero degrees of freedom." — v386EOD

> Note: the five points listed: 273.16 K and 611.657 Pa (ice, liquid, vapour); 251.165 K and 208.566 MPa (ice Ih, ice III, liquid); 256.164 K and 350.1 MPa (ice III, ice V, liquid); 273.31 K and 632.4 MPa (ice V, ice VI, liquid); 355 K and 2216 MPa (ice VI, ice VII, liquid).

**q.**

Exhibit TWENTY-NINE Natural Illustrating, 5.2 Light, spin and the click: the sentence "circular polarization the spiral at its two hands, light always at a hand". The field's record has a photon's angular momentum along its beam at plus or minus one unit, with no zero case, and linearly polarized light as the two hands superposed in equal measure, its average angular momentum zero (Feynman, Leighton and Sands, 1965, The Feynman Lectures on Physics, volume III, chapter 17, https://www.feynmanlectures.caltech.edu/III_17.html). Re-said at the record: "circular polarization the spiral at its two hands, light read at one hand or the other, linear polarization both hands equally." — v386EOD

> Note (narrow): "no zero case" is the record, and the source sentence at Exhibit EIGHTEEN Natural Physics 3.3 carries it ("the two helicities ±1, no zero, light always at a hand"); the droplet adds linear polarization, which the clause here leaves out. Feynman: linearly polarized light "has equal probabilities to appear with plus or minus one unit of angular momentum", and "the average angular momentum is zero".

**s.**

Exhibit TWENTY-NINE Natural Illustrating, 5.4 Earth, matter and phases: the sentence "the trap that works is the Paul trap, trapping by alternating". The field's record has two ion traps at work: the Paul trap, confining by radio-frequency fields, and the Penning trap, using "a static uniform magnetic field and a static electric field" (Bollinger, Wineland and Dubin, 1994, Physics of Plasmas, https://tf.nist.gov/general/pdf/1034.pdf). Re-said at the record: "a trap that works is the Paul trap, trapping by alternating, and another is the Penning trap, trapping by static magnetic and electric fields together." — v386EOD

> Note: the same clause stands at Exhibit EIGHTEEN Natural Physics 3.5 ("the trap that works is the Paul trap, holding by alternating"). The Royal Swedish Academy's 1989 press release names both: the "Paul trap" and "Another kind of ion trap, the 'Penning trap'". Bollinger and colleagues: "A Paul trap confines charged particles by the ponderomotive force provided by inhomogeneous oscillating electric fields."

**u.**

Exhibit TWENTY-NINE Natural Illustrating, 5.3 Cosmos: the sentence "the belt emptied at the rational resonances and the irrational orbits carrying on". The field's record has the belt emptied at some resonances with Jupiter and gathered at others: gaps at 3:1, 5:2, 7:3 and 2:1, the Kirkwood gaps (Jet Propulsion Laboratory, 2007, https://ssd.jpl.nasa.gov/diagrams/mb_hist.html), and major concentrations of asteroids at 3:2 and at 1:1, the Trojans (Swinburne University of Technology, undated, https://astronomy.swinburne.edu.au/cosmos/K/Kirkwood+Gaps). Re-said at the record: "the belt emptied at the resonances 3:1, 5:2, 7:3 and 2:1 and gathered at 3:2 and 1:1, the irrational orbits carrying on." — v386EOD

> Note: the fuller record already stands in the project's own proposed carrying (carryings/natural_physics_v377: "gaps in the asteroid belt at the resonances 3:1, 5:2, 7:3 and 2:1 with Jupiter, the Kirkwood gaps, while at 3:2 and 1:1 asteroids gather, the Hildas and the Trojans"); the clause here follows the shorter line in carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md.

**v.**

Exhibit TWENTY-NINE Natural Illustrating, 5.6 Bodies and life: the sentence "a change rippling across the flock in less than a fifth of a second". The field's record has a turn opening at a few neighbouring birds and travelling through the flock bird to bird at a constant speed, so the crossing time grows with the flock: a little more than half a second across 400 starlings (Attanasi and colleagues, 2014, Nature Physics 10, 691–696, https://www.nature.com/articles/nphys3035; Science News, 2014, https://www.sciencenews.org/article/birds-turns-match-math-quantum-matter). Re-said at the record: "a change rippling across a flock of four hundred in a little more than half a second." — v386EOD

> Note: the clause comes from Exhibit SEVENTEEN Natural Biology 8.14 ("a directional change rippling across the whole flock in less than a fifth of a second"). The preprint's table lists twelve flocks of 50 to 595 birds, speeds of 9.4 to 21.3 m/s, and 25 to 100 ms for the turn to pass one neighbour spacing; reports of the published paper give 20 to 40 m/s. The published full text is behind a subscription and was not opened, so the droplet names no speed.

## NOT MET

**b (the 4.7 clause).** "Both are the most precise theories physics has" is said of general relativity and quantum mechanics together, under "as the field states it"; quantum theory holds quantum electrodynamics, so the plural agrees with the record. (The 2.6 clause is under MET.)

**d.** Not a field matter: "Two and one hundred eighteen stand antipodal" is the project's own pairing word, used two ways across files. Reported below as an internal parting, with the quotes and the ring arithmetic.

**i.** "(presentism and eternalism, McTaggart)" lists McTaggart beside the two positions under one claiming and says nothing of who gave what. The record has McTaggart's 1908 argument with its two orderings, the A series and the B series, and treats presentism and eternalism as a separate question of what exists (Emery, Markosian and Sullivan, Stanford Encyclopedia of Philosophy, "Time", revised 2025, https://plato.stanford.edu/entries/time/). The grouping is the project's own reading.

**j.** The section's sentences agree with the record's inverse relation of temperature to mass ("small fold hot and fast, the largest fold coldest and slowest"; "the largest black hole nearing that cold by folding"); no sentence has an evaporating hole growing colder. The record adds only that the temperature rises as the mass falls (Hawking, 1974, Nature 248, 30, https://www.nature.com/articles/248030a0).

**l.** The Born rule is stated as the record has it ("amplitude squared normalized to one"); "the landed softmax" is the project's own naming. Arithmetic: a softmax over the scores z = ln|c|² returns |c|²/Σ|c|², so the two share the dividing-to-one and part at the map before it, the exponential of a real score beside the squared size of a complex amplitude.

**p.** "For a decade" matches the record's span (2010 to about 2019), and until 2017 the readings did sort by probe; "the same lesson" is the project's own reading. The record's close is not in the sentence: since 2017 electron probes have returned the smaller reading too, and one radius, 0.84075(64) fm, is recommended, some tension remaining (Particle Data Group, 2026, https://pdglive.lbl.gov/view/S016CR). An optional draft carrying that close is given below, outside the MET set.

**r.** "Parity" is the project's own word for the + or − sign (Exhibit TWENTY-NINE Natural Illustrating 1.6: "+ and − are the parity set"; Exhibit TWENTY Natural Naming 2.4 releases "sign" to "parity"), and the source sentences say "sign" (Exhibit FOUR Natural Mathematics 3.1: "comes back with its sign reversed"). Read so, both clauses agree with the record: the 21-centimetre line is the electron's spin turning against the proton's, and at 360 degrees "all amplitudes simply change sign" (Feynman Lectures on Physics III, chapters 12 and 6). One thing for the naming: in physics "parity" names the mirror inversion of space, which neither event changes.

**t.** "iron not a peak two processes approach but the centreline the two phases float about" is the project's own reading of the curve. The record itself is stated at Exhibit EIGHTEEN Natural Physics 4.3 ("peaks near iron-56 (~8.8 MeV/nucleon)"; "iron-56 the field's cited peak, nickel-62 marginally higher") and agrees with Fewell (1995, American Journal of Physics 63, 653, https://ui.adsabs.harvard.edu/abs/1995AmJPh..63..653F/abstract): nickel-62 highest, with iron-58 also above iron-56.

## UNCONFIRMED

None. Each MET and NOT MET above rests on a source that was opened, or on arithmetic shown.

Pages that could not be read (none left a candidate unsettled):
- Europe PMC record for the oganesson paper: refused by the fetch proxy with HTTP 429, a rate limit, and not retried. The same abstract was read at Massey University's repository.
- PubMed and PubMed Central pages (oganesson paper; starling paper): a browser-check page, no content. Wiley's page for the oganesson paper and Science's page for Bezginov and colleagues (2019): the fetch did not complete; Bezginov's value was read from the Particle Data Group listing.
- Nature Physics full text of Attanasi and colleagues (2014): abstract only, the rest behind a subscription.
- NIST's constants value page and the INSPIRE record: no content returned. The IAPWS release was read at a second address after the first returned a landing page.

## Internal parting between files (d) — not a field droplet

One pairing word, used two ways. Arithmetic on a ring of 120 stations: 120 − 2 = 118, four stations from 2 by the shorter way round (118, 119, 120 or 0, 1, 2); 2 + 60 = 62, sixty stations from 2, straight across.

- Exhibit THREE Natural Numbers, 5.6 Ten, nine and eight, one pairing at its two sides: "Podaling is one station at its two sides, a carry one way at k and a carry the other way at N − k on a ring of N." And 9.1 Podal pairing at four hundred forty, two stations pairing with themselves: "Podal pairing at the ring of four hundred forty is k with four hundred forty less k, one station at its two sides." And 8.1 An even ring carries its opposite, and an odd ring its two farthest: "Straight across, h on, is apart from the fold, N less k". So here podal is 2 with 118, and straight across, 2 with 62, is named the opposite.
- Exhibit SIXTEEN Natural Chemistry, 4.4 Elements the doubling face, one recursioning counted one hundred eighteen times: "two and one hundred eighteen are the out-carry and the back-carry at one station, equal and opposite about the turn at sixty (Natural Numbers 9.4, 10.11), and the podal is another relation, straight across on an even count, two and sixty-two." So here bi-co-podaling is 2 with 118, and "the podal" is 2 with 62.
- Exhibit EIGHTEEN Natural Physics, 3.1 An atom at two faces, and the periodic table a catalog: "Two and one hundred eighteen stand antipodal on the ring that closes at one hundred twenty." So here antipodal is 2 with 118.
- Exhibit TWENTY Natural Naming, 2.4 Released words, each with its carrying, has the row "| *antipodal* | *podal* |", and 5.45 bi-co-podaling — binary has "the pair is the podal, 17 less within 1 to 16, and the even number's straight-across, k and k + N/2, is another relation".

Read together: Natural Numbers and Natural Naming give "podal" to k with N − k and keep straight across as another relation; Natural Chemistry 4.4 gives "the podal" to straight across; Natural Physics 3.1 keeps the released word "antipodal" for k with N − k. For a reader from geometry, antipodal points on a ring are the diametrically opposite ones, which on a ring of 120 pairs 2 with 62.

## Optional draft for p — outside the MET set

Offered only should the session wish to carry the record's close into the sentence; the sentence's "for a decade" already agrees with the record.

Exhibit SIXTEEN Natural Chemistry, 6.1 Three declared nothings, and a partition the instrument's own coupling: the sentence "The proton's charge radius carried the same lesson for a decade, depending on which probe asked." The field's record: from 2010 muonic hydrogen gave 0.842 fm where electron probes gave about 0.88 fm; since 2017 electron probes have returned the smaller reading too, and one radius, 0.84075(64) fm, is now recommended, some tension remaining (Particle Data Group, 2026, https://pdglive.lbl.gov/view/S016CR). Re-said at the record: "The proton's charge radius read two ways for a decade, until electron probes returned the muon's smaller reading too." — v386EOD

> Listed at the Particle Data Group page, in fm: muonic hydrogen 0.84184 (2010) and 0.84087 (2013); electron scattering 0.879 (2010), 0.831 (2019), 0.878 (2021); hydrogen spectroscopy 0.8335 (2017), 0.877 (2018), 0.833 (2019), the last noted there as one that "agrees well with the muonic hydrogen Lamb shift value". First report of the parting: Pohl and colleagues (2010, Nature 466, 213), 0.84184(67) fm beside the then-recommended 0.8768(69) fm, five standard deviations apart. Electron scattering: Xiong and colleagues (2019, Nature 575, 147), 0.831 ± 0.007 ± 0.012 fm.

## Also noticed while checking (not in the candidate list)

1. Exhibit SIXTEEN Natural Chemistry 4.4, the same sentence as m: "Their rows run 2, 8, 8, 18, 18, 32, 32, each length twice in succession". In the list as written the first length, 2, stands once, and 8, 18 and 32 stand twice. The row lengths and the closings 2, 10, 18, 36, 54, 86 and 118 agree with the record (running sums 2, 10, 18, 36, 54, 86, 118).
2. Exhibit SIXTEEN Natural Chemistry 4.4 cites "(Natural Numbers 9.4, 10.11)" for 2 with 118. In Exhibit THREE Natural Numbers (v380L) 9.4 is "A prime gap is a step between rings" and part TEN ends at 10.2; 2 with 118 stands at 7.1 and 7.6, and bi-co-podaling at 9.2.
3. Where a droplet's clause also stands in another place: b at Exhibit EIGHTEEN Natural Physics 5.1; e at 5.1; f in the table of 4.5; s at Exhibit EIGHTEEN Natural Physics 3.5; q, in fuller form, at Exhibit EIGHTEEN Natural Physics 3.3; v at Exhibit SEVENTEEN Natural Biology 8.14; u in the carry file named above.

## Sources opened

- a: [Carroll, Lecture Notes on General Relativity (1997), chapter 3](https://ned.ipac.caltech.edu/level5/March01/Carroll3/Carroll3.html)
- a: [Carroll, arXiv record of the same notes](https://arxiv.org/abs/gr-qc/9712019)
- b: [Fan, Myers, Sukra, Gabrielse, Measurement of the Electron Magnetic Moment, Phys. Rev. Lett. 130, 071801 (2023)](https://arxiv.org/abs/2209.13084)
- b: [Kramer and colleagues, Strong-field Gravity Tests with the Double Pulsar, Phys. Rev. X 11, 041050 (2021)](https://arxiv.org/abs/2112.06795)
- b: [Max Planck Society, When the laws of physics are at stake (2023)](https://www.mpg.de/20922980/precise-testing-of-quantum-electrodynamics)
- b: [Physics Today, Gyromagnetic ratio of a lone trapped electron is measured to better than a part per trillion (2006)](https://physicstoday.aip.org/news/gyromagnetic-ratio-of-a-lone-trapped-electron-is-measured-to-better-than-a-part-per-trillion)
- b: [Will, The Confrontation between General Relativity and Experiment, Living Reviews in Relativity 17, 4 (2014)](https://link.springer.com/article/10.12942/lrr-2014-4)
- c: [Smits, Mewes, Jerabek, Schwerdtfeger, Oganesson: A Noble Gas Element That Is Neither Noble Nor a Gas, Angewandte Chemie (2020)](https://mro.massey.ac.nz/handle/10179/70598)
- e: [Myrvold, Genovese, Shimony, Bell's Theorem, Stanford Encyclopedia of Philosophy (2004, revised 2024)](https://plato.stanford.edu/entries/bell-theorem/)
- e: [Hensen and colleagues, Loophole-free Bell inequality violation using electron spins separated by 1.3 kilometres, Nature 526, 682 (2015)](https://www.nature.com/articles/nature15759)
- f: [Feynman, Leighton, Sands, The Feynman Lectures on Physics, volume I, chapter 52 (1963)](https://www.feynmanlectures.caltech.edu/I_52.html)
- f: [Callender, Thermodynamic Asymmetry in Time, Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/entries/time-thermo/)
- f: [Teh, Symmetry and Symmetry Breaking, Stanford Encyclopedia of Philosophy (revised 2023)](https://plato.stanford.edu/entries/symmetry-breaking/)
- f: [Noether, Invariant Variation Problems (1918; Tavel's translation, 1971)](https://arxiv.org/abs/physics/0503066)
- g: [Aidala, Bass, Hasch, Mallot, The Spin Structure of the Nucleon, Rev. Mod. Phys. 85, 655 (2013)](https://arxiv.org/abs/1209.2803)
- g: [Ji, Yuan, Zhao, Proton spin after 30 years: what we know and what we don't? (2020)](https://arxiv.org/abs/2009.01291)
- h: [Ungersböck, Advanced Modelling Aspects of Modern Strained CMOS Technology, Technische Universität Wien (2007), section 3.4](https://iue.tuwien.ac.at/phd/ungersboeck/node27.html)
- h: [Nisoli, Semiconductor Laser Photonics, Cambridge University Press, excerpt](https://assets.cambridge.org/97810090/98748/excerpt/9781009098748_excerpt.pdf)
- h: [TU Delft, Open Solid State Notes, crystal structure solutions](https://solidstate.quantumtinkerer.tudelft.nl/9_crystal_structure_solutions/)
- i: [Emery, Markosian, Sullivan, Time, Stanford Encyclopedia of Philosophy (2002, revised 2025)](https://plato.stanford.edu/entries/time/)
- j: [Hawking, Black hole explosions?, Nature 248, 30 (1974)](https://www.nature.com/articles/248030a0)
- k: [Williams, Planetary Fact Sheet, NASA Goddard Space Flight Center (updated 2025)](https://nssdc.gsfc.nasa.gov/planetary/factsheet/)
- k: [Honma, Sofue, On the Keplerian Rotation Curves of Galaxies (1997)](https://ar5iv.arxiv.org/html/astro-ph/9709217)
- k: [Sofue, Rubin, Rotation Curves of Spiral Galaxies, Annu. Rev. Astron. Astrophys. 39, 137 (2001), section 6](https://ned.ipac.caltech.edu/level5/Sept05/Sofue/Sofue6.html)
- m: [NIST, Atomic Reference Data for Electronic Structure Calculations, Electronic Configurations of the Elements (2015, updated 2025)](https://www.nist.gov/pml/atomic-reference-data-electronic-structure-calculations/atomic-reference-data-electronic-8)
- n: [Marcus, Electron Transfer Reactions in Chemistry: Theory and Experiment, Nobel Lecture, 8 December 1992](https://www.nobelprize.org/uploads/2018/06/marcus-lecture.pdf)
- n: [Royal Swedish Academy of Sciences, press release, Nobel Prize in Chemistry 1992](https://www.nobelprize.org/prizes/chemistry/1992/press-release/)
- o: [IAPWS, Revised Release on the Pressure along the Melting and Sublimation Curves of Ordinary Water Substance, R14-08 (2011)](https://iapws.org/documents/release/MeltSub.download)
- o: [Wagner, Riethmann, Feistel, Harvey, New Equations for the Sublimation Pressure and Melting Pressure of H2O Ice Ih, J. Phys. Chem. Ref. Data 40 (2011)](https://www.nist.gov/document/jpcrd402011newpdf)
- p: [Particle Data Group, proton charge radius, Review of Particle Physics (2026)](https://pdglive.lbl.gov/view/S016CR)
- p: [Pohl and colleagues, The size of the proton, Nature 466, 213 (2010)](https://www.nature.com/articles/nature09250)
- p: [Xiong and colleagues, A small proton charge radius from an electron–proton scattering experiment, Nature 575, 147 (2019)](https://www.nature.com/articles/s41586-019-1721-2)
- q: [Feynman, Leighton, Sands, The Feynman Lectures on Physics, volume III, chapter 17 (1965)](https://www.feynmanlectures.caltech.edu/III_17.html)
- q: [The same, volume III, chapter 11](https://www.feynmanlectures.caltech.edu/III_11.html)
- r: [The same, volume III, chapter 12 (hyperfine splitting in hydrogen)](https://www.feynmanlectures.caltech.edu/III_12.html)
- r: [The same, volume III, chapter 6 (spin one-half)](https://www.feynmanlectures.caltech.edu/III_06.html)
- s: [Bollinger, Wineland, Dubin, Non-neutral ion plasmas and crystals, laser cooling, and atomic clocks, Phys. Plasmas 1, 1403 (1994)](https://tf.nist.gov/general/pdf/1034.pdf)
- s: [Royal Swedish Academy of Sciences, press release, Nobel Prize in Physics 1989](https://www.nobelprize.org/prizes/physics/1989/press-release/)
- t: [Fewell, The atomic nuclide with the highest mean binding energy, Am. J. Phys. 63, 653 (1995)](https://ui.adsabs.harvard.edu/abs/1995AmJPh..63..653F/abstract)
- u: [Jet Propulsion Laboratory, Solar System Dynamics, main-belt histogram with the Kirkwood gaps (2007)](https://ssd.jpl.nasa.gov/diagrams/mb_hist.html)
- u: [Swinburne University of Technology, Kirkwood Gaps](https://astronomy.swinburne.edu.au/cosmos/K/Kirkwood+Gaps)
- u: [Wong, Brown, The color-magnitude distribution of Hilda asteroids (2017)](https://arxiv.org/abs/1701.00367)
- u: [NASA Science, Asteroid Facts](https://science.nasa.gov/solar-system/asteroids/facts/)
- v: [Attanasi and colleagues, Information transfer and behavioural inertia in starling flocks, Nature Physics 10, 691 (2014)](https://www.nature.com/articles/nphys3035)
- v: [The same, preprint (2013)](https://arxiv.org/abs/1303.7097)
- v: [Science News, Birds' turns match math of quantum matter (2014)](https://www.sciencenews.org/article/birds-turns-match-math-quantum-matter)
- v: [Smithsonian Magazine, How a Flock of 400 Flying Birds Manages to Turn in Just Half a Second (2014)](https://www.smithsonianmag.com/smart-news/how-flock-400-flying-birds-manages-turn-just-half-second-180952175/)
- v: [Phys.org, report on the same paper (2014)](https://phys.org/news/2014-07-starling-flight-reveals-message-bird.html)
- v: [Cornell Lab of Ornithology, How Do Starling Flocks Create Those Mesmerizing Murmurations? (2013)](https://www.allaboutbirds.org/news/how-do-starling-flocks-create-those-mesmerizing-murmurations/)
