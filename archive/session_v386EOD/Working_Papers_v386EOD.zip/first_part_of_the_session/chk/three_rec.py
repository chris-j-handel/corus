# Exhibit THREE 3.4: next = a*now + b*prior with a, b in {+1, -1, 0}; eventual period of the value sequence.
def ev_period(a, b, x0=2, x1=5, n=120):
    s = [x0, x1]
    for _ in range(n): s.append(a*s[-1] + b*s[-2])
    tail = s[4:]
    for p in range(1, 40):
        if all(tail[i] == tail[i+p] for i in range(len(tail)-p)): return p
    return None
for a in (1, -1, 0):
    for b in (1, -1, 0):
        s = [1, 1]
        for _ in range(9): s.append(a*s[-1] + b*s[-2])
        print("now %+d, prior %+d -> period %s ; from 1,1: %s" % (a, b, ev_period(a, b), s))
