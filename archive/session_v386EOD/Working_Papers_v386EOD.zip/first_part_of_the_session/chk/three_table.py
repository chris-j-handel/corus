# Verify every row of the 0..440 table in Exhibit THREE section 11.1 (file read as data only).
import sys, re
from math import isqrt
path = sys.argv[1]
sup = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")
sub = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")

def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, isqrt(n) + 1))
def factor(n):
    f, d = {}, 2
    while d * d <= n:
        while n % d == 0:
            f[d] = f.get(d, 0) + 1; n //= d
        d += 1
    if n > 1: f[n] = f.get(n, 0) + 1
    return f
P17 = [p for p in range(2, 60) if is_prime(p)]
ordn = ["first","second","third","fourth","fifth","sixth","seventh","eighth","ninth","tenth","eleventh","twelfth","thirteenth","fourteenth","fifteenth","sixteenth","seventeenth"]
names = {1:'1-co-bi-tri-offering',2:'2-bi-co-bi-offering',3:'3-co-bi-co-sharing',4:'4-bi-co-bi-sharing',5:'5-co-bi-co-competencing',6:'6-bi-co-bi-moralizing',7:'7-co-bi-co-corusing',8:'8-bi-co-bi-torusing',9:'9-tri-bi-co-momentarying',10:'10-bi-tri-bi-tunneling',11:'11-tri-bi-tri-chaining',12:'12-bi-tri-bi-entraining',13:'13-tri-bi-tri-competencing',14:'14-bi-tri-bi-moralizing',15:'15-tri-bi-tri-corusing',16:'16-bi-tri-bi-torusing',17:'17-co-bi-tri-offering'}
fib = {1, 2}
a, b = 1, 2
while b <= 440:
    a, b = b, a + b; fib.add(b)
tri = {k*(k+1)//2: k for k in range(1, 40)}
sq = {k*k: k for k in range(0, 22)}
seam = {(2*k+1)**2 - 1: 2*k+1 for k in range(0, 11)}
fact = {6: 3, 24: 4, 120: 5}
pw = {2**k: k for k in range(1, 9)}

rows = []
for line in open(path, encoding="utf-8"):
    m = re.match(r"^\|\s*(\d+)\s*\|(.*)\|\s*$", line)
    if m and line.count("|") == 8:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) == 7 and cells[1] in ("bi", "co", "tri"):
            rows.append(cells)
print("rows parsed:", len(rows), "first n:", rows[0][0], "last n:", rows[-1][0])
errs = []
tagless_notes = []
for i, c in enumerate(rows):
    n = int(c[0])
    if n != i: errs.append((n, "row order"))
    # parity word
    exp = "bi" if n % 2 == 0 else ("co" if ((n - 1) // 8) % 2 == 0 else "tri")
    if c[1] != exp: errs.append((n, "word %s != %s" % (c[1], exp)))
    # form
    form = c[2].translate(sup)
    if n in (0, 1):
        if form != "—": errs.append((n, "form " + form))
    elif is_prime(n):
        if form != "prime": errs.append((n, "form " + form))
    else:
        got = {}
        for part in form.split("·"):
            part = part.strip()
            mm = re.fullmatch(r"(\d+?)(\d*)", part)
            # exponents were superscripts: recover from the original cell
        # parse from original with superscripts
        got = {}
        okp = True
        for part in c[2].split("·"):
            part = part.strip()
            mm = re.fullmatch(r"(\d+)([⁰¹²³⁴⁵⁶⁷⁸⁹]*)", part)
            if not mm: okp = False; break
            base = int(mm.group(1)); e = int(mm.group(2).translate(sup)) if mm.group(2) else 1
            got[base] = e
        if not okp or got != factor(n): errs.append((n, "factorisation %r" % c[2]))
    if int(c[3]) != (440 - n) % 440 and not (n == 440 and c[3] == "0"): errs.append((n, "far440 " + c[3]))
    if int(c[3]) != ((440 - n) if n not in (0, 440) else 0): errs.append((n, "far440b " + c[3]))
    if int(c[4]) != abs(220 - n): errs.append((n, "radius " + c[4]))
    if int(c[5]) != (120 - n % 120) % 120: errs.append((n, "far120 " + c[5]))
    # tags
    at = c[6]
    exp_tags = []
    if n in names: exp_tags.append(names[n])
    if n in P17: exp_tags.append("the %s prime" % ordn[P17.index(n)])
    for tag, cond in (("square", n in sq), ("seam-face", n in seam), ("triangle", n in tri), ("prior two added", n in fib),
                      ("factorial", n in fact)):
        pass
    checks = []
    if n in names: checks.append((names[n] in at, "name"))
    else: checks.append((not re.search(r"\d+-(co|bi|tri)-", at), "no name"))
    if n in P17: checks.append((("the %s prime" % ordn[P17.index(n)]) in at, "prime ordinal"))
    else: checks.append(("prime" not in at.replace("the seventeen primes added", ""), "no prime tag"))
    if n in sq and n not in (4,):  # 4 is tagged '2²' once (square and power)
        checks.append((("%d²" % sq[n]) in at, "square tag"))
    if n in seam: checks.append(("seam-face" in at and ("%d² − 1" % seam[n]) in at, "seam tag"))
    else: checks.append(("seam-face" not in at, "no seam tag"))
    if n in tri: checks.append((("T" + str(tri[n])) in at.translate(sub), "triangle tag"))
    else: checks.append((not re.search(r"T[₀-₉]", at), "no triangle tag"))
    if n in fib: checks.append(("prior two added" in at, "fib tag"))
    else: checks.append(("prior two added" not in at, "no fib tag"))
    if n in fact: checks.append((("%d!" % fact[n]) in at, "factorial tag"))
    else: checks.append(("!" not in at, "no factorial tag"))
    att = at.translate(sup)
    for base, k in pw.items():
        if n == base: checks.append(("2%s" % str(k).translate(str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")) in at, "power tag"))
        if n == base - 1: checks.append((("2%s − 1" % str(k).translate(str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹"))) in at, "2^k-1 tag"))
        if n == base + 1: checks.append((("2%s + 1" % str(k).translate(str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹"))) in at, "2^k+1 tag"))
    for ok, what in checks:
        if not ok: errs.append((n, "tag: %s | cell=%r" % (what, at)))
    # every expression in the cell of the forms a² , a² − 1, 2^k ± 1, Tk, k! must evaluate to n
    for mm in re.finditer(r"(\d+)([⁰¹²³⁴⁵⁶⁷⁸⁹]+)(?: ([−+]) (\d+))?", at):
        v = int(mm.group(1)) ** int(mm.group(2).translate(sup))
        if mm.group(3): v = v - int(mm.group(4)) if mm.group(3) == "−" else v + int(mm.group(4))
        if v != n: errs.append((n, "expression %r != n" % mm.group(0)))
    for mm in re.finditer(r"T([₀-₉]+)", at):
        k = int(mm.group(1).translate(sub))
        if k*(k+1)//2 != n: errs.append((n, "T%d != n" % k))
    for mm in re.finditer(r"(\d+)!", at):
        k = int(mm.group(1)); f = 1
        for j in range(2, k+1): f *= j
        if f != n: errs.append((n, "%d! != n" % k))
print("errors:", len(errs))
for e in errs[:60]: print("  ", e)
# special free-text tags
for n in (0, 23, 59, 60, 61, 118, 220, 440):
    print(n, "->", rows[n][6])
print("non-empty 'At' cells:", sum(1 for r in rows if r[6]))
print("primes in 0..440:", sum(1 for r in rows if r[2] == "prime"), " expected", sum(1 for n in range(441) if is_prime(n)))
print("co/tri/bi counts:", {w: sum(1 for r in rows if r[1] == w) for w in ("co", "tri", "bi")})
