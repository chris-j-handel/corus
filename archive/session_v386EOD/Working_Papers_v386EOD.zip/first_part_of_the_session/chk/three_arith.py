# Independent arithmetic checks for claims stated in Exhibit THREE (Natural Numbers).
from math import gcd, comb, factorial, isqrt, sqrt
from itertools import combinations, product

def is_prime(n):
    if n < 2: return False
    for d in range(2, isqrt(n) + 1):
        if n % d == 0: return False
    return True

def factor(n):
    f, d = [], 2
    while d * d <= n:
        while n % d == 0:
            f.append(d); n //= d
        d += 1
    if n > 1: f.append(n)
    return f

res = []
def chk(label, cond):
    res.append((label, bool(cond)))
    print(("OK   " if cond else "FAIL ") + label)

P = [p for p in range(2, 60) if is_prime(p)]
T = lambda k: k * (k + 1) // 2
phi = (1 + sqrt(5)) / 2
fib = [1, 1]
while len(fib) < 20: fib.append(fib[-1] + fib[-2])

print("== 1.2 / 1.3 / 1.4")
chk("1.2 sum first n odds = n^2 and evens = n(n+1), n=1..50",
    all(sum(range(1, 2*n, 2)) == n*n and sum(range(2, 2*n+1, 2)) == n*(n+1) for n in range(1, 51)))
chk("1.2 openings 1+3+5=9, completings 2+4+6=12=3*4", 1+3+5 == 9 and 2+4+6 == 12 == 3*4)
chk("1.3 (n-1)(n+1)=n^2-1 ; (n-k)(n+k)=n^2-k^2", all((n-k)*(n+k) == n*n-k*k for n in range(1, 60) for k in range(0, n)))
chk("1.3 23*25 = 24^2 - 1", 23*25 == 24**2 - 1)
# four-cycles: alternate 8 up/down (parity kept) and 17 less (parity changed)
def eight(n): return n + 8 if n <= 8 else n - 8
def seventeen(n): return 17 - n
def cyc(start, first):
    out, n, mv = [start], start, first
    while True:
        n = eight(n) if mv == 8 else seventeen(n)
        mv = 17 if mv == 8 else 8
        if n == start and mv == first: break
        out.append(n)
    return out
chk("1.4 table 8 up / 9 less / 17 less for 1..4",
    [(n+8, 9-n, 17-n) for n in (1,2,3,4)] == [(9,8,16),(10,7,15),(11,6,14),(12,5,13)])
chk("1.4 four-cycles 1-9-8-16, 2-15-7-10, 3-11-6-14, 4-13-5-12",
    cyc(1, 8) == [1,9,8,16] and cyc(2, 17) == [2,15,7,10] and cyc(3, 8) == [3,11,6,14] and cyc(4, 17) == [4,13,5,12])
def parity_changes(c): return sum((c[i] - c[(i+1) % len(c)]) % 2 for i in range(len(c)))
chk("1.4 each four-cycle changes parity exactly twice", all(parity_changes(c) == 2 for c in ([1,9,8,16],[2,15,7,10],[3,11,6,14],[4,13,5,12])))
chk("1.4 the four four-cycles partition 1..16; 17 in none", sorted([1,9,8,16]+[2,15,7,10]+[3,11,6,14]+[4,13,5,12]) == list(range(1,17)))
chk("1.4 9 less = 17 less then 8 down: 17-(n+8)=9-n", all(17 - (n + 8) == 9 - n for n in range(1, 9)))
# six- and eight-cycles named in 5.2: allowed steps 8 up/down, 4 up/down, 17 less
def legal(a, b): return abs(a - b) in (8, 4) or a + b == 17
for c in ([2,15,7,11,6,10], [3,11,7,10,6,14], [7,11,6,10], [2,15,7,11,3,14,6,10]):
    chk("5.2 cycle %s uses only steps 8, 4 or 17-less" % c, all(legal(c[i], c[(i+1) % len(c)]) for i in range(len(c))))
forms16 = [[2,15,7,10],[3,11,6,14],[2,15,7,11,6,10],[3,11,7,10,6,14],[7,11,6,10],[2,15,7,11,3,14,6,10]]
shifted = [[x+16 for x in c] for c in forms16]
chk("5.2 forms sixteen on: 18-31-23-26, 19-27-22-30, 18-31-23-27-22-26, 19-27-23-26-22-30",
    shifted[0] == [18,31,23,26] and shifted[1] == [19,27,22,30] and shifted[2] == [18,31,23,27,22,26] and shifted[3] == [19,27,23,26,22,30])
chk("5.2 twenty-two is in five of: 19-27-22-30, 23-27-22-26, both six-cycles, eight-cycle 18-31-23-27-19-30-22-26",
    sum(22 in c for c in [shifted[1], shifted[4], shifted[2], shifted[3], shifted[5]]) == 5 and shifted[5] == [18,31,23,27,19,30,22,26])

print("== 1.6")
chk("1.6 step k round ring N reaches N/gcd stations (N<=40)",
    all(len({(j*k) % N for j in range(N)}) == N // gcd(N, k) for N in range(2, 41) for k in range(1, N)))
chk("1.6 no power of two above one is a power of three (to 2^200)",
    not ({2**a for a in range(1, 200)} & {3**b for b in range(1, 130)}))
chk("1.6 2*3-(2+3)=1 ; 4+4 = 2*3+2", 2*3 - (2+3) == 1 and 4+4 == 2*3+2)
chk("1.6 self 1..4, other 2..5: three shared, two outer", len(set(range(1,5)) & set(range(2,6))) == 3 and len(set(range(1,5)) ^ set(range(2,6))) == 2)

print("== 2 / 3")
chk("2.1 phi^3 - 1/phi^3 = 4", abs(phi**3 - phi**-3 - 4) < 1e-12)
chk("2.1 C(11,2) = T10 = F10 = 55", comb(11,2) == T(10) == fib[9] == 55)
chk("2.2 440 = sum of 17 primes = 8*55 = 21^2-1", sum(P) == 440 == 8*55 == 21**2 - 1 and len(P) == 17)
chk("3.1 Fibonacci ratios alternate about phi: 2/1 above, 3/2 below, 5/3 above, 8/5 below",
    2/1 > phi > 3/2 and 5/3 > phi > 8/5 and all((fib[i+1]/fib[i] > phi) != (fib[i+2]/fib[i+1] > phi) for i in range(1, 17)))
chk("3.1 phi^2=phi+1; phi-1/phi=1; 1/phi=phi-1", abs(phi*phi - phi - 1) < 1e-12 and abs(phi - 1/phi - 1) < 1e-12)
# 3.4 recurrences next = a*now + b*prior, a,b in {+1,-1,0}
def period(a, b, limit=200):
    best = None
    for x0, x1 in ((1, 0), (0, 1), (1, 1), (1, -1), (2, 5)):
        seq = [(x0, x1)]
        x, y = x0, x1
        per = None
        for t in range(1, limit):
            x, y = y, a*y + b*x
            if (x, y) == (x0, x1):
                per = t; break
        if per is None: return None
        best = per if best is None else best * per // gcd(best, per)
    return best
got = {(a, b): period(a, b) for a in (1, -1, 0) for b in (1, -1, 0)}
print("   periods (now coeff, prior coeff):", got)
chk("3.4 now+1 alone:1 ; now-1 alone:2 ; prior+1 alone:2 ; prior-1 alone:4 ; -1,-1:3 ; +1,-1:6 ; +1,+1 and -1,+1 open",
    got[(1,0)] == 1 and got[(-1,0)] == 2 and got[(0,1)] == 2 and got[(0,-1)] == 4 and got[(-1,-1)] == 3 and got[(1,-1)] == 6
    and got[(1,1)] is None and got[(-1,1)] is None)
# crystallographic restriction: finite orders of 2x2 integer matrices (search entries -2..2)
orders = set()
for a, b, c, d in product(range(-2, 3), repeat=4):
    if a*d - b*c not in (1, -1): continue
    M = (a, b, c, d); X = M
    for n in range(1, 13):
        if X == (1, 0, 0, 1):
            orders.add(n); break
        X = (X[0]*a + X[1]*c, X[0]*b + X[1]*d, X[2]*a + X[3]*c, X[2]*b + X[3]*d)
chk("3.4 finite orders of 2x2 integer matrices found = {1,2,3,4,6}", orders == {1, 2, 3, 4, 6})

print("== 4")
chk("4.1 icosahedron 12-30+20=2", 12 - 30 + 20 == 2)
chk("4.3 360=19^2-1=8*T9 ; 440=21^2-1=8*T10 ; 45=C(10,2)=5*9", 360 == 19**2-1 == 8*T(9) and 440 == 21**2-1 == 8*T(10) and 45 == comb(10,2) == 5*9)
chk("4.3 440-360=80=9^2-1=8*T4, T4=C(5,2)", 440-360 == 80 == 9**2-1 == 8*T(4) and T(4) == comb(5,2))
chk("4.3 360 and 80 podal on ring 440, each at radius 140", 360 + 80 == 440 and 360 - 220 == 140 == 220 - 80)

print("== 5")
names = {1:'offering',2:'offering',3:'sharing',4:'sharing',5:'competencing',6:'moralizing',7:'corusing',8:'torusing',
         9:'momentarying',10:'tunneling',11:'chaining',12:'entraining',13:'competencing',14:'moralizing',15:'corusing',16:'torusing',17:'offering'}
chk("5.2 ten roots among seventeen names; four roots at two numbers eight apart (5/13, 6/14, 7/15, 8/16)",
    len(set(names.values())) == 10 and all(names[a] == names[a+8] for a in (5,6,7,8)) and
    sum(1 for a in range(1, 10) if names[a] == names[a+8]) == 4)
chk("5.2 1 entry + 6 between selves (2,6,9,10,14,17) + 10 own (3,4,5,7,8,11,12,13,15,16) = 17",
    sorted([1] + [2,6,9,10,14,17] + [3,4,5,7,8,11,12,13,15,16]) == list(range(1, 18)))
chk("5.3 (2k+1)^2-1 = 8*T_k for k=0..50", all((2*k+1)**2 - 1 == 8*T(k) for k in range(51)))
chk("5.4 4*6=5^2-1", 4*6 == 24)
quads = [c for c in range(5, 120) if all(is_prime(x) for x in (c-4, c-2, c+2, c+4))]
print("   centres with primes at +-2 and +-4:", quads)
chk("5.4 first prime 'diamond' is about 9 (5,7,11,13) and the next about 15 (11,13,17,19)", quads[:2] == [9, 15])
chk("5.4 1..25 = 24 steps = 3 spans * 8", 25 - 1 == 24 == 3*8)
chk("5.5 2n = n(n-1)/2 only at n=5 above nought", [n for n in range(1, 1000) if 2*n == n*(n-1)//2 and n*(n-1) % 2 == 0] == [5])
# complement of the n-ring is a ring only at n = 5
def comp_is_cycle(n):
    edges = {frozenset((i, (i+1) % n)) for i in range(n)}
    comp = [e for e in map(frozenset, combinations(range(n), 2)) if e not in edges]
    if len(comp) != n: return False
    deg = [sum(1 for e in comp if v in e) for v in range(n)]
    if any(d != 2 for d in deg): return False
    seen, stack = {0}, [0]
    while stack:
        v = stack.pop()
        for e in comp:
            if v in e:
                w = next(iter(e - {v}))
                if w not in seen: seen.add(w); stack.append(w)
    return len(seen) == n
chk("5.5 ring's complement is again one ring only at five (n=4..12)", [n for n in range(4, 13) if comp_is_cycle(n)] == [5])
# R(3,3): K5 colourings without mono triangle; K6 all have one
def mono_tri(n, col):
    idx = {e: i for i, e in enumerate(combinations(range(n), 2))}
    for a, b, c in combinations(range(n), 3):
        if col[idx[(a,b)]] == col[idx[(a,c)]] == col[idx[(b,c)]]: return True
    return False
k5 = [col for col in product((0, 1), repeat=10) if not mono_tri(5, col)]
def is_5cycle(col, colour):
    e = [p for p, c in zip(combinations(range(5), 2), col) if c == colour]
    return len(e) == 5 and all(sum(1 for x in e if v in x) == 2 for v in range(5))
chk("5.5 exactly 12 two-colourings of K5 have no one-coloured triangle, each a 5-ring in both colours",
    len(k5) == 12 and all(is_5cycle(c, 0) and is_5cycle(c, 1) for c in k5))
chk("5.5 every two-colouring of K6 (32768) has a one-coloured triangle: R(3,3)=6",
    all(mono_tri(6, col) for col in product((0, 1), repeat=15)))
chk("5.5 any ten consecutive: a+j with a+9-j opposite parity", all(((a+j) + (a+9-j)) % 2 == 1 for a in range(50) for j in range(5)))
chk("5.6 ring of nine pairs (0,9),(1,8),(2,7),(3,6),(4,5)", [(k, 9-k) for k in range(5)] == [(0,9),(1,8),(2,7),(3,6),(4,5)])
chk("5.6 9 = 2^2 * 2.5 - 1", 2**2 * 2.5 - 1 == 9)
dbl = [pow(2, i, 17) for i in range(9)]
chk("5.7 doubling round 17: 1,2,4,8,16,15,13,9 then 1", dbl == [1,2,4,8,16,15,13,9,1])
QR = sorted({(x*x) % 17 for x in range(1, 17)})
chk("5.7 those eight are the squares mod 17; the other eight are 3 times them",
    QR == sorted(dbl[:8]) and sorted({(3*r) % 17 for r in QR}) == sorted(set(range(1,17)) - set(QR)))
adj = lambda a, b: ((a - b) % 17) in QR
k4 = any(all(adj(a, b) for a, b in combinations(s, 2)) for s in combinations(range(17), 4))
i4 = any(all(not adj(a, b) for a, b in combinations(s, 2)) for s in combinations(range(17), 4))
chk("5.7 Paley graph of order 17: no four mutually coupled and no four mutually uncoupled", not k4 and not i4)
chk("5.7 441 = 21^2 = 9*49", 441 == 21**2 == 9*49)
chk("5.8 8*12=100-4, 7*13=100-9, 6*14=100-16, 14*22=18^2-16, 7*9=63, 9*11=99, 13*15=195",
    8*12 == 96 and 7*13 == 91 and 6*14 == 84 and 14*22 == 18**2 - 16 and 7*9 == 8**2-1 and 9*11 == 10**2-1 and 13*15 == 14**2-1)

print("== 6")
chk("6.1 seam-faces 0,8,24,48,80,120,168,224,288,360,440", [8*T(k) for k in range(11)] == [0,8,24,48,80,120,168,224,288,360,440])
chk("6.2 22*26 = 24^2 - 4 ; 23*25 = 24^2 - 1", 22*26 == 24**2 - 4 and 23*25 == 24**2 - 1)
gaps = [b - a for a, b in zip(P, P[1:])]
chk("6.3 24 = 5^2-1 = 4! ; first prime gap of six is 23->29", 24 == 5**2-1 == factorial(4) and gaps.index(6) == P.index(23))
chk("6.3 primes part at 24: nine behind, eight ahead", len([p for p in P if p < 24]) == 9 and len([p for p in P if p > 24]) == 8)
chk("6.3 C(9,2)=36=60-24=6*6 ; C(8,2)=28=T7 ; T6=21,T8=36 ; 36-21=15=C(6,2)",
    comb(9,2) == 36 == 60-24 == 6*6 and comb(8,2) == 28 == T(7) and T(6) == 21 and T(8) == 36 and 36-21 == 15 == comb(6,2))
chk("6.3 icosahedron rotations: 6 axes*4 = 24 fifths; 15 halves + 20 thirds + identity = 36; total 60", 6*4 == 24 and 15+20+1 == 36 and 24+36 == 60)
chk("6.4 28^2-24*32=16 ; 28^2-27*29=1 ; 24=5^2-1, 27=3^3, 32=2^5 ; 24*27*32=144^2",
    28**2 - 24*32 == 16 and 28**2 - 27*29 == 1 and 24 == 5**2-1 and 27 == 3**3 and 32 == 2**5 and 24*27*32 == 144**2)
chk("6.5 3*16=48 ; 3*48+2=146 ; 3*146+2=440 ; 146=2*73=144+2 ; 440=3*144+8", 3*16 == 48 and 3*48+2 == 146 and 3*146+2 == 440 and 146 == 2*73 == 144+2 and 440 == 3*144+8)
chk("6.5 '3x+2 twice' carries 8*T_j to 8*T_(3j+1) for j=0..200", all(3*(3*8*T(j)+2)+2 == 8*T(3*j+1) for j in range(201)))
chk("6.5 chains 0-2-8, 8-26-80, 24-74-224, 48-146-440", [(8*T(j), 3*8*T(j)+2, 3*(3*8*T(j)+2)+2) for j in range(4)] == [(0,2,8),(8,26,80),(24,74,224),(48,146,440)])
chk("6.5 seam-faces <=440 of form 3x+2 are 8,80,224,440 (x=2,26,74,146), k+1 = 2,5,8,11",
    [(8*T(k), (8*T(k)-2)//3, k+1) for k in range(11) if 8*T(k) % 3 == 2] == [(8,2,2),(80,26,5),(224,74,8),(440,146,11)])
chk("6.5 146-120=26 ; 24*26=25^2-1", 146-120 == 26 and 24*26 == 25**2-1)

print("== 7")
chk("7.1 23 is the 9th prime, 59 the 17th; 59*61=60^2-1; 118=2*59=60+58", P[8] == 23 and P[16] == 59 and 59*61 == 3599 and 118 == 2*59 == 60+58)
chk("7.1 ring 120: 2<->118, 23<->97, 59<->61 ; 24,27,32 <-> 96,93,88 with gaps 5 then 3 on the far side",
    120-2 == 118 and 120-23 == 97 and 120-59 == 61 and [120-x for x in (24,27,32)] == [96,93,88] and (93-88, 96-93) == (5, 3))
chk("7.1 names 3,4,5,7,8 carry primes 5,7,11,17,19 summing to 59", [P[i-1] for i in (3,4,5,7,8)] == [5,7,11,17,19] and 5+7+11+17+19 == 59)
chk("7.1 60..68 pair about 64 adding to 128=2^7 ; 64 = 8^2 = 2+3+59 ; 69 = 3*23 ; 61 and 67 prime (first two after 59)",
    all(a + (128 - a) == 128 for a in range(60, 64)) and 64 == 8**2 == 2+3+59 and 69 == 3*23 and [p for p in range(60, 70) if is_prime(p)] == [61, 67])
chk("7.3 sixteen gaps: 1 once, 2 six times, 4 five times, 6 four times; sum 57 = 59-2",
    len(gaps) == 16 and (gaps.count(1), gaps.count(2), gaps.count(4), gaps.count(6)) == (1, 6, 5, 4) and sum(gaps) == 57)
print("   gaps:", gaps)
twins = [(a, b) for a, b in zip(P, P[1:]) if b - a == 2]
chk("7.3 twin pairs (3,5),(5,7),(11,13),(17,19),(29,31),(41,43); past (3,5) at 6k-1, 6k+1",
    twins == [(3,5),(5,7),(11,13),(17,19),(29,31),(41,43)] and all(a % 6 == 5 and b % 6 == 1 for a, b in twins[1:]))
match = [P[i] for i in range(1, 16) if gaps[i-1] == gaps[i]]
chk("7.3 only 5 (2 either side) and 53 (6 either side) carry a matching pair of gaps", match == [5, 53])
f14 = [p for p in P if 5 <= p <= 53]
chk("7.3 fourteen primes 5..53: eight at 6k-1, six at 6k+1; seven either side of 24",
    len(f14) == 14 and [p for p in f14 if p % 6 == 5] == [5,11,17,23,29,41,47,53] and [p for p in f14 if p % 6 == 1] == [7,13,19,31,37,43]
    and len([p for p in f14 if p < 24]) == 7 == len([p for p in f14 if p > 24]))
pairs60 = [(p, 60-p) for p in P if p < 30 and is_prime(60-p)]
chk("7.4 six prime pairs making sixty: 7+53,13+47,17+43,19+41,23+37,29+31", pairs60 == [(7,53),(13,47),(17,43),(19,41),(23,37),(29,31)])
chk("7.4 distances from thirty 23,17,13,11,7,1 add to 72; spans add to 144; six sixties = 360",
    [30-a for a, b in pairs60] == [23,17,13,11,7,1] and sum(30-a for a, b in pairs60) == 72 and sum(b-a for a, b in pairs60) == 144 and 6*60 == 360)
between = [p for p in P if 5 < p < 55]
chk("7.4 of the primes strictly between 5 and 55 only 11 has a composite far side about thirty (49=7^2)", [p for p in between if not is_prime(60-p)] == [11] and 49 == 7**2 and len(between) == 13)
chk("7.4 37+43 = 80, 47+53 = 100 (three either side of 40 and 50)", (40-37, 43-40, 50-47, 53-50) == (3,3,3,3))
chk("7.5 17 primes + 16 betweens = 33", 17 + 16 == 33)
chk("7.6 120 = 5! = 11^2-1 = 8*T5, T5 = C(6,2), 3*120 = 360", 120 == factorial(5) == 11**2-1 == 8*T(5) and T(5) == comb(6,2) and 3*120 == 360)
chk("7.6 119*121=120^2-1 ; 118*122=120^2-4 ; 110*130=120^2-100", 119*121 == 120**2-1 and 118*122 == 120**2-4 and 110*130 == 120**2-100)
ng = [2, 10, 18, 36, 54, 86, 118]
steps = [ng[0]] + [b - a for a, b in zip(ng, ng[1:])]
chk("7.6 noble gases 2,10,18,36,54,86,118 step 2,8,8,18,18,32,32 = twice 1,4,4,9,9,16,16 ; 59 = 1+2(4+9+16)",
    steps == [2,8,8,18,18,32,32] and [s//2 for s in steps] == [1,4,4,9,9,16,16] and 59 == 1 + 2*(4+9+16) and 118 == 2*59)
chk("7.6 evens 110..130 are 55..65 doubled; 65=2^6+1, 56=8*7, 64=8*8, 128=2^7, 57=sum of gaps, 63=2^6-1",
    [2*x for x in range(55, 66)] == list(range(110, 131, 2)) and 65 == 2**6+1 and 56 == 8*7 and 64 == 8*8 and 128 == 2**7 and 57 == sum(gaps) and 63 == 2**6-1)
chk("7.6 111=3*37,129=3*43,113&127 prime,127=2^7-1,115=5*23,125=5^3,117=9*13,123=3*41,119=7*17,121=11^2",
    111 == 3*37 and 129 == 3*43 and is_prime(113) and is_prime(127) and 127 == 2**7-1 and 115 == 5*23 and 125 == 5**3 and 117 == 9*13 and 123 == 3*41 and 119 == 7*17 and 121 == 11**2)
pp120 = [k for k in range(1, 21) if is_prime(120-k) and is_prime(120+k)]
chk("7.6 prime pairs about 120 open at k = 7, 11, 17, 19 (k<=20)", pp120 == [7, 11, 17, 19])
pos = [P[i-1] + P[17-i] for i in range(1, 9)]
chk("7.7 position pairs i with 18-i make 61,56,52,50,52,50,48,48 ; with 23 they total 440", pos == [61,56,52,50,52,50,48,48] and sum(pos) + 23 == 440)
pr = lambda n: P[n-1]
chk("7.7 8 up: 2+23=25, 5+31=36, 17+47=64, 3+29=32, 19+53=72",
    (pr(1)+pr(9), pr(3)+pr(11), pr(7)+pr(15), pr(2)+pr(10), pr(8)+pr(16)) == (25, 36, 64, 32, 72))
print("   all eight '8 up' prime sums (names n, n+8):", [(n, n+8, pr(n)+pr(n+8)) for n in range(1, 9)])
print("   all eight '17 less' prime sums (names n, 17-n):", [(n, 17-n, pr(n)+pr(17-n)) for n in range(1, 9)])
chk("7.7 17 less: 2+53=55 ; pairs at 3&14, 4&13, 5&12 each 48", pr(1)+pr(16) == 55 and pr(3)+pr(14) == pr(4)+pr(13) == pr(5)+pr(12) == 48)
chk("7.7 primes along four-cycles add to 97, 96, 92, 96 ; 97 = 120-23",
    [sum(pr(n) for n in c) for c in ([1,9,8,16],[2,15,7,10],[3,11,6,14],[4,13,5,12])] == [97, 96, 92, 96] and 120-23 == 97)
chk("7.7 across names 2,6,10,14 -> 3,13,29,43 = 88 = 440/5 ; along 9,17 -> 23,59 = 82",
    [pr(n) for n in (2,6,10,14)] == [3,13,29,43] and 3+13+29+43 == 88 == 440//5 and pr(9)+pr(17) == 82)
chk("7.7 outward 3,4,5,7,8 -> 59 ; inward 11,12,13,15,16 -> 31,37,41,47,53 = 209 = 11*19 ; parts total 440",
    sum(pr(n) for n in (3,4,5,7,8)) == 59 and [pr(n) for n in (11,12,13,15,16)] == [31,37,41,47,53] and 31+37+41+47+53 == 209 == 11*19 and 2+88+82+59+209 == 440)
chk("7.7 primes 2..23 add to 100 ; primes 23..59 add to 363 = 3*11^2", sum(P[:9]) == 100 and sum(P[8:]) == 363 == 3*11**2)

print("== 8")
chk("8.1 primes 5..59 add to 435 ; even rings one short add to 420 ; 9+15+25 = 49", sum(P[2:]) == 435 and sum(p-1 for p in P[2:]) == 420 and 9+15+25 == 49)
ok = True
for N in list(P[2:]) + [9, 15, 25]:
    h = N // 2
    for s in range(N):
        d = [min((t - s) % N, (s - t) % N) for t in range(N)]
        far = sorted((t - s) % N for t in range(N) if d[t] == max(d))
        ok &= far == [h, h+1]
for N in [p-1 for p in P[2:]]:
    h = N // 2
    for s in range(N):
        d = [min((t - s) % N, (s - t) % N) for t in range(N)]
        far = [(t - s) % N for t in range(N) if d[t] == max(d)]
        ok &= far == [h]
chk("8.1 odd ring 2h+1: two farthest at h and h+1 on; even ring 2h: one opposite at h on (all stations of the rings named)", ok)
chk("8.2 59 as an open line: 29 pairs at each parity", (59 - 1)//2 == 29)
# XOR among the 16 two-input functions
resp = []
for tt in product((0, 1), repeat=4):
    f = lambda a, b, tt=tt: tt[2*a + b]
    if all(f(a, b) != f(1-a, b) and f(a, b) != f(a, 1-b) for a in (0, 1) for b in (0, 1)):
        resp.append(tt)
chk("8.2 of 16 two-input functions exactly two answer every single change with a change (XOR, XNOR)", resp == [(0,1,1,0), (1,0,0,1)])
x, y, seq = 1, 1, []
for _ in range(9):
    seq.append(x); x, y = y, x ^ y
chk("8.2 xor of prior and now as next runs round at three (1,1,0,...)", seq == [1,1,0,1,1,0,1,1,0])
step = lambda v: (v[1], -v[0])
def it(v, n):
    for _ in range(n): v = step(v)
    return v
chk("8.2 (x,y)->(y,-x): twice inverts both, four times home, six times inverts both; all four joint forms reached",
    all(it(v, 2) == (-v[0], -v[1]) and it(v, 4) == v and it(v, 6) == (-v[0], -v[1]) and len({it(v, n) for n in range(6)}) == 4
        for v in product((1, -1), repeat=2)))
chk("8.2 24 = 6 rounds of 4 = 4 passages of 6 ; 36 = 9 and 6 ; 60 = 15 and 10", (24//4, 24//6, 36//4, 36//6, 60//4, 60//6) == (6, 4, 9, 6, 15, 10))
# Peres-Mermin: rows product +1, columns +1,+1,-1 (any odd number of -1 columns gives the same count)
cnt = 0
for v in product((1, -1), repeat=9):
    rows = all(v[3*r]*v[3*r+1]*v[3*r+2] == 1 for r in range(3))
    cols = [v[c]*v[c+3]*v[c+6] for c in range(3)]
    if rows and cols == [1, 1, -1]: cnt += 1
chk("8.5 Peres-Mermin square: of 512 settings none satisfies all six conditions", cnt == 0 and 2**9 == 512)

print("== 9")
chk("9.1 ring 440: 219 pairs + two self-paired (0 and 220) = 221 rings", len([k for k in range(1, 220)]) == 219 and 219 + 2 == 221)
chk("9.3 odd primes 3..59 at odd radii 217 down to 161; 2 at even radius 218", all((220 - p) % 2 == 1 for p in P[1:]) and 220-3 == 217 and 220-59 == 161 and 220-2 == 218)
two3 = [p for p in P if p % 3 == 2]
chk("9.3 440 mod 3 = 2 ; ten primes = 2 mod 3 have far sides divisible by 3", 440 % 3 == 2 and two3 == [2,5,11,17,23,29,41,47,53,59] and all((440-p) % 3 == 0 for p in two3))
chk("9.3 437=19*23 ; 7,19,31,43 (=7 mod 12) have prime far sides 433,421,409,397 ; 13,37 (=1 mod 12): 427=7*61, 403=13*31",
    437 == 19*23 and all(p % 12 == 7 for p in (7,19,31,43)) and [440-p for p in (7,19,31,43)] == [433,421,409,397] and all(is_prime(x) for x in (433,421,409,397))
    and 13 % 12 == 1 == 37 % 12 and 427 == 7*61 == 440-13 and 403 == 13*31 == 440-37)
print("   far sides at 440 of the 17 primes:", [(p, 440-p, 'prime' if is_prime(440-p) else factor(440-p)) for p in P])
fives = [k for k in range(1, 441) if k % 5 == 0]
oddf = [k for k in fives if k % 2]
chk("9.3 440 = 8*5*11 ; 88 fives, 44 odd and 44 tens ; odd fives pair at 22 odd radii 5..215 ; 435 = C(30,2) = primes 5..59 added",
    440 == 8*5*11 and len(fives) == 88 and len(oddf) == 44 and len(fives) - len(oddf) == 44
    and sorted({abs(220-k) for k in oddf}) == list(range(5, 216, 10)) and len(range(5, 216, 10)) == 22 and 435 == comb(30, 2) == sum(P[2:]))
chk("9.5 46 = 3+43 = 5+41 = 17+29 by value, and no position pair makes 46", 3+43 == 5+41 == 17+29 == 46 and 46 not in pos and
    [(a, 46-a) for a in P if a < 23 and (46-a) in P] == [(3,43),(5,41),(17,29)])
chk("9.5 primes 5..53 add to 376 ; 2+3+59 = 64 ; 376+64 = 440 ; both at radius 156", sum(f14) == 376 and 2+3+59 == 64 and 376+64 == 440 and 376-220 == 156 == 220-64)
chk("9.6 two surfaces: 880 stations, waists at 220 and 660", 2*440 == 880 and 440+220 == 660)
chk("9.7 3,5,9,17 = 2^k+1 ; (N+1)/2 pairs = 2,3,5,9 ; two-station pairs 1,2,4,8", [2**k+1 for k in (1,2,3,4)] == [3,5,9,17] and [(N+1)//2 for N in (3,5,9,17)] == [2,3,5,9] and [(N-1)//2 for N in (3,5,9,17)] == [1,2,4,8])
chk("9.7 9,17,33,65 each twice the one before less one", all(b == 2*a - 1 for a, b in zip((9,17,33), (17,33,65))))
chk("9.7 rounds 2^k+1: 3,5,9,17,33,65 ; pairs 5,17,65,257 ; threes 9,65,513 ; fours 17,257,4097 ; 8*17-7 = 129",
    [2**k+1 for k in range(1, 7)] == [3,5,9,17,33,65] and [2**k+1 for k in (2,4,6,8)] == [5,17,65,257] and [2**k+1 for k in (3,6,9)] == [9,65,513]
    and [2**k+1 for k in (4,8,12)] == [17,257,4097] and 8*17-7 == 129)
chk("9.7 release places 3,6,9,15,45 for spans 9,13,17,25,65 fit 3(N-5)/4", [3*(N-5)//4 for N in (9,13,17,25,65)] == [3,6,9,15,45])
chk("9.7 four 1-17s run 1-65: 17,33,49,65", [1+16*k for k in (1,2,3,4)] == [17,33,49,65])
chk("9.9 rows 2+2sj: 2,4,6,8 / 2,6,10,14 / 2,8,14,20 / 2,10,18,26 / 2,12,22,32 ; completings 8s+1 = 9,17,25,33,41",
    [[2+2*s*j for j in range(4)] for s in range(1, 6)] == [[2,4,6,8],[2,6,10,14],[2,8,14,20],[2,10,18,26],[2,12,22,32]] and [8*s+1 for s in range(1,6)] == [9,17,25,33,41])
ok = True
for s in range(1, 8):
    B = 8*s
    half = lambda n: n + 4*s if n <= 4*s else n - 4*s
    fold = lambda n: B + 1 - n
    for n in range(1, B+1):
        ok &= fold(half(n)) == (4*s + 1 - n if n <= 4*s else 12*s + 1 - n)
        c = [n]; m = n
        for i in range(4):
            m = half(m) if i % 2 == 0 else fold(m)
            c.append(m)
        ok &= c[4] == n and len(set(c[:4])) == 4
chk("9.9 on names 1..8s: halfway pairing then fold = 4s+1-n (lower) / 12s+1-n (upper); alternating gives four distinct names and home at the fourth (s=1..7)", ok)
chk("9.9 s=1: 3-7-2-6-3 ; s=2: 3-11-6-14-3", [3, 3+4, 9-7, 2+4, 9-6] == [3,7,2,6,3] and [3, 3+8, 17-11, 6+8, 17-14] == [3,11,6,14,3])
chk("9.9 row middle 2+3s; inner reach s over span 2s; outer reach 3s over span 6s", all(
    (r[1]+r[2])/2 == 2+3*s == (r[0]+r[3])/2 and r[2]-r[1] == 2*s and r[3]-r[0] == 6*s for s in range(1, 6) for r in [[2+2*s*j for j in range(4)]]))
enl = lambda r, n: r*(n-2)+2 if n % 2 == 0 else r*(n+1)-1
chk("9.9 enlarging at r=2 sends names 1..8 to 3,2,7,6,11,10,15,14", [enl(2, n) for n in range(1, 9)] == [3,2,7,6,11,10,15,14])
chk("9.9 enlarging continues parity and sends the fold B+1-n to Br+1-n (B=8,16; r=1..5)",
    all(enl(r, n) % 2 == n % 2 and enl(r, B+1-n) == B*r + 1 - enl(r, n) for B in (8, 16) for r in range(1, 6) for n in range(1, B+1)))
chk("9.9 2+r(x-2) after enlarging by s is enlarging by rs", all(2 + r*((2 + s*(x-2)) - 2) == 2 + r*s*(x-2) for r in range(1,6) for s in range(1,6) for x in range(2, 40, 2)))
chk("9.9 2,4,6,8 with 10,12,14,16 are the same eight names as 2,6,10,14 with 4,8,12,16", sorted([2,4,6,8,10,12,14,16]) == sorted([2,6,10,14,4,8,12,16]))
print("== 10")
chk("10.2 17-(n+8) = 9-n ; 8s+1-(n+4s) = 4s+1-n", all(17-(n+8) == 9-n for n in range(1, 9)) and all(8*s+1-(n+4*s) == 4*s+1-n for s in range(1, 9) for n in range(1, 4*s+1)))
chk("10.2 six names between selves are 2,6,9,10,14,17", len([2,6,9,10,14,17]) == 6)
print()
bad = [l for l, c in res if not c]
print("TOTAL checks:", len(res), " failed:", len(bad))
for l in bad: print("  FAILED:", l)
