# My own re-typing of the ~40-line resolver printed in Exhibit ONE (logic only, plain names),
# used to test the resolver-dependent statements made in Exhibit THREE 7.2 and Exhibit FOUR 3.7.
from itertools import product
from math import gcd

def resolve(carrying, offerings):                 # name 1: returns (shared at 10, carried next at 11)
    surf = {}                                     # 14: what surfaces
    for key, val in offerings:
        if val != 0:
            cur = surf.get(key)
            if cur is None:
                surf[key] = 1 if val > 0 else -1
            elif (cur > 0) != (val > 0):
                surf[key] = 0
    ent = dict(surf)                              # 12
    for key, val in carrying:
        cur = surf.get(key, 0)
        if cur != 0 and (cur > 0) == (val > 0):
            ent[key] = 0
        else:
            ent[key] = -1 if val > 0 else 1
    shared = list(ent.items())                    # 10
    chain = dict(carrying)                        # 11
    for key, val in shared:
        if val != 0:
            chain[key] = val
    return shared, list(chain.items())

def momentary(state, wiring):                     # name 17: one momentary of a society
    nxt_carry, nxt_off, out = {}, {i: [] for i in state}, {}
    for i, (carrying, offerings) in state.items():
        shared, nxt_carry[i] = resolve(carrying, offerings)
        out[i] = tuple(shared)
        for conn in ((i, 6), (i, 10), (i, 9)):
            if conn in wiring:
                nxt_off[wiring[conn]].extend(shared)
    return {i: (nxt_carry[i], nxt_off[i]) for i in state}, out

def run(state, wiring, T):
    outs, states = [], []
    for _ in range(T):
        states.append(tuple((i, tuple(c), tuple(sorted(o))) for i, (c, o) in sorted(state.items())))
        state, out = momentary(state, wiring)
        outs.append(tuple(v for i in sorted(out) for (_, v) in out[i]))
    return outs, states

def ev_period(seq, maxp):
    """smallest p and earliest start t0 (1-based momentary) with seq[t+p]==seq[t] for all t>=t0"""
    n = len(seq)
    for p in range(1, maxp + 1):
        t0 = n - p
        while t0 > 0 and seq[t0 - 1] == seq[t0 - 1 + p]:
            t0 -= 1
        if t0 <= n - 3 * p:           # at least three full periods confirmed
            return p, t0 + 1
    return None, None

sym = {1: '+', -1: '-', 0: '0'}
print("== Exhibit FOUR 3.7 / single self")
print(" two + together at an unchained sharing :", resolve([], [('s', 1), ('s', 1)]))
print(" one +                                  :", resolve([], [('s', 1)]))
print(" + and - together (nothing carried)     :", resolve([], [('s', 1), ('s', -1)]))
c1 = resolve([], [('s', 1)])[1]
print(" second + after the first chained +     :", resolve(c1, [('s', 1)]))

print("== spiral of n selves (each releases along at 9 to the next, last to first); self 1 carries -, alternating")
def spiral(n, init=None):
    wiring = {(i, 9): (i % n) + 1 for i in range(1, n + 1)}
    if init is None: init = [-1 if i % 2 == 1 else 1 for i in range(1, n + 1)]
    state = {i: ([('s', init[i-1])], []) for i in range(1, n + 1)}
    return state, wiring
for n in list(range(1, 12)) + [13, 17, 59]:
    state, wiring = spiral(n)
    T = 16 * n + 40
    outs, states = run(state, wiring, T)
    p, t0 = ev_period(outs, 4 * n + 4)
    first12 = ", ".join(sym[o[0]] for o in outs[:12])
    print(" n=%2d  self 1 released (momentaries 1-12): %s   period %s (4n=%d)  from momentary %s" % (n, first12, p, 4*n, t0))

print("== every starting pattern of parities at n selves: set of periods of the releasings")
for n in (3, 5, 7, 9, 11, 13, 15):
    per = {}
    for init in product((1, -1), repeat=n):
        state, wiring = spiral(n, list(init))
        outs, _ = run(state, wiring, 14 * n + 40)
        p, t0 = ev_period(outs, 4 * n + 4)
        alike = len(set(init)) == 1
        per.setdefault(p, [0, 0])
        per[p][0] += 1
        per[p][1] += alike
    print(" n=%2d periods -> {period: [patterns, of which all-alike]} %s" % (n, dict(sorted(per.items(), key=lambda kv: (kv[0] is None, kv[0])))))

print("== like pair in an odd spiral: positions (i, i+1) carrying one parity, momentary by momentary (n=5)")
state, wiring = spiral(5)
for t in range(1, 23):
    car = [state[i][0][0][1] for i in range(1, 6)]
    like = [(i, i % 5 + 1) for i in range(1, 6) if car[i-1] == car[i % 5]]
    state, out = momentary(state, wiring)
    print("  m%2d carrying %s like pairs %s  shared %s" % (t, "".join(sym[c] for c in car), like, "".join(sym[out[i][0][1]] for i in range(1, 6))))

print("== two spirals beside each other (uncoupled): lcm of 4p and 4q")
for p, q in ((3, 5), (5, 7), (7, 11), (11, 13), (13, 17), (17, 59), (9, 15), (2, 3)):
    a = 2 if p % 2 == 0 else 4 * p; b = 2 if q % 2 == 0 else 4 * q
    print("  %d . %d -> lcm = %d ; 4pq = %d" % (p, q, a * b // gcd(a, b), 4 * p * q))

print("== torus of selves: p along (9), q across (10)")
def torus(p, q):
    ids = [(a, b) for a in range(p) for b in range(q)]
    wiring = {}
    for a, b in ids:
        wiring[((a, b), 9)] = ((a + 1) % p, b)
        wiring[((a, b), 10)] = (a, (b + 1) % q)
    state = {(a, b): ([('s', -1 if (a + b) % 2 == 0 else 1)], []) for a, b in ids}
    return state, wiring
for p, q in ((1, 3), (2, 3), (1, 5), (3, 3), (3, 5), (3, 7), (3, 13), (5, 7), (5, 11), (7, 17), (17, 59), (3, 9), (5, 9), (5, 15), (7, 13), (7, 15), (9, 17), (9, 19)):
    for (pp, qq, tag) in ((p, q, "p along, q across"), (q, p, "swapped")):
        state, wiring = torus(pp, qq)
        T = 12 * max(4 * p, q) + 8 * p + 60
        outs, _ = run(state, wiring, T)
        per, t0 = ev_period(outs, max(4 * p, q) * 2 + 4)
        rule = (q if q > 2 * p else 4 * p) if (p % 2 and q % 2) else 2
        print("  %2d . %2d (%s): period %s from momentary %s | file's rule gives %s ; 3p-3=%d 3p-1=%d" % (p, q, tag, per, t0, rule, 3*p-3, 3*p-1))
