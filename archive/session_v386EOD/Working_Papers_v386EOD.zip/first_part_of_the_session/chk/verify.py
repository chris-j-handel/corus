import itertools, math

# 1. transitive relations on 4 elements
def count_transitive(n):
    pairs = [(i, j) for i in range(n) for j in range(n)]
    cnt = 0
    for mask in range(1 << (n * n)):
        R = [[(mask >> (i * n + j)) & 1 for j in range(n)] for i in range(n)]
        ok = True
        for i in range(n):
            for j in range(n):
                if R[i][j]:
                    for k in range(n):
                        if R[j][k] and not R[i][k]:
                            ok = False
                            break
                if not ok:
                    break
            if not ok:
                break
        cnt += ok
    return cnt

print("transitive relations n=1..4:", [count_transitive(n) for n in range(1, 5)])

# 2. irreflexive relations where every element has >=1 successor and >=1 predecessor
def count_serial_both(n):
    offdiag = [(i, j) for i in range(n) for j in range(n) if i != j]
    m = len(offdiag)
    cnt = 0
    acyclic = 0
    for mask in range(1 << m):
        out = [0] * n
        inn = [0] * n
        for b, (i, j) in enumerate(offdiag):
            if (mask >> b) & 1:
                out[i] += 1
                inn[j] += 1
        if all(out) and all(inn):
            cnt += 1
    return cnt

res = [count_serial_both(n) for n in range(1, 6)]
print("irreflexive, every element has successor and predecessor, n=1..5:", res, "sum:", sum(res))

# variants for comparison
def serial_only(n):  # irreflexive, each has a successor
    return (2 ** (n - 1) - 1) ** n
print("irreflexive serial only n=1..5:", [serial_only(n) for n in range(1, 6)])
print("serial (loops allowed) n=1..5:", [(2 ** n - 1) ** n for n in range(1, 6)])

# 3. Landauer
k = 1.380649e-23
print("kT ln2 at 300 K:", k * 300 * math.log(2), " at 293.15:", k * 293.15 * math.log(2), " at 298.15:", k*298.15*math.log(2))

# 4. primes 5..53 partitions
def is_prime(x):
    return x > 1 and all(x % d for d in range(2, int(x ** 0.5) + 1))
ps = [p for p in range(5, 54) if is_prime(p)]
print(len(ps), ps)
print("one before six:", [p for p in ps if p % 6 == 5], "one after:", [p for p in ps if p % 6 == 1])
print("mod 4 ==1:", [p for p in ps if p % 4 == 1], "==3:", [p for p in ps if p % 4 == 3])
print("(p-1)/2 even:", [p for p in ps if ((p - 1) // 2) % 2 == 0], "odd:", [p for p in ps if ((p - 1) // 2) % 2 == 1])
print("below 24:", [p for p in ps if p < 24], "above:", [p for p in ps if p > 24])
print("primes 53..68:", [p for p in range(53, 69) if is_prime(p)])
# tesseract face counts
from math import comb
print("n-cube k-faces n=3:", [comb(3, k) * 2 ** (3 - k) for k in range(4)], "n=4:", [comb(4, k) * 2 ** (4 - k) for k in range(5)])
print("cos60, sin60:", math.cos(math.radians(60)), math.sin(math.radians(60)))
