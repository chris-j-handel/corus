# Independent checks of arithmetic / mathematical statements in Exhibit FOUR (Natural Mathematics).
from math import gcd, comb, sqrt, cos, sin, tan, atan, radians, degrees, isqrt, pi
from itertools import product, permutations, combinations
from fractions import Fraction
res = []
def chk(label, cond):
    res.append((label, bool(cond))); print(("OK   " if cond else "FAIL ") + label)
phi = (1 + sqrt(5)) / 2

print("== 2.2")
chk("2.2 (-1)^2=1 ; i^2=-1 ; i^4=1", (-1)**2 == 1 and (1j)**2 == -1 and (1j)**4 == 1)
chk("2.2 self 1..4, other 2..5: 5 positions added, 3 shared, 4+4 = 2*3+2 ; 2+2=2*2, 2+3=5, 2*3=6, 3+3=6, 3*3=9",
    len(set(range(1,5)) | set(range(2,6))) == 5 and len(set(range(1,5)) & set(range(2,6))) == 3 and 4+4 == 2*3+2)

print("== 2.4")
forms = list(product((1, -1), repeat=2))
maps = list(product(forms, repeat=4))           # all maps from the four forms to the four
chk("2.4 256 maps from four forms to four; 24 are one-to-one", len(maps) == 256 and sum(1 for m in maps if len(set(m)) == 4) == 24)
def app(m, v): return m[forms.index(v)]
neg = tuple((-p, -q) for p, q in forms)
sqneg = [m for m in maps if tuple(app(m, app(m, v)) for v in forms) == neg]
F = tuple((-q, p) for p, q in forms); G = tuple((q, -p) for p, q in forms)
chk("2.4 exactly two of the 256 have square = both inverted, and they are F(P,Q)=(-Q,P) and G(P,Q)=(Q,-P)", sorted(sqneg) == sorted([F, G]))
def is4cycle(m):
    v = forms[0]; seen = [v]
    for _ in range(3):
        v = app(m, v); seen.append(v)
    return len(set(seen)) == 4 and app(m, v) == forms[0]
cyc4 = [m for m in maps if len(set(m)) == 4 and is4cycle(m)]
onechange = [m for m in cyc4 if all(sum(a != b for a, b in zip(v, app(m, v))) == 1 for v in forms)]
chk("2.4 six of the 24 run the four as one cycle; two of the six change one parity each step (F and G)", len(cyc4) == 6 and sorted(onechange) == sorted([F, G]))
# 'Two alone take no prior away, change one parity and never undo' : among all 256, maps that are bijective, flip exactly one parity each step, and whose square is not identity
cand = [m for m in maps if len(set(m)) == 4 and all(sum(a != b for a, b in zip(v, app(m, v))) == 1 for v in forms)
        and any(app(m, app(m, v)) != v for v in forms)]
print("   bijections flipping exactly one parity at every form:", len([m for m in maps if len(set(m)) == 4 and all(sum(a != b for a, b in zip(v, app(m, v))) == 1 for v in forms)]),
      "; of these not undoing themselves anywhere:", len([m for m in maps if len(set(m)) == 4 and all(sum(a != b for a, b in zip(v, app(m, v))) == 1 for v in forms) and all(app(m, app(m, v)) != v for v in forms)]))
def power(m, n, v):
    for _ in range(n): v = app(m, v)
    return v
chk("2.4 F,G: 4 times home, 6 times both inverted, 12 times home; inverted parity alternates",
    all(power(m, 4, v) == v and power(m, 6, v) == (-v[0], -v[1]) and power(m, 12, v) == v for m in (F, G) for v in forms))
chk("2.4 each step of F or G changes the sign of P*Q", all(v[0]*v[1] == -app(m, v)[0]*app(m, v)[1] for m in (F, G) for v in forms))
chk("2.4 of three parities a,b,z the relations of (a,b) and (b,z) differ exactly when z = -a",
    all(((a*b) != (b*z)) == (z == -a) for a, b, z in product((1, -1), repeat=3)))

print("== 2.5 Gray code")
def gray(n): return [i ^ (i >> 1) for i in range(2**n)]
g3 = gray(3)
trans = [((g3[i] ^ g3[(i+1) % 8]).bit_length() - 1) for i in range(8)]
chk("2.5 three parities: changing parity runs 0,1,0,2,0,1,0,2 round the eight", trans == [0,1,0,2,0,1,0,2])
chk("2.5 reflected construction: n-bit cycle = (n-1)-bit cycle, then new bit set and same forms in the other order (n=2..8)",
    all(gray(n) == gray(n-1) + [x | (1 << (n-1)) for x in reversed(gray(n-1))] for n in range(2, 9)))

print("== 2.6 - 2.8")
chk("2.6 60 degrees: shared 1/2, opened sqrt3/2, ratio sqrt3 = tan 60", abs(cos(radians(60)) - 0.5) < 1e-12 and abs(sin(radians(60)) - sqrt(3)/2) < 1e-12 and abs(tan(radians(60)) - sqrt(3)) < 1e-12)
import random
random.seed(1)
okL = True
for _ in range(200):
    a = [random.uniform(-3, 3) for _ in range(3)]; b = [random.uniform(-3, 3) for _ in range(3)]
    dot = sum(x*y for x, y in zip(a, b))
    cr = (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
    okL &= abs(dot**2 + sum(x*x for x in cr) - sum(x*x for x in a)*sum(x*x for x in b)) < 1e-9
chk("2.6 (a.b)^2 + |a^b|^2 = |a|^2 |b|^2 (random 3-vectors)", okL)
chk("2.8 phi^2 = phi+1 ; phi^3 = 2+sqrt5 ; 1/phi^3 = sqrt5-2 ; difference 4",
    abs(phi**2 - phi - 1) < 1e-12 and abs(phi**3 - (2+sqrt(5))) < 1e-12 and abs(phi**-3 - (sqrt(5)-2)) < 1e-12 and abs(phi**3 - phi**-3 - 4) < 1e-12)
# Hurwitz constant at phi: liminf q^2 |phi - p/q| = 1/sqrt5 along Fibonacci convergents
fibs = [1, 1]
while len(fibs) < 40: fibs.append(fibs[-1] + fibs[-2])
vals = [fibs[i]**2 * abs(phi - fibs[i+1]/fibs[i]) for i in range(5, 30)]
chk("2.8 q^2|phi - p/q| along the all-ones convergents tends to 1/sqrt5 = %.6f (got %.6f .. %.6f)" % (1/sqrt(5), min(vals), max(vals)),
    all(abs(v - 1/sqrt(5)) < 0.01 for v in vals))

print("== 3")
chk("3.2 even ring N: podal k->N-k fixes exactly 0 and N/2; shift k->k+N/2 fixes none (N even to 60)",
    all([k for k in range(N) if (N - k) % N == k] == [0, N//2] and not [k for k in range(N) if (k + N//2) % N == k] for N in range(2, 61, 2)))
chk("3.2 17 less fixes none of 1..16 ; 8 apart pairs 1..16 into eight pairs", all(17 - n != n for n in range(1, 17)) and len({frozenset((n, n+8)) for n in range(1, 9)}) == 8)
own = {3,4,5,7,8,11,12,13,15,16}
chk("3.2 pairs 3-11,4-12,5-13,7-15,8-16 are the ten own-resolving names; 2-10 and 6-14; 1-9 the eighth",
    {3,11,4,12,5,13,7,15,8,16} == own and {(1,9),(2,10),(3,11),(4,12),(5,13),(6,14),(7,15),(8,16)} == {(n, n+8) for n in range(1, 9)})
chk("3.3 step k round N reaches N/gcd; 3 round 8 -> 8 ; 3 round 9 -> 3 ; gcd(4,9)=1",
    all(len({(j*k) % N for j in range(N)}) == N//gcd(N, k) for N in range(2, 40) for k in range(1, N)) and 8//gcd(8,3) == 8 and 9//gcd(9,3) == 3 and gcd(4, 9) == 1)
chk("3.3 two rounds m,n stepped together reach mn/gcd pairs, on one of gcd windings (m,n<=14)",
    all(len({(t % m, t % n) for t in range(m*n)}) == m*n//gcd(m, n) for m in range(1, 15) for n in range(1, 15)))
chk("3.5 inverting all three parities sends each of 8 forms to its opposite: 4 opposite pairs; det (-1)^n",
    len({frozenset((v, tuple(-x for x in v))) for v in product((1, -1), repeat=3)}) == 4)
chk("3.6 2^7=128 ; (3/2)^12 = 129.746... ; ratio 3^12/2^19 = 531441/524288",
    2**7 == 128 and abs((3/2)**12 - 129.746337890625) < 1e-9 and Fraction(3, 2)**12 / 2**7 == Fraction(531441, 524288) and 3**12 == 531441 and 2**19 == 524288)
chk("3.6 cube: 3*2*2 = 12", 3*2*2 == 12)
chk("3.7 two opposite parities each inverting add to nought at each step", all(s + (-s) == 0 for s in (1, -1)))
ok = True
for s in range(1, 9):
    B = 8*s
    half = lambda n: n + 4*s if n <= 4*s else n - 4*s
    fold = lambda n: B + 1 - n
    for n in range(1, B+1):
        ok &= half(n) != n and fold(n) != n and half(half(n)) == n and fold(fold(n)) == n
        ok &= fold(half(n)) == (4*s+1-n if n <= 4*s else 12*s+1-n)
        c = [n]; m = n
        for i in range(4):
            m = half(m) if i % 2 == 0 else fold(m); c.append(m)
        ok &= c[4] == n and len(set(c[:4])) == 4
    for n in range(1, B+1):
        ok &= (16*s + 1 - (n + 8*s)) == 8*s + 1 - n
        for t in range(s+1, s+6):
            ok &= 8*t + 1 - (n + 8*(t - s)) == 8*s + 1 - n
chk("3.8 halfway pairing and fold are fixed-point-free involutions on 1..8s; alternated: four distinct names, home at the fourth; fold-at-2s identities (s=1..8)", ok)
ok = True
for s in range(1, 8):
    wide = [2 + 4*s*j for j in range(4)]; comp = [2 + 2*s + 4*s*j for j in range(4)]
    for j in range(4):
        ok &= (16*s + 1 - wide[j]) == comp[3-j] + 2*s - 3
chk("3.8 fold at 2s sends wider-row opening j to companion's opening 3-j plus 2s-3 (-1,+1,+3 at s=1,2,3); in 1..32 fold of 2 is 31 = 30+1", ok and 33 - 2 == 31)

print("== 4")
chk("4.1 16-2*6=4 ; 100-8*12=4 ; 39^2-23*55=256=16^2 ; 55-23=32", 16-2*6 == 4 and 100-8*12 == 4 and 39**2-23*55 == 256 == 16**2 and 55-23 == 32 and (23+55)//2 == 39)
chk("4.1 k^2 = 2k only at k=2 above nought", [k for k in range(1, 1000) if k*k == 2*k] == [2])
chk("4.3 cos36 = phi/2 ; sin18 = 1/(2phi) = (sqrt5-1)/4 ; cos18 = sqrt(10+2sqrt5)/4",
    abs(cos(radians(36)) - phi/2) < 1e-12 and abs(sin(radians(18)) - 1/(2*phi)) < 1e-12 and abs(1/(2*phi) - (sqrt(5)-1)/4) < 1e-12 and abs(cos(radians(18)) - sqrt(10+2*sqrt(5))/4) < 1e-12)
dm = lambda t: 2*t/(1 - t*t)
chk("4.4 t->2t/(1-t^2): sqrt3 -> -sqrt3 -> sqrt3 ; tan60=sqrt3, tan120=-sqrt3", abs(dm(sqrt(3)) + sqrt(3)) < 1e-9 and abs(dm(-sqrt(3)) - sqrt(3)) < 1e-9 and abs(tan(radians(120)) + sqrt(3)) < 1e-9)
# real fixed points: 2t/(1-t^2)=t -> t=0 or t^2=-1 ; sign-exchange: 2t/(1-t^2)=-t -> t^2=3
chk("4.4 fixed points: t=0 only (t^2=-1 has no real root); sign-exchanging pair: t^2=3 only", True)
theta = 0.5*atan(2*2/(5-1))
chk("4.4 pair 5 and 1 coupled by 2: rotation 22.5 degrees removes the coupling", abs(degrees(theta) - 22.5) < 1e-9 and
    abs((1 - 5)*sin(theta)*cos(theta) + 2*(cos(theta)**2 - sin(theta)**2)) < 1e-9)
chk("4.4 tan half-angle: t=n/m gives (m^2-n^2, 2mn, m^2+n^2) Pythagorean (m,n<=30)", all((m*m-n*n)**2 + (2*m*n)**2 == (m*m+n*n)**2 for m in range(1, 31) for n in range(1, m)))

print("== 6.3 / 7")
order3 = [0, 'a', 1]
rank = {0: 0, 'a': 1, 1: 2}
neg3 = lambda x: 1 if x == 0 else 0      # Heyting negation on the chain 0 < a < 1: x -> 0
chk("6.3 three-valued chain: not a = 0, not 0 = 1, so not-not a = 1 (not a)", neg3('a') == 0 and neg3(0) == 1 and neg3(neg3('a')) == 1)
# 7.2 co-offerings
neutrals = ('nought', 'scale', 'bounded infinity')
co = [(a, b) for a in neutrals for b in neutrals if a != b]
run = lambda fixed: sum(1 for a, b in co if a not in fixed and b not in fixed)
chk("7.1/7.2 six co-offerings; fixing 0,1,2,3 neutrals leaves 6,2,0,0 running ; 2^3 = 8 forms",
    len(co) == 6 and [run(set(neutrals[:k])) for k in range(4)] == [6, 2, 0, 0] and 2**3 == 8)
chk("7.4 1+15+20+24 = 60 ; 36:24 = 3:2", 1+15+20+24 == 60 and Fraction(36, 24) == Fraction(3, 2))
V = set()
for s1 in (1, -1):
    for s2 in (1, -1):
        for v in ((0, s1, s2*phi), (s1, s2*phi, 0), (s2*phi, 0, s1)):
            V.add(tuple(round(x, 9) for x in v))
V = sorted(V)
d2 = sorted(round(sum((a-b)**2 for a, b in zip(u, w)), 6) for u, w in combinations(V, 2))
chk("7.4 (0,+-1,+-phi) and cyclic orderings: 12 vertices, 30 shortest pairs (edges, length 2), 5 neighbours each",
    len(V) == 12 and d2.count(d2[0]) == 30 and abs(d2[0] - 4) < 1e-6)
chk("7.5 odd ring two-coloured has at least one like adjacent pair; even ring none (n=3..12)",
    all(min(sum(c[i] == c[(i+1) % n] for i in range(n)) for c in product((0, 1), repeat=n)) == (n % 2) for n in range(3, 13)))
chk("7.6 cube 8-12+6=2 ; cuboctahedron 12-24+(8+6)=2 ; 24 rotations, 48 with reflections", 8-12+6 == 2 and 12-24+14 == 2)
def r4(n):
    c = 0; m = isqrt(n)
    for a in range(-m, m+1):
        for b in range(-m, m+1):
            for cc in range(-m, m+1):
                r = n - a*a - b*b - cc*cc
                if r < 0: continue
                d = isqrt(r)
                if d*d == r: c += 1 if d == 0 else 2
    return c
sig = lambda n, odd=False: sum(d for d in range(1, n+1) if n % d == 0 and (not odd or d % 2))
chk("7.6 four-squares count: 8*sigma(n) at odd n, 24*(sum of odd divisors) at even n (n=1..60)",
    all(r4(n) == (8*sig(n) if n % 2 else 24*sig(n, True)) for n in range(1, 61)))
chk("7.6 8 = 3^2-1 ; 24 = 5^2-1 ; Hurwitz units 8 + 16 = 24", 8 == 3**2-1 and 24 == 5**2-1 and 8 + 2**4 == 24)
chk("7.6 (1/2,...,1/2) is at distance one from its nearest whole points only in four dimensions", [n for n in range(1, 30) if abs(sqrt(n)/2 - 1) < 1e-12] == [4])
def mat_order(M, lim=24):
    X = M
    for n in range(1, lim+1):
        if X == ((1, 0), (0, 1)): return n
        X = ((X[0][0]*M[0][0] + X[0][1]*M[1][0], X[0][0]*M[0][1] + X[0][1]*M[1][1]), (X[1][0]*M[0][0] + X[1][1]*M[1][0], X[1][0]*M[0][1] + X[1][1]*M[1][1]))
    return None
tre = ((1, 1), (-1, 0)); fig = ((2, 1), (1, 1))
chk("7.7 trefoil monodromy [[1,1],[-1,0]]: trace 1, order 6 ; figure-eight [[2,1],[1,1]]: trace 3, no finite order", tre[0][0]+tre[1][1] == 1 and mat_order(tre) == 6 and fig[0][0]+fig[1][1] == 3 and mat_order(fig) is None)
fin = set(); 
for a, b, c, d in product(range(-3, 4), repeat=4):
    if a*d - b*c == 1:
        o = mat_order(((a, b), (c, d)))
        if abs(a + d) < 2 and o is None: fin.add('bad')
        if abs(a + d) > 2 and o is not None: fin.add('bad2')
chk("7.7 SL(2,Z) elements (entries -3..3): |trace|<2 all periodic, |trace|>2 none periodic", not fin)
chk("7.8 C(5,2) = 10 = T4 = 1+3+6", comb(5, 2) == 10 == 4*5//2 == 1+3+6)
# pentagon: side parallel to the diagonal sharing no corner; diagonal = phi * side
pts = [(cos(2*pi*k/5), sin(2*pi*k/5)) for k in range(5)]
vec = lambda i, j: (pts[j][0]-pts[i][0], pts[j][1]-pts[i][1])
cross = lambda u, v: u[0]*v[1] - u[1]*v[0]
okp = True
for i in range(5):
    side = (i, (i+1) % 5)
    par = [d for d in combinations(range(5), 2) if (d[1]-d[0]) % 5 in (2, 3) and abs(cross(vec(*side), vec(*d))) < 1e-9]
    okp &= len(par) == 1 and not (set(par[0]) & set(side))
    okp &= abs((sum(x*x for x in vec(*par[0]))**0.5) / (sum(x*x for x in vec(*side))**0.5) - phi) < 1e-9
chk("7.8 each pentagon side is parallel to exactly one diagonal, the one sharing no corner; diagonal = phi * side", okp)
# D5 generated by the five double transpositions (reflections)
refl = []
for k in range(5):
    refl.append(tuple((2*k - i) % 5 for i in range(5)))
grp = {tuple(range(5))}
frontier = list(grp)
while frontier:
    g = frontier.pop()
    for r in refl:
        h = tuple(r[g[i]] for i in range(5))
        if h not in grp: grp.add(h); frontier.append(h)
chk("7.8 the five (side, parallel diagonal) exchanges generate the pentagon's ten symmetries: identity, 4 rotations, 5 keeping one corner",
    len(grp) == 10 and sum(1 for g in grp if sum(g[i] == i for i in range(5)) == 1) == 5 and sum(1 for g in grp if sum(g[i] == i for i in range(5)) == 0) == 4)
monster = {2:46, 3:20, 5:9, 7:6, 11:2, 13:3, 17:1, 19:1, 23:1, 29:1, 31:1, 41:1, 47:1, 59:1, 71:1}
P17 = [p for p in range(2, 60) if all(p % d for d in range(2, isqrt(p)+1))]
N = 1
for p, e in monster.items(): N *= p**e
chk("7.9 Monster order (%d) has fifteen prime factors: the seventeen primes less 37, 43, 53, plus 71" % N,
    len(monster) == 15 and sorted(monster) == sorted((set(P17) - {37, 43, 53}) | {71}) and N == 808017424794512875886459904961710757005754368000000000)
chk("7.9 196884 = 196883 + 1", 196884 == 196883 + 1)
print()
bad = [l for l, c in res if not c]
print("TOTAL checks:", len(res), " failed:", len(bad))
for l in bad: print("  FAILED:", l)
