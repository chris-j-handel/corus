# Torus-of-selves rule from Exhibit THREE 7.2, tested with my own re-typing of the printed resolver
# on every odd pair p <= q up to 13 by 29 (the range the project says it worked).
def resolve(carrying, offerings):
    surf = {}
    for key, val in offerings:
        if val != 0:
            cur = surf.get(key)
            if cur is None: surf[key] = 1 if val > 0 else -1
            elif (cur > 0) != (val > 0): surf[key] = 0
    ent = dict(surf)
    for key, val in carrying:
        cur = surf.get(key, 0)
        if cur != 0 and (cur > 0) == (val > 0): ent[key] = 0
        else: ent[key] = -1 if val > 0 else 1
    shared = list(ent.items())
    chain = dict(carrying)
    for key, val in shared:
        if val != 0: chain[key] = val
    return shared, list(chain.items())

def run_torus(p, q, T):
    ids = [(a, b) for a in range(p) for b in range(q)]
    state = {i: ([('s', -1 if (i[0] + i[1]) % 2 == 0 else 1)], []) for i in ids}
    outs = []
    for _ in range(T):
        nc, no, out = {}, {i: [] for i in ids}, []
        for i in ids:
            carrying, offerings = state[i]
            shared, nc[i] = resolve(carrying, offerings)
            out.append(shared[0][1])
            a, b = i
            no[((a + 1) % p, b)].extend(shared)      # released along at 9
            no[(a, (b + 1) % q)].extend(shared)      # shared across at 10
        state = {i: (nc[i], no[i]) for i in ids}
        outs.append(tuple(out))
    return outs

def ev_period(seq, maxp):
    n = len(seq)
    for per in range(1, maxp + 1):
        t0 = n - per
        while t0 > 0 and seq[t0 - 1] == seq[t0 - 1 + per]: t0 -= 1
        if t0 <= n - 3 * per: return per, t0 + 1
    return None, None

bad, n = [], 0
for p in range(1, 14, 2):
    for q in range(p, 30, 2):
        n += 1
        want = q if q > 2 * p else 4 * p
        T = 4 * max(4 * p, q) + 3 * p + 20
        per, t0 = ev_period(run_torus(p, q, T), 2 * max(4 * p, q))
        start = (3 * p - 1) if q > 2 * p else (3 * p - 3)
        flag = "" if (per == want) else "  <-- differs from rule"
        if per != want: bad.append((p, q, per, want))
        if (p, q) in ((3, 19), (5, 21), (13, 15), (1, 1), (5, 5), (9, 9), (13, 29), (7, 7), (3, 3), (1, 3), (11, 21), (11, 23)) or flag:
            print("  %2d by %2d: period %s from momentary %s ; rule %s from %s%s" % (p, q, per, t0, want, start, flag))
print("odd pairs tested:", n, " disagreeing with 'q if q > 2p else 4p':", bad)
