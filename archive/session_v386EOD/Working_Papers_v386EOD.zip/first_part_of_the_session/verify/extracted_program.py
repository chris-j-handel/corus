
"""Exhibit ONE · Natural Resolver"""


def _1_co_bi_tri_offering(_3_co_bi_co_sharing, _2_bi_co_bi_offering):
    _14_bi_tri_bi_moralizing = {}
    for _4_bi_co_bi_sharing, _7_co_bi_co_corusing in _2_bi_co_bi_offering:
        if _7_co_bi_co_corusing != 0:
            _15_tri_bi_tri_corusing = _14_bi_tri_bi_moralizing.get(_4_bi_co_bi_sharing)
            if _15_tri_bi_tri_corusing is None:
                _14_bi_tri_bi_moralizing[_4_bi_co_bi_sharing] = 1 if _7_co_bi_co_corusing > 0 else -1
            elif (_15_tri_bi_tri_corusing > 0) != (_7_co_bi_co_corusing > 0):
                _14_bi_tri_bi_moralizing[_4_bi_co_bi_sharing] = 0
    _12_bi_tri_bi_entraining = dict(_14_bi_tri_bi_moralizing)
    for _4_bi_co_bi_sharing, _7_co_bi_co_corusing in _3_co_bi_co_sharing:
        _15_tri_bi_tri_corusing = _14_bi_tri_bi_moralizing.get(_4_bi_co_bi_sharing, 0)
        if _15_tri_bi_tri_corusing != 0 and (_15_tri_bi_tri_corusing > 0) == (_7_co_bi_co_corusing > 0):
            _12_bi_tri_bi_entraining[_4_bi_co_bi_sharing] = 0
        else:
            _12_bi_tri_bi_entraining[_4_bi_co_bi_sharing] = -1 if _7_co_bi_co_corusing > 0 else 1
    _10_bi_tri_bi_tunneling = list(_12_bi_tri_bi_entraining.items())
    _11_tri_bi_tri_chaining = dict(_3_co_bi_co_sharing)
    for _4_bi_co_bi_sharing, _7_co_bi_co_corusing in _10_bi_tri_bi_tunneling:
        if _7_co_bi_co_corusing != 0:
            _11_tri_bi_tri_chaining[_4_bi_co_bi_sharing] = _7_co_bi_co_corusing
    return _10_bi_tri_bi_tunneling, list(_11_tri_bi_tri_chaining.items())


def _9_tri_bi_co_momentarying(_10_bi_tri_bi_tunneling, _5_co_bi_co_competencing):
    return [(_5_co_bi_co_competencing[_13_tri_bi_tri_competencing], _15_tri_bi_tri_corusing)
            for _13_tri_bi_tri_competencing, _15_tri_bi_tri_corusing in _10_bi_tri_bi_tunneling]


def _17_co_bi_tri_offering(_16_bi_tri_bi_torusing, _5_co_bi_co_competencing):
    _8_bi_co_bi_torusing = {}
    _14_bi_tri_bi_moralizing = {_13_tri_bi_tri_competencing: [] for _13_tri_bi_tri_competencing in _16_bi_tri_bi_torusing}
    for _13_tri_bi_tri_competencing, (_3_co_bi_co_sharing, _2_bi_co_bi_offering) in _16_bi_tri_bi_torusing.items():
        _10_bi_tri_bi_tunneling, _8_bi_co_bi_torusing[_13_tri_bi_tri_competencing] = _1_co_bi_tri_offering(
            _3_co_bi_co_sharing, _2_bi_co_bi_offering)
        _6_bi_co_bi_moralizing = _10_bi_tri_bi_tunneling
        for _4_bi_co_bi_sharing, _15_tri_bi_tri_corusing in _9_tri_bi_co_momentarying(
                [(_4_bi_co_bi_sharing, _15_tri_bi_tri_corusing)
                 for _4_bi_co_bi_sharing, _15_tri_bi_tri_corusing in (
                     ((_13_tri_bi_tri_competencing, 6), _6_bi_co_bi_moralizing),
                     ((_13_tri_bi_tri_competencing, 10), _10_bi_tri_bi_tunneling),
                     ((_13_tri_bi_tri_competencing, 9), _10_bi_tri_bi_tunneling))
                 if _4_bi_co_bi_sharing in _5_co_bi_co_competencing],
                _5_co_bi_co_competencing):
            _14_bi_tri_bi_moralizing[_4_bi_co_bi_sharing].extend(_15_tri_bi_tri_corusing)
    return {_13_tri_bi_tri_competencing: (_8_bi_co_bi_torusing[_13_tri_bi_tri_competencing],
                                           _14_bi_tri_bi_moralizing[_13_tri_bi_tri_competencing])
            for _13_tri_bi_tri_competencing in _16_bi_tri_bi_torusing}

CONNECTORS = {
    2: ('2-bi-co-bi-offering', 'bi-moral-so-far', 'arriving'),
    6: ('6-bi-co-bi-moralizing', 'not-yet-bi-moral', 'releasing'),
    9: ('9-tri-bi-co-momentarying', 'not-yet-co-competent', 'along'),
    10: ('10-bi-tri-bi-tunneling', 'not-yet-bi-moral', 'releasing'),
    14: ('14-bi-tri-bi-moralizing', 'bi-moral-so-far', 'arriving'),
    17: ('17-co-bi-tri-offering', 'co-competent-so-far', 'along'),
}
JOINS = {10: 14, 6: 2, 17: 9, 9: 17}
