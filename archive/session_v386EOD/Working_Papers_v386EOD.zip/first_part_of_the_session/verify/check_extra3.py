"""D: 'The spirals of Exhibit ONE's tables, alternating along, arrive outside as the between.'
Every spiral of the Exhibit's table (n = 1..11, 17, 59; self 1 carries -, alternating along 9), each member sharing
across (10) to one further self X that sends nothing back; _17 stepping together."""
import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

SYM = {1: '+', -1: '-', 0: '0', None: '.'}
for n in list(range(1, 12)) + [17, 59]:
    carry = {i: [('k', -1 if i % 2 == 0 else 1)] for i in range(n)}
    carry['X'] = [('k', 1)]
    joins = {(i, 9): (i + 1) % n for i in range(n)}
    for i in range(n):
        joins[(i, 10)] = 'X'
    steps = max(40, 8 * n + 8)
    state = {s: (list(c), []) for s, c in carry.items()}
    got = []
    for t in range(steps):
        offs = state['X'][1]
        comb = dict(ONE([], offs)[0]).get('k')          # the code's own combining of what X is offered
        got.append(SYM[comb])
        state = SEVENTEEN(state, joins)
    between = got == ['.'] + ['0'] * (steps - 1)
    print('spiral of %2d, %3d momentaries: X is offered %s ...  between at each momentary after the first: %s'
          % (n, steps, ' '.join(got[:9]), between))
