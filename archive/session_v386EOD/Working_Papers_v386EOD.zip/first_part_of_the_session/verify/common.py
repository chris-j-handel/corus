"""Shared helpers for the independent check (written before reading the report's scripts).

Loads the fenced python block of Exhibit ONE and offers two ways of running a society:
  run_together : every self stepped at once, by the program's own _17
  run_waiting  : one self stepped at a time, each later step consuming exactly one
                 releasing from each of its givers, first-in first-out per (giver, name)
"""
import collections

EXHIBIT = '/home/claude/chris-j-handel/corus/Exhibit_ONE_Natural_Resolver_v380R.md'
NAMES = (6, 10, 9)


def load():
    text = open(EXHIBIT, encoding='utf-8').read()
    code = text.split('```python', 1)[1].split('```', 1)[0]
    ns = {}
    exec(code, ns)
    return ns, code


NS, CODE = load()
ONE = NS['_1_co_bi_tri_offering']
NINE = NS['_9_tri_bi_co_momentarying']
SEVENTEEN = NS['_17_co_bi_tri_offering']


def val(shared, key='k'):
    """Shared value at key, None if the key is absent from the shared list."""
    d = dict(shared)
    return d.get(key)


def run_together(carry0, joins, steps, key='k', full=False):
    """Step all selves together with _17.  Returns {self: [value at key per step]}.

    The shared list of a self at a step is not returned by _17, so it is captured from
    inside _17 by wrapping the _1 it calls, and cross-checked against a direct _1 call
    on the state _17 was given.
    """
    state = {s: (list(c), []) for s, c in carry0.items()}
    out = {s: [] for s in carry0}
    carries = {s: [list(c)] for s, c in carry0.items()}
    calls = []
    real = NS['_1_co_bi_tri_offering']

    def spy(c, o):
        r = real(c, o)
        calls.append((list(c), list(o), list(r[0]), list(r[1])))
        return r

    for _ in range(steps):
        direct = {s: real(c, o) for s, (c, o) in state.items()}
        calls.clear()
        NS['_1_co_bi_tri_offering'] = spy
        try:
            nxt = SEVENTEEN(state, joins)
        finally:
            NS['_1_co_bi_tri_offering'] = real
        assert len(calls) == len(state)
        for (s, (c, o)), call in zip(state.items(), calls):
            assert call[0] == list(c) and call[1] == list(o)
            assert call[2] == list(direct[s][0]) and call[3] == list(direct[s][1])
            out[s].append(dict(call[2]) if full else val(call[2], key))
            assert list(nxt[s][0]) == call[3]
            carries[s].append(list(nxt[s][0]))
        state = nxt
    if full:
        return out, carries
    return out


def givers_of(selves, joins):
    g = {s: [] for s in selves}
    for (giver, name), receiver in joins.items():
        g[receiver].append((giver, name))
    return g


def run_waiting(carry0, joins, steps, choose, key='k', full=False, shuffle_givers=None,
                first_step_consumes=(), empty_counts=True):
    """One self at a time.

    choose(ready_list, done_dict) -> the self to step next.
    A self is ready when it has done fewer than `steps` steps and either it has done none
    (its first step is its own, nothing offered) or every one of its givers has at least one
    unconsumed releasing queued for it.  A releasing is the whole shared list, so a list
    holding a 0, or an empty list, counts as arrived.

    first_step_consumes: selves whose FIRST step also waits for and consumes one releasing
        from each giver (used only for the variant in B1; empty for the claim in A).
    empty_counts=False : negative control - a releasing that is an empty list is not queued.
    Returns ({self: [value per step]}, order_of_stepping).  Raises on deadlock.
    """
    selves = list(carry0)
    givers = givers_of(selves, joins)
    queues = {gn: collections.deque() for gn in joins}
    carrying = {s: list(c) for s, c in carry0.items()}
    done = {s: 0 for s in selves}
    out = {s: [] for s in selves}
    order = []

    def ready(s):
        if done[s] >= steps:
            return False
        if done[s] == 0 and s not in first_step_consumes:
            return True
        return all(queues[gn] for gn in givers[s])

    while True:
        r = [s for s in selves if ready(s)]
        if not r:
            break
        s = choose(r, done)
        if done[s] == 0 and s not in first_step_consumes:
            offerings = []
        else:
            gl = list(givers[s])
            if shuffle_givers is not None:
                shuffle_givers.shuffle(gl)
            offerings = []
            for gn in gl:
                offerings.extend(queues[gn].popleft())
        shared, carrying[s] = ONE(carrying[s], offerings)
        for name in NAMES:
            if (s, name) in joins:
                if empty_counts or shared:
                    queues[(s, name)].append(list(shared))
        out[s].append(dict(shared) if full else val(shared, key))
        done[s] += 1
        order.append(s)
    if any(done[s] != steps for s in selves):
        raise RuntimeError('deadlock: steps done %r' % (done,))
    return out, order


# ---- orders ---------------------------------------------------------------

def lowest_index(index):
    return lambda r, done: min(r, key=lambda s: index[s])


def highest_index(index):
    return lambda r, done: max(r, key=lambda s: index[s])


def fewest_done(index):
    return lambda r, done: min(r, key=lambda s: (done[s], index[s]))


def fewest_done_high(index):
    return lambda r, done: min(r, key=lambda s: (done[s], -index[s]))


def most_done(index):
    return lambda r, done: max(r, key=lambda s: (done[s], -index[s]))


def most_done_high(index):
    return lambda r, done: max(r, key=lambda s: (done[s], index[s]))


def uniform(rng):
    return lambda r, done: rng.choice(r)


def weighted(rng, weight):
    def ch(r, done):
        tot = sum(weight[s] for s in r)
        x = rng.random() * tot
        for s in r:
            x -= weight[s]
            if x <= 0:
                return s
        return r[-1]
    return ch


def starve(victim, rng):
    """Step anything but the victim for as long as anything else is ready."""
    def ch(r, done):
        others = [s for s in r if s != victim]
        return rng.choice(others) if others else victim
    return ch


# ---- arrangements ---------------------------------------------------------

def two_alike():
    return {0: [('k', 1)], 1: [('k', 1)]}, {(0, 10): 1, (1, 10): 0}


def ring(n, name=9):
    carry = {i: [('k', -1 if i % 2 == 0 else 1)] for i in range(n)}
    joins = {(i, name): (i + 1) % n for i in range(n)}
    return carry, joins


def torus(a, b):
    carry = {(i, j): [('k', -1 if (i + j) % 2 == 0 else 1)] for i in range(a) for j in range(b)}
    joins = {}
    for i in range(a):
        for j in range(b):
            joins[((i, j), 9)] = ((i + 1) % a, j)
            joins[((i, j), 10)] = (i, (j + 1) % b)
    return carry, joins


def random_society(rng, nmax=8, key='k'):
    n = rng.randint(1, nmax)
    carry = {}
    for i in range(n):
        c = rng.choice((1, -1, None))
        carry[i] = [] if c is None else [(key, c)]
    joins = {}
    for i in range(n):
        for name in NAMES:
            if rng.random() < 0.5:
                joins[(i, name)] = rng.randrange(n)
    return carry, joins
