"""A. Independent check of the central claim (Part ONE, section 2).

Claim: each self's first step is its own with nothing offered; each later step consumes one
releasing from each giver (0 counts), FIFO per (giver, name); then each self's sequence of
shared values equals what _17 gives stepping all together, whatever the order of stepping.
"""
import itertools
import random
import sys
import time

sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

T0 = time.time()
FAIL = []
TALLY = {}


def orders_for(carry, rng, n_random):
    index = {s: i for i, s in enumerate(carry)}
    out = [('lowest index', lowest_index(index)), ('highest index', highest_index(index)),
           ('fewest done', fewest_done(index)), ('fewest done, high first', fewest_done_high(index)),
           ('most done', most_done(index)), ('most done, high first', most_done_high(index))]
    for j in range(n_random):
        out.append(('random %d' % j, uniform(rng)))
    selves = list(carry)
    for j in range(2):
        w = {s: 10.0 ** rng.uniform(-2, 2) for s in selves}
        out.append(('weighted %d' % j, weighted(rng, w)))
    out.append(('starve', starve(rng.choice(selves), rng)))
    return out


def check(label, carry, joins, steps, rng, n_random, group):
    ref = run_together(carry, joins, steps)
    n_orders = 0
    distinct = set()
    for oname, ch in orders_for(carry, rng, n_random):
        for shuffle in (None, rng):
            got, order = run_waiting(carry, joins, steps, ch, shuffle_givers=shuffle)
            n_orders += 1
            distinct.add(tuple(order))
            if got != ref:
                FAIL.append((label, oname, carry, joins, order, ref, got))
    t = TALLY.setdefault(group, [0, 0, 0])
    t[0] += 1
    t[1] += n_orders
    t[2] += len(distinct)
    return ref, len(distinct)


rng = random.Random(386001)

# 1. two selves both +, joined both ways at 10
carry, joins = two_alike()
ref, d = check('two alike', carry, joins, 40, rng, 300, 'two selves + +, both ways at 10')
print('two alike, _17 together, first 12 steps:', {s: v[:12] for s, v in ref.items()})

# 2. rings n = 1..9 along 9
for n in range(1, 10):
    carry, joins = ring(n)
    ref, d = check('ring %d' % n, carry, joins, 12 * n + 24, rng, 100, 'rings n=1..9 along 9')
for n in (11, 13, 17):
    carry, joins = ring(n)
    check('ring %d' % n, carry, joins, 6 * n, rng, 30, 'rings n=11,13,17 along 9 (extra)')

# 3. torus 3 by 5
carry, joins = torus(3, 5)
check('torus 3x5', carry, joins, 60, rng, 100, 'torus 3 by 5')
for a, b in ((3, 7), (5, 7), (2, 2), (1, 4), (4, 4)):
    carry, joins = torus(a, b)
    check('torus %dx%d' % (a, b), carry, joins, 40, rng, 30, 'other toruses (extra)')

# 4. random societies
N_SOC = 2000
sizes = {}
nonempty = 0
with_self_join = 0
with_empty_carry = 0
few_orders = 0
for i in range(N_SOC):
    carry, joins = random_society(rng)
    sizes[len(carry)] = sizes.get(len(carry), 0) + 1
    nonempty += bool(joins)
    with_self_join += any(g == r for (g, _), r in joins.items())
    with_empty_carry += any(not c for c in carry.values())
    ref, d = check('random %d' % i, carry, joins, 30, rng, 24, 'random societies, 1..8 selves')
print('random societies: sizes', dict(sorted(sizes.items())), '| with any join', nonempty,
      '| with a self-join', with_self_join, '| with an empty carrying', with_empty_carry)

print()
print('%-40s %8s %10s %16s' % ('group', 'cases', 'orders run', 'distinct orders'))
for g, (a, b, c) in TALLY.items():
    print('%-40s %8d %10d %16d' % (g, a, b, c))
print('failures:', len(FAIL))
for f in FAIL[:5]:
    print('  FAIL', f)


# 5. exhaustive: every society of 1 and of 2 selves, every admissible order, a few steps
def all_orders(carry, joins, steps):
    """Every admissible order of stepping, by depth-first search over the ready sets."""
    import collections
    selves = list(carry)
    givers = givers_of(selves, joins)
    results = set()
    count = 0

    def rec(carrying, queues, done, out):
        nonlocal count
        r = [s for s in selves if done[s] < steps and
             (done[s] == 0 or all(queues[gn] for gn in givers[s]))]
        if not r:
            assert all(done[s] == steps for s in selves), 'deadlock'
            count += 1
            results.add(tuple((s, tuple(out[s])) for s in selves))
            return
        for s in r:
            c2 = dict(carrying)
            q2 = {gn: list(q) for gn, q in queues.items()}
            d2 = dict(done)
            o2 = {x: list(v) for x, v in out.items()}
            if done[s] == 0:
                off = []
            else:
                off = []
                for gn in givers[s]:
                    off.extend(q2[gn].pop(0))
            shared, c2[s] = ONE(c2[s], off)
            for name in NAMES:
                if (s, name) in joins:
                    q2[(s, name)].append(list(shared))
            o2[s].append(val(shared))
            d2[s] += 1
            rec(c2, q2, d2, o2)

    rec({s: list(c) for s, c in carry.items()}, {gn: [] for gn in joins},
        {s: 0 for s in selves}, {s: [] for s in selves})
    return results, count


ex_soc = 0
ex_orders = 0
ex_fail = []
for n, steps in ((1, 6), (2, 4)):
    slots = [(i, name) for i in range(n) for name in NAMES]
    for targets in itertools.product([None] + list(range(n)), repeat=len(slots)):
        joins = {sl: t for sl, t in zip(slots, targets) if t is not None}
        for cs in itertools.product((1, -1, None), repeat=n):
            carry = {i: ([] if c is None else [('k', c)]) for i, c in enumerate(cs)}
            ref = run_together(carry, joins, steps)
            res, cnt = all_orders(carry, joins, steps)
            ex_soc += 1
            ex_orders += cnt
            want = tuple((s, tuple(ref[s])) for s in carry)
            if res != {want}:
                ex_fail.append((carry, joins, want, res))
print()
print('exhaustive: every society of 1 self (6 steps) and of 2 selves (4 steps): %d societies, '
      '%d admissible orders in all, failures %d' % (ex_soc, ex_orders, len(ex_fail)))
for f in ex_fail[:3]:
    print('  EXHAUSTIVE FAIL', f)

# 3 selves, sampled, all admissible orders for 3 steps
rng3 = random.Random(386003)
ex3 = 0
ex3_orders = 0
ex3_fail = []
for i in range(1500):
    n = 3
    carry = {j: ([] if c is None else [('k', c)]) for j, c in enumerate(rng3.choice((1, -1, None)) for _ in range(n))}
    joins = {}
    for j in range(n):
        for name in NAMES:
            if rng3.random() < 0.5:
                joins[(j, name)] = rng3.randrange(n)
    ref = run_together(carry, joins, 3)
    res, cnt = all_orders(carry, joins, 3)
    ex3 += 1
    ex3_orders += cnt
    want = tuple((s, tuple(ref[s])) for s in carry)
    if res != {want}:
        ex3_fail.append((carry, joins, want, res))
print('exhaustive orders, 1500 random societies of 3 selves (3 steps): %d admissible orders in all, failures %d'
      % (ex3_orders, len(ex3_fail)))

print('seconds: %.1f' % (time.time() - T0))
print('A:', 'HOLDS in every case run' if not (FAIL or ex_fail or ex3_fail) else 'DOES NOT HOLD')
