"""Extra checks made after reading the three scripts (for parts C and D)."""
import collections
import random
import sys

sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

SYM = {1: '+', -1: '-', 0: '0', None: '.'}
show = lambda seq: ' '.join(SYM[v] for v in seq)

# 1. Exhibit ONE's remaining arrangements (those the report's script did not run), waiting model vs _17
print('1. Exhibit ONE arrangements the script did not run, 30 random orders + 6 fixed orders each:')
rng = random.Random(386100)


def crossed(p, q):
    c = {}
    j = {}
    for tag, n in (('A', p), ('B', q)):
        for i in range(n):
            c[(tag, i)] = [('k', -1 if i % 2 == 0 else 1)]
            j[((tag, i), 9)] = (tag, (i + 1) % n)
    j[(('A', 0), 10)] = ('B', 0)
    j[(('B', 0), 10)] = ('A', 0)
    return c, j


def torus_exhibit(p, q):
    return torus(p, q)


todo = []
for n in (6, 8, 10, 59):
    todo.append(('spiral of %d' % n, ring(n), 4 * n + 6))
for p, q in ((2, 3), (7, 11), (11, 13), (13, 17), (9, 15), (17, 59)):
    todo.append(('spirals %d and %d crossed' % (p, q), crossed(p, q), 60))
for p, q in ((1, 3), (2, 3), (1, 5), (3, 3), (3, 13), (5, 11), (7, 17)):
    todo.append(('torus %d by %d' % (p, q), torus(p, q), 60))
for a, b in ((1, 1), (1, -1)):
    for label, j in (('both ways', {(0, 10): 1, (1, 10): 0}), ('A from B alone', {(1, 10): 0}),
                     ('B from A alone', {(0, 10): 1}), ('neither', {})):
        todo.append(('two selves %s%s %s' % (SYM[a], SYM[b], label), ({0: [('k', a)], 1: [('k', b)]}, j), 30))
bad = 0
for label, (c, j), T in todo:
    ref = run_together(c, j, T)
    index = {s: i for i, s in enumerate(c)}
    chs = [lowest_index(index), highest_index(index), fewest_done(index), most_done(index),
           most_done_high(index), starve(next(iter(c)), rng)] + [uniform(rng) for _ in range(30)]
    orders = set()
    ok = True
    for ch in chs:
        got, order = run_waiting(c, j, T, ch)
        orders.add(tuple(order))
        ok &= (got == ref)
    bad += not ok
    print('   %-28s %3d momentaries, %2d distinct orders: %s' % (label, T, len(orders), 'the same' if ok else 'DIFFERS'))
print('   arrangements differing:', bad)

# 2. a releasing that is an EMPTY list (from a self carrying none): must it count as arrived?
print('2. a releasing that is an empty list not counted as arrived (societies drawn as the script draws them):')
rr = random.Random(386200)
dead = same = differ = with_none = 0
for trial in range(400):
    n = rr.randint(1, 7)
    c = {i: ([('k', rr.choice((1, -1)))] if rr.random() < .9 else []) for i in range(n)}
    j = {(i, name): rr.randrange(n) for i in range(n) for name in (6, 10, 9) if rr.random() < .5}
    ref = run_together(c, j, 30)
    with_none += any(not v for v in c.values())
    try:
        got, order = run_waiting(c, j, 30, uniform(rr), empty_counts=False)
        if got == ref:
            same += 1
        else:
            differ += 1
    except RuntimeError:
        dead += 1
print('   400 societies (%d with a self carrying none): same %d, differ %d, stuck (a self waits for ever) %d'
      % (with_none, same, differ, dead))
# smallest instance
c = {0: [], 1: [('k', 1)]}
j = {(0, 10): 1}
print('   smallest: self 0 carrying none releases to self 1 carrying +; _17 gives self 1', show(run_together(c, j, 6)[1]))
st = {s: (list(v), []) for s, v in c.items()}
nx = SEVENTEEN(st, j)
print('   _17: self 1\'s next offerings after self 0 (carrying none) released to it:', nx[1][1],
      '| and where nothing is joined to it:', SEVENTEEN(st, {})[1][1])

# 3. turns that wait for no arriving: does stopping a self after its 12th momentary change the tally?
print('3. turns waiting for no arriving, 12 momentaries compared, 30,000 drawings each:')


def no_wait(carry, joins, T, rr, stop):
    c = {s: list(v) for s, v in carry.items()}
    inbox = {s: [] for s in carry}
    out = {s: [] for s in carry}
    selves = list(carry)
    while any(len(out[s]) < T for s in selves):
        s = rr.choice([x for x in selves if len(out[x]) < T]) if stop else rr.choice(selves)
        offered, inbox[s] = inbox[s], []
        shared, c[s] = ONE(c[s], offered)
        out[s].append(val(shared))
        for name in NAMES:
            if (s, name) in joins:
                inbox[joins[(s, name)]].extend(shared)
    return {s: v[:T] for s, v in out.items()}


for label, (c, j) in (('two selves + +', two_alike()),
                      ('two selves + -', ({0: [('k', 1)], 1: [('k', -1)]}, {(0, 10): 1, (1, 10): 0})),
                      ('spiral of three', ring(3))):
    ref = run_together(c, j, 12)
    res = []
    for stop in (True, False):
        rr = random.Random(386300)
        res.append(sum(no_wait(c, j, 12, rr, stop) == ref for _ in range(30000)))
    print('   %-16s same as _17: %5d of 30000 (a self stopped after its 12th, as the script) | %5d of 30000 (every self kept in the draw)'
          % (label, res[0], res[1]))

# 4. the loop count for other loops: spiral of three, torus
print('4. releasings queued in the whole society after each entering (waiting model, first step its own):')
for label, (c, j), T in (('two selves + +', two_alike(), 6), ('spiral of three', ring(3), 6)):
    rr = random.Random(386400)
    seen = collections.Counter()
    for trial in range(200):
        selves = list(c)
        givers = givers_of(selves, j)
        queues = {gn: collections.deque() for gn in j}
        carrying = {s: list(v) for s, v in c.items()}
        done = {s: 0 for s in selves}
        counts = []
        while True:
            r = [s for s in selves if done[s] < T and (done[s] == 0 or all(queues[gn] for gn in givers[s]))]
            if not r:
                break
            s = rr.choice(r)
            off = []
            if done[s]:
                for gn in givers[s]:
                    off.extend(queues[gn].popleft())
            shared, carrying[s] = ONE(carrying[s], off)
            for name in NAMES:
                if (s, name) in j:
                    queues[(s, name)].append(list(shared))
            done[s] += 1
            counts.append(sum(len(q) for q in queues.values()))
        seen[tuple(counts[:len(selves) + 3])] += 1
    print('   %-16s first counts -> how many of 200 orders:' % label, dict(seen))
