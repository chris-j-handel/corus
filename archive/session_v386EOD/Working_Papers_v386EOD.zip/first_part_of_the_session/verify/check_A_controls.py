"""A, continued: controls showing the comparison in check_A.py is able to fail,
and a harder form of the claim (several keys per self)."""
import collections
import random
import sys

sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

rng = random.Random(386011)

# --- how non-trivial are the random societies? -------------------------------
triv = 0
has_zero = 0
N = 2000
r2 = random.Random(386001)
for i in range(N):
    carry, joins = random_society(rng)
    ref = run_together(carry, joins, 30)
    vals = [v for seq in ref.values() for v in seq]
    if all(v is None for v in vals):
        triv += 1
    if any(v == 0 for v in vals):
        has_zero += 1
print('random societies (fresh draw of %d): every shared value None in %d; a shared 0 somewhere in %d'
      % (N, triv, has_zero))


# --- control 1: a releasing that is all 0 / empty is NOT delivered ------------
def run_variant(carry0, joins, steps, choose, mode):
    """mode: 'lifo'            - newest releasing consumed first
             'drop_zero_token' - a releasing with no non-zero value is not queued
             'strip_zero'      - zeros removed from the releasing, releasing still queued
             'first_consumes'  - the first step also consumes whatever is queued (no waiting at step 1)
    Returns (out or None if deadlock)."""
    selves = list(carry0)
    givers = givers_of(selves, joins)
    queues = {gn: collections.deque() for gn in joins}
    carrying = {s: list(c) for s, c in carry0.items()}
    done = {s: 0 for s in selves}
    out = {s: [] for s in selves}

    def ready(s):
        if done[s] >= steps:
            return False
        if done[s] == 0:
            return True
        return all(queues[gn] for gn in givers[s])

    while True:
        r = [s for s in selves if ready(s)]
        if not r:
            break
        s = choose(r, done)
        offerings = []
        if done[s] == 0:
            if mode == 'first_consumes':
                for gn in givers[s]:
                    if queues[gn]:
                        offerings.extend(queues[gn].popleft())
        else:
            for gn in givers[s]:
                offerings.extend(queues[gn].pop() if mode == 'lifo' else queues[gn].popleft())
        shared, carrying[s] = ONE(carrying[s], offerings)
        for name in NAMES:
            if (s, name) in joins:
                if mode == 'drop_zero_token' and not any(v != 0 for _, v in shared):
                    continue
                if mode == 'strip_zero':
                    queues[(s, name)].append([(k, v) for k, v in shared if v != 0])
                else:
                    queues[(s, name)].append(list(shared))
        out[s].append(val(shared))
        done[s] += 1
    if any(done[s] != steps for s in selves):
        return None
    return out


for mode in ('lifo', 'drop_zero_token', 'strip_zero', 'first_consumes'):
    same = differ = dead = 0
    rr = random.Random(386012)
    for i in range(600):
        carry, joins = random_society(rr)
        ref = run_together(carry, joins, 30)
        for j in range(5):
            got = run_variant(carry, joins, 30, uniform(rr), mode)
            if got is None:
                dead += 1
            elif got == ref:
                same += 1
            else:
                differ += 1
    print('control %-16s on 600 random societies x 5 random orders: same %4d, differs %4d, deadlock %4d'
          % (mode, same, differ, dead))

# the same controls on the named arrangements
for label, (carry, joins) in (('two alike', two_alike()), ('ring 3', ring(3)), ('ring 5', ring(5)),
                              ('torus 3x5', torus(3, 5))):
    for mode in ('lifo', 'drop_zero_token', 'strip_zero', 'first_consumes'):
        same = differ = dead = 0
        rr = random.Random(386013)
        ref = run_together(carry, joins, 30)
        for j in range(100):
            got = run_variant(carry, joins, 30, uniform(rr), mode)
            if got is None:
                dead += 1
            elif got == ref:
                same += 1
            else:
                differ += 1
        print('  %-10s control %-16s x 100 random orders: same %3d, differs %3d, deadlock %3d'
              % (label, mode, same, differ, dead))

# --- harder form: several keys, each self carrying its own key and perhaps 'k' ---
rr = random.Random(386014)
maps_differ = lists_differ_fixed = lists_differ_shuffled = runs = 0
for i in range(800):
    n = rr.randint(1, 8)
    carry = {}
    for s in range(n):
        c = []
        if rr.random() < 0.7:
            c.append((('own', s), rr.choice((1, -1))))
        if rr.random() < 0.5:
            c.append(('k', rr.choice((1, -1))))
        if rr.random() < 0.3:
            c.append((('pair', s // 2), rr.choice((1, -1))))
        rr.shuffle(c)
        carry[s] = c
    joins = {}
    for s in range(n):
        for name in NAMES:
            if rr.random() < 0.5:
                joins[(s, name)] = rr.randrange(n)
    # reference, full shared lists
    state = {s: (list(c), []) for s, c in carry.items()}
    ref_lists = {s: [] for s in carry}
    for t in range(30):
        for s, (c, o) in state.items():
            ref_lists[s].append(list(ONE(c, o)[0]))
        state = SEVENTEEN(state, joins)
    ref_maps = {s: [dict(x) for x in v] for s, v in ref_lists.items()}
    index = {s: s for s in carry}
    for oname, ch, shuffle in (('random', uniform(rr), None), ('random', uniform(rr), rr),
                               ('most done', most_done(index), None), ('fewest', fewest_done(index), rr),
                               ('lowest', lowest_index(index), None), ('random', uniform(rr), rr)):
        # full=True gives dict(shared); list order needs a separate capture
        selves = list(carry)
        givers = givers_of(selves, joins)
        queues = {gn: collections.deque() for gn in joins}
        carrying = {s: list(c) for s, c in carry.items()}
        done = {s: 0 for s in selves}
        out = {s: [] for s in selves}
        while True:
            r = [s for s in selves if done[s] < 30 and (done[s] == 0 or all(queues[gn] for gn in givers[s]))]
            if not r:
                break
            s = ch(r, done)
            off = []
            if done[s]:
                gl = list(givers[s])
                if shuffle is not None:
                    shuffle.shuffle(gl)
                for gn in gl:
                    off.extend(queues[gn].popleft())
            shared, carrying[s] = ONE(carrying[s], off)
            for name in NAMES:
                if (s, name) in joins:
                    queues[(s, name)].append(list(shared))
            out[s].append(list(shared))
            done[s] += 1
        assert all(done[s] == 30 for s in selves)
        runs += 1
        if {s: [dict(x) for x in v] for s, v in out.items()} != ref_maps:
            maps_differ += 1
        if out != ref_lists:
            if shuffle is None:
                lists_differ_fixed += 1
            else:
                lists_differ_shuffled += 1
print('several keys per self, 800 societies x 6 orders = %d runs: key->value maps differ in %d; '
      'list ORDER differs in %d runs with givers read in _17\'s order, in %d runs with givers read in a shuffled order'
      % (runs, maps_differ, lists_differ_fixed, lists_differ_shuffled))
