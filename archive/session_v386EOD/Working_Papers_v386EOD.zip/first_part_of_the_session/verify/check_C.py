"""C. Looking for trivial reasons behind the three scripts' results.

The originals are not edited.  The functions of co_sequencing_v386EOD.py are loaded from the original
file's text (everything above the line `rng = random.Random(386)`), and the same draws are replayed
with the same seed while counting what the original does not print: lengths, distinct orders.
"""
import collections
import heapq
import random
import sys

F = '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/out/incoming/v386EOD/'
EXHIBIT = '/home/claude/chris-j-handel/corus/Exhibit_ONE_Natural_Resolver_v380R.md'

src = open(F + 'co_sequencing_v386EOD.py', encoding='utf-8').read()
head = src.split("rng = random.Random(386)", 1)[0]
sys.argv = ['x', EXHIBIT]
g = {}
exec(head, g)
together, at_arrivings, own_beat, first_parting = g['together'], g['at_arrivings'], g['own_beat'], g['first_parting']
ENTRY, K, say = g['ENTRY'], g['K'], g['say']

rng = random.Random(386)
PHI = (1 + 5 ** .5) / 2
SAME = 'the same at each self, each momentary'


def admissible_count(carry, joins, T, cap=10 ** 6):
    """Number of admissible orders (depends only on steps done), by counting paths; capped."""
    selves = list(carry)
    incoming = {s: [g_ for (g_, nm), r in joins.items() if r == s] for s in selves}
    from functools import lru_cache
    idx = {s: i for i, s in enumerate(selves)}

    @lru_cache(maxsize=None)
    def cnt(done):
        if all(d == T for d in done):
            return 1
        tot = 0
        for s in selves:
            d = done[idx[s]]
            if d >= T:
                continue
            if d == 0 or all(done[idx[gv]] >= d for gv in incoming[s]):
                # a later step d+1 of s needs step d of each giver done; a self-giver has done d already
                nd = list(done)
                nd[idx[s]] += 1
                tot += cnt(tuple(nd))
                if tot > cap:
                    return tot
        return tot
    return cnt(tuple(0 for _ in selves))


print('--- co_sequencing: replay with the same seed, counting lengths and distinct orders ---')
# 1
carry = {'A': [(K, 1)], 'B': [(K, 1)]}
joins = {('A', 10): 'B', ('B', 10): 'A'}
T = 13
tg = together(carry, joins, T)
orders = set()
short = 0
allsame = True
for trial in range(300):
    out, order = at_arrivings(carry, joins, T, rng, pace={'A': rng.random() + .01, 'B': rng.random() + .01})
    orders.add(tuple(order))
    short += any(len(out[s]) != T for s in carry)
    allsame &= (out == tg)
print('1. two selves: 300 draws, distinct orders %d, runs with a self short of %d momentaries: %d, exact equality of whole tables: %s'
      % (len(orders), T, short, allsame))
print('   last order as the original prints it:', ''.join(order[:26]))
out, order = at_arrivings(carry, joins, T, rng, first_at_arriving=('B',))
print('   B first at A\'s releasing: order', ''.join(order), '| A', say(out['A']), '| B', say(out['B']))
beats = {}
for label, period, phase in [('alike at once', {'A': 1, 'B': 1}, {'A': 0, 'B': 0}),
                             ('alike, one then other', {'A': 1, 'B': 1}, {'A': 0, 'B': .5}),
                             ('A twice per B', {'A': 1, 'B': 2}, {'A': 0, 'B': .5}),
                             ('phi', {'A': 1, 'B': PHI}, {'A': 0, 'B': .3})]:
    out, order = own_beat(carry, joins, T, period, phase)
    beats[label] = (out, order)
    print('   own beat %-22s A: %s | B: %s | order %s' % (label, say(out['A']), say(out['B']), ''.join(order)))

# 2
carry3 = {i: [(K, -1 if i % 2 == 0 else 1)] for i in range(3)}
joins3 = {(i, 9): (i + 1) % 3 for i in range(3)}
T = 24
tg = together(carry3, joins3, T)
orders = set()
short = 0
allsame = True
for trial in range(300):
    out, order = at_arrivings(carry3, joins3, T, rng, pace={i: rng.random() + .01 for i in range(3)})
    orders.add(tuple(order))
    short += any(len(out[s]) != T for s in carry3)
    allsame &= (out == tg)
print('2. spiral of three: 300 draws, distinct orders %d, short runs %d, exact equality %s' % (len(orders), short, allsame))
out, order = own_beat(carry3, joins3, T, {0: 1, 1: 1.3, 2: 1.7}, {0: 0, 1: .1, 2: .2})

# 3
spiral, along = g.get('spiral'), g.get('along')


def spiral(n, tag=''):
    return {(tag, i): [(K, -1 if i % 2 == 0 else 1)] for i in range(n)}


def along(n, tag=''):
    return {((tag, i), 9): (tag, (i + 1) % n) for i in range(n)}


arrangements = []
for n in (1, 2, 3, 4, 5, 7, 9, 11, 17):
    arrangements.append(('a spiral of %d' % n, spiral(n), along(n), 4 * n + 6))
for p, q in ((3, 5), (5, 7)):
    c = {}
    c.update(spiral(p, 'A'))
    c.update(spiral(q, 'B'))
    j = {}
    j.update(along(p, 'A'))
    j.update(along(q, 'B'))
    j[(('A', 0), 10)] = ('B', 0)
    j[(('B', 0), 10)] = ('A', 0)
    arrangements.append(('spirals of %d and %d crossed' % (p, q), c, j, 60))
for p, q in ((3, 5), (3, 7), (5, 7)):
    c = {(i, x): [(K, -1 if (i + x) % 2 == 0 else 1)] for i in range(p) for x in range(q)}
    j = {}
    for i in range(p):
        for x in range(q):
            j[((i, x), 9)] = ((i + 1) % p, x)
            j[((i, x), 10)] = (i, (x + 1) % q)
    arrangements.append(('a torus of %d along and %d across' % (p, q), c, j, 50))
print('3. arrangements, 40 draws each:')
for label, c, j, T in arrangements:
    tg = together(c, j, T)
    orders = set()
    short = 0
    allsame = True
    for trial in range(40):
        out, order = at_arrivings(c, j, T, rng, pace={s: rng.random() + .01 for s in c})
        orders.add(tuple(order))
        short += any(len(out[s]) != T for s in c)
        allsame &= (out == tg)
    print('   %-34s momentaries %3d | distinct orders among 40: %2d | short runs %d | exact equality %s'
          % (label, T, len(orders), short, allsame))

# 4
print('4. random societies:')
sizes = collections.Counter()
one_order = 0
no_join = 0
none_carry = 0
all_none_tables = 0
distinct_hist = collections.Counter()
short = 0
bad = 0
empty_releasing_met = 0
for trial in range(400):
    n = rng.randint(1, 7)
    c = {i: ([(K, rng.choice((1, -1)))] if rng.random() < .9 else []) for i in range(n)}
    j = {(i, name): rng.randrange(n) for i in range(n) for name in (6, 10, 9) if rng.random() < .5}
    tg = together(c, j, 30)
    sizes[n] += 1
    no_join += not j
    none_carry += any(not v for v in c.values())
    all_none_tables += all(v is None for seq in tg.values() for v in seq)
    orders = set()
    for k in range(10):
        out, order = at_arrivings(c, j, 30, rng, pace={s: rng.random() + .01 for s in c})
        orders.add(tuple(order))
        short += any(len(out[s]) != 30 for s in c)
        bad += (out != tg)
    distinct_hist[len(orders)] += 1
    if admissible_count(c, j, 4, cap=5) == 1:
        one_order += 1
print('   sizes', dict(sorted(sizes.items())), '| societies with no join at all:', no_join,
      '| with a self carrying none:', none_carry, '| tables that are all "."', all_none_tables)
print('   distinct orders among the 10 drawn, societies by that number:', dict(sorted(distinct_hist.items())))
print('   societies with exactly one admissible order (so every draw is the same order):', one_order)
print('   short runs', short, '| draws differing from 17:', bad, 'of 4000')

# --- first_parting cannot see a shorter table: demonstrate -------------------------------------------
print('--- first_parting on a table cut short ---')
tg = together(carry, joins, 13)
cut = {'A': tg['A'][:3], 'B': []}
print('   first_parting(full, cut-to-3-and-0 momentaries) ->', first_parting(tg, cut))

# --- the own-beat sequences: each self is stopped after 13 momentaries of its own ---------------------
print('--- own beats: what the stopping after 13 momentaries does ---')


def own_beat_until(carry, joins, horizon, period, phase):
    """Same rule as the original own_beat, but every self keeps its beat until a common time horizon."""
    c = {s: list(v) for s, v in carry.items()}
    inbox = {s: [] for s in carry}
    out = {s: [] for s in carry}
    times = {s: [] for s in carry}
    ev = [(phase[s], i, s) for i, s in enumerate(carry)]
    heapq.heapify(ev)
    while ev:
        t = ev[0][0]
        if t > horizon:
            break
        batch = []
        while ev and abs(ev[0][0] - t) < 1e-12:
            batch.append(heapq.heappop(ev))
        results = []
        for _, i, s in batch:
            offered, inbox[s] = inbox[s], []
            shared, c[s] = ENTRY(c[s], offered)
            out[s].append(dict(shared).get(K))
            times[s].append(t)
            results.append((i, s, shared))
        for i, s, shared in results:
            for name in (6, 10, 9):
                if (s, name) in joins:
                    inbox[joins[(s, name)]].extend(shared)
            heapq.heappush(ev, (t + period[s], i, s))
    return out, times


o13, order13 = beats['phi']
ofull, times = own_beat_until(carry, joins, 40.0, {'A': 1, 'B': PHI}, {'A': 0, 'B': .3})
print('   phi, original (each stopped after its own 13th):  A:', say(o13['A']), '| B:', say(o13['B']))
print('   phi, both keeping their beats (first 13 of each): A:', say(ofull['A'][:13]), '| B:', say(ofull['B'][:13]))
print('   B\'s entering times:', ' '.join('%.2f' % t for t in times['B'][:13]), '| A\'s 13th and last entering in the original is at time 12')
print('   B first differs at its momentary:',
      next((i + 1 for i, (x, y) in enumerate(zip(o13['B'], ofull['B'])) if x != y), None))
o13b, _ = beats['A twice per B']
ofullb, timesb = own_beat_until(carry, joins, 40.0, {'A': 1, 'B': 2}, {'A': 0, 'B': .5})
print('   A twice per B, original: B:', say(o13b['B']), '| both keeping beats: B:', say(ofullb['B'][:13]))
tgl = together(carry, joins, 20)
print('   together at 17 for comparison: ', say(tgl['A'][:13]))

# --- society_from_outside: the turns ------------------------------------------------------------------
print('--- society_from_outside part 1: replay, distinct turn orders, effect of stopping selves at 12 ---')
src2 = open(F + 'society_from_outside_v386EOD.py', encoding='utf-8').read()
head2 = src2.split("rng = random.Random(386)", 1)[0]
g2 = {}
exec(head2, g2)
tog2, turns2 = g2['together'], g2['turns_waiting_for_no_arriving']
rng = random.Random(386)


class Rec(random.Random):
    pass


for label, cr, jn in [
        ('two selves + +', {'A': [(K, 1)], 'B': [(K, 1)]}, {('A', 10): 'B', ('B', 10): 'A'}),
        ('two selves + -', {'A': [(K, 1)], 'B': [(K, -1)]}, {('A', 10): 'B', ('B', 10): 'A'}),
        ('a spiral of three', {i: [(K, -1 if i % 2 == 0 else 1)] for i in range(3)}, {(i, 9): (i + 1) % 3 for i in range(3)})]:
    tg = tog2(cr, jn, 12)
    same = 0
    outs = set()
    for trial in range(300):
        o = turns2(cr, jn, 12, rng)
        outs.add(tuple((s, tuple(v)) for s, v in o.items()))
        same += (o == tg)
    print('   %-18s same as 17 at %d of 300 | distinct result tables among the 300 draws: %d' % (label, same, len(outs)))

# --- how typical is "4 of 300" for two selves + - under the script's own function? -----------------------
print('--- society_from_outside part 1: the script\'s own function at 40 other seeds, two selves + - ---')
cr = {'A': [(K, 1)], 'B': [(K, -1)]}
jn = {('A', 10): 'B', ('B', 10): 'A'}
tg = tog2(cr, jn, 12)
counts = []
for seed in range(40):
    r = random.Random(seed)
    counts.append(sum(turns2(cr, jn, 12, r) == tg for _ in range(300)))
print('   same-as-17 counts out of 300 at seeds 0..39:', sorted(counts), '| mean %.1f' % (sum(counts) / len(counts)))
