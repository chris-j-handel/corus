"""B. Independent checks of the further claims B1..B7 (written before reading the report's scripts)."""
import ast
import collections
import itertools
import random
import sys
import types

sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

SYM = {1: '+', -1: '-', 0: '0', None: '.'}


def show(seq):
    return ' '.join(SYM[v] for v in seq)


def least_period(seq, start=0):
    seq = list(seq)[start:]
    for p in range(1, len(seq) // 2 + 1):
        if all(seq[i] == seq[i + p] for i in range(len(seq) - p)):
            return p
    return None


VERDICT = {}

# ------------------------------------------------------------------ B1
print('=== B1 ===')
carry, joins = two_alike()
ref = run_together(carry, joins, 48)
print('together      self 0:', show(ref[0][:13]), '| self 1:', show(ref[1][:13]))
ok_a = ref[0] == [-1, 0, 1, 0] * 12 and ref[1] == [-1, 0, 1, 0] * 12
print('  each is - 0 + 0 repeated over 48 steps:', ok_a, '| least period', least_period(ref[0]), least_period(ref[1]))

# variant: self 1's FIRST step waits for and consumes self 0's first releasing
orders_seen = set()
ok_b = True
for seed in range(50):
    rr = random.Random(seed)
    got, order = run_waiting(carry, joins, 48, uniform(rr), first_step_consumes={1})
    orders_seen.add(tuple(order))
    ok_b &= got[0] == [-1, 0, 1] * 16 and got[1] == [-1, 1, 0] * 16
print('second waits  self 0:', show(got[0][:13]), '| self 1:', show(got[1][:13]))
print('  self 0 is - 0 + repeated, self 1 is - + 0 repeated over 48 steps:', ok_b,
      '| least periods', least_period(got[0]), least_period(got[1]),
      '| distinct admissible orders met in 50 tries:', len(orders_seen))
VERDICT['B1'] = ok_a and ok_b and least_period(ref[0]) == 4 and least_period(got[0]) == 3 and least_period(got[1]) == 3


# how many releasings are queued in the loop after each entering?
def loop_counts(first_step_consumes, chooser, steps=12):
    selves = [0, 1]
    queues = {(0, 10): collections.deque(), (1, 10): collections.deque()}
    givers = {0: [(1, 10)], 1: [(0, 10)]}
    carrying = {0: [('k', 1)], 1: [('k', 1)]}
    done = {0: 0, 1: 0}
    counts = []
    carr = []
    while True:
        r = [s for s in selves if done[s] < steps and
             ((done[s] == 0 and s not in first_step_consumes) or all(queues[g] for g in givers[s]))]
        if not r:
            break
        s = chooser(r, done)
        off = []
        if not (done[s] == 0 and s not in first_step_consumes):
            for g in givers[s]:
                off.extend(queues[g].popleft())
        shared, carrying[s] = ONE(carrying[s], off)
        queues[(s, 10)].append(list(shared))
        done[s] += 1
        counts.append(sum(len(q) for q in queues.values()))
        carr.append((dict(carrying[0])['k'], dict(carrying[1])['k']))
    return counts, carr


allc = collections.Counter()
for seed in range(300):
    rr = random.Random(1000 + seed)
    c, carr = loop_counts((), uniform(rr))
    allc[tuple(c)] += 1
print('  releasings queued in the loop after each entering, each first step its own (300 random orders):')
for k, v in allc.items():
    print('    ', list(k), 'x', v)
c, carr = loop_counts({1}, uniform(random.Random(5)))
print('  the same where the second self\'s first step consumes the first self\'s first releasing:', c)

# ------------------------------------------------------------------ B2
print('=== B2 ===')


def run_no_wait(carry0, joins, turns, key='k'):
    """A self steps whenever drawn and consumes everything queued for it, possibly nothing."""
    selves = list(carry0)
    givers = givers_of(selves, joins)
    queues = {gn: [] for gn in joins}
    carrying = {s: list(c) for s, c in carry0.items()}
    out = {s: [] for s in selves}
    for s in turns:
        off = []
        for gn in givers[s]:
            for rel in queues[gn]:
                off.extend(rel)
            queues[gn] = []
        shared, carrying[s] = ONE(carrying[s], off)
        for name in NAMES:
            if (s, name) in joins:
                queues[(s, name)].append(list(shared))
        out[s].append(val(shared, key))
    return out


def tally_no_wait(label, carry, joins, L, drawings, seed, mode):
    rr = random.Random(seed)
    selves = list(carry)
    ref = run_together(carry, joins, L)
    same = 0
    for d in range(drawings):
        if mode == 'uniform':        # one self drawn uniformly at each turn, until each has L steps
            turns = []
            cnt = {s: 0 for s in selves}
            while min(cnt.values()) < L:
                s = rr.choice(selves)
                turns.append(s)
                cnt[s] += 1
        else:                        # each round every self once, in a fresh random order
            turns = []
            for _ in range(L):
                p = list(selves)
                rr.shuffle(p)
                turns.extend(p)
        got = run_no_wait(carry, joins, turns)
        if all(got[s][:L] == ref[s] for s in selves):
            same += 1
    return same


b2_rows = []
for label, (carry, joins) in (('two alike (+ +, both ways at 10)', two_alike()),
                              ('two opposite (+ -, both ways at 10)', ({0: [('k', 1)], 1: [('k', -1)]}, {(0, 10): 1, (1, 10): 0})),
                              ('ring of 3 along 9', ring(3)),
                              ('ring of 5 along 9', ring(5)),
                              ('torus 3 by 5', torus(3, 5))):
    for mode in ('uniform', 'round-shuffled'):
        for L in (8, 13, 24):
            s = [tally_no_wait(label, carry, joins, L, 300, seed, mode) for seed in (1, 2, 3)]
            b2_rows.append((label, mode, L, s))
            print('  %-36s turns %-14s first %2d steps compared: same as _17 in %s of 300 (three seeds)'
                  % (label, mode, L, s))
rr = random.Random(77)
same = tot = 0
for i in range(1000):
    carry, joins = random_society(rr)
    if len(carry) < 2 or not joins:
        continue
    selves = list(carry)
    ref = run_together(carry, joins, 20)
    turns = []
    cnt = {s: 0 for s in selves}
    while min(cnt.values()) < 20:
        s = rr.choice(selves)
        turns.append(s)
        cnt[s] += 1
    got = run_no_wait(carry, joins, turns)
    tot += 1
    same += all(got[s][:20] == ref[s] for s in selves)
print('  random societies (2..8 selves, at least one join), one uniform drawing each, 20 steps: same in %d of %d' % (same, tot))
VERDICT['B2'] = all(max(s) < 150 for (label, mode, L, s) in b2_rows if label.startswith(('two alike', 'ring of 3')))

# ------------------------------------------------------------------ B3
print('=== B3 ===')
tree = ast.parse(CODE)
funcs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
J = '_5_co_bi_co_competencing'


def stores_and_mutations(fn):
    found = []
    for node in ast.walk(fn):
        if isinstance(node, ast.Name) and node.id == J and isinstance(node.ctx, (ast.Store, ast.Del)):
            found.append(('name bound/deleted', node.lineno))
        if isinstance(node, (ast.Subscript, ast.Attribute)) and isinstance(node.ctx, (ast.Store, ast.Del)):
            base = node.value
            while isinstance(base, (ast.Subscript, ast.Attribute)):
                base = base.value
            if isinstance(base, ast.Name) and base.id == J:
                found.append(('item/attribute set', node.lineno))
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            base = node.func.value
            if isinstance(base, ast.Name) and base.id == J:
                found.append(('method call .%s' % node.func.attr, node.lineno))
        if isinstance(node, (ast.Global, ast.Nonlocal)) and J in node.names:
            found.append(('global/nonlocal', node.lineno))
    return found


uses = collections.defaultdict(list)
for name, fn in funcs.items():
    for node in ast.walk(fn):
        if isinstance(node, ast.Name) and node.id == J:
            uses[name].append((node.lineno, type(node.ctx).__name__))
        if isinstance(node, ast.arg) and node.arg == J:
            uses[name].append((node.lineno, 'parameter'))
print('  where the joins name occurs:', dict(uses))
mut = {name: stores_and_mutations(fn) for name, fn in funcs.items()}
print('  assignments / deletions / item sets / method calls on it:', mut)
module_level = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Name) and n.id == J and isinstance(n.ctx, ast.Store)]
print('  stores anywhere in the block:', module_level)
ret17 = [n for n in ast.walk(funcs['_17_co_bi_tri_offering']) if isinstance(n, ast.Return)]
ret_names = sorted({n.id for r in ret17 for n in ast.walk(r) if isinstance(n, ast.Name)})
print('  names in the return expression of _17:', ret_names)
ok_static = not any(mut.values()) and not module_level and J not in ret_names


# dynamic: a read-only mapping, and a dict that records any write
class Watch(dict):
    writes = 0

    def _w(self, *a, **k):
        Watch.writes += 1
        raise AssertionError('write attempted')
    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = __ior__ = _w


rr = random.Random(9)
dyn_ok = True
contains_joins = 0
for i in range(500):
    carry, joins = random_society(rr)
    before = dict(joins)
    state = {s: (list(c), []) for s, c in carry.items()}
    w = Watch(joins)
    ro = types.MappingProxyType(dict(joins))
    for t in range(10):
        a = SEVENTEEN(state, w)
        b = SEVENTEEN(state, ro)
        dyn_ok &= (a == b)
        dyn_ok &= (dict(w) == before)
        # what is returned: {self: (list, list)} and nothing else
        dyn_ok &= set(a) == set(state)
        for s, v in a.items():
            dyn_ok &= isinstance(v, tuple) and len(v) == 2 and isinstance(v[0], list) and isinstance(v[1], list)
            for item in v[0] + v[1]:
                # every item is a (key, value) pair; no (self, name) pair of the joins is in it
                dyn_ok &= isinstance(item, tuple) and len(item) == 2 and item[0] == 'k' and item[1] in (1, -1, 0)
        if a is w or any(x is w for x in a.values()):
            contains_joins += 1
        state = a
print('  dynamic, 500 random societies x 10 steps: writes attempted on joins:', Watch.writes,
      '| read-only mapping accepted and same result, return holds only {self: (carrying, offerings)}:', dyn_ok)

# a shared 0 IS delivered
st = {0: ([('k', 1)], [('k', 1)]), 1: ([], [])}
sh, nc = ONE(*st[0])
nx = SEVENTEEN(st, {(0, 10): 1})
print('  self 0 carrying +, offered + : shared', sh, '-> _17 gives self 1 next offerings', nx[1][1])
ok_zero_delivered = sh == [('k', 0)] and nx[1][1] == [('k', 0)]
for name in NAMES:
    assert SEVENTEEN(st, {(0, name): 1})[1][1] == [('k', 0)]
# count delivered zeros in ordinary runs
carry, joins = two_alike()
state = {s: (list(c), []) for s, c in carry.items()}
zeros = 0
for t in range(12):
    state = SEVENTEEN(state, joins)
    zeros += sum(1 for s in state for _, v in state[s][1] if v == 0)
print('  two alike, 12 steps of _17: zero-valued items found in next-offerings lists:', zeros)

# _1 skips offered zeros
skip_ok = True
skip_ok &= ONE([], [('k', 0)]) == ([], [])
skip_ok &= ONE([('k', 1)], [('k', 0)]) == ONE([('k', 1)], [])
skip_ok &= ONE([('k', -1)], [('k', 0)]) == ONE([('k', -1)], [])
skip_ok &= ONE([], [('k', 1), ('k', 0)]) == ONE([], [('k', 1)])
skip_ok &= ONE([], [('k', 0), ('k', -1), ('k', 0)]) == ONE([], [('k', -1)])
rr = random.Random(10)
for i in range(20000):
    c = [(k, rr.choice((1, -1))) for k in rr.sample('abcd', rr.randint(0, 4))]
    o = [(rr.choice('abcde'), rr.choice((1, -1, 0))) for _ in range(rr.randint(0, 7))]
    skip_ok &= ONE(c, o) == ONE(c, [x for x in o if x[1] != 0])
print('  _1 gives the same with offered zeros removed (20,000 random calls, several keys):', skip_ok)
VERDICT['B3'] = ok_static and dyn_ok and Watch.writes == 0 and ok_zero_delivered and skip_ok and zeros > 0

# ------------------------------------------------------------------ B4
print('=== B4 ===')
r1 = ONE([('k', 1)], [('m', 1)])
r2 = ONE([('k', 1)], [('m', 0)])
r3 = ONE([('k', 1)], [('m', 1), ('m', -1)])
r4 = ONE([('k', 1)], [('m', -1), ('m', 1)])
print('  _1([k+],[m+])      =', r1)
print('  _1([k+],[m0])      =', r2)
print('  _1([k+],[m+, m-])  =', r3)
print('  _1([k+],[m-, m+])  =', r4)
VERDICT['B4'] = (set(r1[0]) == {('m', 1), ('k', -1)} and set(r1[1]) == {('k', -1), ('m', 1)}
                 and all(k != 'm' for k, _ in r2[1]) and r2[1] == [('k', -1)]
                 and all(k != 'm' for k, _ in r3[1]) and all(k != 'm' for k, _ in r4[1]))
print('  with [m0] is m in the SHARED list?', any(k == 'm' for k, _ in r2[0]),
      '| with [m+, m-] the shared list is', r3[0])

# ------------------------------------------------------------------ B5
print('=== B5 ===')


def outside(members, ring_name=9, self_join_single=True, steps=41, extra_joins=None, x_carry=1):
    """Members 0..n-1 in a ring at 9; each member's 10 to 'X'; X sends nothing back.
    Returns the list, step by step, of the set of non-zero signs in X's offerings."""
    n = len(members)
    carry = {i: [('k', v)] for i, v in enumerate(members)}
    carry['X'] = [('k', x_carry)]
    joins = {}
    if n > 1 or self_join_single:
        for i in range(n):
            joins[(i, ring_name)] = (i + 1) % n
    for i in range(n):
        joins[(i, 10)] = 'X'
    if extra_joins:
        joins.update(extra_joins)
    state = {s: (list(c), []) for s, c in carry.items()}
    got = []
    xs = []
    for t in range(steps):
        offs = state['X'][1]
        signs = {v for _, v in offs if v != 0}
        got.append('.' if not signs else ('0' if len(signs) == 2 else SYM[signs.pop()]))
        # what _1 itself makes of these offerings for a self carrying nothing
        comb = dict(ONE([], offs)[0]).get('k')
        assert SYM[comb] == got[-1], (comb, got[-1])
        xs.append(val(ONE(*state['X'])[0]))
        state = SEVENTEEN(state, joins)
    return got, xs


b5_ok = True
for members, sj, label in (((1,), False, 'one self +, joined to no member'),
                           ((1,), True, 'one self +, ring of one (joined to itself at 9)'),
                           ((1, 1), True, 'pair + +'), ((1, 1, 1), True, 'three + + +'),
                           ((1, 1, 1, 1), True, 'four alike +'), ((1,) * 5, True, 'five alike +'), ((1,) * 6, True, 'six alike +'),
                           ((-1, -1), True, 'pair - -'), ((-1, -1, -1), True, 'three - - -'),
                           ((1, -1), True, 'pair + -'), ((-1, 1), True, 'pair - +'),
                           ((-1, 1, -1), True, 'ring - + -'), ((-1, 1, -1, 1), True, 'ring - + - +'),
                           ((-1, 1, -1, 1, -1), True, 'ring - + - + -')):
    got, xs = outside(members, self_join_single=sj)
    print('  %-48s %s   | X (carrying +) releases %s' % (label, ' '.join(got[:9]), show(xs[:9])))
    if len(set(members)) == 1 and (len(members) > 1 or sj):
        a, b = ('-', '+') if members[0] == 1 else ('+', '-')
        want = ['.'] + [(a, '.', b, '.')[i % 4] for i in range(len(got) - 1)]
        b5_ok &= got == want
    elif len(set(members)) == 2:
        b5_ok &= got == ['.'] + ['0'] * (len(got) - 1)
VERDICT['B5'] = b5_ok
print('  alike rings give . - . + . (or . + . - .), parting pair and alternating rings 3,4,5 give . 0 0 0 ...: over 41 steps', b5_ok)

# wider: EVERY ring of members that are not all alike, n = 2..9, 200 steps
bad = []
checked = 0
for n in range(2, 10):
    for members in itertools.product((1, -1), repeat=n):
        if len(set(members)) == 1:
            continue
        got, xs = outside(members, steps=120)
        checked += 1
        if got != ['.'] + ['0'] * 119:
            bad.append((members, ' '.join(got[:16])))
print('  wider: every ring along 9, n=2..9, members not all alike: %d rings; X is NOT offered + and - together at every later step in %d'
      % (checked, len(bad)))
for b in bad[:6]:
    print('     e.g.', b)

# members that part, coupled otherwise than in a ring
ex = outside((1, -1), self_join_single=True, steps=17, extra_joins={(0, 9): 0, (1, 9): 0})
print('  members + -, each joined at 9 to member 0 (not a ring):', ' '.join(ex[0]))
carry = {0: [('k', 1)], 1: [('k', -1)], 'X': [('k', 1)]}
joins = {(0, 9): 0, (0, 6): 1, (0, 10): 'X', (1, 10): 'X'}
state = {s: (list(c), []) for s, c in carry.items()}
g = []
for t in range(17):
    signs = {v for _, v in state['X'][1] if v != 0}
    g.append('.' if not signs else ('0' if len(signs) == 2 else SYM[signs.pop()]))
    state = SEVENTEEN(state, joins)
print('  members + -, member 0 joined to itself at 9 and to member 1 at 6:', ' '.join(g))

# ------------------------------------------------------------------ B6
print('=== B6 ===')


def both_ways(members, x_carry, steps=64):
    """X joined both ways with the members.  1 member: 10 each way.  2 members: members in a ring at 9,
    each member's 10 to X, X's 10 to the first and X's 9 to the second.  3 members: X's 6 to the third as well."""
    n = len(members)
    carry = {i: [('k', v)] for i, v in enumerate(members)}
    carry['X'] = [('k', x_carry)]
    joins = {}
    if n > 1:
        for i in range(n):
            joins[(i, 9)] = (i + 1) % n
    for i in range(n):
        joins[(i, 10)] = 'X'
    out_names = (10, 9, 6)
    for i in range(n):
        joins[('X', out_names[i])] = i
    ref = run_together(carry, joins, steps)
    return ref['X'], ref


table = {}
for label, members in (('one self +', (1,)), ('pair + +', (1, 1)), ('one self -', (-1,)), ('pair - -', (-1, -1)),
                       ('pair + -', (1, -1)), ('pair - +', (-1, 1)), ('ring - + -', (-1, 1, -1))):
    row = []
    for xc in (1, -1):
        xs, ref = both_ways(members, xc)
        table[(label, xc)] = xs
        row.append(show(xs[:8]))
    print('  X both ways with %-11s  X carrying + releases %s | X carrying - releases %s' % (label, row[0], row[1]))
b6 = all(table[('pair + +', xc)] == table[('one self +', xc)] for xc in (1, -1))
b6m = all(table[('pair - -', xc)] == table[('one self -', xc)] for xc in (1, -1))
print('  pair + + gives X the same as one self +, X carrying + and X carrying -, 64 steps:', b6)
print('  pair - - gives X the same as one self -, X carrying + and X carrying -, 64 steps:', b6m)
alone = {xc: run_together({'X': [('k', xc)]}, {}, 64)['X'] for xc in (1, -1)}
print('  X with none offered: carrying +', show(alone[1][:8]), '| carrying -', show(alone[-1][:8]))
print('  parting rows equal X-with-none-offered over 64 steps:',
      all(table[(lab, xc)] == alone[xc] for lab in ('pair + -', 'pair - +', 'ring - + -') for xc in (1, -1)))
VERDICT['B6'] = b6
# is the "pair alike = one self" result sensitive to which X-name goes to which member, or to the members' ring name?
alt = []
for xc in (1, -1):
    carry = {0: [('k', 1)], 1: [('k', 1)], 'X': [('k', xc)]}
    for xnames in ((10, 9), (9, 10), (6, 10), (10, 6), (6, 9)):
        for ringname in (9, 6):
            joins = {(0, ringname): 1, (1, ringname): 0, (0, 10): 'X', (1, 10): 'X', ('X', xnames[0]): 0, ('X', xnames[1]): 1}
            alt.append(run_together(carry, joins, 64)['X'] == table[('one self +', xc)])
    # X reaching only ONE member of the pair
    joins = {(0, 9): 1, (1, 9): 0, (0, 10): 'X', (1, 10): 'X', ('X', 10): 0}
    one = run_together(carry, joins, 64)['X']
    print('  X carrying %s reaching only the first member of the pair + +: %s  (same as one self +: %s)'
          % (SYM[xc], show(one[:12]), one == table[('one self +', xc)]))
print('  other namings of the same arrangement (20 variants) all the same as one self +:', all(alt))

# ------------------------------------------------------------------ B7
print('=== B7 ===')
b7_ok = True
for n in list(range(1, 10)) + [11, 13, 17, 2 * 9, 21]:
    steps = 12 * n + 24
    carry, joins = ring(n)
    shares, carries = run_together(carry, joins, steps, full=True)
    c = [[dict(carries[i][t])['k'] for i in range(n)] for t in range(steps + 1)]     # c[t][i], start of step t
    y = [[c[t][i] * (1 if t % 2 == 0 else -1) for i in range(n)] for t in range(steps + 1)]
    rule = (y[1] == y[0])
    flips = [[y[t + 1][i] != y[t][i] for i in range(n)] for t in range(steps)]        # flip AT step t
    mism = 0
    for t in range(1, steps):
        for i in range(n):
            want = (y[t][(i - 1) % n] == y[t][i]) and (not flips[t - 1][(i - 1) % n])
            if want != flips[t][i]:
                mism += 1
    # the report's wording, read literally: "changes at the second momentary after its giver changed"
    lit = 0
    for t in range(2, steps):
        for i in range(n):
            want = (y[t][(i - 1) % n] == y[t][i]) and flips[t - 2][(i - 1) % n]
            if want != flips[t][i]:
                lit += 1
    pc = least_period([tuple(r) for r in c])
    ps = least_period([tuple(shares[i][t].get('k') for i in range(n)) for t in range(steps)])
    py = least_period([tuple(r) for r in y])
    opp = all(c[t][i] == -c[t][(i - 1) % n] for t in range(steps + 1) for i in range(n))
    want_p = 4 * n if n % 2 else 2
    good = rule and mism == 0 and pc == want_p
    if n in list(range(1, 10)) + [11, 13, 17]:
        b7_ok &= good
    print('  n=%2d steps %3d: y(1)=y(0) %s | rule mismatches %d | literal "second momentary after" mismatches (t>=2) %d | '
          'least period of c %s (claimed %d), of releasings %s, of y %s | each self opposite its giver always: %s'
          % (n, steps, rule, mism, lit, pc, want_p, ps, py, opp))
VERDICT['B7'] = b7_ok

# the rule is an identity of _1 on any ring: check with random (not alternating) carryings too
rr = random.Random(21)
mm = 0
for trial in range(300):
    n = rr.randint(1, 12)
    carry = {i: [('k', rr.choice((1, -1)))] for i in range(n)}
    joins = {(i, 9): (i + 1) % n for i in range(n)}
    steps = 60
    shares, carries = run_together(carry, joins, steps, full=True)
    c = [[dict(carries[i][t])['k'] for i in range(n)] for t in range(steps + 1)]
    y = [[c[t][i] * (1 if t % 2 == 0 else -1) for i in range(n)] for t in range(steps + 1)]
    flips = [[y[t + 1][i] != y[t][i] for i in range(n)] for t in range(steps)]
    mm += y[1] != y[0]
    for t in range(1, steps):
        for i in range(n):
            want = (y[t][(i - 1) % n] == y[t][i]) and (not flips[t - 1][(i - 1) % n])
            mm += want != flips[t][i]
print('  the same rule on 300 rings with random carryings (n 1..12, 60 steps): mismatches', mm)

print()
for k in sorted(VERDICT):
    print(k, 'HOLDS' if VERDICT[k] else 'DOES NOT HOLD')
