"""Two more checks for part D: the golden-ratio beats without stopping a self, and alike members not coupled along."""
import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify')
from common import *  # noqa

SYM = {1: '+', -1: '-', 0: '0', None: '.'}
show = lambda seq: ' '.join(SYM[v] for v in seq)
PHI = (1 + 5 ** .5) / 2


def beats(n_a, n_b):
    """A enters at times 0,1,2,..,n_a-1; B at 0.3 + k*PHI for k < n_b.  Each meets everything arrived since its last entering."""
    ev = [(float(k), 'A') for k in range(n_a)] + [(0.3 + k * PHI, 'B') for k in range(n_b)]
    ev.sort()
    gaps = min(b[0] - a[0] for a, b in zip(ev, ev[1:]))
    carrying = {'A': [('k', 1)], 'B': [('k', 1)]}
    inbox = {'A': [], 'B': []}
    out = {'A': [], 'B': []}
    log = []
    for t, s in ev:
        off, inbox[s] = inbox[s], []
        shared, carrying[s] = ONE(carrying[s], off)
        out[s].append(val(shared))
        other = 'B' if s == 'A' else 'A'
        inbox[other].extend(shared)
        log.append((round(t, 2), s, [SYM[v] for _, v in off], SYM[val(shared)]))
    return out, gaps, log


o_stop, gap, log = beats(13, 13)       # as the script: A stops after its 13th (time 12), B goes on to time 19.72
o_keep, gap2, log2 = beats(40, 13)     # A keeps its beat past B's 13th
print('A stopped after its 13th: A', show(o_stop['A']), '| B', show(o_stop['B']))
print('A keeping its beat:       A', show(o_keep['A'][:13]), '| B', show(o_keep['B']))
print('smallest gap between two enterings: %.3f (no two at once)' % min(gap, gap2))
print('B\'s 9th entering, A stopped:', [x for x in log if x[1] == 'B'][8])
print('B\'s 9th entering, A keeping:', [x for x in log2 if x[1] == 'B'][8])
print('report: A - 0 + - 0 + 0 - + 0 - 0 + | B - + - + - + - + 0 - + - +')

# alike members joined to nothing but X
carry = {0: [('k', 1)], 1: [('k', 1)], 'X': [('k', 1)]}
joins = {(0, 10): 'X', (1, 10): 'X'}
state = {s: (list(c), []) for s, c in carry.items()}
got = []
for t in range(9):
    signs = {v for _, v in state['X'][1] if v != 0}
    got.append('.' if not signs else ('0' if len(signs) == 2 else SYM[signs.pop()]))
    state = SEVENTEEN(state, joins)
print('pair + + NOT coupled along, each sharing across to X: X is offered', ' '.join(got))

# three selves in a line, as Exhibit ONE's table: A's parity offered to B in the first momentary alone
for a in (1, -1):
    state = {'B': ([('k', 1)], [('k', a)]), 'C': ([('k', 1)], [])}
    joins = {('B', 9): 'C'}
    rows = {'B': [], 'C': []}
    for t in range(2):
        for s, (c, o) in state.items():
            rows[s].append(val(ONE(c, o)[0]))
        state = SEVENTEEN(state, joins)
    print('three in a line, A offering %s to B in the first momentary: B %s | C %s' % (SYM[a], show(rows['B']), show(rows['C'])))

# longer run, neither self stopped: does B ever release 0?
o_long, g3, _ = beats(400, 240)   # A to time 399, B to time 0.3 + 239*PHI = 387
print('both keeping their beats, B\'s first 240 momentaries: zeros %d, strictly alternating - + : %s'
      % (o_long['B'].count(0), all(o_long['B'][i] == (-1 if i % 2 == 0 else 1) for i in range(240))))
print('   A\'s first 26:', show(o_long['A'][:26]))
# the checker of the report's text-match for assignments: what it would and would not count
name = '_5_co_bi_co_competencing'
for line in (name + ' = {}', name + ' += x', name + '[(s, n)] = r', name + '[k] = r', name + '[k]=r',
             name + '.update(x)', 'del ' + name + '[k]', 'a, ' + name + ' = 1, 2'):
    hit = line.strip().startswith(name) and '=' in line.split('#')[0].split(name, 1)[1][:4]
    print('   the script\'s text match on %-48r -> %s' % (line, 'counted' if hit else 'NOT counted'))
