**(1)**
- A: HOLDS. 0 differences in 135,422 runs: two selves; rings 1–9, 11, 13, 17; torus 3×5; 2,000 random societies × 66 orders (random, lowest index, fewest done, most done), 30 steps. Also all 1.26 million admissible orders of every 1–2-self society and of 1,500 3-self societies.
- B1: HOLDS. Periods 4 and 3, sequences as stated, 48 steps.
- B2: HOLDS. Same as `_17` in 0 of 900 drawings (two alike; ring of 3), 2–8 of 300 (two opposite), 84 of 889 random societies.
- B3: HOLDS. Syntax tree: the name is only read; a read-only mapping works (500 societies); 0 arrives as `[('k', 0)]`; `_1` ignores offered zeros (20,000 calls).
- B4: HOLDS. Exact outputs as stated.
- B5: HOLDS. 41 steps; alike rings of 2–6; pair; alternating rings of 3, 4, 5.
- B6: HOLDS. 64 steps, X + and X −.
- B7: HOLDS. 0 mismatches at all twelve n over 12n+24 steps; least periods 4n and 2.

**(2) C**
- `co_sequencing`: output identical to returned file. Genuine comparison with `_17`; orders vary (257 distinct of 300; 298 of 300). Concerns: a spiral of 1 and the 52 one-self random societies have one possible order; `first_parting` zips, so a table cut short would read "the same" (none was).
- `society_from_outside`: identical. Genuine. "4 of 300" depends on the seed: 5–18 (mean 11) at 40 other seeds.
- `further_tallies`: identical. "0 assigning lines" is a text match on line starts, blind to a normally spaced item assignment or `.update`. The ring rule is `_1`'s own rule rewritten, so agreement is guaranteed.

**(3) D**
1. "Each self entering at a beat of its own, in step with no other, parts too: two selves alike, at beats in the golden ratio, release − 0 + − 0 + 0 − + 0 − 0 + and − + − + − + − + 0 − + − +." The second sequence's 9th–13th values come after `own_beat` stopped the first self; with both keeping their beats it alternates − + throughout.
2. "That number is the same after each entering, at each order of entering, and it is at neither self's carrying." No script counts it; counted, it is 1 after the first entering and 2 after each later one (300 orders).
3. "Three sayings are enough, each at the code already: each self's first momentary is its own, none offered; each later momentary of a self is at one releasing arrived from each of its givers; and a changing that is not is released and arrives as a changing does." Also needed: oldest releasing first (newest first differs in 100 of 100 orders), and an empty releasing (self carrying none) counting as arrived, which `_17` leaves no trace of (else 116 of 400 societies stick or differ).
4. "A society whose members part arrives as the between at each momentary, and the further self releases as a self with none offered." Run only for a pair and alternating spirals of 3, 4, 5. True for all 1,004 unlike rings to n=9; false elsewhere (pair + −, first joined to itself at 9 and to the second at 6, arrives as single parities after the second momentary).
5. "The spirals of Exhibit ONE's tables, alternating along, arrive outside as the between." Not the Exhibit's spiral of 1: one parity at each second momentary (2–11, 17, 59 do).
6. "One self carrying + | . − + − + − + − +" Under "Members, coupled along", true only for a self joined to nothing.
7. "Spirals of 1, 2, 3, 4, 5, 7, 9, 11 and 17 | 40 each | the same", and "10 each" in the random row: one order repeated (see C).
8. "The tables need no stepping of the selves together." Only 15 Exhibit arrangements were run (24 more agree); its three selves in a line starts with an offering, against the first saying.

**(4)**
- Section 7's worded rule misses the first change, which no giver change precedes.
- Not checked: outside citations, quotations from other files, the counts 81, 82, 19.
- No file was changed. My scripts: `/tmp/claude-0/-home-claude/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/verify/`.
