# A fresh reading of lines at their publishings

You are a fresh reader. Another working wrote the lines below; you have not seen them being written, and you are not asked to agree with them. Each line says what a publishing has (a paper, a textbook page, a rule, a lecture). Your one job: open each publishing and read the line again there, then report exactly what the publishing has.

## How to read

- Open each address given in the item with the web fetching tool. Ask it for exact quoted words and for the place they are at (section, table, page), not for a summary.
- If an address cannot be opened, try an open copy of the same publishing: its PubMed page, a PubMed Central copy, its arXiv page (also `arxiv.org/pdf/<number>` or `arxiv.org/html/<number>` for the full text), the publisher's abstract page, or a web search for its title. Say which address you actually read.
- Report only what you read at a publishing in this task. Do not fill anything in from memory. If a figure, a name or a statement in the line is not at the page you could open, write "not found at the page read".
- Keep each quotation short, under 25 words.
- Whole names: no abbreviations for journals, organisations or methods the first time they appear.
- No opinion, no recommendation, no caution. Plain words.

## What to report, for each item

Use exactly this form:

```
### ITEM <number>
- Publishing reached: yes or no — the address actually read (and any other tried)
- Kind of publishing: the observing's own report / a review or textbook reporting observings (name the original observing if the page names it) / a rule or record / a proof or derivation / a lecture or commentary
- Each part of the line, read at the publishing:
  - "<part of the line>" — at the publishing / not found at the page read / the publishing has it otherwise — "<short quotation>" (place)
- Seen, as the publishing gives it: what was seen or measured, by what doing (instrument, method), at what conditions (which organism or sample, how many, what range), with any figures and their uncertainty exactly as given
- The field's explaining, as the publishing gives it: the interpretation, model or naming the publishing lays over what was seen (or "none given")
- Anything the line has that the publishing does not have, or has otherwise
```

For a publishing that is a rule, a record, a proof or a citation, "Seen" is what the text itself states (the rule's words, the theorem's exact conditions, the author and year printed on the page).

## Where to write

Write your whole report to the file named in your task, then reply with a summary of at most 12 lines: for each item, one line saying whether every part of the line was at its publishing, and which part was not.
