Session v386EOD · working papers

These are the papers session v386EOD worked from, kept so a later session can lay any change beside what its readers said. They hold no incoming value of their own beyond what For_The_Next_Session_v386EOD.md names.

- first_part_of_the_session/: the first report, The Next Coupling, with its scripts (out/), and the first readers' reports of the living files and their checks at the publishings.
- gathering/: the readers' reports for each source gathered into carry/ (reports*, recon, check*), their briefs, and the scripts that placed the sections.
- older_droplets/: for each older Droplets section, the paragraphs as they were in portions (*.txt), the first reader's verdict for each (*_report.md), the second reader's check (*_harm.md), the briefs, and the scripts that applied them.
- close/: the two readings of the session's transcript (T1_report.md, T2_report.md), the independent audit (A1 to A7), the third reading of each older paragraph said again or released (B01 to B11, R01, R02), and the list of what was put back (restore.json, restored_log.json).
