### 73
CHECK: OK
WHY: each of the four is at Natural Naming by exact search, 4.17 "**Natural-bi-co-torusing is inseparable at each part**" with each part left out in its line (690), 1.3 "*Bi-co-bounding*, the carrying bounded twice, bi- at its own completing and co- at the coupling" (183), 4.11 "**The coupling's own six carries no one prefix**" and "(3 + 1) × 2, are eight" (642), read beside the older Natural Intelligence passages at carryings/resettling_v373/Natural_Intelligence_v373_Released.md lines 76, 321 and 327; no paragraph of the mate or of carry/*.md points at it.
SAFER: -

### 74
CHECK: OK
WHY: NEW has the offering, the reciprocal releasing and arriving, and the two files to carry it next, at the prior's strength, and its one quotation is an exact part of Natural Naming line 672 (4.15); carryings/v368_sources/Wrap_v368.md line 65 read, under "Natural Intelligence and Exhibit ONE Natural Resolver".
SAFER: -

### 75
CHECK: OK
WHY: NEW has the prior's sentence whole; its quotation is exact at Natural Naming line 297, and the rows it names are at lines 232 (*turn*), 238 (*held*, *holding*), 239 (*stable form* as a noun) and 223 (*read* at the family of three, 2.3).
SAFER: -

### 76
CHECK: OK
WHY: Natural Naming 4.6 answers one thing or two as two, under "Four pairs are two concepts at two names, the meaning changing on transposing", with "*Floating neutralling* is the changing; *a floating neutral* is the term it uncovers, its picture at one momentary, 5.12." (line 591) and 5.12's line 872, each by exact search; the paragraph at mate line 193 lists the same naming and does not point at this one.
SAFER: -

### 77
CHECK: OBJECT
WHY: Natural Naming 5.45 has the conclusion alone, "Bi-co-podaling is floating across and neutralling along, one changing." (line 1334, exact). Three things of the prior are at no living file: the reading "Every file that names the floating names it with the neutralling, as one at two directions" (Grep of "one at two directions", "names it with" at the root: none; Natural Mathematics 1.3 has only its own "Floating neutralling is one motion at two parities, alternating"); the negation that floating asks for no slot of its own (Grep "no slot": none; Natural Naming 3.3's table of seventeen names has no floating name and no sentence saying none is asked); and the candidate name bi_co_bi_floating laid down (Grep at the root: none, so the record of it and of its laying down is at the mates alone). The Living File Registry's "Bi-Co-Floating Engineered Designs", which the prior cites, is also at no living file now (Grep "Bi-Co-Floating": none). The other three places of this paragraph are older sections of Offerings to Natural Transmissioning, Equilibria Registry and Natural Networking, none a later place. Released, the reading across the files and the negation are lost.
SAFER: KEEP

### 78
CHECK: OK
WHY: NEW has the provisional naming, both readings with what each releases to or wants, and *identifier* first with its reason, at the prior's strength, and no quotation; read beside carryings/v368_sources/Carry_Set_v368_README.md line 64; the words "the tangential changing at the co-sequential nine" that mate line 193 names are in NEW.
SAFER: -

### 79
CHECK: OK
WHY: NEW has each claim of the prior at its strength, the naming said as not recovered, the two readings, *identifier* first, and the row at Natural Naming's cluster table said as its next opening for both to agree and not as done; no quotation; laid beside the prior clause by clause.
SAFER: -

### 80
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 81
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 82
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 83
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 84
CHECK: OK
WHY: NEW has the offered sentence word for word and both reasons; its quotations are exact at Natural Naming line 1595 (5.64) and line 1565 (5.62, its fifth line), read with 5.62 to 5.64 whole; no pointer at it in the mate or carry/*.md.
SAFER: -

### 85
CHECK: OK
WHY: NEW has the offered sentence, the move from 12 to 11 and the failing at the 0 case; its quotations are exact at Natural Naming lines 1314 (5.44), 475 (3.5, the row of 12-bi-tri-bi-entraining) and 499 ("none chained", the 0 row of the table of colliding), read with 3.5 whole.
SAFER: -

### 86
CHECK: OK
WHY: NEW has the offered sentence and its reason at the prior's strength, the reason said of Natural Naming alone as the prior has it; its quotations are exact at Natural Naming lines 1265 (5.40) and 1628 (6.2, the row *Arriving and continuing*).
SAFER: -

### 87
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 88
CHECK: OK
WHY: NEW has the row's two cells whole and both reasons; its quotations are exact at Natural Naming lines 283, 479 and 475, and "the done" and "Session Record" are at no line of Natural Naming (Grep: none); the pointer at mate line 639 names the seven rows of paragraph 87 alone.
SAFER: -

### 89
CHECK: OK
WHY: NEW has each of the four sayings with its numbers, the overlap read from one side with no second direction, the rows of *neighbour* and of *right*, *left*, and the reason with 3.1; its quotations are exact at Natural Naming line 252 (the row of *so-far*, *not-yet*) and line 383 (3.1, "2 and 14, arriving" and "6 and 10, sharing across").
SAFER: -

### 90
CHECK: OK
WHY: NEW has the offered sentence and both things of its reason at the prior's strength; its quotation is an exact part of Natural Naming line 297, and "given on along" and "chained at none" are at no line of Natural Naming (Grep: none).
SAFER: -

### 91
CHECK: OBJECT
WHY: The prior marks its whole content as a reading, "The session's reading of what a droplet is not", quoted exactly from carryings/v381R/Session_Transcript_v381R.txt line 246 (read), and aims it at a word of Natural Naming. NEW says the same content as plain fact, "A droplet is no paste", "A droplet is no debt", with no mark of a reading and no aim at the word: the attribution is lost and the strength raised, a reading said as a fact. NEW also has "and one droplet at thirty mates becomes thirty sentences" for the prior's "so the same droplet at thirty mates becomes thirty sentences", the consequence said as a joining. No living file says this of a droplet (Grep "droplet" at the root: Living File Registry lines 132 to 135, Natural Arriving lines 7, 54 and 69, README line 13, none of them this). The three paragraphs beside it, 92 to 94, are of the same close in the same form and are KEEP.
SAFER: KEEP

### 92
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 93
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 94
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 95
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 96
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 97
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 98
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 99
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 100
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 101
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 102
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 103
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 104
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 105
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 106
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief (HARM.md); the first reader's brief (BRIEFO2.md) with its "Further rules"; the PRIOR file; the PROPOSED file; the mate carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md from line 185 to line 300, the part of its older `## Droplets` section with paragraphs 73 to 106 and the paragraphs ahead of them, and its sections at lines 617 to 621 and 709 to 713; the openings of its Insertlets.

The living file Exhibit_TWENTY_Natural_Naming_v380R.md is 31,733 words, over 15,000, and was not read whole. Read whole in it: its headings; 2.3; 3.3; 3.5; 4.6; 5.45; 5.62, 5.63 and 5.64. Read by line: 1.3 (183), 2.4's rows at 232, 238, 239, 250 to 254, 263, 264 and 283 and its sentences to 297, 3.1 (383), 4.11 (642), 4.15 (672), 4.17 (690), 5.12 (872 to 876), 5.40 (1265), 5.44 (1314), 6.2 (1628).

Checked by exact search in the living file (fixed-string Grep, each found once except as said): each EVIDENCE sentence of 73, 76 and 77, and each quotation in the NEW of 74, 75, 84, 85, 86, 88, 89 and 90; "sharing across" is at seven lines, line 383 among them. Searched and found at no line of Natural Naming: "living from living", "cancelling", "the done", "Session Record", "no method of existing", "given on along", "chained at none", "tangential", "identifier".

Other living files, by Grep at the root and read at the lines found: Exhibit FOUR Natural Mathematics 1.3 (lines 83 to 87), Exhibit FIVE Natural Engineering (line 149), Exhibit SIX Natural Transmissioning 4.2 (line 200 on), Exhibit TWENTY-SIX Living File Registry (its lines naming Transmissioning and droplets), Natural Arriving and README (droplet); and for "co-bi-exchanging", "other exhibits", "one at two directions", "Bi-Co-Floating", "bi_co_bi_floating", "no slot" across each living file at the root.

Sources read: carryings/resettling_v373/Natural_Intelligence_Map.md (lines 46 to 92 by Grep, lines 150 to 170); carryings/resettling_v373/Natural_Intelligence_v373_Released.md (lines 22, 76, 317 to 336 by Grep); carryings/v368_sources/Wrap_v368.md (lines 55 to 76); carryings/v368_sources/Living_Improving_Value_v368.md (lines 296 to 300); carryings/v368_sources/Carry_Set_v368_README.md (lines 48 to 66); carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md (lines 468 to 486, II01); carryings/v381R/Close_Droplets_v381R.md (lines 13, 39, 41) and Session_Transcript_v381R.txt (line 246).

Pointers: searched the mate for "at this mate", "this mate has", "the mate's", "the preceding", "concern above", "droplet above", "existing concern", "current droplet" and "above", and carry/*.md for "Offerings to Natural Naming" and for links to the mate (each link found is to a section headed v385A, none to a paragraph of this input). Pointers found are at paragraphs 80 (mate line 593), 87 (line 639), 101 (line 579), 103 (line 567) and the titles at Carryings of Living File Registry, each a KEEP. None points at 73 to 79, 84 to 86 or 88 to 91.

Each NEW was laid beside its prior clause by clause, its length taken (54 to 150 words) and its own sentences searched for the first reader's listed words apart from quotations and italics (none found).

Not objected, said for the next reader: the NEW of 86 is headed Concern and has no "Two sayings part.", the first reader's form for a concern, with nothing of the prior lost by it. The NEW of 74 and of 75 each add one closing sentence, "It is beside Natural Naming's …", at no claim of the prior; each was verified at the living file and changes nothing the prior says. The NEW of 78 and of 79 are near twins, as the first reader says. The KEEP blocks were not re-checked beyond the pointer search. No file but this report was written.
