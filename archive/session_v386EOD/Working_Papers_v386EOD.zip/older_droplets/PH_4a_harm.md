### 37
CHECK: OK
WHY: Exhibit_EIGHTEEN_Natural_Physics_v379.md line 82, within 1.1 (66 to 91), still has "is bi-co-momentarying, at no line of the code, Natural Intelligence 6.1", and "at no line of the resolver" is an exact string at Natural Mathematics line 179, Natural Numbers line 349 and Natural Intelligence line 220, with Natural Naming line 270 "code executing is said *at the resolver*"; each claim of the prior, the three twins, Natural Naming's carrying and the ready saying, is in NEW.
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: OK
WHY: The four quotations are exact at Natural Physics line 205 within 3.1, Natural Numbers line 349 within 7.1 and Natural Chemistry line 313 within 4.4; the closing sentence has the one saying as the three files' own to make at their motions, none made, and is word for word the paragraph at carry/Exhibit_THREE_Offerings_to_Natural_Numbers.md line 43; the source, archive/session_v379/Session_Report_v379.md line 20, has no more than the prior.
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 42
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 43
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 46
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 47
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 48
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 49
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 50
CHECK: OK
WHY: Laid beside the prior and its earlier copy at archive/carrying_v381R/Exhibit_EIGHTEEN_Natural_Physics_v380R.md line 120: each of the seven findings and each number (five, forty-nine, fifteen of sixteen, fifty-one, thirty of forty) is in NEW at the same strength, the branch is named, and the entering is said at its working's motion with section 2 of the review first, the condition carried; carryings/review_natural_physics_v377/README.md lines 15 to 21 and 85 have the same.
SAFER: -

### 51
CHECK: OK
WHY: Both quotations are exact, Natural_Intelligence_v380R.md line 99 within 1.4 (five things named) and Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 192 within 2.7; they are the two sentences the prior is about, and the proposed text's 2.1 (its line 129) has "is at one of six binaries, the rigorizer, Geodesic Improving Method 2.7"; the one list at both files, at the observings, is carried.
SAFER: -

### 52
CHECK: OK
WHY: The proposed text's 3.4 (carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md line 240) has "the white paper's rings at 4.13 are these spirals", and the review's line 75 has "the file asserting it at 3.4; each file's motion"; the asserting, the place, open across the set and each file's motion are each in NEW.
SAFER: -

### 53
CHECK: OBJECT
WHY: One attribution is moved. The prior has "alpha and beta decay are single-nucleus events with no partner at the field's record, and a halving at each step is a common beat": the field's record is of the first clause alone. NEW opens the sentence "At the field's record alpha and beta decay are …, and a halving at each step is a common beat", and the opening phrase reads over both clauses, so the common beat is said as the field's record. It is not: the review (carryings/review_natural_physics_v377/README.md line 30) has "a halving at each step is a common beat, the thing the file releases elsewhere", a finding at the proposed text's own form (its 3.8, line 282, "goes to one member in two at each pairing"), and *a common beat* is Natural Intelligence 1.4's naming, no word of the field. The rest was laid beside the prior and holds: its 3.8, single-nucleus, no partner, the reading at its relation or released. SAFER changes that one sentence's order alone.
SAFER: **Droplet · Decay read as pairing, at the proposed Natural Physics of version 377.** The proposed Natural Physics of version 377 reads decay as pairing at its 3.8. Alpha and beta decay are single-nucleus events with no partner at the field's record, and a halving at each step is a common beat. The reading carries on at its relation or is released.

### 54
CHECK: OK
WHY: The proposed text's 4.11 (lines 503 to 514) has the three readings, "a rate not falling to rest at the edge" (line 509), "the two expansion rates read as rates local to their couplings" (line 510) and "a temperature difference as a measured exchange rate" (line 512), and the review's lines 38 to 40 and 77 name them as its 4.11's; the three readings and "each said at the field's kind or released" are in NEW as the prior has them.
SAFER: -

### 55
CHECK: OK
WHY: The proposed text has the persistent current at its 3.5 (line 256) and its 4.10 (line 498), and the review's line 78 has the prior's words; steady charge transport at the field's record and the cyclic pattern with no transport are both in NEW, *keep* said as *carry*, and the second clause follows from the first at the field's record itself, so the opening phrase moves nothing.
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: OK
WHY: The four strings of Exhibit_TWENTY_Natural_Naming_v380R.md are exact at lines 617 and 621 within 4.9 (603 to 627) and the two of Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md at line 35 in its front; the first of each pair there is the odd and the second the even (the proposed text's line 673 says so), so the two-way and the rate are each at the other parity at the other file, which is the prior's "different faces" and carryings/natural_physics_v377/README.md line 111, "at opposite faces".
SAFER: -

### 58
CHECK: OK
WHY: The proposed text's 3.4 (line 246) has "The beat and the locking range at close paces are to be executed at each spiral pacing its own"; 17 is 17-co-bi-tri-offering at Exhibit_ONE_Natural_Resolver_v380R.md lines 68 and 124, and Natural_Intelligence_v380R.md line 222 within 3.5 has "the resolver steps each self's entry at 17-co-bi-tri-offering together, a common beat laid over the selves"; the promise, the pacing not carried, and said so or released are each in NEW.
SAFER: -

### 59
CHECK: OBJECT
WHY: The title says as done a thing the paragraph has as ready. The prior's title is "Ready: *face* dissolves."; NEW's is "*Face* dissolved, at Natural Physics' own sentences", which read alone has the word dissolved at Natural Physics' sentences. It is not: Exhibit_EIGHTEEN_Natural_Physics_v379.md still has *face* at its sentences and at three section titles (3.1 "An atom at two faces", 4.4 and 4.9), and the body of NEW itself has each sentence ready for its re-saying. A thing intended said as done, and a title saying more than the paragraph (the first reader's rules 4 and 11). The body was laid beside the prior and holds: Natural Naming's row is at its line 313 within 2.4, "| *face*, *faces* | the name; *its side*; *its form*, of an emanation; *is facing*, of a direction; …", facing a direction carrying on, each sentence ready at the file's motion (Exhibit TWENTY-SIX Living File Registry line 154 has Ready as "waiting for the file's own motion"). SAFER changes the title alone, to the prior's own words.
SAFER: **Droplet · *Face* dissolves.** Exhibit TWENTY Natural Naming carries *face* among the released words, each re-saying beside it; facing is a direction and carries on. Exhibit EIGHTEEN Natural Physics says *face* at its own sentences. Each of those sentences is ready for its re-saying, Natural Physics' own to make at its motion.

### 60
CHECK: OK
WHY: Laid beside the prior and carryings/review_natural_physics_v377/README.md line 15: the two code blocks and their versions, `outputs.txt`, sixteen and fifteen, the thirteen places 3.2 to 4.7 in the same order, the seven numbers of the register from its fifty rows, and the report's section 6.2 are each in NEW; the review and its section 1 are named.
SAFER: -

### 61
CHECK: OK
WHY: Laid beside the prior and carryings/review_natural_physics_v377/README.md line 17: forty-nine entries, no `&nbsp;`, the ten words each with its two numbers (28 to 0, 13 to 0, 117 to 0, 49 to 0, 57 to 0, 67 to 1, 59 to 1, 44 to 0, 21 to 0, 18 to 0), *keeping* 1 to 10 as the name of a binary, and Natural Intelligence 1.4 with the Geodesic Improving Method 2.7 are each in NEW.
SAFER: -

## READING
Read whole: HARM3.md; BRIEFO3.md with its further rules; PH_4a.txt; PH_4a_report.md; carryings/review_natural_physics_v377/README.md, the source of paragraphs 50 to 61. The living Exhibit_EIGHTEEN_Natural_Physics_v379.md is over 15,000 words (21,830) and was not read whole: read at its headings, line 82 within 1.1, line 205 within 3.1 and its register at 5.11, and searched for *at no line of the code*, *sixty* and *60*, *two-way*, *a rate held*, *persistent current* and *face*. The mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md was read at its lines 1 to 170 (the front, the insertlets and the older droplets through this portion) and at its later sections headed v385A and v386EOD, lines 574 to 712, in shortened lines.

Read at the places named and searched: Natural_Intelligence_v380R.md 1.4 (line 99) and 3.5 (lines 220 and 222); Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md 2.7 whole (lines 186 to 194); Exhibit_TWENTY_Natural_Naming_v380R.md 4.9 whole (lines 603 to 627), line 270 and line 313 within 2.4; Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md lines 25 to 40; Exhibit_THREE_Natural_Numbers_v380L.md line 349 within 7.1; Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 313 within 4.4; Exhibit_FOUR_Natural_Mathematics_v380L.md line 179; Exhibit_ONE_Natural_Resolver_v380R.md for the name of 17; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md line 154 for the kinds Ready and Concern. The proposed text carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md at its headings, its 2.1, 3.4, 3.5, 3.8, 4.10, 4.11 and 5.11 and line 673; carryings/natural_physics_v377/README.md at its 6.1 (line 111); archive/carrying_v381R/Exhibit_EIGHTEEN_Natural_Physics_v380R.md lines 100 to 140, the earlier copy of paragraphs 37 to 58 under its headings Ready and Concern; archive/session_v379/Session_Report_v379.md line 20; carryings/v380L/Progress.md searched (the prior's `incoming/v380L/Progress.md` is at that path now).

By exact search: each quotation of each NEW paragraph (37, 39, 51 and 57 have quotations; the others have none) is an exact string of the living file it names, at the section it names. Each NEW was read for the first reader's unused words outside quotations and cited words, none found, and numbered: 41 to 146 words each.

For pointers, carry/*.md was searched for the opening words of each re-said paragraph and for "the concern at this mate", "the droplet at this mate", "the concern above", "the preceding", "existing concern" and "the current droplet is at"; none points at a paragraph of this portion that is re-said. Every verdict here that is not KEEP is RESAY, so no release was to be checked. The twelve KEEP blocks (38, 40 to 49, 56) were not checked further, a paragraph left as it is costing nothing.

Said plainly: "for both" at paragraph 39 is left out of NEW and is the kind of a Concern, which the form "Concern · … Two sayings part" carries (Living File Registry line 154, "**Concern**, two sayings parting at one place with the reason, waiting for both"). The source names and version tags of 37, 39 and 59 are left out and were read as the session's labels. Paragraphs 51 to 58 were Concerns under their own heading at the earlier copy; the prior as it is now has no such heading, and the NEW paragraphs of 52 to 55 and 58 as Droplets lose nothing the prior has. No file in /home/claude/corus was edited; this report is the one file written.
