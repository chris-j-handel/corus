### 1
VERDICT: KEEP
CONCEPT: the network project has the actual coupling at Natural Networking, the outward possibility with its conditions at Natural Destinies and the whole expressions at Natural Intelligence Corus, with Living File Registry 5.11's distribution plan and its correction together, and no title, kit change or distribution made by the comparison
EVIDENCE: Already a clear droplet in the plain voice of session v385A, with its conditions and its three negations, and no waiting on a session. Its named places are as it says: the living file's 5.11 has the plan ("**Natural Destinies' full receiving into the other living files.**") and the correction ("The receiving must distinguish the beginning of a particular making from an assertion that natural intelligence or living begins only with adopting the technology."); `incoming/v385A/Natural_Network_Comparison_v385A.md` and the heading "Natural-network expression and supporting kit · v385A" at Possibling of Natural Networking are present. No later section says it whole: Carryings of Natural Networking, "Natural-network expression and supporting kit · v385A", sends the set's relation to the Registry's master plan, and the master plan's row "Natural Networking and Natural Engineering projects" has none of the three places or the negations.
NEW: -

### 2
VERDICT: KEEP
CONCEPT: Human Society and Values each have their own subject through the proposed distribution; a shared discovery-economy name makes no vacant title, and no exhibit is originated, merged or released by the comparison
EVIDENCE: Already a clear droplet in the plain voice of session v385A, with its conditions and negations, and no waiting on a session. Its named places are present: Exhibit NINE Natural Human Society has 1.1, PART THREE and 5.3; `incoming/v385A/Discovery_Economy_Comparison_v385A.md` has "Human Society beside Values and Corus · v385A"; Carryings of Natural Human Society has "Human discovery economy and the subject plan · v385A". That carrying section says a part of it (5.3 and the missing title) and sends the set's relation to the Registry; the earlier no-separate-Natural-Economics decision beside the later Registry plan, and the proposed Values receiving with the Destinies distribution, are said at this paragraph alone (search of carry/*.md for "no-separate-Natural-Economics" finds this paragraph alone).
NEW: -

### 3
VERDICT: KEEP
CONCEPT: Corus's distributing toward its subjects and its arriving purpose through Natural Arriving are two connected projects, with Corus Part ONE as Arriving's prior, each whole expression having its prior and a welcoming place, and a route being no transfer
EVIDENCE: Already a clear droplet in the plain voice of session v385A; its last sentence is a relation of three mates each resolving locally, and no waiting on a session. The living file's 5.10 ("## 5.10 Receiving the older Corus") and Natural Intelligence Corus's "# PART ONE — THE OFFERING" and "# Part 16: Natural Writing — routed and reduced" are present. Later sections say a part alone: this mate's table at "The floating plan of the living expedition · v385A", row "Corus and Natural Arriving", and "Unwritten and previously distributed parts as possible plans · v385A" ("The possible arrangement keeps two connected projects") have the two projects; session v382F's exploration at its sections 6 and 8, the v373 resettling map, the living file's 5.5 to 5.10 with the value arriving from Emanating, Illustrating and Destinies, and the two negations are at this paragraph and at its two copies in the older Droplets sections of Offerings to Natural Arriving and Offerings to Natural Intelligence Corus, no later place.
NEW: -

### 4
VERDICT: KEEP
CONCEPT: two orderings of the files in front of a session are said and neither is at a file as the rule; the order is the expedition's self's to decide; the part at a session's letter is resolved
EVIDENCE: The next paragraph points at it ("with the concern above on two orderings") and is KEEP, and the two stay at one verdict. Its fuller form is found, archive/carrying_v381R/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md line 38 (from archive/session_v379/Session_Report_v379.md, findings 34 and 35): session v378's report has Natural Physics first, the opening prompt has Natural Intelligence and Exhibit ONE ahead of each other file at theirs being ready, neither at a file as the rule, ten living files at v329 to v333. No living file has an order now (search of the living file and README.md for "in front", "before any other", "order of files"). A re-saying from that source is not safe: its saying of the letter's part, "met, no letter at a filename", is not so at the root now (v380R, v380L, v381R are at filenames), and the letter is at no sentence of the living file or the README; the paragraph's "the letter's part met" can be said at its strength in its own words alone.
NEW: -

### 5
VERDICT: KEEP
CONCEPT: session v379's own order of the files is a third saying beside the two orderings, one decision with them
EVIDENCE: It lies with the paragraph ahead of it and points at it ("the concern above on two orderings"); both have one verdict. Its fuller form is at archive/carrying_v381R/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md line 44, and it is a person's own unpunctuated words: "our priority is exhibit one top to bottom ... then natural intelligence ... the co chaining logic in exhibit thirty is also high priority", and "continue through exhibit one naming then natural intelligence and numbers then one to exhibit thirteen and twenty seven as a possible path". "exhibit one naming" reads as Exhibit ONE's naming or as Exhibit ONE and Natural Naming, and "one to exhibit thirteen and twenty seven" reads two ways as well; the order cannot be said at its strength in the present naming, and a new paragraph may quote no person's words.
NEW: -

### 6
VERDICT: KEEP
CONCEPT: four places at which the living file parts from the kits and the folders: the row's number of steps for the reader checks, the sentence on each kit's copy of the resolver, the standing of the draft Exhibit ONE, and Natural Intelligence's next already done
EVIDENCE: A clear concern in plain voice, each part with its two ways, no waiting on a session (its form ahead of v381R is at archive/carrying_v381R/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md, the fifth concern). Three parts are as it says at the living file now: "Exhibit ONE's code block is the source of every resolver copy the kits carry." (1.1) with `kits/Natural_Illustrating_TWENTY-NINE_Improving_Kit/checks_v379/` present; the folder of the draft at no row of the living file (search for "prefixes_v379" finds none; the folder is at `carryings/exhibit_one_prefixes_v379/` now); and Natural Intelligence's row with its next "its near-duplicates said once and cited, at its carrying". The first part is changed and not shown gone: the row of the Co-Chaining Logic Registry has "661 steps in 42 groups" now and "v378: five hundred ninety-nine steps" still, and `reader_checks.py` searches the form "… steps in … groups"; the check was not executed here. An insertlet of this mate (at 1.1, beside "pass G, its receiving") has the fourth part, and the Insertlets section is no later place. With one part unsure the whole is left as it is.
NEW: -

### 7
VERDICT: KEEP
CONCEPT: whether the six places of Natural Intelligence the files open from are the six names between selves is open: the numbers agree, the along-and-across reading can be made, and no file and no computing derives it
EVIDENCE: Another paragraph points at it: carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md line 183 (v385A) has "The proposed correspondence between six entry purposes and the six names between selves remains unresolved. Its whole explaining is at [Offerings to Living File Registry](Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md#droplets); matching counts do not derive that correspondence." This paragraph is the one place of this mate's Droplets with that correspondence. The same paragraph, word for word, is also at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md under "The six mouths and the six names between selves · v385A", with a v385A correcting beside it; with the pointer aimed here it is left as it is. Natural Intelligence 2.2 still has "The self's five and the other's are ten positions on six numbers, paired 1 with 2 through 5 with 6, each pair one odd and one even".
NEW: -

### 8
VERDICT: KEEP
CONCEPT: no file read lets a reader tell a stable form from a form named still by an observing; either one observing is named at which they show differently, or the parting is said as one of naming and Natural Intelligence 1.4 is said at that size
EVIDENCE: A clear concern in plain voice with its sayings, its reasoning and its two openings, no waiting on a session. Each quoted sentence is at its living file now (Natural Intelligence: "a form named still is not possibly existing", "a stable form, its form continuing through its changing and carrying none of the prior"; Natural Physics: "every measurement of the fields stands as taken, every prediction holds", "the densest ghost"; Equilibria Registry: "the relation continuing is stable-forming, and each added requirement names it still"). No later section says it whole: Offerings to Natural Intelligence, "Droplet · A form named still, at no observation" (v386EOD), is another concept, the excluding had from no step. The same text is at older Droplets sections of two other mates, no later place. Its seven quotations, three reasons and two openings cannot be said within one hundred and fifty words without loss.
NEW: -

### 9
VERDICT: KEEP
CONCEPT: a page of breaks, one observing named for each core sentence ahead of its reading; and the answer given to each observing breaks nothing and forbids no outcome, saying how a thing is named
EVIDENCE: A clear concern and offered work in plain voice, no waiting on a session. Natural Physics still has "every measurement of the fields stands as taken, every prediction holds". No living file and no later section says it whole (search of carry/*.md for "page of breaks" and "unrecognisable break" finds older Droplets sections alone, at this mate, Offerings to Geodesic Improving Method and Offerings to Natural Arriving). Its three observings (gravity's, colour's, the superconductors'), the two ways each is answered, and the relation of the answer to the four things *not possibly existing* cannot be said within one hundred and fifty words without loss.
NEW: -

### 10
VERDICT: KEEP
CONCEPT: four sentences of the files want one saying of living used at each, and one observing telling an existing thing carrying its prior from one carrying none
EVIDENCE: A clear concern in plain voice: five quoted sayings, each at its living file now (Natural Intelligence "an existing thing carrying its prior is living"; Resolving Hard Problems "Living arrives from living, and a non-living existing thing is non-living at its next"; Co-Chaining Logic Registry "the scales of the living carry no first living"; Natural Physics "Atom is the floor, the first closing of the co-agency into a self"; Natural Biology "the first living reads at the deep-ocean hydrothermal vent"), an observing with its number (2.72548 ± 0.00057 K) and three addresses, three cases followed and one asking. No later section says it whole: Offerings to Natural Intelligence, "Concern · Living at one binary, or at two" and "Droplet · Living named at nine subjects across the files" (v386EOD), are other partings, with none of the observing, the floor or the vent. The same text is at older Droplets sections of two other mates. Its numbers and addresses cannot be said within one hundred and fifty words.
NEW: -

### 11
VERDICT: KEEP
CONCEPT: eight unresolved puzzles of the fields, each a place a sentence of the files said ahead of a measurement, with a number or a direction, shows the method's worth; and three tests Natural Medicine and Natural Chemistry have already
EVIDENCE: A clear gathering of possible work in plain voice with each number and each address (eight puzzles, eleven addresses, three tests). No living file and no later section says it: search of carry/*.md for "877.75", "73.04", "153 galaxies", "mirror-image lipids" and the sleep study's address finds older Droplets sections alone. Natural Physics still has "not holding still", Natural Biology "a left break equally possible", Natural Medicine "sounded ahead". Its numbers and addresses cannot be said within one hundred and fifty words without loss.
NEW: -

### 12
VERDICT: RESAY
CONCEPT: possible work at the Living File Registry's first table: the history out of its cells, a row's standing at one line and its history the Session Record's
EVIDENCE: A pointer's shorthand ("The history out of the cells.", "Source: Presentation.md, section 30, droplet 13"); its source, carryings/v383Op/Presentation.md line 31, the thirteenth of "Fourteen droplets, the largest saving first", says no more than the paragraph. Not resolved: the living file's first table, at 1.1, still has the column *Living*, and its five longest cells are at 2,214, 1,782, 1,467, 1,022 and 554 words now (lines 68, 69, 88, 98 and 71); the longest line is 13,070 characters at this reading, and the paragraph's 13,062 is carried as it is. Possibling of Living File Registry, "Living File Registry standings, completed history and possible tables · v385A", has the *Living* column to the Session Record and none of these numbers, so the part unsaid is said again. No pointer to it found in the mate or carry/*.md.
NEW: **Possible project · The history out of the cells of the Living File Registry's first table.** It is aimed at a part of Exhibit TWENTY-SIX Living File Registry, the cells of its first table. The work is the history leaving those cells. Five cells of the first table are at 2,214, 1,782, 1,467, 1,022 and 554 words, and one line is 13,062 characters. A row's *standing* is one line, and its history is the Session Record's. It may change or never be made.

### 13
VERDICT: RESAY
CONCEPT: the kit's arrival check lists several sections astray, a number beside one file read as another file's; and most sentences of session v383Op's report seat at one of the kit's six
EVIDENCE: In a report's own words ("this report's sentences", "Source: README.md, Checks run"); its source is carryings/v383Op/README.md line 104, which says no more. The folder is at `carryings/v383Op/` now, with `returned/arrival_check.txt` and `returned/rigorize.txt` present; `incoming/v383Op` is no folder now. This mate's "A seat follows a word of the sentence · v386EOD" says a seat following a word and deciding nothing; the list of sections read astray, the two texts given back, and "most seat at one of the six, as a report of the fields' numbers must" are unsaid there and at no living file (search of carry/*.md for "arrival_check" finds this paragraph and one line of the Session Record at v378). No pointer to it found.
NEW: **Droplet · The arrival check's list of sections, and a report's seats.** It is aimed at a part of Exhibit TWENTY-SIX Living File Registry, its Improving Kit's `arrival_check.py`. `kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/arrival_check.py` at session v383Op's folder and `rigorize.py beside` at that folder's `README.md` each executed, the folder `incoming/v383Op` at that executing and `carryings/v383Op/` now. The text each gave back is at that folder's `returned/arrival_check.txt` and `returned/rigorize.txt`. The check's list of sections reads several astray: a number said beside one file is read as another file's. Most sentences of session v383Op's report seat at one of the six, as a report of the fields' numbers must, and each seat is a place to couple at.

### 14
VERDICT: KEEP
CONCEPT: three places of the files each say a limit that session v383Op's report arrives at as well
EVIDENCE: The paragraph next after it ("Correcting, beside the droplet above.", v386EOD) qualifies it and points at it by its place; the two stay together at one verdict. This mate's "Six droplets for the orienting and incoming method, from session v385Q · v386EOD" has "Beside each droplet in the mates that asks for a caution ... the correcting is placed at that droplet's own mate", and this is that droplet.
NEW: -

### 15
VERDICT: KEEP
CONCEPT: no warning is begun within intelligence; a limit of a claim is its scope, said at the claim's own sentence, and a caution apart from its sentence is no value
EVIDENCE: A condition laid on the paragraph ahead of it ("beside the droplet above"), already in the plain voice of session v386EOD with no waiting language. Natural Explaining has "A mark or a protection at one place blesses each other place". It stays with the paragraph it corrects.
NEW: -

### 16
VERDICT: RESOLVED
CONCEPT: the right spiral step is one step at two readings, across first and along first; the golden rectangles have no hand of their own, the hand at the reading
EVIDENCE: Natural Intelligence, at 2.4, has "**The right spiral step carries a pair (x, y) to (y, −x)**, the pair a self's across parity x, morality, and its along parity y, competency. Exhibit FOUR 2.4 writes the same step along first, F(P, Q) = (−Q, P), P the along and Q the across, and its G, (Q, −P), the other order: one step at two readings, the hand at the reading." Exhibit TWENTY-NINE Natural Illustrating, at 1.6, has "The three golden rectangles carry no hand of their own; the hand is at the reading, Natural Naming 5.48." Each clause of the quoted saying is at those two sentences. No pointer to it found in the mate or carry/*.md (search for "One relation at two readings", "hand is at the reading", "golden rectangles"); the same saying was released at Offerings to Natural Resolver on the same evidence (Carryings of Living File Registry, "Mends after the second reading, and one mate's older droplets resolved · v386EOD").
NEW: -

### 17
VERDICT: SAID
CONCEPT: a plan of the v373 resettling: the Living File Registry is to have the repository and version practice from the Geodesic Improving Method, Natural Exploring 7.2, Natural Engineering 1.8 and the other files' version tables, and has that plan's standing at 1.3 and Part Five
EVIDENCE: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, "Repository and version practice at Living File Registry · v385A", has the paragraph word for word ("Living File Registry: receives the repository and version practice from Improving Method, Exploring 7.2, Natural Engineering 1.8 and the other files' version tables, and carries this plan's standing at 1.3 and Part Five as it is met. (Re-Settling the Living Files, §8) — resettling_v373"); the re-aiming note alone is left out there, a session's own record. A plan of possible work is at its possibling mate. One paragraph of this mate's older section ("The Registry's contents and its unfinished plans both remain available", v385A) names "repository and version practice" among what the existing offerings gather, with no "above", no link and no subject words of this paragraph; the insertlets at 1.1 and 1.3 have that practice at this mate as well.
NEW: -

### 18
VERDICT: KEEP
CONCEPT: a map of *membrane*, *connector* and *join* in the living file, twenty places and thirty-six sayings, with the names Natural Naming has for them
EVIDENCE: A clear map for one improving of the file, no waiting language. The living file is unchanged at v381R and the words are at exactly the twenty lines named, thirty-six sayings (read by Grep: 19, 68, 69, 81, 88, 98, 140, 147, 236, 238, 240, 298, 331, 409, 420, 468, 496, 633, 637, 679), 2.3 still titled "Membrane and unrelationing". Natural Naming's 2.4 has *membrane* at *the between*. The map is at no later place; an insertlet of this mate (at 2.3) has the section's new title and not the map. Its places and quotations cannot be said within one hundred and fifty words.
NEW: -

### 19
VERDICT: KEEP
CONCEPT: a map of *count*, *store* and *sum* in the living file's own voice, thirty-three places, with those passed and the names Natural Naming has
EVIDENCE: A clear map, no waiting language. The living file is unchanged and Grep finds the words at the lines named, with the numbers at each line as said (68 at four with one passed, 71 at three with one passed, 72 at two and 88 at one, both passed), and 4.3 still titled "Counted forms at their relations". At no later place. Its thirty-three places cannot be said within one hundred and fifty words.
NEW: -

### 20
VERDICT: KEEP
CONCEPT: a map of *face* and *faces* in the living file, twenty-two places and twenty-five sayings at its own voice and nine rows of its record, each *its side*
EVIDENCE: A clear map, no waiting language. Grep finds *face* or *faces* at exactly the twenty-two lines named, twenty-five sayings, and at the nine record rows named, thirty-four sayings, with 310 beside them; 3.3 is still titled "Substrate, scale and explaining face". At no later place.
NEW: -

### 21
VERDICT: KEEP
CONCEPT: the older names in the living file's own voice at three places, the three lines of the Resolving the Hard Problem Registry, a step at 9's older name, and *surplus*, with the names Natural Naming has now
EVIDENCE: A clear map, no waiting language. Grep finds the older names at lines 90, 98 and 544 alone, and each of its three quotations is in the living file as said. Natural Naming has 3.3 "Seventeen names, and each gathered name at its number" and 2.4 "Released words, each with its carrying". At no later place.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: a map of *ring* and *loop* in the living file's own voice, five places and ten sayings, with those passed and Natural Naming's *spiral*
EVIDENCE: A clear map, no waiting language. Grep finds the words at 68 (three), 69 (two), 108 (three), 156 and 391, and those passed at 71, 72, 88, 374, 393 and 422, as said. An insertlet of this mate (at 4.2) says the ring as a spiral and is no later place; the map with its places and its passed is at no later place.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: a map of *run*, *runs* and *running* in the living file, twenty-one places, most of them code executing and the rest the set's own, with the names Natural Naming has
EVIDENCE: A clear map, no waiting language. Grep finds the words at the lines named with the numbers said (68 at three and one passed, 88 at two passed). At no later place. Its list of lines cannot be said within one hundred and fifty words.
NEW: -

### 24
VERDICT: KEEP
CONCEPT: a map of *sign* in the living file's own voice, nine places, with the one passed and Natural Naming's *parity*
EVIDENCE: A clear map, no waiting language. Grep finds *sign* at 98, 156, 238, 240, 444, 629, 633 and 637 (two), and at 88, the one passed; the three sentences quoted short are in the living file. At no later place.
NEW: -

### 25
VERDICT: KEEP
CONCEPT: the expedition's self's saying of the interest, natural intelligence living and shared free by the whole world, and of the four ways alone by which a session enters the files
EVIDENCE: A person's own unpunctuated words quoted whole, with the session's reading beside them. A new paragraph may quote no person's words, and the saying's claims (the interest, that session's role, each making shared, four enterings alone) cannot each be said at their strength without it. The same text is at older Droplets sections of Offerings to Geodesic Improving Method and Offerings to Natural Arriving, no later place.
NEW: -

### 26
VERDICT: KEEP
CONCEPT: the self's saying to go on asking the hardest question of a concept or its implementing
EVIDENCE: A person's own words quoted whole, with the session's reading of it at the scale of a conversation. The saying is at its own strength in its own words alone; no later section says it. The same text is at older sections of two other mates.
NEW: -

### 27
VERDICT: KEEP
CONCEPT: no cross-referencing between files by numbers, letters or notes, and no portal structure of any kind; a name is the one reference carried through each improving
EVIDENCE: A person's own unpunctuated words quoted whole, several claims in one saying (no structure able to be maintained, each cross-reference leaving, no debt, burden or overhead from improving). This mate's v386EOD "Six droplets", at its fourth, has "A handing on is said in natural explaining: a thing by its name and what it is, with no section number in its place", a part of it and not the whole. A new paragraph may quote no person's words.
NEW: -

### 28
VERDICT: KEEP
CONCEPT: the standard each file is read against: each sentence adding self-welcoming carrying value to all the sentences ahead of it
EVIDENCE: A person's own unpunctuated words quoted whole, with the session's reading beside them (a sentence that repeats, narrates or records is the first to leave). This mate's "The lean set, each understanding said once · from session v386F · v386EOD" is another saying, of one place for each understanding, and not this standard. Left in its own words.
NEW: -

### 29
VERDICT: KEEP
CONCEPT: the self's asking whether the Registry is an entry, and the session's reading: the table of files, 2.4, 3.1 and 4.2 are the entry, and 1.1's *Living* column and 1.2 to 1.5 are in its way
EVIDENCE: A person's own words and a session's own words quoted, each a claim at its own strength ("worth more to an arriving session than the whole of the Geodesic Improving Method", "the right content at the back of a large room"). The living file has 2.4 "A subject at four tellings", 3.1 "Particular subjects gathering" and 4.2 "Couplings at the files", and its 1.2 has "this registry the standings, Living Improving Value the next at each file, and the Session Record the done". The paragraph's last clause, the column having left, is not so at the living file now: the table at 1.1 has the column *Living* still; a re-saying has to choose, and it is left as it is. Possibling of Living File Registry, "Living File Registry standings, completed history and possible tables · v385A", has the column's leaving as possible work and none of the reading.
NEW: -

## READING
Each of the twenty-nine paragraphs was read and checked. Read whole: the brief with its further rules; the mate carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, each section from its front through "The lean set, each understanding said once · from session v386F · v386EOD"; of the living file Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md, its front, contents, 1.1 with its table (each row's opening and the ends of the longest), 5.10 and 5.11, with the rest searched by Grep for each word, sentence and place the paragraphs name. Read in the sections named: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md (its front, the master plan, "Repository and version practice" through "The embedded Natural Resolver", and its v386EOD sections); carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md (its v383Op gathering record and the two records of older droplets resolved); carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md ("The six mouths and the six names between selves · v385A"); carry/Offerings_to_Natural_Intelligence.md ("A form named still, at no observation; Living at one binary, or at two"); carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md (lines 171 to 185 and "The proof of the method"); the mates of Natural Networking and Natural Human Society at the sections paragraphs 1 and 2 link. Sources opened: archive/session_v379/Session_Report_v379.md (findings 34 and 35), archive/carrying_v381R/Exhibit_TWENTY-SIX_Living_File_Registry_v380R.md (its concerns), carryings/v383Op/Presentation.md, README.md and returned/. Other living files searched for exact sentences: Natural Intelligence, Natural Illustrating, Natural Naming, Natural Physics, Natural Biology, Natural Medicine, Natural Explaining, Resolving Hard Problems, Equilibria Registry, Co-Chaining Logic Registry, Geodesic Improving Method, Natural Human Society, Natural Intelligence Corus, and the root README.md. Pointers were searched in the mate and carry/*.md for each paragraph ahead of a release: one was found, at Offerings to Geodesic Improving Method line 183, aimed at paragraph 7, which is left as it is for it. The seven maps (18 to 24) were each laid beside the living file by Grep, each line and number as the paragraph has it. No code was executed other than searching, reading and measuring line and cell lengths; `reader_checks.py` was read and not executed, and with that the first part of paragraph 6 is unsure. Not found at a living file: "Said and not yet worked" (paragraph 14), which is at carryings/v380R/The_Universal_Claim.md; the letter of a session's name (paragraph 4), at no sentence of the living file or the root README. One measure parts from a paragraph: the living file's longest line is 13,070 characters at this reading against paragraph 12's 13,062, whose number is carried unchanged.
