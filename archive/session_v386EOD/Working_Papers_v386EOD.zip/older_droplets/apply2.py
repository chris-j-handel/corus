import re,sys,subprocess,json
S='/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/older/'
C='/home/claude/corus/'
exec(open(S+'apply.py').read().split("def plan")[0])
def prior(t):
    x=open(S+t+'.txt',encoding='utf-8').read(); d={}
    for m in re.finditer(r'^### (\d+)[ \t]*\n(.*?)(?=^### \d+[ \t]*$|\Z)',x,flags=re.M|re.S): d[int(m.group(1))]=m.group(2).strip()
    return d
def plan(tags):
    P={}; PR={}
    for tag in tags:
        R=blocks(S+tag+'_report.md',['VERDICT','CONCEPT','EVIDENCE','NEW']); H=blocks(S+tag+'_harm.md',['CHECK','WHY','SAFER']); PR.update(prior(tag))
        assert set(R)==set(H)==set(prior(tag)),tag
        for n,r in R.items():
            assert n not in P
            v=r['VERDICT'].split()[0]; h=H[n]; c=h['CHECK'].split()[0]
            if v=='KEEP': P[n]=('keep',None,None)
            elif c=='OK': P[n]=('resay',r['NEW'],'ok') if v=='RESAY' else ('release',v,(r['CONCEPT'],r['EVIDENCE'],h['WHY']))
            elif c=='OBJECT' and h['SAFER'].startswith('**'): P[n]=('resay',h['SAFER'],'corrected')
            else: P[n]=('keep',None,'objected')
    return P,PR
def norm(s): return ' '.join(s.split())
def apply(tags,mate,section='## Droplets',dry=False):
    P,PR=plan(tags); f=C+'carry/'+mate; t=open(f,encoding='utf-8').read()
    secs=re.split(r'(?m)^(?=## )',t); i=[k for k,x in enumerate(secs) if x.split('\n',1)[0].strip()==section][0]
    s=secs[i]; parts=s.split('\n\n'); head=parts[0]; ps=[x for x in parts[1:] if x.strip()]
    assert len(ps)==len(P)==max(P),(len(ps),len(P))
    out=[]; rel=[]; cnt={'keep':0,'objected-keep':0,'resay':0,'corrected':0,'release':0,'repeat':0}; seen=set()
    for n,p in enumerate(ps,1):
        assert norm(p)==norm(PR[n]),(n,p[:80],PR[n][:80])
        k,v,x=P[n]
        if k=='keep': out.append(p.strip('\n')); cnt['objected-keep' if x else 'keep']+=1
        elif k=='resay':
            assert v.startswith('**') and '\n' not in v
            if v.rstrip() in seen: cnt['repeat']+=1; continue
            seen.add(v.rstrip()); out.append(v.rstrip()+' — v386EOD'); cnt['corrected' if x=='corrected' else 'resay']+=1
        else: rel.append((n,v,x)); cnt['release']+=1
    secs[i]=head+'\n\n'+'\n\n'.join(out)+'\n\n'
    if not dry: open(f,'w',encoding='utf-8').write(''.join(secs))
    return cnt,rel
