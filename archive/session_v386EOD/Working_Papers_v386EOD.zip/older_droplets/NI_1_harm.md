### 1
CHECK: OK
WHY: Natural Intelligence line 99 and Exhibit TWENTY-FOUR Geodesic Improving Method line 192 have the two quotations exactly, `rigorize.py` names the six, and carryings/rings_are_spirals_v377/README.md line 126 has "Natural Physics 2.1 welcomes the six" of the proposed file, the living Natural Physics v379 having no six binaries (searched).
SAFER: -

### 2
CHECK: OBJECT
WHY: Lost: the second of the prior's three concerns, "Two senses of odd and even … one word at each sense". Natural Intelligence's 4.7 no longer has the second sense (line 973, "one inversion across … none along"), but a living file has it still: Natural Naming line 399, "Morality is the changing parity between, odd at the between, and competency the unchanging parity between, even at the between, the numbers' own odd and even as they are", beside Natural Intelligence line 121, "Odd is competency and even is morality". The first reader's EVIDENCE leaves it to "its own mate's"; by search ("odd at the between", "even at the between", "senses of odd", "numbers' own odd and even") no file of carry/ but this paragraph and the Session Record has it, so with NEW the concern is at no mate. The third concern is said in its present form at Offerings to Natural Resolver, "Concern · One and eight across and along at one file" (v386EOD, line 327, read). The four quotations of NEW are exact, and its saying of the between as the method is the source's (carryings/cohering_ten_and_six_v377/README.md, section 5, "A second reading offered" and "What resolves it").
SAFER: KEEP

### 3
CHECK: OBJECT
WHY: Lost on a finding that is not so. The first reader's EVIDENCE has 'Natural Naming has no "infinity" at any line now', and NEW leaves out the prior's "Natural Naming's naming of the same set still saying it". Natural Naming line 837 has "a set is defined by its existing things, and null and infinity + 1 are both possible numbers of its elements" (searched "infinity": that one line). The clause "and no number names it" alone is gone from Natural Naming. All else of the prior is in NEW, and its two quotations are exact (Natural Intelligence line 77; the Geodesic Improving Method's heading 2.4, whose section has "A concern at a file's opening sentence is brought to both selves at the coupling, and no working changes one alone.").
SAFER: **Concern · Null and infinity + 1.** Two readings part. Natural Intelligence has "no count names it: null and infinity + 1 are both possible numbers of elements" and "no number bounds it". Released at one working's own resolving, it is carried again as it was: a fresh reading has the relation at no other sentence of the file, and Natural Naming has "null and infinity + 1" of the same set. Either the sentence saying no number names the set offers two numbers of its elements, and a set of null existing things is a changing set with nothing changing; or the two say no number bounds the set at either side, none and one beyond each number, and are whole. By the Geodesic Improving Method's "Each improving decided at do-no-harm", the opening section's sentences are brought to both selves at the coupling, and no working changes one alone.

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: OK
WHY: Natural Intelligence line 145 has both quotations exactly, carryings/v380R/For_The_Workings.md lines 61 and 96 have the premise and the two sayings as NEW gives them, and the title has the subject words the pointer at "Next at the named prior and actual offerings · v385A" finds.
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: OK
WHY: Natural Intelligence line 1000 has both quoted clauses exactly, and each claim of the prior, the one list at 6, 10 and 9, each 0 passed over at 14, and the two sayings, is in NEW.
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: OBJECT
WHY: Two things. (1) The condition is laid on another file at the place named. Carryings of Co-Chaining Logic Registry, "Earlier reading conditions and available drafts · v385A" (line 43, read), has the paragraph word for word, and its "Nothing enters this file from it" is of the Co-Chaining Logic Registry; the sentence after it, "The old conferring and draft-entry conditions are historical", is of "These paragraphs", that mate's. The condition laid on Natural Intelligence is at no living file and no section headed v385A or v386EOD (searched "conferr" in this mate and in Carryings and Possibling of Natural Intelligence: this paragraph and line 49 alone). (2) A pointer finds it: this mate's line 49, outside the older section, has "then the conferrings below", and this paragraph is the one paragraph below it with a conferring; the paragraph that line was first of (archive/carrying_v381R/Natural_Intelligence_v380R.md line 9) is no longer in the mate, so released, line 49 points at nothing.
SAFER: KEEP

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OK
WHY: archive/session_v380/v380G/README.md line 11 has the three questions as the record's and "Each is said as an absence; each needs its positive saying", and line 34 has "from outside this version's improving", of version 380.
SAFER: -

### 13
CHECK: OBJECT
WHY: Added, at neither the prior nor its source (carryings/review_natural_physics_v377/README.md line 51, its 2.2): the last sentence, 'Natural Intelligence names five things beside all existing things at "No other possible method", and its 4.13 is "Spirals, co-spiraling and crossing"'. Both are so at the living file (lines 99 and 1023), and the first is the subject of paragraph 1; the prior has neither, and the first reader's rule 4 has only what the source says in NEW. Nothing of the prior is lost; the source's "asserts" is "said as resolved" in NEW, and its "section 6.1" is said by that section's title.
SAFER: **Concern · Two sayings of the proposed Natural Physics of version 377, each listed open for both files.** Two sayings part. The proposed Natural Physics of version 377 has, at its 2.1, a naming beside all existing things at one of six binaries, and, at its 3.4, Natural Intelligence's rings at 4.13 as its spirals. Its own report lists the two as open for both files, at its section 6.1, of concerns with another file. They part at a reading asserted in the one and listed open in the other.

### 14
CHECK: OBJECT
WHY: Lost, and a finding added that the history does not have. The prior has the rule's release laid ready and waiting, and the work, "re-say 3.6 at 4.13's new sentence and mark the concern met"; NEW has neither, and has instead "Natural Intelligence's 4.13 has the rule at a newer sentence", at neither the prior nor its source (carryings/natural_physics_v377/README.md line 106). Read in the repository's history: the waist rule, "p no more than q, goes round at 4p at a q short of the ring of 4p's waist, 2p, and at q at a q past that waist", is in Natural Intelligence v378 at commit 69872eb, whose carrying has "the waist rule released with its evidence", the rule parting at 1 by 5, 3 by 13, 3 by 15, 3 by 27 and 5 by 25; each file of version 379 (commits 3b94693 line 654 to ef82136 line 682) has no waist rule, "at a momentary dividing 4p or 4q" and then "at 4p or at q". NEW's "the waist rule as Natural Intelligence's 4.13 had it at version 379" is the proposed file's own label (its line 260) said as a fact of Natural Intelligence. The living sentence NEW quotes is of another opening, "With each self carrying a parity, alternating along and across", with "3 by 13 at 13"; the proposed 3.6 is of "one self chained + and the others at none" and says of itself that the rule parts at 3 by 13 "at each 12th". The two are two openings, and "the rule at a newer sentence" is derived at no place read. Both quotations are exact (line 1033).
SAFER: KEEP

### 15
CHECK: OBJECT
WHY: Added, at neither the prior nor its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md line 102). (1) "had at version 373": the source has "already carries", and at that proposing the Registry's file was at version 371 (read at commit f50cc74, "Each link stands at one of seven standings"). (2) The sentence 'Exhibit THIRTY Co-Chaining Logic Registry has now "A step carrying an unsure line is open …"', exact at the Registry's line 52, a fourth sentence of the work beside the form's one to three. Nothing of the prior is lost: "run" is said as "executed", the standing's name at that Registry being *Run*, "holds at a running of the resolver's code", and "white paper" is said as Natural Intelligence.
SAFER: **Possible project · Natural Intelligence's contents decided by its title and the line under it.** An earlier proposed arrangement has the title and the line under it deciding the contents: Natural Intelligence, the fractal method of existing and discovering, stated from the origin as co-chaining binary co-sequential logic, each step at its standing. A step is origin, definition, premise, exact, executed, field or open, the standings Exhibit THIRTY Co-Chaining Logic Registry had at the proposing, and a step open is said open. Nothing is in Natural Intelligence that is no step of the chain, no statement of the object and no standing of the whole. It may change or never be made.

### 16
CHECK: OBJECT
WHY: Added, at neither the prior nor its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md line 115, the row of Part 7): "Natural Intelligence has no part with the chain." and the sentence 'Exhibit THIRTY Co-Chaining Logic Registry has "The co-chaining is one sequence of steps …"'. Both are so at the living files (Natural Intelligence's contents, lines 7 to 65; the Registry's line 52, exact), and they make four sentences of the work beside the form's one to three. All of the prior is in NEW: the seventh part, each step at its standing, the open steps said open, the chain checked at version 370, the Registry's Part Eleven and the Registry cited whole.
SAFER: **Possible project · The chain whole as a part of Natural Intelligence.** An earlier proposed arrangement has a seventh part of Natural Intelligence, the chain whole: the co-chaining from the origin to the only method, step by step, each step at its standing and the open steps said open, citing Exhibit THIRTY Co-Chaining Logic Registry whole. It was proposed from a chain checked at version 370, incoming at Natural Intelligence's carrying, and from that Registry's Part Eleven. It may change or never be made.

### 17
CHECK: OK
WHY: Exhibit TWENTY-FOUR Geodesic Improving Method's 1.5 has both quoted sentences exactly, of each delivery at each file, and Possibling of Living File Registry, "Earlier proposed improving order · v385A", has "the receiving before the releasing" of that same plan; no pointer to the paragraph was found (searched "Where the present sentences go" in carry/*.md).
SAFER: -

### 18
CHECK: OK
WHY: Natural Intelligence has no Part Seven and no 7.1 (searched), its society being 6.4 alone, and Possibling of Living File Registry, "Earlier Natural Intelligence protecting and co-competencing distribution · v385A" (line 327), has the sorting of that part's society, "the four kept at 5.6; the theorems near, to Natural Societies"; no pointer was found (searched "at the white paper"; the copy at this mate's line 183 is a second paragraph of the same older section).
SAFER: -

### 19
CHECK: OBJECT
WHY: The choice is not said as closed at the later place, and its two readings are at no later place. Possibling of Living File Registry, "The earlier Natural Intelligence object-and-kit arrangement · v385A" (line 363, read), has "Its inclusion or citation of Natural Resolver remains possible work". The prior's reading of each side, within and whole "the white paper stands alone with its object", and by citation it "is about 7,000 words shorter and leans on a second file", with "This draft keeps it inside, at its origin", is at no living file and no section headed v385A or v386EOD (searched "by citation", "stands alone", "leans on" in carry/*.md: this paragraph alone at this subject). The places named have parts: the 7,000 words at "Earlier proposed extent of the living subjects · v385A", and the fact of the file within the file at "Droplet · Six places at the file's own form". No pointer to the paragraph was found.
SAFER: KEEP

### 20
CHECK: OK
WHY: Exhibit THIRTY Co-Chaining Logic Registry has no Part Eleven and other sentences at its steps 9 and 21 (lines 96 and 148), F41 and F67 are at no living file (searched), and the present form of the concern is at this mate's "Droplet · Six places at the file's own form" (v386EOD), "At 1.4 no sentence says of each step that it is a naming, at the code, or still possibling".
SAFER: -

### 21
CHECK: OBJECT
WHY: The binary and its three outcomes are at no living file and no later section (searched "Three outcomes" in carry/*.md and the living files: this paragraph alone), and later paragraphs are said in its words. Possibling of Living File Registry has the map's rows in sections headed v385A (lines 195, 197, 325, 327, 357 and 359), "kept at 3.1", "near, to Natural Mathematics", "the carrying released and re-said at 3.1", and thirteen more mates have paragraphs of the same map (searched "Natural Intelligence Map"); this paragraph is the one place in carry/ that says what kept, near and released are, with the condition on near, "received whole at its receiving file first, then leaves Natural Intelligence, do-no-harm". The receivings are not all made: Offerings to Natural Physics has still "Natural Physics receives from Natural Intelligence: the aberration study", and the living Natural Physics v379 and Natural Intelligence have no "aberration" at any line (searched). The old means it names are gone from Natural Intelligence, as the first reader has it.
SAFER: KEEP

### 22
CHECK: OBJECT
WHY: The EVIDENCE "The plan of a motion since made" is so for three of its four steps and not for the first. Natural Intelligence's parts now are the map's (carryings/resettling_v373/Natural_Intelligence_Map.md, "The parts at the subtitle": One and Two, Three, Exhibit ONE, Four, Five, Six). The first step, "the receivings at section 3, each at its own file, whole, so nothing leaves Natural Intelligence before it is carried near", is not made at each file: twelve mates have "receives from Natural Intelligence" as droplets still (searched), and the aberration study, for one, is at no line of the living Natural Physics v379 or of Natural Intelligence (searched). The places named do not have this order: Exhibit TWENTY-FOUR Geodesic Improving Method's 3.5 is of a body edited ahead of its contents, and "Earlier proposed improving order · v385A" is of the order among the files (Re-Settling the Living Files, its section 10). With paragraph 21 it is what this mate says of the map those receivings are from.
SAFER: KEEP

### 23
CHECK: OK
WHY: Natural Intelligence line 131 and Exhibit TWENTY-EIGHT Equilibria Registry lines 203 and 211 have the three quotations exactly, and carryings/session_v377/Session_Report_v377.md, section 5 item 3, has each claim NEW gives, the self's 6, no self's 1 and the thing missing.
SAFER: -

### 24
CHECK: OK
WHY: Natural Intelligence line 1000 has both quoted sentences exactly, "no existing thing" is at no line of the file (searched), and no pointer to the paragraph was found.
SAFER: -

### 25
CHECK: OK
WHY: archive/carrying_v381R/Natural_Intelligence_v380R.md lines 46 and 50 have the twenty-four at two readings and "the four stills at the sixteen ways and the ten at the faces, two counts at one kind", and the three quotations are exact (Natural Intelligence lines 154 and 192; the Registry's step 506).
SAFER: -

### 26
CHECK: OBJECT
WHY: The living file does not say all the prior asks. The prior asks each statement "with its full deduction" from the opening sentence. Natural Intelligence has the first two as sentences (lines 99 and 154, exact), and this mate's own later sections say the deductions are not made: "The stronger universal claim, no other method of possibling next existing, still needs its complete co-chaining" (v385A, line 323) and "the excluding is derived at no step here" (v386EOD, line 387). The third statement, "the scientific method not demonstrating existing", is at no sentence of Natural Intelligence and at no living file (searched "demonstrat" at the root); its 5.4 has an accounting against fixings, another saying. It is at a later section of another mate, Offerings to Natural Philosophy, "Droplet · An explaining, and its occurring" (v386EOD, line 176), "That the scientific method demonstrates no existing is said with the asking it leans on", as a droplet and with no deduction; and the later place named, Possibling of Co-Chaining Logic Registry, "Each universal claim at a heading of the contents", has "the scientific method incompetent at discovering competency", of the Registry's contents. Exhibit ONE Natural Resolver has none of the three (searched). So the work asked is in part not made, and no one place has it whole: the three statements at Natural Intelligence, each with its deduction.
SAFER: KEEP

### 27
CHECK: OBJECT
WHY: The thing asked of is changed, and three things are added. The prior asks of two namings, "the carry living" and "the carrying travelling", the second from "names the carrying as what travels at the geodesic changing" (carryings/v368_sources/Carry_Set_v368_README.md line 66). NEW has the second as "the carrying as the thing at the geodesic changing": the naming's own word is gone, and the name NEW gives is at neither the prior nor its source. Natural Naming's row (line 247) releases *travel* for *carrying*, so by the first reader's own rules the second naming cannot be said at its word in NEW. Added: "Whether the two are one naming or two is said at no file", where the prior has "One naming or two" alone; "Neither naming is at a sentence of Natural Intelligence"; and "At version 368".
SAFER: KEEP

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: OK
WHY: Natural Intelligence lines 121 and 125 have the two quotations exactly, and the two notes left out are gone from the living files: "coming home", "one running", `bi_arriving` and `bi_offering` are at no line of Natural Intelligence or Exhibit ONE Natural Resolver (searched), and Natural Intelligence's 3.2 has now "each goes in and out at the parity opposite its name's opening".
SAFER: -

### 30
CHECK: OBJECT
WHY: Three things. (1) Changed: the arriving wording, "Self and other travel at the co-sequential momentary rate. Carrying travels at the geodesic unrelationing rate", is "are offered as at" in NEW, and the prior's "the carrying travelling" is "the carrying at the geodesic changing", a name the prior does not have, brought from paragraph 27; the source (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Natural_Illustrating_v366.md lines 79 to 89) has "the carrying named as what travels at it". (2) Added and inexact: "then named 17-social-abundancing". The first reader's EVIDENCE has the name "at no living file"; it is at Natural Naming line 448 and at Natural Networking lines 159 to 170 (searched). (3) Lost: "Held for both to agree beside the five dimensional relational", the prior's condition of an agreeing by both. Paragraph 27 is the short saying of the same and is objected alike.
SAFER: KEEP

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: OK
WHY: Natural Intelligence line 210 and Exhibit ONE Natural Resolver lines 64 and 66 have the three quotations exactly, with `'along'` at 9 and 17, and Living Improving Value line 56 (v385A) has the earlier front's concern, "the unused `CONNECTORS` and `JOINS` lists names releasing at 6 and 10".
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR, each of its 32 paragraphs; the PROPOSED, each block and its closing section; the mate Offerings to Natural Intelligence, lines 1 to 705, each section headed v385A and v386EOD and the whole older section; and the objections of the first mate's harm reading, for the form and the strictness. The living file is over 15,000 words, 24,946, and was read at its sections: Natural Intelligence lines 1 to 369, its front, parts ONE to THREE and the resolver's lines, list and table of seventeen names, and lines 915 to 1146, parts FOUR to SIX; the tables of the Exhibit ONE within it, lines 370 to 914, were not read.

Read at the places named: Exhibit TWENTY-FOUR Geodesic Improving Method, 1.5, 2.4, 2.7 and 3.5; Exhibit THIRTY Co-Chaining Logic Registry, line 52 and steps 9, 21 and 506; Exhibit TWENTY-EIGHT Equilibria Registry, lines 182, 203 and 211; Exhibit ONE Natural Resolver, lines 62 to 70; Natural Naming, lines 247, 399, 448 and 837; Exhibit TWENTY-SIX Living File Registry, line 68; the living Natural Physics v379 by its headings and by search. Mates: Carryings of Co-Chaining Logic Registry, "Earlier reading conditions and available drafts"; Possibling of Living File Registry, seven of its sections headed v385A; Offerings to Natural Resolver, lines 77 and 327; Possibling of Co-Chaining Logic Registry, line 116; Living Improving Value, line 56; Offerings to Natural Physics, lines 452 to 454; Offerings to Natural Philosophy, line 176. Sources: in carryings/, rings_are_spirals_v377, natural_physics_v377 with its proposed file, review_natural_physics_v377, cohering_ten_and_six_v377 (2.3 to 2.7, 2.12 and 5), resettling_v373 (Re-Settling the Living Files and the Natural Intelligence Map), session_v377, session_v378, v368_sources, v380R and v382F; in archive/, carrying_v381R, carrying_v380L and session_v380/v380G. From the repository's history: Natural Intelligence v378 at commit 69872eb and v379 at its commits, for the torus's sentence, and the Co-Chaining Logic Registry v371 at commit f50cc74, for its standings.

Checked by search: each quotation in each NEW, by exact search in the living files at the root, each found; pointers to each paragraph released, in the mate and in carry/*.md, by the paragraph's own opening words and its subject words; and the words each finding leans on, "infinity", "odd at the between", "conferr", "Three outcomes", "aberration", "demonstrat", "by citation", "stands alone", "leans on", "receives from Natural Intelligence", "Natural Intelligence Map", "the carry living", "17-social-abundancing", "waist", "F41" and "F67".

Not checked: the resolver was not executed, so no number of a torus or a spiral in a NEW or in a prior was worked; the nine other files of paragraph 28's inventory were not read; the corrected paragraphs at SAFER were checked for their quotations, their length and the first reader's excluded words, and were read by no second reader.
