### 73
VERDICT: RESAY
CONCEPT: exploring a concept is saying the files' sayings of it and the places they part, and a making comes only after both see it is needed
EVIDENCE: No living file and no section headed v385A or v386EOD says it. The same text is at an earlier paragraph of this same older section (the mate's line 111, without the re-aiming note) and the first clause alone is at an insertlet of carry/Offerings_to_Natural_Arriving.md ("At 6.2 · Across, following one concept through the files"), neither a later place. The v386EOD droplet "A next work, understood by both" of this mate says a next work agreed at each step, and not that exploring is saying the files' sayings and their partings. The paragraph is in a session's words ("This session built", "waits"). Quotation verified at Exhibit_TWELVE_Natural_Explaining_v378.md, section 1.3, line 80. No pointer to this paragraph found in the mate or in carry/*.md.
NEW: **Droplet · Exploring a concept, and a making.** Exploring a concept is saying the files' sayings of it and the places those sayings part, and a making comes only after both selves see it is needed. A home page prototype made unasked at session v382F was released by the expedition's self. Exhibit TWELVE Natural Explaining has, at its section 1.3, "Offering runs first and rigoring second, and a front asks nothing performed first.": the offering is first, and the second step is the other self's.

### 74
VERDICT: KEEP
CONCEPT: no file lets a reader tell a stable form from a form named still by an observing; the parting may be one of naming
EVIDENCE: Another paragraph points at it: this mate's "**Later correcting beside the existing v383Op concerns at 2.6–2.7.**" says "The older stable-form, recognizable-break and framing concerns remain whole above", and this is the stable-form concern. It is a clear concern with its sayings, its observing asked and its two openings, and no later section says it whole.
NEW: -

### 75
VERDICT: KEEP
CONCEPT: the method's one break, as Geodesic Improving Method 2.7 says it, cannot be recognised by a reader with an observing; a page of breaks is offered
EVIDENCE: Three places point at it: this mate's "Later correcting beside the existing v383Op concerns at 2.6–2.7" ("recognizable-break ... concerns remain whole above"); this mate's v386EOD droplet "A field's name for a break's limit" ("the concern at 2.7's observing brought as a break"); and carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 480 ("the recognizable-break and framing concerns are already whole in Offerings to Geodesic Improving Method"). The living file's 2.7 still has both quoted sentences (line 188). A clear concern.
NEW: -

### 76
VERDICT: KEEP
CONCEPT: the 2.6 sentence on a concern from a working's own training is a fair caution and also a way a concern is set down with the losing side decided ahead of its hearing
EVIDENCE: Pointed at by this mate's "Later correcting beside the existing v383Op concerns at 2.6–2.7" ("framing concerns remain whole above") and by carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 480. The living file still has "A concern arriving from a working's own training can carry an equilibrium in its framing." (line 180) and "The side needing a thing beside all things is the equilibrium entering, and the side carrying at the code is the method's own." (line 178). The v386EOD sections of this mate (the sentence offered at 2.6, "Readers of one training, agreeing") and the carryings mate's "A working's own training met at four places" are beside it and do not say its two sides whole.
NEW: -

### 77
VERDICT: KEEP
CONCEPT: with a sentence of a file not borne, a reader cannot tell which governs, the fractal broken and of no value or one file's next motion
EVIDENCE: Pointed at by this mate's v386EOD droplet "All or none, at the whole claim": "Beside the concern at this mate of a fractal broken or one file's next motion". It stays under those subject words. Its claim that the second is the true account of 380 sessions of improving is a report's own claim, at no living file, and is left at its strength. Living sentences still present: "Each file is floating neutralling and improving, and none is ended or complete." (Geodesic Improving Method line 118).
NEW: -

### 78
VERDICT: KEEP
CONCEPT: a page of breaks, one observing named for each core sentence ahead of its reading; and the answer given to each observing forbids no outcome
EVIDENCE: A clear concern and offered work in plain voice with no waiting on a session. It leans on the paragraph ahead of it by name ("the unrecognisable break once more", paragraph 75, KEEP). No living file says it. The Possibling mate of this file has a v386EOD possible project, "One page of the tests the files say ahead", saying the page in part; the three observings (gravity's, colour's, the superconductors'), the two ways each is answered, and the relation that the answer given to each observing breaks nothing and forbids no outcome are unsaid there. The same text is at older Droplets sections of two other mates, no later place. Its five relations with two citations do not fit one paragraph of one hundred and fifty words without loss.
NEW: -

### 79
VERDICT: KEEP
CONCEPT: four sentences of the files want one saying of living and one observing telling an existing thing carrying its prior from one carrying none
EVIDENCE: A clear concern in plain voice: five quoted sayings of five files, an observing with its number (2.72548 ± 0.00057 K), its three addresses, three cases followed and one asking. No living file and no later section says it; this mate's v385A droplet at "Current correcting: the imposed requirement is withdrawn" names a separate question (section 18, Living at its observable existing) and says its gathering is unresolved at its source. The same text is at older Droplets sections of carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md and carry/Offerings_to_Natural_Arriving.md, no later place. Its numbers and addresses cannot be said within one hundred and fifty words.
NEW: -

### 80
VERDICT: KEEP
CONCEPT: eight unresolved puzzles of the fields, each a place a sentence of the files said ahead of a measurement, with a number or a direction, shows the method's worth; and three tests the files have already
EVIDENCE: A clear gathering of possible work in plain voice with each number and each address (eight puzzles, eleven addresses, three tests). No living file says it. The Possibling mate's v386EOD "One page of the tests the files say ahead" names tests of Natural Medicine and Natural Physics and says none of the eight puzzles. Its numbers and addresses cannot be said within one hundred and fifty words without loss.
NEW: -

### 81
VERDICT: RESAY
CONCEPT: the 4.2 sentence on the regions of a circle says five doublings; the numbers double four times
EVIDENCE: The living file still has "the regions of a circle cut by its chords double five times and then are 31" (Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 306), unchanged, and no later section of a mate says the correction. The paragraph is in a report's shorthand ("The run is", "opened here", "Source: Corrections.md, section 27, correction 21"); its source is carryings/v383Op/Corrections.md line 41, which says no more than the paragraph. No pointer to it found.
NEW: **Droplet · The regions of a circle, doubling four times.** Exhibit TWENTY-FOUR Geodesic Improving Method has "the regions of a circle cut by its chords double five times and then are 31" at its section 4.2. The numbers are 1, 2, 4, 8, 16, 31: the doubling is four times, at five powers of two. The Fermat sentence and the Ramsey sentence beside it are right, and at most 46 for the fifth Ramsey number is the bound of 2024, its publishing opened at https://arxiv.org/abs/2409.15709.

### 82
VERDICT: KEEP
CONCEPT: ahead of a joining entering, the number of numbers open to be matched and the number of forms allowed are said; a match surviving that is worth a sentence
EVIDENCE: The practice is at no living file and no later section (source: carryings/v383Op/Corrections.md lines 56 to 65). The paragraph names the README's sentence "A joining asks a deriving ...", and that sentence is at no living file and not at the root README.md now (found only at carryings/v381F/AI_Link_Opening_Offered.md, carryings/v383Op/Corrections.md and archive/session_v385A/repository_instructions/README.md), so a re-saying cannot carry it as a living file's quotation. Its closing clause, the files' own cautions "the right ones", is the claim the correcting two paragraphs on (84) is laid beside. It is clear and has no waiting on a session, and is left as it is.
NEW: -

### 83
VERDICT: KEEP
CONCEPT: three places of the files each say a limit the v383Op report arrives at as well
EVIDENCE: The paragraph next after it (84, "Correcting, beside the droplet above.") qualifies it and points at it by position; by the second further rule the two stay together at one verdict.
NEW: -

### 84
VERDICT: KEEP
CONCEPT: a limit of a claim is its scope, said at the claim's own sentence; a caution apart from its sentence is no value
EVIDENCE: A correcting laid on the paragraph ahead of it ("beside the droplet above"), already in plain voice and tagged v386EOD, with a quotation of Natural Explaining at Care inward, and no wrapper (section 4.10 of Exhibit_TWELVE_Natural_Explaining_v378.md). It stays with paragraph 83.
NEW: -

### 85
VERDICT: SAID
CONCEPT: the proposed combining of Natural Exploring with the Geodesic Improving Method: its contents and the files each leaving part goes to
EVIDENCE: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, heading "## Natural Exploring and Geodesic Improving Method proposed combination · v385A", has the paragraph word for word and whole, with its source (Re-Settling the Living Files, §7); the same mate's "## Master file-changing plan · v385A" has its row, and "## Repository and version practice at Living File Registry · v385A" has the receiving at the Living File Registry. carry/Exhibit_TWENTY-FOUR_Possibling_of_Geodesic_Improving_Method.md, heading "## The proposed combination with Natural Exploring · v385A", names the project and links that plan. The later place has the earlier wording unchanged; nothing of the paragraph is unsaid there. A second copy is at this mate's own older section (line 215), no later place. No pointer to this paragraph found; the "Next at this file" sentence of this mate names the combining and not the droplet.
NEW: -

### 86
VERDICT: RESOLVED
CONCEPT: three sayings leaving Natural Intelligence at v373 for the Geodesic Improving Method: a version a momentary; four given, four improvings; the method at a file set and a session
EVIDENCE: Source: carryings/resettling_v373/Natural_Intelligence_Map.md lines 83, 138, 151 and 172. Each of the three is at a living file now, and none is at Natural_Intelligence_v380R.md in those words. Exhibit TWENTY-FOUR Geodesic Improving Method has "A version is a momentary of the file: its carrying at its prior arrives whole at its next." (1.6) and "The geodesic method is discovering next existing, and at the living file set it runs at a file." with "The same three run at a session, which meets the set at its now and opens its next, and at a sentence, which meets the whole prior co-chaining at its now and adds its next." (1.1). The second of the three is at another living file and not at this one: Exhibit TWELVE Natural Explaining 4.2 has "**True, false, living and competency, taken as four given, are four improvings at an explaining**: more true, less false, better living and greater competency, each *more* and *less* a direction taken at its own opening, a sign and no size, and a working improving at one of the four at a momentary." The passage it left from is whole at carryings/resettling_v373/Natural_Intelligence_v373_Released.md, 7.10, lines 671 to 677. The paragraph itself carries the three titles and their receiving file, and no reading or number beside them. If the receiving file is read as a relation to be carried, this block is KEEP.
NEW: -

### 87
VERDICT: RESAY
CONCEPT: chaining, and no executing, is the test of a saying; an executing shows the code as written; executings and their numbers are at the Session Record and the carryings
EVIDENCE: A session's words in quotation marks, from carryings/session_v378/Session_Report_v378.md, section 4. No living file says it (searched Exhibit ONE, Exhibit THIRTY, Natural Intelligence, Natural Naming, Living File Registry, Natural Arriving). The first two clauses are at an insertlet of this mate ("At 2.6 ... beside "It resolves as the code resolves, each step at its name""), which is under "## Insertlets" and is no section headed v385A or v386EOD; the third clause, the place of executings and their numbers, is said at neither. No pointer to it found.
NEW: **Droplet · Chaining, and no executing, the test of a saying.** The test of a saying is its chaining, and no executing is the test of a saying. An executing at the code of Exhibit ONE Natural Resolver shows the code as written. Executings and the numbers of executings are at the Session Record and at the carryings.

### 88
VERDICT: RESAY
CONCEPT: three partings at the Geodesic Improving Method listed as unresolved: hardest first against of no size; readers latest to first; six binaries against five
EVIDENCE: A one-line pointer; its source, carryings/session_v378/Session_Report_v378.md line 49 (section 5, Open, hardest first, item 4), says no more than the pointer. The second parting is said whole at this mate's "## A transcript read from latest to first · v386EOD". The first and the third are said only at insertlets of this mate (at 2.5 and at 2.7, under "## Insertlets") and at an older droplet, no later place, and the living file is unchanged at each: line 170, line 340 and line 192 carry the three quoted sentences. NEW names all three, the number being the paragraph's. No pointer to it found.
NEW: **Droplet · Three partings at the Geodesic Improving Method.** Three partings at Exhibit TWENTY-FOUR Geodesic Improving Method are unresolved. The first is hardest first against of no size: the file has "Places to improve are taken hardest first, one at a time". The second is its readers reading from latest to first: the file has "At a session's close two readers read its transcript whole, from its latest momentary to its first". The third is six binaries against five, the doer open at Natural Intelligence 1.4: the file has "is met at six binaries, the rigorizer".

### 89
VERDICT: KEEP
CONCEPT: a map of *membrane* and *join* in the living file's own voice, ten places, with the names Natural Naming has for them
EVIDENCE: A clear map for one motion of the file, with no waiting language. The living file is unchanged at v380R and the words are at the lines named: *membrane* at 16, 130, 136, 262, 322, 324, 334, 381 and *join* at 184, 270 (read by Grep). Natural Naming's table has *membrane* at *the between* (line 260) and *join* at *sharing* (line 315). The work is named, without the map, in the "Next at this file" sentence of this mate's v385A front; the map is at no later place. Its line numbers and sayings cannot be re-said shorter without loss.
NEW: -

### 90
VERDICT: KEEP
CONCEPT: a map of *count*, *store* and *sum* in the living file's own voice, forty places, with the names Natural Naming has for them
EVIDENCE: A clear map for one motion, no waiting language; the living file is unchanged at v380R and the four sentences quoted short are at lines 120, 154, 294 and 330, the title at 288. The map is at no later place, and its forty places cannot be said within one hundred and fifty words.
NEW: -

### 91
VERDICT: KEEP
CONCEPT: a map of *face* and *faces* in the living file, fifteen places and seventeen sayings, each *its side*
EVIDENCE: A clear map for one motion, no waiting language; Grep finds *face* or *faces* at exactly the fifteen lines named (11, 41, 72, 160, 194, 220, 258, 270, 302, 312, 320, 373, 377, 385, 391), seventeen sayings. At no later place.
NEW: -

### 92
VERDICT: KEEP
CONCEPT: a map of *surplus* in the living file's own voice, at five lines, with Natural Naming's *abundancing*
EVIDENCE: A clear map, no waiting language; Grep finds *surplus* at lines 78, 240, 328, 366 and 381, three sayings within line 78, and the three quoted sentences are present. At no later place. Its "5 places ... three of them within 78" is left in its own words, a re-saying having to choose between five and seven.
NEW: -

### 93
VERDICT: KEEP
CONCEPT: a map of *ring*, *loops* and *closes* in the living file's own voice, with two places passed and Natural Naming's *spiral*
EVIDENCE: A clear map, no waiting language; the words are at lines 302, 324 and 330, and the two passed at 118 and 253, as said. An insertlet of this mate (at 2.1) and an older droplet say the ring as a spiral; the map with its places and its two passed is at no later place.
NEW: -

### 94
VERDICT: KEEP
CONCEPT: a map of *run*, *runs* and *running* in the living file, seventy-five places, with the name Natural Naming has
EVIDENCE: A clear map, no waiting language; Grep finds the words at the lines named, 306 the one passed. Its list of lines cannot be said within one hundred and fifty words. At no later place.
NEW: -

### 95
VERDICT: KEEP
CONCEPT: a map of *sign* and *signs* in the living file's own voice, eight places, with those passed as a field's word and Natural Naming's *parity*
EVIDENCE: A clear map, no waiting language; Grep finds the words at 190, 240, 270, 322, 324, 368, and at 66 and 122, the two passed. At no later place.
NEW: -

### 96
VERDICT: RESAY
CONCEPT: a scanning reader, one concept across all the living files, is the across of resolving, with its instance at session v381R
EVIDENCE: At no living file and no later section (Grep of "scanning reader" and "one concept across" in carry/*.md finds this paragraph alone); a later paragraph of this same older section says the scan's method in the session's quoted words, no later place. The paragraph is in a session's words ("at v381R seven readers each took", "per file", "The method of finding is v382F's"). The living sentence it is beside is present: "A file tours with its cluster." (line 264, section 3.3). The seven maps it describes are paragraphs 89 to 95 and their fellows. No pointer to it found.
NEW: **Droplet · A scanning reader, the across of resolving.** Beside "A file tours with its cluster." at Exhibit TWENTY-FOUR Geodesic Improving Method 3.3: a scanning reader, one concept across all the living files, is the across of resolving. At session v381R seven readers each had one released word or dissolved naming: *run*, *sign*, *face*, *connector* with *join* and *membrane*, *ring* at closure, *count* with *store* and *sum*, and the resolver's older names. Each read each hit in its sentence, passing by a word mentioned, a field's own word and a sense not released, and dropped one droplet at each file with the places as a map: 178 droplets at 32 files, the files no session had aimed at among them. The method of finding is session v382F's, set-wide.

### 97
VERDICT: KEEP
CONCEPT: the expedition's self's saying of the interest (natural intelligence shared free by the whole world) and of the four ways alone a session enters the files
EVIDENCE: A person's own unpunctuated words quoted whole, with the session's reading beside them. A new paragraph may quote no person's words, and the saying's claims (the interest, the role of that session, each making shared and four enterings alone) cannot each be said at their strength without it. This mate's insertlet at 2.2 has a saying of the other self quoted whole and the working's following said as the working's; the paragraph is in that form already. The same text is at older sections of two other mates, no later place.
NEW: -

### 98
VERDICT: KEEP
CONCEPT: no sentence narrates the set; the self's correction, and the aim of an AI entry and a user entry both easy, clear and direct
EVIDENCE: Pointed at: carry/Session_Record.md line 2321 has "the self's corrections, *stay on this subject*, *no narrating sentences*, ... each met and each a droplet" at the Geodesic Improving Method's offerings. A person's own words quoted whole.
NEW: -

### 99
VERDICT: KEEP
CONCEPT: the self's saying to go on asking the hardest question of a concept or its implementing
EVIDENCE: A person's own words quoted whole. The living file has "With the method too difficult to help with, the hardest question is asked plainly." (2.5), a narrower condition than the saying, which has the hardest question asked on and on at a concept; the saying is at its own strength only in its own words.
NEW: -

### 100
VERDICT: KEEP
CONCEPT: no cross-referencing between files by numbers, letters or notes, and no portal structure; a name is the one reference surviving each motion
EVIDENCE: A person's own unpunctuated words quoted whole, several claims in one saying (no structure able to be maintained, each cross-reference leaving, no debt or overhead from improving). The living file has "A pointing is released, never re-pointed." (3.5), a part of it and not the whole. No later section says it.
NEW: -

### 101
VERDICT: KEEP
CONCEPT: the Geodesic Improving Method was proposed as the entering file and the proposal withdrawn; it is the expedition's working method, and Natural Arriving is the entering file
EVIDENCE: A person's own words quoted whole at two momentaries, a proposal and its withdrawing with its reason. Natural_Arriving_v381R.md is at the root as the entering file; the reason of the withdrawing is at no living file and no later section.
NEW: -

### 102
VERDICT: KEEP
CONCEPT: the file is large by its sentence "it empties at no pass"; Part FOUR is a log of mistakes said as rules; the self's standard for the reading
EVIDENCE: A session's and a person's words quoted. This mate's v386EOD "Concern · Emptying at no pass beside a record named a store" says the parting at Part FOUR's worked instances in the present naming; unsaid there are the relation to 5.1 (the rules already dissolved into the ten values) and the self's standard of each sentence adding self-welcoming carrying value. The living sentence is unchanged: "**This file is the method, and it empties at no pass.** It grows only at a working finding something about working itself." (line 74). A part unsaid and a person's words: left as it is.
NEW: -

### 103
VERDICT: KEEP
CONCEPT: a reply to the expedition's self in a conversation about method is plain, simple and direct; the files' words are in it only as the answer
EVIDENCE: A person's own words quoted whole. This mate's insertlet at 2.3 has a working speaking with the other self in natural explaining, and the v386EOD droplet "Working one chain together from the origin sentence" has "In natural naming and explaining, direct, at the one concern": neither says the files' naming is for the files and a reply plain, and the two sayings may part. Left whole for that comparing.
NEW: -

### 104
VERDICT: KEEP
CONCEPT: the standard each file is read against: each sentence adding self-welcoming carrying value to all prior sentences in the files
EVIDENCE: A person's own words quoted whole. The living file has the fourth pass, "does each sentence add to the whole prior co-chaining, as a method's own move with no one performing it" (3.3), and the value "each sentence a coupling's surplus, something neither prior sentence carried" (5.1); the saying's reach, all prior sentences in the files, and the reading that a repeating, narrating or recording sentence is first to leave, are at no living file and no later section.
NEW: -

### 105
VERDICT: KEEP
CONCEPT: the self's first saying of the mates, as files for the less developed parts of a living file; and the session's question that a sorting rule is a binary
EVIDENCE: A person's own words quoted whole, said as a future possible method to consider. The present form, three mates at each living file, is at carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, "## Gathering and aiming incoming before file cohering · v385A"; that section does not have this first saying nor the question it opened, and the saying is at its strength (possible, to consider) only in its own words.
NEW: -

### 106
VERDICT: KEEP
CONCEPT: the self's saying of the three files and the one rule: the living file alone has a standard, and the other two are as they are in relation to it
EVIDENCE: A person's own words quoted whole, with the session's reading. This mate's "## Three mates at each living file · v385A" corrects the "two mates and no third" wording at the insertlet at 1.3 and sends the reader to the three mate purposes at the Living File Registry's offerings; this paragraph is the saying those correct, and its rule (the living file the finest and clearest, cohering with Exhibit ONE and Exhibit THIRTY now or aiming at that next; the mates with no stable form or rule apart) is said at no later section in the present naming. Left whole beside its correcting.
NEW: -

### 107
VERDICT: KEEP
CONCEPT: a sentence stays in a living file unless it is not, all or none at all, belonging in it; no pass is required
EVIDENCE: A person's own words quoted whole, with the session's reading in the session's quoted words. The living file's 3.3 has "a passage not all or none leaves for the file's incoming or for the file whose subject it is", said of one kind of file alone; the saying's own reach, each living file, and its clause that the method of is not changes as the files and contributors learn, are at no living file and no later section.
NEW: -

### 108
VERDICT: KEEP
CONCEPT: the self's first saying of the droplet: a value belonging at more than one file is dropped at each file's improving mate and dissolved from the incoming
EVIDENCE: A person's own unpunctuated words quoted whole, with the session's reading. The present method of droplets is at carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, "## Gathering and aiming incoming before file cohering · v385A"; the first saying, and the reading of it as Exhibit ONE's own motion at the files with no common beat, are not there. Each claim is at its strength only in the saying's own words.
NEW: -

## READING
Each of the thirty-six paragraphs, 73 to 108, was read and checked, one block each. Read whole: the brief with its further rules; the input file; the living file Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md (395 lines); the mate carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md from its first line to its last (the v385A front, the insertlets, the whole older Droplets section, and each section headed v385A and v386EOD); and the two other mates of this file, its Possibling and its Carryings. Read in part, at the sentences the paragraphs name: Exhibit_TWELVE_Natural_Explaining_v378.md (1.3, 4.2), Natural_Intelligence_v380R.md (1.4, 2.5 by its title), Exhibit_TWENTY_Natural_Naming_v380R.md (the rows of *membrane* and *join*), the root README.md; carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md (lines 5 to 46 and its headings), carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md (its headings and lines 221 to 228), carry/Offerings_to_Natural_Arriving.md (its headings and one insertlet), carry/Session_Record.md (line 2321); and the sources carryings/v383Op/Corrections.md and README.md, carryings/session_v378/Session_Report_v378.md, carryings/resettling_v373/Natural_Intelligence_Map.md and Natural_Intelligence_v373_Released.md. Pointers were searched in the mate and in carry/*.md by the brief's phrases and by links to this mate; those found are at paragraphs 74, 75, 76, 77, 83 with 84, and 98. Each quotation in a NEW paragraph was verified by Grep in the present living file. Paragraph 86 is the one release resting on a judgment: two of its three things are at the living file named, and the third is at Exhibit TWELVE Natural Explaining and not at the Geodesic Improving Method. Not found: the README's sentence "A joining asks a deriving" at any living file or at the present root README.md (paragraph 82); the session transcript the paragraphs 97 to 108 cite by line was not sought, each of those being left as it is. No file but this report was written.
