### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OK
WHY: laid beside the prior and its source, carryings/co_chaining_coverage_v378/readings/11_registries_illustrating_corus.md line 41 (contradiction 7) and lines 9, 15, 17 and 19 (the things entered): both quotations are exact strings, "The technology is all or none at all." under "## 1.1" at line 105 of Exhibit_TWENTY-FIVE_Living_Society_Registry_v347.md and "A technology is a made non-living thing applied to a changing from beside it, and a method is at the couplings themselves, applied by nothing." at step 50, line 272 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md; 1.1 is named, no step number is added, the entering from this file at version 378 and its things are as the prior has them, and "for both" is said with no word added to it; the folder the prior names is still named for this file at Carryings of Living Society Registry line 9, and no later section says of this concern that it carries its source (searched "exact sources", "technology", "all or none at all" in carry/*.md).
SAFER: -

### 4
CHECK: OBJECT
WHY: Lost: whose reading it is and of which session, and with it the strength of four claims. The prior closes "(Re-Settling the Living Files, §2 table) — resettling_v373". Its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md, read at lines 1 to 40, 65, 207 and 272) is headed "first draft, session v373"; the row at line 65 lies under the column heads of line 38, "Shape at this reading", "Its own subject", "Restating the common method", "Old code or older wording"; and line 28 has "shares of a file by kind are readings, not measurements". NEW says each as a thing that is now, with no reading named: "It is good and clear", "About 75% of the file is its own subject, and about 5% restates the common method", "It has little old wording", "is at 12,200 words". (1) "Little old wording" is against the naming of version 373. At the naming now this same mate's paragraphs 14 to 19, each left as it is, map released words at this file at 28, 65, 3, 1, 50 and 19 places (*membrane*, *count* with *store* and *sum*, *face*, *surplus*, *run*, *sign*), so the sentence said as of now parts from the mate it lies in. (2) The two portions are a reader's estimates by the source's own word, and NEW says them as measures of the file. (3) "Good and clear" is one session's judging of the file's shape. (4) The living file is 12,011 words at a plain word search now (wc), so "is at 12,200 words" is the source's figure and not a present measure. Nothing else is lost: 12,200, version 347, no sources, 1.10 missing, about 75%, about 5% and little old wording are each in NEW as the prior has them, and "no sources" and "1.10 missing" are at the living file still (its contents and sections go from 1.9 to 1.11; no entry has a source of its own). The mend is the reading named, as the first reader's rule 12 has it and as its own NEW for paragraph 8 does.
SAFER: **Droplet · Living Society Registry good and clear, with no sources and 1.10 missing, at session v373's reading.** Session v373's reading of the living files has Exhibit TWENTY-FIVE Living Society Registry, 12,200 words at its version 347, as good and clear, with no sources and its 1.10 missing. At that reading about 75% of the file is its own subject, about 5% restates the common method, and it has little old wording.

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: OK
WHY: laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md line 207, an item of a document that says of itself "It is a first draft of a re-settling plan" and "It changes no living file" (line 24), so the work is proposed and not done: the observations home for the sciences, a source address at each entry and at none now, the Part Three status paragraph going to the Living File Registry, and 1.10 written or the numbering closed are each in NEW at the prior's strength; at the living file no entry has a source address, "# 3 Passing at the substrates, one at a time" has its "**So far, and not yet.**" paragraph at line 1009, and no 1.10 is between 1.9 and 1.11 (read whole); the subject words "the observations home for the sciences" stay, and no paragraph of carry/*.md points at this one (searched "observations home", "status paragraph").
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: OK
WHY: laid beside the prior and carryings/session_v378/Session_Report_v378.md line 19, under "## 2. The standing of the living files against the apex" ("**Far back, v345 to v348, five files.** … the Living Society Registry v347 and Natural Philosophy v348, light."): both files, both versions, far back and the light carrying of each are in NEW with that session's reading named and nothing beside them; the past "were" lies under that date and denies nothing of now, both files being at versions 347 and 348 still (Exhibit TWENTY-SIX Living File Registry lines 87 and 93).
SAFER: -

### 9
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Wrap_v368.md line 73 ("**Across the set.** Each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words."): each of the five things released, the improving and the shared words are in NEW as a droplet, with no "may never be made" added, and the aiming at the set is said; the same NEW is at carry/Exhibit_SEVEN_Offerings_to_Natural_Societies.md line 51.
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OK
WHY: laid beside the prior and carryings/v381F/v381F/Session_Report_v381F.md (Finding 2, "TWENTY-ONE's and TWENTY-FIVE's *An Open Registry of …*, the two subtitles with no -ing and no relation unfolded", and the Ready line, "TWENTY-ONE's and TWENTY-FIVE's at the relation each unfolds, an -ing in place of *An Open Registry of*, at each file's own motion and in its own voice") and Next.md line 58: the aiming at one sentence, the two subtitles, the other file and each clause of the laid-ready line are in NEW at the prior's strength, laid ready and not said as made; the one quotation, "An Open Registry of Observations from Science", is exact at line 9 of the living file, and the other subtitle is Exhibit TWENTY-ONE Hard Problem Registry's, "**An Open Registry of Hard Problems in Science**" (its line 7), Exhibit TWENTY-TWO's having an -ing.
SAFER: -

### 13
CHECK: OK
WHY: the second copy of paragraph 6, word for word but for "(re-aimed from Exhibit TWENTY-SIX Offerings to Living File Registry at v381R)", which says where the paragraph lay before and carries no claim of the file; checked as at 6 against carryings/resettling_v373/Re-Settling_the_Living_Files.md line 207 and the living file, with both files the paragraph is for named in NEW; carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md has no paragraph of the observations home or the status paragraph pointing here (searched).
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its Further rules; the PRIOR file LS_1.txt and the PROPOSED file LS_1_report.md; the living file Exhibit_TWENTY-FIVE_Living_Society_Registry_v347.md (12,011 words, 1,013 lines); the mate carry/Exhibit_TWENTY-FIVE_Offerings_to_Living_Society_Registry.md with its two sections headed v386EOD; and this file's two other mates, Carryings of and Possibling of Living Society Registry.

The proposed file has no RESOLVED, SAID or NOVALUE; its seven changes are each RESAY (3, 4, 6, 8, 9, 12, 13), and each was laid beside its prior and beside its source, read at the lines named: carryings/co_chaining_coverage_v378/readings/11_registries_illustrating_corus.md (lines 1 to 41, each line naming this file); carryings/resettling_v373/Re-Settling_the_Living_Files.md (lines 1 to 40, 65, 196 to 212, 262 to 276); carryings/session_v378/Session_Report_v378.md (lines 1 to 24); carryings/v368_sources/Wrap_v368.md (lines 60 to 75); carryings/v381F/v381F/Session_Report_v381F.md (lines 57 to 63, 125 to 129) and Next.md (line 58); incoming/v385A/Registry_Plan_Comparison_v385A.md (lines 28, 30, 57).

Checked by exact search: the two quotations of NEW 3 (living file line 105; Exhibit THIRTY Co-Chaining Logic Registry v380L line 272, step 50); the quotation of NEW 12 (living file line 9) and the subtitles of Exhibit TWENTY-ONE Hard Problem Registry and Exhibit TWENTY-TWO Resolving the Hard Problem Registry; the rows of Exhibit TWENTY-SIX Living File Registry v381R for versions 347 and 348; Exhibit TWENTY Natural Naming v380R line 297. Searched in carry/*.md: pointers to this mate and its paragraphs (its name, its link, "the concern at this mate", "above", "the preceding", "existing concern"), and each changed paragraph's subject words ("technology", "all or none at all", "observations home", "status paragraph", "far back", "good and clear", "12,200", "namings of other exhibits", "Open Registry", "no -ing", "exact sources"). The one place naming this mate from another is the table row at Carryings of Living File Registry line 390, a link to the mate whole. Each NEW was also searched by script for the first reader's barred words outside quotation and italics (none found) and for its length (45 to 126 words; the SAFER of 4 is 72).

Not checked again: the thirteen KEEP blocks, which leave their paragraphs as they are.

Numbers: OK 6 (3, 6, 8, 9, 12, 13); OBJECT 1 (4); KEEP-UNCHANGED 13 (1, 2, 5, 7, 10, 11, 14, 15, 16, 17, 18, 19, 20).
