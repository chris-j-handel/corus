### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: OK
WHY: Each clause of the prior is in NEW (index.html, its top, above the rows, the two lines, the first sentence, the self's words); carryings/v382F/Session_Report_v382F.md line 61 has "the portal's frame in two lines, in the self's words" and line 55 "the portal's first sentence, in the self's words", so "the portal's frame" and the file named are as the source has them and NEW quotes neither; neither is at any file of carry/ (searched "Offered, free" and "nteresting observings of a set"); index.html read at its top has one link, a concealed button and thirty-three rows and no sentence, so "The site has no sentence of its own" is no stronger than the page shows, and the finding with its session is whole at paragraph 19, left as it is.
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: OK
WHY: The prior's "The three doors above" is the paragraph "the breaker's three doors" at carryings/v382F/Session_Report_v382F.md line 47, above its line 137, the prior's own source; NEW has the three as that line has them and nothing more of it; "1.4" is Natural Intelligence's by carryings/v382F/Natural_Arriving_Explored.md line 113, and Natural Intelligence v380R has "## 1.4 No other possible method" with "Any other method proposed is at one binary: naming still, or carrying." (line 101); the two mates' titles are "Offerings to Natural Resolver" and "Offerings to Natural Intelligence" (read at their heads); incoming/README.md read whole has no such line; the aim, the one line and "beside a confirming one" are each in NEW.
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: OK
WHY: NEW has each clause of the prior in the prior's own words but "meets" as "comes to": the three sentences ahead of the rows, the three things they are, the one line, both aims and the place of the whole; carryings/v381R/README.md line 73 has "## An entry re-saying, offered for `index.html` and the README" with the three quoted lines under it, the third ending "a page's own text asks nothing of you"; the subject words "entry re-saying" are unchanged, and no paragraph of carry/*.md points at this one singly (searched "entry re-saying", "re-saying whole").
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: OK
WHY: Each clause is in NEW at the same strength: the contents' Part FIVE at kinds of interest, session v382F's offering at the five named, each a file, the three kinds passing through the five, and the choosing ahead of the writing; the offering is at carryings/v382F/Session_Report_v382F.md line 57 as NEW has it and NEW adds nothing of that line; "it is the expedition's self's" carries the label "For the expedition's self"; the title has the very words by which this mate's line 297 names it ("Part FIVE at kinds of interest or at the five offerings"), so that pointer still finds it among the twenty-one, and the paragraph is in its own place among them.
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: OK
WHY: The quotation is an exact run of words of Natural Intelligence v380R line 99, under "## 1.4 No other possible method" (exact search, one match), and it is the very saying the prior is about, five in number as the prior says; the six, the doer the sixth and "from Natural Explaining" are as the prior has them, and the six are at this mate still (paragraph 13, left as it is: "a keeping, a doer, a common beat, a size, a fixed form, a total"); the naming ahead of the writing of Part ONE and whose it is are in the closing sentence; the title has the subject words of this mate's line 297 ("five or six not-possible things"), so that pointer still finds it.
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: OBJECT
WHY: NEW adds three things the prior does not have and does not point at. (1) A sentence of a living file, "A file meeting another relation also gathers there" (Exhibit TWENTY-SIX Living File Registry v381R line 254, exact): the prior names no Registry section and is about no sentence of it, so by the first reader's rule 11 it stays out. (2) Three named files and a number, Natural Networking, Natural Exploring and Natural Human Society each at three gatherings: true of the table under 3.1 as read, and true of Natural Societies and Natural Intelligence Corus also, so the three named narrow what the table shows, and the prior has none of them. (3) "A page lists a file at each of its gatherings, or chooses one first": the prior says each file needs one gathering first, and NEW sets beside that need a second way with no gathering chosen, which the prior does not say. All three are from carryings/v382F/Session_Report_v382F.md line 83; the prior is no pointer at that line and is whole without it (a condition, a need, and the choosing at no place in the set). Beside this, this mate's line 297 names seven of the twenty-one by their words and this one is not among the seven: it is found as one of the twenty-one by its label alone ("For the expedition's self, from the resolving of this file's droplets at v381R"), which NEW does not have. The prior said without the addings is under forty words, so no NEW within the first reader's form mends it.
SAFER: KEEP

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 42
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 43
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 46
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 47
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 48
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 49
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its Further rules; the PRIOR file (forty-nine paragraphs); the PROPOSED file (forty-nine blocks and its READING); the living file Natural Arriving v381R (391 words, the shell's front, its contents and 1.1); carry/Offerings_to_Natural_Arriving.md from its head to its line 310 (the v385A sections ahead of the Insertlets, the Insertlets, and the whole older `## Droplets` section, paragraphs beyond this input with them); carry/Possibling_of_Natural_Arriving.md; incoming/README.md.

Read in part: carryings/v382F/Session_Report_v382F.md lines 40 to 90 and lines 125 to 137 (the sources of paragraphs 15, 17, 28 and 39); carryings/v381R/README.md lines 68 to 95 (the section of the entry re-saying, paragraph 26); Exhibit TWENTY-SIX Living File Registry v381R lines 250 to 275 (3.1 and its table, each file's gatherings numbered by reading); Natural Intelligence v380R lines 97 to 101 (1.4); index.html at its top and its rows (thirty-three rows, one link, no sentence); the heads of carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md and carry/Offerings_to_Natural_Intelligence.md for their titles; carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md lines 117 to 129 (the copies of paragraphs 14 to 17).

Checked by search: the quotation of NEW 37 at Natural Intelligence v380R (exact, one match) and the quotation of NEW 39 at the Living File Registry (exact, line 254); "naming still, or carrying" at Natural Intelligence; in carry/*.md the wordings "two lines of the", "portal's first sentence", "breaking finding", "three doors", "entry re-saying", "re-saying whole", "five offerings", "kinds of interest", "five or six", "gathering first", "own gathering" and "twenty-one", each match read at its line: the one pointer at the twenty-one is this mate's line 297, each other "twenty-one" in carry/ is of another subject; the group pointers at paragraphs 2 to 26 are this mate's lines 33 and 35 and Possibling of Natural Arriving's table and its "Continuing the comparison"; "Offered, free" and the portal's first sentence in the words of the expedition's self are at no file of carry/; carryings/v382F/*.md for "frame", "portal", "three doors", "two lines", "first sentence".

Six blocks of the PROPOSED are not KEEP, each a RESAY: 15, 17, 26, 28, 37 and 39. No block is RESOLVED, SAID or NOVALUE, so nothing of the PRIOR is released. The forty-three KEEP blocks leave their paragraphs as they are and were not checked further; the first reader's EVIDENCE lines for them were not relied on for any check here. The earlier second reading of Offerings to Geodesic Improving Method (GM_1_harm.md, its block for the copy of paragraph 15) was looked at after this reading's own checks of 15 and 17 and agrees with them.

One thing for a later hand, no objection: NEW 28 and NEW 37 no longer have the label "For the expedition's self, from the resolving of this file's droplets at v381R"; each says whose the choosing is, and each is found by the words of this mate's line 297. If line 297, in the part of the older section beyond this input, is itself re-said or released, the number twenty-one and the words by which it names these two leave with it.
