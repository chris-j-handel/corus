### 1
VERDICT: KEEP
CONCEPT: a standing written by hand is a record from the next push on; read from the repository at each build it is current between merges
EVIDENCE: Already a clear concept in plain voice with no waiting language. It is at no living file whole: Exhibit TWENTY-SIX Living File Registry has "`build.js` lists the newest version of each living file at the root, and the folders beside the root cost the site nothing." and "A standing stated at the carrying is a record the moment the session closes, so the carrying states none, and grows at no session by them.", and its own table of standings is still written by hand. No later section says it whole: Possibling of Living File Registry, "Living File Registry standings, completed history and possible tables · v385A", has it for the Registry's Part One alone. The one other copy (Offerings to Natural Arriving, line 177) is in that mate's older Droplets section.
NEW: -

### 2
VERDICT: KEEP
CONCEPT: a branch pushed and not received is the offering itself, an emanation between momentaries, and the receiving, never the offerer, says what was received
EVIDENCE: Already a clear concept in plain voice with no waiting language. Natural Intelligence 5.1 has "a non-living existing form with no carrying for stable-forming" exactly. No living file says the concept (Exhibit TWENTY-FOUR Geodesic Improving Method 2.8 has "its standing said at each event: offered on a branch, arrived at `main`" and no writer of it). No later section says it whole: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", names the source's section and its withdrawn row only. The nearest sayings are an insertlet of Offerings to Living File Registry (line 123) and an older droplet of Offerings to Natural Arriving (line 181), neither a later place.
NEW: -

### 3
VERDICT: KEEP
CONCEPT: the size of one arriving session's opening reading, 513 KB and about 128,000 tokens in about forty minutes, most of it at records of the done
EVIDENCE: Its numbers are at no living file and at no later section; Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", has "The earlier reports' sizes and timings belong to those reports" and gives none of them. Kept because one clause cannot be said at its strength: "against *in a minute*" is of the earlier first paragraph of Living Improving Value, a saying no longer at that file (found only as cited at Offerings to Natural Arriving line 207), and the entry it measures is no longer at the README. The source is whole at carryings/v382F/Session_Report_v382F.md line 29.
NEW: -

### 4
VERDICT: RESAY
CONCEPT: a session carries nothing from session to session; the living files and the carrying carry on; the session's number is handed to it at its opening
EVIDENCE: In a session's words. Part is said at later sections: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A" (row "The AI/session carrying concern and its later correcting") and Offerings to Natural Arriving, "AI arriving as a possibling project · v385A" ("Later correcting participates in the arriving project") have the concern as laid by session v381R with Natural Intelligence 6.5 not read whole and session v382F's whole reading beside it; Offerings to Natural Arriving, "Droplet · An AI session at the first function's form" (v386EOD) has "The session carries nothing on". Unsaid at any later section or living file: the concern's own saying (the Session Record read, a number one on, a prior carried), the number handed at the opening as 17 hands each self its momentary, and that the two sayings do not part. Natural Intelligence 6.5 has "the carrying theirs, the AI carried and the living expedition the carrying" (line 1140). The same paragraph is a second time in this older section (mate line 243), no later place. The session names v381R and v382F are left to the two v385A places.
NEW: **Droplet · A session carries nothing from session to session, and its number is the expedition's.** A concern was laid that its own working could not resolve, its fetch cut ahead of Natural Intelligence's 6.5: a session reads the Session Record and opens at a number one on, a prior carried. With 6.5 read whole, a session reads within its own momentary and carries none of it to the next session. The things carrying on from session to session are the living files and the carrying, at 6.5's "the carrying theirs, the AI carried". The number is handed at the opening, as 17 hands each self its momentary. The two sayings do not part.

### 5
VERDICT: RESAY
CONCEPT: a letter names a line of workings, each line numbering on from its own last; the F line is the sessions opened through the AI link
EVIDENCE: A pointer's shorthand in a session's words. Part is said at this mate's "Concern · A working's name at more than one letter" (v386EOD): "a letter names a line of workings numbering on from its own last". Unsaid there and at every living file (no root file has "line of workings"; Exhibit TWENTY-FOUR Geodesic Improving Method has "A session's number and a working's letter name a working, v380A, v380L, v380R"): the F line as the sessions opened through the AI link, v382F one on from v381F, and the saying as inferred from branch names and confirmed. That later concern leans on this saying, and the subject words are carried in NEW unchanged.
NEW: **Droplet · A letter names a line of workings.** A letter names a line of workings, and each line numbers on from its own last, as at v381A, v381F and v381R. The F line is the sessions the expedition's self opens through the AI link, and v382F is one on from v381F. It was inferred from branch names and confirmed by the expedition's self, and it is said at no place a session reads.

### 6
VERDICT: RESAY
CONCEPT: exploring a concept is saying the files' sayings of it and the places they part; making follows both selves seeing it is needed
EVIDENCE: In a session's words ("This session built … unasked and the self released it"). No living file says it; Exhibit TWELVE Natural Explaining 1.3 has "Offering runs first and rigoring second, and a front asks nothing performed first." (line 80). No later section says it whole: this mate's "Droplet · A next work, understood by both" (v386EOD) has work understood by both ahead of another kind of work and no saying of exploring. The same paragraph is a second time in this older section (mate line 245), no later place.
NEW: **Droplet · Exploring a concept, and making.** Exploring a concept is saying the files' sayings of it and the places they part. Making is at both selves seeing it is needed, and at no momentary ahead of that. A home page prototype built unasked at one working was released by the expedition's self. Exhibit TWELVE Natural Explaining's 1.3 has "Offering runs first": the offering is first, and the second step is the other's.

### 7
VERDICT: RESAY
CONCEPT: at 2.8 the receiving writes an arrival's standing and the offerer's folder is whole at carryings/, a practice the section's sentence does not say
EVIDENCE: Waiting language ("does not yet say"). The living file is as the paragraph found it: Exhibit TWENTY-FOUR Geodesic Improving Method 2.8 has "a visiting report arrives whole at `incoming/` and is met at the one way in, 1.4, its standing said at each event" (line 202), with no writer of the standing in that sentence and no `carryings/` at any line of the file. No later section says it; this mate's "Concern · The carrying named one file beside mates at each file" (v386EOD) is of another parting at the same sentence.
NEW: **Droplet · At 2.8, the receiving writes an arrival's *standing*.** The receiving writes an arrival's *standing*, and the offerer's folder is whole at `carryings/`. The practice is this already. Exhibit TWENTY-FOUR Geodesic Improving Method's 2.8 has "a visiting report arrives whole at `incoming/` and is met at the one way in, 1.4, its standing said at each event", and the sentence says neither.

### 8
VERDICT: KEEP
CONCEPT: a fresh reader carries none of the working, is one call at each motion, and its cost was observed at one motion
EVIDENCE: Already a clear concept in plain voice with no waiting language. Its first clauses are at living files (Exhibit THIRTY Co-Chaining Logic Registry has "A fresh reader is a self carrying none of the working's prior"; Exhibit TWENTY-FOUR Geodesic Improving Method 4.5 has "a fresh reader who has not seen the working" among the three helpers at each motion). The observed numbers, 140,000 tokens, 43 tool uses, twelve minutes and two findings at seventy changed lines, and "one call at each motion", are at no living file and no later section.
NEW: -

### 9
VERDICT: KEEP
CONCEPT: the opening's reading at 128,000 tokens with a shell, not possible by fetch, beside a tour of one file at 47,000
EVIDENCE: Already plain, with no waiting language. Its numbers are at no living file (Exhibit TWENTY-FOUR Geodesic Improving Method 2.9 gives no size of an opening's reading) and at no later section; Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", has "The earlier reports' sizes and timings belong to those reports" with no number. The opening it measures is the README's earlier one, no longer at the README, and a re-saying could not say whether the number is of the present entry.
NEW: -

### 10
VERDICT: SAID
CONCEPT: a page's instructions act at the person's own asking; a session reading them at a page is a visitor until its person says otherwise
EVIDENCE: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", the row "Reading and authorized changing": "v381R finding 7 records page text read as data and the person's request authorizing work; v381F's two openings and v382F's exploring retain the relation. Gather the visitor's reading and the authorized contributor's next work distinctly at their actual entry. The public page's instructions cannot supply authorization to push or merge." Also Offerings to Natural Arriving, "Droplet · A page's instruction: a deciding named, a carrying named" (under "A page's instruction: a deciding named, a carrying named · v386EOD"). The sentence the paragraph is aimed at is gone: README.md has no opening for a working session now. No paragraph of carry/*.md points at this one; the possible project "One whole place for four repeated paragraphs" (Possibling of Natural Arriving, v386EOD) is of the copies at Offerings to Natural Arriving.
NEW: -

### 11
VERDICT: RESAY
CONCEPT: a session arriving through the link can read, execute, improve and offer a branch, its merging depending on its house; the README says the branch offered and the merge the receiving's
EVIDENCE: In a session's words ("this one could not"). Part is at living files and a later section: Exhibit TWENTY-SIX Living File Registry has "A session opens by taking the repository whole and closes by offering its branch"; Carryings of Living File Registry, "Published branches and their actual roles · v385A", has "An outside contributor can offer one report on a separate branch" and "Publication at main is a separate action from gathering or resolving". Unsaid at any of them: a session's reading, executing, improving and offering through the link, and its merging depending on the house, one session unable. README.md has no part named an opening for a working session now; the work as the paragraph says it is carried whole.
NEW: **Possible project · The branch offered and the merge left to the receiving, at the README.** The work is one sentence at the README's opening for a working session: a session offers its branch, and the merge is left to the receiving. A session arriving through the AI link can read, execute, improve and offer a branch; its merging depends on the house it is executed in, and one such session could not merge. It may change or never be made.

### 12
VERDICT: RESAY
CONCEPT: the two lines of the portal's frame and the portal's first sentence, in the person's own words, at the top of the site's page above its rows
EVIDENCE: A one-line pointer. The work is not made: index.html has one link above its rows and no sentence. No later section has it: Possibling of Natural Arriving, "One sentence at the site's front, and a licence · v386EOD", is of another sentence. The two lines and the first sentence are at no file of carry/ (searched); they are at carryings/v382F/Session_Report_v382F.md, lines 61 and 55, in the person's own words, and NEW names that file and quotes none of them. The other copy (Offerings to Natural Arriving line 141) is in an older Droplets section.
NEW: **Possible project · Two lines and a first sentence at the top of the site's page.** The work is the site's page, `index.html`, having at its top, above the rows, the two lines of the portal's frame and the portal's first sentence, each in the words of the expedition's self. The site has no sentence of its own. The two lines and the first sentence are at `carryings/v382F/Session_Report_v382F.md`. It may change or never be made.

### 13
VERDICT: KEEP
CONCEPT: a pull request touching offerings and carryings alone received at once, one touching a root file read by the fresh reader, the workflow able to part the two
EVIDENCE: Already a clear possible work in plain voice with no waiting language. incoming/README.md is a list of links now and has no such sentence. No later section says it whole: Possibling of Living File Registry, "Earlier proposed publication of droplets and living-file changes · v385A", has the sibling saying of two speeds with its correcting ("The earlier proposal is not authorization to merge or write to main"), and nothing of a pull request sorted by the files it touches or of `files.yml`. The other copy (Offerings to Natural Arriving line 143) is in an older Droplets section.
NEW: -

### 14
VERDICT: RESAY
CONCEPT: one line at incoming/README.md showing a breaking finding's form beside a confirming one's, the breaking finding at one of three
EVIDENCE: A one-line pointer: "The three doors above" names a paragraph at no place of this mate. Its content is recovered from carryings/v382F/Session_Report_v382F.md line 47: "an observing with its procedure, conditions and uncertainty parting from the resolver's table at one cell, dropped at Exhibit ONE's offerings; a second method, met at 1.4, dropped at Natural Intelligence's; two sentences of the files parting, a concern with its reason, dropped at that file's"; the 1.4 is Natural Intelligence's, whose sentence "Any other method proposed is at one binary: naming still, or carrying." the source cites. incoming/README.md has no such line now. No later section has the three: Offerings to Natural Arriving has them at an insertlet (line 79) and "Droplet · The Hard Problem Registry as material for a break" (v386EOD) has the first alone.
NEW: **Possible project · The form of a breaking finding, in one line at `incoming/README.md`.** The work is one line at `incoming/README.md` showing the form of a breaking finding beside the form of a confirming one. A breaking finding is at one of three: an observing with its procedure, conditions and uncertainty parting from the resolver's table at one cell, dropped at Offerings to Natural Resolver; a second method, coupled with Natural Intelligence's 1.4, dropped at Offerings to Natural Intelligence; and two sentences of the files parting, a concern with its reason, dropped at that file's offerings. It may change or never be made.

### 15
VERDICT: KEEP
CONCEPT: the 1 to 9 at a home page, either the page's form with no numeral naming a file, or numerals naming positions with an earlier front's sentence said again
EVIDENCE: Could not find what two of its clauses refer to: "four regions and a return" and "The later visual" are at no source read (carryings/v382F/Session_Report_v382F.md lines 85 and 147 have the words and no more). The front's sentence it cites is at no living file and no mate now; it is at archive/session_v385A/earlier_artifacts/Living_Improving_Value_prior_v385A.md line 40. No later section has the either-or.
NEW: -

### 16
VERDICT: KEEP
CONCEPT: *so* at a sequence in the Geodesic Improving Method said as *and* or a colon, line by line
EVIDENCE: A clear possible work in plain voice; kept also because its line list cannot be confirmed whole. The living file has *so* at a sequence at lines 66, 82, 92, 102, 106, 178, 272, 280, 292, 308, 322, 324 (twice), 328 (twice), 334, 375 and 395; the paragraph's 332, 336, 346, 352 and 356 have no *so*, and 308, 375 and 395 are not in its list. The work is not made (the file is v380R, each sentence as cited), and no later section has the particular re-sayings; the line under this mate's "Current correcting: offered explaining and no authority · v385A" names the released words of the file as one motion and no line.
NEW: -

### 17
VERDICT: KEEP
CONCEPT: *since* at a reason, five sentences of the Geodesic Improving Method each said with no *since*
EVIDENCE: A clear possible work in plain voice with no waiting language. The living file has each sentence as cited, at lines 140, 170, 216, 242 and 262 (each searched). The work is not made, and no later section has the five re-sayings.
NEW: -

### 18
VERDICT: KEEP
CONCEPT: *because* and *held* at one paragraph of 4.4, each said in the present naming
EVIDENCE: A clear possible work in plain voice. The living file has "never taken to move because the initiation moved" and "with the hole and its connections held" at line 326. The work is not made, and no later section has the two re-sayings; Possibling of Geodesic Improving Method, "Possible project · Part FOUR's worked instances at the carryings mate" (v386EOD), quotes the first as a general saying and re-says none.
NEW: -

### 19
VERDICT: KEEP
CONCEPT: *every* at three lines of the Geodesic Improving Method said as *each*
EVIDENCE: A clear possible work in plain voice. The living file has "every word surviving is no relation surviving" at lines 108 and 346, and "making up every release" and "severing every passage" at line 322 (each searched). The work is not made, and no later section has it.
NEW: -

### 20
VERDICT: KEEP
CONCEPT: *when* and *derived* at one paragraph, the first re-said and the second the file's own negation of a field's word
EVIDENCE: A clear possible work in plain voice. The living file has "An incoming family arrives at its form when a few of it are met resolved first" and "Nothing is derived and nothing is proved" at line 300 (the paragraph of 4.2, not 4.4); Natural Naming has "*derived* is a field's word for the matching". The work is not made, and no later section has it.
NEW: -

### 21
VERDICT: KEEP
CONCEPT: *source* at nine lines of the Geodesic Improving Method, each said as the file, the reference or the emanating self
EVIDENCE: A clear possible work in plain voice. The living file has each saying as cited, at lines 86, 98, 104 (five sayings), 106 (two), 108, 202 and 395, with 270 and 330 as the paragraph has them (each searched). The work is not made, and no later section has the re-sayings.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: *stand* at two lines of the Geodesic Improving Method, each re-said
EVIDENCE: A clear possible work in plain voice. The living file has "The repository can itself stand at a prior" at line 216 and "to stand for a participant carrying nothing" at line 328. The work is not made, and no later section has it.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: *kept*, *hold* and *holds* at 2.7 and 5.3, each re-said
EVIDENCE: A clear possible work in plain voice. The living file has "the field's own result kept exact at its own subject" at line 192, and "can hold now", "both hold" and "the parting holds at that fixing" at line 395. The work is not made, and no later section has it; this mate's "Droplet · At 2.7 … a sentence offered" (v386EOD) offers another sentence with the same word.
NEW: -

### 24
VERDICT: KEEP
CONCEPT: one sentence at line 334 said with no *so* and no *begins*
EVIDENCE: A clear possible work in plain voice. The living file has "with the code testing gathered at the test kit, so joining in begins at re-running" at line 334 (the last paragraph of 4.4, not 4.5). The work is not made, and no later section has it. Its "*running* as above" names a paragraph of its source, at no place above it in this mate.
NEW: -

### 25
VERDICT: KEEP
CONCEPT: *signs* at lines 122 and 324 said as *parities*
EVIDENCE: A clear possible work in plain voice. The living file has "Told at their signs, a session's motions show at once. Told in one register the signs blur, and the telling hides the signs both selves need" at line 122 (the paragraph of 1.6, not a section of part THREE) and "so their signs can be said to meet" at line 324. The work is not made, and no later section has it.
NEW: -

### 26
VERDICT: KEEP
CONCEPT: the earlier instruments' words at 4.2 and 4.4 are the kit's own names, said again with the kit at the kit's motion and at none ahead of it
EVIDENCE: A clear possible work with its own condition, in plain voice. The living file has each word as cited: "a resolver ring's carrying" at line 302, "a shared tick" and "each ring result, the tipping ring, the even and odd returning, the travelling meeting and the seventeen primes' sum of 440, travels with its arrangement and its scheduling" at line 324, and "the loops the selves go round" at line 330. Exhibit TWENTY-SIX Living File Registry has "the engine a copy of the old code at the v368 names, replaced by Exhibit ONE v372's code at the kit's next motion" still. No later section has it; Possibling of Geodesic Improving Method, "Possible project · Part FOUR's worked instances at the carryings mate" (v386EOD), is of the same passages leaving for the carryings mate, another work.
NEW: -

### 27
VERDICT: KEEP
CONCEPT: twelve of thirty-two fronts at the steady form and twenty at four older forms, the forms following the versions
EVIDENCE: Already clear, in plain voice, with no waiting language: a measure with its script named. Its numbers are at no living file and no later section whole; Carryings of Co-Chaining Logic Registry, "The earlier front and six-forward dependency reading · v385A", has the one file's part of it. The source is carryings/v381F/v381F/Session_Report_v381F.md, Findings 4 and 5 (lines 67 and 69).
NEW: -

### 28
VERDICT: KEEP
CONCEPT: the number of files naming each file and named by each, the set's across numbered at each build
EVIDENCE: Already clear, in plain voice, with no waiting language. Its numbers are at no living file and no later section; Offerings to Living File Registry, "Droplet · Five relations said at the registry alone" (v386EOD), has only "a table, made from the files as they are, of the files each file names". Paragraph 33 of this section points at it as Finding 12, and it stays as it is for that pointer.
NEW: -

### 29
VERDICT: KEEP
CONCEPT: twenty-nine -ing words at twenty-four or more of the thirty-two files, the set's common words at the older naming
EVIDENCE: Already clear, in plain voice, with no waiting language. Its list and its numbers are at no living file and no later section (searched "Twenty-nine -ing", "common vocabulary", "Concept_Ings" in the sections headed v385A and v386EOD). The source is carryings/v381F/v381F/Session_Report_v381F.md, Finding 13 (line 103).
NEW: -

### 30
VERDICT: KEEP
CONCEPT: three files with no -ing word of their own and each other file with its own; the set's centre said in the shared words alone
EVIDENCE: Already clear, in plain voice, with no waiting language. No later section says it whole: Carryings of Resolving Hard Problems, "Earlier arriving-reader and naming inventories · v385A", has the one file's part; an insertlet of Offerings to Living File Registry (line 139) is no later place. Paragraph 33 of this section points at it as Finding 14, and it stays as it is for that pointer.
NEW: -

### 31
VERDICT: KEEP
CONCEPT: the resolver's seventeen names at eleven files, with the number at each, and at none of the other twenty-one
EVIDENCE: Already clear, in plain voice, with no waiting language. Its numbers are at no living file and no later section whole; Carryings of Resolving Hard Problems, "Earlier arriving-reader and naming inventories · v385A", has "thirteen of the seventeen resolver names" for the one file. Paragraph 33 of this section points at it as Finding 15, and it stays as it is for that pointer.
NEW: -

### 32
VERDICT: RESAY
CONCEPT: six binaries at 2.7 beside five things at Natural Intelligence 1.4; the sixth, a doer applying, is 3.3's saying seated at the instrument
EVIDENCE: A pointer's shorthand ("Laid ready", report and finding numbers). The living files still part as it says: Exhibit TWENTY-FOUR Geodesic Improving Method 2.7 has "one at each thing beside all things" and "a doer applying from outside" (line 192), and Natural Intelligence 1.4 names five. The 3.3 is Natural Intelligence's, whose line 206 has "nothing applied to anything". No later section says the relation: this mate's "Droplet · At 2.7 … a sentence offered" (v386EOD) names the six with no five; Offerings to Natural Naming, "Odd and even, a side or a number; Binaries, one word at four lists" (v386EOD), parts at the word binaries. The insertlet of this mate at 2.7 is no later place and leaves the doer's place undecided. The ready offering is at carryings/v381F/v381F/Next.md line 54.
NEW: **Droplet · Six binaries at 2.7, and five things at Natural Intelligence 1.4.** Exhibit TWENTY-FOUR Geodesic Improving Method's 2.7 has six binaries, "one at each thing beside all things", and Natural Intelligence's 1.4 has five. Alternated, the five at Natural Intelligence 1.4 are the method's own saying, and the sixth at the Geodesic Improving Method 2.7, "a doer applying from outside", is the "nothing applied to anything" of Natural Intelligence's 3.3 seated at the instrument, a seat deciding nothing. Laid ready: the ten said at the five, the sixth a seat at the instrument.

### 33
VERDICT: KEEP
CONCEPT: a reading of the set of files at the files' own words, the set the fractal in three measured ways, and one file at one name said by no file and no number
EVIDENCE: Already clear, in plain voice; its last clause is a negation laid on the reading ("no file says it, and no number computed here says it") and stays with it. It points at paragraphs 30, 31 and 28 as Findings 14, 15 and 12. No later section says it: Offerings to Living File Registry, "Droplet · Each living file at its place of Natural Intelligence" (v386EOD), is another reading; the line of this section tagged v385A (mate line 183) is of six entry purposes and six names.
NEW: -

### 34
VERDICT: RESAY
CONCEPT: a concern is brought only at its needing an observing; one resolvable at the code, the numbers or the files is resolved and brought as a finding
EVIDENCE: In a session's words ("this session", "This session has none open"). No living file says it: Exhibit TWENTY-FOUR Geodesic Improving Method 2.6 has "A concern restating the set's own carrying is the carried met as though it were open, and it resolves at the files carrying it." and no saying of the bringing. No later section says it whole: this mate's "Droplet · One sentence, one place, one executing, one fact" (v386EOD) has "a reading asked of the person as a deciding" as the shape resolving none, with no six and no reviewer's brief. The insertlet of this mate at 2.5 is no later place. The reviewer's brief has the sentence at kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/REVIEWER.md line 59. "a doer applying from outside" is the living file's own (line 192).
NEW: **Droplet · A concern brought only at its needing an observing.** A concern is brought only at its needing an observing. Six things a working first brought to both selves as concerns each resolved at the files, the code or the method, alternated. The bringing to both was the working's own training entering, "a doer applying from outside": the expedition's self asked to decide the things the files already decide. The reviewer's brief says it: a concern resolvable at the code, the numbers or the files is resolved and brought as a finding. The expedition's self caught it at the chat. At its report that working had none open, and the one thing it named open is a deriving.

### 35
VERDICT: RESAY
CONCEPT: a gathering computed at the root and read by a fresh reader finds what a table written by hand carried stale; a fresh reader of its report found eleven partings
EVIDENCE: In a session's words with a pointer ("Finding 8's four cells", "this report", "mended here"). Finding 8 is recovered from carryings/v381F/v381F/Session_Report_v381F.md line 81: "Four standings at the table and 1.3 part from the repository … Each is a cell the hand did not reach". No living file says it: Exhibit TWENTY-FOUR Geodesic Improving Method 4.1 has "A count carried past the motion that changed it is stale, and a carrying or a report carries one most easily." and no gathering computed. No later section has it (searched "hand table", "computed at the root", "eleven partings").
NEW: **Droplet · A gathering computed at the root, read by a fresh reader.** A gathering computed at the root and read by a fresh reader finds in an hour the things a table written by hand carried stale for five sessions: four cells of the Living File Registry's table and its 1.3, each a *standing* parting from the repository. A fresh reader read that gathering's report beside the files and the scripts' outputs ahead of its offering and found eleven partings, each mended at the report: among them a number of seventeen at `== 17` leaving out two files carrying eighteen names, about three hundred said at four hundred, and a sentence of the README said as the carrying's.

### 36
VERDICT: RESAY
CONCEPT: a number said with its script is a finding and a number said alone is a claim
EVIDENCE: In a session's words ("each number here", "Each number below", "this report"). No living file says it: Exhibit TWENTY-FOUR Geodesic Improving Method 4.1 has "A count carried with its rule is run again from the rule, and never taken from its carrying" and no script. No later section says it whole: this mate's "Droplet · A droplet's aiming at one of six degrees" (v386EOD) has "a number with its script" among a droplet's evidence, with no finding beside a claim. The insertlet of this mate at 4.1 is no later place. The scripts are beside the report at carryings/v381F/v381F/.
NEW: **Droplet · A number said with its script.** A number said with its script is a finding, and a number said alone is a claim. The saying is of a report with each of its numbers from a script beside the report, executed at the root: a reader executes the script again and sees the same.

## READING
Each of the thirty-six paragraphs was read and checked, one at a time, against the living file and the later sections.

Read whole: the brief with its further rules; the input file; Exhibit TWENTY-FOUR Geodesic Improving Method v380R; this mate's sections ahead of its Droplets (the v385A sections and the Insertlets) and each section after them headed v385A or v386EOD; this mate's older Droplets section itself, lines 99 to 272 in full and lines 273 to 382 at each paragraph's opening, for pointers at paragraphs 1 to 36; Possibling of and Carryings of Geodesic Improving Method; Possibling of Natural Arriving; Natural Arriving v381R; README.md and incoming/README.md; the two sources, carryings/v382F/Session_Report_v382F.md and carryings/v381F/v381F/Session_Report_v381F.md.

Read in part or by search: Natural Intelligence v380R (1.4, 3.3, 5.1, 6.5), Exhibit TWENTY-SIX Living File Registry v381R, Exhibit TWELVE Natural Explaining v378 (1.3), Exhibit TWENTY Natural Naming v380R (the rows of 2.4 the word paragraphs cite), Exhibit THIRTY Co-Chaining Logic Registry v380L (one sentence); the v385A and v386EOD sections of Offerings to Natural Arriving, Offerings to Natural Intelligence, Offerings to, Possibling of and Carryings of Living File Registry; index.html, .github/workflows/files.yml, the kit's REVIEWER.md, carryings/v381F/v381F/Next.md, carryings/v381R/README.md, carryings/v382F/Natural_Arriving_Explored.md and the archived front of Living Improving Value. Each quotation in a NEW paragraph and in EVIDENCE was searched exactly in the file it is given to. Each line the word paragraphs 16 to 26 cite was searched in the living file.

Pointers: carry/*.md was searched for "at this mate", "above", "the preceding", "existing concern" and for links and plain names of this mate. No paragraph points at paragraphs 1 to 36 by those words; the later concern of a working's name at more than one letter leans on paragraph 5's saying, and paragraph 33 points at paragraphs 28, 30 and 31 by their finding numbers.

Not found or not confirmed: what "four regions and a return" and "The later visual" of paragraph 15 name; five of the seventeen line numbers of paragraph 16, which have no *so* in the living file; the sections four word paragraphs name (20, 24, 25 and 26 name a section other than the one their line is in, the lines themselves exact). The sections headed v385A and v386EOD of mates other than those named above were reached by search alone, not read whole.

Paragraphs 4 and 6 are each a second time in this same older section (mate lines 243 and 245), and paragraphs 10, 12, 13 and 14 have copies in the older Droplets section of Offerings to Natural Arriving; none of these copies was counted as a later place.

No verdict is RESOLVED or NOVALUE: the living file is at v380R as each paragraph found it, and each paragraph carries a concept, a number or a possible work.
