### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: OK
WHY: laid beside the prior and its source (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md lines 459 to 469, note AA04, and lines 88 to 96, 1.2, read), NEW has each of the eleven things: the two files' sentences at their places, the six listed numbers' subjects, the numbers carried as numbers, the animation opening from the figure, the difference a finding about the motion and none about the drawing, and the next opening with its condition said as a relation ("at its being at hand"); both quotations of Exhibit_TWO_Natural_Networking_v371.md are exact at line 955 under "## 6.2" (lines 953 to 966), "only its sign crosses the file membrane" is exact at the living file's line 177 and "Field observing remains at the field face" at line 182, both under "## 1.2" (lines 168 to 185); "the instrument's numbers" for "returned numbers" is the source's own ("what an instrument returned from the image", "the rings the instrument returned"); 150 words; no pointer at it in the mate or carry/*.md (searched "AA04", "returned numbers", "nine circles").
SAFER: -

### 46
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 47
CHECK: OK
WHY: laid beside the prior and its source (carryings/v381F/v381F/Session_Report_v381F.md line 61, Finding 2, and carry/Session_Record.md line 2141 under "## The harm reading at the close, and its mend (v379)", read), NEW has the aiming at the one word, *still* within *is-still-possibling* alone as the Session Record's paragraph of v379 has it, the subtitle parting at the one word, and the one line at one file's own motion; the quotation "Still Accounting and Stable-Forming Co-Competency" is exact at the living file's line 9, so the concern is open still; the subject words *Still Accounting* are in the title, and no paragraph of the mate or carry/*.md points at it (searched "Still Accounting", "subtitle").
SAFER: -

### 48
CHECK: OK
WHY: laid beside the prior and its sources (Session_Report_v381F.md lines 87, 97, 175, 211, 213 and 234; Entry_Journey_For_An_AI.md lines 11 to 13 and 43; Next.md line 62, read), NEW has 0 and 32 (the living file has *so-far* at no line and *not-yet* 32 times now, measured), the ready saying with Natural Naming's row (at 2.4 now, line 252), the far side 5.4 with its title exact at Natural_Intelligence_v380R.md line 1085, sound, twenty files, loopings 4, and the retitling at Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md 4.7 (line 478, "The titles proposed are Ghost Observer Registry and Equilibria Representation Registry.") as a receiving not made; each word NEW has beside the prior ("at 2.4", "at Natural Intelligence", "read as", "its versions", session v381F's computing) is the source's own at those lines and no more; the words *Ghost Observer Registry*, "retitled" and "v381F" stay, so the pointer "Ghost mate's v381F retitling note" at incoming/v385A/Registry_Plan_Comparison_v385A.md line 29 still finds it.
SAFER: -

### 49
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 50
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 51
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 52
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 53
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 54
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 55
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 58
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 59
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 60
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 61
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the task; this brief (HARM3.md); the first reader's brief (BRIEFO3.md) with its Further rules; the PRIOR file GH_2.txt, each of its eighteen paragraphs; the PROPOSED file GH_2_report.md, each block and its READING.

The living file Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md is 37,208 words, over fifteen thousand, and was not read whole. Read at it: its front (lines 1 to 12, the subtitle at line 9), the headings of its parts and of Part One, and lines 177 and 182 under 1.2, each found by exact search; the hyphenated *so-far* and *not-yet* were measured (0 and 32), and the file's versions by the repository's history (four file names).

Other living files, at the places the three changed paragraphs name, each by exact search of the quoted words and by reading the headings round them: Exhibit_TWO_Natural_Networking_v371.md line 955 and the headings of Part Six; Exhibit_TWENTY_Natural_Naming_v380R.md lines 252 and 280 and the headings of Part Two; Natural_Intelligence_v380R.md lines 56 and 1085; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md lines 472 and 478.

Sources read: carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md at its headings, lines 84 to 100 (1.2) and lines 455 to 471 (the note AA04 whole); carryings/v381F/v381F/Session_Report_v381F.md at lines 23, 61, 87, 97, 175, 183, 211, 213 and 234; Entry_Journey_For_An_AI.md at lines 9 to 13, 43, 49 and 106; Next.md at line 62; carry/Session_Record.md at lines 2136 to 2143; incoming/v385A/Registry_Plan_Comparison_v385A.md at lines 29, 51 and 57.

Checked by search, for a pointer at each changed paragraph, over the mate carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md (its headings listed; each line with "at this mate", "preceding", "the concern above", "droplet above", "existing concern", "current droplet", "earlier pointer", "earlier plan", "older", "so-far", "far side", "loopings", "subtitle", "animation") and over carry/*.md ("AA04", "returned numbers", "nine circles", "Still Accounting", "is-still-possibling", "0 and 32", "far side", "Ghost Observer Registry", and each line naming the Living Ghost Registry or its offering mate beside those words). None found in carry/*.md. One found outside it: the comparison at incoming/v385A names "Ghost mate's v381F retitling note", which is paragraph 48; NEW has its words. Each NEW paragraph was measured (150, 60 and 106 words) and searched for the words the first reader's brief rules out; the ones found (*membrane* and *sign* at 45, *so-far* and *Observer* at 48) are within a living file's quotation or its own word in italics.

The fifteen KEEP blocks were not checked for harm, a kept paragraph being unchanged. Earlier second readings in the scratchpad (IL_1_harm.md, NW_2_harm.md, XP_1_harm.md) were looked at for how a re-said kit note and a re-said v381F paragraph were weighed; the checks here were made by reading and search of their own. No file but this report was written; no file in /home/claude/corus was changed; nothing was executed beyond searching, reading and measuring.

Not said as an objection, and for the one deciding:
- Paragraph 45: NEW names the kit, its version and its 3.2, and leaves out the note's own name, AA04, which the prior has at its opening and its close. 3.2 has some forty notes; AA04 is the heading of this one (the kit's line 459). The first reader's brief has a finding number as a session's word, and earlier second readings passed the same; the mate's own line 105 names other notes of the same kit by such names. Said as "at 3.2, AA04," it is one word more, 151.
- Paragraph 45: the file is said as "Natural Networking", with no "Exhibit TWO"; the first reader's rule asks whole names and gives "Natural Naming" as one, so it is passed.
- Paragraph 47: NEW closes "the Living Ghost Registry's", which the prior has not in those words; the source has "Each is one line at one file's own motion" of five subtitles at five files, and the prior's aiming names this file, so it is passed as the prior's own. The subtitle is also at Exhibit TWENTY-SIX Living File Registry's table (the first reader's EVIDENCE, line 95), a place neither the prior nor NEW names.
- Paragraph 48: the prior's list of report parts and finding numbers is left out of NEW, with "session v381F's computing" in its place; "read as sound" for "sound" is the source's own ("the session's reading of each row is beside it"), and "ready at it" gives the readiness the file as its place, the source having "at the carryings of … the Living Ghost Registry".
