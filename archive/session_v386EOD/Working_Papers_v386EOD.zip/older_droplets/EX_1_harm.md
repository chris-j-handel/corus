### 1
CHECK: OK
WHY: The quotation is an exact string of Natural Explaining 4.9 (line 378); "for both", the second saying, both alternatives and the reason found at the working v380A are each in NEW; the title carries the words the v386EOD droplet "4.9's carrying offered across, re-said" points with (mate line 352); *meeting* said as coupling is Natural Naming's own re-saying of the word (line 258).
SAFER: -

### 2
CHECK: OK
WHY: 2.2 "A length is a tell and never the binary" (line 126), 3.8 "This tell arrives at a telling's close" (252), 4.7 "An unrelationing shows at its tell" (362) and 4.9 "*Tell*, said as a demand" (374) read at the living file; the three places, the third use, both alternatives and "at a naming pass" are in NEW; the title carries "the *tell* collision", the words of the mate's front paragraph (line 7).
SAFER: -

### 3
CHECK: OK
WHY: The quotation is an exact string of 4.2 (line 320); "for both", the place 4.2, the four named, the paragraph's own reading "all or none at its step" (the same sentence was at 4.2 at version 371, so the reading was always the paragraph's) and both readings are in NEW; no paragraph of carry/*.md points at it.
SAFER: -

### 4
CHECK: OK
WHY: Natural_Intelligence_Corus_v330.md still has "# Part 16: Natural Writing" (line 183) and "### Two One-Way Languages" under 16.3 (586); the number 13,450, the remainder, 16.3 and the wait as a relation to Corus's rebuild are in NEW; the title carries "Part 16 receiving plan", the words of the mate's front paragraph (line 5) and of carry/Carryings_of_Natural_Intelligence_Corus.md lines 70 and 79.
SAFER: -

### 5
CHECK: OK
WHY: Each destination is in NEW; 8.6 to 5.4 is right, archive/resolver_v372_proposal/Natural_Intelligence_v372.md line 1377 "8.6 Two methods parting at the precise place" being Natural_Intelligence_v380R.md line 1085 "5.4 Two methods parting at the now"; the one sentence left out, of 8.7's sentence paragraph, concerns a thing wholly gone (Natural Intelligence v380R has six parts, no 8.7, and "sentence" at line 77 alone), and the v372 paragraph (line 1391) read beside Natural Explaining 2.1 and 3.1 is said there.
SAFER: -

### 6
CHECK: OK
WHY: Both EVIDENCE rows found by exact search at Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1 lines 82 and 83, 1.5 lines 203 and 205); the paragraph is a pointer at 1.5 and its quotation the session report's compression of those rows (Session_Report_v378.md line 21), which were word for word the same at version 378 (git e96a5e0); the Registry names Natural Explaining for Natural Emanating (1.5, 5.7 line 541, 5.8 line 560) and Corus and Natural Naming for Natural Destinies (5.11 line 616), and Natural Explaining for Natural Destinies at no row, then as now; no paragraph points at this one, the three other mates carrying copies and not pointers.
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: OK
WHY: Natural Naming 2.4's rows for *every*, *sign*, *run*, *so* and *since* (lines 241, 255, 270, 273) and its sentence at 299, Natural Explaining 1.6's title, the Geodesic Improving Method 2.9 line 218 "by arithmetic", and REVIEWER.md line 56 read; each file, version, place and the closing claim of the session and `reader_checks.py` are in NEW, each quotation exact.
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: OK
WHY: Natural Explaining 3.10 (line 270), Natural Naming 2.4's row (line 280) and the Geodesic Improving Method line 170 read, the last under "## 2.5 The hardest first" (line 168), so 2.3 to 2.5 is the number now; the aiming, the three sayings, both alternatives and the reason "one compound alone" are in NEW, each quotation exact.
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: OK
WHY: As at 5: the same paragraph but for a re-aiming note that has no concept in it, each destination of the plan being named in NEW; 8.6 to 5.4 and the gone 8.7 read as at 5.
SAFER: -

### 14
CHECK: OK
WHY: As at 5: the same paragraph but for a re-aiming note that has no concept in it; 8.6 to 5.4 and the gone 8.7 read as at 5.
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: OK
WHY: Natural Explaining line 156 and Natural Naming's row at line 258 read, both quotations exact, the row being the very sentence the paragraph names; the source carryings/v383Op/Presentation.md line 38 has no more than NEW; the aiming, Natural Intelligence throughout, "a number is a coordinate" and the two living files are in NEW.
SAFER: -

### 17
CHECK: OK
WHY: Natural Explaining line 230 and Natural_Intelligence_v380R.md line 83 "## 1.2 Changing, one and then the other" read, both quotations exact; the aiming at the word, the place 1.2 and the parting are in NEW and nothing is added beside carryings/v383Op/Presentation.md line 40.
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: OK
WHY: As at 5: the same paragraph but for a re-aiming note that has no concept in it; 8.6 to 5.4 and the gone 8.7 read as at 5.
SAFER: -

### 20
CHECK: OK
WHY: Each EVIDENCE sentence found by exact search at Natural Explaining (2.1 lines 112 and 114, 3.1 lines 172 and 174); the v372 sentence paragraph (archive/resolver_v372_proposal/Natural_Intelligence_v372.md line 1391) read beside them is said there, and Natural_Intelligence_v380R.md has no 8.7 and no paragraph of a sentence; no paragraph points at this one, carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md line 21 and carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md line 267 being other rows of the same source and not pointers.
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file; the PROPOSED file; the living file Exhibit_TWELVE_Natural_Explaining_v378.md (7,155 words). Of the mate carry/Exhibit_TWELVE_Offerings_to_Natural_Explaining.md: its front (lines 1 to 8), its older Droplets section (69 to 124) and each section headed v386EOD (348 to 392), with its headings listed; its Insertlets and its v385A sections were checked by search and not read whole.

Read in part, at the passages found: Natural_Intelligence_v380R.md (each heading, 5.4, 1.2's title, each line with "sentence"); archive/resolver_v372_proposal/Natural_Intelligence_v372.md (8.5's close, 8.6 and 8.7 whole); Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1's two rows, 1.5, 5.7's rows, 5.8, 5.11 whole) and the same rows at version 378 by git; Exhibit_TWENTY_Natural_Naming_v380R.md (2.4's rows for *every*, *sign*, *met*, *membrane*, *run*, *so* and *since*, *stilling*, and line 299); Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md (Part TWO's headings, lines 170 and 218); Natural_Intelligence_Corus_v330.md (Part 16's headings and 16.3's two one-way languages); carryings/resettling_v373/Re-Settling_the_Living_Files.md (lines 130, 166, 173) and Natural_Intelligence_Map.md (150, 151, 173); carryings/session_v378/Session_Report_v378.md (line 21); carryings/v381F/README.md (line 53); carryings/v383Op/Presentation.md (34 to 44); carryings/v380R/Natural_Networking_From_v380A.md (8, 45 to 47); archive/carrying_v381R/Exhibit_TWELVE_Natural_Explaining_v380R.md (17, 25, 28 to 36); kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/REVIEWER.md (line 56); carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md (870 to 892), which records the same pass G paragraph as released at the Natural Naming mate with the same evidence.

Checked by search: each of the twelve distinct quotations in the NEW paragraphs, exactly, in the living files at the root (each found in the file NEW names); carry/*.md for pointers at paragraphs 6 and 20 ("pass G", "Destinies and Emanating", "method at a sentence") and for the subject words of 1, 2, 3, 4, 8, 10, 16 and 17; "all or none at its step" across the repository; the number of words of each NEW (52 to 151; paragraph 8's is at the upper bound) and each NEW's own sentences for the words the first brief sets aside (none found).

Seen and not objected to. At 1, the closing sentence names the working v380A as the place the concern was found; it is the prior's own stated reason and is said as a fact of that working. At 3, "all or none at its step" follows the exact quotation without quotation marks, as the paragraph's reading; 4.2 itself has "a direction taken at its own opening, a sign and no size". At 5, 13, 14 and 19, one NEW is given four times; laid once it loses nothing, the three re-aiming notes having no concept in them. At 6, the session report's sentence joins Natural Destinies with Natural Explaining, a pairing the Registry has at no row, at version 378 or now; the paragraph gives it as the Registry's own 1.5, and 1.5 is whole at the living file.

The thirteen paragraphs with the verdict KEEP were not checked further, a paragraph left as it is losing nothing.
