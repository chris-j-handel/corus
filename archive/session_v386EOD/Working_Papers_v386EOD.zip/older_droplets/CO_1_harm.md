### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: OK
WHY: laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md line 71 with its column heads at line 38: 62,100 words, version 330, worst shaped with its three things, the marker at line 778, older than the old code, about 15%, about 35% and the older vocabulary throughout are each in NEW at the same strength, with no quotation and nothing beside them; the living file is at version 330 still with the marker at its line 778; no paragraph of carry/*.md points at this one (searched "62,100", "about 15%", "worst shaped").
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 165 (table "Corus now | Proposed home", "Stays; re-said in current words"): Part One, the offering, the six *doors*, the staying and the re-saying in current words are each in NEW at the strength of a proposal; the living file has "# PART ONE — THE OFFERING" (line 57), "## The offering" (line 67) and "## Six doors — each opens one reading" (line 103) still; the mate's later paragraph "Part ONE's receiving is Natural Arriving" (line 107) is another proposal and names no paragraph; no pointer found (searched "re-said in current words", "Corus table").
SAFER: -

### 19
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 166: Part 16, Natural Writing, about 13,450 words, Natural Explaining with "much already re-said", 16.2's pronouns and contested concepts at Natural Naming and 16.3's two one-way languages at Natural Explaining are each in NEW with the same section numbers; the places are at the living file now (lines 183, 468, 524, 534, 564, 586); the "existing bulk route" that Carryings of Natural Intelligence Corus line 89 names is at Natural Naming's mate, and no paragraph points at this one.
SAFER: -

### 20
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 168: Part 17, its three subjects, the Living Ghost Registry, the hard-problem registries un-narrowed, 17.4 and the combined Exploring are each in NEW as a proposal; the living file has "# Part 17" at line 1635 and "## 17.4" at line 1840 still; NEW is, but for the session tag, the paragraph at carry/Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.md line 51 (compared by script); no pointer found (searched "control ghost").
SAFER: -

### 21
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 171: the 54 bracketed continuing items, the *v314* routing notes, the writer catches, the carrying for a value and the archive for a record are each in NEW as a proposal, no number added; the living file has the items still ("continuing nye" at 54 lines), the *v314* notes (nine lines, the first at 185) and the catches (line 353); the other places of "bracketed" in carry/*.md (Carryings of Natural Intelligence Corus lines 52 and 156) are of other things, and no paragraph points at this one.
SAFER: -

### 22
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 173: the craft at four parts, Corus Part 16's remainder, 1.6 and 4.1, 4.2's paragraph, 4.5's surgical method, 4.6's resolver case and each receiving file are in NEW; each place is at Exhibit_TWELVE_Natural_Explaining_v378.md now (headings at lines 100, 300, 310, 338, 346; the three paragraphs at lines 320, 344, 352; four parts); the one number changed, Natural Intelligence 8.6 to 5.4, is at carryings/resettling_v373/Natural_Intelligence_v373_Released.md line 787 ("*Receiving: Re-said at 5.4.*") and Natural_Intelligence_v380R.md line 1085; the sentence left out is resolved: the earlier 8.7's sentence paragraph (v373_Released lines 797 to 803) is at no line of Natural Intelligence now (searched "a sentence", "inside the last") and Natural Explaining 2.1 says it (lines 110 to 112).
SAFER: -

### 23
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md lines 225 and 226: the two places of currency, the seven places of abundancing and the *discovery economy*, and the one home of each at Natural Values are in NEW, no quotation; the sections are at Natural Human Society lines 167 and 243, Natural Values lines 73 and 157, Natural Exploring line 425 and the living file's lines 1043, 1466, 2228 and 2482; paragraph 4's "the older proposal to receive value at Values" still finds it by the subject words in the title.
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 269: the marker at line 778, Parts TWO and FOUR announced empty and each of the five references are in NEW in the prior's own words and italics, no repair and no reading added; each is at the living file now by exact search (line 778; line 45; "Part 2.8.5" at 1152 and 2422; "sections 20.1, 20.3, 20.4, 20.5" at 1420; "Part 20.3" at 2562; "corus line 1321" at 2402 and 2418; "line 3373" at 2455); no paragraph points at it (searched "Defect", "INSEPARATOR", "line 778", "2.8.5" in the mates of this file and of the Living File Registry).
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 has the ten files at their four versions and "Forty-five to forty-nine versions behind the apex, each at the old seventeen names, the old code's means and words since released", and its line 15 the apex at v377 to v378; the ten files are at those versions at the root now (file names read); each is in NEW, the number said as of session v378's apex, with no quotation; "words since released" is read as the third of three things and said as "words released after it", the reading the same paragraph has at carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md line 35.
SAFER: -

### 32
CHECK: OK
WHY: the four rows of the EVIDENCE are exact at Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1 lines 82 and 83, each "pass G"; 1.5 lines 203 and 205), and 5.8 (line 560) and 5.11 (lines 607 to 620) were read: Corus as the receiving of each file is at the living file, Natural Naming for each (the row of 1.5; 5.11's "Natural Intelligence and Naming for common explaining"), Natural Explaining for Natural Emanating; the prior is a pointer at 1.5 and its quotation the session report's compression of it (Session_Report_v378.md line 21); the other places of the sentence in carry/*.md are copies and the records of its release at two other mates, none a pointer.
SAFER: -

### 33
CHECK: OK
WHY: the root has no file of version 368, no Natural_Intelligence_v345a.md and no Equilibria Definitions (listing read), and files.json line 33 lists Natural_Intelligence_Corus_v330.md; the three quotations of the Living File Registry are exact (lines 99, 102 and 198), and the one deciding the prior leaves, this file carried on or archived, is said by them; the later question of one file or two with Natural Arriving is another paragraph's (mate line 109) and names no paragraph; no pointer found (searched "keep or archive", "second Natural Intelligence file").
SAFER: -

### 34
CHECK: OBJECT
WHY: Added: the sentence "It is beside Natural Naming's … its rows of released words for *turn*, for *held* and *holding* and for *stable form* as a noun, and *read* at its family of three." The prior, and its source carryings/v368_sources/Wrap_v368.md line 73, name no file and no row; the sentence is the first reader's finding at Exhibit_TWENTY_Natural_Naming_v380R.md (line 297, the rows at lines 232, 238 and 239, the row of *reading* at line 223), each true and the quotation exact, and by the first reader's rule 11 a thing found at a living file that the paragraph does not have stays out of NEW; the rows and the family of three are no quotation of a sentence the paragraph is about. Nothing of the prior is lost: NEW's first sentence is the prior word for word. The same NEW was passed at Offerings to Natural Networking (line 137); the plain form below was passed at Offerings to Natural Societies (line 51) and at the Equilibria Registry's portion, and it is given here word for word.
SAFER: **Droplet · Across the set, what each file releases at its own improving.** Across the set, each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words. It is aimed at the set.

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: OBJECT
WHY: A work is in it, at no living file and no later section. "Next: improving relative to Exhibit ONE, from its section" names a work for this file: by the source (carryings/v368_sources/Carry_Set_v368_README.md lines 148, 154 and 188) "its section" is the file's own section of Living Improving Value at version 368, a finding "a note in the carry aimed at the file", and the nine are named at carryings/v368_sources/Living_Improving_Value_v368.md line 1639 (J05, J07, XX01, XX02, XX05, YY02, ZZ04, ZZ06, ZZ07). The file is at version 330 still, so the improving is not made. "relative to Exhibit ONE" is at this paragraph alone at this file's three mates, and at no line of the Living File Registry or the Geodesic Improving Method (searched); the mate's own "Next at this file" (line 21) and the Registry's row (line 99, "pass G") name another next. The number alone is bookkeeping, as the first reader says, and the bundle's value for this file is at the mate's "A speaker at two paragraphs, and all that is · v386EOD" (read); the clause of work is what would be lost. The like row was passed as released at Natural Exploring's portion and objected to at the Geodesic Improving Method's; no paragraph points at this one.
SAFER: KEEP

### 37
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 38
CHECK: OBJECT
WHY: Two paragraphs point at it. carry/Carryings_of_Natural_Intelligence_Corus.md line 77, under "## Corus arriving and distribution: passage comparison · v385A", "### Part 16.1: writing value beside its current subjects", has in its row of **Multiple Paintings; Appearing-in-Nature Pattern** "Corus's existing v366 illustrating droplet" and "The Corus mate already names this source"; carry/Exhibit_TWENTY-NINE_Carryings_of_Natural_Illustrating.md line 23, under "## Further Natural Writing value aimed · v385A", has "The Corus offering already names this source through v366". This paragraph is that droplet: it is the one paragraph of this mate, tagged illustrating_v366, that names Corus 16.1's "Multiple Paintings of the Same Form" (paragraph 37, of the same tag, names no section of Corus). Released, both pointers find nothing at this mate; the mate's later "Several expressions of the form and each distinct contribution · v385A" (line 472) is of v385A and is the further droplet those rows name beside this one. The rest of the EVIDENCE is sound: the sentence of Natural Illustrating 4.5 (line 348), the twelve rows of its 8.2 (lines 567 to 578), the Registry's 5.8 (line 558) and Natural Transmissioning 3.8 and 4.6 (lines 187 and 218) are each exact. The first reader's search was by the paragraph's own words ("plaza was recovered", "source-based opportunities", "numerical straddling") and not by "v366" or "Multiple Paintings".
SAFER: KEEP

### 39
CHECK: OK
WHY: the second copy of 21, the same but for the label, and NEW is 21's; the label is no aiming of this paragraph: the commit that laid it (git 106abbb) added the same label, word for word, to each of the thirty-six droplets re-aimed in that working whatever its file, and the working's record, carryings/geodesic_improving_method_v381R_proposed/Resolving_of_174_droplets.md line 277, has this droplet as "for Natural Intelligence Corus", its droplets "for the reviewer's brief" being other ones; the paragraph lies at the mate of the file it is for, and nothing of 21's content is lost.
SAFER: -

## READING
Thirty-nine blocks: 12 OK, 3 OBJECT (34, 36, 38), 24 KEEP-UNCHANGED. No file in /home/claude/corus was edited; nothing was executed but reads, searches, two readings of the repository's history (the commit that laid the re-aiming label) and two small scripts in the scratchpad, one comparing NEW paragraphs with paragraphs at other mates and one measuring each NEW against the first reader's forty to one hundred and fifty words and its list of words (each within the length, none of the listed words in the first reader's own sentences).

Read whole: HARM3.md; BRIEFO3.md with its "Further rules"; TASK_second.md; the PRIOR file CO_1.txt; the PROPOSED file CO_1_report.md with its READING.

The living file Natural_Intelligence_Corus_v330.md is 61,779 words, over the 60,000 of the task, and was not read whole. Read at it: line 45 (the two parts announced empty), line 778, and each heading and line a paragraph names, found by exact search (lines 57, 67, 103, 183, 185, 193, 353, 452, 468, 524, 534, 564, 586, 1043, 1152, 1420, 1466, 1635, 1840, 2228, 2402, 2418, 2422, 2455, 2482, 2562), with the numbers of lines having "continuing nye" and "v314".

Read at other living files: Exhibit TWENTY-SIX Living File Registry v381R, its headings, 1.1 at lines 82, 83, 99 and 102, 1.5 whole (lines 196 to 207), 5.8 (lines 554 to 560) and 5.11 whole (lines 605 to 622); Exhibit TWELVE Natural Explaining v378, its headings, 2.1 and the three paragraphs of 4.2, 4.5 and 4.6; Natural Intelligence v380R, its part headings and 5.4 whole; Exhibit TWENTY-NINE Natural Illustrating v379, its part headings, the sentence of 4.5 and 8.2 whole (lines 561 to 582); Exhibit TWENTY Natural Naming v380R at lines 213 to 239 and 297; the headings named at Natural Human Society, Natural Values, Natural Exploring and Natural Transmissioning; files.json and the root's listing.

Read at the mates: Offerings to Natural Intelligence Corus, its headings, its front (lines 1 to 22), the opening of each paragraph of its older section (lines 27 to 140), lines 107 to 113, 472 to 479 and 702 to 708; Carryings of Natural Intelligence Corus at lines 52, 60 to 64, 77, 79, 89, 90, 156, 189 and 209 to 219; Carryings of Natural Illustrating line 23 and Possibling of Natural Illustrating line 17; Offerings to Natural Societies line 51; Possibling of Living File Registry line 385.

Read at the sources: carryings/resettling_v373/Re-Settling_the_Living_Files.md at lines 38, 71, 160 to 173, 225, 226 and 262 to 270; carryings/resettling_v373/Natural_Intelligence_v373_Released.md at lines 785 to 806; carryings/session_v378/Session_Report_v378.md lines 13 to 23; carryings/v368_sources/Carry_Set_v368_README.md lines 148 to 160 and 186 to 192; carryings/v368_sources/Living_Improving_Value_v368.md at its table by file (lines 1630 to 1642) and the lines naming this file; carryings/illustrating_v366/Session_Report_v366.md lines 112 to 121; carryings/geodesic_improving_method_v381R_proposed/Resolving_of_174_droplets.md, its opening and lines 250 to 315.

Checked by exact search: each EVIDENCE sentence and row of the three RESOLVED blocks in the living file it names (ten strings of the Living File Registry, thirteen of Natural Illustrating, two of Natural Transmissioning); the one quotation in a NEW (34, Natural Naming line 297); each defect of 27 in the living file. By script: the NEW of 20, 22, 23, 31 and 34 beside the paragraphs at other mates the first reader names (each the same but for the session tag).

Pointers: carry/*.md was searched for each paragraph with a verdict other than KEEP, by its subject words and by "Corus's existing", "Corus mate already", "Corus offering already", "droplet at Corus", "concern at Corus", "Corus table", "v366", "v373 concern" and the like, and by links to this mate. One pair was found, at 38. The sentences found for kept paragraphs (Carryings of Natural Intelligence Corus line 189 at paragraphs 1 and 3, line 90 and line 167 at paragraph 7, and "already a v373 concern" at paragraph 24) agree with the first reader's KEEP.

The earlier readings of the same sentences at other portions were read after my own (XP_1 blocks 4, 6, 7, 12, 14, 16 and 17; EX_1 block 6; NW_1 block 24; NN_2 blocks 49 and 62; EQ_4b blocks 135 and 139; PH_6b blocks 213 and 214; HP_1 block 8; GM_2 block 49). Two of my objections part from one of them and agree with another: at 34 the NEW was passed at Natural Networking's portion and the plain form at the Equilibria Registry's; at 36 the like row was passed as released at Natural Exploring's portion and objected to at the Geodesic Improving Method's.

Not settled here: the twenty-four blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. The label of 39 is on four other paragraphs in carry/*.md now, and at one of them (the Natural Physics portion PH_7, paragraph at its line 15) a first reader carried "It is for the reviewer's brief at the kit" into NEW as an aiming; by the commit and the record read for 39 it is the same blanket label there, which is for whoever checks that portion. The number 54 of 21 and 39 and the 62,100 words of 10 are carried as the paragraphs have them (the living file is 61,779 words by a plain measure).
