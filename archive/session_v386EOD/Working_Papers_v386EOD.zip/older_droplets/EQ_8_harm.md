### 237
CHECK: OK
WHY: the living file's 2.2 (line 138) has the saying of the man and the river word for word, "As suggested, at each observing a momentary stable form and at the next a different carrying", the two observing sentences at the Co-Chaining Logic Registry steps 135 and 136 and the stable form beside step 390, and "each read, as suggested, as stable forming"; 4.2 item 1 (line 253) has "the row's own column, *the changing it names*, is carried beside it as it stood, its *that can change* said at 2.2 as stable forming"; each found by exact search. The prior's steps 125, 126 and 284 are the same three sentences at the Registry's numbering at v377 (read at the history of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v376.md, commit 3673fbb, lines 618, 622 and 1326), now 135, 136 and 390 at Exhibit THIRTY Co-Chaining Logic Registry v380L (lines 648, 652, 1736). *can change* is at the living file eighteen times, seventeen in the column *The changing it names* and once at 4.2's own sentence, as the prior says. No paragraph of the mate or of carry/*.md points at this one: the mate's line 61 is another paragraph of the same subject with its own content, line 279 is a copy in another portion, and carry/Session_Record.md line 2012 is a record; the paragraphs beside it (236, 238) lay no condition on it and it lays none on them.
SAFER: -

### 238
CHECK: OK
WHY: carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md, under the heading "## The surfacing faces and their local four-cycling · v385A" (lines 205 to 207), has the paragraph word for word, with "open", both sentences and "Missing: where each surfacing face sits on the loops, chained locally.", lacking only the re-aiming note, which is a session's bookkeeping; the heading is a later section and no older section named Droplets. The pointers found go to that later section and not to this paragraph: the mate's line 295 and Offerings to Co-Chaining Logic Registry line 207 are links to the Natural Resolver heading, and Carryings of Living File Registry line 539 has "whole once" at Offerings to Natural Resolver. The paragraphs beside it (237, 239) lay no condition on it and it lays none on them.
SAFER: -

### 239
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 240
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 241
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 242
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 243
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 244
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 245
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 246
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 247
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 248
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 249
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 250
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 251
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 252
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 253
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 254
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 255
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 256
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 257
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 258
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_8.txt (paragraphs 237 to 258); the PROPOSED file EQ_8_report.md; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (541 lines, 12,261 words); the mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md at its front, its Insertlets and the opening of its older Droplets section (lines 1 to 62), and at lines 291 to 297 and 521 to 531, the paragraphs beside the two released; carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md at lines 199 to 211, with its list of headings.

Checked by search: the three EVIDENCE sentences of paragraph 237 at the living file, each by exact search, one match each; each place of *can change* at the living file (eighteen: line 253 and seventeen rows of the column); the three sentences at Exhibit THIRTY Co-Chaining Logic Registry v380L (steps 135, 136, 390); the older numbering 125, 126 and 284 at the history of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v376.md (read with git show, nothing changed) and at carryings/session_v377/Session_Report_v377.md lines 34, 99 and 191; the mate and each of carry/*.md for the subject words of 237 (the man and the river, "Stable forming, at 2.2", steps 125 and 284) and of 238 (the surfacing faces' loops, the surfacing faces and their local four-cycling, where each surfacing face sits), with the heading each match lies under.

The twenty blocks the first reader gave KEEP (239 to 258) change nothing and were not checked further, as the brief says. Two notes for the one laying portions together: paragraph 237 has a copy earlier in the same older section (file line 279) and paragraph 238's subject has a direction at file line 295, both in other portions; the release of 237 rests on the living file alone and the release of 238 on the later section at Offerings to Natural Resolver, so neither depends on what is decided of those.
