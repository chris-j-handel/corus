### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: OK
WHY: Laid beside the prior and its source, archive/session_v379_exhibit_one_first/Session_Transcript_v379.md lines 798 to 807 and 838 and Session_Report_v379.md line 74: the offered sentence is in NEW word for word, with 3 and 5, thirteen, momentary 13 and "no gate over the crossing"; the aiming is the living heading "## 3.8 Social membrane, the plaza, sign between" (line 187, exact); the likeness to the crowded plaza and the two executings are said as facts of session v379 and no more; no paragraph of carry/*.md points at it (searched "plaza at the code", "plaza").
SAFER: -

### 3
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 46 read, "| SIX · Natural Transmissioning | 5,200 | v330 | Coherent, written to an older set | about 40% | about 30% | about 12% |"; each of the five things is in NEW at the prior's own words, the file is at v330 and 5,193 words now, nothing is added, and nothing in carry/*.md points at it (searched "about 40%", "written to an older set").
SAFER: -

### 4
CHECK: OK
WHY: The source line 191 of Re-Settling_the_Living_Files.md read beside NEW: each place (1.3, 2.4 to 2.5, 3.1 to 3.7, 3.8's plaza, 3.8's conversation, 4.3, 4.4, 4.6, each a section of the living file still), each receiving file, the one change with both its reasons, "about 12%" and the two things re-said are in NEW; the pointer at carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md line 383 ("An earlier plan at Offerings to Natural Transmissioning has that comparing at Exhibit FIVE Natural Engineering, one form at many materials") still finds it.
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: OK
WHY: Each of its three partings read at its place now: Natural_Intelligence_v380R.md has no 6.7 and "ambient" at no line; local and ambient at unrelationing are at Exhibit TWENTY Natural Naming 5.41 (line 1278, the EVIDENCE sentence exact) and Exhibit THREE Natural Numbers 3.3 (line 199, "local and ambient alike"); φ as the rate is at Exhibit FOUR Natural Mathematics 2.8 (line 179, exact); and the one part at no living file, *the ambient is the transmissioning* for Natural Transmissioning, is at this mate's "## The ambient is the transmissioning, no medium; A rate ridden within and a rate gone at · v386EOD" (mate lines 181 to 187, read), a later section from the same map and released file; no paragraph points at it (searched "ambient", "6.7").
SAFER: -

### 8
CHECK: OK
WHY: The place named was opened and read, mate lines 181 to 185: a section headed v386EOD, lying at Offerings to Natural Transmissioning, its opening saying each is from "the resettling of version 373, its released Natural Intelligence, its map", and its droplet opening "The ambient is the transmissioning."; receiver, giver and the thing received are each there, and no paragraph points at this one.
SAFER: -

### 9
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 read with its line 15 (the apex at v377 to v378): the ten files at their four versions (each at that version at the root now), the old seventeen names, the old code's means, the words released later and forty-five to forty-nine are each in NEW, the number said as of session v378's apex; NEW has no quotation and is word for word the paragraph at carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md line 35.
SAFER: -

### 10
CHECK: OK
WHY: Each EVIDENCE row found by exact search at Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md: 1.1 line 74 "pass G, its receiving", 1.5 line 202 "Complete receiving through the common method, Networking, Engineering and the sciences; keep the cross-substrate comparison connected", and 5.12 "The receiving is planned; no source removal has occurred."; the session report's "into Natural Networking and the method" is within the 1.5 row; no paragraph points at it (searched "pass G", "Transmissioning is at pass G").
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OBJECT
WHY: Lost, changed and added, laid beside the prior and its source (carryings/v368_sources/Carry_Set_v368_README.md line 32, place 6, under the column "What it releases" of line 25, and line 57). (1) Added beside the prior, against rule 11: "Natural Naming parts these at "Four pairs are two concepts at two names, the meaning changing on transposing"" and "the eight bi-couplings", both from Exhibit_TWENTY_Natural_Naming_v380R.md lines 586 to 591 (the quotation is exact); the prior has neither. (2) Narrowed: the prior has seven namings open for both to agree; NEW's "Open are" has three, and says four are parted. For "three sets of four boundings" the living pair is the eight bi-couplings beside the four boundings of a naming, two sets, where the source has "three sets of four stand across the set, each wanting one name at one thing". (3) Lost: "closing". The prior has "It releases the single naming closing at all or none at all"; NEW has "gives the single naming, at all or none at all". (4) Changed: "The ten is settled at v368" is "The ten were agreed at version 368"; *settled* is no word set aside. The same words are at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 187, passed there before rule 11; a second reader of the Equilibria Registry's copy objected to them for these same things, and the SAFER below is that reader's paragraph word for word, checked here against the prior: its seven as they are, the ten settled, "closing" whole, nothing from Natural Naming.
SAFER: **Droplet · The namings open for both to agree.** The namings open for both to agree are these: bi-co-podaling or transmissioning, which names a file's title too; three sets of four boundings; two fives under one word; floating neutral or floating neutralling; the tangential changing at the co-sequential nine; the centre at the local face and the station at its two *turns*; and the version 368 carry set's own name. The ten is settled at version 368: the ten ways, each named. The settling of these namings releases the single naming closing at all or none at all.

### 13
CHECK: OK
WHY: Exhibit_TWENTY_Natural_Naming_v380R.md 4.6 read, lines 586 to 588: the EVIDENCE sentence is exact, under "Four pairs are two concepts at two names, the meaning changing on transposing:", so the naming open between the two is decided as two concepts at two names, and its reason is there at "a file's title carrying it"; no paragraph points at it (searched "Held at Natural Naming", "five namings held").
SAFER: -

### 14
CHECK: OBJECT
WHY: A work is in it. "11 findings and 4 discoveries waiting" is a number with no finding in it, as the first reader says (carryings/v368_sources/Carry_Set_v368_README.md line 164). "Next: improving relative to Exhibit ONE, from its section" names a work for this file: the file is at v330 still, and by search "relative to Exhibit ONE" is at no living file and at no later section, in this mate or another (it is at the like rows of the other mates' older sections alone). The living file's next for it now is another work, Exhibit TWENTY-SIX Living File Registry 1.1 line 74, "pass G, its receiving", and this mate's front has "**Next at this file:** No sentence of the code."; neither says improving relative to Exhibit ONE. The like row was released at Offerings to Natural Exploring and objected to at the Geodesic Improving Method's mate; the first readers of six other mates left it as it is. No paragraph points at it.
SAFER: KEEP

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: OK
WHY: Each EVIDENCE sentence and row found by exact search at Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md: 4.5 line 348 has the plaza of Natural Transmissioning 3.8 and "its 4.6 corrects the wall to the passing-through"; 8.2 lines 567 to 578 have the several paintings and the floating, rotating, self-adapting sphere at Natural Intelligence Corus 16.1, and one row for each of the ten further places; the three places named are at their files still (Natural Transmissioning lines 187 and 218, Corus line 452); no paragraph points at it.
SAFER: -

### 29
CHECK: OK
WHY: carryings/illustrating_v366/Session_Report_v366.md line 165 read, under "## 8. Receiving next": both receiving files, "actual", stitching, passing and returning, and "proposed" are each in NEW, with the receiving said as the next one named and as work that may change; nothing of a living file is added, NEW has no quotation, and *returning* is Exhibit FIVE Natural Engineering's own word at its line 614.
SAFER: -

### 30
CHECK: OK
WHY: As at 10: the same paragraph but for a re-aiming note with no concept in it; the three rows read at the Living File Registry, lines 74, 202 and 5.12.
SAFER: -

### 31
CHECK: OK
WHY: As at 8: the same paragraph but for a re-aiming note with no concept in it; the v386EOD section read at mate lines 181 to 185.
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Forty blocks: 12 OK (2, 3, 4, 7, 8, 9, 10, 13, 28, 29, 30, 31), 2 OBJECT (12, 14), 26 KEEP-UNCHANGED. No file in /home/claude/corus was edited; nothing was executed but reads, searches and one script over the PROPOSED file, for the number of words of each NEW and its own sentences against the first brief's list of words.

Read whole: HARM3.md; BRIEFO3.md with its "Further rules"; TASK_second.md; TR_1.txt; TR_1_report.md with its READING; the living file Exhibit_SIX_Natural_Transmissioning_v330.md (5,193 words, lines 1 to 222); the mate carry/Exhibit_SIX_Offerings_to_Natural_Transmissioning.md (lines 1 to 193, its front, its older "## Droplets" and each section headed v385A and v386EOD); carry/Exhibit_SIX_Possibling_of_Natural_Transmissioning.md.

Read at the places the paragraphs name: Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1's table at lines 60 to 102, line 74; 1.5, lines 196 to 206; 5.12, lines 623 to 640); Exhibit_TWENTY_Natural_Naming_v380R.md (4.6 whole, lines 576 to 591; 5.41 at line 1278); Exhibit_FOUR_Natural_Mathematics_v380L.md (2.8, lines 177 to 179); Exhibit_THREE_Natural_Numbers_v380L.md (3.3, line 199); Natural_Intelligence_v380R.md (Part SIX's headings, and each line with "ambient", none); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md (4.5 line 348, 8.2 lines 561 to 578); Exhibit_FIVE_Natural_Engineering_v345a.md (line 614); Natural_Intelligence_Corus_v330.md (line 452, by search; the file is over 60,000 words and was not read whole). Sources: carryings/resettling_v373/Re-Settling_the_Living_Files.md (lines 40 to 47, 185 to 195, 255 to 262), Natural_Intelligence_Map.md (lines 1 to 30, 112 to 126, 160 to 172) and Natural_Intelligence_v373_Released.md (6.7, lines 544 to 552); carryings/session_v378/Session_Report_v378.md (lines 13 to 23); carryings/v368_sources/Carry_Set_v368_README.md (lines 26 to 34, 49 to 58, 148 to 166); carryings/illustrating_v366/Session_Report_v366.md (lines 158 to 168); archive/session_v379_exhibit_one_first/Session_Transcript_v379.md (lines 794 to 812, 834 to 840, and each line with "plaza") and Session_Report_v379.md (lines 72 to 76). Other mates at the lines found: Offerings to Living File Registry (lines 119 and 383), Carryings of Living File Registry (lines 586 to 600, 940 to 960), Possibling of Living File Registry (line 319), Offerings to Natural Naming (line 187), Offerings to Natural Exploring (line 35).

Checked by search: each EVIDENCE sentence of 7, 10, 13, 28 and 30, exactly, at the living file named; the quotation in the NEW of 2 (Natural Transmissioning line 187) and of 12 (Natural Naming line 586); carry/*.md for pointers at each released paragraph ("ambient", "6.7", "pass G", "Held at Natural Naming", "discoveries waiting", "plaza was recovered", "source-based opportunities", "about 40%", "plaza at the code", "the preceding", "the concern above", "at this mate", "existing concern", each link into this mate and each naming of "Offerings to Natural Transmissioning"); "relative to Exhibit ONE" and the like wordings at the living files and carry/*.md; the ten files' versions at the root. The reports and checks of the same paragraphs at other mates were read for their copies: XP_1 (14, 17), GM_2 (49), PH_6b (214), NN_2 (53), EQ_4b (140), EQ_7 (213), NW_1 (34), CH_1 (13) and PL_1 (12), and the first readers' verdicts for the like row of 14 at nine mates.

Seen and not objected to:
- At 2, the transcript's path is not in NEW; the session is named, and the path is a report's name in the first brief's sense. The two closing facts name session v379 and say no more than the prior's "executed at the session and again at the close".
- At 4, the same prior has three re-sayings in three wordings, here and at the Natural Chemistry and Natural Philosophy mates (CH_1 13, PL_1 12); none loses a place, but they are not one saying word for word. Exhibit TWENTY-SIX Living File Registry 5.12 has the comparison "as a connected gathering within Networking", which parts from this paragraph's one change; NEW rightly has none of it.
- At 7, the verdict is RESOLVED and one of its three parts is at no living file: *the ambient is the transmissioning* is at this mate's v386EOD section alone, which is a later place of the kind SAID asks. The map's "kept at unrelationing, 6.1" is a place in its own proposed contents; Natural Intelligence has neither word now, and local and ambient are at Natural Naming 5.41 and Natural Numbers 3.3. Nothing of the paragraph was found at no place.
- At 10 and 30, an insertlet at Offerings to Living File Registry (line 119) says the Registry's rows at *pass G* "say a next no carrying now says" and asks each said again from its file's offerings. It points at no paragraph of this mate; with 1.5 and 5.12 as they are, the planned receiving is at the living file whichever way that row goes.
- At 12 and 13 together: 13 is released on Natural Naming 4.6, and the SAFER of 12 has "bi-co-podaling or transmissioning" among the seven as the prior has it. The two do not lean on each other; 12 carries the reason 13 has.
- At 12, three copies of the one prior would be at two wordings if the SAFER is laid here: Offerings to Natural Naming line 187 has the first reader's words, and the Equilibria Registry's copy has the SAFER's.

The twenty-six paragraphs with the verdict KEEP were not checked further, a paragraph left as it is losing nothing; the pairs 8 with 31, 10 with 30 and 21 with 32 are each at one verdict.
