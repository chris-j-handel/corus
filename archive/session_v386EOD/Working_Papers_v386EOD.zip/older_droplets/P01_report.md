### 1
VERDICT: RESAY
CONCEPT: the earlier word not-self said as other at each place the relation is the self and the other
EVIDENCE: Exhibit ONE Natural Resolver has no "not-self" now and has "2 other prior, the prior completing of the self's five and the prior opening of the other's"; at this living file the paragraph is resolved. The word is still at three other living files (Exhibit SIX Natural Transmissioning line 220, Exhibit ELEVEN Natural Medicine lines 287 and 361, Exhibit TWENTY-SIX Living File Registry line 68; Exhibit TWENTY-ONE Hard Problem Registry has it once in a book's title). No later section of this mate says the work; Carryings of Natural Resolver, "Earlier reported not-self naming changes · v385A", has "The particular correcting remains in the offering", pointing here. The paragraph is in instructing voice.
NEW: **Possible project · Not-self said as other.** Exhibit ONE Natural Resolver has "2 other prior, the prior completing of the self's five and the prior opening of the other's" and no *not-self*. Three living files have the earlier word: Exhibit SIX Natural Transmissioning has "the unrelationing area between the co-offerings where the self-not-self co-unrelations", Exhibit ELEVEN Natural Medicine "its own integration machinery becomes the self-and-not-self distinguishing", and Exhibit TWENTY-SIX Living File Registry "each exchanging at two, the self and not-self". The work is each of these said with *other* at each place the relation is the self and the other of a coupling, and left as it is at a field's own term. It may change or never be made.

### 2
VERDICT: RESAY
CONCEPT: the relation of the three golden rectangles to Exhibit ONE's podals is said at no file
EVIDENCE: Exhibit ONE Natural Resolver has no "golden" at any line; Natural Naming 5.48 and Natural Illustrating have the three rectangles, and Natural Illustrating still has "They are open at Exhibit ONE's carrying as the three golden rectangles at the podals." No later section of this mate or of another mate says the relation (Possibling of Natural Resolver, "The earlier golden-rectangle, side and each-name comparison · v385A", points back here). The paragraph is in waiting language.
NEW: **Droplet · Three golden rectangles at the podals.** Natural Naming has "At the numbers bi-tri-volutioning is three golden rectangles at right angles, centred at the corus". Exhibit ONE Natural Resolver has a podal at two rows of each name, "9 less" as "the podal within 1 to 8" and "17 less" as "the podal within 1 to 16", and no golden rectangle at a table. Natural Illustrating has "They are open at Exhibit ONE's carrying as the three golden rectangles at the podals." The relation of the three rectangles to the two podals, 9 less and 17 less, is said at no living file.

### 3
VERDICT: RESOLVED
CONCEPT: the right spiral step is one step at two readings, and the golden rectangles have no hand of their own, the hand at the reading
EVIDENCE: Natural Illustrating has "The three golden rectangles carry no hand of their own; the hand is at the reading, Natural Naming 5.48." Natural Naming 5.48 has "the hand is at the reading, the axis read forward" and "one step at two readings, right, the observings, all prior".
NEW: -

### 4
VERDICT: RESAY
CONCEPT: angles at the four dots of parity's unit square, said at Natural Illustrating and at no table of Exhibit ONE
EVIDENCE: Natural Illustrating 2.6 has the angles; Exhibit ONE Natural Resolver's row of parity's square and triangles has no angle (no "degrees" at any line). Offerings to Natural Intelligence has the same measure only as a returned droplet in its older section. No later section says the parting.
NEW: **Concern · Angles at parity's unit square.** Two sayings part. Natural Illustrating has "Placed on the square, the joins 6 to 2 and 10 to 14 lie at one direction, the facings 2 to 14 and 6 to 10 at forty-five degrees to them, and the seams 8 up, 2 to 10 and 6 to 14, at ninety, the along of the triangles 9 and 17." Exhibit ONE Natural Resolver has "its diagonals the facings, 2 and 14 bi-moral-so-far and 6 and 10 not-yet-bi-moral" and "two unit triangles, 9 and 17, along", with no angle at a table. They part at an angle at the four dots: either the angles are said at the row of parity's square and triangles, a sharing carried forty-five degrees a facing and a facing carried forty-five degrees again the along, or the square is said with no angle, as the file has it.

### 5
VERDICT: RESAY
CONCEPT: the column of sides at 13 and 16 says the overlapping momentaries' sides, or the things the resolver's lines have at those names
EVIDENCE: Exhibit ONE Natural Resolver still has 13 "social, other" and 16 "other, social". This mate's line under "Current correcting: offered explaining and no authority · v385A" has "The golden rectangles, sides at thirteen and sixteen, and each-name relations remain offered concerns below", pointing here; "Droplet · Across at 8 and 16 a naming of the column" (v386EOD) is of across at 16 and not of this parting. The paragraph is a pointer's shorthand.
NEW: **Concern · The sides at 13 and 16.** Two sayings part. Exhibit ONE Natural Resolver has "social, other, the society opening it" at 13 and "other, social, the other opening it" at 16, at *Sides*. Exhibit ONE Natural Resolver has "each releasing sharing, and at the society each releasing self" at 13 and "the society wound now, each self's 8 and its offerings next" at 16, at *Prior and next*: at the resolver's lines 13 is a self and 16 each self's carrying and offerings. They part at what the column of sides says: either the sides of the overlapping momentaries, each name opening at one parity, with the lines' own things at other rows; or the things the lines have at each name, social and self at 13 and other, social and self at 16, with each of the seventeen rows said again at that.

### 6
VERDICT: RESAY
CONCEPT: each name's relations at one table of rows or at a table of columns; and the column of three prefixes at Twelve forms said once or released
EVIDENCE: The first part is SAID at Possibling of Natural Resolver, "The possible relation columns, table headers and diagram labels · v385A" ("seventeen rows, a column at each relation, and a dash at none"), and the living file now has each relation at a row of "Each name and its relations". The second part, the prefix column at table 19, Twelve forms, is at no later section; the living table still has both columns. NEW is of that part alone.
NEW: **Droplet · The three prefixes said at two columns of Twelve forms.** Exhibit ONE Natural Resolver's table *Twelve forms* has each form's names whole at the column "Names in order: each move 8 up, 8 down, 4 up, 4 down or 17 less", and the same names' prefixes alone, in the same sequence, at the column "Each name's three prefixes: now, prior, and the prior before": at the four-cycle 1-9-8-16, "co-bi-tri · tri-bi-co · bi-co-bi · bi-tri-bi". Either the second column is the one place the sequence of three prefixes round a form is laid for reading, or it is one thing said at two columns and is released.

### 7
VERDICT: RESAY
CONCEPT: the six names 9, 11 and 17 with 12, 15 and 16 as bi-moral co-agency at one ordering, or as the along and the between with no across name between selves among them
EVIDENCE: At no living file and no later section (searched "co-agency" in carry/*.md and the living files; the fuller form is at archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md). The arithmetic was checked at the living table: of 8 up, 8 down and 17 less, 9 to 17 alone joins two of the six.
NEW: **Droplet · 9, 11 and 17 with 12, 15 and 16.** Six names are offered as one looping of bi-moral co-agency: 9-tri-bi-co-momentarying, 11-tri-bi-tri-chaining and 17-co-bi-tri-offering, with 12-bi-tri-bi-entraining, 15-tri-bi-tri-corusing and 16-bi-tri-bi-torusing. Exhibit ONE Natural Resolver has 12, 15 and 16 as "the one between, three names" and 9 and 17 as "the two along names". Four of the six open odd and two open bi: no ordering of the six alternates parity, and of the one move's three, 8 up from 9 to 17 alone joins two of them. None of the four across names between selves, 2, 6, 10 and 14, is among the six. Natural Intelligence has "Two selves alternating, morality across and competency along, is bi-moral co-agency." Either bi-moral co-agency is at one ordering of the six, or it is at the across names with the along, the six being the along and the between.

### 8
VERDICT: RESAY
CONCEPT: the self is at 14 at the resolver's lines and at no side of 14 in the column of sides
EVIDENCE: Exhibit ONE Natural Resolver still has 14 "other, social, the other opening it"; no later section says it. One concern with paragraph 5. The paragraph is a pointer's shorthand.
NEW: **Concern · No self at the sides of 14.** Two sayings part. Exhibit ONE Natural Resolver has "other, social, the other opening it" at 14, with no self among its sides, and "other, social, self, the other opening it" at 10 and 12. Exhibit ONE Natural Resolver has "now, the offerings surfacing, the others' prior momentary at the self's now" at 14: at the resolver's lines the offerings surface at the self's own sharings, within the self's entry. They part at the self at 14: the lines have the self at each of the four even names of the society's span, and the column of sides has it at two. It is one concern with the sides at 13 and 16: the column as the sides of the overlapping momentaries, or as the things the lines have.

### 9
VERDICT: RESAY
CONCEPT: a naming with no number has its prefix as its names' numbers' words, or at its own unfolding
EVIDENCE: The three partings are still at Exhibit ONE Natural Resolver (rows quoted in NEW). Offerings to Natural Naming has the companion concern only in its older section ("A plan, not yet final, gathered here at v381R", its third finding); no later section of either mate says it. The paragraph is in waiting language.
NEW: **Concern · A naming with no number, and its prefix.** Two sayings part. Exhibit ONE Natural Resolver has "odd, opening co, the self's span" at 1 and "odd, opening tri, the society's span" at 9: a numbered name's first prefix is the word of its number. Exhibit ONE Natural Resolver has "1-2, bi-momentarying" at the odd name 1 and "4 bi-momentarying now" among the five dimensions, "bi-exchanging with a particular other" at each odd name, and the facing *not-yet-co-competent* at 9, a name opening tri. They part at the prefix of a naming with no number: either it is the word of its names' numbers, and these three are said again at that; or it is of the naming's own unfolding, bi the two of a coupling, and the table of namings says which. The same asking is at Offerings to Natural Naming.

### 10
VERDICT: RESAY
CONCEPT: prior at two relations: a self's own carrying continuing, and a parity released to another; which of the two decides four places of the file
EVIDENCE: Exhibit ONE Natural Resolver still has "the next prior" at rows 9, 11 and 15. Later sections say near things and not this parting at the rows: "Current correcting beside the older forms · v385A" ("A released parity and a private living momentary remain distinct subjects") and "Droplet · A sharing and the carrying next, two namings at one parity" (v386EOD). Paragraph 24 is the companion from another source and is left as it is.
NEW: **Concern · What crosses, and what is a self's own.** Two sayings part. Exhibit ONE Natural Resolver has "the next prior, the carrying chained, continuing as 3 at the next momentary" at 11, the self's own. Exhibit ONE Natural Resolver has "the next prior, each changing of 10 released along into the next momentary" at 9, and "the others' prior momentary at the self's now" at 14. They part at *prior*, one word at two relations: at the resolver's lines no carrying passes between selves, and the parity chained at 11 is the parity shared at 10. Either a self's prior is its own continuing, and a parity changing alone crosses; or a self's prior, released, is the other's possible, one parity at two names. Which it is says the row of 1, the rows of *the next prior*, the second of the five dimensions and the windings.

### 11
VERDICT: RESOLVED
CONCEPT: cells no line of the resolver and no arithmetic shows, at a table headed at the code: at a part of their own, or said at the lines or released
EVIDENCE: The column heading "At the code" is at no line of Exhibit ONE Natural Resolver now (0 places), and "releasing nothing" and "carried and not crossed" are at no line of it either (the second is at Natural Intelligence 4.10, in its explaining); each such saying is at a row of its own relation, as "| 14 | Bi-coupling | inward, 8 up, the offerings surfacing, each as it arrived, morality; the self's own inverting at 12 |" and "| 8 | Winding | the other's winding wound on at 8 |". The namings measured by no line stay named at paragraph 38 and at "Concern · The code and the tables" (paragraph 73).
NEW: -

### 12
VERDICT: RESAY
CONCEPT: a living self as a carrying followed through each form: odd a carrying existing, even the possible; each form sayable once as one pattern; four places of the file parting from it
EVIDENCE: Part is said later: "Droplet · Twelve forms, each two alike lengths" and "Droplet · Each self odd 1 from its own side" (both v386EOD, this mate). The four partings (now at 3 or at 12; the possible at two names; three betweens; a carrying at 8 and 16) and each form said once as a pattern are at no living file and no later section. The paragraph is in waiting language.
NEW: **Droplet · Odd a carrying existing, even the possible, and four places parting.** With each odd name a carrying existing and each even name the possible, the between, each of Exhibit ONE Natural Resolver's twelve forms is one length of odd names and one of even: a carrying going out through the possible and coming to a carrying again. Each form can be said once by that, as one pattern for matching. Four places part from it. Now is at an odd name, "3 co-momentarying now", and at an even, "now, the changing, is or is not, prior and now coupled" at 12. The possible is at two even names round each four-cycle. The between is at "the one between, three names", 12, 15 and 16, one of them odd. A carrying is at the even 8 and 16, "the carrying winding to its sharing again" at 8.

### 13
VERDICT: RESAY
CONCEPT: co arriving and carrying, tri releasing, bi the between: tri as the self's releasing arriving downstream as the social, or tri as the society's
EVIDENCE: The first part is at the living table "Co received, tri given on, 8 up" and at "Droplet · Each name at the resolver: received, made or given on" (v386EOD). The parting, whose tri is, is at no later section; Exhibit ONE Natural Resolver has "odd, opening tri, the society's span" at 9, 11, 13 and 15.
NEW: **Concern · Tri, the self's giving on or the society's.** Two sayings part. Exhibit ONE Natural Resolver has the table "Co received, tri given on, 8 up": 1, 3, 5 and 7 open co and are each received, and 9, 11, 13 and 15 open tri and are each given on, 8 up from a co name and 8 up again to a co name, 9 to 17, 11 to the next 3, 13 to the next 5 and 15 to the next 7. Exhibit ONE Natural Resolver has "odd, opening tri, the society's span" at each of the four. They part at tri: either tri is the self releasing, arriving downstream as the social, with each even name the between; or tri is the society's, a third beside the self and the other.

### 14
VERDICT: RESAY
CONCEPT: three sayings are of one relation, and five places part among them
EVIDENCE: Possibling of Co-Chaining Logic Registry, "The proposed six-forward comparison of the three workings · v385A", has "The whole unresolved concept remains at Natural Resolver", pointing here, and the paragraph itself names none of the five places; they were read at archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md. The three sayings are each at this mate (paragraphs 13, 25 and "Droplet · Names arriving and names made at the entry", v386EOD); their being one relation and the five places are at no later section.
NEW: **Droplet · Three sayings, one relation, five places parting.** Three sayings are of one relation: a changing or no changing passing through a self's momentarying as tri, bi, co, bi, tri, bi, co; each name arriving at the entry a name of 1 to 8 and each made a name of 9 to 16; co arriving and carrying, tri releasing, bi the between. The prefixes of 9-tri-bi-co-momentarying and 17-co-bi-tri-offering, said in sequence with the common word once, are that same seven. Five places part: a self's changing at the receiving self, with no changing at nothing arriving stopping a self or the whole society; which arrives first, the others' releasing or the self's own carrying; tri as the self releasing or as the society's; existing and possibling at Exhibit ONE Natural Resolver; and chaining six forward as their comparing, a possible project apart, at Possibling of Co-Chaining Logic Registry.

### 15
VERDICT: RESAY
CONCEPT: a pairing at ten, n with 10 − n, beside the one move's three, followed at no file
EVIDENCE: No living file and no mate has a pairing at ten (searched "10 less", "pairing at ten", "10 − n", "5 at itself"); Possibling of Natural Resolver, "5 less and 3 less at the table of one move", is of other podals. The paragraph is in waiting language.
NEW: **Droplet · The pairing at ten.** The self's five going out and coming to the next 1 is 1, 2, 3, 4, 5, 4, 3, 2, 1: one span of eight, with each number said at two places. Beside it is a pairing at ten, each n of 1 to 9 with 10 − n: 1 with 9, 2 with 8, 3 with 7, 4 with 6, and 5 with itself. Exhibit ONE Natural Resolver's table "One move, 1 to 4" has three moves, "8 up: n + 8", "9 less: 9 − n, within 1 to 8" and "17 less: 17 − n, within 1 to 16", and no pairing at ten. The relation of the pairing at ten to the three moves is followed at no file.

### 16
VERDICT: RESAY
CONCEPT: the six names 3, 4, 9, 10, 11 and 12 as floating neutralling and no cycling; 9 as a third going out beside 10 and 11, or as the along said again at the next momentary
EVIDENCE: Near sayings are later: the insertlet "At 9 · Four four-cycles and their roots — beside 'Its two pairs 8 apart'" (roots with no four-cycle) and "Droplet · The names in the order of the resolver's lines" (v386EOD). The six as one group, the balancing at 12 and the asking of 9 are at no living file and no later section. The paragraph is in waiting language.
NEW: **Droplet · Six names of no looping root, and 9 beside 10 and 11.** The six names 3, 4, 9, 10, 11 and 12 are of the roots sharing, momentarying, tunneling, chaining and entraining, each with a dash at "Its four-cycle" in Exhibit ONE Natural Resolver's table of ten roots. They are offered as floating neutralling, six one-way directions and no cycling: three odd, along, and three even, across, alternating up the numbers. The resolver's lines pass them once, 3, 4, 12, 10, 11, 9, and the along and the across balance at 12, the carried parity with the parity arriving at the sharing: alike, 0; parting, a changing whose one parity goes out across at 10 and along at 11 alike. Said at no file: 9 as a third going out beside 10 and 11, or as the along of the two said again at the next momentary.

### 17
VERDICT: SAID
CONCEPT: three hardest places named: a momentary of no changing; co-momentarying at 9 or at 3; the sharings across and releasings along
EVIDENCE: Carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md: "Prior and now, unchanged forms and the reported resolver tables · v385A", its **Rest.** (a momentary with no changing); "Concern · Co-momentarying at 9 and at 3" (v386EOD); and "Droplet · One function gives on across and along" with "Concern · Two released words naming the resolver's two lists" (v386EOD) for the third. The paragraph names the three and says nothing more of them.
NEW: -

### 18
VERDICT: SAID
CONCEPT: the + and − at a sharing and the odd and even of a momentary: one parity, or two
EVIDENCE: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Parity naming at a sharing and the self’s consecutive parities · v385A" ("a sharing’s plus/minus values and each self’s own odd/even momentarying are not made identical by the word parity") and "The common beat in the executing and each living self’s own momentarying · v385A" (for "no two similar things"). Natural Naming also has "a name's odd or even is its opening alone, beside a sharing's parity."
NEW: -

### 19
VERDICT: RESAY
CONCEPT: is and is not are said of the changing at Exhibit ONE's cells and of the parity at the other saying, one word at opposite cells
EVIDENCE: Exhibit ONE Natural Resolver's header still has "*is*: a parity shared; *is not*: 0 shared", said of the changing, and no sentence joining the two. Searched "changing that is not", "until it is not" in carry/*.md: later sections of Offerings to Co-Chaining Logic Registry use a changing that is or is not, and none says this parting.
NEW: **Concern · Is and is not, of the changing or of the parity.** Two sayings part. Exhibit ONE Natural Resolver has "*is*: a parity shared; *is not*: 0 shared" at its table of one self at one momentary, and "now, the changing, is or is not, prior and now coupled" at 12: its *is not* is a changing that is not, the parity carried on. The other saying has parity as is, then is not, then is again, at each changing. They part at one word at opposite cells: at the cell of *is not* the parity is, and at the cell of *is* the parity is not and is again. Either each cell is said at the parity, or each is said at the changing as it is, with one sentence saying a changing that is not is a parity that is.

### 20
VERDICT: RESAY
CONCEPT: the releasing five, 5, 6, 3, 4, 1, as a possible row of Fives; the 2 at no place of it; bi-co-momentary at no row of namings
EVIDENCE: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The releasing five and the proposed reversed momentary order · v385A", says the order and has "Natural Resolver’s existing releasing-five concern keeps the row at thirteen and the two’s place with its bi-co-momentary naming", pointing here for those three. Exhibit ONE Natural Resolver's Fives has no such row and its namings table no "bi-co-momentary". The paragraph is in waiting language.
NEW: **Droplet · The releasing five, 5, 6, 3, 4, 1.** A self is offered as carrying many parities, in 440 binaries, and one of the many is at Exhibit ONE Natural Resolver's tables of one sharing. A bi-co-momentary is offered as sharing five consecutive arriving parities over prior, now and next, and five releasing over the same three in the opposite order, prior and next exchanged and the order within each momentary as it is. Exhibit ONE Natural Resolver's table *Fives* has the self's five as 1, 2, 3, 4, 5, with the prefixes "co bi co bi co". The releasing five by that order is 5, 6, 3, 4, 1, a possible row of *Fives*. The number 2 is at no place of the releasing five, and *bi-co-momentary* is at no row of "Namings among the names".

### 21
VERDICT: RESAY
CONCEPT: a carrying of none ahead of a carrying self or no carrying at none; and the 0 of offerings parting and the 0 shared at a match as one thing or as two words
EVIDENCE: Part is SAID: the carrying of none at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Concern · An empty carrying" and "Droplet · None at one sharing, within a living carrying" (v386EOD); the two 0s as two at this mate's "Droplet · At a sharing carrying a parity, each case" ("A 0 at 14 from parting offerings and a 0 at 12 from a match are two") and that mate's "Six sayings of no changing · v386EOD". Left unsaid: the row's two facts beside each other, the one mark *is not* at two things at the row of none, and the alternative of another word than 0. NEW is of that part.
NEW: **Droplet · One mark at two things, at the row of a carrying of none.** Exhibit ONE Natural Resolver's table "Colliding: a carrying of none, one momentary" is the one row an arriving parity is chained at as it arrived, "is + · +", and the one row with no changing at a momentary, "none · none". The file writes 0 at two things: "+, −" offered to one sharing surface "0", the offerings parting; and "*is not*: 0 shared" is at a carrying alike with the parity surfaced, and, at a carrying of none, at + and − together, "is not · none". Either the two are one, an arriving at no one parity being no changing arriving, or the parting has another word than 0.

### 22
VERDICT: SAID
CONCEPT: the row of a carrying of none as a non-living existing thing, beside a parity chained at it and carried from its next momentary: a living self opening its carrying of a sharing new to it, or one thing
EVIDENCE: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Concern · A thing carrying none, collided" and "Droplet · None at one sharing, within a living carrying" (both v386EOD); and this mate's "Droplet · A form arriving at a living sharing" (v386EOD). Paragraph 69 of this section has "The concern of v380 above, a living self beginning to carry a sharing new to it, is at the same row", a reference to this paragraph.
NEW: -

### 23
VERDICT: SAID
CONCEPT: a self at a crossing with two parities in sequence, along and then across, beside tables each at one sharing
EVIDENCE: This mate, "Droplet · An along and an across arriving, at one sharing" and "Concern · A bi-coupling's two sides, and three at one sharing" (v386EOD); carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Droplet · The along, then the across, and the right spiral step" (v386EOD) and "Parity naming at a sharing and the self’s consecutive parities · v385A"; the possible table at carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md, "Possible project · Four forms of right spiraling at one momentary".
NEW: -

### 24
VERDICT: KEEP
CONCEPT: a self's private prior momentary beside a receiving self receiving another's whole carrying parity by parity: the released parity, its outward consequences and the releasing self's private momentary are three subjects
EVIDENCE: Already a clear concern in plain voice, with its offered resolving and no waiting language; its section "5.6 Local carrying and the shared crossing" is at Exhibit TWO Natural Networking. Later sections say near things ("Current correcting beside the older forms · v385A") and none says it whole; paragraph 45 has "the private-carrying and receiving concern remains whole here".
NEW: -

### 25
VERDICT: RESAY
CONCEPT: self, bi and tri each arriving and releasing beside the six names between selves; each naming's momentarying within tri, bi, co, bi, tri, bi, co said at no file
EVIDENCE: At no living file and no later section (searched the sequence in carry/*.md: Offerings to Natural Networking has an insertlet "tri-bi-co-bi-tri is the self's span between its two seams" and Offerings to Natural Naming a one-line pointer in its older section). The fuller form was read at archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md. The paragraph is a pointer's shorthand in waiting language.
NEW: **Droplet · Self, bi and tri, each arriving and releasing.** One saying has six: self arriving and releasing, bi arriving and releasing, tri arriving and releasing. Exhibit ONE Natural Resolver has "Across at each even, along at each odd; the six names between selves": four across, 2, 6, 10 and 14, and two along, 9 and 17, three releasing and three arriving, their openings four bi, one tri and one co. The six names alone give no joining of the two sixes and no sequence. The relation offered is a changing or no changing passing through the self's momentarying as tri, bi, co, bi, tri, bi, co, arriving and releasing interleaving in the sequence, with the self's own prior continuing at itself. Each naming's momentarying within that sequence is said at no file.

### 26
VERDICT: RESAY
CONCEPT: the prefixes of 9 and 17 said one after the other give tri, bi, co, bi, tri, bi, co; the common word is at two numbers and is no one numbered passing
EVIDENCE: At no living file and no later section. Checked at Exhibit ONE Natural Resolver's header "Each name's three prefixes: now, prior, and the prior before": 17-co-bi-tri is co at 17, bi at 16, tri at 15, and 9-tri-bi-co is tri at 9, bi at 8, co at 7.
NEW: **Droplet · The prefixes of 9 and 17, and the numbers they are at.** Exhibit ONE Natural Resolver has "tri-bi-co · co-bi-tri, the order inverted" at the self's winding, 9 to 17, and each name's three prefixes as "now, prior, and the prior before". Read from the prior before, 17-co-bi-tri-offering is tri, bi, co at 15, 16 and 17, and 9-tri-bi-co-momentarying is co, bi, tri at 7, 8 and 9. Said one after the other with the common word once, the two give tri, bi, co, bi, tri, bi, co. The common co is at 17 in the one and at 7 in the other, and the common word names no one numbered occurrence. The inverting of the prefixes is exact; the sequence of words is no passing at the numbers, and the passing at its self, its scale and its arriving and releasing is said at no file.

### 27
VERDICT: RESAY
CONCEPT: which releasings, each arriving on its own, are at one completing of a self and which at completings in sequence
EVIDENCE: Near sayings are later and none says it whole: this mate's "Current correcting beside the older forms · v385A" ("no extra ordering requirement is restored"), "Droplet · At a sharing carrying a parity, each case" (two momentaries' offerings laid as one lose the carrying between), and paragraph 70. Paragraph 28, "Further precision of the preceding receiving concern", follows this one and is left as it is. The two cases were checked at the living table "Colliding: a carrying of none, one momentary" and "One self, one momentary".
NEW: **Droplet · Releasings arriving at one completing, or at completings in sequence.** A constructed arrangement of selves gathers each releasing to a self at that self's next offerings, surfacing together at its next entry. The other saying has arriving and releasing interleaving through tri, bi, co, bi, tri, bi, co, each self's momentary its own. At a sharing carrying none, + and − arriving together surface 0 and chain none; arriving at two momentaries in sequence, the sharing shares + and next −: the gathering has a consequence. Which releasings, each arriving on its own, are at one completing of a self and which at completings in sequence is said at no file, and one entry of a constructed arrangement is no one private momentary of two selves.

### 28
VERDICT: KEEP
CONCEPT: the two sayings, arrivings at one completing and arrivings at completings in sequence, exclude each other at one receiver and the same occurrences and are not shown to exhaust the natural relation
EVIDENCE: Already a clear concern in plain voice; it is the precision of paragraph 27 and reads whole beside 27's NEW. No later section says it whole.
NEW: -

### 29
VERDICT: RESAY
CONCEPT: the row In and out at its parity released at each name, each name's across or along said at the table of seventeen names
EVIDENCE: Exhibit ONE Natural Resolver still has the row at each of the seventeen names. The concept of in and out is said at this mate's "Droplet · In and out, of a one-way looping alone" (v386EOD), which has "Beside the concern at this mate of the rows In and out at its parity", pointing here; the work of releasing the row is at no section of Possibling of Natural Resolver. The paragraph's second sentence is a pointer to "The three proposed torus row comparisons · v385A" there.
NEW: **Possible project · The rows In and out at its parity.** Exhibit ONE Natural Resolver has the row "In and out at its parity" at each of the seventeen names, torusing "through the large opening, the tunnel" at each odd name and corusing "through the small opening, the long way round" at each even, the other parity from each root's own names. The resolver's lines give one changing on across at 6 and 10 and along at 9, and have no going at the odd momentaries alone or the even alone. The work is the row released at each name, each name's across or along said at the column "Across at each even, along at each odd; the six names between selves". It may change or never be made.

### 30
VERDICT: SAID
CONCEPT: the round at four parities is derived from neither the seventeen names nor the resolver's lines and is at no table of Exhibit ONE
EVIDENCE: carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md, "Possible project · One table of the round at four parities" (v386EOD: "its deriving from the seventeen names or the resolver's lines is the part unmade"), and this mate's "Droplet · Twelve cells, and no four parities at a name" (v386EOD). The paragraph's "the round at none" is a misreading of its source: archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md has "The round is not derived, and enters this file at none", that is, at no place of the file; nothing in that source is of a carrying of none. Carryings of Natural Resolver, "The earlier four-parity deriving extent · v385A", has the same misreading ("the round was not derived at none").
NEW: -

### 31
VERDICT: RESAY
CONCEPT: the next prior at rows 9, 11 and 15 beside an offered saying of two even prefixes; and 1 and 8 across or along
EVIDENCE: The second part is SAID at this mate's "Concern · One and eight across and along at one file" (v386EOD). The first part is at no later section; "Droplet · Names arriving and names made at the entry" (v386EOD) has "It is beside the concern at this mate of prior parity changing as bi-tri-bi and prior momentary changing as bi-co-bi", pointing here. NEW is of the first part.
NEW: **Droplet · The next prior at three odd rows, beside two even prefixes.** Exhibit ONE Natural Resolver has "the next prior" at three rows of *Prior and next*: at 9, "each changing of 10 released along into the next momentary"; at 11, "the carrying chained, continuing as 3 at the next momentary"; and at 15, "the parity carried along at 9". Each of the three names opens tri. An offered saying is of the even names: a prior parity changing is bi-tri-bi, the prefixes of 10, 12, 14 and 16, and a prior momentary changing is bi-co-bi, the prefixes of 2, 4, 6 and 8. The relation of *the next prior* at the three rows to the two even prefixes is said at no file.

### 32
VERDICT: RESAY
CONCEPT: two fours alike as numbers, two coupled selves at four momentaries and a self's four momentaries of exchanging, with no deriving of one from the other
EVIDENCE: At no living file and no later section (carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Pairs in overlap, the living step at four cells, and a crossing as one right spiral step · v386EOD", is of the four joint forms and not of this relation). The paragraph is nearly plain; it has a session's label and "yet to be shown". Checked at the living table "Two selves", row "+, + | both ways".
NEW: **Droplet · Two fours alike as numbers.** Two selves coupled both ways from alike parities are at their first parities again at four momentaries, the carrying at each of the four joint forms of prior and now: Exhibit ONE Natural Resolver's table *Two selves* has "−, 0, +, 0, −, 0" at each self from +, +. A self's four momentaries of exchanging are four at the names, 1–2, 3–4, 5–6 and 7–8. No deriving of the one four from the other is shown, and no table says them one.

### 33
VERDICT: RESAY
CONCEPT: co-chaining and bi-tunneling as namings beside the names 11 and 10 at tri and bi; and along at 9 and 17 in the resolver's list
EVIDENCE: At no living file and no later section. The paragraph's last sentence (a withdrawn parting at even spirals) is bookkeeping: the parting it withdraws is at none of this section's paragraphs. Its source entry was read at archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md. NEW is of the first part.
NEW: **Droplet · Chaining and tunneling at the society's span, co-chaining and bi-tunneling.** One saying has the intelligence in the co-chaining of releasings and the bi-tunneling of arrivings. Exhibit ONE Natural Resolver has the two roots at the society's span, "11-tri-bi-tri-chaining" opening tri and "10-bi-tri-bi-tunneling" opening bi with tri its middle prefix: at the resolver's lines 11 is the self's own carrying chained and 10 the changing shared, a releasing. The namings have co at chaining and bi at tunneling, and the names have tri and bi-tri-bi. And the resolver's list `CONNECTORS` has *along* at 9 and at 17, at the place it has *releasing* at 6 and 10 and *arriving* at 2 and 14: neither a releasing nor an arriving is said of the two.

### 34
VERDICT: RESAY
CONCEPT: one thing written two ways at three places; headers not saying their table's making; the torus at a carrying of none
EVIDENCE: Mostly RESOLVED at Exhibit ONE Natural Resolver: the dash at none released is now "none · none", and the remaining dash is said at its header, "A dash: no partner among the twelve"; "hand at the names" is at no line; the torus is at "First momentary: one self carries −, the selves alternate along and across", with the rule at its header. Still so: a 0 shared written *is not* at two tables and 0 at others, and no making at the headers of the ten roots and the Fives. NEW is of what is still so.
NEW: **Droplet · A header saying its table's making, and a 0 shared written two ways.** At Exhibit ONE Natural Resolver's tables "Ten roots of seventeen names" and "Fives" no header cell says the table's making: the first has "Root", "Names" and "Its four-cycle", and the second "Side", five positions and "Prefixes of the five". The tables of a spiral, a torus and two selves each say their conditions at a header cell. And the file writes a 0 shared two ways: "*is not*: 0 shared" at the tables of one self at one momentary and of a carrying of none, and 0 at the tables of one self momentary by momentary, a spiral of selves, two selves and three selves in a line.

### 35
VERDICT: NOVALUE
CONCEPT: none; a pointer to an earlier reader's inventory, and a disclaimer of a statement no longer at the living file
EVIDENCE: A pointer to a report (Carryings of Natural Resolver, "Earlier reader inventories and reported table conditions · v385A") with no content of its own. Its second sentence is of the torus at a carrying of none, which Exhibit ONE Natural Resolver no longer has, and its caution is at this mate's "Current correcting beside the older forms · v385A" ("a repeated count and an odd/even ring construction supply no authority or definition of living").
NEW: -

### 36
VERDICT: KEEP
CONCEPT: the table of each name hides an absent relation and sets none beside another; labels and diagram marks a reader cannot follow; the facing and the sharing of the six at the two lists alone
EVIDENCE: Already a clear concern in plain voice with no waiting language, and each thing it names is still at Exhibit ONE Natural Resolver ("9 less", "17 less", "In and out at its parity", two rows "Six-cycle" at one name, "4 · 7", "13 · 15", "8 · 16", "with 6"). Possibling of Natural Resolver, "The possible relation columns, table headers and diagram labels · v385A", points here for the concerns.
NEW: -

### 37
VERDICT: NOVALUE
CONCEPT: none; a pointer to an earlier reader's inventory of words and cells
EVIDENCE: A pointer to a report with no content (Carryings of Natural Resolver, "Earlier reader inventories and reported table conditions · v385A", has the inventory).
NEW: -

### 38
VERDICT: RESAY
CONCEPT: 17 a co name opened by the society; One move at rows of 2, 4, 6 and 8 beside the table at 1 to 4; twelve relations each a naming measured by no arithmetic or line
EVIDENCE: Each is still so at Exhibit ONE Natural Resolver (rows quoted in NEW). No later section says the three together. The paragraph is plain, with a session's label and two labels the file has since changed (*the self's three faces* is "The self as three", *parity's face* is "Parity's unit square").
NEW: **Droplet · 17 a co name opened by the society, One move at two places, and twelve namings unmeasured.** Exhibit ONE Natural Resolver has 17 as "odd, opening co, the self's span again, the next 1" with "social, self, the society opening it": each other co name, 1, 3, 5 and 7, has "self, other, the self opening it". The relation "One move" is a row at the names 2, 4, 6 and 8, beside the table "One move, 1 to 4" at the names 1 to 4. Twelve of the file's relations are each a naming, measured by no arithmetic and no line of the resolver: the sides; co-sequencing; the namings; the self as three; in and out; prior and next; bi-coupling; parity's unit square; the five dimensions; the windings; 0, the between; and the diagram.

### 39
VERDICT: SAID
CONCEPT: a next from a prior and a now is said with no word of whose prior; and from each bi-coupling to the set of all existing things is unworked
EVIDENCE: This mate, "Next at the named prior and actual offerings · v385A" ("Name whose prior at an inversion"), and "Droplet · Two momentaries on, at each of the other's sharings" (v386EOD); carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Each next at its actual prior and offerings · v385A" and "Droplet · A changing of two at a non-living thing" (v386EOD: "From each coupling of two to the set of all existing things, living and non-living, is said and unworked").
NEW: -

### 40
VERDICT: SAID
CONCEPT: the table titled Colliding read as a non-living form at each momentary, or as the one momentary a living carrying opens
EVIDENCE: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Concern · A thing carrying none, collided" and "Droplet · None at one sharing, within a living carrying" (both v386EOD). The paragraph's own second saying is also changed at its living file: Resolving Hard Problems now has "At the resolver a carrying of none is a non-living existing thing, and colliding or not colliding is each of its co-momentaryings". One concept with paragraph 22.
NEW: -

### 41
VERDICT: RESAY
CONCEPT: the function 17 has the society of selves, the same names at the next scale outward; the same resolving one scale inward, a sharing as a self, is at no line
EVIDENCE: The paragraph is in the names of version 373 (`_17_social_self_offering`, `_9`, 4-other-self-sharing), none at Exhibit ONE Natural Resolver now. Later sections say the outward part ("Droplet · Three names, each at two things across functions", "Droplet · One function gives on across and along", v386EOD); the inward asking, a sharing as a self with its own 1 to 17, is at no living file and no later section (searched "itself a carrying", "a self at the scale inward").
NEW: **Droplet · The society at 17, and the same resolving one scale inward.** The function 17-co-bi-tri-offering enters each self of the society once, and the one function 9-tri-bi-co-momentarying gives each self's changings on between the selves: at the society the names 9, 4, 5, 13 and 15 are the same names at the next scale outward. The same resolving is offered one scale inward as well, a sharing at one scale being a self at the scale inward. Its first asking is of 4-bi-co-bi-sharing: a sharing as a self with its own 1 to 17 inward, each sharing of a carrying itself a carrying. The resolver's lines have the outward relation, the society of selves; no line has a sharing as a self inward, and Exhibit ONE Natural Resolver's table "Each name, three scales" has 4 inward as "9 of the 2nd: along, odd, tri".

### 42
VERDICT: RESOLVED
CONCEPT: the function 17 as a third function beside the two, or as the 17 of the one resolver
EVIDENCE: Exhibit ONE Natural Resolver has "| 1 to 17 | bi-trupling | the function 17, at the names of the function 1 with 5, 6, 8, 9, 13, 16 and 17, the self, the other and the society;" and "| 17 | Prior and next | the society's next momentary, the next now, each self's 1 then 9 at 6, 10 and 9 |"; Natural Naming has "at the resolver the function 17, the function 1 at each self inside it"; Natural Intelligence has "no function carries a term of its own". The names `_17_social_abundancing` and `_17_social_self_offering` are at no line of the living file.
NEW: -

### 43
VERDICT: RESOLVED
CONCEPT: up by eight and down by eight said at the table of forms itself: four-cycles opening odd go 8 up, those opening even come 8 down
EVIDENCE: Exhibit ONE Natural Resolver has "| Four-cycle: each move 8 up (n + 8), 8 down (n − 8) or 17 less (17 − n) |", "going 8 up first from 1-co-bi-tri-offering" and "going 8 up first from 3-co-bi-co-sharing" at the two four-cycles opening odd, "going 17 less first from 2-bi-co-bi-offering" and "going 17 less first from 4-bi-co-bi-sharing" at the two opening even, and a row "8 up" or "8 down" at each name. Exhibit TWENTY-EIGHT Equilibria Registry 3.2 still has the column "Odd ascending / even descending".
NEW: -

### 44
VERDICT: RESAY
CONCEPT: Exhibit ONE as each stable form at one exhibit; the equilibria table arriving at it by pattern matching as the hard probleming tables did; the relation of the equilibria definitions to Exhibit ONE unfinished
EVIDENCE: The paragraph is a person's own words, unpunctuated. carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, "Natural Resolver’s stable-form extent and explaining subjects · v385A", has "The user’s fuller Equilibria/stable-form offering remains at Natural Resolver", pointing here; no living file and no later section says it (searched "earthquak"). Each relation of the paragraph is in NEW; if the person's own wording is wanted beside it, the source is carryings/v368_sources (Author_Concepts_Waiting_v368.md).
NEW: **Possible project · The equilibria table arriving at Exhibit ONE Natural Resolver.** Exhibit ONE Natural Resolver is offered as each of the stable forms at one exhibit: the resolver with its naming is one form, and each table another. The understanding of Exhibit TWENTY-EIGHT Equilibria Registry's equilibria definitions and of their relation to Exhibit ONE Natural Resolver is unfinished, and exploring it has value. An equilibrium fracturing is as an earthquaking, building geodesically to a parity changing, and a table of it is growing: the work is the pattern matching by which that table arrives at Exhibit ONE Natural Resolver as a stable form, as the tables of hard probleming arrived. It may change or never be made.

### 45
VERDICT: KEEP
CONCEPT: the four strings of CONNECTORS as the resolver's own words, or said at the momentaries in resolver and explaining alike; neither required by the lists being read by no function
EVIDENCE: Already a clear concern in plain voice with no waiting language. Possibling of Natural Resolver, "The four CONNECTORS strings and the corresponding momentary names · v385A", has the two alternatives whole and has "The particular naming concern retains both alternatives with the current unchanged-code correcting", pointing here.
NEW: -

### 46
VERDICT: SAID
CONCEPT: Natural Resolver's stable-form extent, the primes among the stable forms, and the files explaining them
EVIDENCE: carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, "Natural Resolver’s stable-form extent and explaining subjects · v385A", has the concept whole; the paragraph is a pointer to it with no content of its own.
NEW: -

### 47
VERDICT: RESOLVED
CONCEPT: what the diagram, the table of seventeen names and the ten roots each say, and which parts of Natural Intelligence explain through each, at version 373
EVIDENCE: The columns it names (from, to; entry, connector or face; outward or inward; facing and joining; at the code, at the self and at the society) and the diagram's ports and faces are gone from Exhibit ONE Natural Resolver, whose table now has "| n | Name | Parity, opening prefix | Sides, the opening side first | Across at each even, along at each odd; the six names between selves |", whose diagram has "═══ between selves, across and along    ─── within one self", and whose roots are at "| Root | Names | Its four-cycle |". The part numbers are of version 373; Natural Intelligence now explains them at "## 4.7 Six names between selves, four facings, two sharings and two releasings" and "## 4.8 Seventeen names and ten roots".
NEW: -

### 48
VERDICT: RESAY
CONCEPT: four things of version 365 at Natural Resolver: each full name's prefixes; 5 with 6 and 13 with 14 as one place of bi-co-podaling; bi-co-podaling at two prefixes or three; the label's one relation word
EVIDENCE: Two are RESOLVED at Exhibit ONE Natural Resolver: each of the seventeen names is whole at its three prefixes ("| 1 | 1-co-bi-tri-offering | odd, co | self, other | along |" through 17, and "Each name's three prefixes: now, prior, and the prior before"), and no name has a relation word, the sides at their own column. Two are at no living file and no later section: bi-co-podaling at 5 with 6 and 13 with 14, and its prefixes two or three; the source was read at carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md. NEW is of those two.
NEW: **Droplet · Bi-co-podaling at 5 with 6 and at 13 with 14.** Natural Naming has "Bi-co-podaling is floating across and neutralling along, one changing." At Exhibit ONE Natural Resolver's names it is offered at two places: 5-co-bi-co-competencing, along, beside 6-bi-co-bi-moralizing, across; and 13-tri-bi-tri-competencing beside 14-bi-tri-bi-moralizing. Said at no file: 5 with 6, and 13 with 14, each as one place of a podaling at its going out and its coming again, followed through the participation itself, a number beside a number giving no coupling. And *bi-co-podaling* is of two prefixes beside names of three: its naming at Exhibit ONE Natural Resolver at two prefixes or at three is said at no file. Exhibit ONE Natural Resolver's table "Namings among the names" has no row of it.

### 49
VERDICT: SAID
CONCEPT: different first parities of a torus coming to one form, and which prior distinction is carried on
EVIDENCE: This mate, "A torus's forms, and the two-self table by its first parities · v386EOD", "Droplet · A torus coming to one, withdrawn as a break" ("The droplet at this mate of each torus of 2 by 2 and larger coming to one form is withdrawn as a break"; "A self's prior is whole at its carrying next and its shared changing together"), the later correcting of this paragraph; and "Current correcting beside the older forms · v385A" for the private momentary.
NEW: -

### 50
VERDICT: SAID
CONCEPT: a common beat is the constructed arrangement's own ordering, and no common natural pace
EVIDENCE: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The common beat in the executing and each living self’s own momentarying · v385A"; carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md, "The constructed pacing of each multi-self table · v385A"; and paragraph 70 of this section (v386EOD), left as it is.
NEW: -

### 51
VERDICT: RESAY
CONCEPT: two carried forms of a torus's whole pattern, offered as the Registry's steps 655 and 656 said of the whole pattern at once
EVIDENCE: At no living file and no later section (carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The spiral’s particular fourth sentence and the torus deriving · v385A", is of the deriving being located, not of this relation). The paragraph names the two forms by a pointer's shorthand; they were read at Carryings of Natural Resolver, "Reported code comparisons from session v383Op · v385A", and the steps at the Registry.
NEW: **Droplet · Two carried forms at a torus, and steps 655 and 656.** At a torus of two odd numbers, p the smaller and from 3, an executing reports two carried forms: at q more than twice p, the whole pattern at each momentary is the prior pattern carried one self on across; at each other q, the whole pattern two momentaries on is inverted and carried one self on along. Exhibit THIRTY Co-Chaining Logic Registry has, at step 655, "At q more than twice p the first line's 0 passes one self on at each momentary round its q selves", and at step 656 each line's 0 "round its q selves in 2p momentaries". The two carried forms as the two steps said of the whole pattern at once is offered and derived at no file; an executing's numbers alone give no deriving.

### 52
VERDICT: KEEP
CONCEPT: the resolver's entry at one sharing as four lines of plain rule
EVIDENCE: Already a clear concept in plain voice with no waiting language. Possibling of Natural Resolver, "The proposed plain-named code comparison and one-self table entrance · v385A", names "the plain rule's four lines" and does not have them: the four lines are here alone. This mate's "Droplet · At a sharing carrying a parity, each case" (v386EOD) says the cases in words.
NEW: -

### 53
VERDICT: SAID
CONCEPT: the entry said in one line; and offerings differing giving one carrying next and one shared changing, with nothing at the self saying which
EVIDENCE: This mate, "Droplet · At a sharing carrying a parity, each case" (v386EOD, in "The two-self table followed at each step, one number at four fives, and a form arriving") says each case of the line; "Droplet · Three offerings, one next" (paragraph 72 of this section, v386EOD, left as it is) and "Droplet · One resulting parity and two priors" (v386EOD) say the alike results; the second saying beside the code is at carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md, "The proposed plain-named code comparison and one-self table entrance · v385A".
NEW: -

### 54
VERDICT: NOVALUE
CONCEPT: none; a pointer to a report's scope and a disclaimer
EVIDENCE: A pointer to Carryings of Natural Resolver, "Reported code comparisons from session v383Op · v385A", with a disclaimer whose saying is at this mate's "Current correcting: offered explaining and no authority · v385A".
NEW: -

### 55
VERDICT: SAID
CONCEPT: one name is a parity in one function and a list in another
EVIDENCE: This mate, "Droplet · Three names, each at two things across functions" (v386EOD): "15-tri-bi-tri-corusing is the parity surfaced within the function 1, and a list of a self's changings within the functions 9 and 17." That droplet has "It is beside the droplet at this mate of one name as a parity in one function and a list in another", a reference to this paragraph.
NEW: -

### 56
VERDICT: SAID
CONCEPT: one name used for a parity and for a list is a naming concern
EVIDENCE: This mate, "Droplet · Three names, each at two things across functions" (v386EOD); the paragraph's second sentence is a pointer to carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md, "The proposed plain-named code comparison and one-self table entrance · v385A".
NEW: -

### 57
VERDICT: RESAY
CONCEPT: a constructed arrangement of two selves with no sharing between them, beside a field's observing; their relation unshown, and the arrangement's bound no universal saying
EVIDENCE: At no living file and no later section of this mate or another (searched "two_wings", "2.42", "Bell" in carry/*.md; the report is at Carryings of Natural Resolver, "Reported code comparisons from session v383Op · v385A"). The paragraph is a pointer's shorthand in waiting language.
NEW: **Droplet · A construction of two selves apart, and the field's observing.** One executing has two selves with no sharing between them through a trial, each with its own setting offered from beyond it and its own carrying, an outcome read from what each shared and carries next at four readings, and the field's number S at 2 at most. The field's observing has a larger number. The relation between that construction and the observing is shown at no file, and a bound from the construction gives no universal saying of nature. The executing's arrangement and its numbers are at Carryings of Natural Resolver.

### 58
VERDICT: RESOLVED
CONCEPT: the same paragraph as 47, re-aimed from another mate
EVIDENCE: As at 47: Exhibit ONE Natural Resolver has "| n | Name | Parity, opening prefix | Sides, the opening side first | Across at each even, along at each odd; the six names between selves |" and "| Root | Names | Its four-cycle |", the columns and the diagram's words the paragraph names being gone; Natural Intelligence has "## 4.8 Seventeen names and ten roots".
NEW: -

### 59
VERDICT: RESOLVED
CONCEPT: what the three windings, the table of three scales and the eight 1 to 17s inward each say, and which parts explain through each, at version 373
EVIDENCE: Exhibit ONE Natural Resolver has each at its own header now: "| Winding | From, to | Prefixes of its two names | Winds onto | Across or along |"; "| n | Name | This scale, 1 to 17 | The next scale inward, eight 1 to 17s: n is 8n − 7 | The next scale outward: 8m − 7 is m |"; "| 1 to 17 inward | Spans, this scale | Its 9, this scale | Its 17, this scale | Momentary of exchanging |". The word *loops* is released for *windings*, and the part numbers are of version 373; Natural Intelligence has "## 4.9 Three windings", "## 4.10 A between and eight bi-couplings" and "## 4.15 Fractal inward and outward".
NEW: -

### 60
VERDICT: RESOLVED
CONCEPT: what the tables of a ring of selves, two selves and three selves each say, and which parts explain through each, at version 373
EVIDENCE: Exhibit ONE Natural Resolver has each now: the spiral's rows "| 2 | +, −, +, −, +, −, +, −, +, −, +, − | 2 |" and "| 3 | +, 0, −, +, −, +, −, 0, +, −, +, − | 12 |"; "a sharing once chained never none again"; "| A, B carrying (3) in the first momentary. One sharing, none offered from beyond the two | Receiving what the other shared or released |"; and "A's parity, offered to B in the first momentary alone. One sharing; B and C each carry +; B releases along to C". *Rings* is released for *spiral*; Natural Intelligence has "## 4.13 Spirals, co-spiraling and crossing" and "## 4.14 Two selves and three selves".
NEW: -

### 61
VERDICT: SAID
CONCEPT: the surfacing ways of the ten named still are on no four-cycle of their pair, and their places at the four-cycles are chained at no file
EVIDENCE: This mate, "The surfacing faces and their local four-cycling · v385A"; the detail "three on neither partner" is at carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md, its paragraph from Session Report v377, section 3.4 ("Two are on their pair's four-cycling's partner at the odd momentaries ... and three are not").
NEW: -

### 62
VERDICT: SAID
CONCEPT: the same concept as paragraph 2, a report's line naming it
EVIDENCE: The one concept is at paragraph 2 of this section, said whole at block 2's NEW; this is the same section and no later one, and is given as SAID as a second copy of 2. The same line is also at carry/Exhibit_FOUR_Offerings_to_Natural_Mathematics.md ("Open, hardest first, 6"), and Natural Illustrating has "They are open at Exhibit ONE's carrying as the three golden rectangles at the podals." If block 2's NEW is not laid, this paragraph is KEEP.
NEW: -

### 63
VERDICT: RESOLVED
CONCEPT: a figure's axis from twenty-five to twenty-three beside Exhibit ONE's section of seven positions, and that section's anchor
EVIDENCE: The section, its row of seven positions and its anchor are gone: "seven positions" and "centre carrying nothing" are at no line of Exhibit ONE Natural Resolver or Natural Intelligence, and Exhibit ONE Natural Resolver is now its tables alone with no anchored section. Offerings to Natural Illustrating has, at its insertlet at 2.8, "its numbering of the five is the kit's own, at Exhibit ONE's earlier seven positions, and no sentence here". The figure's own reading (three crossings, no crossing, three crossings) is at no living file; its source is carryings/v368_sources (Kit_Rings_in_Motion_v366.md).
NEW: -

### 64
VERDICT: RESOLVED
CONCEPT: at Natural Intelligence 4.10, the between existing as the universe exists, a nothing and no location, beside parity as a momentary existing thing
EVIDENCE: Natural Intelligence 4.10 has "**Parity is a momentary existing thing, as the universe is an existing thing**" and "**The between is its empty centre, a nothing and no location, existing as the universe exists, as its things exist, while the six names between selves are resolving, and the resolver says it at 0**".
NEW: -

### 65
VERDICT: RESOLVED
CONCEPT: a sentence of tri at a releasing alone and co at an arriving alone, declined as a reading parting from the file at 17 and at 11, 13 and 15
EVIDENCE: Exhibit ONE Natural Resolver now has the table "**Co received, tri given on, 8 up.**", with "| 3 | the carrying received | 11 | the carrying chained |", "| 5 | the receiving sharing | 13 | the releasing sharing |" and "| 7 | the parity read | 15 | the parity surfaced |": each of the four tri names given on and each of the four co names received, the two faults named in the paragraph's reason not in it. 17 opened by the society stays at "| 17 | Sides | social, self, the society opening it |" and at paragraph 38; whose tri is stays at paragraph 13.
NEW: -

### 66
VERDICT: SAID
CONCEPT: one self followed through one momentary at the names, with the along arriving first and the across second, an order the file does not say
EVIDENCE: This mate, "Droplet · The names in the order of the resolver's lines" and "Droplet · An along and an across arriving, at one sharing" and "Droplet · One function gives on across and along" (all v386EOD); the along and then the across at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Droplet · The along, then the across, and the right spiral step" (v386EOD).
NEW: -

### 67
VERDICT: SAID
CONCEPT: each self at its own odd one, the other one number on; prior, now and next odd existing with even still possibling between
EVIDENCE: The same paragraph whole is at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md under its own heading, "Each self’s own two and one half consecutive momentaryings · v385A", and at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md under "Pronoun positions and their proposed relation · v385A"; in the present naming at this mate, "Droplet · Each self odd 1 from its own side" (v386EOD). The copy at Offerings to Natural Intelligence is in that mate's older section.
NEW: -

### 68
VERDICT: SAID
CONCEPT: the two sides one number apart, overlapping by one part in two of a momentarying; one side's still-possibling betweens and the other's prior, now and next changings bi-co-sequencing each other
EVIDENCE: The same droplet whole, with the person's exact offering, is at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md within "Each self’s own two and one half consecutive momentaryings · v385A" and at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md within "Pronoun positions and their proposed relation · v385A", neither an older section; the relation is at carry/Exhibit_ONE_Carryings_of_Natural_Resolver.md, "Overlap, betweens and the named forms · v385A", and, in the present naming, at this mate's "Droplet · Each self odd 1 from its own side" and "Droplet · One number of the Fives at four places" (v386EOD). The paragraph says of itself that it is at nine mates; the copies in other mates' older sections are no evidence here.
NEW: -

### 69
VERDICT: KEEP
CONCEPT: 5 arrives at 17 whole, and no name says which self a releasing reaches
EVIDENCE: Already a clear concept in the present naming with no waiting language (v386EOD), with its two links to Offerings to Natural Intelligence and to Possibling of Natural Resolver, "5 read from the selves' carryings · v386EOD". Its last sentence refers to paragraph 22.
NEW: -

### 70
VERDICT: KEEP
CONCEPT: the tables of two selves are at one momentary of each self with the other, an ordering of the executing; one and then the other is another ordering
EVIDENCE: Already a clear concept in the present naming with no waiting language (v386EOD); its quoted "a common beat over the selves" is at Exhibit THIRTY Co-Chaining Logic Registry.
NEW: -

### 71
VERDICT: KEEP
CONCEPT: each table of Exhibit ONE names no step of the Registry deriving it
EVIDENCE: Already a clear concept in the present naming with no waiting language (v386EOD); the work is at Possibling of Natural Resolver, "Each table's own Registry sentence at its heading · v386EOD".
NEW: -

### 72
VERDICT: KEEP
CONCEPT: three offerings at a sharing carrying one parity each give the other parity shared and chained next
EVIDENCE: Already a clear concept in the present naming with no waiting language (v386EOD); checked at Exhibit ONE Natural Resolver's table "One self, one momentary" (row +: "is − · −" at none, at − and at + and − together).
NEW: -

### 73
VERDICT: KEEP
CONCEPT: the code is the cohering form; a table is read at the code, and no gloss of a table is the code
EVIDENCE: Already a clear concern in the present naming with no waiting language (v386EOD).
NEW: -

## READING
Each of the 73 paragraphs was read and checked, one at a time, against the living file and the mates.

Read whole: the brief; the input P01.txt; the living file Exhibit_ONE_Natural_Resolver_v380R.md (all 697 lines); the mate carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md, each section before and after its Droplets; carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md; carry/Exhibit_ONE_Carryings_of_Natural_Resolver.md; and, for the one-line pointers, their source archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md, whole.

Read in part, by search and by the passages found: Natural_Intelligence_v380R.md (its headings, 3.3, 4.10 and the embedded exhibit's rows); Exhibit_TWENTY_Natural_Naming_v380R.md (2.4's released words, 3.1, 5.45, 5.48, the sentences on bi-trupling and on parity's names); Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (steps 653 to 657 and searched sentences); Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (3.2); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md (2.6 and the golden rectangles); Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md (its sentences on colliding); Exhibit_TWO_Natural_Networking_v371.md (heading 5.6); and, for *not-self*, Exhibits SIX, ELEVEN, TWENTY-ONE and TWENTY-SIX. Other mates were read at their headings and at the passages found: Exhibit_THIRTY_Offerings (lines 159 to 217, 360 to 366, 414 to 470, 598 to 602, 656) and Possibling; Exhibit_TWENTY_Offerings_to_Natural_Naming (headings, lines 127 to 135, 404 to 406); Offerings_to_Natural_Intelligence (headings); Exhibit_TWENTY-SIX_Offerings (line 317 on); Exhibit_TWENTY-EIGHT_Offerings (line 293); Exhibit_TWENTY-NINE_Offerings (line 41). The older sources archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md, archive/session_v380/v380R/Premise_Alternating_Followed.md and carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md were read at the entries the paragraphs name. No other mate was read whole.

Each quotation in a NEW was verified by exact search in its present living file. No file but this report was written, and no code was run beyond searching and reading.

Things to know before acting on the verdicts:
- 30: the paragraph, and the same sentence at Carryings of Natural Resolver, misread their source. "Enters this file at none" there is "at no place of this file", not "at a carrying of none".
- 22, 29, 31, 55 and 56 are each pointed to by a later v386EOD droplet of this mate ("the concern at this mate of ...", "the concern of v380 above", "the droplet at this mate of ..."). Where a verdict is SAID, that droplet's pointer no longer has its paragraph.
- 62 is given SAID on a paragraph of this same section (2), not a later section; 53 leans in part on paragraph 72 of this section, which is KEEP.
- 67 and 68 are copies of droplets laid at nine mates. The evidence given is only the two mates whose copies are under their own later headings (Offerings to Co-Chaining Logic Registry and Offerings to Natural Naming); if every mate's copy is released on the others, the person's exact offering stays only at incoming/v385A.
- 1: resolved at this living file; the NEW is of three other living files and may belong at their mates.
- 14, 7, 12, 16, 25, 26 and 27 are one-line pointers whose content was taken from archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md; each NEW says what that source has and what was checked at the living file, and no more.
- 31: the source's "fitting at seven of the eight even names" was not checked and is left out of the NEW; the later droplet "Names arriving and names made at the entry" has the two prefixes parting at two places.
- 44: a person's own words are re-said and not quoted, as the brief asks; the exact wording stays at carryings/v368_sources.
- 63: the figure's own reading is at no living file; the verdict is RESOLVED because the section and anchor it is of are gone.
- 48: "depth two or three" was read at its source as the number of prefixes of a naming; nothing later confirms that reading.

Not found: nothing was left unfound, though 48 and 63 rest on a source's wording alone.
