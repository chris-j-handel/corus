### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OK
WHY: laid beside the prior clause by clause, each of the four things is in NEW at its strength (the octet with 2, 8, 18 and 32, group three with the provisional report's leaning, the bond "proposed", the p-block's six "a numeral alone and no correspondence", the three sections aimed at, "the sciences paused"); the source, carryings/rings_are_spirals_v377/README.md section 6 items 3 and 5 (lines 128 and 130), has no more; the 3.10 is the proposed text's (carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md line 296, with the bolded sentence at line 306), and the same section is 3.1 at Exhibit_EIGHTEEN_Natural_Physics_v379.md (line 191, the bond at line 201), each read.
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: OK
WHY: the four quotations are exact at Exhibit_EIGHTEEN_Natural_Physics_v379.md line 205 within 3.1, Exhibit_THREE_Natural_Numbers_v380L.md line 349 within 7.1 and Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 313 within 4.4, each read; the closing sentence has the one saying as the three files' own to make, none made; the title has the subject words this mate's "The element count and the turn at sixty · v385A" (line 155, "the existing concern here") points with; "for both" is left out and the paragraph is laid as a Concern, the kind that label names.
SAFER: -

### 9
CHECK: OK
WHY: carryings/natural_physics_v377/README.md lines 173 to 180 read: section 6.6 is headed "Seams with other files, each side at its own file", its *this file* is Natural Physics, and the 5.2, 3.4 and 3.12 are the proposed text's (its lines 546, 246 and 330, read), so NEW's "the proposed text has its side at the section named" is the prior's last clause at the file it is of; NEW has no quotation.
SAFER: -

### 10
CHECK: OK
WHY: carryings/natural_physics_v377/README.md line 184 (6.7) read; 442, 341, 500, "no script named", "at its stated choices", the three files with F40 and F41, and the 4.5 are each in NEW; the proposed text's 4.5 has the execution (its line 426), `sums.py` is at carryings/natural_physics_v377/executions/, and paragraph 5, which this one points at, is left as it is.
SAFER: -

### 11
CHECK: OBJECT
WHY: Lost: whose reading it is and of which version, and with it the strength of two claims. The prior has "(Re-Settling the Living Files, §2 table) — resettling_v373"; its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md line 56, under the column heads of line 38, "Shape at this reading" and "Old code or older wording", the document headed "first draft, session v373") is one session's reading of each file beside the others as they were. NEW says both as things that are now, with no reading named: "It is the best-shaped science" and "it has little old wording". (1) The superlative is among the sciences of that reading, Natural Physics then at version 348 (the same table, line 58, "unhedged beside Chemistry") and at version 379 now. (2) "Little old wording" is against the naming of version 373; at the naming now this same mate's paragraphs 27 to 33 map released words at this file at 39, 81, 38, 9, 3, 22 and 37 places (*membrane*, *count*, *face*, *surplus*, *loop*, *run*, *sign*), so the sentence said as of now parts from the mate it lies in. The numbers, the version 346c and the two portions are each in NEW as the prior has them; the mend is the reading named, as rule 12 has it.
SAFER: **Droplet · Natural Chemistry the best-shaped science, at session v373's reading.** Session v373's reading of the living files has Exhibit SIXTEEN Natural Chemistry, 14,000 words at its version 346c, as the best-shaped science: the field's record and the reading are carried apart. At that reading 60 to 65% of the file is its own subject, 8 to 10% restates the common method, and it has little old wording.

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 191 read beside NEW: each section number (1.3, 2.4 to 2.5, 3.1 to 3.7, 3.8 twice, 4.3, 4.4, 4.6), each receiving file, the one change to the agreed receiving with both its reasons, and "About 12%" are in NEW, said as a plan's and not as done; the numbers are Exhibit_SIX_Natural_Transmissioning_v330.md's headings still (read), and *membrane* and "sum to a **bounding-zeroing**" are that file's own words (lines 79 and 177).
SAFER: -

### 14
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 197 read: the subtitle's three words, the claim said once with its breaking observation, the periodic table to 4.3 and 4.4, 2.5 and the garbled lines, and the seven things of Natural Biology in their order are each in NEW; the prior's 4.1 is of Natural Physics at version 348 ("## 4.1 An atom at two faces, and the periodic table as emanation-catalog", read at the repository's history) and is "## 3.1 An atom at two faces, and the periodic table a catalog" at Exhibit_EIGHTEEN_Natural_Physics_v379.md now, and 2.5 is at that number at both.
SAFER: -

### 15
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 223 is a row of a table of each repeated passage, its places and its one home; "a turn stands at 60" is under 4.1 at version 348 and under 3.1 at Exhibit_EIGHTEEN_Natural_Physics_v379.md (line 205) now, so the number given is the number now; "4.3 to 4.4" and the one home are as the prior has them, the home said as work and not as made.
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: OK
WHY: both quotations are exact, Exhibit_SEVENTEEN_Natural_Biology_v333.md line 375 within 3.1 and Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 393 within 5.4, each read; the two places, cardiolipin, 1/φ² and "no universal ancestral value" are the prior's, and the source (Re-Settling_the_Living_Files.md line 256) has no more.
SAFER: -

### 18
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 19, within "## 2. The standing of the living files against the apex", has "**Far back, v345 to v348, five files.** … Natural Chemistry v346c, paused, five ready"; NEW has the three things, the version and the place, with that session's reading named and nothing beside them.
SAFER: -

### 19
CHECK: OBJECT
WHY: Added: "It may change or never be made.", and with it the kind, a possible project. The prior says the releasing as a thing each file does at its own improving, and its source (carryings/v368_sources/Wrap_v368.md line 73, "**Across the set.**", under "## 4 · What each file carries next") has it as carried, with no word of a thing that may never be. The living files say it as a rule: Exhibit_TWENTY_Natural_Naming_v380R.md line 297, "**Each word releases at its file's next improving, in the shared words**", and Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 282, "A pointing is released, never re-pointed" (each read). So NEW says a thing intended as possible work (the first reader's rule 4) and is weaker than the prior and than the living sentence. The middle sentence is the prior word for word and "It is aimed at the set." carries the aiming; the mend is the form alone. The same sentence was re-said as a droplet and confirmed at another mate (SO_1, block 6), and is at carry/Exhibit_SEVEN_Offerings_to_Natural_Societies.md line 51 in that form.
SAFER: **Droplet · Across the set, what each file releases at its own improving.** Across the set, each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words. It is aimed at the set.

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: OK
WHY: both quotations are exact, Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 9 and the row's first cell at Exhibit_TWENTY_Natural_Naming_v380R.md line 247 under "## 2.4 Released words, each with its carrying" (read); the parting at one word is the prior's own saying ("the subtitle parts from 2.4 at this one word"; carryings/v381F/v381F/Session_Report_v381F.md line 61, "Five subtitles part from Natural Naming 2.4"), and the line laid ready is said as laid ready, at the file's own motion and in its own voice, with the aiming.
SAFER: -

### 24
CHECK: OK
WHY: each part read at its source: carryings/v381F/v381F/Session_Report_v381F.md lines 193 and 201 (the lean, co- 21 to bi- 9, the three roots, "as offered", and the competency loop at a subject) and line 175 ("Natural Chemistry 20"), and Entry_Journey_For_An_AI.md line 32 under the heads "Far side in Natural Intelligence" and "The session's reading"; the 3.2 is Natural Intelligence's, whose line 194 within "## 3.2" has "the ring of one hundred twenty" and "one hundred eighteen the returning's far end"; each number of the prior is in NEW and none beside them.
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: HARM3.md, BRIEFO3.md with its further rules, CH_1.txt (thirty-nine paragraphs), CH_1_report.md (each block and its READING), Exhibit_SIXTEEN_Natural_Chemistry_v346c.md (13,891 words), and carry/Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md with each of its sections headed v385A and v386EOD.

The first reader releases nothing: thirteen paragraphs are re-said (3, 8, 9, 10, 11, 13, 14, 15, 17, 18, 19, 23, 24) and twenty-six left as they are. Each of the thirteen was laid beside its prior clause by clause, and its source was opened and read at the lines named: carryings/rings_are_spirals_v377/README.md (section 6); carryings/natural_physics_v377/README.md (6.6 and 6.7) and the proposed text beside it (its headings whole, and lines 246, 306, 330, 426 and 546); carryings/resettling_v373/Re-Settling_the_Living_Files.md (its head, lines 38 to 58, 187 to 197, 221 to 225, 255 and 256); carryings/session_v378/Session_Report_v378.md (section 2); carryings/v368_sources/Wrap_v368.md (line 73 and its headings); carryings/v381F/v381F/Session_Report_v381F.md (lines 57 to 62, 125 to 128, 171 to 201), Entry_Journey_For_An_AI.md (lines 10 to 40) and Next.md (lines 56 to 59).

Checked by exact search and then read at the place: each of the eight quotations of the NEW paragraphs at the living file it names (Exhibit_EIGHTEEN_Natural_Physics_v379.md line 205, Exhibit_THREE_Natural_Numbers_v380L.md line 349, Exhibit_SIXTEEN_Natural_Chemistry_v346c.md lines 9, 313 and 393, Exhibit_SEVENTEEN_Natural_Biology_v333.md line 375, Exhibit_TWENTY_Natural_Naming_v380R.md line 247), each exact; the headings of Exhibit_EIGHTEEN_Natural_Physics_v379.md whole, and of Natural Physics at version 348 at the repository's history (commit 0eef2d2), for the numbers 4.1, 3.1 and 2.5; the headings of Exhibit_SIX_Natural_Transmissioning_v330.md whole; Natural_Intelligence_v380R.md at 3.2 and 4.11; Natural Naming line 297 and the Geodesic Improving Method line 282; 341 and 442 at the living Natural Physics (neither); `sums.py` at the repository (two places under carryings/).

Searched in carry/*.md for pointers at this mate's older paragraphs ("the concern at this mate", "the droplet at this mate", "existing concern here", "crystal-twinning", "current droplet is at", links to this mate, each row of the Living File Registry's two mates naming Natural Chemistry): two point at the older section, line 151 of this mate at paragraph 1, left as it is, and line 155 at paragraph 8, whose NEW has the same subject words. Each NEW was measured, 45 to 149 words, and searched for the words set aside, none found apart from a living file's own word in italics or within a quotation.

Read beside these, as other readers' work and not as proof: the blocks for the same words at other mates (PH_6b report and harm for paragraphs 9, 10, 14 and 15; NU_1 and PH_4a for paragraph 8; HP_1, SO_1, NN_2 and NW_1 for paragraph 19; XP_1, PH_6b and GH_1 for the row of paragraph 11). The first reader's saying that six of its paragraphs are word for word those confirmed at other mates is so for 8, 9, 10, 14, 15 and 19; of these I object to 19, where the same sentence was confirmed in two forms at two mates and the droplet's form adds nothing.

Said plainly: the twenty-six KEEP blocks were not checked further, a paragraph left as it is costing nothing; "for both" and the report names are left out of each NEW and were read as a session's labels, apart from paragraph 11, where the reading's name is what dates two of its claims; whether the 60 to 65% and the 8 to 10% of paragraph 11 are so could not be checked. No file in /home/claude/corus was edited, no script of the repository was executed, and this report is the one file written.
