### 1
VERDICT: RESAY
CONCEPT: Natural Explaining's sentence of a self's carrying shown and offered across parts from the saying that a self's carrying is its own and only one sharing's parity crosses.
EVIDENCE: The living file still has the sentence at 4.9, "that self's own carrying shown, and that carrying offered across" (Exhibit_TWELVE_Natural_Explaining_v378.md, line 378), so it is not resolved. The later section of this mate "A carrying offered across re-said, importancing, and the origin at two statements · v386EOD" opens its first droplet "Beside the concern at this mate of "that self's own carrying shown, and that carrying offered across"": a pointer at this paragraph, so it stays and is re-said with the same subject words (rule 2). The paragraph is in waiting language ("A plan, not yet final, gathered here at v381R", a report path, a retired working). The second saying is named at no file by the paragraph (source: carryings/v380R/Natural_Networking_From_v380A.md, line 47, and archive/carrying_v381R/Exhibit_TWELVE_Natural_Explaining_v380R.md, line 33), so NEW gives it unquoted and adds no file's sentence beside it. "For both" and the reason are carried.
NEW: **Concern · That self's own carrying shown, and that carrying offered across.** Two sayings part, a concern for both. Natural Explaining has "that self's own carrying shown, and that carrying offered across". Beside it is the saying of a self's carrying as its own, crossing at no coupling of selves, and of the thing crossing as one sharing's parity at its changing. They part at a carrying crossing between selves: either the sentence is said again at the carrying the self's own, or the sentence is as now and is said of another relation. The concern was found at the working v380A and laid at no carrying before.

### 2
VERDICT: RESAY
CONCEPT: *a tell* as the mark a fault shows at is a third use of the word at Natural Explaining, beside a telling and *tell* said as a demand, and the collision is named or the use moved to another word.
EVIDENCE: The living file still has the three uses: "A length is a tell and never the binary" (2.2), "This tell arrives at a telling's close" (3.8), "An unrelationing shows at its tell" (4.7), and "*Tell*, said as a demand, is the alternating stopped" (4.9); not resolved. The mate's own front paragraph (line 7) says "the *tell* collision below met at the same motion": a pointer at this paragraph, so it stays and NEW carries the words "the *tell* collision" (rule 2). No section headed v385A or v386EOD says it. The paragraph has waiting language (the opening label). *sign* and *meeting* in NEW are the living file's own words, cited in italics.
NEW: **Droplet · The *tell* collision.** At Natural Explaining, *a tell* as the *sign* a fault shows at, at 2.2's length, 3.8's close and 4.7's unrelationing, is a third use beside a telling and *tell* said as a demand. Either the collision is named at its first *meeting*, or the *sign* use is carried at another word, at a naming pass.

### 3
VERDICT: RESAY
CONCEPT: Whether Natural Explaining 4.2's four improvings are four improvings or one improving at four directions.
EVIDENCE: The living file's 4.2 still has "True, false, living and competency, taken as four given, are four improvings at an explaining" (line 320); the concern is said at no living file and at no section headed v385A or v386EOD (searched "four improvings" and "one improving at four" in the living files and carry/*.md; only carry/Session_Record.md names the four improvings, as an entering, not this concern). The paragraph has waiting language (the opening label). No pointer at it found. NEW carries the place 4.2, "for both", the paragraph's own reading "all or none at its step", and both readings.
NEW: **Concern · Four improvings, or one improving at four directions.** It is a concern for both. Natural Explaining 4.2 has "True, false, living and competency, taken as four given, are four improvings at an explaining": more true, less false, better living and greater competency, each *more* and *less* a direction and all or none at its step, a working improving at one of the four at a momentary. Two readings part at the number of improvings: four improvings, or one improving at four directions.

### 4
VERDICT: RESAY
CONCEPT: Natural Intelligence Corus Part 16, Natural Writing, is planned to be received at Natural Explaining, following Corus's rebuild.
EVIDENCE: Not done at the living files: Natural_Intelligence_Corus_v330.md still has "# Part 16: Natural Writing — routed and reduced" and Natural Explaining is at v378 unchanged; the Living File Registry has no sentence of Part 16. Later places point at this paragraph: this mate's front paragraph (line 5) says the Corus passage comparison "now supports the existing Part 16 receiving plan", and carry/Carryings_of_Natural_Intelligence_Corus.md, under "Corus arriving and distribution: passage comparison · v385A", says "existing bulk Part 16 receiving plan at its offering mate" and "The existing bulk receiving plan remains available". It therefore stays, re-said with the words "Part 16 receiving plan" (rule 2). Source of the pointer: carryings/resettling_v373/Re-Settling_the_Living_Files.md, line 166 (the §6 Corus table row). The wait is said as a relation (rule 9).
NEW: **Possible project · The Part 16 receiving plan.** Natural Intelligence Corus Part 16, Natural Writing, about 13,450 words, goes to Natural Explaining: Natural Explaining receives Part 16's remainder and the two one-way languages of 16.3. Its receiving is a following at Natural Intelligence Corus's rebuild. It may change or never be made.

### 5
VERDICT: RESAY
CONCEPT: The plan that Natural Explaining stays the craft at four parts, receives Corus Part 16's remainder, and releases its general method to other files.
EVIDENCE: Four copies are in the input (5, 13, 14, 19), alike but for the opening label here and a re-aiming note at the others; all four are given the same verdict and one NEW serves the four (rule 13). Source: carryings/resettling_v373/Re-Settling_the_Living_Files.md, line 173. The releasing is not done: Natural Explaining v378 still has 1.6, 4.1, 4.2's "Knowing named still is science, and a device is that knowing named still in a substrate.", 4.5's "Surgical-method is one instance" and 4.6's "One worked case is the resolver, the set's logic object". No section headed v385A or v386EOD says the plan (searched "general method", "surgical", "resolver case", "science and device" in carry/*.md; only older copies at other mates). The v385A pointers named at paragraph 4 also rest on this paragraph's "receives Corus Part 16's remainder". One part is resolved and left out of NEW: "Natural Intelligence 8.7's sentence paragraph says what Explaining 2.1 says and releases there" — Natural_Intelligence_v380R.md has six parts, no 8.7 and no sentence paragraph (the word "sentence" is at one line, 77, of another subject), and Natural Explaining 2.1 has "The prior sentences are its possibling, the sentence coheres now, and the next it opens is its living: prior, now and next, three sequential momentaries at one sentence." A place renumbered (rule 8): Natural Intelligence 8.6 at version 372 was "Two methods parting at the precise place" (archive/resolver_v372_proposal/Natural_Intelligence_v372.md, line 1377) and is now "## 5.4 Two methods parting at the now" (Natural_Intelligence_v380R.md, line 1085).
NEW: **Possible project · Natural Explaining the craft, its general method released.** Natural Explaining stays the craft, tight at four parts. It receives the remainder of Natural Intelligence Corus Part 16 and releases its own general method: 1.6 and 4.1 to Natural Intelligence or Natural Naming; the paragraph of truth, science and a device at 4.2 to Natural Intelligence 5.4 or Natural Philosophy; the surgical method at 4.5 to the combined Exploring; and the resolver case at 4.6 to Exhibit ONE Natural Resolver. It may change or never be made.

### 6
VERDICT: RESOLVED
CONCEPT: Natural Destinies and Natural Emanating are at pass G, their receiving planned at the Living File Registry 1.5.
EVIDENCE: The paragraph is a pointer to the Living File Registry, and that living file says it now. Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md, 1.1, rows: "| **FOURTEEN · Natural Destinies** | Social Moral Co-Abundancing | v333 | v333 | — | pass G |" and "| **FIFTEEN · Natural Emanating** | Self-Welcoming Social Moral Co-Offerings | v329 | v329 | — | pass G |". Its 1.5, rows: "| **FOURTEEN · Natural Destinies** | All content receives in Corus and the relevant subject exhibits | When every imaginative expression, particular making and methodological contribution has received |" and "| **FIFTEEN · Natural Emanating** | Whole expressions toward Corus, concepts toward Naming, craft toward Explaining; the remaining natural emanating subject still needs comparison | A possible fourth released place, and no whole-file release |". The paragraph's quotation is the session report's own summary of 1.5 (carryings/session_v378/Session_Report_v378.md, line 21) and carries nothing beside it. No pointer at this paragraph found in the mate or in carry/*.md. One narrowing to see: the registry says of Natural Destinies "the relevant subject exhibits" and names Natural Naming and Natural Explaining for Natural Emanating alone; its 5.11 gives Natural Destinies' receiving in full.
NEW: -

### 7
VERDICT: KEEP
CONCEPT: The released-words motions at the Geodesic Improving Method and Natural Explaining, large and mechanical, the Method's motion also entering both workings' learnings.
EVIDENCE: Could not find the whole of what it refers to. The two motions are at the Living File Registry now: Natural Explaining's row ends "| its released words re-said at one motion, at its carrying |" and the Geodesic Improving Method's row ends "| its released words re-said at one motion, then its combining with Exhibit EIGHT, at its carrying |". The rest is at no living file and no later section: the reading "large and mechanical", and "the Method also entering both workings' learnings", whose two workings the source does not name (carryings/session_v378/Session_Report_v378.md, lines 15 and 30, has only "both workings' learnings at 2.6, 2.7 and 4.5"). With that part unfound the paragraph is left exactly as it is (rule 3). Its opening label and report pointer are its only session wording.
NEW: -

### 8
VERDICT: RESAY
CONCEPT: Files use released words at the same version at which Natural Naming 2.4 releases them, and nothing says whether each use is a finding to bring or a carrying to leave.
EVIDENCE: Still so at the living files: Natural Naming 2.4 has the rows for *every*, *sign*, *run* and "*so* at a sequence, *since* at a reason", and "The same word at a sentence living, coupling and resolving carries whole at that sentence" (line 299); Natural Explaining v378 has "A file is a membrane, and only signs cross it" (1.6); the Geodesic Improving Method 2.9 has "A file at a prior version to the files resolving its subject carries prior sayings by arithmetic and not by fault." (line 218), of which NEW quotes "by arithmetic" alone, the paragraph's own extent; `REVIEWER.md` (kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/) has "no released word" and uses *every*. No section headed v385A or v386EOD of this mate or another says it; the one other saying is a paragraph of the older Droplets section of carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md ("Concern · Released words in use"), which is no later place (rule 1). Source: carryings/v381F/README.md, line 53, finding 8. The paragraph has waiting language (the opening label, a report pointer). No pointer at it found.
NEW: **Concern · Released words in use.** Two sayings part. Natural Naming 2.4 releases *run*, *sign*, *so* at a sequence, *since* at a reason and *every*. Natural Explaining v378 has *running* and *sign* many times and 1.6's title "A file is a membrane, and only signs cross it", *membrane* a released word; the Geodesic Improving Method v380R, at Natural Naming's own version, has *so* at a sequence and *since* at a reason; `REVIEWER.md` has *every* beside its rule *no released word*. Natural Naming 2.4 has "The same word at a sentence living, coupling and resolving carries whole at that sentence", and the Geodesic Improving Method 2.9 has a file at a prior version carrying prior sayings "by arithmetic". They part at a released word used at the releasing version: a session cannot tell from the files whether these are findings to bring or carryings to leave, and `reader_checks.py` flags them either way.

### 9
VERDICT: KEEP
CONCEPT: *running*, *run* and *runs*, Natural Explaining's own word for the changing, are released at Natural Naming 2.4 and are re-said one at a time at the file's next motion.
EVIDENCE: Left as it is. Not resolved: Natural Explaining v378 still has each quoted sentence (2.6 "A sentence at its -ing carries the running at the momentary it runs", 3.1 "Each sentence says the running, at the momentary it runs", 3.4 "a sentence carrying something the running does not carry", 4.5 "Its running is no other possible") and the Living File Registry row still has "its released words re-said at one motion, at its carrying". No section headed v385A or v386EOD says it; paragraph 26 of this same older section says it at 78 places and names this one ("v382F's droplet at the Session Report named this at fifty-three"), so it stays (rules 1 and 2). Its body is a clear droplet in plain voice; its only waiting language is the opening label "A plan, not yet final, gathered here at v381R:". A re-saying carrying each of its four quotations, the Natural Naming row, the number fifty-three and each line number does not fit one hundred and fifty words without dropping one, so none is offered. Whole also at carryings/v382F/Session_Report_v382F_2.md, line 45.
NEW: -

### 10
VERDICT: RESAY
CONCEPT: *stilling along* at Natural Explaining 3.10 and the Geodesic Improving Method is a second compound of a still, beside Natural Naming 2.4's one compound alone.
EVIDENCE: Still parting at the living files: Natural Explaining 3.10 has "*stilling along* is the form carried through the changing, never a frozen carrying" (line 270); the Geodesic Improving Method has "neutralling without floating across while stilling along, the form carried on through the changing" (line 170), now under "## 2.5 The hardest first, and the hardest question asked plainly", the paragraph's 2.3 renumbered (rule 8); Natural Naming 2.4 has the row "*stilling*, *self-stilling-self*" with "the self's own still is at one compound alone, *is-still-possibling*, 5.62" (line 280). No section headed v385A or v386EOD says it; the other saying is a paragraph of the older Droplets section of carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md ("Concern · *Stilling along*, beside one compound alone"), no later place (rule 1). The paragraph has waiting language (the opening label). The aiming is carried (rule 10). No pointer at it found.
NEW: **Concern · *Stilling along*, beside one compound alone.** It is aimed at Natural Explaining 3.10 and Natural Naming 2.4. Two sayings part. Natural Explaining, at 3.10, has "*stilling along* is the form carried through the changing, never a frozen carrying", and the Geodesic Improving Method, at 2.5, has "neutralling without floating across while stilling along, the form carried on through the changing". Natural Naming, at 2.4, releases *stilling* and *self-stilling-self* to *self discovering next self* and has "the self's own still is at one compound alone, *is-still-possibling*". They part at a second compound of a still, 2.4 having one compound alone: either *stilling along* is a second compound the set carries, said at 2.4 beside *is-still-possibling*, or it releases at the two files at *the form carried on through the changing*, which both sentences say beside it.

### 11
VERDICT: KEEP
CONCEPT: Natural Explaining 2.7's "no coordinate" parts from the files' own practice of pointing by section number, within a file and into other files.
EVIDENCE: Already a clear concern in plain voice with no waiting language, aimed at the set, with its two readings and its reason. Not resolved: 2.7 still has "A reference carries a plain name and no coordinate." and "a section mark, a numbered crossing and a counted step each hand over a position to be looked up and carry nothing of the concept there". No section headed v385A or v386EOD says it whole: "A file by itself, or among the files" (v386EOD) is of 1.4's "no file named inside another", another rule, and the 2.7 insertlets are in the Insertlets section, no later place. One thing seen and left: the sentence it gives the README, *no living file … names no other file*, is no longer at README.md.
NEW: -

### 12
VERDICT: KEEP
CONCEPT: Natural Explaining and its Part THREE to say *chains at none, the prior carrying on* at each of fourteen sentences that said *releases*, with *releasing* one thing again, the giving on along.
EVIDENCE: Already a clear possible project in plain voice, marked "from the self", with each line and each intended wording. It says what the file will say, an intending not done: the living file still has "A SENTENCE'S SUPPLYING, AND ITS RELEASING" as Part THREE's title and "at that binary each releases" (line 116). A thing intended is not to be said as done or as possible work (rule 4), and its fourteen places and wordings do not fit one hundred and fifty words. No section headed v385A or v386EOD says it. Left exactly as it is.
NEW: -

### 13
VERDICT: RESAY
CONCEPT: The plan that Natural Explaining stays the craft at four parts, receives Corus Part 16's remainder, and releases its general method to other files.
EVIDENCE: A copy of paragraph 5 (also 14 and 19), differing only by the note "(re-aimed from Exhibit ONE Offerings to Natural Resolver at v381R)", a session's bookkeeping of where the copy lay; same verdict and the same NEW as 5, one NEW serving the four copies (rule 13). The evidence is as at 5: the releasing is not done at Natural Explaining v378; no later section says it; the 8.7 sentence part is resolved (no 8.7 and no sentence paragraph at Natural_Intelligence_v380R.md; Natural Explaining 2.1 has "The prior sentences are its possibling, the sentence coheres now, and the next it opens is its living: prior, now and next, three sequential momentaries at one sentence."); Natural Intelligence 8.6 is now "## 5.4 Two methods parting at the now".
NEW: **Possible project · Natural Explaining the craft, its general method released.** Natural Explaining stays the craft, tight at four parts. It receives the remainder of Natural Intelligence Corus Part 16 and releases its own general method: 1.6 and 4.1 to Natural Intelligence or Natural Naming; the paragraph of truth, science and a device at 4.2 to Natural Intelligence 5.4 or Natural Philosophy; the surgical method at 4.5 to the combined Exploring; and the resolver case at 4.6 to Exhibit ONE Natural Resolver. It may change or never be made.

### 14
VERDICT: RESAY
CONCEPT: The plan that Natural Explaining stays the craft at four parts, receives Corus Part 16's remainder, and releases its general method to other files.
EVIDENCE: A copy of paragraph 5 (also 13 and 19), differing only by the note "(re-aimed from Exhibit TWENTY Offerings to Natural Naming at v381R)", a session's bookkeeping of where the copy lay; same verdict and the same NEW as 5, one NEW serving the four copies (rule 13). The evidence is as at 5.
NEW: **Possible project · Natural Explaining the craft, its general method released.** Natural Explaining stays the craft, tight at four parts. It receives the remainder of Natural Intelligence Corus Part 16 and releases its own general method: 1.6 and 4.1 to Natural Intelligence or Natural Naming; the paragraph of truth, science and a device at 4.2 to Natural Intelligence 5.4 or Natural Philosophy; the surgical method at 4.5 to the combined Exploring; and the resolver case at 4.6 to Exhibit ONE Natural Resolver. It may change or never be made.

### 15
VERDICT: KEEP
CONCEPT: A person's own direction for the narrow method of writing and the model of an exhibit: title, subtitle, floating neutralling contents, bold concepts, full explaining, and no sentence that does not advance the carrying.
EVIDENCE: A person's own unpunctuated words (rule 5). Natural Explaining 1.1 to 1.3 say much of it ("A title is the whole bounded context of its file, and a subtitle carries that context with the file's own stable-forming inside it.", "so scanning it is scanning the whole explaining", "One subject is told at four tellings of itself"), yet the paragraph also carries claims a re-saying cannot give at their strength in the present naming: do no harm improving as binary at all explaining and naming, the method "without landing and holding and cause and effecting and more", the clustering concepts showing in the parts, and the asking to read three exhibits for the method. Left exactly as it is.
NEW: -

### 16
VERDICT: RESAY
CONCEPT: Natural Explaining's "no coordinate" parts from Natural Naming's and Natural Intelligence's saying of a name with its number.
EVIDENCE: Both sentences are living: Natural Explaining has "A reference carries a plain name and no coordinate." (line 156); Natural Naming has the row "| *met*, *meet*, *meeting* | the component's own name, *at 14*, *at 12*; *couples with*; *is facing*; *reaches*; *at* |" (line 258). No section headed v385A or v386EOD says it: "Two rules of this file, beside Natural Intelligence · v386EOD", from the same source, says two other partings (no file named within another; the positive over the negation), and the insertlets at 2.7 are in no later place. The paragraph is a pointer in shorthand; its source is carryings/v383Op/Presentation.md, line 38, under "Five places the explaining's own sentences part", and NEW has only what that line and the paragraph say. The aiming is carried (rule 10). No pointer at it found.
NEW: **Concern · A plain name and no coordinate, beside a name with its number.** It is aimed at a sentence of Natural Explaining. Two sayings part. Natural Explaining has "A reference carries a plain name and no coordinate." Natural Naming has, for *met*, *meet* and *meeting*, "the component's own name, *at 14*, *at 12*", the name with its number, and Natural Intelligence says a name with its number throughout. They part at a number beside a name: a number is a coordinate. The two sentences are of two living files.

### 17
VERDICT: RESAY
CONCEPT: Natural Explaining releases *then* as laying a schedule, and Natural Intelligence 1.2's title has *then*.
EVIDENCE: Both are living: Natural Explaining has "*Then*, *after*, *once*, *before*, *finally* and *now that* each lay a schedule over co-sequencing running" (line 230); Natural_Intelligence_v380R.md has "## 1.2 Changing, one and then the other" (line 83). No section headed v385A or v386EOD says it; "The first coming again, at alternating's sixth line · v386EOD" at the Natural Naming mate is of another concern. The paragraph is a pointer in shorthand; source carryings/v383Op/Presentation.md, line 40. The aiming and the place 1.2 are carried (rules 8 and 10). No pointer at it found.
NEW: **Concern · *Then* laying a schedule, beside a title with *then*.** It is aimed at a word of Natural Explaining, *then*. Two sayings part. Natural Explaining has "*Then*, *after*, *once*, *before*, *finally* and *now that* each lay a schedule over co-sequencing running". Natural Intelligence has, as the title of 1.2, "Changing, one and then the other". They part at *then*: released at one file as laying a schedule, and said at the other file's title.

### 18
VERDICT: KEEP
CONCEPT: Natural Explaining's setting down of the summary and the re-saying forbids the plain abstract a newcomer most needs, and a sentence parting a summary laid over a file from a plain saying at its front frees it.
EVIDENCE: Not resolved: Natural Explaining 2.1 still has "Summarizing, re-saying, abstracting and a backward look at a close each patch one fault". No section headed v385A or v386EOD says it. A re-saying cannot carry one of its claims in the present naming: the sentence it gives the README, *plain explaining a reader meets once and understands*, is no longer at README.md (it is at archive/session_v385A/repository_instructions/README.md and at the source, carryings/v383Op/Presentation.md, line 42), so it can be neither quoted as a living file's sentence nor left out. The paragraph is otherwise plain, with no waiting language. Left exactly as it is.
NEW: -

### 19
VERDICT: RESAY
CONCEPT: The plan that Natural Explaining stays the craft at four parts, receives Corus Part 16's remainder, and releases its general method to other files.
EVIDENCE: A copy of paragraph 5 (also 13 and 14), differing only by the note "(re-aimed from Offerings to Natural Intelligence at v381R)", a session's bookkeeping of where the copy lay; same verdict and the same NEW as 5, one NEW serving the four copies (rule 13). The evidence is as at 5.
NEW: **Possible project · Natural Explaining the craft, its general method released.** Natural Explaining stays the craft, tight at four parts. It receives the remainder of Natural Intelligence Corus Part 16 and releases its own general method: 1.6 and 4.1 to Natural Intelligence or Natural Naming; the paragraph of truth, science and a device at 4.2 to Natural Intelligence 5.4 or Natural Philosophy; the surgical method at 4.5 to the combined Exploring; and the resolver case at 4.6 to Exhibit ONE Natural Resolver. It may change or never be made.

### 20
VERDICT: RESOLVED
CONCEPT: Natural Explaining receives from Natural Intelligence the method at a sentence.
EVIDENCE: The passage is gone from Natural Intelligence and Natural Explaining says it. The source (carryings/resettling_v373/Natural_Intelligence_Map.md, line 173, and its row for 8.7 at line 151) is of Natural Intelligence 8.7 at version 372, "One method at existing things, at a sentence, at a file set and at a session" (archive/resolver_v372_proposal/Natural_Intelligence_v372.md, line 1387). Natural_Intelligence_v380R.md has six parts, no 8.7, and the word "sentence" at one line alone (77, of the opening sentence). Each claim of the old sentence paragraph is at Natural Explaining v378 now: 2.1, "The prior sentences are its possibling, the sentence coheres now, and the next it opens is its living: prior, now and next, three sequential momentaries at one sentence." and "One binary at each sentence: is it or is it not living, coupling and resolving."; 3.1, "A sentence carries no cause and effect." and "A sentence carries no birth and no death." No pointer at this paragraph found in the mate or in carry/*.md.
NEW: -

### 21
VERDICT: KEEP
CONCEPT: *membrane* and *membranes* at twelve places and two *join* at Natural Explaining, with Natural Naming's *the between* and *sharing* for them.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file is at v378 and each quoted sentence is at the line given (100, 104, 132, 220, 292, 340, 360, 362, 376 checked). No section headed v385A or v386EOD says it; the re-sayings at 1.6, 2.2 and 4.9 are in the Insertlets section, no later place (rule 1). Its lines and quotations do not fit one hundred and fifty words.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: *count*, *counts*, *counted* and *store* at Natural Explaining's own voice at 16 places, with Natural Naming 2.4's carrying for each.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file still has "A count is taken at its paragraph's naming" (140), "a count is the co-sequencing running" (216), "a pattern space and a set point are a store and a value named still" (362), "count in and count out, all or none, along the plane and never across" (344), and 3.11's title. No section headed v385A or v386EOD says it; the insertlets at 2.4, 3.4, 3.11, 4.6 and 4.7 are in no later place.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: *face* and *faces* at twenty-one places at Natural Explaining, most re-said as *its side*, with the three titles and the two other re-sayings named.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file still has the three titles (1.4, 3.4, 3.8) and "A finding carries at two faces, the field's words and the set's own" (90), "A public face is a third face of one sentence" (92), "Asking an alternating which of its two faces it is names it still" (250). No section headed v385A or v386EOD says it; the insertlets at 1.4, 3.4 and 3.8 are in no later place. Its "a v382F droplet already at its offerings" could not be found at this mate; that droplet is whole at carryings/v382F/Session_Report_v382F_2.md, line 49.
NEW: -

### 24
VERDICT: KEEP
CONCEPT: *surplus* and *co-offering* at three places at Natural Explaining, with Natural Naming's *abundancing* and the dissolving of *co-offering*.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file still has "its adding to the prior sentences' carrying is the surplus" (122), "Three run at an improving: co-offering, the reach; co-competencing, the surplus" (316), "the surplus is a shared experience none carries alone" (376). No section headed v385A or v386EOD says it; the insertlets at 2.2, 4.2 and 4.9 re-say *surplus* alone, say nothing of *co-offering*, and are in no later place.
NEW: -

### 25
VERDICT: KEEP
CONCEPT: *ring* at two places at Natural Explaining, with Natural Naming 2.4's *spiral* for it.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file still has "Three at one self along the running and three at three selves across the ring are two things at one number" (360) and "Suspense is a telling at an odd ring, closing at no parity, a meeting travelling round it and never locking" (366). No section headed v385A or v386EOD says it; the insertlets at 4.7 and 4.8 are in no later place.
NEW: -

### 26
VERDICT: KEEP
CONCEPT: *run*, *runs* and *running* at 78 places at Natural Explaining, three section titles among them, with Natural Naming 2.4's *momentarying* for it.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file is at v378 with the three titles (3.5, 3.8, 3.9) and each quoted sentence. No section headed v385A or v386EOD says it; the mate's front paragraph and the Living File Registry row name the motion and not the places. It names paragraph 9 ("v382F's droplet at the Session Report named this at fifty-three"), so the two stay together.
NEW: -

### 27
VERDICT: KEEP
CONCEPT: *sign* and *signs* at 26 places at Natural Explaining, two section titles among them, with Natural Naming 2.4's *parity* for it.
EVIDENCE: Already a clear droplet aimed at a file, in plain voice with no waiting language. Not resolved: the living file still has the titles of 1.6 and 4.6 and "a sign crossing it carries nothing" (104), "A coupling carries a sign at each side, offer or not" (236), "A sign is a sign of one exact predicate at one receiving" (354). No section headed v385A or v386EOD says it; the insertlets at 1.6 and 4.6 are in no later place.
NEW: -

## READING
Each of the 27 paragraphs was read and checked, one block for each, none left out.

Read whole: the brief with its further rules; the input; the living file Exhibit_TWELVE_Natural_Explaining_v378.md; the mate carry/Exhibit_TWELVE_Offerings_to_Natural_Explaining.md, with its front, its Insertlets, its older Droplets and each later section headed v385A and v386EOD; the two other mates, carry/Exhibit_TWELVE_Carryings_of_Natural_Explaining.md and carry/Exhibit_TWELVE_Possibling_of_Natural_Explaining.md; README.md; archive/carrying_v381R/Exhibit_TWELVE_Natural_Explaining_v380R.md.

Read in part, by search and by the passages found: Natural_Intelligence_v380R.md (its contents, 1.2, 5.4, 6.2 and each line with "sentence"); Exhibit_TWENTY_Natural_Naming_v380R.md (2.4's rows and line 656); Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md (2.5 and 2.9); Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1's rows, 1.5, 5.11); Natural_Intelligence_Corus_v330.md (Part 16's heading); carry/Carryings_of_Natural_Intelligence_Corus.md (the v385A passage comparison, Part 16); carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md (its headings and its copies of paragraphs 8 and 10); carry/*.md by search for each concept and for pointers at this mate's paragraphs; the sources carryings/v380R/Natural_Networking_From_v380A.md, carryings/resettling_v373/Re-Settling_the_Living_Files.md and Natural_Intelligence_Map.md, carryings/session_v378/Session_Report_v378.md, carryings/v381F/README.md, carryings/v382F/Session_Report_v382F.md and Session_Report_v382F_2.md, carryings/v383Op/Presentation.md, archive/resolver_v372_proposal/Natural_Intelligence_v372.md, and kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/REVIEWER.md.

Each quotation in a NEW was verified by exact search in the present living file. Pointers found at this mate's older paragraphs: the v386EOD droplet "4.9's carrying offered across, re-said" at paragraph 1; the mate's front paragraph ("the *tell* collision below") at paragraph 2; the mate's front paragraph and the v385A passage comparison at the Corus carryings ("the existing Part 16 receiving plan") at paragraph 4 and the four copies 5, 13, 14, 19; paragraph 26 at paragraph 9.

Not found: which two workings "both workings' learnings" names (paragraph 7); the "v382F droplet already at its offerings" that paragraph 23 names, at this mate; the README sentences that paragraphs 11 and 18 give, which are no longer at README.md. Paragraphs 5, 13, 14 and 19 are four copies and carry one NEW: laid at the mate it is one paragraph, not four. Paragraphs 9 and 7 are kept with their opening label "A plan, not yet final, gathered here at v381R:" still on them, their bodies unchanged.
