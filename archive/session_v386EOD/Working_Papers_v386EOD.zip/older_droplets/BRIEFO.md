# Brief for a reader resolving one mate's older droplets

A file set called natural intelligence has living files at the root of `/home/claude/corus` and, in `carry/`, three mates for each living file: Offerings (concepts, concerns), Possibling (possible work that may change or never be made), Carryings (observings, gatherings). Your input file holds the numbered paragraphs of one mate's older section named `## Droplets`. These paragraphs were gathered by earlier sessions, often as one-line pointers in a session's own words, some marked as plans "not yet final" or as waiting on a later session. The living files have moved on, and later sections of the same mate (headed `## … · v385A` and `## … · v386EOD`) say many of the same things in the present naming.

Your work: for each numbered paragraph, find what it is now. Do not edit any file in `/home/claude/corus`. Do not run code other than searching and reading. You write exactly one file, your report.

## The rule above all: do no harm

A paragraph is changed or released only if you have found, by reading, the place that makes the change safe. If you cannot find what a paragraph refers to, or you are unsure, its verdict is KEEP and it is left exactly as it is. A wrong KEEP costs nothing; a wrong release or a re-saying that drops a relation loses value.

## For each paragraph

1. Read it. Say to yourself the one concept, concern or piece of work it carries, apart from the session's words about it (version labels, "for the next session", "a plan, not yet final", report names, finding numbers).
2. Read the living file's present sentence, table or row it is about (Grep two or three wordings in the living file named at the top of your input, and in any other living file the paragraph names). Read the mate's later sections for the same concept (Grep in the mate file named at the top of your input, and in `carry/*.md` for other mates).
3. Give exactly one verdict:
   - **RESOLVED**: the living file now says what the paragraph asks for, or the sentence, row or word it concerns is gone from the living file. Give the living file's present sentence or row exactly, in quotation marks, as EVIDENCE.
   - **SAID**: a later section of this mate, or another mate, says the paragraph's whole concept in the present naming, with nothing of the paragraph left unsaid there. Give the file name and the heading or bold title as EVIDENCE. If a part is left unsaid, the verdict is RESAY for that part.
   - **NOVALUE**: the paragraph carries no concept, concern or work: a session's own bookkeeping, a pointer to a report with no content, a number of findings, a plan about the session itself. Say which as EVIDENCE.
   - **RESAY**: the paragraph carries value that is at no living file and at no later section, and it is in a session's words, a pointer's shorthand, or waiting language. Write NEW: the paragraph said whole in the present naming and plain voice (rules below), losing no relation, condition, negation or attribution of fact the paragraph has.
   - **KEEP**: the paragraph is already a clear concept, concern or possible project in plain voice with no waiting language; or you could not find what it refers to. Say which as EVIDENCE.

## How to write NEW

- One paragraph, forty to one hundred and fifty words, in one of three forms:
  `**Droplet · <title>.** <text>` for a concept;
  `**Concern · <title>.** Two sayings part. <File> has "…". <File> has "…". They part at <the one subject>: <reason>.` for two sayings that part;
  `**Possible project · <title>.** <what the work is, one to three sentences> It may change or never be made.` for work proposed and not done.
- Plain declarative sentences. No "I", no narration of sources or sessions, no advice, no warning, no promise of later work, no waiting on anything.
- Quote only living files' own sentences, exactly, in double quotation marks, each verified with Grep in the present living file. Never quote a person's or a session's words.
- Whole names for files (Natural Intelligence, Exhibit ONE Natural Resolver, Natural Naming, Exhibit THIRTY Co-Chaining Logic Registry).
- Do not use these words in your own sentences: every (each), when, where, there, because, since, so, would, until, wait, hold, held, keep, kept (carry), stand, start, begin (open), return, memory, surplus, membrane (the between), door, neighbour, inside, outside (inward, outward, within), run, take, half, count (number), sign (parity), turn, mirror, reflection, meet, met (couple, at), not yet, so far, discovery, technology, travel, observer. A living file's own word may be cited in *italics*.

## The report file

Plain text, one block for each numbered paragraph, in order, none left out:

```
### <number>
VERDICT: <RESOLVED | SAID | NOVALUE | RESAY | KEEP>
CONCEPT: <the one thing the paragraph carries, in a short plain clause>
EVIDENCE: <as above>
NEW: <for RESAY alone: the new paragraph on one line; otherwise a single dash>
```

Then one closing section:

```
## READING
<whether each paragraph was read and checked, which living files and mates were read, and anything you could not find>
```

Then return, as your final message, only: the path of your report, and the number of each verdict.
