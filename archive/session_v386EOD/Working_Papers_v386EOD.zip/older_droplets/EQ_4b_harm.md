### 122
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 123
CHECK: OK
WHY: Natural_Intelligence_v380R.md line 131 (within 2.2, lines 127 to 134) and Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md line 203 (3.3) and its table row at line 211 each have NEW's quotation by exact search; the source, carryings/session_v377/Session_Report_v377.md line 192, laid beside NEW has each of 2.2, 3.2, 3.3, the self's 6, no self's 1 and the Missing; paragraph 134 finds it by the title's subject words.
SAFER: -

### 124
CHECK: OK
WHY: Natural_Intelligence_v380R.md line 154 (2.4) has the quotation and the table above it has joint forms still "two, prior and now agreeing", "one", "one" and "none"; step 368 of the Registry at git 5e5b1ab is word for word step 506 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (line 2232); four, ten and the Missing are in NEW as the prior has them.
SAFER: -

### 125
CHECK: OBJECT
WHY: One narrowing, small. The prior has "an observing or a form at the code that parts the two", with no comma, as its source has it (carryings/session_v377/Session_Report_v377.md line 194) and as concern 8 of this mate has it (line 67); "at the code" can be of the form alone or of both. NEW's two commas, "an observing, or a form at Exhibit ONE Natural Resolver's code, that parts the two", lay the code at the form alone. The rest is as the prior has it: the living file's 1.3 has "its empty centre the between" and no "fuzzy" at any line, so the paragraph is not resolved, and "the code" as Exhibit ONE's is at the source's line 91.
SAFER: **Droplet · The between's centre, empty or fuzzy.** The centre of the between is said as empty and is said as fuzzy, and the two sayings are open beside each other. Missing is an observing or a form at Exhibit ONE Natural Resolver's code that parts the two.

### 126
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 127
CHECK: OBJECT
WHY: The strength is changed. The prior is one of the things open, said by what is missing (its source's heading at carryings/session_v377/Session_Report_v377.md line 188 is "What stays open, hardest first, each as what is missing"): "Missing: each chained at … steps 38 to 44 and 131 to 134; the carrying's concerns 2 and 6 still name the code, to be re-said." NEW says it as a possible project, "The work is each chained …", and closes "It may change or never be made.", which the prior does not have; a thing missing and a thing intended are said as possible work that may never be made (the first reader's rule 4), where 123, 124 and 125 of the same list have "Missing is". NEW has "Open together", and "with this mate's concern 2" where the prior lists three; "still" of "still name the code" is gone. Confirmed and not objected: steps 38 to 44 and 131 to 134 at git 5e5b1ab are sentence for sentence steps 42 to 48 and 143 to 146 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md; concerns 2 and 6 are at this mate's lines 97 and 99, each naming the code; the living file's 2.1 names no step.
SAFER: **Droplet · 2.1 and this mate's concerns 2 and 6, open.** Open at Exhibit TWENTY-EIGHT Equilibria Registry are its 2.1, *not possibly existing as a method*, this mate's concern 2, and this mate's concern 6: three of the ten seated at names at which the code carries the joins and the sharing. Missing is each chained at Exhibit THIRTY Co-Chaining Logic Registry's steps 42 to 48 and 143 to 146, and this mate's concerns 2 and 6, each still naming the code, re-said.

### 128
CHECK: OK
WHY: the report is whole at carryings/cohering_ten_and_six_v377/README.md (its headings read) and that folder is named at carry/Exhibit_TWENTY-EIGHT_Carryings_of_Equilibria_Registry.md line 9; the paragraph has a place and a list of parts and no concept, concern, condition or work, and no paragraph of carry/*.md points at it.
SAFER: -

### 129
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 130
CHECK: OK
WHY: Exhibit_ONE_Natural_Resolver_v380R.md line 481 has "| Four-cycle: each move 8 up (n + 8), 8 down (n − 8) or 17 less (17 − n) |", its table of twelve forms (line 590) has "each move 8 up, 8 down, 4 up, 4 down or 17 less", the four-cycles opening at 1 and 3 go "8 up first" and those opening at 2 and 4 "17 less first" with an "8 down" row at each of 9 to 17; this file's 3.2 has the column and its four rows; the one other place with "up by eight" in carry/*.md is the record of the same paragraph's release at Offerings to Natural Resolver (Carryings of Living File Registry line 819).
SAFER: -

### 131
CHECK: OK
WHY: archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_concern_7_v377.md read whole: it has "most of the files counted say the between *a nothing*, which is kept, and six say *no existing thing* or its like" and the first opening "**7. Ten files say the between a nothing.**"; concern 7 is at this mate's line 65 with the subject words NEW names it by; NEW has the ten, most, six, "or its like" and the archive's place.
SAFER: -

### 132
CHECK: OK
WHY: carry/Session_Record.md line 2022 has the working merged at main at v377, pull request 113, and archive/carrying_v377/ has the prior sayings; a session's note of its branch with no concept, concern or condition, and no paragraph points at it.
SAFER: -

### 133
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md section 2 read: a version and two numbers of a carrying with none of their content; it names no concern, lays no condition on a paragraph beside it, and no paragraph points at it.
SAFER: -

### 134
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 48 is the prior's sentence, the third of "Open, hardest first", and NEW has its three in order; "one twenty-four at both" is at Natural_Intelligence_v380R.md line 192, within 3.2 (lines 178 to 203), the very sentence of the twenty-four; the second and third are found at 123 and 124 by their titles.
SAFER: -

### 135
CHECK: OK
WHY: the root has no file of version 368, no Natural_Intelligence_v345a.md and no Equilibria Definitions (git 7060704 and d246ca5 are the two deletings, bdf5ef1 and 45541cc the addings); files.json lists the four at v380R and v380L and Natural_Intelligence_Corus_v330.md; both quotations of Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md are exact; the placing is whole at carryings/v368_sources/Wrap_v368.md lines 9 to 21, and no paragraph points at it.
SAFER: -

### 136
CHECK: OK
WHY: a list of checks of a placing whose four files are at the root no longer; the four fingerprints open the four lines of kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/living_file_checks/checks_for_the_living_files_v368/living_files_v368.sha256 (read) and are at carryings/v368_sources/Wrap_v368.md lines 25 to 30; no concept, concern or condition, and no paragraph points at it.
SAFER: -

### 137
CHECK: OBJECT
WHY: A number and a name of the prior are at no living file, as the first reader's own EVIDENCE says. "41 of 41 checks" and the subtitle "Impossible Stable Forms of Existing" are at no file at the root of /home/claude/corus (searched each living file) and, in carry/*.md, at this mate's lines 325 and 343 alone, which are this paragraph and 146, both proposed for release; released together, the two are at the kit's returned text (kits/…/checks_for_the_living_files_v368/twenty_eight_at_the_code_v368_returned.txt line 42, "41 of 41 hold") and at carryings/v368_sources/ alone, neither a living file nor a later section. The first reader's rule 3 has this case as RESAY for that part, or KEEP. The rest is confirmed: the living file's 4.1 has "**Each conception arrives whole, in its own words, with its conserving relation and its reach.**", its 4.2 has "**The specified accounts and the prior worked definitions, SA01 to SA21, are placed the same way.**", and the tables of 4.3 to 4.12 have the columns "Field" and "The changing it names". What would be lost is a tally and an earlier subtitle of a version no longer at the root; it is small, and it is the whole of the objection.
SAFER: KEEP

### 138
CHECK: OK
WHY: carryings/v368_sources/Wrap_v368.md lines 34 to 41 name the four files and have "Each names no other exhibit and points to no section, file or link."; carryings/v368_sources/Carry_Set_v368_README.md line 17 has "each file's next improving runs them first"; the checks are at kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/living_file_checks/checks_for_the_living_files_v368/ (listed: four scripts, their returned texts, the sha256 list; the kit's README line 28) and "checks_for_the_living_files" is at no other place of the root, kits or carry/.
SAFER: -

### 139
CHECK: OK
WHY: NEW's sentence is the prior's sentence word for word with the five words in italics as carryings/v368_sources/Wrap_v368.md line 73 has them; the releasing is said as the prior says it; the same paragraph is at carry/Exhibit_SEVEN_Offerings_to_Natural_Societies.md line 51 in these words; no pointer at this copy.
SAFER: -

### 140
CHECK: OBJECT
WHY: Lost, changed and added, each small. (1) Lost: "closing". The prior has "It releases the single naming closing at all or none at all"; NEW has "The agreeing of each gives the single naming, at all or none at all", with "releases" as "gives" and "closing" gone, where 141 of this same report has the same phrase whole ("releases the single naming closing at all or none at all"), as the source's column has it (carryings/v368_sources/Carry_Set_v368_README.md line 32). (2) Changed: "The ten is settled at v368" is "The ten were agreed at version 368"; *settled* is no word set aside and 141's NEW has it. (3) Added beside the prior: "Natural Naming parts these at "Four pairs are two concepts at two names, the meaning changing on transposing"" and "the eight bi-couplings", from Exhibit_TWENTY_Natural_Naming_v380R.md lines 586 to 590 (the quotation is exact); the prior has seven namings open for both to agree and says nothing of four of them parted, and NEW's "Open are" then has three open where the prior has seven. An earlier second reading passed these very words at Offerings to Natural Naming (NN_2_harm.md, block 53; that mate's line 187), where the quotation is that mate's own living file; laid beside this prior, the three things above are still so. The SAFER paragraph has the prior's seven as they are and nothing from Natural Naming.
SAFER: **Droplet · The namings open for both to agree.** The namings open for both to agree are these: bi-co-podaling or transmissioning, which names a file's title too; three sets of four boundings; two fives under one word; floating neutral or floating neutralling; the tangential changing at the co-sequential nine; the centre at the local face and the station at its two *turns*; and the version 368 carry set's own name. The ten is settled at version 368: the ten ways, each named. The settling of these namings releases the single naming closing at all or none at all.

### 141
CHECK: OK
WHY: carryings/v368_sources/Carry_Set_v368_README.md lines 47 to 57 read: the ten is the fifth row of "The five namings held at Natural Naming, each with its reason", "settled at v368 in THIRTEEN and TWENTY-EIGHT", its reason "one gathering at one naming", and "What it releases" is "The single naming closing at all or none at all, which every file's improving waits on"; NEW has each, the wait said as a condition of each file's improving.
SAFER: -

### 142
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 143
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 144
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 145
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 146
CHECK: OBJECT
WHY: Two standings and a number of the prior are at no living file, and the living file now has the opposite of one. (1) "*read* released" of this file at version 368 is at this paragraph alone in carry/*.md (the wrap's table has it of Natural Intelligence and Exhibit THIRTEEN, and the row of carryings/v368_sources/Carry_Set_v368_README.md line 186 alone has it of this file); the living file now has "**Read across a row, a subject shows those of the ten at which its fields name the changing still; read down a column, the subjects naming one still gather.**" at 4.13 (line 480), so the releasing is undone there, and with this paragraph gone no mate says it was once done, beside 139's each file releasing *read* at its own improving. (2) "naming no other exhibit" of this file would be at 138's NEW alone, said of four files. (3) "41 of 41 checks" and "Impossible Stable Forms of Existing" are at no living file and, in carry/*.md, at this paragraph and 137 alone, both proposed for release. The first reader's EVIDENCE says each of the three is "of no file now"; its rule 3 has that as RESAY for that part, or KEEP. Confirmed and not objected: the placing is done (files.json line 30; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md has "| **TWENTY-EIGHT · Equilibria Registry** | Not Possibly Existing, Living or Non-Living | v380L |"; git d246ca5 is the deleting of Equilibria Definitions v363), and no paragraph points at it.
SAFER: KEEP


## READING

Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_4b.txt (paragraphs 122 to 146); the PROPOSED file EQ_4b_report.md, each of its twenty-five blocks and its READING; and the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md, 542 lines.

Read in part: the mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md at its lines 1 to 75 (the opening, the insertlets, and the numbered concerns 1, 3, 4, 5, 7, 8, 9 and 10 of the older section), 97 to 99 (concerns 2 and 6), 255 to 364 (the paragraphs of this portion and those beside them) and 565 to 682 (each later section headed v385A or v386EOD); the rest of the mate by search.

Checked by exact search and by reading the lines found:
- Natural_Intelligence_v380R.md: the quotations of 123, 124 and 134 (lines 131, 154, 192), the table of 2.4, and the section each line is within (2.2, 2.4, 3.2).
- Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md: steps 42 to 48, 143 to 146, 504 to 506 and 522, each laid beside steps 38 to 44, 131 to 134, 366 to 368 and 380 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v376.md at git 5e5b1ab.
- Exhibit_ONE_Natural_Resolver_v380R.md: the table of four four-cycles (line 481), the table of twelve forms (lines 588 to 603), each "going 8 up first" and "going 17 less first", each row "8 up" and "8 down".
- Exhibit_TWENTY_Natural_Naming_v380R.md: lines 584 to 592, the four pairs.
- Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md: the three quotations given at 135 and 146.
- Sources: carryings/session_v377/Session_Report_v377.md lines 186 to 200 and 245 to 258; carryings/session_v378/Session_Report_v378.md lines 15 and 44 to 50; carryings/v368_sources/Wrap_v368.md lines 5 to 45 and 70 to 74; carryings/v368_sources/Carry_Set_v368_README.md lines 15 to 17, 26 to 34, 45 to 60 and 184 to 188; carryings/cohering_ten_and_six_v377/README.md at its headings; archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_concern_7_v377.md whole; the kit's folder checks_for_the_living_files_v368/ (its listing, the sha256 list, the returned text's line 42) and the kit's README line 28.
- The root and git: no file of version 368 at the root, files.json, and the commits adding the four files and deleting Natural_Intelligence_v345a.md and Equilibria Definitions v363.
- Pointers, over the mate and carry/*.md: "the preceding", "concern above", "droplet above", "existing concern", "current droplet is at", "at this mate of", "this mate's concern", each link into this mate by its anchor (nine anchors, each a section headed v385A, none into the older Droplets), and each released paragraph's own subject words ("up by eight", "seven files cohered", "ready for the lead's review", "four ready and thirteen", "serves corus.me", "fingerprint", "ready to place", "41 of 41", "Impossible Stable Forms of Existing", "checks_for_the_living_files"). No pointer at a released paragraph was found; "41 of 41" and the earlier subtitle are at 137 and 146 alone.
- Earlier second readings, read after my own checks for how the same paragraphs were judged: NN_2_harm.md block 53 (the paragraph of 140), SO_1_harm.md and HP_1_harm.md (the paragraph of 139), GM_2_harm.md block 49, NW_2_harm.md block 51 and XP_1_harm.md block 17 (rows of the same table as 146).

The words set aside were searched in each NEW of the PROPOSED: *held*, *turn* and *turns* alone, each cited in italics. Each NEW and each SAFER paragraph is within forty to one hundred and fifty words, taken by splitting at spaces. The seven KEEP blocks (122, 126, 129, 142, 143, 144, 145) leave their paragraphs as they are and were not checked further.

Three things to know. The objections at 137 and 146 are one finding: the tally "41 of 41 checks", the earlier subtitle, and at 146 "*read* released" are at these two paragraphs alone among the mates and at no living file, so releasing both leaves them at the kit and the sources alone; either left as it is carries them, and 146 is the one that has all three. The objection at 140 parts from an earlier second reading that passed the same words at another mate; the things lost and added are named one at a time for weighing. The objection at 125 is two commas.

No file in /home/claude/corus was changed.
