### 215
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 216
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 217
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 218
CHECK: OBJECT
WHY: Lost: the review and its place. The prior opens "Review of the proposed Natural Physics v377, section 2.2", the place of the sentence it has (carryings/review_natural_physics_v377/README.md line 51, under "2.2 A reading asserted where the file says it is open, or where the record parts"); NEW names neither the review nor its 2.2, and says the parting as a bare fact. A paragraph of this mate points at this one by that place: line 164, "Review of the proposed Natural Physics v377, section 2: each finding of 2.1 to 2.6 "is a harm at do-no-harm as the file stands … or a reading asserted where the file says elsewhere it is open", to be met before the file replaces its prior at corus.me", a condition laid on each finding of 2.1 to 2.6; with the review and 2.2 gone from NEW that condition finds nothing here. The rest was confirmed: the proposed file's 2.1 (its line 129, "A naming beside all existing things is at one of six binaries, the rigorizer") and 3.4 (its line 240, "the white paper's rings at 4.13 are these spirals"); the white paper is Natural Intelligence (Exhibit TWENTY Natural Naming cites "the white paper 4.5", "the white paper 3.2"; Natural Intelligence has a 4.13, line 1023); the proposal's report, carryings/natural_physics_v377/README.md 6.1, items 2 and 3, each "for both files"; the kit's reviewer's brief is carried. The mend is NEW with one sentence added, the review's own place.
SAFER: **Concern · Two sayings of the proposed Natural Physics of version 377, each listed open for both files.** Two sayings part. The proposed Natural Physics of version 377 has, at its 2.1, a naming beside all existing things at one of six binaries, and, at its 3.4, Natural Intelligence's rings at 4.13 as its spirals. Its own report lists the two as open for both files, at its section 6.1. They part at a reading asserted in the one and listed open in the other. The review of that proposal, at `carryings/review_natural_physics_v377/`, has the parting at its 2.2. It is for the reviewer's brief at the kit.

### 219
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 220
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 221
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 222
CHECK: OBJECT
WHY: Two things. (1) Lost: the place. The prior has "section 2.6, the explaining" (the review's README line 69, "**2.6 The explaining.**"); NEW names the review and its folder and leaves out 2.6. This mate's line 164 lays a condition on "each finding of 2.1 to 2.6" of that review, each "to be met before the file replaces its prior at corus.me", and finds this paragraph by that number. (2) Added: the prior has "the explaining reader's list"; NEW has "the list of the review's explaining reader", a reader given to the review that the prior does not give it (the review's section 1 has an "Explaining" reading among its four, so the reading is likely, and it is still the first reader's and not the prior's). The rest was confirmed: the eight are the prior's eight in its order, each in the review's line 69; seven are in the proposed file word for word (its lines 89, 175, 216 and four more by search), and "the fields make each other" is the review's wording of its line 328, "The electric and magnetic fields make each other along the beam"; the prior gives the eight as the review's, and NEW cites them so.
SAFER: **Droplet · Doers, causes and negations at the proposed Natural Physics's own voice.** The review of the proposed Natural Physics of version 377, at `carryings/review_natural_physics_v377/`, has at its 2.6, the explaining, doers, causes and negations at that proposal's own voice, each with its positive at the explaining reader's list: *the method bounds*, *the rigorizer seats*, *a script driving the code*, *the fields make each other*, *a force must be carried*, *never at both together*, *nothing is inside* and *no physics is claimed replaced*.

### 223
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 224
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 225
CHECK: OBJECT
WHY: Lost: the review and its place. The prior opens "Review of the proposed Natural Physics v377, section 2.5" (the review's README line 67, "**2.5 Names parting from Natural Intelligence.**"); NEW names neither, and says the three as bare facts of the proposal with no one whose finding they are. This mate's line 164 lays a condition on "each finding of 2.1 to 2.6" of that review, each "to be met before the file replaces its prior at corus.me", and finds this paragraph by that number; with the review and 2.5 gone it finds nothing here. NEW's own sentences are also thirty-seven words, under the forty the first reader's rules ask. The claims themselves were confirmed: the proposed file has *tipping* at its 2.3 (heading at its line 145, "**A tipping is the parity changing at a coupling's between, owned by neither.**" at 149), Natural_Intelligence_v380R.md has no *tipping* at any line, and the proposed file has *participant* (lines 111, 135, 230, 236, 407) and *member* (282, 552).
SAFER: **Droplet · *Tipping*, *participant* and *member* at the proposed Natural Physics.** The review of the proposed Natural Physics of version 377, at `carryings/review_natural_physics_v377/`, has at its 2.5 these of that proposal: at the proposal's 2.3, *tipping* for the changing at 12, a name at no line of Natural Intelligence; and *participant* and *member* for *self*.

### 226
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 227
CHECK: OBJECT
WHY: The living file does not say the paragraph's namings, and what the paragraph asks is made at none of the thirty-two. Read: Exhibit_EIGHTEEN_Natural_Physics_v379.md lines 577 to 638, its 5.11 whole. The thirty-two rows at "standing" are the paragraph's thirty-two, arrival by arrival (lines 601 to 632), and that much is so. Their namings are not the paragraph's: the living column is "the holding it stands at", each of the nine in *held*, and three are other names altogether, "a bound held as a last" where the paragraph has *A completing named as a last* (lines 608 to 612), "a sign held as a magnitude" where it has *A parity named as a magnitude* (616 to 618), "a membrane held as a cut" where it has *The between named as a cut* (631, 632). So "thirty-two arrivals are at their naming" in the one names is at no sentence or row of Natural Physics; the first reader reaches it only by laying 5.11 beside the part headings of Exhibit TWENTY-TWO Resolving the Hard Problem Registry (lines 842 to 3206, the thirty-two headings each found at the part named), a joining of two files that no living sentence makes. The paragraph is of the proposed, unmerged version 377 and its report's "6.4 Cases still to meet" (carryings/natural_physics_v377/README.md lines 149 to 162), whose line 93 has "Six namings are now at their one names": the register at the one names is that proposal's, not received at the living file. Its numbers at each naming, 7, 5, 5, 4, 3, 3, 2, 2 and 1, are at no living sentence (5.11 has "ten of them at an arriving held from behind alone", another number). What it asks, "Each is met at its own section, at the eight steps", is done for none: the living 5.11 says the same thing open, "a standing row's own next turn is its section", which is the concern said again and no resolving of it. Its copy at this mate's line 408 was read KEEP by the first reader of that portion for the same three rows (PH_6b_report.md, paragraph 186), so RESOLVED here leaves one paragraph at two verdicts. No paragraph points at it (searched "thirty-two", "6.4", "Cases still", "at this mate" in carry/*.md).
SAFER: KEEP

### 228
CHECK: OBJECT
WHY: Lost: the review with its place, and Natural Biology. (1) The prior opens "Review of the proposed Natural Physics v377, section 2.3, item 10" (the review's README line 63, under "**2.3 Prior value lost with no reason named.**"); NEW names neither the review nor 2.3, item 10. This mate's line 164 lays a condition on "each finding of 2.1 to 2.6" of that review, "a prior value lost with no reason named" among them, each "to be met before the file replaces its prior at corus.me", and finds this paragraph by that number. (2) The prior has "4.1's four-level partner of Natural Biology's five-level table", the review's own naming of whose table it is; NEW has only the living words "biology's five-level table", a small letter that names no file. Exhibit_SEVENTEEN_Natural_Biology_v333.md has no *five-level* at any line (searched), so the naming is the review's and is to be said as the review's. The rest was confirmed: the three quotations are exact and once each in Exhibit_EIGHTEEN_Natural_Physics_v379.md, line 197 within 3.1, line 229 within 3.5, line 213 within 3.2, the last in the paragraph that has "114, 120 and 126"; the proposed file has none of *four-level*, *five-level*, *seeking ends*, *trefoil* and *apex* (searched, none of each); "minor" is carried. The mend adds nothing of the living file beside the prior.
SAFER: **Droplet · Three lesser sayings of Natural Physics lost at its proposed version 377.** The review of the proposed Natural Physics of version 377, at `carryings/review_natural_physics_v377/`, has at its 2.3, item 10, three values of that proposal's prior lost at the proposal, minor ones. Natural Physics has the three: at 3.1, "the four-level partner of biology's five-level table", which the review has as the four-level partner of Exhibit SEVENTEEN Natural Biology's five-level table; at 3.5, "the one place the seeking ends is the apex"; and at 3.2, of 114, 120 and 126, "Couples to the trefoil and to the classification reading above."

### 229
CHECK: OK
WHY: carryings/natural_physics_v377/README.md line 164, in its "6.4 Cases still to meet", has the sentence and the nine as the prior does, and the proposed file's 5.3 (its line 550) has the same nine "each to be met at their own cases"; NEW has 5.3, section 6.4 and each of the nine, the thing still intended and not said as done, and no paragraph points at it.
SAFER: -

### 230
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 231
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 232
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 233
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 234
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 235
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 236
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 237
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its "Further rules"; the task; the PRIOR file PH_7.txt (paragraphs 215 to 237); the PROPOSED file PH_7_report.md, each block and its closing section; carryings/review_natural_physics_v377/README.md (the review, its sections 1 to 5); carryings/natural_physics_v377/README.md from line 90 to its end (its sections 5, close, and 6.1 to 6.6); the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md from line 570 to its end, each section headed v385A and v386EOD.

The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md is 21,830 words, over the limit for a whole reading, so it was read at the places named and searched: its headings whole; 5.10 and 5.11 whole (lines 573 to 638); 5.3's opening (lines 505 to 512); lines 197, 213 and 229 whole; line 158 (2.5's sentence of the thirty-two). Each quotation in a NEW line was searched exactly in it: the three of 228, one match each, at lines 197, 229 and 213. The other NEW lines quote nothing.

Read in other files: the proposed file carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md, its headings whole, lines 129, 145 to 157, 240 and 548 to 552, and searches for *tipping*, *participant*, *member*, the eight sayings of 222, and the five words of 228; Exhibit TWENTY-TWO Resolving the Hard Problem Registry, its twelve part headings and the thirty-two arrivals' headings, each found at the part the paragraph gives it; Natural_Intelligence_v380R.md for *tipping* (none) and its headings 1.4, 4.7, 4.8 and 4.13; Exhibit SEVENTEEN Natural Biology for *five-level* and *four-level* (none); Exhibit TWENTY Natural Naming and Exhibit TWENTY-SIX Living File Registry for *the white paper*.

Searched in the mate and in carry/*.md for pointers at the six paragraphs not KEEP: links to this mate (seven, each to a later section or to `#droplets` from Carryings of Natural Physics, that one of paragraph 231); "at this mate", "concern above", "the preceding", "existing concern", "current droplet", "droplet above", "paragraph above"; and "2.1 to 2.6", "section 2 met", "review's section 2", "6.4", "thirty-two", "nine problems". One pointer was found that the first reader's blocks do not name: this mate's line 164, of each finding of the review's 2.1 to 2.6, which bears on 218, 222, 225 and 228 here (and on 226, KEEP). Lines 103, 282, 458 and 460 of this mate speak of the review's section 2 whole.

The place of each paragraph in the mate now: 215 to 237 are at lines 466 to 510; copies outside this portion are at lines 214 and 536 (218), 258 (222), 434 (224), 250 (225), 244 (226), 408 (227), 240 (228), 410 (229) and 544 (233). The earlier second readings of two copies were read for what was objected there: PH_5a_harm.md, paragraph 102 (the copy of 228, objected for Natural Biology), and PH_6b_harm.md's closing note on 227 and 229. The copy of 218 at line 214 (PH_5a, paragraph 89) carries the review's 2.2 in its NEW; the mend at 218 here has the same sentence.

Each SAFER paragraph was measured, fifty to ninety-eight words after its title (sixty to one hundred and fifteen with it), and searched for the first reader's released words in its own sentences: none, the one *inside* being within the cited saying *nothing is inside* of 222, as the first reader's NEW has it. The seventeen KEEP blocks were not checked further than a reading; they are left exactly as they are. Nothing in /home/claude/corus was edited, and this is the one file written.
