### 238
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 239
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 240
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 241
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 242
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 243
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 244
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 245
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 246
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 247
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 248
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 249
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 250
CHECK: OBJECT
WHY: Lost: the named place "Review of the proposed Natural Physics v377, section 2.2", and with it a condition laid on this paragraph. The prior says whose finding it is and at which section; NEW names the proposal's 2.1 and 3.4 and its report's 6.1 and has no review and no 2.2. Three paragraphs of this mate find this one by that place: line 164, "Review of the proposed Natural Physics v377, section 2: each finding of 2.1 to 2.6 "is a harm at do-no-harm as the file stands … or a reading asserted where the file says elsewhere it is open", to be met before the file replaces its prior at corus.me", and lines 95 and 103, "section 2 of the review … the readings asserted where the file says them open" and "each item of the review's section 2 stands" (each read at the mate). Line 164 stays at the mate re-said by the same words ("Each finding of the review's 2.1 to 2.6", PH_4b_harm.md paragraph 64), so the condition is still laid, and with NEW it no longer finds this finding. The first reader's EVIDENCE has "No pointer to this paragraph was found"; the copy at mate line 214 was re-said with the review's place for this reason (PH_5a_report.md paragraph 89). Everything else is right, read at the sources: carryings/review_natural_physics_v377/README.md line 51 (its 2.2) has the sentence; the proposed file has "A naming beside all existing things is at one of six binaries" in its 2.1 (line 129) and "the white paper's rings at 4.13 are these spirals" in its 3.4 (line 240); the proposal's report has both in its 6.1, items 2 and 3 (carryings/natural_physics_v377/README.md lines 102 to 108); the white paper is Natural Intelligence (carryings/resettling_v373/Re-Settling_the_Living_Files.md, section 4, "Natural Intelligence as the white paper"), whose 4.13 is at line 1023 now; the living Natural Physics v379 has neither sentence (searched "six binaries", "these spirals", "white paper"). NEW has no quotation, adds nothing, narrates no session, and has none of the excluded words (85 words).
SAFER: **Concern · Two sayings of the proposed Natural Physics of version 377, each listed open for both files.** Two sayings part. The proposed Natural Physics of version 377 has, at its 2.1, a naming beside all existing things at one of six binaries, and, at its 3.4, Natural Intelligence's rings at 4.13 as its spirals. Its own report lists the two as open for both files, at its section 6.1. They part at a reading asserted in the one and listed open in the other. The review of that proposal, at `carryings/review_natural_physics_v377/`, has the parting at its 2.2.

### 251
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 252
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 75 (section 2, the first of its five findings; the file is headed "first draft, session v373") has each clause, file, section number and percentage of the prior and NEW has each of them and no more, the past form at version 373 being the prior's own closing mark and matching the living files having moved (Natural Intelligence has six parts and no 7.2; the first sentence is at three living files and *aberration* at two); both quotations are exact by search, the first at Natural Intelligence line 1134, Exhibit TWENTY Natural Naming and Exhibit TWENTY-EIGHT Equilibria Registry, the second at Natural Societies 1.1 (line 95), Natural Health 1.1 (line 57), Natural Medicine 1.1 (line 87) and Natural Destinies' core (line 39), with Natural Values 4.1 (line 143) saying it again in other words; no paragraph of this mate points at it or is laid on it (lines 438 to 454 and 538 to 542 read at their opening words), and the pointer at four other mates, "The v373 source already identifies the repeated selecting/sign-only/summing/+1 sentence", finds it by version 373 and the core coupling sentence.
SAFER: -

### 253
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 254
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 255
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 256
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 257
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 258
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 259
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 260
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 261
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 262
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 263
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 264
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 265
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 266
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 267
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 268
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the task, the brief HARM3.md, the first reader's brief BRIEFO3.md with its further rules, the PRIOR file PH_8.txt (paragraphs 238 to 268, thirty-one) and the PROPOSED file PH_8_report.md. Twenty-nine blocks of the PROPOSED are KEEP and are left as they are; two are RESAY, 250 and 252, and each was laid beside its prior, clause by clause.

The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md is 21,830 words, over 15,000, and was not read whole; no block of this portion is RESOLVED, and it was searched for "six binaries", "these spirals" and "white paper" (none of the first two; the proposal is unmerged at it). Other living files, by exact search across each file at the root of /home/claude/corus: the two quotations of 252's NEW, each found once at the files named in that block, and the heading above each found line read (Natural Societies 1.1, Natural Health 1.1, Natural Medicine 1.1, Natural Destinies' core, Natural Values 4.1); *aberration* (two living files); Natural_Intelligence_v380R.md at its parts' headings, line 1023 (4.13) and line 1134.

The mate, carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md, is 31,477 words and was not read whole: its headings; lines 95, 103 and 164; the three copies of paragraph 250 at lines 214, 472 and 536; lines 156 to 270 at their opening words (the review's findings, each named by its section) and lines 438 to 454 and 538 to 542 at theirs; and searches for "the preceding", "concern above", "droplet above", "Re-Settling", "Five findings" and "§2". carry/*.md was searched for "v373 source", "restat", "common method" and "one of six binaries"; carry/Offerings_to_Natural_Intelligence.md line 137 and carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 171 were read, each under its older "## Droplets".

Sources read: carryings/review_natural_physics_v377/README.md lines 14 to 22 and 45 to 53; carryings/natural_physics_v377/README.md lines 98 to 112, and Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md lines 129, 240 and 242 with its headings of Part Two and 3.4; carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 1 to 12, its headings and lines 70 to 80.

Earlier readings of the same two paragraphs at their copies, read for how the copies lie and trusted for nothing: NI_1_report.md and NI_1_harm.md paragraph 13; PH_5a_report.md and PH_5a_harm.md paragraph 89 (mate line 214); PH_7_report.md (mate line 472); PH_4b_harm.md paragraph 64 (mate line 164); PH_6b_report.md and PH_6b_harm.md paragraph 202 (mate line 440); NN_2_report.md and NN_2_harm.md paragraph 43.

Each NEW line and the SAFER line were searched for the first reader's excluded words apart from quotations, italics and code marks (none), and their words numbered: 85 (250), 149 (252), 98 (the SAFER of 250).

The copies of 250. The paragraph is three times in this mate. At line 214 the re-saying second-read as sound has "at its section 6.1, of concerns with another file" and the review's place; at line 472 the first reader's NEW has neither and closes "It is for the reviewer's brief at the kit."; at line 536, this portion, it has neither. The SAFER here adds the review's place alone and leaves out "of concerns with another file", which this prior does not have (the heading of the proposal's 6.1 is "Concerns shared with another file", so the clause is true and is no claim). With the review's place the copies at 214 and 536 differ by that one clause; the copy at 472 wants the review's place for the same reason.

Not opened: the publishings linked in the KEEP paragraphs. No file in /home/claude/corus was edited; this report is the one file written.
