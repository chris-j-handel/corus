### 73
CHECK: OBJECT
WHY: No claim of the prior is lost or misquoted: the quotation "Offering runs first and rigoring second, and a front asks nothing performed first." is an exact sentence of Exhibit_TWELVE_Natural_Explaining_v378.md at section 1.3 (line 80, read with its paragraph), and the session is v382F (the same paragraph is at carryings/v382F/Session_Report_v382F.md line 35). Two things part from the prior and the first reader's rules. NEW's second sentence, "A home page prototype made unasked at session v382F was released by the expedition's self.", narrates a session, and the instance cannot be said without that narrating. And the prior's aiming, "Aimed at the set", is at no word of NEW; NEW also has "both selves" at the prior's "both". The prior is clear as it is, and the mate's line 111 has the same text in the same older section, no later place.
SAFER: KEEP

### 74
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 75
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 76
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 77
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 78
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 79
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 80
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 81
CHECK: OK
WHY: the quotation is exact at the living file's line 306 under 4.2, and the numbers 1, 2, 4, 8, 16, 31, four doublings, five powers of two, at most 46, 2024 and the address are each in NEW as in the prior and as at carryings/v383Op/Corrections.md line 41; no pointer to it in the mate or carry/*.md; the report's name and its correction number alone leave.
SAFER: -

### 82
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 83
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 84
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 85
CHECK: OK
WHY: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 223, under "## Natural Exploring and Geodesic Improving Method proposed combination · v385A", is the prior character for character once the re-aiming note is taken off (compared by script, 983 characters each), a section headed v385A and no older Droplets section; carry/Exhibit_TWENTY-FOUR_Possibling_of_Geodesic_Improving_Method.md line 5 to 7 links that mate's master plan, whose row at line 34 names the combination; no paragraph of the mate or of carry/*.md points at this one, the "Next at this file" sentence at line 21 naming the combining and no droplet.
SAFER: -

### 86
CHECK: OBJECT
WHY: The living file says two of the three and not the third. Read at Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md: "A version is a momentary of the file: its carrying at its prior arrives whole at its next." (line 124, 1.6) and "The same three run at a session, which meets the set at its now and opens its next, and at a sentence, which meets the whole prior co-chaining at its now and adds its next." (line 58, 1.1) are present; "four given" and "four improvings" are at no line of it (Grep, no match). The one living place is Exhibit_TWELVE_Natural_Explaining_v378.md line 320, narrowed to "four improvings at an explaining". The passage the paragraph sends to this file, carryings/resettling_v373/Natural_Intelligence_v373_Released.md 7.10 (lines 671 to 677, headed "Receiving: Geodesic Improving Method"), also has the four alternating, "orthogonal at each", "none is a floor" and "a total across the four is one side taking each opening"; Grep finds none of these at a living file or at a mate. The relation that the Geodesic Improving Method receives the four given and four improvings is at no living file, and this paragraph is the one place in carry/*.md naming that receiving (Grep of "four given" in carry/*.md: this paragraph, a concern at Offerings to Natural Explaining about 4.2, and the Session Record). The first reader's own EVIDENCE says the block is KEEP on this reading.
SAFER: KEEP

### 87
CHECK: OK
WHY: the three clauses of the prior, as at carryings/session_v378/Session_Report_v378.md line 40, are each in NEW at the same strength (chaining the test and no executing the test; an executing at Exhibit ONE's code showing the code as written; executings and their numbers at the Session Record and the carryings), with no quotation, nothing added and no session narrated; the report's name alone leaves.
SAFER: -

### 88
CHECK: OK
WHY: the number three and each parting's own words (hardest first against of no size; readers latest to first; six binaries against five, the doer open at Natural Intelligence 1.4) are in NEW as at carryings/session_v378/Session_Report_v378.md line 49, and the three quotations are exact at the living file's lines 170, 340 and 192 (one match each); the quotations are the first reader's placing, each having the parting's own words, and Natural_Intelligence_v380R.md 1.4 still names five with no doer, so "unresolved" is the prior's "Open"; no pointer to it found.
SAFER: -

### 89
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 90
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 91
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 92
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 93
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 94
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 95
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 96
CHECK: OBJECT
WHY: Nothing of the prior is lost or misquoted: "A file tours with its cluster." is exact at the living file's line 264 under 3.3, and seven readers, the seven words with their fellows, the three things passed by, one droplet at each file with the places as a map, 178 droplets, 32 files, the files no session had aimed at, and the method of finding as v382F's are each in NEW. The objection is one: three of NEW's four sentences narrate a session ("At session v381R seven readers each had one released word or dissolved naming", "Each read each hit in its sentence ... and dropped one droplet at each file", "The method of finding is session v382F's"), which the first reader's rules for NEW exclude, and the instance with its numbers cannot be said without that narrating. The prior is clear as it is and waits on nothing.
SAFER: KEEP

### 97
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 98
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 99
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 100
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 101
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 102
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 103
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 104
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 105
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 106
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 107
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 108
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM.md; the first reader's brief BRIEFO2.md with its Further rules; the PRIOR file GM_3.txt, paragraphs 73 to 108; the PROPOSED file GM_3_report.md, each of its thirty-six blocks and its READING; the living file Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md, lines 1 to 395 (9,809 words); and of the mate carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md its front and Insertlets (lines 1 to 98) and each section headed v385A and v386EOD (lines 383 to 630). The mate's older Droplets section (lines 99 to 382) was read at its paragraph openings, to match the numbers 73 to 108 to lines 245 to 315, and whole at lines 111, 215, 245, 261, 269, 271, 273, 275, 291, 349 and 363.

Read in part: Exhibit_TWELVE_Natural_Explaining_v378.md section 1.3 whole and line 320; Natural_Intelligence_v380R.md section 1.4; carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md lines 25 to 36 and 215 to 232 with its list of headings; carry/Exhibit_TWENTY-FOUR_Possibling_of_Geodesic_Improving_Method.md lines 1 to 20; carry/Session_Record.md line 2321; carryings/resettling_v373/Natural_Intelligence_Map.md lines 83, 138, 151 and 172; carryings/resettling_v373/Natural_Intelligence_v373_Released.md lines 665 to 680; carryings/session_v378/Session_Report_v378.md lines 40 and 49; carryings/v383Op/Corrections.md line 41; carryings/v382F/Session_Report_v382F.md line 35.

Checked by search: each of the five quotations in the NEW paragraphs by exact search in the living file it names (one match each at the Geodesic Improving Method; one at Natural Explaining); paragraph 85 against the later section by an exact comparison of the two lines; "four given", "four improvings", "more true, less false", "orthogonal at each", "one side taking each opening", "none is a floor" in each living file at the root and in carry/*.md; pointers to the seven paragraphs not KEEP, in the mate and in carry/*.md, by their own subject words, by the phrases "the droplet above", "concern above", "remain whole above", "the preceding", "at this mate of", "at this mate already", "existing concern", "current droplet is at", by links to this mate, and by the name Offerings to Geodesic Improving Method in the other mates. The pointers found are the ones the first reader names (at 74, 75, 76, 77, 83 with 84, and 98), each at a paragraph left as it is; none points at 73, 81, 85, 86, 87, 88 or 96.

The twenty-nine blocks with the verdict KEEP were not checked further, each being left exactly as it is. The objections at 73 and 96 are of the form of NEW (a session narrated, and at 73 the aiming gone) and of no claim lost; the objection at 86 is of a receiving at no living file. No file but this report was written.
