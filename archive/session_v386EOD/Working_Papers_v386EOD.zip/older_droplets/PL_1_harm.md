### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: OK
WHY: laid beside the prior and carryings/physics_for_other_files_v377/README.md 2.3 (line 26) and section 3 (lines 30 to 37): the three seams with their sections and subjects, "one arrival at two names", the ten at their one names, Natural Naming 4.9 and the seventy-six *held* forms are each in NEW at the prior's strength, the seams still said as for Natural Philosophy's own motion and not as done; each named place is at the living files now ("## 3.4 Subject and object", "## 3.7 The flowing now and the block", "## 3.29 Bearer and bundle" at lines 262, 316 and 628 of the living file; "## 4.4", "## 4.8" and "## 4.12" at Exhibit_EIGHTEEN_Natural_Physics_v379.md lines 290, 395 and 469; "## 5.11 Substance and bundle · 102" at Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md line 2007; "## 4.9 The ten named still, one name each" at Exhibit_TWENTY_Natural_Naming_v380R.md line 603); *observer* is the living file's own word (lines 252, 266, 268); NEW leaves out only the report's path and its 2.3 and 3, and paragraph 4's "received the three seams" still finds it by its title.
SAFER: -

### 3
CHECK: OK
WHY: laid beside the prior and carryings/co_chaining_coverage_v378/readings/08_physics_philosophy_emanating.md lines 11, 29 to 37, 64 and 66: the three lists at one set of fixings, 3.15 beside the registry's saying with the selves inward, the one sentence at Natural Philosophy's own motion, the six entered at version 378 in the prior's own words and "for both" are each in NEW; the living file has "one requirement worn four ways" at 1.3 (line 177) and "a carry divides the way a store cannot" at 3.15 (line 438), Natural Physics v379 "worn six ways" (line 120) and "the one error is five" (line 146), and Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md steps 322, 389 and 401 (lines 1447, 1732, 1784); the row at carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 688 ("A carrying dividing at fission, a concern") is of paragraph 31, which is left as it is.
SAFER: -

### 4
CHECK: OK
WHY: laid beside the prior and carryings/natural_physics_v377/README.md line 87 (its section 4): the saying at the second report's section 3 (carryings/physics_for_other_files_v377/README.md line 32, read), its being false, the three sections each saying their seam, the search requiring text after the name, the carrying receiving the three seams with no such sentence and nothing at it leaning on it, and 3.4, 3.7 and 3.29 named are each in NEW; the living Natural Physics v379 has the word Philosophy at no line (searched), so "Physics 4.4, 4.8 and 4.12" is the proposed text's, whose lines 416, 475 and 532 end at "Natural Philosophy 3.4, subject and object", "Natural Philosophy 3.7" and "Natural Philosophy 3.29, which names the two bearer and bundle" now, which bears "ended" and "the proposed Natural Physics of version 377" (the report is titled "Natural Physics v377: the proposed version"); the same re-saying was read and passed at the Natural Physics mate.
SAFER: -

### 5
CHECK: OK
WHY: laid beside the prior and carryings/natural_physics_v377/README.md line 95 (its section 5, "Corrections made at the file after the close"): the sections named at 4.4, 4.8 and 4.12 and Natural Philosophy naming the arrival bearer and bundle at 4.12 are in NEW, and the proposed text's line 532 has "Natural Philosophy 3.29, which names the two bearer and bundle"; the living file has "## 3.29 Bearer and bundle" (line 628).
SAFER: -

### 6
CHECK: OK
WHY: laid beside the prior and carryings/natural_physics_v377/README.md lines 173 to 180 (its section 6.6): the heading, the three pairs, "one arrival at two names, bearer and bundle, and substance and bundle" and each side at its own file are in NEW; the source's "This file keeps its side at the section named" is Natural Physics', so NEW's naming of the two files is the source's, and the proposed text has its side at lines 416, 475 and 532 while Natural Philosophy's side is paragraph 2 at this mate; the living Natural Physics names Natural Philosophy at no line (searched).
SAFER: -

### 7
CHECK: OBJECT
WHY: Lost: whose reading it is and of which session, and with it the strength of three claims. The prior closes "(Re-Settling the Living Files, §2 table) — resettling_v373". Its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md, read at lines 1 to 8, 26 to 38 and 59) is headed "first draft, session v373"; the row at line 59 lies under the column heads of line 38, "Shape at this reading", "Its own subject", "Restating the common method", "Old code or older wording"; and line 28 has "shares of a file by kind are readings, not measurements". NEW says each as a measure of the file now, with no reading named: "About 65% of the file is its own subject, and about 15% restates the common method" and "About 40% of its sentences are at the wording of version 348". (1) The two portions are a reader's estimates by the source's own word. (2) The third is a reading under the head "Old code or older wording", against the naming of version 373; said of a file that is itself at version 348, with no reading named, the sentence no longer says that the wording is the older one, and at the naming now this same mate's paragraphs 20 to 26, each left as it is, map released words at this file at 77, 34, 45, 13, 1, 64 and 48 places. (3) "is at 17,400 words" is the source's figure; the living file is 17,330 words at a plain word search now. Nothing else is lost: 17,400, version 348, Part Four's heading ahead of 3.9 (still so, "# PART FOUR · CO-SEQUENCING" at line 346 and "## 3.9 Cause and effect" at line 348), about 65%, about 15% and about 40% are each in NEW as the prior has them. The mend is the reading named, as the first reader's rule 12 has it, as its own NEW for paragraphs 8, 9 and 14 does, and as the second readings at the like rows of Offerings to Natural Chemistry and to Living Society Registry gave.
SAFER: **Droplet · The shape of Natural Philosophy, at session v373's reading.** Session v373's reading of the living files has Exhibit NINETEEN Natural Philosophy at 17,400 words at its version 348, with Part Four's heading ahead of 3.9. At that reading about 65% of the file is its own subject, about 15% restates the common method, and about 40% of its sentences are at the wording of version 348.

### 8
CHECK: OK
WHY: the row is at carryings/resettling_v373/Re-Settling_the_Living_Files.md line 146 under the heads "Section now", "Explaining in it" and "Proposed home", and NEW has its section, its explaining and its home as a plan's and not as done; "#### Five, and a seam at 8 up" is a heading of carryings/resettling_v373/Exhibit_ONE_v372_Released.md (line 108) and of no line of Exhibit_ONE_Natural_Resolver_v380R.md (searched), so "at version 372" is the named place checked now; the living file has "unreachab" at no line; paragraph 19 is the same paragraph with a re-aiming note and has the same NEW.
SAFER: -

### 9
CHECK: OK
WHY: the row is at carryings/resettling_v373/Re-Settling_the_Living_Files.md line 150, and NEW has its two section titles, its two explainings in the row's own words and its two homes, with no explaining given to either file alone, as the row gives none; "#### The membrane and the eight bi-couplings" and "#### Bi-inversioning-co-recursioning, one move at three faces" are headings of Exhibit_ONE_v372_Released.md (lines 300 and 315) and of no line of Exhibit_ONE_Natural_Resolver_v380R.md (searched), which bears "two sections" and "at version 372"; the living file has "podal", "not possibly" and "ratio reading" at no line.
SAFER: -

### 10
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 173: the craft at four parts, Corus Part 16's remainder, 1.6 and 4.1, 4.2's paragraph, 4.5's surgical method, 4.6's resolver case and each receiving file are in NEW; each place is at Exhibit_TWELVE_Natural_Explaining_v378.md now (headings at lines 100, 300, 310, 338 and 346, the three paragraphs at lines 320, 344 and 352, four parts) and "# Part 16" at Natural_Intelligence_Corus_v330.md line 183; the one number changed, Natural Intelligence 8.6 to 5.4, is at carryings/resettling_v373/Natural_Intelligence_v373_Released.md line 787 ("*Receiving: Re-said at 5.4.*") and Natural_Intelligence_v380R.md line 1085; the sentence left out is of a thing gone: the earlier 8.7's sentence paragraph (v373_Released lines 797 to 803, read) is at no line of Natural Intelligence now (the word "sentence" is at one line, 77, of another subject), and Natural Explaining 2.1 says it still (lines 110 to 112).
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OBJECT
WHY: Two things, both at the second sentence. (1) Added: the verb "is". The prior and its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md line 191, read) have no verb, "Its common crossing, 1.3 and 2.4 to 2.5, at Natural Intelligence as the claim that the form is independent of any substrate's rate", a plan's placing; NEW has "Its common crossing, 1.3 and 2.4 to 2.5, is at Natural Intelligence as the claim …", which says the plan's intended home as the place the crossing is now, and the five placings after it lean on the same verb. It is not so: Exhibit_SIX_Natural_Transmissioning_v330.md has 1.3, 2.4, 2.5, 3.1 to 3.8, 4.3, 4.4 and 4.6 whole still (headings at lines 89, 145, 149, 159 to 187, 204, 208 and 216), and Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md line 625 has "The receiving is planned; no source removal has occurred." A thing intended is said as done (the first reader's rule 4); the title and the closing sentence do not undo a plain sentence of where a thing is. (2) Changed: "3.8's plaza and 4.3" is said "the plaza of 3.8 and 4.3", which reads as a plaza of both sections; the plaza is 3.8's alone ("## 3.8 Social membrane, the plaza, sign between") and 4.3 is "## 4.3 Natural network, transmissionings co-chaining, all-edge", sent whole. The rest was laid beside the prior and the source and loses nothing: each section number, each receiving file, the one change to the agreed receiving with both its reasons, "About 12%", *sum to a bounding-zeroing* (the file's lines 79 and 106 have "sum to a **bounding-zeroing**") and *membrane* as a third. The like re-sayings passed at Offerings to Natural Transmissioning ("goes to") and at Offerings to Natural Chemistry ("A plan made at version 373 has …") say the placing as a going and not as a being.
SAFER: **Possible project · Exhibit SIX Natural Transmissioning receiving and releasing.** Exhibit SIX Natural Transmissioning receives and releases. Its common crossing, 1.3 and 2.4 to 2.5, goes to Natural Intelligence as the claim that the form is independent of any substrate's rate; 3.1 to 3.7 to Natural Engineering's entries and to Natural Chemistry and Natural Biology; 3.8's plaza and 4.3 to Natural Networking; 3.8's conversation to Natural Explaining; 4.4 to Natural Philosophy; 4.6 to Natural Naming. One change to the agreed receiving: the cross-substrate comparison at Natural Engineering rather than Natural Networking, it being one form at many substrates, Natural Engineering's subject, and Natural Networking being already the most overstuffed. About 12% of Exhibit SIX is re-said at the receiving, its *sum to a bounding-zeroing* and its *membrane* as a third among them. It may change or never be made.

### 13
CHECK: OK
WHY: the living file has "# PART FOUR · CO-SEQUENCING" at line 346 (the quotation exact, found there and at the contents, line 111), "## 3.9 Cause and effect" at line 348, "## 3.37" at line 740 and "## 4.1" at line 754 with no part heading ahead of it, so the heading, its line, 3.9 and the seams 3.9 to 3.37 under Part Four are each in NEW and each so at the file now; the source line is Re-Settling_the_Living_Files.md line 267.
SAFER: -

### 14
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 19, under "## 2. The standing of the living files against the apex", has "**Far back, v345 to v348, five files.** … the Living Society Registry v347 and Natural Philosophy v348, light."; NEW has the two files, their versions, far back and the light carrying, said as that session's reading and not as a measure now.
SAFER: -

### 15
CHECK: OK
WHY: NEW's sentence is the prior's sentence word for word, with the words named in italics as at carryings/v368_sources/Wrap_v368.md line 73 ("**Across the set.** Each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words."), and "It is aimed at the set." carries the aiming; it leaves out only the source's name.
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: OK
WHY: the same paragraph as 8 but for the note "(re-aimed from Exhibit ONE Offerings to Natural Resolver at v381R)", which has no concept, concern, condition or work in it; the same NEW, read as at 8 (the row at Re-Settling_the_Living_Files.md line 146, the heading at Exhibit_ONE_v372_Released.md line 108, gone from the living Exhibit ONE).
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the task (TASK_second.md), this brief (HARM3.md), the first reader's brief with its further rules (BRIEFO3.md), the PRIOR file (PL_1.txt) and the PROPOSED file (PL_1_report.md); the mate carry/Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.md, 5,873 words, each section of it.

The living file Exhibit_NINETEEN_Natural_Philosophy_v348.md is 17,330 words, over 15,000, and was not read whole: its headings (each part and section, lines 5 to 893), 3.15 whole (lines 432 to 444), and searches for "Physics" (none), "observer", "worn four ways", "PART FOUR · CO-SEQUENCING" (lines 111 and 346), "unreachab", "podal", "not possibly", "ratio reading" (none of the four), and the ten *held* forms (77 by my search, the prior's and NEW's number being the report's seventy-six, carried as it is). No block of this portion is RESOLVED, SAID or NOVALUE; each change is a RESAY, fourteen of them, and each was laid beside its prior and its source.

Other living files, by search and by the lines found: Exhibit_EIGHTEEN_Natural_Physics_v379.md (headings 2.1, 2.5, 4.4, 4.8, 4.12; "Philosophy": none; lines 120 and 146); Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md (5.11); Exhibit_TWENTY_Natural_Naming_v380R.md (headings 2.3 to 2.5, 3.2, 4.9; line 422); Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (steps 322, 389, 401 and the adding lines of the six entered); Exhibit_ONE_Natural_Resolver_v380R.md (searched for the three section titles: none); Exhibit_TWELVE_Natural_Explaining_v378.md (its headings, lines 110 to 112, 320, 344, 352); Natural_Intelligence_v380R.md (its parts, part FIVE's headings, "sentence"); Natural_Intelligence_Corus_v330.md (Part 16); Exhibit_SIX_Natural_Transmissioning_v330.md (each heading the paragraph names, lines 79, 106, 189); Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (lines 625 and 629).

Sources, read at the lines named: carryings/physics_for_other_files_v377/README.md (lines 20 to 40); carryings/natural_physics_v377/README.md (lines 79 to 96 and 164 to 182, and its headings) and its proposed text (each line naming Philosophy: 416, 475, 532); carryings/co_chaining_coverage_v378/readings/08_physics_philosophy_emanating.md (each line naming Philosophy); carryings/resettling_v373/Re-Settling_the_Living_Files.md (lines 1 to 8, 26 to 38, 59, 138 to 150, 173, 191, 267), Exhibit_ONE_v372_Released.md (its opening and the three headings) and Natural_Intelligence_v373_Released.md (lines 785 to 806); carryings/session_v378/Session_Report_v378.md (line 19 and its headings); carryings/v368_sources/Wrap_v368.md (line 73). The history of the seam sentences was searched in the repository: they entered at one commit, the receiving of the proposed Natural Physics, and are at no living file.

Pointers: carry/*.md was searched for links to this mate (those found are to its sections headed v385A, to its `#droplets` from carry/Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.md line 71, and the rows at carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md lines 377, 589 and 688, each of paragraphs 27 to 31, which are left as they are) and for "three seams", "seventy-six", "the concern at this mate", "the droplet at this mate", "concern above", "the preceding", "existing concern", "current droplet is at", "Natural Philosophy's carrying" and "Offerings to Natural Philosophy"; the one pointer among paragraphs 1 to 26 is paragraph 4's to paragraph 2, and both NEW paragraphs carry "the three seams". carry/Exhibit_NINETEEN_Possibling_of_Natural_Philosophy.md was read at its headings and each paragraph's opening; carry/Exhibit_NINETEEN_Carryings_of_Natural_Philosophy.md by search for "droplet" and "offerings"; carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md at lines 328, 334 and 418, the copies of paragraphs 4 to 6.

The first and second readings already made for the same paragraphs or the like rows at other mates were read for what was passed or objected to: Natural Physics (paragraphs 146, 149 and 191 there, the copies of 4, 5 and 6), Natural Transmissioning and Natural Chemistry (the copy of 12), Natural Explaining, Natural Intelligence Corus and Natural Exploring (the copy of 10), Natural Networking (the next row of the table of 8, 9 and 19), Natural Chemistry and Living Society Registry (the like rows of 7, each objected to for the reading not named), Living Ghost Registry and Natural Biology (the like of 2).

Not checked: the KEEP blocks, which are left exactly as they are; the numbers of places of paragraphs 20 to 26 were not numbered again, and are cited in block 7 as the prior gives them.
