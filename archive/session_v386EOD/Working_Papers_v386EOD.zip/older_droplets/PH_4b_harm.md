### 62
CHECK: OK
WHY: laid beside the prior and carryings/review_natural_physics_v377/README.md line 19, the number fifty-one, "checked and correct at their numbers and their sources" and the whole list from Hensen's S = 2.42 ± 0.20 at 245 trials and 1.3 kilometres to the Magnetospheric Multiscale events are letter for letter in NEW (exact search), the section 1 and its heading are named, the title's "of the field" is the review's own name for these records (its line 27, and this mate's line 95), and NEW has no quotation, 127 words and none of the listed words; the report's folder name alone leaves.
SAFER: -

### 63
CHECK: OK
WHY: laid beside the prior and the review's line 21, thirty of forty, the three corrections (gravity is nothing, relativistic simultaneity, the simulation inadmissible) "each rightly made" and the fourteen released readings from 23 and 55 to fifty-nine as light, "released with their reasons and rightly", are letter for letter in NEW (exact search), "stand whole" is said as "are whole", and "the proposal's report" is the report the review means (its line 9, "The proposal's own report"); 120 words, no quotation, none of the listed words.
SAFER: -

### 64
CHECK: OBJECT
WHY: Narrowed, found by laying NEW beside the prior and the review's lines 25 and 51. The prior has "a reading asserted where the file says elsewhere it is open"; NEW has "a reading asserted while the proposed text says at another section it is open". Elsewhere is any other place of the file; another section shuts out the same section, and the review's own first finding of this kind, paragraph 87 here, is of one section parting from itself ("5.1 lists … and the same section lists … under reaching"), as is "3.4 The reading is … declarative after the proposal sentence" at its line 51. With NEW, the condition this paragraph lays on 87 would no longer cover 87. All else is whole: each finding of 2.1 to 2.6, a harm at do no harm, the file as it is, the three kinds in their order, the answering ahead of the replacing at corus.me said as a relation, the review's section 2 named; the two paragraphs of this mate that name "section 2 of the review" (its lines 95 and 103) still find it. The SAFER paragraph changes "at another section" to "at another place" and nothing else.
SAFER: **Droplet · Each finding of the review's 2.1 to 2.6, a harm at do no harm.** The review of the proposed Natural Physics of version 377 has, at its section 2, each finding of its 2.1 to 2.6 as a harm at do no harm, the proposed text being as it is: a field's record said wrongly, a prior value lost with no reason named, or a reading asserted while the proposed text says at another place it is open. Answering each is ahead of the proposed text replacing its prior at corus.me.

### 65
CHECK: OK
WHY: laid beside the prior and the review's line 28, with the sentence found at the proposed text's line 284 within its 3.8, each thing is in NEW at its strength (short times at Wilkinson, long times at Rothe; neither nuclear decay; Wilkinson 1997 cold sodium atoms tunnelling in an optical lattice; Rothe 2006 luminescence of organic molecules in solution; no departure measured at radioactive decay; Norman and colleagues 1988 setting limits; 3.8, 2.1, item 1), and "the field's record said wrongly, with the record beside it" is the heading of the review's 2.1 at its line 27; 101 words, no quotation, none of the listed words.
SAFER: -

### 66
CHECK: OK
WHY: laid beside the prior and the review's line 29, with the sentence found at the proposed text's line 286 within its 3.8, each thing is in NEW at its strength (the rate changing at the atom about the nucleus opening or closing; the field's account of the dysprosium-163 and rhenium-187 cases, bound-state beta decay, the electron emitted into an empty shell; neither the account nor the reading stated as proposed; 3.8, 2.1, item 2); 89 words, no quotation, none of the listed words.
SAFER: -

### 67
CHECK: OK
WHY: laid beside the prior and the review's line 30, each thing is in NEW at its strength (the form, word for word as the prior has it; alpha and beta decay single-nucleus events with no partner; a halving at each step a common beat; the thing the proposed text releases at its other places, for "elsewhere", not narrowed to sections; 3.8, 2.1, item 3); the form in italics is the review's citing of the proposed text's line 282 ("meeting in pairs at an empty carrying, with no others joining, goes to one member in two at each pairing") and is at no living file (searched), so its listed word *meeting* is the proposed text's and the prior's own, cited and not used; 84 words, no quotation.
SAFER: -

### 68
CHECK: OK
WHY: laid beside the prior and the review's line 31, with the sentence found at the proposed text's line 234 within its 3.3, each thing is in NEW at its strength (perfectly correlated at equal settings; Hensen's pairs a singlet, anti-correlated at equal settings; Aspect's cascade photons correlated; one fact stated for both; 3.3, 2.1, item 4); 70 words, no quotation, none of the listed words.
SAFER: -

### 69
CHECK: OBJECT
WHY: A named place made unsure, found by laying NEW beside the prior and the review's line 32. The prior has "At Bell, 3.3", the proposed text's 3.3 (its line 232, "Nothing passes between them but the changings"). NEW has "At Bell, at its 3.3" straight after "Its review, at item 5 of its 2.1", so "its" reads first as the review's, and the review has a section 3 with a third item ("3.8's decay read as pairing", its line 76) and numbers its own items that way ("lost at 2.3.2", its line 79). All else is whole: nothing passing between the spirals but the changings, at Huygens' clocks (the proposed text's lines 242 and 244, within its 3.4); momentum exchanged through the common beam; the mechanism dropped; the same phrase carrying no-signalling intact, for the prior's "keeps"; 3.4, 2.1, item 5. The SAFER paragraph says whose 3.3 it is and changes nothing else.
SAFER: **Droplet · Nothing passing but the changings, at Huygens' clocks and at Bell.** The proposed Natural Physics of version 377 has, at its 3.4, nothing passing between the spirals but the changings, at Huygens' clocks. Its review, at item 5 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's account has momentum exchanged through the common beam, and the mechanism is dropped. At Bell, at the proposed text's 3.3, the same phrase carries no-signalling intact.

### 70
CHECK: OK
WHY: laid beside the prior and the review's line 33, with the sentence found at the proposed text's line 278 within its 3.7, each thing is in NEW at its strength (the flow between two quark jets differing with the third, at OPAL; the string effect first observed by JADE, 1983, Physics Letters B 134, 275; OPAL's photon comparison, 1991, the later test; 3.7, 2.1, item 6); 75 words, no quotation, none of the listed words.
SAFER: -

### 71
CHECK: OK
WHY: laid beside the prior and the review's line 34, with the sentence found at the proposed text's line 484, step 4 of its 4.9, each thing is in NEW at its strength (the cold both approach from opposite sides; a black hole's Hawking temperature rising as it evaporates; T proportional to 1/M; only the background cools; 4.9 step 4, 2.1, item 7), and nothing of the living 4.9 is added; 71 words, no quotation, none of the listed words.
SAFER: -

### 72
CHECK: OK
WHY: laid beside the prior and the review's line 35, with the sentence found at the proposed text's line 507, step 1 of its 4.11, each thing is in NEW at its strength (the field naming dark matter, dark energy or a reconciliation at the Hubble tension; the field names systematics or physics beyond ΛCDM; dark energy at cosmic acceleration, a row at 5.11; 4.11 step 1, 2.1, item 8); 76 words, no quotation, none of the listed words.
SAFER: -

### 73
CHECK: OK
WHY: laid beside the prior and the review's line 36, with the sentence found at the proposed text's line 512, step 6 of its 4.11, each thing is in NEW at its strength (S8's difference closing at the KiDS-Legacy analysis; one survey consistent with Planck; DES Y3 and HSC Y3 still low; the field says eased; 4.11 step 6, 2.1, item 9); 68 words, no quotation, none of the listed words.
SAFER: -

### 74
CHECK: OK
WHY: laid beside the prior and the review's line 37, with the sentence found at the proposed text's line 507, step 1 of its 4.11, each thing is in NEW at its strength (pulsars' pulses matching the Hellings–Downs pattern; NANOGrav's fifteen-year set; three to four sigma evidence; *matching* overstates; 4.11 step 1, 2.1, item 10); 60 words, no quotation, none of the listed words.
SAFER: -

### 75
CHECK: OK
WHY: laid beside the prior and the review's line 38, with the words found at the proposed text's lines 509 and 510, steps 3 and 4 of its 4.11, each thing is in NEW at its strength (a rate not falling to rest at the edge; the expected Keplerian curve; "not to rest"; a rotation speed no rate in the proposed text's sense; 4.11 steps 3 and 4, 2.1, item 11), and "r to the power −1/2" is the prior's "r to the minus one half", the one power; 82 words, no quotation, none of the listed words.
SAFER: -

### 76
CHECK: OK
WHY: laid beside the prior and the review's line 39, with the sentence found at the proposed text's line 510, step 4 of its 4.11, each thing is in NEW at its strength (the two expansion rates read as rates local to their couplings, no one global rate; H0 one present-day parameter with two measured values; local variation bounded to one or two percent; 4.11 step 4, 2.1, item 12), and nothing of the living 4.11 is added; 81 words, no quotation, none of the listed words.
SAFER: -

### 77
CHECK: OK
WHY: laid beside the prior and the review's line 40, with the sentence found at the proposed text's line 512, step 6 of its 4.11, each thing is in NEW at its strength (a temperature difference as a measured exchange rate; the Cold Spot and the hemispheric asymmetry; intensity differences on one surface at one epoch; 4.11 step 6, 2.1, item 13); 68 words, no quotation, none of the listed words.
SAFER: -

### 78
CHECK: OK
WHY: laid beside the prior and the review's line 41, with the words found at the proposed text's line 469 within its 4.8, each thing is in NEW at its strength (presentism and eternalism at McTaggart; McTaggart gave the A and B series; the two terms later, Prior and Putnam; 4.8, 2.1, item 14), and the living 4.8's like words are not added; 60 words, no quotation, none of the listed words.
SAFER: -

### 79
CHECK: OK
WHY: laid beside the prior and the review's line 42, with the sentence found at the proposed text's line 139 within its 2.2, each thing is in NEW at its strength (a force at the field's account as a doer applying from outside; force defined as the rate of change of momentum; with no doer; the sentence the proposed text's reading said as the field's account; 2.2, 2.1, item 15), and the listed word *outside* is in italics within words a living file has exactly (Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 192, "or a doer applying from outside", one match); 81 words, no quotation.
SAFER: -

### 80
CHECK: OBJECT
WHY: Added, at the title: "Interpretations each moving the cause". The prior gives its claim to four named things, "Copenhagen, many worlds, decoherence and objective collapse each move the cause", and calls them by no one name; the review's line 43 has none either (the word *interpretation* is at no line of the review, searched). The title gives the claim to interpretations as a kind, a subject wider than the four and one the paragraph does not give it (the first reader's rule 11); the word is the living file's (line 294, "Decades of interpretations") and the proposed text's (line 410), brought in beside the prior. The body is whole: the four named, each moving the cause, at 2.3 and 4.4 (the proposed text's lines 147 and 409); many worlds denies collapse and seeks no cause; Copenhagen posits none; 2.1, item 16. The SAFER paragraph names the four in the title in the prior's own words and changes nothing else.
SAFER: **Droplet · Copenhagen, many worlds, decoherence and objective collapse, each moving the cause.** The proposed Natural Physics of version 377 has, at its 2.3 and 4.4, Copenhagen, many worlds, decoherence and objective collapse each moving the cause. Its review, at item 16 of its 2.1, has this as the field's record said wrongly, with the record beside it: many worlds denies collapse and seeks no cause, and Copenhagen posits none.

### 81
CHECK: OK
WHY: laid beside the prior and the review's line 44, with the sentence found at the proposed text's line 422, step 1 of its 4.5 ("names two hard parts: energy's being, only the conserved number given; and time's direction"), each thing is in NEW at its strength (the field naming two hard parts, energy's being one of the two; the field names no such standing problem; 4.5 step 1, 2.1, item 17), and the listed word *standing* is in italics and a living file's own (Exhibit_EIGHTEEN_Natural_Physics_v379.md lines 257, 324 and 326); 61 words, no quotation.
SAFER: -

### 82
CHECK: OK
WHY: laid beside the prior and the review's line 45, with the sentence found at the proposed text's line 396, step 1 of its 4.3, each thing is in NEW at its strength (the field calling the curve the most important diagram in nuclear physics; a textbook flourish; no claim of the field; 4.3 step 1, 2.1, item 18), and the living 4.3's like sentence is not added; 67 words, no quotation, none of the listed words.
SAFER: -

### 83
CHECK: OK
WHY: laid beside the prior and the review's line 46, with the words found at the proposed text's line 328 within its 3.12, each thing is in NEW at its strength (each changing making the other at the field's account; in a plane wave the two fields in phase and both sourced by the charges; the curl equations relate and cause nothing; 3.12, 2.1, item 19); 77 words, no quotation, none of the listed words.
SAFER: -

### 84
CHECK: OK
WHY: laid beside the prior and the review's line 47, with the sentence found at the proposed text's line 344 within its 3.14, each thing is in NEW at its strength (physics having sought rest at ten subjects; the field sought rest at neither the critical point nor the inertial frame; the ten the proposed text's framing; 3.14, 2.1, item 20), and nothing of the living file's ten is added; 70 words, no quotation, none of the listed words.
SAFER: -

### 85
CHECK: OK
WHY: laid beside the prior and the review's line 48, with the words found at the proposed text's line 220 within its 3.1, each thing is in NEW at its strength (the Jet Propulsion Laboratory's aberration correction; the field's name light-time correction, Moyer; aberration a separate correction; 3.1, 2.1, item 21); 57 words, no quotation, none of the listed words.
SAFER: -

### 86
CHECK: OK
WHY: laid beside the prior and the review's line 49, with the sentence found at the proposed text's line 456, step 1 of its 4.7, each thing is in NEW at its strength (quantum theory describing the small scale as discrete and probabilistic; the wavefunction evolves continuously; discreteness at spectra and outcomes; 4.7 step 1, 2.1, item 22), and the living 4.7's like sentence is not added; 67 words, no quotation, none of the listed words.
SAFER: -

### 87
CHECK: OBJECT
WHY: Changed, at the closing sentence, found by laying NEW beside the prior and the review's line 51. The prior has only "section 2.2"; NEW adds that section's heading and says it otherwise than the review does. The review has "A reading asserted where the file says it is open, or where the record parts": what the file says is open is the reading. NEW has "a reading asserted at a place the proposed text says is open, or at a parting of the record": what is said open is now the place. The finding here is that 5.1 lists two readings under no contradiction found while the same section lists their relations under *reaching*; no place is said open. The first sentence is whole and checked at the proposed text's lines 540 and 542, within its 5.1: Bell's correlated clicks, 3.3, and wave and particle, 4.4, under the one label, 3.3's angle dependence and 4.4's amplitudes under the other, the same section, 2.2; the two labels in italics are the proposed text's own, word for word as the prior has them, and are at no living file (searched), so the listed word *meets* is cited and not used. The SAFER paragraph says the heading as the review has it and changes nothing else.
SAFER: **Droplet · Bell's clicks and wave and particle, listed at no contradiction and at reaching.** The proposed Natural Physics of version 377 lists, at its 5.1, Bell's correlated clicks, 3.3, and wave and particle, 4.4, under *meets the field's records with no contradiction found*, and the same section lists 3.3's angle dependence and 4.4's amplitudes under *reaching*. Its review has this at its 2.2, as a reading asserted while the proposed text says it is open, or while the record parts.

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file PH_4b.txt (paragraphs 62 to 87); the PROPOSED file PH_4b_report.md; the source of each of the twenty-six paragraphs, /home/claude/corus/carryings/review_natural_physics_v377/README.md (all 89 lines). Read at the lines the review's findings name, each line read in full: the proposed text /home/claude/corus/carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md, its headings and its lines 139, 147, 220, 232, 234, 242, 244, 278, 282, 284, 286, 328, 344, 396, 409, 422, 456, 469, 484, 507, 509, 510, 512, 540 and 542; each sentence the review cites is at the section and step the review names, so each "has, at its …" of a NEW paragraph is true of the proposed text. The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md is over 15,000 words (21,830) and was not read whole; it was searched for each word a NEW paragraph has in italics and for "interpretation", "Copenhagen" and "standing problem". The mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md was not read whole (31,477 words); its headings were listed, its lines 95 and 103 read in full, and its later sections (lines 574 to 712) searched for the review and for the names of each finding (Wilkinson, JADE, McTaggart, Hellings, Keplerian, Cold Spot, Moyer, bound-state, plane wave, KiDS, Copenhagen, textbook): no later section has any of them, and the three framing lines of the v386EOD sections say only that a thing a mate says already is not said again.

Checked by search: each NEW paragraph's words were laid against its prior's by a word-for-word comparison, and the long lists of 62 and 63 by exact search of the whole list in both; the words of each NEW paragraph and of the four SAFER paragraphs were numbered (57 to 127) and searched for the listed words; NEW has no double quotation mark at any paragraph, so there is no quotation of a living file to verify; all the root's living files were searched for "meeting in pairs", "one member in two", "doer applying from outside", "meets the field" and "no contradiction found"; carry/*.md was searched for pointers at these paragraphs ("review_natural_physics_v377", "review of the proposed Natural Physics", "the review's 2.", "review's section 2", "twenty-two places", "twenty-two records"). The pointers found are this mate's lines 95, 103, 458 and 460, each naming the review's section 2 as a whole ("twenty-two records of the field said wrongly", "each item of the review's section 2", "the review's section 2 met first"); each NEW and SAFER paragraph names the review of the proposed Natural Physics of version 377, its section and its item, so each is still found. No paragraph of this portion is released, each being re-said, so nothing pointed at leaves.

What the checks rest on. All twenty-six verdicts are RESAY and none is KEEP. Twenty-two lose nothing but the report's folder name and the session's framing. Four are objected, each for one thing, with a SAFER paragraph that changes that thing alone: 64, "elsewhere" narrowed to "at another section", which shuts out the same-section finding of 87; 69, "its 3.3" readable as the review's own third item of section 3; 80, a title giving the claim to interpretations as a kind; 87, the review's 2.2 heading added and said so that the place, not the reading, is open.

Three things left to the caller to weigh, none objected. (1) Each NEW of 65 to 86 has "has this as the field's record said wrongly, with the record beside it", which the prior paragraph does not have; it is the heading of the review's 2.1 at its line 27 ("The field's record said wrongly, twenty-two places. Each is the observings reader's, with the record beside it."), the name of the very place each prior names, said as the review says it, and this mate's line 95 calls the same findings "twenty-two records of the field said wrongly"; it was passed as the named place said by its name, not as a sentence brought from a living file. (2) The italic words at 67 (*meeting in pairs, one member in two at each pairing*) and at 87 (*meets the field's records with no contradiction found*, *reaching*) are the proposed text's, as the review cites them, and are at no living file; the first reader's rule allows a living file's own word in italics, and the proposed text is not a living file. They were passed, since each is word for word what the prior has and the claim cannot be carried without it; at 67 the italic form is the review's shortening of the proposed text's line 282 and not that line exact. (3) "Answering each is ahead of the proposed text replacing its prior at corus.me" at 64 says the prior's "to be met before the file replaces its prior at corus.me" as a relation of order, as the first reader's rule 9 asks; the proposed text is still unentered (the living file is version 379 and has, for one, "(presentism and eternalism, McTaggart)" still).

No file but this report was written, and no file in /home/claude/corus was edited.
