### 62
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' observings: fifty-one records of the field checked and correct at their numbers and sources, each named.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 19 (its section 1). A record with its names and numbers, at no living file and no later section. No pointer to this paragraph found.
NEW: **Droplet · Fifty-one records of the field, correct at the proposed Natural Physics of version 377.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the observings read as a physicist: fifty-one records checked and correct at their numbers and their sources: Hensen's S = 2.42 ± 0.20 at 245 trials and 1.3 kilometres, Aspect, File and Mills, Tsuei's h/4e, the Kirkwood gaps, Greene, Jung's 47 days and Bosch's 33 years, Ohtsuki's 0.83 percent, Wu, Goldhaber, the shell capacities, the IUPAC group-three report, Bakun and Lindh, Deegan, the AME2020 masses, Noether, Onsager, Jaffe and Witten, the ALICE and CMS papers, Gibbons and Hawking, Steinhauer, DESI, GW190521 and GW231123, KiDS-Legacy, the muon g-2 lattice result, Eriksson, Phan, Torbert and the Magnetospheric Multiscale events.

### 63
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics read fresh beside its prior: thirty of forty sections whole, the corrections of the prior's overclaimings rightly made, the released readings released with their reasons and rightly.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 21 (its section 1). A record with its named readings, at no living file and no later section; this mate's last v386EOD section, from the physics motion of version 377, has five concerns from the released readings and not this finding. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, read fresh beside its prior.** The review of the proposed Natural Physics of version 377 has, at its section 1, of a fresh reading beside the prior: thirty of the prior's forty sections are whole at the proposal; the corrections of the prior's overclaimings, gravity is nothing, relativistic simultaneity, the simulation inadmissible, are each rightly made; and the released readings the proposal's report names, 23 and 55, the capstone, the singularity as the Navier–Stokes seam, the genus with no φ, the softmax, the completest inversions, the screening constant, the clean conservings, the dark matter and black-hole pairing, ageing, the rhyme, geotensioning and fifty-nine as light, are released with their reasons and rightly.

### 64
VERDICT: RESAY
CONCEPT: each finding of the review's 2.1 to 2.6 is a harm at do no harm in the proposed text as it is, of three kinds, and is answered ahead of the proposed text replacing its prior at corus.me.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md lines 23 to 25 (its section 2). It is a condition laid on the paragraphs after it (rule 6), paragraphs 65 to 87 here and the items of 2.2 to 2.6 after them, so it is re-said with them (rule 2): it keeps its subject words, "each finding of its 2.1 to 2.6", and each of 65 to 87 names the review's 2.1 or 2.2 and its item, so each still finds the other. "To be met before" is said as a relation (rule 9). At no living file and no later section.
NEW: **Droplet · Each finding of the review's 2.1 to 2.6, a harm at do no harm.** The review of the proposed Natural Physics of version 377 has, at its section 2, each finding of its 2.1 to 2.6 as a harm at do no harm, the proposed text being as it is: a field's record said wrongly, a prior value lost with no reason named, or a reading asserted while the proposed text says at another section it is open. Answering each is ahead of the proposed text replacing its prior at corus.me.

### 65
VERDICT: RESAY
CONCEPT: the proposed 3.8 has decay departing from the exponential at Wilkinson and at Rothe; neither is nuclear decay, and no departure has been measured at radioactive decay.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 28 (2.1 item 1, under "The field's record said wrongly, twenty-two places … with the record beside it"). The sentence is at the proposed file's line 284, within its 3.8. Not resolved: the proposed text is not entered, and the living Natural Physics has no section of decay. At no later section (searched "Wilkinson", "Norman and colleagues" in carry/*.md: this mate's older paragraphs and the Session Record alone). Paragraph 64 frames it and is re-said with it; no other pointer found.
NEW: **Droplet · A departure from the exponential, measured at no radioactive decay.** The proposed Natural Physics of version 377 has, at its 3.8, decay departing from the exponential at short times, at Wilkinson, and at long times, at Rothe. Its review, at item 1 of its 2.1, has this as the field's record said wrongly, with the record beside it: neither is nuclear decay; Wilkinson 1997 is cold sodium atoms tunnelling in an optical lattice, and Rothe 2006 is luminescence of organic molecules in solution; no departure from the exponential has been measured at radioactive decay, Norman and colleagues 1988 setting limits.

### 66
VERDICT: RESAY
CONCEPT: the proposed 3.8 has the decay rate changing at the atom about the nucleus opening or closing; the field's account of the two cases is bound-state beta decay, and the text states neither the account nor the reading as proposed.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 29 (2.1 item 2). The sentence is at the proposed file's line 286, within its 3.8. Not resolved, the proposed text not entered; the living Natural Physics has no section of decay. At no later section (searched "bound-state beta"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A decay rate changing at the atom, beside bound-state beta decay.** The proposed Natural Physics of version 377 has, at its 3.8, the rate changing at the atom about the nucleus opening or closing. Its review, at item 2 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's account of the dysprosium-163 and rhenium-187 cases is bound-state beta decay, the electron emitted into an empty shell, and the proposed text states neither the account nor the reading as proposed.

### 67
VERDICT: RESAY
CONCEPT: the proposed 3.8's form of pairing, one member in two at each pairing; alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat, a thing the text releases at its other places.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 30 (2.1 item 3). The words in italics are the proposed text's own, at its line 282 within 3.8 ("meeting in pairs at an empty carrying, with no others joining, goes to one member in two at each pairing"), cited as the review cites them. Not resolved, the proposed text not entered. At no later section. Paragraph 53 is the like concern from the review's section 3 and is no later place. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A form of pairing at decay, beside single-nucleus events.** The proposed Natural Physics of version 377 has, at its 3.8, the form *meeting in pairs, one member in two at each pairing*. Its review, at item 3 of its 2.1, has this as the field's record said wrongly, with the record beside it: alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat, the thing the proposed text releases at its other places.

### 68
VERDICT: RESAY
CONCEPT: the proposed 3.3 has the two sides' clicks perfectly correlated at equal settings; Hensen's pairs are anti-correlated there and Aspect's photons correlated, one fact stated for both.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 31 (2.1 item 4). The sentence is at the proposed file's line 234, within its 3.3. Not resolved, the proposed text not entered; the living Natural Physics' 3.3 is light and has no such sentence. At no later section (searched "anti-correlated", "singlet"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Clicks at equal settings, correlated and anti-correlated.** The proposed Natural Physics of version 377 has, at its 3.3, the two sides' clicks perfectly correlated at equal settings. Its review, at item 4 of its 2.1, has this as the field's record said wrongly, with the record beside it: Hensen's pairs are a singlet, anti-correlated at equal settings; Aspect's cascade photons are correlated; and one fact is stated for both.

### 69
VERDICT: RESAY
CONCEPT: the proposed 3.4 has nothing passing between the spirals but the changings at Huygens' clocks; the field's account has momentum exchanged through the common beam, the mechanism dropped, while at Bell, 3.3, the same phrase carries no-signalling intact.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 32 (2.1 item 5). The sentence is at the proposed file's line 242, within its 3.4, and the like phrase at its line 232, within 3.3. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of Huygens. At no later section (searched "common beam"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Nothing passing but the changings, at Huygens' clocks and at Bell.** The proposed Natural Physics of version 377 has, at its 3.4, nothing passing between the spirals but the changings, at Huygens' clocks. Its review, at item 5 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's account has momentum exchanged through the common beam, and the mechanism is dropped. At Bell, at its 3.3, the same phrase carries no-signalling intact.

### 70
VERDICT: RESAY
CONCEPT: the proposed 3.7 has the flow between two quark jets differing with the third at OPAL; the string effect was first observed by JADE in 1983, and OPAL's photon comparison of 1991 is the later test.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 33 (2.1 item 6). The sentence is at the proposed file's line 278, within its 3.7. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of OPAL. At no later section (searched "JADE"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The string effect, first observed by JADE.** The proposed Natural Physics of version 377 has, at its 3.7, the flow between two quark jets differing with the third, at OPAL. Its review, at item 6 of its 2.1, has this as the field's record said wrongly, with the record beside it: the string effect was first observed by JADE, 1983, Physics Letters B 134, 275, and OPAL's photon comparison, 1991, is the later test.

### 71
VERDICT: RESAY
CONCEPT: the proposed 4.9, step 4, has the cold both approach from opposite sides; a black hole's Hawking temperature rises as it evaporates, and only the background cools.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 34 (2.1 item 7). The sentence is at the proposed file's line 484, step 4 of its 4.9. Not resolved: the proposed text is not entered, and the living 4.9, step 4, has the like sentence still ("the cold both approach and neither lands on is the 0"), which NEW does not add. At no later section: "Concern · Two horizons, each with a temperature, at the field" (v386EOD) is another parting. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The cold both approach, beside a black hole's temperature rising.** The proposed Natural Physics of version 377 has, at step 4 of its 4.9, the cold both approach from opposite sides. Its review, at item 7 of its 2.1, has this as the field's record said wrongly, with the record beside it: a black hole's Hawking temperature rises as it evaporates, T proportional to 1/M, and only the background cools.

### 72
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 1, has the field naming dark matter, dark energy or a reconciliation at the Hubble tension; the field names systematics or physics beyond ΛCDM, and dark energy is at cosmic acceleration, a row at 5.11.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 35 (2.1 item 8). The sentence is at the proposed file's line 507, step 1 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 1, has the like sentence still ("Each is taken as an anomaly demanding a substance (dark matter, dark energy) or a reconciliation."). At no later section (searched "ΛCDM"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The field's names at the Hubble tension.** The proposed Natural Physics of version 377 has, at step 1 of its 4.11, the field naming dark matter, dark energy or a reconciliation at the Hubble tension. Its review, at item 8 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field names systematics or physics beyond ΛCDM, and dark energy is at cosmic acceleration, a row at 5.11.

### 73
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 6, has S8's difference closing at the KiDS-Legacy analysis; one survey is consistent with Planck, two are still low, and the field says eased.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 36 (2.1 item 9). The sentence is at the proposed file's line 512, step 6 of its 4.11. Not resolved, the proposed text not entered; the living 4.11 has S8 as not agreeing and no KiDS-Legacy. At no later section; this mate's droplet aimed at the living S8 sentence (session v383Op's) is within the older Droplets and is of another sentence. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · S8's difference at the KiDS-Legacy analysis.** The proposed Natural Physics of version 377 has, at step 6 of its 4.11, S8's difference closing at the KiDS-Legacy analysis. Its review, at item 9 of its 2.1, has this as the field's record said wrongly, with the record beside it: one survey is consistent with Planck, DES Y3 and HSC Y3 are still low, and the field says eased.

### 74
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 1, has pulsars' pulses matching the Hellings–Downs pattern; NANOGrav's fifteen-year set reports three to four sigma evidence, and *matching* overstates.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 37 (2.1 item 10). The sentence is at the proposed file's line 507, step 1 of its 4.11. Not resolved, the proposed text not entered; the living 4.11 has no Hellings–Downs. *Matching* is the word judged, cited as a word, as the review cites it. At no later section (searched "Hellings"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Pulsars' pulses at the Hellings–Downs pattern.** The proposed Natural Physics of version 377 has, at step 1 of its 4.11, pulsars' pulses matching the Hellings–Downs pattern. Its review, at item 10 of its 2.1, has this as the field's record said wrongly, with the record beside it: NANOGrav's fifteen-year set reports three to four sigma evidence, and *matching* overstates.

### 75
VERDICT: RESAY
CONCEPT: the proposed 4.11, steps 3 and 4, has a rate not falling to rest at the edge; the expected Keplerian curve falls as r to the power −1/2, not to rest, and a rotation speed is no rate in the text's sense.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 38 (2.1 item 11). The sentence is at the proposed file's line 509, step 3 of its 4.11, with step 4 at line 510. Not resolved: the proposed text is not entered, and the living 4.11 has the like sentences still ("a rate that does not fall to rest at the edge", "Kepler, a landing toward zero"). The review's "r to the minus one half" is given in numerals, the same power. At no later section (searched "Keplerian"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A rate not falling to rest at the edge.** The proposed Natural Physics of version 377 has, at steps 3 and 4 of its 4.11, a rate not falling to rest at the edge. Its review, at item 11 of its 2.1, has this as the field's record said wrongly, with the record beside it: the expected Keplerian curve falls as r to the power −1/2, not to rest, and a rotation speed is no rate in the proposed text's sense.

### 76
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 4, reads the two expansion rates as rates local to their couplings; H0 is one present-day parameter with two measured values, and local variation is bounded to one or two percent.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 39 (2.1 item 12). The sentence is at the proposed file's line 510, step 4 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 4, has the like sentence still ("Both-scale expansion difference is rates being local — no single global rate to land on."). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Two expansion rates read as local, beside H0 as one parameter.** The proposed Natural Physics of version 377 has, at step 4 of its 4.11, the two expansion rates read as rates local to their couplings, no one global rate. Its review, at item 12 of its 2.1, has this as the field's record said wrongly, with the record beside it: H0 is one present-day parameter with two measured values, and local variation is bounded to one or two percent.

### 77
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 6, has a temperature difference as a measured exchange rate; the Cold Spot and the hemispheric asymmetry are intensity differences on one surface at one epoch.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 40 (2.1 item 13). The sentence is at the proposed file's line 512, step 6 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 6, has the like sentence still ("the equilibrium framing of a measured bi-exchange rate"). At no later section (searched "Cold Spot"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A temperature difference as a measured exchange rate.** The proposed Natural Physics of version 377 has, at step 6 of its 4.11, a temperature difference as a measured exchange rate. Its review, at item 13 of its 2.1, has this as the field's record said wrongly, with the record beside it: the Cold Spot and the hemispheric asymmetry are intensity differences on one surface at one epoch.

### 78
VERDICT: RESAY
CONCEPT: the proposed 4.8 has presentism and eternalism at McTaggart; McTaggart gave the A and B series, and the two terms are later, Prior and Putnam.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 41 (2.1 item 14). The sentence is at the proposed file's line 469, within its 4.8. Not resolved: the proposed text is not entered, and the living 4.8 has the like words still ("(presentism and eternalism, McTaggart)", line 399), which NEW does not add. At no later section (searched "McTaggart"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Presentism and eternalism, later than McTaggart.** The proposed Natural Physics of version 377 has, at its 4.8, presentism and eternalism at McTaggart. Its review, at item 14 of its 2.1, has this as the field's record said wrongly, with the record beside it: McTaggart gave the A and B series, and the two terms are later, Prior and Putnam.

### 79
VERDICT: RESAY
CONCEPT: the proposed 2.2 has a force at the field's account as a doer applying from outside; the field defines force as the rate of change of momentum, with no doer, and the sentence is the text's reading said as the field's account.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 42 (2.1 item 15). The sentence is at the proposed file's line 139, within its 2.2. The words in italics are the proposed text's, and a living file's own as well (Exhibit TWENTY-FOUR Geodesic Improving Method 2.7, "or a doer applying from outside"). Not resolved, the proposed text not entered; the living 2.2 has no such sentence. At no later section (searched "rate of change of momentum"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A force at the field's account, with no doer.** The proposed Natural Physics of version 377 has, at its 2.2, a force at the field's account as *a doer applying from outside*. Its review, at item 15 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field defines force as the rate of change of momentum, with no doer, and the sentence is the proposed text's reading said as the field's account.

### 80
VERDICT: RESAY
CONCEPT: the proposed 2.3 and 4.4 have Copenhagen, many worlds, decoherence and objective collapse each moving the cause; many worlds denies collapse and seeks no cause, and Copenhagen posits none.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 43 (2.1 item 16). The sentence is at the proposed file's line 409, within its 4.4, and "each candidate moving the cause" at its line 147, within 2.3. Not resolved: the proposed text is not entered, and the living 4.4, step 1, has the like sentence still ("each relocate the cause and none terminates the question"). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Interpretations each moving the cause, beside many worlds and Copenhagen.** The proposed Natural Physics of version 377 has, at its 2.3 and 4.4, Copenhagen, many worlds, decoherence and objective collapse each moving the cause. Its review, at item 16 of its 2.1, has this as the field's record said wrongly, with the record beside it: many worlds denies collapse and seeks no cause, and Copenhagen posits none.

### 81
VERDICT: RESAY
CONCEPT: the proposed 4.5, step 1, has the field naming two hard parts, energy's being among them; the field names no such standing problem.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 44 (2.1 item 17). The sentence is at the proposed file's line 422, step 1 of its 4.5 ("names two hard parts: energy's being, only the conserved number given; and time's direction"). *Standing* is the review's word and a living file's own (Natural Physics 4.5, "the standing problem"), cited in italics. Not resolved: the proposed text is not entered, and the living 4.5, step 1, has "Hard parts: energy's being" still. At no later section; this mate's droplet aimed at the living sentence of energy as a stuff (session v383Op's) is within the older Droplets and of another sentence. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Energy's being, at no problem the field names.** The proposed Natural Physics of version 377 has, at step 1 of its 4.5, the field naming two hard parts, energy's being among them. Its review, at item 17 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field names no such *standing* problem.

### 82
VERDICT: RESAY
CONCEPT: the proposed 4.3, step 1, has the field calling the curve the most important diagram in nuclear physics; a textbook flourish, no claim of the field.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 45 (2.1 item 18). The sentence is at the proposed file's line 396, step 1 of its 4.3. Not resolved: the proposed text is not entered, and the living 4.3, step 1, has the like sentence still ("This is, in the field's words, the single most important diagram in nuclear physics."). At no later section (searched "most important diagram", "textbook flourish"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The most important diagram in nuclear physics, a textbook flourish.** The proposed Natural Physics of version 377 has, at step 1 of its 4.3, the field calling the curve the most important diagram in nuclear physics. Its review, at item 18 of its 2.1, has this as the field's record said wrongly, with the record beside it: a textbook flourish, and no claim of the field.

### 83
VERDICT: RESAY
CONCEPT: the proposed 3.12 has each changing making the other at the field's account; in a plane wave the two fields are in phase and both sourced by the charges, and the curl equations relate and cause nothing.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 46 (2.1 item 19). The sentence is at the proposed file's line 328, within its 3.12. Not resolved: the proposed text is not entered, and the living 3.3 has the like sentence still ("a changing electric offering sourcing a magnetic one, a changing magnetic offering sourcing an electric"). At no later section (searched "plane wave"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Each changing making the other, beside a plane wave's two fields.** The proposed Natural Physics of version 377 has, at its 3.12, each changing making the other at the field's account. Its review, at item 19 of its 2.1, has this as the field's record said wrongly, with the record beside it: in a plane wave the two fields are in phase and both sourced by the charges, and the curl equations relate and cause nothing.

### 84
VERDICT: RESAY
CONCEPT: the proposed 3.14 has physics having sought rest at ten subjects; the field sought rest at neither the critical point nor the inertial frame, and the ten are the text's framing.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 47 (2.1 item 20). The sentence is at the proposed file's line 344, within its 3.14. Not resolved: the proposed text is not entered, and the living 3.5 has the ten still, the inertial rest frame and the critical point among them. At no later section: "Concern · Thermal equilibrium among the ten rests" and "Droplet · A rest sought, at a sphere's form" (v386EOD) are of other rests and another reading. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Rest sought at ten subjects, the ten a framing.** The proposed Natural Physics of version 377 has, at its 3.14, physics having sought rest at ten subjects. Its review, at item 20 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field sought rest at neither the critical point nor the inertial frame, and the ten are the proposed text's framing.

### 85
VERDICT: RESAY
CONCEPT: the proposed 3.1 has the Jet Propulsion Laboratory's aberration correction; the field's name is light-time correction, Moyer, and aberration is a separate correction.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 48 (2.1 item 21). The sentence is at the proposed file's line 220, within its 3.1. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of the Jet Propulsion Laboratory. At no later section (searched "light-time correction", "Moyer"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Light-time correction, the field's name.** The proposed Natural Physics of version 377 has, at its 3.1, the Jet Propulsion Laboratory's aberration correction. Its review, at item 21 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's name is light-time correction, Moyer, and aberration is a separate correction.

### 86
VERDICT: RESAY
CONCEPT: the proposed 4.7, step 1, has quantum theory describing the small scale as discrete and probabilistic; the wavefunction evolves continuously, and discreteness is at spectra and outcomes.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 49 (2.1 item 22). The sentence is at the proposed file's line 456, step 1 of its 4.7. Not resolved: the proposed text is not entered, and the living 4.7, step 1, has the like sentence still ("quantum mechanics describes the small scale as discrete, probabilistic, granular"). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The small scale said discrete, beside a wavefunction evolving continuously.** The proposed Natural Physics of version 377 has, at step 1 of its 4.7, quantum theory describing the small scale as discrete and probabilistic. Its review, at item 22 of its 2.1, has this as the field's record said wrongly, with the record beside it: the wavefunction evolves continuously, and discreteness is at spectra and outcomes.

### 87
VERDICT: RESAY
CONCEPT: the proposed 5.1 lists Bell's correlated clicks and wave and particle under no contradiction found, and lists 3.3's angle dependence and 4.4's amplitudes under reaching, in one section.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 51 (2.2, "A reading asserted where the file says it is open, or where the record parts"). The two lists are at the proposed file's lines 540 and 542, within its 5.1; the two phrases in italics are those lists' own labels, cited as the review cites them. Not resolved, the proposed text not entered; the living 5.1 has other lists. At no later section: "Concern · Bell's exclusion as proof, the distribution declined" (v386EOD) is another parting. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Bell's clicks and wave and particle, listed at no contradiction and at reaching.** The proposed Natural Physics of version 377 lists, at its 5.1, Bell's correlated clicks, 3.3, and wave and particle, 4.4, under *meets the field's records with no contradiction found*, and the same section lists 3.3's angle dependence and 4.4's amplitudes under *reaching*. Its review has this at its 2.2, as a reading asserted at a place the proposed text says is open, or at a parting of the record.


## READING
Each of the fifty-one paragraphs, 37 to 87, was read and checked, one block for each, none left out. Read whole: the living Exhibit_EIGHTEEN_Natural_Physics_v379.md (all 638 lines); the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md, its front, its Insertlets, its older Droplets (lines 13 to 573) and each later section headed v385A or v386EOD (lines 574 to 712); carryings/review_natural_physics_v377/README.md whole, the source of paragraphs 50 to 87. Read in part and searched: the proposed text carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (its headings, and each sentence the review cites, found at the section the review names); Natural Intelligence 1.4 and 3.5; Exhibit TWENTY-FOUR Geodesic Improving Method 2.7; Exhibit TWENTY Natural Naming 2.4, 2.5 and 4.9; Exhibit TWENTY-TWO Resolving the Hard Problem Registry's front; Exhibit THREE Natural Numbers 7.1 and 3.3; Exhibit SIXTEEN Natural Chemistry 4.4; Exhibit FOUR Natural Mathematics; Exhibit TWELVE Natural Explaining 4.7; Exhibit THIRTY Co-Chaining Logic Registry step 644; Exhibit TWENTY-NINE Natural Illustrating; Exhibit ONE Natural Resolver's names. Mates searched for the same concepts and for pointers: carry/*.md, with the Carryings and Possibling mates of Natural Physics, and the offering mates of Natural Numbers, Natural Chemistry, Natural Naming, the Geodesic Improving Method, Natural Intelligence, Resolving the Hard Problem Registry, the Co-Chaining Logic Registry and Exhibit ONE read at the places found. Each quotation in a NEW paragraph was searched exact in its living file.

The proposed Natural Physics of version 377 is not entered: the living file is version 379, at forty sections, and the review's section numbers (3.8, 3.12, 3.14 and the like) are the proposed text's, so no review finding is RESOLVED, and none is at a later section. Each NEW from the review names the proposed text and the review's own section and item, so paragraph 64's "each finding of its 2.1 to 2.6" still finds them; where the living file has the like sentence, EVIDENCE says so and NEW adds none of it. Words of the proposed text are cited in italics at 67, 79 and 87, and words numbered or judged as words at 61, 74 and 81.

Pointers found at paragraphs of this portion: at 42 (this mate's line 568, the Carryings mate's line 29, Natural Illustrating line 446) and at 43 (Natural Illustrating line 446); both kept. Paragraph 40 points at another paragraph of this mate, "the forms above", and 41 qualifies 40; both kept.

Not found: what "the proposed three-science contents" of paragraph 46 is; the labels "THIRTY P1–P4" and on of paragraph 48 at any present file; one present sentence for "the older k-bound, iron-centreline and pair-creation relation" of paragraph 47. Each is kept as it is. Paragraphs 51 to 58 are the like of the review's section 3 items laid later in this mate's older section (outside this portion); they are not two copies within this input and were each given their own verdict.
