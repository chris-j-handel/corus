import re,sys
S='/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/older/'
def blocks(path,keys):
    t=open(path,encoding='utf-8').read(); out={}
    for m in re.finditer(r'^### (\d+)[ \t]*\n(.*?)(?=^### |^## READING|\Z)',t,flags=re.M|re.S):
        b=m.group(2); d={}
        for k in keys:
            mm=re.search(r'^'+k+r':[ \t]*(.*?)(?=^(?:'+'|'.join(keys)+r'):|\Z)',b,flags=re.M|re.S)
            d[k]=' '.join(mm.group(1).split()) if mm else ''
        out[int(m.group(1))]=d
    return out
def plan(tag):
    R=blocks(S+tag+'_report.md',['VERDICT','CONCEPT','EVIDENCE','NEW']); H=blocks(S+tag+'_harm.md',['CHECK','WHY','SAFER'])
    P={}
    for n,r in R.items():
        v=r['VERDICT'].split()[0]; h=H.get(n,{'CHECK':'MISSING','SAFER':''}); c=h['CHECK'].split()[0] if h['CHECK'] else 'MISSING'
        if v=='KEEP': P[n]=('keep',None)
        elif c=='OK':
            P[n]=('resay',r['NEW']) if v=='RESAY' else ('release:'+v,r['CONCEPT'])
        elif c=='OBJECT' and h['SAFER'].startswith('**'): P[n]=('resay',h['SAFER'])
        else: P[n]=('keep',None)   # objected with KEEP, or no check: unchanged
    return P
def apply(tag,mate,section='## Droplets',dry=False):
    P=plan(tag); f='/home/claude/corus/carry/'+mate; t=open(f,encoding='utf-8').read()
    secs=re.split(r'(?m)^(?=## )',t); i=[k for k,x in enumerate(secs) if x.split('\n',1)[0].strip()==section][0]
    s=secs[i]; parts=s.split('\n\n'); head=parts[0]; ps=[x for x in parts[1:] if x.strip()]
    assert len(ps)==len(P),(len(ps),len(P))
    out=[]; rel={'RESOLVED':[],'SAID':[],'NOVALUE':[]}; cnt={'keep':0,'resay':0,'release':0}
    for n,p in enumerate(ps,1):
        k,v=P[n]
        if k=='keep': out.append(p.strip('\n')); cnt['keep']+=1
        elif k=='resay': out.append(v.rstrip()+' — v386EOD'); cnt['resay']+=1
        else: rel[k.split(':')[1]].append(v.rstrip('.')); cnt['release']+=1
    lines=[]
    if rel['RESOLVED']: lines.append("The living file says it now, or the row or word it was of is at the living file no more: "+'; '.join(rel['RESOLVED'])+'.')
    if rel['SAID']: lines.append("A later section of this mate, or another mate, says it whole in the naming now: "+'; '.join(rel['SAID'])+'.')
    if rel['NOVALUE']: lines.append("A session's own record, with no concept, concern or work in it: "+'; '.join(rel['NOVALUE'])+'.')
    if lines: out.append("**Released from this section at a reading beside the living file now, each with its reason.** "+' '.join(lines)+' — v386EOD')
    secs[i]=head+'\n\n'+'\n\n'.join(out)+'\n\n'
    if not dry: open(f,'w',encoding='utf-8').write(''.join(secs))
    return cnt,rel
if __name__=='__main__':
    cnt,rel=apply(sys.argv[1],sys.argv[2],dry=len(sys.argv)>3)
    print(cnt)
    for k,v in rel.items():
        for x in v: print(' ',k,'|',x[:170])
