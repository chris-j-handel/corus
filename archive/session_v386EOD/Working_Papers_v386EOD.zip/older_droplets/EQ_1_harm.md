### 1
CHECK: OBJECT
WHY: Four of the five asks are said at living files, read at each place: the version line "Exhibit TWENTY-EIGHT Equilibria Registry v380L", as the other files' first lines are; the forms at 3.4, "the middle four-cycle 7-11-6-10, through 6-bi-co-bi-moralizing, and the eight-cycle 2-15-7-11-3-14-6-10, through both, partner themselves at the even momentary"; the ring at 3.4, "**One parity offered once co-chains through the whole.**", executed again at v377; the ten and the six at 3.4, "**Ten faces and six connectors.**" with "The ten ways sit at 2 to 6 and 10 to 14, 3.2", at Natural Intelligence line 990, "The ten are five outward and five inward of the tunneling co-sequencing", and line 971, "**Six names between selves are bi-moral-co-competency discovering next existing**"; and the openings at 3.3, "and it carries no number of its openings". The fifth ask is not wholly met: "each claim written on the sum are re-said at the one sign and parity changing". The first reader searched the word "sum" alone and says in its own READING "Not established". The older resolver's sum is the file's *aggregate*: Exhibit ONE v371 (git f50cc74) has "two signs at one key sum together" and "a cancelled sum as nought", Session_Record line 239 has "The code changed at one thing: no sum", and the file at v371 (git f50cc74, lines 315, 335, 336 and 352) wrote three claims on it, "Nonzero offering from the opposed aggregate route", "Zero aggregate from nonzero surfaces is a different condition", and "An opposed row with a nonzero onward offering through the stated aggregate route". Two are re-said at the living file (5.3, "at the resolver a surface 0 arrives only from offerings parting"; 5.5 has the clause no more). One is neither re-said at the one parity nor gone: the living file's 5.1, group D, still has "the older resolver's case at its opposed aggregate route is at `archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_older_resolver.md`", its 5.3 row at the archive alone (archive file lines 72 and 79, "rows 2 and 4 kept here"). The only other place carrying that it is unsettled is paragraph 3 of this same older section (concern 4), no living file and no later section. Releasing paragraph 1 loses the asking that this claim on the sum be re-said at the one parity and parity changing. No other paragraph points at paragraph 1 (searched the mate and carry/*.md for "Incoming, at v372", "both crossings", "one sign offered once", "internal names", "next discovering", "openings 1, 2 and 3", "to a fourth": the mate's lines 177, 185, 187, 195 and 219 quote the v371 file's sentences as their own items, and Session_Record lines 219 and 241 record the same receiving).
SAFER: KEEP

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the task TASK_second.md; the brief HARM3.md; the first reader's brief BRIEFO3.md with its Further rules; the PRIOR file EQ_1.txt (ten paragraphs); the PROPOSED file EQ_1_report.md (one RESOLVED, nine KEEP); the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md, all 541 lines (about 12,300 words).

Checked by search and by reading the lines found, for paragraph 1 alone (the one block that is not KEEP): the living file for each quotation of the first reader's EVIDENCE (each found exactly, at lines 1, 74, 215, 219, 221, 231 and 235) and for "sum", "aggregate", "second sign", "never none", "offerings parting" and "zero aggregate"; Natural Intelligence v380R lines 971 and 990 and Natural Naming v380R line 381 for the six names between selves and the ten outward and inward; the first lines of five other living files for the version line's form; Exhibit ONE Natural Resolver v380R for "sum" and "aggregate" (none at its resolver; line 476 for "a sharing once chained never none again"). The mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md was searched, not read whole (about 29,200 words): its headings, its lines 53, 57, 177 to 219, 243 and 253, and its later section at line 613 (· v385A, the older and newer ten, a different correspondence from the faces' with the ten ways). carry/*.md was searched for pointers to paragraph 1 by its title and by each of its quoted phrases; carry/Session_Record.md lines 215 to 243 were read (the record of version 372's proposal and receiving, where "no sum" is said). The sister mates Carryings of and Possibling of Equilibria Registry were searched for "v372": no pointer.

To find what "each claim written on the sum" names, read from git: Exhibit_TWENTY-EIGHT_Equilibria_Registry_v371.md at commit f50cc74 (searched for "sum", "aggregate", "second sign", "retained", "fresh"; lines 205 to 223, 315, 319, 333 to 336 and 352 read) and Exhibit_ONE_Natural_Resolver_v371.md at the same commit (lines 259, 353 and 365, the older resolver's sum); and archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_older_resolver.md, searched for "sum", "aggregate", "second sign", "fourth" and "openings" (lines 5, 9, 11, 55, 62, 66, 72 to 79, 115, 127 and 129 read).

Paragraphs 2 to 10 are KEEP at the PROPOSED file and are left exactly as they are; nothing of them was laid beside a change, there being none.
