### 1
VERDICT: RESAY
CONCEPT: Natural Naming 4.9 gives each of the ten named still one name, and Natural Biology has the older *held* forms at one place, each offered for local naming correction.
EVIDENCE: In a session's words ("Incoming, at v378", a report's path, "received at v378, 2.3"). Source read: carryings/physics_for_other_files_v377/README.md line 26, "2.3 Six files say the ten at older forms", which has "Natural Biology v333 1". Not resolved: Exhibit_SEVENTEEN_Natural_Biology_v333.md still has, at 2.3 (line 334), "teleology and function stands in the registry as a two-way held to one side". The ten names are checked at Exhibit_TWENTY_Natural_Naming_v380R.md, "## 4.9 The ten named still, one name each" and its table (lines 603 to 622), each of the ten word for word. At no section headed v385A or v386EOD (this mate's "Earlier naming corrections at their particular subjects · v385A" has other words; the possible project at Possibling of Living File Registry, "the ten named still at each subject", lays other sentences). A row points at this section by subject: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 465 ("Ten particular naming corrections …") and carry/Living_Improving_Value.md line 289 ("particular naming corrections"); NEW has the same subject words. The one place is not named in NEW, the paragraph naming none (rule 11).
NEW: **Droplet · The ten named still at their one names, at Natural Biology.** Natural Naming 4.9 gives each of the ten named still one name: *an arriving named from behind*, *an opening named as a place*, *a completing named as a last*, *a carry named as a store*, *a middle named as an end*, *a parity named as a magnitude*, *a sequencing named to one beat*, *a rate named as a value*, *a two-way named to one side* and *the between named as a cut*. Natural Biology carries the older *held* forms at one place, each offered for local naming correction.

### 2
VERDICT: KEEP
CONCEPT: a set-wide concern: selves joined along at the code are a spiral and no ring, closure named as the form is an equilibrium entering the explaining, with the odd and the even spiral said, three offered re-sayings, and a field's own ring and the numbers' podaling rings left as theirs.
EVIDENCE: Already a concern in plain voice; about two hundred words of conditions (the like pair, the 0 moving one self on at each second momentary, the pattern inverted and the parities again at 4n, the even spiral, the torus, three re-sayings, two exemptions), over one NEW of one hundred and fifty words at their strength (rule 4). Not resolved at this living file: it still has "Each living cycle is six one-way-forward recursionings" (line 239), "the genetic code closes its shell at five" (line 480) and "the two ghost-rings pulling apart" (line 375); source carryings/rings_are_spirals_v377/README.md line 91, "| Natural Biology v333 | 22 | 6 | 24 | 0 |", and line 110. Its general part is at living files: Natural Naming 2.4's row "*ring*, *loop*, *goes round*, *round*, *closes* at the resolver's coupling of selves along" and "a closure named as its form is an equilibrium entering" (line 1056). A row points at it by subject: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 465, "ring/spiral concern", at this section; Carryings of Natural Biology, "Reported ring comparison and earlier gathering condition · v385A", has this file's numbers and the executed momentaries apart from it.
NEW: -

### 3
VERDICT: RESAY
CONCEPT: three partings at Natural Biology laid beside the Co-Chaining Logic Registry: 7.5's *or a self across* against 7.6's same-scale harm, 1.4's third self against the crossing as a nothing, and 6.1's *ingression* sharing a word; its resolving the Registry's.
EVIDENCE: A one-line pointer in shorthand with a wait. Source read: carryings/co_chaining_coverage_v378/readings/09_chemistry_biology_health_medicine.md, line 35 (A: 7.5's sentence, "A 'self across' is the same scale … Biology's own 7.6 sides with the registry ('same-scale ingestion is the landing whether the shedder is the ingester or another'), so 7.5's 'or a self across' is the sentence out of line"), line 37 (B: 1.4's sentence against "The crossing is no location and no existing thing"), and line 21 (8: Biology 6.1, "Step 20's 'nothing ingressing' is the self-emptying set, a different sense"). Each quotation checked now: Natural Biology line 799 (7.5), line 812 (7.6), line 232 (1.4), line 715 (6.1); Exhibit THIRTY Co-Chaining Logic Registry step 103, "The crossing is no location, a nothing" (line 500, the present wording of the source's step 102), and step 20, "nothing ingressing into it and nothing escaping out of it" (line 140). Not resolved: each sentence is at the living file unchanged. Later sections say parts and not the whole: "Concern · The between said as a third self" (v386EOD) has 1.4's part; "Concern · An emanation living again" and "Concern · Same-scale form ingested, at two sayings" (v386EOD) have 7.5's and 7.6's sentences against other sayings, and not 7.5 against 7.6; *ingression* is at no later section (searched "ingress" in carry/Exhibit_SEVENTEEN_*.md). A row points at it by subject ("cross-scale harm", Carryings of Living File Registry line 465, Living Improving Value line 289); NEW has "same-scale harm". The wait is said as a relation (rule 9).
NEW: **Concern · *Or a self across* and same-scale harm, the third self, and *ingression*.** Sayings of Natural Biology part at three places. Natural Biology 7.5 has "An emanation lives again only in a coupling other than the one it left: a grain down, or a self across.", against the same-scale harm of its 7.6, "same-scale ingestion is the landing whether the shedder is the ingester or another". Natural Biology 1.4 has "The nothing between two selves is a third self, carrying only the sign.", against the crossing as a nothing, Exhibit THIRTY Co-Chaining Logic Registry's "The crossing is no location, a nothing". Natural Biology 6.1 has *ingression*, "the larger ingressing the smaller", a word shared at another sense with Exhibit THIRTY Co-Chaining Logic Registry's "nothing ingressing into it and nothing escaping out of it". Its resolving is a following at Exhibit THIRTY Co-Chaining Logic Registry.

### 4
VERDICT: RESAY
CONCEPT: at 5.3's neoblast two sayings part, the carrying the self's own or the sentence's fragment entering with the carry empty as it is now, and neither is chosen.
EVIDENCE: A one-line pointer in shorthand. Source read: carryings/v380R/Natural_Networking_From_v380A.md line 47, "Natural Biology's *entering with empty carry* … each beside *a self's carrying its own*". The sentence is at Natural Biology 5.3 (line 655) unchanged: "each cut fragment read as a new sequence entering from the first element with the carry empty". A later paragraph points at this one: this mate's "Droplet · The fragment's carry empty, at four." (v386EOD) opens "Beside the concern at this mate of 'each cut fragment read as a new sequence entering from the first element with the carry empty'"; under rule 2 it stays, and NEW has the same sentence and the subject words (neoblast, the carry empty), so that pointer and the row "neoblast carrying" (Carryings of Living File Registry line 465, Living Improving Value line 289) still find it. That later droplet says four things beside it and does not say the two sayings or that neither is chosen.
NEW: **Concern · The neoblast's fragment entering with the carry empty.** Two sayings part. Natural Biology, at 5.3, has "each cut fragment read as a new sequence entering from the first element with the carry empty", of the neoblast. The other saying has the carrying the self's own. They part at the neoblast's carrying: the self's own, or empty as the sentence has it now. Neither is chosen.

### 5
VERDICT: KEEP
CONCEPT: phytochrome in darkness at two proposed correspondences, each photon a parity inverted at each call or each photon a nothing with darkness no call, and Pfr's slow passing toward Pr in darkness a further coupling at warmth.
EVIDENCE: Already a titled concept in plain voice. Not at the living file (searched "phytochrome" in Exhibit_SEVENTEEN_Natural_Biology_v333.md: none). This mate's "Droplet · Living alternating by internal consumption or external adapting" (v386EOD) has one of the two alone, "Each photon is a nothing coupled at a pigment's own opening, and darkness is no call"; the other correspondence and Pfr are at no later section. Its "the run above" I could not find (the paragraph above it is of the neoblast). A row points at it by name: Carryings of Living File Registry line 465, "phytochrome in darkness … four identical phytochrome copies now have one full place", and Living Improving Value line 289. Left exactly as it is.
NEW: -

### 6
VERDICT: RESAY
CONCEPT: an arriving has a plant in wind; at Natural Biology it is received at the field's finding of growth changing under mechanical stress, or released, and neither is chosen.
EVIDENCE: A one-line pointer in a session's words. Source read: archive/session_v380/v380G/README.md line 16, "| Plants in wind | Growth halting at motion, light carried as form | An observing from a field, said more strongly than the field says it. For Natural Biology only as the field's own finding, sourced. |", and line 30, "**Plants and wind.** One observing for Natural Biology, at the field's own finding." NEW has what the paragraph and that row say and no more. Not at the living file (searched "plant in wind", "wind", "mechanical stress": no sentence of a plant in wind) and at no later section. A row points at it by subject ("plant wind stress", Carryings of Living File Registry line 465, Living Improving Value line 289); NEW has "a plant in wind" and "mechanical stress".
NEW: **Droplet · A plant in wind.** An arriving has a plant in wind, growth halting at motion and light carried as form, an observing from a field said more strongly than the field says it. At Natural Biology it is received at the field's finding of growth changing under mechanical stress, or it is released. Neither is chosen.

### 7
VERDICT: RESAY
CONCEPT: two sayings part at a floor below the living: Natural Physics has the atom the floor and no self closing below it, Natural Biology has no fundamental self and no floor, and Natural Physics 1.1 has one form at each scale.
EVIDENCE: A pointer's shorthand closing with a report's name. Source: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 254, the same words. Not resolved: Exhibit_EIGHTEEN_Natural_Physics_v379.md still has "Below the atom no self closes" and "Atom is the floor, the first closing of the co-agency into a self" (line 363), now in "## 4.6 Strong force, three phases of one coupling" (the paragraph's 3.6 is the section's number at version 348; given as 4.6 now, rule 8), and Natural Biology 1.3 (line 221) has "so there is no fundamental self anywhere and no floor to the counting". The third sentence is changed: version 348's 1.1 had "one living torusing at three prime societies and the difference among them scale alone" (git 0eef2d2, line 121); the present 1.1 has in its place "**Chemistry and Biology are the same method at their own subjects, the same form at each scale**" (line 90), and NEW quotes those five present words, the sentence the paragraph is about as it is now. A second reader may judge that quotation; without it the third saying is at no living file in the paragraph's words. At no section headed v385A or v386EOD: this mate's "Concern · The cell named the engine of living" (v386EOD) has 1.3's sentence against 3.1 and 4.1, not against Natural Physics; Offerings to Natural Physics has the atom's floor against its own 4.12 and against the Registry. A row points at it by subject ("floor contradictions", Carryings of Living File Registry line 465; Living Improving Value line 289); NEW has the title's words.
NEW: **Concern · The floor below the living.** Two sayings part. Natural Physics, at 4.6, has "Below the atom no self closes" and "Atom is the floor, the first closing of the co-agency into a self". Natural Biology, at 1.3, has "there is no fundamental self anywhere and no floor to the counting". They part at a floor below the living: the atom a floor in the one, and no floor in the other. Natural Physics, at 1.1, has "the same form at each scale".

### 8
VERDICT: KEEP
CONCEPT: Natural Biology draws a line between living and non-living (metabolic beating at 3.1, a virus and a prion non-living at 4.1, x² = x + 1 and x² = x) that Natural Chemistry 1.1 and 6.4 do not draw, the atom, the molecule, the bilayer and the cell all living there and 1.2 leaving the stronger reading open; no file explains the difference as a difference of re-forming, though named sections carry what that explaining needs.
EVIDENCE: Already a concern in plain voice with no waiting language, and not resolved. Checked at the living files now: Natural Biology 3.1 "Living is metabolic beating." (line 373); 4.1 "neither is a living self" and "x² = x + 1 with the living rate its positive root … x² = x" (lines 535 and 541); Natural Chemistry 1.1 "the hydrogen-bond network, the bilayer and the cell are societies at their own membranes, each a self at the scale above" (line 115), 6.4's table row "living … the atom … the molecule … the bilayer; the cell" (line 453), and 1.2 "the stronger reading, every molecule living and every bond at coefficient one, stands open" (line 123). It names twelve places and "the carrying's Natural Intelligence section", a place I could not find in the present naming; a re-saying could not carry that attribution at its strength. Later sections say parts and not the whole: the insertlet at 4.1 and "Concern · The cell named the engine of living" (v386EOD) are of Natural Biology alone, with no parting from Natural Chemistry and nothing of re-forming. A row points at it by subject ("living/non-living … contradictions", Carryings of Living File Registry line 465; Living Improving Value line 289).
NEW: -

### 9
VERDICT: RESAY
CONCEPT: two sayings part at the omega ratio: Natural Biology 3.1 has cardiolipin's ancestral ratio at 1/φ², and Natural Chemistry 5.4 has no universal ancestral value.
EVIDENCE: A pointer's shorthand closing with a report's name. Source: carryings/resettling_v373/Re-Settling_the_Living_Files.md, section 11. Not resolved: Natural Biology 3.1 (line 375) still has "the ancestral ratio of cardiolipin's omega-6 to omega-3 lands within a hair of 1/φ²", and Natural Chemistry 5.4 (line 393) has "no universal ancestral value standing at the field face". The only other places are older ones: paragraph 14 of this section (session v383Op's droplet at the same sentence, which has Natural Chemistry's sentence and no parting said) and the same line at Offerings to Natural Chemistry line 53; neither is a later place (rule 1). A row points at it by subject ("cardiolipin ratio", Carryings of Living File Registry line 465; Living Improving Value line 289); NEW has both words.
NEW: **Concern · The omega ratio at cardiolipin.** Two sayings part. Natural Biology, at 3.1, has "the ancestral ratio of cardiolipin's omega-6 to omega-3 lands within a hair of 1/φ²". Natural Chemistry, at 5.4, has "no universal ancestral value standing at the field face". They part at an ancestral ratio: cardiolipin's at 1/φ² in the one, and no universal ancestral value in the other.

### 10
VERDICT: RESAY
CONCEPT: across the set, each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words.
EVIDENCE: A pointer's form closing with a report's name and section. Its source says the same and no more: carryings/v368_sources/Wrap_v368.md line 73, "**Across the set.** Each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words." Part is at the living Natural Naming 2.4 (rows "| *held*, *holding* | *named*, and a form named still |" and "| *stable form* as a noun | *stable-forming* |", lines 238 and 239); "its namings of other exhibits" is at no living sentence and no section headed v385A or v386EOD, so it is not whole at a living file (rule 3). Not made at this file: Natural Biology has *held* in its own voice ("one part can be held still while another is varied", line 272) and *turn* ("turn to turn", line 601). The same paragraph is in the older sections of about twenty other mates; NEW is the paragraph's own sentence with the aiming at the set said (rule 10), the releasing said as the paragraph says it and as no possible project; Natural Naming's sentences are left out (rule 11). A row names it at this section ("general dissolving corrections", Carryings of Living File Registry line 465).
NEW: **Droplet · Across the set, what each file releases at its own improving.** Across the set, each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words. It is aimed at the set.

### 11
VERDICT: KEEP
CONCEPT: the *so-far* and *not-yet* naming concern is at each particular prior, now and next relation of this file, beside Natural Naming's row; the earlier examination of "far side", loopings, standing and the first root is a reported inventory whose numbers are not the present condition.
EVIDENCE: Already a clear concern in plain voice with no waiting language, and its second sentence is a negation laid on the inventory it links (rule 6). Natural Naming has the row, "| *so-far*, *not-yet* as places and as two directions on one | *prior*, *now* and *next* …" (line 252). The link's place is there: carry/Exhibit_SEVENTEEN_Carryings_of_Natural_Biology.md line 57, "## Reported arriving-reader inventory and insertlet locations · v385A", which says "They do not establish the current counts or resolving". Not resolved at the living file: it has "10.1 Cohering, and the not-yet" and "10.3 Not-yet-explored" as section titles. At no other later section.
NEW: -

### 12
VERDICT: KEEP
CONCEPT: at Natural Biology's *displaced monarchs will re-resolve a heading locally*, monarchs moved 2,500 km flew on at their heading and did not correct; whether that is the file's re-resolving or its reverse is unsaid, an inherited heading being a thing carried; it rests on a news account and asks for its primary source.
EVIDENCE: Two places point at it, so it stays (rule 2): paragraph 32 of this section, "Beside the droplet of session v383Op in this list at *displaced monarchs will re-resolve a heading locally*, which asks for its primary source", and carry/Exhibit_SEVENTEEN_Carryings_of_Natural_Biology.md line 162, "This is the primary source the droplet of session v383Op at [the offering mate](…#droplets) asks for". Both name it by its asking, which a re-saying would change. Not resolved: Natural Biology 8.9 (line 997) still has "displaced monarchs will re-resolve a heading locally (they do — the compass recomputes)". Carryings of Natural Biology, "Displaced monarchs fly on at one heading" (v386EOD), has the observing at its publishing; the paragraph's question, re-resolving or its reverse, and "an inherited heading is a thing kept" are at no later section.
NEW: -

### 13
VERDICT: KEEP
CONCEPT: at Natural Biology's *The field uses this directly in non-caloric sweeteners*, of L-glucose: it was proposed and never marketed, for its cost, by an encyclopaedia; it asks for its primary source.
EVIDENCE: A paragraph points at it, so it stays (rule 2): paragraph 34 of this section, "Beside the droplet of session v383Op in this list, which rests on an encyclopedia", and carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 598, "Two further droplets, at Offerings to Natural Medicine and Offerings to Natural Biology, each name a publishing beside a droplet of session v383Op". Already a clear concern aimed at a sentence. Not resolved: Natural Biology 3.3 (line 408) still has "The field uses this directly in non-caloric sweeteners". At no later section (Carryings of Natural Biology has "A soil bacterium using L-glucose", another observing).
NEW: -

### 14
VERDICT: KEEP
CONCEPT: at Natural Biology's *the ancestral ratio of cardiolipin's omega-6 to omega-3 lands within a hair of 1/φ²*: mammalian cardiolipin is mostly linoleic acid, an omega-6, at each of its four chains, by an encyclopaedia; Natural Chemistry already has no universal ancestral value; it asks for its primary source.
EVIDENCE: Already a clear concern in plain voice, aimed at a sentence. Not resolved: Natural Biology 3.1 (line 375) has the sentence unchanged, and Natural Chemistry 5.4 (line 393) has "no universal ancestral value standing at the field face". At no later section (searched "cardiolipin" and "linoleic" in carry/*.md: this paragraph, paragraph 9, the same older line at Offerings to Natural Chemistry, and an inventory row). Its closing sentence, that it rests on an encyclopaedia and asks for a primary source before it enters a file, is a condition on the fact's strength (rule 6); it is one of five droplets of session v383Op in this section with the same closing, two of them named by that closing at other places (paragraphs 12 and 13), and the five are left alike. Source: carryings/v383Op/Corrections.md, section 27, correction 18.
NEW: -

### 15
VERDICT: KEEP
CONCEPT: at Natural Biology's *the six core reactions cycling over carbon (the citric-acid cycle …)*: the cycle has eight steps, and Natural Chemistry says six is no number of those reactions.
EVIDENCE: A later paragraph points at it, so it stays (rule 2): this mate's "Droplet · The cycle's eight steps, and six." (v386EOD), "Beside the concern at this mate of the citric-acid cycle: steps and directed couplings are two things, and eight and six were never one number." Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 3.1 (line 373) still has "the six core reactions cycling over carbon (the citric-acid cycle returning to begin)"; Natural Chemistry 5.1 (line 373) has "Six is no count of those reactions".
NEW: -

### 16
VERDICT: KEEP
CONCEPT: at Natural Biology's *The devil facial tumour carries its host population toward extinction*: later work finds the disease endemic and the hosts adapting, by an encyclopaedia; the file's own test sorted the case the wrong way; it asks for its primary source.
EVIDENCE: Already a clear concern in plain voice, aimed at a sentence. Not resolved: Natural Biology 6.1 (line 711) still has "The devil facial tumour carries its host population toward extinction, and toward its own end with it". At no later section and no other mate (searched "devil facial" and "Tasmanian" in carry/*.md: this paragraph alone). Its closing sentence is a condition on the fact's strength (rule 6), left with it as at paragraphs 12, 13 and 14. Source: carryings/v383Op/Corrections.md, section 27, correction 20.
NEW: -

### 17
VERDICT: RESAY
CONCEPT: the comparison with the supplied biology transcript has a shared interest in five things: intelligence beyond brains, competency at three scales, collective capacities, unfamiliar capacities through changed embodiment, and relating across different intelligences.
EVIDENCE: A plain sentence closing with a report's name, a kit's file and a re-aiming label. This mate's "Intelligence across scales and the supplied biology transcript · v385A" has the five ("The comparison with the supplied biology transcript offers intelligence beyond brains, competency at cell, organism and society scales, collective capacities beyond a description of parts, unfamiliar capacities through changed embodiment, and improved relating across different intelligences"), as things offered and not as a shared interest; and a row points at this section by subject ("transcript concepts", Carryings of Living File Registry line 465), so the paragraph stays with its subject words (rule 2). NEW is the paragraph's own sentence with the session's labels left off; it adds nothing. Not at the living file.
NEW: **Droplet · The supplied biology transcript, a shared interest.** The comparison with the supplied biology transcript has a shared interest in intelligence beyond brains; in competency at cellular, organism and society scales; in collective capacities beyond a description of parts; in unfamiliar capacities through changed embodiment; and in improved relating across different intelligences.

### 18
VERDICT: RESAY
CONCEPT: the difference to follow between the transcript and Natural Intelligence is the relation of goals, *memory* and proposed patterns to continuing changing; each explains its own four things, and shared words do not by themselves establish one operation.
EVIDENCE: Plain sentences closing with a report's name and a re-aiming label. Part is at this mate's "Intelligence across scales and the supplied biology transcript · v385A" ("Its distinct comparison concerns how goals, memory and a proposed pattern space relate to continuing changing … Shared words do not establish either a shared operation or a parted one"); the two lists, the transcript's "goal-directed collectives, future conditions, memory and a proposed pattern space" and Natural Intelligence's "co-offering, carrying, co-releasing and competency at the coupling", are at no later section whole (the insertlet at 5.3 has three of each and is no later place; "future conditions" and "co-releasing" are at neither). A row points at this section by subject ("transcript concepts", Carryings of Living File Registry line 465). NEW is the paragraph's three sentences word for word with the labels left off; *memory* is the field's word and the living files' (Natural Naming 2.4, "*memory* at *the carrying*"; Natural Biology 8.8's title), cited in italics. Not at the living file.
NEW: **Droplet · The supplied biology transcript, the difference to follow.** The difference to follow is the relation of goals, *memory* and proposed patterns to continuing changing. The transcript explains goal-directed collectives, future conditions, *memory* and a proposed pattern space; Natural Intelligence explains co-offering, carrying, co-releasing and competency at the coupling. The shared words do not by themselves establish the same operation.

### 19
VERDICT: KEEP
CONCEPT: at Natural Biology's six substrate-positions carrying nesting-table primes: none of 22, 26, 28, 33, 34 and 38 is a prime.
EVIDENCE: Already a clear concern in plain voice with no waiting language, and not resolved: Natural Biology 10.4 (line 1233) still has "the six substrate-positions carrying nesting-table primes (cristae 22, renal 26, inner-ear 28, hepatic 33, bronchioalveolar 34, spermatogonial 38)". A row points at it: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 564, "| The six numbers named primes | Offerings to Natural Biology | droplet |". At no later section.
NEW: -

### 20
VERDICT: KEEP
CONCEPT: at Natural Biology's *never another cell's interior directly*: at a plasmodesma one plasma membrane lines the pore from one plant cell to the next and the two cytoplasms are connected; beside the concern at the placenta in Offerings to Natural Medicine; unresolved.
EVIDENCE: Already a clear concern in plain voice. Not resolved: Natural Biology 1.4 (line 230) has the sentence unchanged. Its links are there: Carryings of Natural Biology "### A plasmodesma, one cytoplasm through two cells" (line 65), and the placenta concern at Offerings to Natural Medicine line 27. Others lean on it: Offerings to Natural Transmissioning line 101 has the same observing at its own sentence, and Possibling of Natural Transmissioning line 21 has "Resolving at Natural Biology's sentence". Its closing words say it is unresolved, which it is. At no later section.
NEW: -

### 21
VERDICT: KEEP
CONCEPT: at Natural Biology's *an atom a society of nuclei and electrons*: the field's definition has one nucleus; its insertlet is in this mate.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 1.3 (line 221) still has "an atom a society of nuclei and electrons". The insertlet it names is at this mate's Insertlets, "At 1.3 · Every self is a society of selves — beside 'an atom a society of nuclei and electrons'" (line 53). At no later section; the Insertlets section is no later place.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: at two sentences of Natural Biology on the surplus returned as coupling and not falling out as heat: a living body is warm, and the field's textbook has the rest of the oxidation's energy released as heat, parting from both.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 3.1 (line 373) has "the surplus returned as coupling and not lost" and 4.6 (line 601) "the surplus kept as coupling turn to turn, carrying, and not falling out as heat". Its link is there: Carryings of Natural Biology "### Respiration's heat" (line 74). At no later section of the offering mate.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: at Natural Biology's *over-wound behind and under-wound ahead*: the field's model has positive supercoils ahead of the polymerase and negative behind, the sentence having the two windings the other way round; the publishing is a model.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 3.3 (line 418) has the sentence and "under negative supercoiling" unchanged. Its insertlet is at this mate's line 55 and its observing at Carryings of Natural Biology line 81, whose line 90 points back to this mate. "The publishing is a model" is a condition on the fact (rule 6). At no later section.
NEW: -

### 24
VERDICT: KEEP
CONCEPT: at Natural Biology's *Released as procollagen, the molecules cleave, meet, and assemble into triples*: the field's textbook has the three chains joined within the cell, procollagen the triple's name, and the end pieces guiding the triple's forming, beside the section's "Assembly carries upward with nothing directing it".
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 3.7 (line 498) has both sentences unchanged. Its insertlet is at this mate's line 57 and its observing at Carryings of Natural Biology line 92. At no later section.
NEW: -

### 25
VERDICT: KEEP
CONCEPT: at Natural Biology's *two hundred square metres of gut in a tube*: measured on biopsies the digestive tract's inner surface is about 32 square metres, 260 to 300 the figure the report gives as the textbooks'.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 3.8 (line 527) has "two hundred square metres of gut in a tube". Its insertlet is at this mate's line 59 and its observing at Carryings of Natural Biology line 103. At no later section.
NEW: -

### 26
VERDICT: KEEP
CONCEPT: at Natural Biology's error rate *from about one in ten million to about one in ten billion*: the field's textbook table has one in a hundred thousand to one in a billion across three steps, the sentence's two figures each a hundred times smaller; the table names no measuring.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 4.7 (line 615) has the sentence unchanged. Its record is at Carryings of Natural Biology "### Copying errors at three steps" (line 112). "The table names no measuring" is a condition on the fact (rule 6). At no later section.
NEW: -

### 27
VERDICT: KEEP
CONCEPT: at Natural Biology's *the sperm … with its own mitochondria shed*: a sperm's mitochondria are seen within the fertilized egg in cow and monkey, their destroying there the field's explaining, parting from *shed*.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 5.1 (line 635) has the sentence unchanged. Its insertlet is at this mate's line 61 and its observing at Carryings of Natural Biology line 121. At no later section.
NEW: -

### 28
VERDICT: KEEP
CONCEPT: at Natural Biology's *The caterpillar's tissues dissolve almost wholly*: scans follow the tracheae and the gut through the pupal days, and a moth avoids an odour learned at its fifth larval stage, parting from the sentence and beside the paragraph's own "The next regime is always already inside".
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 5.2 (line 643) has both sentences unchanged. Its insertlet is at this mate's line 63 and its observings at Carryings of Natural Biology line 132. At no later section.
NEW: -

### 29
VERDICT: KEEP
CONCEPT: at Natural Biology's *Seven independent phyla carry the same geometry*: the sentence's cases are at two phyla in the field's grouping, Arthropoda and Chordata; a grouping is the field's naming and the seven is the sentence's own.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 5.2 (line 643) has "Seven independent phyla carry the same geometry". Its closing sentence is a condition on the fact (rule 6). At no later section and no other mate (searched "phyla" in this mate's later sections).
NEW: -

### 30
VERDICT: KEEP
CONCEPT: at Natural Biology's *two genus-nought cells arriving as one multinucleated genus-one fibre*: a working, no observing; two closed surfaces of genus nought joined through one hole are one surface of genus nought, and genus one arrives at a second hole or at one surface joined to itself.
EVIDENCE: Already a clear concern in plain voice with no waiting language, its numbers its own working (2 + 2 − 2 = 2). Not resolved: Natural Biology 5.5 (line 685) has the sentence unchanged. "A working at a stable form, and no observing" is a condition on it (rule 6). At no later section.
NEW: -

### 31
VERDICT: KEEP
CONCEPT: at Natural Biology's *no animal makes that ring*: pea aphids are reported making carotenoids with enzymes their own genome carries, the field tracing those genes to fungi, the making itself arriving from another self's emanation.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 7.6 (line 814) has the sentence unchanged. Its insertlet is at this mate's line 65 and its observing at Carryings of Natural Biology line 144. "As its abstract reports it" is a condition on the fact (rule 6). At no later section.
NEW: -

### 32
VERDICT: KEEP
CONCEPT: at Natural Biology's *robust to displacement, since the heading is recomputed locally at each moment*: twenty-three monarchs flown in Ontario and again 2,500 kilometres west flew at one southwest heading, 213 and 244 degrees, the course from the new place 161, parting from both sentences; beside session v383Op's droplet at the other sentence.
EVIDENCE: Left as it is with paragraph 12, which it points at and stands beside ("Beside the droplet of session v383Op in this list … which asks for its primary source"). Already a clear concern in plain voice. Not resolved: Natural Biology 8.9 (lines 995 and 997) has both sentences unchanged. Its link is there: Carryings of Natural Biology "### Displaced monarchs fly on at one heading" (line 155), with the numbers 23, 213, 244 and 161 as here. Its sentence "A fresh reader read the report whole" is a condition on the fact's strength (rule 6). At no later section of the offering mate.
NEW: -

### 33
VERDICT: KEEP
CONCEPT: at three sentences of Natural Biology on a flock's correlation and its turning: in flocks up to 86 metres across the correlation decays with distance and passes zero at 0.35 of the flock's size, and a turn passes through four hundred birds in a little more than half a second, parting from the three; the section's explaining leans on a correlation that does not decay.
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not resolved: Natural Biology 8.14 (lines 1078 and 1084) has the three sentences unchanged. Its two insertlets are at this mate's lines 67 and 69 and its observings at Carryings of Natural Biology line 164. At no later section.
NEW: -

### 34
VERDICT: KEEP
CONCEPT: at Natural Biology's *The field uses this directly in non-caloric sweeteners*: a nearer publishing than the encyclopedia is named, the Spinoff 2004 page, given by a helper as L-glucose proposed and not made cheaply enough for use, and read by no fresh reader.
EVIDENCE: A row points at it, so it stays (rule 2): carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 598, "Two further droplets, at Offerings to Natural Medicine and Offerings to Natural Biology, each name a publishing beside a droplet of session v383Op." It stands beside paragraph 13 and is left as it is with it. Its closing sentence is in a session's words ("This session's helper", "no fresh reader of this session"), and is a condition on the fact's strength (rule 6); I could not find which session it names beyond the label v386EOD, so a re-saying naming the session (rule 12) is not safe. Not resolved: Natural Biology 3.3 (line 408) has the sentence unchanged.
NEW: -

### 35
VERDICT: KEEP
CONCEPT: two sayings part at a seed: Natural Biology's 4.1 has a seed inert beside a virus, and the newer concept has a seed at rest living, a carrying thing in dormant stable form; observations of old seeds and dormant spores are beside it.
EVIDENCE: Already a concern in plain voice, in the form of two sayings parting, with no waiting language. Not resolved: Natural Biology 4.1 (line 537) has "inert outside a host, as a spore or a seed is inert". A row points at it: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 641, "| Two sayings parting at a seed inert and at the reaction dead | Offerings to Natural Biology |". Its links are there: Carryings of Natural Biology "### Date seeds germinating after two thousand years" (line 176) and Offerings to Co-Chaining Logic Registry "## Living as a stable changing form, at the observations · v386EOD" (line 336). This mate's later sections on a seed ("A seed and a virus, parted at carrying", "At 4.1 …, a sentence offered", "A seed, a living society at its prime scale", each v386EOD) say other things of it and none has this parting with its four observations.
NEW: -

### 36
VERDICT: KEEP
CONCEPT: two sayings part at combustion: Natural Biology's 3.1 has the reaction dead, and the newer concept has a flame a society of molecules stable forming, living at its grain; the file's "Living is metabolic beating" is beside the same concept.
EVIDENCE: Already a concern in plain voice, in the form of two sayings parting, with no waiting language. Not resolved: Natural Biology 3.1 (line 373) has "Combustion lands (fire, ash, the surplus lost as heat, the reaction dead)". The same row points at it (Carryings of Living File Registry line 641, "… and at the reaction dead"). Its links are there: Carryings of Natural Chemistry "### A candle's flame in orbit" (line 68) and Offerings to Co-Chaining Logic Registry line 336. At no later section of this mate.
NEW: -

### 37
VERDICT: KEEP
CONCEPT: beside this mate's defining-living droplets a newer naming is at Offerings to Co-Chaining Logic Registry, living as existing as a stable changing form; the droplets here have a flame among the comparisons alternating alone does not part, and further cases are at Possibling of Natural Biology.
EVIDENCE: A paragraph laid on other paragraphs of this mate (rule 2), in plain voice with no waiting language. A row points at it: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 662, "| 8 · The defining of living | The defining-living droplets at Offerings to Natural Biology and Natural Intelligence; a newer naming laid beside them now, living as a stable changing form |". Its links are there: Offerings to Co-Chaining Logic Registry line 336 and Possibling of Natural Biology "## Cases for living as a stable changing form · v386EOD" (line 49); the droplets it names are this mate's "Recognizing living without making the break unavailable · v385A".
NEW: -

### 38
VERDICT: KEEP
CONCEPT: healing from a prior colliding is the surface resolving by bi-tunneling, and a rolled edge at a skin cut is the bounding zeroing, natural torusing at the skin's surface; the whole droplets are at Offerings to Natural Networking.
EVIDENCE: Already a droplet in the present form and plain voice, with no waiting language: a direction at this subject to the whole droplets, which are at carry/Exhibit_TWO_Offerings_to_Natural_Networking.md "## A surface resolving after a colliding · v386EOD" (line 351). It is this mate's direction, as this mate's "Skin repair and the changing at its edge · v385A" is the earlier one; releasing it as said there would leave the present naming at no place of this subject. Not at the living file.
NEW: -

### 39
VERDICT: KEEP
CONCEPT: two sayings part at *releasing*: Natural Biology's 7.4 has releasing as decay, and the newer concept has releasing as uncoupling and the self's next momentarying, with a society's ceasing of its own co-chaining.
EVIDENCE: Already a concern in plain voice, in the form of two sayings parting, with no waiting language. Not resolved: Natural Biology 7.4 (line 790) has "Decay is the couplings releasing, one at a time, while the members stand." Its link is there (Offerings to Natural Networking line 351). This mate's "Releasing and the particular society coupling · v385A" has the earlier correcting at 7.4 and not this parting at the sentence.
NEW: -

### 40
VERDICT: KEEP
CONCEPT: two sayings part at a rate locked: living rates are locked to the day at 4.5, and the Co-Chaining Logic Registry has φ locking at none; a locked rate as natural torusing, a coupling among the selves and the day, is said at neither; no natural observation is beside it.
EVIDENCE: A later paragraph points at it, so it stays (rule 2): this mate's "Concern · A rate locked." (v386EOD), "Beside the concern at this mate of a rate locked and a rate locking at none"; also Carryings of Natural Biology line 271, "**The file's sentence**: at the offering mate, the concern of a rate locked", and Carryings of Living File Registry line 711, "| Living rates locked to the day, a concern | Offerings to Natural Biology |". Already a concern in plain voice. Both quotations are exact at Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md, and the section 4.5 is at Natural Biology line 579. Its last sentence is true now: the observing beside it at Carryings has "*Natural observation*: none read; a field's definition."
NEW: -

### 41
VERDICT: KEEP
CONCEPT: a mutation is a precise accounting at a gene and a form named still as a disease's name at each scale; a hormone as a trigger, a signal or a controller is three doers placed beside a coupling; the whole droplet is at Offerings to Resolving Hard Problems.
EVIDENCE: Already a droplet in the present form and plain voice, with no waiting language. A row points at it: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 743, "… Offerings to Resolving Hard Problems, with a direction at Offerings to Natural Biology". The whole droplet is there: carry/Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.md "## A hard problem, a saying from outside each coupling · v386EOD" (line 153), "Droplet · Doers from outside." (line 163). Not at the living file.
NEW: -

## READING
Each of the forty-one paragraphs was read and checked. Read whole: the brief BRIEFO3.md with its further rules; the input BI_1.txt; the mate carry/Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md from its first line to its last (the Insertlets, the older Droplets, and each section headed v385A and v386EOD). The living file Exhibit_SEVENTEEN_Natural_Biology_v333.md is 35,858 words and was not read whole: its headings were read, 4.1 was read whole, and each sentence the paragraphs name was found by exact search with its section (each present and unchanged). Other living files were searched and the places read: Exhibit TWENTY Natural Naming (4.9 and its table whole; the rows of 2.4), Exhibit THIRTY Co-Chaining Logic Registry (steps 20, 100, 103, 380; the two sentences of paragraph 40), Exhibit EIGHTEEN Natural Physics (1.1, the line of 4.6, its headings), Exhibit SIXTEEN Natural Chemistry (1.1, 1.2 and 6.4 whole; the lines of 5.1 and 5.4), Exhibit TWO Natural Networking and Natural Intelligence by search. Mates read in part: Carryings of Natural Biology (its v385A sections whole, its headings, and the observings the paragraphs link); Possibling of Natural Biology's headings; Carryings of Living File Registry's rows at lines 465, 564, 598, 641, 661, 662, 711, 743 and 780; Living Improving Value line 289; the linked sections of Offerings to Co-Chaining Logic Registry, Natural Networking, Resolving Hard Problems, Natural Medicine and Natural Transmissioning. Sources read for the one-line pointers: carryings/physics_for_other_files_v377/README.md (2.3), carryings/rings_are_spirals_v377/README.md (its table and sections 4 to 6), carryings/co_chaining_coverage_v378/readings/09_chemistry_biology_health_medicine.md, carryings/v380R/Natural_Networking_From_v380A.md, archive/session_v380/v380G/README.md, carryings/resettling_v373/Re-Settling_the_Living_Files.md (its line 254), carryings/v368_sources/Wrap_v368.md (line 73), and Natural Physics at version 348 in the repository's history for the older 1.1 and 3.6. Each quotation in a NEW was found by exact search in the living file it names; each NEW was numbered at its words (48 to 148) and searched for the barred words.

The whole section is pointed at by subject from Carryings of Living File Registry line 465 and Living Improving Value line 289, and many of its paragraphs by a later paragraph or a carrying; no paragraph is released, and each re-saying has the subject words those rows use.

Not found: the place paragraph 5 names as "the run above"; the place paragraph 8 names as "the carrying's Natural Intelligence section"; which session paragraph 34 names as "this session". Those three paragraphs are left exactly as they are. At paragraph 7 the older sentence of Natural Physics 1.1 is gone and its present sentence is quoted in its place; this is said in that block's EVIDENCE for a second reader to judge. At paragraph 1 the one place of the older *held* form was found by search at 2.3 and is given in EVIDENCE alone.

Verdicts: RESOLVED 0, SAID 0, NOVALUE 0, RESAY 9 (1, 3, 4, 6, 7, 9, 10, 17, 18), KEEP 32.
