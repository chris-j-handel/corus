### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: OK
WHY: Exhibit_TWENTY_Natural_Naming_v380R.md lines 603 to 622 read: "## 4.9 The ten named still, one name each" and its table have each of the ten names in NEW word for word; an exact search of *held* in Exhibit_ELEVEN_Natural_Medicine_v331.md gives the older forms at lines 147, 377, 533 (twice), 535, 539, 541, 549, 551 and 601 (four), thirteen as the prior has it; the place 4.9, the number thirteen and "each re-said at its one name at this file's motion" are each in NEW at the prior's strength, and what is left out is the report's name and "received at v378" alone.
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 51, with its column heads (Words, Version, Shape at this reading, Its own subject, Restating the common method, Old code or older wording), has each of the six things NEW says and no more: 25,500, version 331, carefully sourced and overstuffed with 3.1 alone at 5,900, about 70%, about 7%, and the persistence reading resting on the old bound; the two numbers of words are said as that reading's, and "## 3.1 Two adjacent societies at a gut collar" is the living file's 3.1 still.
SAFER: -

### 10
CHECK: OK
WHY: laid beside the prior clause by clause and beside carryings/resettling_v373/Re-Settling_the_Living_Files.md, the first of its "Five findings": each percentage, each number of files, each file and each section number of the prior is in NEW; both quotations are exact strings of living files ("Non-living existing things are included in discovering social moral competency among the living." at Natural_Intelligence_v380R.md line 1134, Exhibit TWENTY Natural Naming line 1163 and Exhibit TWENTY-EIGHT Equilibria Registry line 132; "a sign, sign-only — summing to a bounding-zeroing made by the coupling itself" at Natural Societies line 95, Natural Health line 57, Natural Medicine line 87 and Natural Destinies line 39, each under the section the prior names); "At version 373" is the prior's own tag, and the past is right, Natural Intelligence having six parts and no 7.2 now (the sentence is under its 6.5).
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OK
WHY: laid beside the prior clause by clause: the two files as one file releasing one number, the saying of both files, the three repeatings with each section number (Natural Health's "## 2.1", "## 2.2" and "## 4.1" and Natural Medicine's "## 2.1" and "## 5.2" read at the headings now), the five parts in order, the model, "about a third of it", the rebuilding "before unpausing" and "a rebuilding of the argument, not a wording pass" are each in NEW at the prior's strength, with no quotation; the one thing left out, "(new)", is the draft's mark that this receiving is beyond those agreed ahead of it, said at a later place, Possibling of Living File Registry's "## Earlier proposed exhibit combination and distribution · v385A" ("A fifth is proposed: Natural Health and Natural Medicine as one file, releasing one of TEN and ELEVEN"); the title has the subject words the three v385A sections find it by.
SAFER: -

### 13
CHECK: OK
WHY: the quotation is an exact string at each of the four places the prior names (Natural Societies line 95 under "## 1.1", Natural Health line 57 under "## 1.1", Natural Medicine line 87 under "## 1.1", Natural Destinies line 39 under "## The core — the bi-moral co-agency"), and Natural Values has "## 4.1" at its line 139; the five places and "released, old code" are in NEW as the prior has them, the releasing said as a saying of the sentence beside its being at the five places still, as the source's row has it (line 219, "Released: old code" under "One home"). The title's name for the sentence, "the core coupling sentence", is no word of this paragraph; it is paragraph 10's name for the same sentence, from the same source, and gives the sentence no claim the prior does not have.
SAFER: -

### 14
CHECK: OK
WHY: each quotation is an exact string under the section NEW names: Exhibit_TEN_Natural_Health_v329.md line 85, the opening sentence of "## 3.4 The flawed-ingestion disease-face, and the value of the outer living form"; Exhibit_ELEVEN_Natural_Medicine_v331.md line 163, in 1.3, "The food-cause is set down here: it re-installs a one-way actor the form does not carry"; and its line 651, in 5.1, "*Read at that same binary and not standing here:*" with "the food-as-primary-determinant at the liver collar" the one saying of food in that list (5.1 read from line 645 to 657); the three places 3.4, 1.3 and 5.1, the food claim, the setting down and the listing as not standing are each in NEW, and the closing sentence says the parting in the prior's own words.
SAFER: -

### 15
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 has the ten files at their four versions and "Forty-five to forty-nine versions behind the apex, each at the old seventeen names, the old code's means and words since released", and its line 15 the apex at v377 to v378; the ten files are at those versions at the root now (file names read); each file, each version and each of the three things each file is at are in NEW, the number of versions said as of session v378's apex, with no quotation.
SAFER: -

### 16
CHECK: OBJECT
WHY: Lost: a relation among files, beside the number. The prior has two things: the number of ready paragraphs (five, a number of findings, and those five are paragraphs 1 to 5 of this section, each staying), and that Natural Medicine is "one of the two prior-to-momentarying files with real incoming". The second is no number of findings: it parts two of the ten files prior to momentarying from the other eight, whose incoming the source has as receivings at pass G (carryings/session_v378/Session_Report_v378.md line 21, "Two carry real incoming: Natural Biology, eleven ready and eight concerns, the largest carrying after Physics, and Natural Medicine, five ready. The rest are at pass G"). It is at no later place: "real incoming" is at this paragraph alone in carry/*.md; Carryings of Natural Biology's "## Reported ring comparison and earlier gathering condition · v385A" (line 33) has Natural Biology's side alone ("the subject with the most incoming before its improving"); the NEW of paragraph 15 has the ten files and nothing of which carry incoming, and the NEW of paragraph 17 has Natural Biology alone. The like standing of another file ("the largest carrying of the set", Offerings to Natural Physics) was re-said and not released. No paragraph points at this one (the mate read whole; "five ready" elsewhere is Offerings to Natural Chemistry's own number).
SAFER: KEEP

### 17
CHECK: OBJECT
WHY: Two things. Lost: the number. The prior has "Opportunity 2" from "The opportunities, in order": Natural Biology's motion is the second of seven in that session's order (carryings/session_v378/Session_Report_v378.md lines 23 to 31, Natural Physics the first), and NEW has neither the 2 nor the order. A later section finds it by that number: Carryings of Natural Biology, "## Reported ring comparison and earlier gathering condition · v385A" (line 33), closes "The earlier report is Session_Report_v378.md, section 3, Opportunity 2." Added: a present saying. The prior has "the sciences' pause is the only thing before its motion" within quotation marks, as the report of session v378; NEW dates the most incoming "At session v378" and then says the pause as the only thing before the motion plainly, as so now. The same later section says of these "These are earlier conditions and a proposed dependency order, not the present work order or an examined current backlog", and no file read gives the pause as the only thing before Natural Biology's motion now. The rest is sound: the pass B carrying Natural Medicine and Natural Health, "which lean on it", the aiming at Natural Biology and the closing sentence are as the prior has them, with no quotation.
SAFER: **Possible project · Natural Biology's motion, its pass B carrying Natural Medicine and Natural Health.** The work is Natural Biology's motion, the second of the opportunities in order at session v378. At that session Natural Biology had the most incoming of the files prior to momentarying, and the sciences' pause was the only thing before its motion. Its pass B carries Natural Medicine and Natural Health, which lean on it. It is aimed at Natural Biology. It may change or never be made.

### 18
CHECK: OK
WHY: carryings/v368_sources/Wrap_v368.md line 73 has "**Across the set.** Each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words."; NEW is that sentence with the prior's "Across the set", each of the five words and the namings of other exhibits in it, nothing beside them but the aiming at the set, which is the prior's own opening.
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the task; the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file ME_1.txt and the PROPOSED file ME_1_report.md; the mate carry/Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md, each of its 280 lines (its older `## Droplets` section and each section headed · v385A and · v386EOD).

Read in the sections the paragraphs name and searched in the rest (the living file is 25,140 words, over the fifteen thousand): Exhibit_ELEVEN_Natural_Medicine_v331.md at its headings, its line 163 (1.3's paragraph of the food cause) whole, 5.1 from line 645 to 657, 5.2 at lines 659 to 661, and each line having *held*. Other living files: Exhibit_TWENTY_Natural_Naming_v380R.md 4.9 (lines 603 to 626); Exhibit_TEN_Natural_Health_v329.md at its headings, 3.4 whole (lines 83 to 87) and 4.1 (lines 110 to 112); Natural_Intelligence_v380R.md at its part and section headings from Part Two on; the headings of Natural Societies, Natural Destinies and Natural Values; the root's file names for the ten versions of paragraph 15.

Sources read at the lines the paragraphs are from: carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 24 to 40, 51, 70 to 80, 183 to 200, 205 to 222 and 250 to 260; carryings/session_v378/Session_Report_v378.md lines 10 to 34; carryings/physics_for_other_files_v377/README.md line 26; carryings/v368_sources/Wrap_v368.md line 73. Mates: carry/Exhibit_SEVENTEEN_Carryings_of_Natural_Biology.md line 33 with its headings; carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md at lines 34 to 36, 207, 215 and its headings from 153 to 237; carry/Exhibit_ELEVEN_Possibling_of_Natural_Medicine.md lines 13 to 15.

Checked by exact search: each quotation in a NEW paragraph, in the living file it names (paragraphs 10, 13 and 14), and each of the ten names of paragraph 5 in Natural Naming's 4.9; "real incoming", "five ready", "most incoming" and "prior to momentarying" in carry/*.md for paragraphs 15, 16 and 17; the namings of the proposed combination of Natural Health and Natural Medicine in carry/*.md for paragraph 12. Each NEW paragraph was laid beside its prior clause by clause, and its length and the first reader's word list were checked by script (48 to 147 words by a split at spaces, the form's mark and title within the number; none of the listed words in the first reader's own sentences); the corrected paragraph at 17 was checked the same way (82 words, none of the listed words).

Earlier reports of this working were read for the like paragraphs alone, after my own reading: XP_1_harm.md blocks 4, 14, 16 and 17; NN_2_harm.md and NN_2_report.md block 50; EQ_4b blocks 133; PH_6b blocks 211. At NN_2 block 50 the like "Opportunity 3" was re-said with its number left out and found sound; at 17 here I read it otherwise, a later section of Carryings of Natural Biology naming the opportunity by its number.

Not settled here: the twelve blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 13 the title's "the core coupling sentence" is paragraph 10's name and no word of paragraph 13; I read no adding in it and say so in the block. At 16 a re-saying in place of KEEP is possible (the number as session v378's, and Natural Medicine as one of the two files prior to momentarying with real incoming), but it comes under forty words, and KEEP loses nothing. The publishings the paragraphs cite were not opened.
