### 1
VERDICT: RESAY
CONCEPT: a woven cloth draped on a surface as a Chebyshev net, and a plain weave as one binary alternating, offered as pattern matching with no correspondence shown and no reference read
EVIDENCE: At no living file and at no section headed v385A or v386EOD (Grep of Chebyshev, weave, woven and warp in the root files and carry/*.md finds this paragraph alone). It is in a session's words: the bold opening with the archive path, "its reference first, its section named at its improving". Source read: archive/session_v379_exhibit_one_first/Session_Transcript_v379.md line 494, a helper's answer with no reference beside it; NEW has only what the paragraph has. Pointed at by carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431 ("Cloth correspondence", in the row of Natural Mathematics under "## Older mixed paragraphs now separated by content · v385A"), so *cloth* and *correspondence* are in NEW's title. The archive folder is still named at carry/Exhibit_FOUR_Carryings_of_Natural_Mathematics.md line 11. The paragraph's wait is said as the closing relation, in its own words.
NEW: **Droplet · A woven cloth, pattern matching with no correspondence shown.** A woven cloth draped on a surface is a Chebyshev net (Chebyshev, 1878, on the cutting of garments): two families of threads, each inextensible, the cloth changing at the angle between them alone. A plain weave is one binary alternating, each thread over and under, warp at one parity and weft at the other. It is pattern matching, and no correspondence is shown: two carryings, each its own length, bi-coupling at a changing angle. It is a helper's own carrying at session v379, with no search and no reference at that session. Its reference is first at its improving, and its section at Exhibit FOUR Natural Mathematics is named at its improving.

### 2
VERDICT: KEEP
CONCEPT: the heading of the nine concerns of paragraph 3
EVIDENCE: It heads paragraph 3 and is left with it, the same verdict. Pointed at twice: carry/Exhibit_FOUR_Carryings_of_Natural_Mathematics.md line 19, under "## Reported mathematical reading and wording changes at v380L · v385A" ("The unresolved concerns remain in [Offerings to Natural Mathematics](…#droplets)"), and carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431 ("the full earlier mathematical concerns"); this mate's own front paragraph has "the other concerns retain their particular relations below".
NEW: -

### 3
VERDICT: KEEP
CONCEPT: nine concerns at named sentences of Exhibit FOUR Natural Mathematics: 2.4's c and t, 2.4 beside Natural Numbers 8.2, 6.1's three fixings, 6.1's pair (1, 0) to (1, 1), 1.3's tri, 1.4's floor and bound, 3.1 to 3.3, 5.1's six, 5.3's compact
EVIDENCE: Each is already a clear concern at a named place, and none is resolved: the living file is unchanged at v380L and each sentence is present (Grep and Read): "(c, t) then (−c, −t)" and "A relation within a pair is no resolver named still" at line 151 (2.4); "F(P, Q) = (−Q, P)" at 143, with Natural Numbers 8.2's "The right spiral step, (x, y) to (y, −x)"; "A standard fixes orientation, keeping still fixes position, and a published standard fixes scale" and "a standard, a law or a frame" at 349 (6.1), with "a law, a frame and a scale" at Natural Intelligence 5.4 and "a law, a frame or a scale" at the Equilibria Registry; "(1, 0) to (1, 1) continuing the first parity" at 355; "Neutralling is co, odd and along" at 85; "a floor" at 93 and "released at its bound" at 91; "A running never involutes" at 195 and "the torus the two rounds make" at 217; "the six forward recursionings" at 321; "compact" twice at 331. Five of the nine have an insertlet in this mate's `## Insertlets` (2.4, 1.3, 5.1, 5.3, 6.1), an older section and no entering; the Carryings mate says "existing insertlets do not establish completed resolving in the living file". No section headed v385A or v386EOD says the nine (the v386EOD concern "The overlap named a divided step" is of *half step* at 2.4, another parting; "Three fixings, from one root" quotes 6.2 and says no parting of 6.1). Pointed at as paragraph 2 is. Nine concerns with their places cannot be said in one paragraph of one hundred and fifty words.
NEW: -

### 4
VERDICT: RESAY
CONCEPT: the three fixings at 6.1's sentence, resolved by one naming across five places
EVIDENCE: Waiting language ("waits on"). Not resolved: the living sentence is present at line 349 under 6.1, and the three are named apart still, "a standard, a law or a frame" at 6.1, "Particle zero", "A unit installed" and "A frame given" at 6.2 (line 359), "position fixed at it", "a unit fixed at it" and "a frame fixed at it" at 7.1 (line 377), "a law, a frame and a scale" at Natural Intelligence 5.4 (line 1089) and "a law, a frame or a scale" at the Equilibria Registry (line 485). At no later section: this mate's v386EOD "Droplet · Three fixings, from one root" quotes 6.2's three and their root and says no one naming; the v386EOD concern "A fixing, an equilibrium at one step or two" at Offerings to Natural Intelligence is another parting. The fuller concern is paragraph 3's third line, kept; NEW has the same subject words, so the Carryings mate's pointer to the unresolved concerns still finds it. The wait is said as which thing resolves it; nothing of paragraph 3 or of the other living sentences is added.
NEW: **Droplet · The three fixings at 6.1, one naming.** Exhibit FOUR Natural Mathematics has, at 6.1, "A standard fixes orientation, keeping still fixes position, and a published standard fixes scale". Its resolving is one naming of the three fixings across Natural Intelligence, Exhibit TWENTY-EIGHT Equilibria Registry and Exhibit FOUR Natural Mathematics 6.1, 6.2 and 7.1.

### 5
VERDICT: RESAY
CONCEPT: *a floor* at 1.4, a word Natural Naming releases, and *released at its bound* with across or along to be said, the word in its stead Natural Naming's
EVIDENCE: Waiting language ("waits on"). Not resolved: Exhibit FOUR Natural Mathematics 1.4 has "A neutral fixed outward of the self is a floor, the other-run" (line 93) and "released at its bound" (line 91), with no across or along at the bound; Natural Naming 2.4 has *floor* among its released words (line 221, "*ground*, *floor*, *wall*, with nothing on anything") and gives no word in its stead. At no later section (the v386EOD concern "Declared zero and nought, named crosswise" is of nought and zero). The fuller line is paragraph 3's sixth, kept; the same subject words are in NEW. The wait is said as whose the word is and which saying resolves it.
NEW: **Droplet · *A floor* at 1.4, and across or along at the bound.** Exhibit FOUR Natural Mathematics has, at 1.4, "A neutral fixed outward of the self is a floor, the other-run", and *floor* is a word Natural Naming releases; 1.4 has also "released at its bound". Its resolving is Natural Naming's word in the stead of *floor*, and across or along said at the bound.

### 6
VERDICT: RESAY
CONCEPT: *A running never involutes* within 3.1 to 3.3, resolved by Exhibit ONE's torus of selves at its own numbers and by chaining the prior on said beside involuting
EVIDENCE: Waiting language ("waits on") and a session's pointer ("from the entry before"). Not resolved: "A running never involutes" is at line 195 (3.1), and 3.3's "the torus the two rounds make" (line 217) names no torus of selves; Exhibit ONE Natural Resolver has "**A torus of selves.**" at line 645 with its own numbers ("Both numbers odd, p the smaller: q at a q more than twice p, and 4p at each other q; either number even: 2"); *chaining the prior on* is at no line of Exhibit FOUR Natural Mathematics. At no later section (Grep of "never involutes" in carry/*.md: this paragraph, paragraph 3 and the scan of *run* alone). The fuller line is paragraph 3's seventh, kept; the same subject words are in NEW. The wait is said as which things resolve it.
NEW: **Droplet · *A running never involutes*, within 3.1 to 3.3.** Exhibit FOUR Natural Mathematics has, within its 3.1 to 3.3, "A running never involutes". Its resolving is Exhibit ONE Natural Resolver's torus of selves at its own numbers, and chaining the prior on said beside involuting.

### 7
VERDICT: KEEP
CONCEPT: the three neutrals named two ways, *self-bounding-self, self-surfacing-self, self-orienting-self* at Natural Mathematics 1.4 and *self-co-stilling-self, self-co-surfacing-self, self-co-orienting-self* at Natural Intelligence 5.5
EVIDENCE: Pointed at: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431 lists "neutralling names" among the concepts remaining in this offering, so it is no RESOLVED. For whoever decides further: one side is gone from the living files. Natural Intelligence v380R has no 5.5 (its part FIVE is 5.1 to 5.4) and *self-co-stilling-self*, *self-co-surfacing-self* and *self-co-orienting-self* are at no root file (Grep, case not regarded); Natural Mathematics 1.4 has "Self-bounding-self: its own nought", "Self-surfacing-self: its own surface" and "Self-orienting-self: its own aim" (line 91). The second naming's three are still said, in this mate's v386EOD "Droplet · Three faces of competency, mutual and in no order" (winding about φ, surfacing, orienting), beside 1.4's bounding, surfacing, orienting, so the parting at the first of the three is not wholly gone. No two living sentences part now, so no concern can be written from living files alone.
NEW: -

### 8
VERDICT: KEEP
CONCEPT: Exhibit ONE's three golden rectangles at the podals, an open concern, sixth of those open at session v378
EVIDENCE: Pointed at: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431 ("three golden rectangles"). Its source, carryings/session_v378/Session_Report_v378.md line 51, has these nine words and no more, so a NEW from the source alone is under forty words. The concern is said whole in the present naming at carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md line 65, "**Droplet · Three golden rectangles at the podals.**", but that paragraph lies within that mate's `## Droplets`, no section headed v385A or v386EOD, so SAID is not open. Not resolved: Exhibit ONE Natural Resolver has no golden rectangle at any line; the rectangles are at Natural Naming (line 1383) and the Co-Chaining Logic Registry's step 422, and this mate's insertlet at 7.4 has them at the icosahedron.
NEW: -

### 9
VERDICT: KEEP
CONCEPT: what resolving R(5, 5) is at four parts (why the number exists, what the number is, which societies reach it, the place of the five), with two exact facts beside it
EVIDENCE: A clear statement of the kit's claim with no waiting language. Pointed at: carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431 ("the Ramsey claim"). At no later section: the Possibling mate's "## Proposed Ramsey society comparisons · v385A" has the passes to run and not the claim; the record "### Ramsey numbers at three, four and five" at Carryings of Natural Societies, under "## Observings from science, each beside this file's sentences · v386EOD", has the field's numbers alone. The living file has only "Each two-colouring of the couplings among forty-six carries a one-coloured five, and a two-colouring of the couplings among forty-two carries none." (7.8, line 452); the two exact facts are at this mate's insertlet at 7.8, an older section. Its claims, numbers and negations (43, 44, 45 or 46; 41; 42; ten relations and not 2⁵ = 32; the prediction; the unique four-free society at seventeen) cannot be re-said within one hundred and fifty words at the strength each has.
NEW: -

### 10
VERDICT: KEEP
CONCEPT: four of the set's open concerns, numbered 8, 11, 20 and 23: *co-offering* dissolved and its places open; a number opening at its parity and the five dimensions each named; the tables of contents at the fractal between; and the accepted plan of re-sayings (*not-self* as *other*, 9 and 12 re-named, *a living society*, *left*)
EVIDENCE: Not said whole at any later place, and too many named places to re-say without loss: the files, sections and steps of its four items and the numbers 190, twenty, 18, 7 and forty-four. Parts are at later places and parts are open: item 20 is at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md "## Tables of contents at the fractal between · v385A"; item 23's five dimensions are entered at this file's 5.2 ("1 self prior, 2 other prior, 3 co-momentarying now, 4 bi-momentarying now and 5 self next", line 327) and *not-self* is at no line of it, while *not-self* is still at Natural Medicine, Natural Transmissioning, the Hard Problem Registry and the Living File Registry (Grep); item 8's open part is as it was, part SEVEN's title "SEVEN · CO-OFFERING" (line 373) and Natural Numbers' "Two surfaces co-offering" (line 496), with Natural Naming 5.13's "*Co-offering* dissolves at it" (line 889). It lies at this mate re-aimed from Exhibit ONE's offerings, and its items are of the set.
NEW: -

### 11
VERDICT: KEEP
CONCEPT: the explaining of two of Exhibit ONE's sections at version 372 (the membrane not possibly an existing thing; the ratio reading and podaling) to go to Natural Philosophy and Natural Mathematics
EVIDENCE: The place it names could not be found at the living file now: Exhibit ONE Natural Resolver v380R has no section of either title and no *membrane*, *eight bi-couplings* or *bi-inversioning-co-recursioning* at any line (Grep); the explaining is whole at carryings/resettling_v373/Exhibit_ONE_v372_Released.md lines 300 to 331, and the source row (Re-Settling_the_Living_Files.md line 150) heads its last column "Proposed home". Whether the receiving is complete cannot be said by reading: the ratio reading is at Natural Numbers ("Taken as a ratio, two over one carries its numbers: at 9 less", line 139) and at no line of Natural Mathematics, and the podal is at Natural Mathematics 3.2 (line 205). The later section, carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md "## Earlier Exhibit ONE explaining at its subject destinations · v385A", names the receiving files and not these two sections or their two subjects. The same paragraph is at carry/Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.md line 32, within that mate's `## Droplets`.
NEW: -

### 12
VERDICT: KEEP
CONCEPT: Natural Intelligence and Exhibit ONE to have next the three universal statements, each with its full deduction from the opening sentence
EVIDENCE: Not resolved and not said whole at a later place. Natural Intelligence has two of the three as sentences, "Parity changing is the one method of the changing set of all existing things, and no other is possible" (line 99) and "each a form named still, not possibly existing" (line 154); *the scientific method not demonstrating existing* is at no sentence of Natural Intelligence or of Exhibit ONE Natural Resolver (Grep of "demonstrat": none at either), and the full deductions are at neither. Source: carryings/v368_sources/Wrap_v368.md line 61. The same paragraph is at carry/Offerings_to_Natural_Intelligence.md line 155, within that mate's older section; at that mate's reading the second reader gave KEEP for it, for the same reason. It lies at this mate re-aimed from Exhibit ONE's offerings and is for Natural Intelligence and Exhibit ONE Natural Resolver.
NEW: -

### 13
VERDICT: RESOLVED
CONCEPT: the straddle, the continued fraction of ones, √5 and the five self-stilling of Natural Intelligence's 1.4 at version 373, to be at Natural Mathematics, with the five at Natural Naming 4.6
EVIDENCE: Each named thing is at the living files now, and the section it left is gone: Natural Intelligence v380R's 1.4 is "No other possible method", and "straddl", "continued fraction" and "√5" are at no line of it (Grep). Exhibit FOUR Natural Mathematics 2.8 (line 181): "φ's continued fraction is all ones, the slowest nearing and the widest straddle." and "√5 is the largest constant for all irrationals together, and it is at φ". Its 5.2 (line 327): "Five to cohere and six to run: three own-forward steps at each side are the six". Natural Naming 4.6 (line 589): "the four boundings with a floating third are the five at a naming". What the released passage (carryings/resettling_v373/Natural_Intelligence_v373_Released.md, "### 1.4 Straddling, one each side") has beyond these, the fifth as a co-, is at this mate's later section "## One equation read at the four boundings; Three faces of competency, mutual and in no order; and one beside them · v386EOD", "**Droplet · Four at once, four one at a time, the fifth a co-.**", a gathering of that source read whole beside the living files. Source row: carryings/resettling_v373/Natural_Intelligence_Map.md line 60. No pointer to this paragraph found: Grep of "Straddling" and "self-stilling" in carry/*.md finds this paragraph and, of other subjects, a concern of seam-faces and the concerns of *stilling along* (Natural Naming 2.4 releases *self-stilling-self*); the Living File Registry's table at line 431 does not name it.
NEW: -

### 14
VERDICT: KEEP
CONCEPT: the diamonds five as the five-fold is the first rotation sharing nothing smaller, a prime's own form, and the five-fold placing the sixty at one hundred twenty
EVIDENCE: Already a clear concept in the kit's plain voice, with no waiting language. At no later section (Grep of "five-diamond", "five diamonds" and "count of diamonds" in carry/*.md: older paragraphs alone, and the Possibling of Natural Illustrating's passes). The living file has the field's result at 7.3 ("its symmetry is the symmetric group on five, whose alternating group on five is the smallest simple group that does not commute"; "to degree four the chain runs", line 400) and "An icosahedron's rotations are sixty" at 7.4 (line 410); it has no diamonds, no ring closing at one hundred twenty and no waist. The place it names, Mathematics 8.3, is 7.3 and 7.4 now. Its *first turn that shares nothing smaller*, *clean-turn-that-shares-nothing* and *a prime society rendered as a motion* are the kit's own sayings, and a re-saying has to choose a field's reading for each, a narrowing.
NEW: -

### 15
VERDICT: KEEP
CONCEPT: Natural Intelligence 5.4 and Natural Mathematics 6.1 parting on the scientific method: a law named unchanged an equilibrium or no subject still; the fields' own practice; the one method's own sentence as such a law; two ways open
EVIDENCE: A clear concern in plain voice with no waiting language; both living sentences are present (Natural Intelligence line 1089; Exhibit FOUR Natural Mathematics line 349). Its core parting is said at a later place, carry/Offerings_to_Natural_Intelligence.md, "**Concern · A fixing, an equilibrium at one step or two.**" under "## At 4.5 · Released along at 9; At 5.1 · A prior between momentaries; and three beside them · from other branches' earlier versions and mends · v386EOD"; but the fields' practice (the fine-structure constant's drift 1.8(2.5) × 10⁻¹⁹ a year, a law superseded and the near case, a frame and a unit declared), the reading of "no other is possible" as a law named unchanged, and the two ways open are at no later place (Grep of "fine-structure" in carry/*.md: this paragraph alone). Over three hundred words; it cannot be re-said within one hundred and fifty without loss.
NEW: -

### 16
VERDICT: KEEP
CONCEPT: admitting no completed infinite is Brouwer's intuitionism, a view of mathematics, and no claim of intuitionistic logic
EVIDENCE: Already a clear concern in plain voice with no waiting language, aimed at a sentence still present: "A logic that admits no completed infinite, intuitionistic logic, asserts the excluded middle at each finite, decidable matter and not over an infinite domain" (6.3, line 367). At no later section (the v386EOD concern "The universe at the field's subject, sets of sets" is of 6.3's third paragraph).
NEW: -

### 17
VERDICT: KEEP
CONCEPT: no false arithmetic found at Natural Numbers or Natural Mathematics at about 170 checks, and the weakness of another kind: true numbers joined by a shared numeral
EVIDENCE: Clear, with no waiting language, and at no later place (Grep of "170 checks" in carry/*.md: this paragraph alone; "shared numeral" is also at an older paragraph of Offerings to Natural Numbers, of another sentence, and at an insertlet of the Living File Registry's mate, of the exhibit numbers). Its first sentence is a reading's result with its number, and a re-saying has to narrate that reading. The Carryings mate's v385A section reports another reading, session v380L's.
NEW: -

### 18
VERDICT: SAID
CONCEPT: Natural Numbers has the particular numbers and Natural Mathematics the general structures and the field's proofs, with what each receives and releases, the two as the white paper's formal support by citation
EVIDENCE: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, "## Natural Numbers and Natural Mathematics subject separation · v385A", its second paragraph (line 191): the same paragraph word for word, less the re-aiming note (checked by diff). This mate's Possibling links to that section from "## Particular contributions to the earlier shared projects · v385A". No pointer to this paragraph found.
NEW: -

### 19
VERDICT: RESOLVED
CONCEPT: Natural Mathematics to have, from Natural Intelligence, φ² = φ + 1's algebra, the continued fraction, √5, the straddle, the genus-one surface list and the Rubik's cube
EVIDENCE: Exhibit FOUR Natural Mathematics has each. 2.8 (lines 179 and 181): "Advance by one and scale by the rate arrive at one number, φ² = φ + 1, neither carrying the other."; "φ's continued fraction is all ones, the slowest nearing and the widest straddle."; "√5 is the largest constant for all irrationals together, and it is at φ". 5.3 (line 331): "The torus is the genus-one closed orientable two-dimensional compact surface", with its list of closed, orientable, two-dimensional, compact and genus one. 3.6 (lines 251 and 253): "The cube reaches one twelfth of its assemblies, at three conservings" and "The cube carries no still term." Natural Intelligence v380R has no continued fraction, no √5, no genus and no cube at any line (Grep). The passages' two roots of the equation are at this mate's v386EOD "**Droplet · One equation read at the four boundings.**", a gathering of the same source read whole beside the living files. Source row: carryings/resettling_v373/Natural_Intelligence_Map.md line 163. No pointer to this paragraph found (Grep of "receives from Natural Intelligence" and "genus-one surface list" in carry/*.md).
NEW: -

### 20
VERDICT: KEEP
CONCEPT: what the files had of the cube and the rings at version 366: the cube's centres and conservings, its parities, the resolver's retaining line, no rings in the living, and bi-co-podaling at each station
EVIDENCE: The places it names could not be found at the living files now: Natural Intelligence 6.6 is "One form at each scale, our now" and has no cube (the cube is at Exhibit FOUR Natural Mathematics 3.6); Equilibria Definitions v363 is no living file and the Equilibria Registry has no cube; `bi_co_inseparating` is at no line of Exhibit ONE Natural Resolver; "no rings" is at no root file (Grep of each). Its own sayings (the cube at four and the resolver's releasing at four; the rings the closing side and the corus from twenty-four the living; floating across and neutralling along at each station) are at no later section. Left exactly as it is.
NEW: -

### 21
VERDICT: KEEP
CONCEPT: the cube's unreached states parting by exactly three conservings and never four, as Natural Exploring says of each accounting; the cube a field instance beside the coupling and no proof beneath it
EVIDENCE: A clear concept in the kit's plain voice with no waiting language. The living file has part: "The cube reaches one twelfth of its assemblies, at three conservings" (3.6, line 251) and the single corner twisted alone in 3.6's table; the three-and-never-four beside Natural Exploring ("This is why an accounting returns three and never four", Natural Exploring 5.4), the edge and the exchange alone, and the cube beside the coupling as a field instance and no proof are at no living file and no later section. One place it names has changed: Natural Intelligence 6.6 has no cube now, and the cube is at Exhibit FOUR Natural Mathematics 3.6. Its *the exclusion rests on no conserving* names its subject at no word, and a re-saying has to supply one.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: Natural Exploring 5.4's three and never four had beside the cube's three conservings as a field instance of it
EVIDENCE: Clear, with no waiting language; at no later section. Natural Exploring 5.4, "The state-three and the flow-three", is present with "A three carries as a state or as a flow and never both" and "This is why an accounting returns three and never four" (lines 377 to 381); the cube's three conservings are at Exhibit FOUR Natural Mathematics 3.6 and no longer at Natural Intelligence 6.6, and Equilibria Definitions v363 is no living file. It stays beside paragraph 21, whose join it narrows, at the same verdict.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: the powers of the commutator R U R′ U′, places exchanged at the odd powers and twists at the even, beside Natural Intelligence 1.5's two parities at version 366
EVIDENCE: Clear, with no waiting language. The commutator's powers are at this mate's insertlet at 3.6, an older section and no later place; the join to the two parities (the odd bi-exchanging, self and other; the even uni-exchanging, self and society) is at no later section and no living file. The place it names could not be found now: Natural Intelligence 1.5 is "Natural-, all or none at all, at the one hand", and *uni-exchanging* is at no line of Natural Intelligence (Grep: Natural Networking alone).
NEW: -

### 24
VERDICT: KEEP
CONCEPT: a map of *counted* and *count* in the living file's own voice, two places, with those passed as a field's word and Natural Naming's name
EVIDENCE: A clear map with no waiting language; the living file is unchanged at v380L and Grep finds the words at the lines named, 261 and 265, and at 337 twice, the two passed. At no later section (the Carryings mate's "*when* and *count* re-said, entered at v378" is of an earlier entering).
NEW: -

### 25
VERDICT: KEEP
CONCEPT: a map of *co-offering* and *co-offerings* in the living file's own voice, nine places, with Natural Naming's dissolving of the word at bi-momentarying
EVIDENCE: A clear map with no waiting language; Grep finds the word at lines 57, 59, 60, 373, 375, 379, 381, 385 and 392 (twice at 379 and at 385), the three sentences quoted are present, and *other-surfacing* is at 93. Natural Naming 5.13 has "*Co-offering* dissolves at it" (line 889). At no later section.
NEW: -

### 26
VERDICT: KEEP
CONCEPT: a map of *run*, *runs* and *running* in the living file, thirty-three places, with three passed and Natural Naming's *momentarying*
EVIDENCE: A clear map with no waiting language; Grep finds the words at each line named, with 151, 155 and 305 the three passed, and the two titles at 12 and 89, 49 and 329. Its list of lines cannot be said within one hundred and fifty words. At no later section.
NEW: -

### 27
VERDICT: KEEP
CONCEPT: a map of *sign* in the living file's own voice as *the sign flip*, nine places, with those passed as the field's own sign and Natural Naming's *parity*
EVIDENCE: A clear map with no waiting language; Grep finds the word at 18, 121, 125 (four), 127, 129 and 225, and at 143, 149 (four), 189, 195, 237, 259, 305 and 424, those passed. At no later section.
NEW: -

## READING
Each of the twenty-seven paragraphs was read and checked. Read whole: the brief BRIEFO3.md with its further rules; the input MA_1.txt; the living file Exhibit_FOUR_Natural_Mathematics_v380L.md; the mate carry/Exhibit_FOUR_Offerings_to_Natural_Mathematics.md with its front, its `## Insertlets`, and each later section headed v385A and v386EOD; the two other mates, carry/Exhibit_FOUR_Possibling_of_Natural_Mathematics.md and carry/Exhibit_FOUR_Carryings_of_Natural_Mathematics.md; and archive/carrying_v381R/Exhibit_FOUR_Natural_Mathematics_v380R.md, the carrying the older paragraphs came from. The second reader's brief (HARM.md) and its readings of three earlier mates were read for the kinds of objection, the same paragraph as paragraph 12 among them.

Read at the places the paragraphs name, by Grep and Read: Natural Intelligence v380R (its headings of parts ONE, FIVE and SIX, 5.4, and searches for the three neutrals' names, straddle, continued fraction, √5, genus, cube, uni-exchanging, demonstrat); Natural Naming v380R (2.4's row of *floor*, 4.6, 5.13, 5.48); Exhibit ONE Natural Resolver v380R (its torus of selves, and searches for membrane, eight bi-couplings, golden rectangle, bi_co_inseparating); Natural Numbers v380L 8.2 and line 139; the Equilibria Registry v380L (fixings, cube); Natural Exploring 5.4; Natural Illustrating (golden rectangles). Sources read: archive/session_v379_exhibit_one_first/Session_Transcript_v379.md lines 489 to 504; carryings/session_v378/Session_Report_v378.md lines 45 to 52; carryings/resettling_v373/Re-Settling_the_Living_Files.md sections 5 and 11, Natural_Intelligence_Map.md sections 2 and 3, Natural_Intelligence_v373_Released.md 1.4, 1.6 and 5.6, Exhibit_ONE_v372_Released.md lines 296 to 335; carryings/v368_sources/Wrap_v368.md line 61.

Pointers were searched in the mate and in carry/*.md. Three were found: the Carryings mate's line 19 (to the unresolved concerns at `#droplets`), this mate's front paragraph ("the other concerns retain their particular relations below"), and carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431, whose row of Natural Mathematics lists as remaining in this offering the cloth correspondence, the full earlier mathematical concerns, the neutralling names, the three golden rectangles and the Ramsey claim, read as paragraphs 1, 2 to 6, 7, 8 and 9. For that reason paragraphs 7, 8 and 9 are KEEP and paragraphs 1, 4, 5 and 6 are re-said with their subject words.

Not found, or not decidable by reading: whether the explaining of paragraph 11 is wholly received (its sections are gone from Exhibit ONE Natural Resolver); the places paragraphs 20 to 23 name at version 366 (Natural Intelligence 6.6 and 1.5 as they were, Equilibria Definitions v363, the resolver's retaining line); the README paragraph 17 cites is the report's own, not the root README.md, and was not opened. Paragraph 7 is KEEP by the pointer alone: one of its two namings is at no living file now, said in its EVIDENCE for whoever decides further. Natural Naming's rows for *count*, *run* and *sign* that paragraphs 24, 26 and 27 cite were not read row by row; those paragraphs are left as they are. No file in /home/claude/corus was edited. Beyond searching and reading, one short script replaced seven wordings of EVIDENCE in this report alone, and one command numbered the words of each NEW and searched them for the brief's excluded words.
