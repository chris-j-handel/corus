### 33
CHECK: OBJECT
WHY: Lost: the subjects of the last sentence. The prior has "From the v380L reading's four things seen; outside the eleven mends", signed v382F; NEW has "one of four things seen at one reading" and "the eleven mends" with neither named. The eleven are session v382F's mends of Natural Intelligence, made from the working v380L's reading by hand (carryings/v382F/Session_Report_v382F.md, lines 17 and 89; Carryings of Living File Registry, line 856, "Seven of session v382F's eleven mends are at Offerings to Natural Intelligence already and four are laid as offered sentences"; Carryings of Natural Intelligence, line 43, the proposed version "offered and not yet received"). With "v380L" and the signature released, the negation "it is none of the eleven mends" is of no mends a reader can find, and the sentence narrates a reading without naming it. "From the v380L reading" by itself is a version label and no loss, as at 34; the negation is the part that needs its subject. All else is whole: both quotations are exact (Natural Intelligence line 1004; Exhibit ONE Natural Resolver lines 383 and 576), and lines 14 to 21 and line 28 of the resolver are the surfacing at 14 and the inverting at 12 (read). The corrected NEW names a working and a session; if a NEW is to name neither, the safer is KEEP.
SAFER: **Concern · The cell of 14 quoted at its prior words.** Two sayings part. Natural Intelligence has "14-bi-tri-bi-moralizing, the offerings surfacing, the self's own inverting, morality". Exhibit ONE Natural Resolver has "the offerings surfacing, each as it arrived, morality; the self's own inverting at 12". They part at the name the self's own inverting is at: Natural Intelligence's sentence at 4.10, line 1004, has Exhibit ONE Natural Resolver's cell of 14 at the cell's prior words, and at the resolver 14 inverts nothing, lines 14 to 21, the inverting at line 28. It is one of four things seen at the working v380L's reading, and it is none of session v382F's eleven mends.

### 34
CHECK: OK
WHY: the four quotations are exact at Natural Intelligence line 1000, Exhibit ONE Natural Resolver lines 473 and 400 and Exhibit THIRTY Co-Chaining Logic Registry line 1912 (step 430), the three places and the one word asked are all in NEW, and "From the v380L reading" is a version label with no claim in it.
SAFER: -

### 35
CHECK: OBJECT
WHY: Lost: the place of the work laid ready. The prior ends with its sources, "Session_Report_v381F.md parts 4.1, 4.2, 10 and 12, Findings 12, 14 and 18; Entry_Journey_For_An_AI.md part 3; Next.md Ready"; NEW has "Laid ready are 4.9's windings re-said at the overlap, and the other sayings at their sentences, fifty-five, each one word" and no place, and what the one word is is at no living file and at no later section of this mate (searched: *so-far* and *not-yet* are at this mate in its insertlets at 4.7 and 4.10 and in this older section alone). It is at the source, carryings/v381F/v381F/Session_Report_v381F.md, part 12, lines 226 to 232: "The re-saying at each file is one word at each, the four facings at their momentary", with *bi-moral-so-far* said the other's prior at the self's now, at 2 and 14, *not-yet-bi-moral* the self's now at the other's next, at 6 and 10, *not-yet-co-competent* the next prior, at 9, and *co-competent-so-far* the next now, at 17. The rest of NEW was checked and is whole: 25 and 30 by search of the living file; "at the overlap" at Next.md line 50; the words, tokens and size at Entry_Journey_For_An_AI.md line 53; 38 versions from v249, the three files named and no -ing word at Findings 18, 12 and 14 (lines 175, 97 and 105), the prior's "…" being a quoted sentence of Exhibit FOUR and no further file. The corrected NEW adds what that source says of the one word and no more, at 150 words.
SAFER: **Droplet · *So-far* and *not-yet* at Natural Intelligence, and the file at its measures.** Natural Intelligence has *so-far* and *not-yet* at 25 and 30 sayings. Laid ready are 4.9's windings re-said at the overlap, and the other sayings at their sentences, fifty-five, each one word, each facing said at its momentary: the other's prior at the self's now at 2 and 14, the self's now at the other's next at 6 and 10, the next prior at 9 and the next now at 17. The file is measured at 25,300 words with Exhibit ONE Natural Resolver's 10,000 within it, about 47,000 tokens whole, and 141 KB. It is at 38 versions from version 249, the most of the file set. It names Exhibit ONE Natural Resolver twenty-five times, Exhibit FOUR Natural Mathematics once and Exhibit TWENTY-EIGHT Equilibria Registry once, and it has no -ing word that no other file has.

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: OK
WHY: the eleven places are at the lines given in the living file (77, 81, 99, 164 twice, 935, 1012, 1055, 1063, 1126 twice), no heading has any of the five words, the four quotations of Natural Intelligence and the two of Natural Naming 2.4 (lines 275 and 281) are exact, and the prior's "Nothing passed" is "none passed" in NEW, the eleven being each place of the words.
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: OK
WHY: both quotations are exact at Natural Intelligence lines 206 and 1055, the offered saying and both parts of its reason are in NEW, and no paragraph of carry/ points at this one (searched: river, returned).
SAFER: -

### 40
CHECK: OK
WHY: the quotation is exact at Natural Intelligence line 1000, "The method names no size." is at its line 123, and the four relations at the unit square with both parts of the reason are in NEW, *rotated* for the prior's *turned*.
SAFER: -

### 41
CHECK: OK
WHY: the quotation is exact at Natural Intelligence line 129, and the offered saying, its "3.2" and the reason with the term's two uses at 3.2 (lines 192 and 198) are in NEW.
SAFER: -

### 42
CHECK: OK
WHY: the quotation is exact at Natural Intelligence line 188 and each clause of the saying and of the reason is in NEW word for word; the heading's words "Five dimensions, each binary in its two directions" are left out with the number 3.2 naming the same place, NEW being at 150 words.
SAFER: -

### 43
CHECK: OK
WHY: both quotations are exact at Natural Intelligence line 982, the heading of 4.7 is as NEW has it (line 969), and the later "Droplet · At 4.7 · Six names between selves, four facings, two sharings and two releasings, a sentence offered" (this mate, line 691, read) has neither "9 to 17 the releasing and 17 to 9 its arriving" nor the reason, both of which are in NEW.
SAFER: -

### 44
CHECK: OK
WHY: the quotation is exact at Natural Intelligence line 1057, and the saying and both parts of the reason are in NEW with nothing added.
SAFER: -

### 45
CHECK: OK
WHY: the quotation is exact at Natural Intelligence line 131 and 2.1's sentence of + and − and 0 is at its line 123; the saying and the reason are whole in NEW, the saying's "so far and not yet" being the cited *so-far* and *not-yet*, the same two words as the file has them at 4.7 and 4.10.
SAFER: -

### 46
CHECK: OBJECT
WHY: Changed: the place. The prior is at this mate's own living file: "Exhibit ONE · Natural Resolver" is the part of that title within Natural Intelligence (line 228), with `CONNECTORS` at its lines 285 to 292, and "4.7's bullets", "4.4" and "the file" are Natural Intelligence's (lines 976, 977, 982 and 951). NEW has "A saying is offered at Exhibit ONE Natural Resolver's `CONNECTORS`" and names Natural Intelligence at no word, so "4.7's bullets" and "The file names 6 and 10 releasing at `CONNECTORS` and 4.7, and sharing across at `JOINS` and 4.4" read as of Exhibit ONE Natural Resolver, a file of one heading with no 4.7 and no 4.4 (searched). Nothing else is lost: the quotation is exact at Natural Intelligence lines 287 and 289 and at Exhibit ONE Natural Resolver lines 64 and 66, the two lists are named at no line of the three functions (Exhibit ONE Natural Resolver lines 13 to 60 read, and both files searched), and both parts of the reason are in NEW.
SAFER: **Droplet · `'sharing'` offered at `CONNECTORS`, at 6 and 10.** A saying is offered at Natural Intelligence's Exhibit ONE · Natural Resolver, at `CONNECTORS`, beside "'not-yet-bi-moral', 'releasing'": at 6 and 10 the list's third word is `'sharing'`, across, and at 9 and 17 `'along'`; no line of the three functions reads `CONNECTORS` or `JOINS`, and the resolver's executing is identical with the word changed; 4.7's bullets of 6 and 10 after it say sharing across, to the 2 and to the 14 of the self at not-yet-bi-moral. It is no insertlet: it is a plan said as a sentence, and two things, a change to `CONNECTORS` and a change to 4.7's bullets after it. Natural Intelligence names 6 and 10 releasing at `CONNECTORS` and 4.7, and sharing across at `JOINS` and 4.4, and which word is the file's own motion.

### 47
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 48
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 49
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 50
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 51
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 52
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 53
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 54
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 55
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 58
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 59
CHECK: OK
WHY: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md has the paragraph under its own heading "## Each self’s own two and one half consecutive momentaryings · v385A" (line 59, text at line 61), compared character for character with this one and the same, each negation with it; no paragraph of this mate or of carry/ points at this mate's copy (searched), Carryings of Living File Registry (lines 23 and 831) names the Registry mate's section as the place, and paragraph 60, which this one accompanies, says nothing of it and is left as it is.
SAFER: -

### 60
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 61
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 62
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 63
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM.md; the first reader's brief BRIEFO2.md with its "Further rules"; the prior NI_2.txt; the proposed NI_2_report.md with its READING; the earlier second reading P01_harm.md, for the form and its measure of an objection.

The living file Natural_Intelligence_v380R.md is 24,946 words, past 15,000, and was read at the sections the paragraphs name: Parts ONE, TWO and THREE whole (lines 60 to 227) and Parts FOUR, FIVE and SIX whole (lines 923 to 1146); its part Exhibit ONE · Natural Resolver (lines 228 to 922) was searched and read at the lines found (228 to 240, 285 to 293, 606, 623, 696, 799). Exhibit_ONE_Natural_Resolver_v380R.md was read at lines 1 to 70, the three functions and the two lists, and at lines 383, 400, 473 and 576. Exhibit_TWENTY_Natural_Naming_v380R.md was read at lines 275 and 281 of 2.4, and Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md at line 1912, step 430.

The mate carry/Offerings_to_Natural_Intelligence.md was read at lines 1 to 367: its opening sections of v385A, its Insertlets, the whole older Droplets (lines 111 to 237) and the later sections to "Next at the named prior and actual offerings · v385A"; and at lines 517 to 529 and 681 to 693. Its lines 368 to 705 beyond those were searched, not read whole. Read at other mates: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md (its headings; lines 55 to 63 and 183) and carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md (lines 23, 831 and 856). Sources read: carryings/v381F/v381F/Session_Report_v381F.md (lines 97, 105, 175 and 205 to 236), Next.md (lines 44 to 56) and Entry_Journey_For_An_AI.md (lines 50 to 56); carryings/v382F/Session_Report_v382F.md (lines 17 and 70 to 95).

Checked by search: each quotation in each NEW, by exact search over the living files at the root; each is an exact run of words of the file NEW names. *So-far* and *not-yet* in the living file, 25 and 30. For pointers, over the mate outside its older section and over carry/*.md: at this mate, this mate's, above, the preceding, existing concern, returned, own-side, consecutive, two and one half, own odd one, prior being absent; river, forty-five, bi-folding within, one tunneling, loop twisted, self-competent, recursioning self, one releasing along at its two, four things seen, eleven mends, fifty-five, Nothing passed; and each mention of this mate by name or by link in carry/*.md. One pointer at this part of the section was found, "The earlier returned 4.13 concern" at "The relation carried at each self's own pacing · v385A", and it is at paragraph 47, which is KEEP. Each corrected NEW in a SAFER line was checked the same way: 113, 150 and 140 words, its quotations exact, none of the first reader's listed words in its own sentences.

Three things to know.
- In 39 to 46 each NEW has "It is no insertlet" for "Returned to the droplets by a second reader at v381R", and says the second reader's reason in plain voice. The prior's reason is itself said as a fact, and each part of it is in each NEW, so this was read as the same condition at the same strength and no objection is made for it. If the returning by a second reader is to stay said, each of the eight is KEEP.
- The KEEP blocks were not checked beyond reading them in the prior; 36 is the same paragraph as paragraph 18 of the section, outside this input.
- The objections are of two kinds. A place or a subject left out of NEW: 33 (whose eleven mends, which reading) and 35 (what the one word of the work laid ready is, at its source alone). A place changed: 46 (Natural Intelligence's own part, bullets and sections said as of Exhibit ONE Natural Resolver).

Not done: no code was run. incoming/v385M and incoming/v385R are not on this branch; they are sources of KEEP paragraphs alone. No file in /home/claude/corus was edited; this report is the one file written.
