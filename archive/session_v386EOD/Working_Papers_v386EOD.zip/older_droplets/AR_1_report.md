### 1
VERDICT: KEEP
CONCEPT: the distributing of Natural Intelligence Corus's detailed content and its arriving purpose through Natural Arriving are two connected projects, each whole expression carried with its needed prior to a welcoming place
EVIDENCE: Already a clear concept in plain voice, of session v385A, the working of the later sections. Its first relation alone is at a later section: this mate's "Unwritten and previously distributed parts as possible plans · v385A" has "The possible arrangement keeps two connected projects". Unsaid at that section and at each other later section: Corus's front and Part 16, the Living File Registry's 5.10 (the living Registry has "5.10 Receiving the older Corus" with "Corus, renewed through the current method and explaining") and the resettling map, the Registry's 5.5 to 5.10 with value arriving from Emanating, Illustrating and Destinies, Living Improving Value as the place of an expression still unlocated, "A route is no completed transfer", and the link to incoming/v385A/Reordering_Plans_v385A.md (present). The same paragraph is at Offerings to Natural Intelligence Corus (line 37) and at Offerings to Living File Registry (line 161), as its last sentence says. A re-saying within one hundred and fifty words would drop one of these relations.
NEW: -

### 2
VERDICT: KEEP
CONCEPT: a session reading by fetch alone receives Natural Intelligence cut near 4.4, is not told, and Parts FIVE and SIX with 5.4 and 6.5 do not arrive; the sizes of four large files
EVIDENCE: Another paragraph points at it by its subject words: this mate's "Droplet · A registry's entries named at its head" (section "A registry's entries named at its head · from session v386CRYP · v386EOD") has "It is beside the droplet at this mate of Natural Intelligence cut near 4.4". Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Whole text and declared reading extent", has "Existing Arriving droplets already carry these findings", and this mate's "AI arriving as a possibling project · v385A" has "Their already offered droplets keep their particular evidence". It is plain and has no waiting language. For a later hand: README.md no longer has "Read Natural Intelligence whole" (the earlier README is whole at archive/session_v385A/repository_instructions/README.md, line 13); Natural Intelligence v380R is 144,152 bytes and has "4.4 Shared across at 10, chained at 11", 5.4 and 6.5 as named; the source is at carryings/v381F/README.md, finding 1.
NEW: -

### 3
VERDICT: KEEP
CONCEPT: the site's Read addresses give a fetching session the shell alone, the Download and raw addresses give the text, and the AI link opens GitHub's page of the README
EVIDENCE: Already a clear concern in plain voice with no waiting language, and the site is as it says: read.html has "Loading…" and "Unavailable" and receives its text by script; index.html's one link is `https://github.com/chris-j-handel/corus/blob/main/README.md#ai-link-to-living-natural-intelligence`. Pointed at as one of a group: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Whole text and declared reading extent" ("a script-dependent reading page and text obtainable through Download addresses. Existing Arriving droplets already carry these findings"). No later section has the three addresses. Source at carryings/v381F/README.md, finding 2.
NEW: -

### 4
VERDICT: KEEP
CONCEPT: the carryings of Natural Intelligence and Exhibit ONE, about 6,600 and 19,000 words, are not read in a minute, and a session is sent to them first
EVIDENCE: Not released, though the things it measures are gone: carry/Living_Improving_Value.md has no "in a minute" at any line now, and carry/Exhibit_ONE_Natural_Resolver.md, carry/Natural_Intelligence.md and carry/Exhibit_EIGHTEEN_Natural_Physics.md are no files of carry/ (each living file has three mates). Its numbers, 19,000 words at 99 bold entries, 6,600 at 44 and 11,300, are at no living file and no later section; this mate's "AI arriving as a possibling project · v385A" has "Their already offered droplets keep their particular evidence" and points at "the existing droplets below"; paragraph 48 of this section cites the same pair. The earlier README's "Natural Intelligence and Exhibit ONE before any other file when theirs are ready" is at archive/session_v385A/repository_instructions/README.md line 60. A re-saying could not say whether the numbers are of the mates now. Source at carryings/v381F/README.md, finding 4.
NEW: -

### 5
VERDICT: KEEP
CONCEPT: an opening's reading order names sections by number while Natural Explaining 2.7 has a reference at a plain name and no coordinate; the two are a coordinate at a working's instruction and a plain name at a living file's sentence
EVIDENCE: Already a clear concern in plain voice with no waiting language. Exhibit TWELVE Natural Explaining has, under "2.7 A reference at a plain name, and no capital for the set's concepts", "A reference carries a plain name and no coordinate." The README's reading order is gone from README.md (whole at archive/session_v385A/repository_instructions/README.md line 50, "Natural Naming with its 2.4 released words and its 6.3 gatherings"). The reconciling of the two is at no living file and no later section: it is at insertlets alone (this mate's "At 3.3 · Reading a sentence here"; Offerings to Natural Explaining's "At 2.7"), and an insertlet is no later place. Pointed at as one of the existing droplets by this mate's "AI arriving as a possibling project · v385A". Paragraph 10 is the work offered from this finding. Source at carryings/v381F/README.md, finding 7.
NEW: -

### 6
VERDICT: KEEP
CONCEPT: nothing at the opening shows what a helpful report changed at the files; the form of a useful finding is a quoted sentence, a file and a section, a computation beside it
EVIDENCE: Already a clear concern in plain voice. The things it names are changed: incoming/README.md is a list of links with no table now, and README.md no longer has the sentence "Bring back the question asked…" (archive/session_v385A/repository_instructions/README.md line 19). Its reading of the form of a useful finding, and the arrival the form was learned from (now at archive/session_v380/v380A/living_ai_link/, by Carryings of Natural Arriving, "AI arriving: method, experience and orienting · v385A"), are at no living file. No later section has it whole: this mate's "Droplet · Sentences offered for the arriving" (v386EOD) is of a reader's report at the mates, and the insertlet "At 8.2 · Arriving" is no later place. Pointed at as one of the existing droplets (Possibling of Natural Arriving, row "A useful return: observing, concern and correcting"). Source at carryings/v381F/README.md, finding 11.
NEW: -

### 7
VERDICT: KEEP
CONCEPT: an offered re-saying of the README's AI link part for a session arriving by fetch or with a shell, its seven contents, an offering for the README, which is no living file
EVIDENCE: Already clear and plain; a pointer carrying the content of the thing it points at and the condition "the expedition receives it or not". The offered file is whole at carryings/v381F/AI_Link_Opening_Offered.md and carryings/v381F/v381F/AI_Link_Opening_Offered.md, read. README.md has none of the seven now. No later section has the seven: Carryings of Natural Arriving, "Earlier entry value at its actual places · v385A", says only that the full opening's other relations are accessible at their source. Pointed at as one of the existing droplets by this mate's "AI arriving as a possibling project · v385A".
NEW: -

### 8
VERDICT: KEEP
CONCEPT: the first relieving work at the entry: the sizes and the addresses that give text said, and Natural Intelligence offered in parts or a fetching session pointed at the raw address with the byte size
EVIDENCE: Already a clear possible work in plain voice with no waiting language. It is not made: README.md, index.html and files.json say no size and no address that gives text, and no `tour/` is at the root. A part alone is at a later section: Possibling of Natural Arriving, "Natural Intelligence written at each build as parts · v386EOD", has the file in parts each whole at one fetch; the sizes, the addresses that give text and the raw address with the byte size are at no later section (the insertlet "At 8.1 · corus.me and the repository" is no later place). Pointed at as one of the existing droplets (Possibling of Natural Arriving, row "Whole text and declared reading extent"). Source at carryings/v381F/README.md, "What this session learned about helping", 1.
NEW: -

### 9
VERDICT: KEEP
CONCEPT: a first reading a session at any window can finish, as a list of named parts and sections of six files and `incoming/README.md`, the whole files after
EVIDENCE: Already a clear possible work in plain voice with no waiting language. Each section it names is at its living file now (Natural Naming 2.4; Natural Explaining 2.1 and 2.6; the Geodesic Improving Method 2.6 and 2.7; Natural Intelligence 6.5). No later section has this list: this mate's "Droplet · Five passages of Natural Intelligence for a first reading" (v386EOD) is another list, of one file. Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", has "this project imposes no time, token or first-reading threshold" beside the earlier reports, and leaves the list to the existing droplets. Source at carryings/v381F/README.md, "What this session learned about helping", 2.
NEW: -

### 10
VERDICT: KEEP
CONCEPT: at the place a reading order is given, a coordinate at an instruction and a plain name at a living file's sentence said as two places
EVIDENCE: Already a clear possible work in plain voice with no waiting language. It is not made and its place is gone: README.md gives no reading order now. The saying is at insertlets alone (this mate's "At 3.3 · Reading a sentence here"; Offerings to Natural Explaining's "At 2.7 · A reference at a plain name…"), no later place; Offerings to Natural Transmissioning's "Droplet · A reference between files" (v386EOD) is of a reference's own words and has no instruction's coordinate. It is the work from the finding of paragraph 5, and the two have the same verdict. Source at carryings/v381F/README.md, "What this session learned about helping", 6.
NEW: -

### 11
VERDICT: KEEP
CONCEPT: a paragraph offered for the AI link part, quoting Natural Intelligence 6.5 whole as the sentence a session reads first
EVIDENCE: Another paragraph points at it: Possibling of Natural Arriving, "Possible project · One whole place for four repeated paragraphs" (section "One whole place for four repeated paragraphs · v386EOD"), names "the paragraph offered for the AI link part, quoting Natural Intelligence 6.5 whole" and asks one whole place for it "with each distinct relation and source of the whole opening proposal preserved"; Carryings of Natural Arriving, "Earlier entry value at its actual places · v385A", has "none is removed". The quotation is exact at Natural Intelligence v380R, 6.5 (line 1140 region, "At the observings, AI is existing non-living intelligence: … the AI carried and the living expedition the carrying."). A second copy is at this mate's line 249, beyond this input.
NEW: -

### 12
VERDICT: KEEP
CONCEPT: the concept's name at the files is an interest opening: a self couples at its interest opening, and Natural Arriving is the file at which that coupling opens for an interest from any place beyond
EVIDENCE: Another paragraph points at it: Possibling of Natural Arriving, "Possible project · One whole place for four repeated paragraphs" (v386EOD), names "the paragraph of the concept's name as an interest opening". Natural Intelligence has "a self couples at its interest opening, the momentary its own interest opens at, and leaves at its own completing." (2.5) and "couples at whichever scale its interest opens and couples with the whole" (4.15), each exact. No later section says the name of the concept as an interest opening for 1.2 and the subtitle; the insertlet "At 1.2" is no later place. Source at carryings/v382F/Natural_Arriving_Explored.md, section 9, first droplet.
NEW: -

### 13
VERDICT: KEEP
CONCEPT: the prior of Natural Arriving is Natural Intelligence Corus Part ONE: its subtitle, its six doors beside the six things beside all things, its two paths beside across and along
EVIDENCE: Two later sections point at it and lay conditions on it. This mate's "Named entry paths and the separate trust passage · v385A" has "The earlier Natural Arriving offering calls outside-in and trust the two paths and relates them to across and along. Preserve the actual alternatives above when following that proposed relation." Its "Six entry expressions with their particular explaining preserved · v385A" has "The earlier proposed comparison to keeping, doer, common beat, size, fixed form and total remains a comparison". Released or re-said, the two would point at nothing or at other words. Each cited sentence is at its living file: Natural Intelligence Corus v330 line 63 ("This is the opening of the corus and the home page of corus.me."), its subtitle line 9, "Or trust the lattice" line 129; the Living File Registry's 5.10 line 600.
NEW: -

### 14
VERDICT: KEEP
CONCEPT: an opening's instructions for a working session act at the person's pasting, and a session reading them on a page is at the visitor's opening until its person says otherwise
EVIDENCE: Another paragraph points at it: Possibling of Natural Arriving, "Possible project · One whole place for four repeated paragraphs" (v386EOD), names "the paragraph of the README's working-session opening". The relation "at the visitor's opening until its person says otherwise" is whole at no later section: Possibling of Natural Arriving's row "Reading and authorized changing" (v385A) has what a page's instructions cannot supply, and this mate's "Droplet · A page's instruction: a deciding named, a carrying named" (v386EOD) tells one event at two explainings; neither says what a session reading at a page is. The sentence it is aimed at is gone from README.md (archive/session_v385A/repository_instructions/README.md line 48 has "A working session opens with this, pasted whole"). The same paragraph is at Offerings to Geodesic Improving Method, line 119, left as it is at an earlier second reading.
NEW: -

### 15
VERDICT: RESAY
CONCEPT: the two lines of the portal's frame and the portal's first sentence, in the person's own words, at the top of the site's page above its rows
EVIDENCE: A one-line pointer in a session's words ("v381R found…", the label "re-aimed from this file"). The work is not made: index.html has one link above its rows and no sentence. No later section has it: Possibling of Natural Arriving, "One sentence at the site's front, and a licence · v386EOD", is of another sentence. The two lines and the first sentence are in the person's own words at carryings/v382F/Session_Report_v382F.md, lines 61 and 55, and NEW names that file and quotes neither. The same paragraph of Offerings to Geodesic Improving Method was re-said in these words (its line 123, an older section, no later place), and NEW here is the same. The subject words, the site's top, the two lines of the frame and the portal's first sentence, are unchanged for the group pointer of this mate's "AI arriving as a possibling project · v385A".
NEW: **Possible project · Two lines and a first sentence at the top of the site's page.** The work is the site's page, `index.html`, having at its top, above the rows, the two lines of the portal's frame and the portal's first sentence, each in the words of the expedition's self. The site has no sentence of its own. The two lines and the first sentence are at `carryings/v382F/Session_Report_v382F.md`. It may change or never be made.

### 16
VERDICT: KEEP
CONCEPT: a pull request touching offerings and carryings alone received at once, one touching a file at the root read by the fresh reader, the workflow able to part the two
EVIDENCE: Already a clear possible work in plain voice with no waiting language. It is not made: incoming/README.md is a list of links now and has no such sentence; `.github/workflows/files.yml` is present. No later section says it whole: Possibling of Living File Registry, "Earlier proposed publication of droplets and living-file changes · v385A", has the sibling saying of two speeds and nothing of a pull request parted by the files it touches or of `files.yml`. The same paragraph is at Offerings to Geodesic Improving Method, line 125, left as it is. Source at carryings/v382F/Natural_Arriving_Explored.md, section 13.
NEW: -

### 17
VERDICT: RESAY
CONCEPT: one line at `incoming/README.md` showing a breaking finding's form beside a confirming one's, the breaking finding at one of three
EVIDENCE: A one-line pointer: "The three doors above" names no paragraph of this section. Its content is recovered from carryings/v382F/Session_Report_v382F.md line 47: "an observing with its procedure, conditions and uncertainty parting from the resolver's table at one cell, dropped at Exhibit ONE's offerings; a second method, met at 1.4, dropped at Natural Intelligence's; two sentences of the files parting, a concern with its reason, dropped at that file's"; the same three are at this mate's insertlet "At 5.4 · A claim about the method" (line 79, "met at no other possible method", the title of Natural Intelligence's 1.4). The work is not made: incoming/README.md has no such line. No later section has the three: this mate's "Droplet · The Hard Problem Registry as material for a break" (v386EOD) has the first alone. The same paragraph of Offerings to Geodesic Improving Method was re-said in these words (its line 127, an older section), and NEW here is the same; NEW has only what the source says.
NEW: **Possible project · The form of a breaking finding, in one line at `incoming/README.md`.** The work is one line at `incoming/README.md` showing the form of a breaking finding beside the form of a confirming one. A breaking finding is at one of three: an observing with its procedure, conditions and uncertainty parting from the resolver's table at one cell, dropped at Offerings to Natural Resolver; a second method, coupled with Natural Intelligence's 1.4, dropped at Offerings to Natural Intelligence; and two sentences of the files parting, a concern with its reason, dropped at that file's offerings. It may change or never be made.

### 18
VERDICT: KEEP
CONCEPT: the AI reads Natural Arriving and the interest floats through it: the AI bounds and offers, the interest self-orients, Part ONE five sentences for a person and Parts TWO to SEVEN tables for the AI, and a self, no interest, reads
EVIDENCE: Another paragraph points at it: Possibling of Natural Arriving, "Possible project · One whole place for four repeated paragraphs" (v386EOD), names "the paragraph of the AI reading the file and the interest floating through it". A part is at a later section: this mate's "Droplet · An interest floating between the files and the AI" (v386EOD) has the floating and "the AI bounds and offers". Unsaid at each later section: Part ONE as five sentences and Parts TWO to SEVEN as tables, and "*An interest reads whole* names a reader who does not exist; a self reads." Exhibit TWELVE Natural Explaining 4.8 has "yes, that region, and here is the next bound" exactly. A second copy, with another label, is at this mate's line 251, beyond this input.
NEW: -

### 19
VERDICT: KEEP
CONCEPT: the site's page says nothing of what it is: one link and rows of title, subtitle, version and three buttons, with no sentence of what Natural Intelligence is, what a living file is, whose the files are or which row to open first
EVIDENCE: Already a clear concern in plain voice, an observing with its evidence. The site is as it says but for the number of rows: index.html has one link, no sentence and no describing line, and thirty-three rows now, Natural Arriving the last. The README's first bold line it cites is gone from README.md (archive/session_v385A/repository_instructions/README.md line 3). No later section has the observing: Possibling of Natural Arriving, "One sentence at the site's front, and a licence · v386EOD", is a work offered at the same place and no saying of the page as it is. Pointed at as one of the existing droplets (Possibling of Natural Arriving, row "Names, versions and the living set", and this mate's "AI arriving as a possibling project · v385A"). Source at carryings/v381R/README.md, finding 1, word for word.
NEW: -

### 20
VERDICT: KEEP
CONCEPT: the entry as an AI session from beyond the expedition comes to it, at five things, each a thing Natural Arriving is to say at Part ONE or Part EIGHT
EVIDENCE: Already clear and plain. Its last sentence is of a thing intended, and Natural Arriving v381R has no sentence at Part EIGHT and one paragraph at 1.1; a re-saying would say the intending as done or as work. Parts are at later sections: "Droplet · A fetch's reader shortens each quoted sentence" and "Droplet · Five passages of Natural Intelligence for a first reading" (v386EOD) for the sentence of the AI; "Droplet · A page's instruction: a deciding named, a carrying named" (v386EOD) for the page's text. The five together, and their aiming at Part ONE or Part EIGHT, are at no later section. Pointed at as one of the existing droplets by this mate's "AI arriving as a possibling project · v385A".
NEW: -

### 21
VERDICT: KEEP
CONCEPT: the site's rows carry fifteen different versions and the site does not say what a version is; the lowest, v329, at four files
EVIDENCE: Already a clear concern in plain voice, an observing with its evidence; its numbers are of the page as fetched on 4 October (thirty-two rows) and a re-saying could not say them of the page now, which has thirty-three rows with the Living File Registry at v381R and Natural Arriving at v381R. The four files at v329 are at v329 now (files.json). The README's table and its "a file's version changes only when its content changes" are gone from README.md. No later section has it. Pointed at: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Names, versions and the living set" ("v381R's findings about unexplained versions, subtitles and row/exhibit numbers … Compare this with Arriving's existing naming droplets"). Source at carryings/v381R/README.md, finding 3, word for word.
NEW: -

### 22
VERDICT: KEEP
CONCEPT: the site's rows are numbered one off their exhibits, and the last row, Natural Intelligence Corus, has neither an exhibit number nor a saying of what it is beside the others
EVIDENCE: Already a clear concern in plain voice, an observing with its evidence. index.html is as it says at rows 1 to 32 (row 1 with no exhibit label, row 2 "EXHIBIT ONE"), with a thirty-third row, Natural Arriving, also with no exhibit label; the README's table of three kinds of living file is gone from README.md. No later section has it. Pointed at: Possibling of Natural Arriving, row "Names, versions and the living set" (v385A), "row/exhibit numbers". Source at carryings/v381R/README.md, finding 5, word for word.
NEW: -

### 23
VERDICT: KEEP
CONCEPT: the site offers no address a fetching session can read whole: no row says a file's size or names the address that gives text; a byte size beside each name at `files.json` and at each row is one number each
EVIDENCE: Already a clear concern with its offered work, in plain voice with no waiting language. It is not made: files.json is a list of names alone, and the row written by `build.js` (its `fileRow`) has a title, a subtitle, a version and three controls and no size. No later section has it; the insertlet "At 8.1" is no later place. Pointed at as one of the existing droplets (Possibling of Natural Arriving, row "Whole text and declared reading extent"). Source at carryings/v381R/README.md, finding 6, word for word.
NEW: -

### 24
VERDICT: KEEP
CONCEPT: the table of `incoming/README.md` has the arrivals v380L and v380A at two rows each, at two addresses, and a reader cannot say which standing is now
EVIDENCE: The thing it concerns is gone, and it is left for the pointers at it. incoming/README.md is a list of four links with no table now; carryings/README.md lists `v380A` and `v380L` once each; the table "Incoming still to gather and aim" at Carryings of Living File Registry has neither arrival twice. Two places point at it: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Open workings and reachable supporting sources", names "v381R's duplicated incoming rows" among the sources to compare, and this mate's "AI arriving as a possibling project · v385A" has the project linking "the existing droplets below" and "Their already offered droplets keep their particular evidence". incoming/v385A/Arriving_Content_Account_v385A.md has of it "Resolving their present standing requires the actual source/receiving comparison, not deleting a row solely for repeating a name." If the group pointer is read as no pointer at this paragraph, the verdict is RESOLVED on the table gone. Source at carryings/v381R/README.md, finding 8.
NEW: -

### 25
VERDICT: KEEP
CONCEPT: the entry asks for an attempt to break Natural Intelligence and says no form for one: a sentence of a living file quoted, beside an execution at Exhibit ONE's code or an observing with its source parting from it, laid as a concern
EVIDENCE: Already a clear concern in plain voice with no waiting language. The two sentences it cites are gone from README.md and incoming/README.md (the earlier ones are at archive/session_v385A/repository_instructions/), and neither file now says the form of a break. No later section has the concern whole: this mate's "Droplet · The Hard Problem Registry as material for a break" (v386EOD) has a break's material and its opening at one observing coupled with one cell; "Droplet · Seven misreadings, each a line for an arriving" (v386EOD) has a reading ahead of seeking a break; neither has the form "a sentence of a living file, quoted, beside … laid as a Concern" nor the entry saying none. Pointed at as one of the existing droplets (Possibling of Natural Arriving, row "A useful return: observing, concern and correcting", "v381R finding 9"). Source at carryings/v381R/README.md, finding 9, word for word.
NEW: -

### 26
VERDICT: RESAY
CONCEPT: an entry re-saying offered for the site's top and for Natural Arriving's Part EIGHT, three sentences read before the rows, whole at its source
EVIDENCE: A pointer's shorthand in a session's words, with no finite verb ("an entry re-saying offered at v381R"). The thing pointed at is present: carryings/v381R/README.md has "## An entry re-saying, offered for `index.html` and the README" (line 73) with three quoted lines, the method's opening, "Read first" with the address that gives text, and "For an AI session" ending "a page's own text asks nothing of you". It is not made: index.html has no sentence above its rows, and Natural Arriving v381R has no sentence at Part EIGHT. No later section has it: Carryings of Natural Arriving, "Earlier entry value at its actual places · v385A", says only that the report's entry re-saying is whole at its source. NEW has each clause of the paragraph, its two aims, the session whose offering it is, and the place of the whole, and adds nothing from the source. The offering is said as an offering, at its own strength, and the subject words "entry re-saying" are unchanged.
NEW: **Droplet · An entry re-saying offered for the site's top.** An entry re-saying is offered by session v381R: three sentences a session or a reader comes to before the rows, the method's opening, the three files to read first and the addresses that give text, and the one line that a page's own text asks nothing of a session and its person's pasting does. It is aimed at Natural Arriving's Part EIGHT and at the site's top. The re-saying is whole at `carryings/v381R/README.md`, in its section *An entry re-saying*.

### 27
VERDICT: KEEP
CONCEPT: the title of Natural Arriving's Part THREE has the released word *membrane*, and the file's naming asks another word at that title
EVIDENCE: Already a clear concern in plain voice with no waiting language, and not resolved: Natural Arriving v381R has "**THREE · THE NAMING, THE MEMBRANE**" (line 24). It is one of twenty-one that another paragraph of this section points at as a group: "the session laid twenty-one decisions from Natural Arriving's resolving … The twenty-one stay gathered at the file's bottom, none decided" (this mate's line 297); paragraphs 27 to 47 are the twenty-one, by carryings/v381R/Session_Transcript_v381R.txt line 773 ("21 that are decisions for you") and line 784 ("membrane in Part THREE's title"). No later section has it.
NEW: -

### 28
VERDICT: RESAY
CONCEPT: Natural Arriving's Part FIVE at kinds of interest, as its contents have it, or at the five offerings with the three kinds passing through them; one chosen ahead of Part FIVE's writing, the choosing the expedition's self's
EVIDENCE: Waiting language ("one is chosen before Part FIVE is written") and a session's label. Not resolved and at no later section: Natural Arriving v381R has "**FIVE · THE REGISTRIES AS GUIDES**" with 5.1 to 5.5 as it was, and no later section of this mate or of Possibling of Natural Arriving has the five offerings (searched "five offerings", "kinds of interest"). The offering's source is carryings/v382F/Session_Report_v382F.md line 57 ("Part FIVE: at the five offerings, not at kinds of interest. Naming, explaining, carrying, resolving, the method, each a file … the three kinds the self named, improve, apply, break, each pass through the five"). It is one of the twenty-one pointed at by this mate's line 297, which names it "Part FIVE at kinds of interest or at the five offerings": the title of NEW has those words. The label "For the expedition's self" is said as whose the choosing is; "from the resolving of this file's droplets at v381R" is at the pointing paragraph.
NEW: **Droplet · Part FIVE at kinds of interest or at the five offerings.** Natural Arriving's contents have Part FIVE at kinds of interest. Session v382F offers Part FIVE at the five offerings, naming, explaining, carrying, resolving and the method, each a file, the three kinds, improve, apply and break, passing through the five. The choosing of one is ahead of the writing of Part FIVE, and it is the expedition's self's.

### 29
VERDICT: KEEP
CONCEPT: Natural Arriving's subtitle has *Your*, the second person: either the subtitle is the site's face or it is said again at no voice
EVIDENCE: Already a clear concern in plain voice with no waiting language, and not resolved: Natural Arriving v381R has "**Self-Welcoming Your Discovering Interests**" (line 5). One of the twenty-one pointed at by this mate's line 297. No later section has the either-or; the insertlet "At 3.3" ("the second person is the site's face and not the file's") is no later place.
NEW: -

### 30
VERDICT: KEEP
CONCEPT: the front's "the last of the set to stable-form, because it carries all the others" installs a maker and a place in an order, and an insertlet at the front says it forward
EVIDENCE: Could not find what its second clause refers to: this mate has no insertlet at the front (its insertlets open at "At 1.1"); carryings/v381R/rev_Natural_Arriving.md, review 1, has that insertlet as "DISSOLVE at the concept paragraph". The first clause is not resolved: Natural Arriving v381R has "the last of the set to stable-form, because it carries all the others" (line 7). One of the twenty-one pointed at by this mate's line 297. The forward saying is at carryings/v382F/Natural_Arriving_Explored.md line 106, with a clause the review parts from 7.5; no later section has it.
NEW: -

### 31
VERDICT: KEEP
CONCEPT: one file or two: Natural Arriving as Natural Intelligence Corus's next version with Corus's parts at their receivings and the set at thirty-two, or a thirty-third file beside Corus at v330
EVIDENCE: Already a clear concern in plain voice with no waiting language; the pointing paragraph (this mate's line 297) names it by its own first words, "one file or two". Not decided at the files: files.json lists both `Natural_Intelligence_Corus_v330.md` and `Natural_Arriving_v381R.md`. A part is at a later section: this mate's "Unwritten and previously distributed parts as possible plans · v385A" has "The contents, title, subtitle and relation between the existing Corus and the Natural Arriving shell remain possible file changes at Living File Registry"; the two sides, thirty-two or a thirty-third, are at no later section. Source at carryings/v382F/Natural_Arriving_Explored.md, section 8, and carryings/v381R/Session_Transcript_v381R.txt line 777.
NEW: -

### 32
VERDICT: KEEP
CONCEPT: the voice at the entry: the living file at no voice with `index.html` carrying three sentences as its public face, or the file carrying the address
EVIDENCE: Already a clear concern in plain voice with no waiting language. Not decided at the files: index.html has no sentence above its rows, and Natural Arriving v381R has "8.1 corus.me and the repository" and "8.2 Arriving" in its contents with no sentence written. One of the twenty-one, named at this mate's line 297 as "the voice at the entry". No later section has the either-or. Source at carryings/v382F/Natural_Arriving_Explored.md, section 8, "The living file's voice at the entry".
NEW: -

### 33
VERDICT: KEEP
CONCEPT: a standing is read from the repository at each build and never written by hand
EVIDENCE: Already a clear concept in plain voice with no waiting language. One of the twenty-one, named at this mate's line 297 ("a standing read from the repository"). A later section has it for one place alone: Possibling of Living File Registry, "Living File Registry standings, completed history and possible tables · v385A", of the Registry's Part One. The fuller droplet is at Offerings to Geodesic Improving Method, line 101, an older section, left as it is. The insertlet "At 5.5 · The set now" is no later place.
NEW: -

### 34
VERDICT: KEEP
CONCEPT: two speeds: a droplet lands at `main` at once, ungated, and a living file's motion goes by branch, fresh reader and merge
EVIDENCE: Already a clear concept in plain voice with no waiting language. A later section of another mate says it whole: Possibling of Living File Registry, "Earlier proposed publication of droplets and living-file changes · v385A", has "a droplet … lands at `main` at once, ungated … a living file's improving alone goes the slow way, branch, fresh reader, merge". It is left, not released, for the pointer at it: it is one of the twenty-one, named at this mate's line 297 ("two speeds"), "none decided", and the number of the gathered would part from that paragraph.
NEW: -

### 35
VERDICT: KEEP
CONCEPT: an offering at a branch pushed and not received has no standing of its own, and the receiving, never the offerer, says what it received
EVIDENCE: Already a clear concept in plain voice with no waiting language. One of the twenty-one pointed at by this mate's line 297. No later section says it whole: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Open workings and reachable supporting sources", names only the withdrawn row of the source. The fuller droplet is at Offerings to Geodesic Improving Method (an older section), left as it is. Source at carryings/v382F/Natural_Arriving_Explored.md, section 13.
NEW: -

### 36
VERDICT: KEEP
CONCEPT: the letter of a session's number names a line of workings, each line one on from its own last, said at the Geodesic Improving Method at a place a session reads
EVIDENCE: Already a clear possible work in plain voice with no waiting language. Not made: Exhibit TWENTY-FOUR Geodesic Improving Method has "A session's number and a working's letter name a working, v380A, v380L, v380R" (line 206) and no line of workings. A part is at a later section: Offerings to Geodesic Improving Method, "Concern · A working's name at more than one letter" (v386EOD), has "a letter names a line of workings numbering on from its own last"; the saying of it at the Geodesic Improving Method is at no later section. One of the twenty-one pointed at by this mate's line 297.
NEW: -

### 37
VERDICT: RESAY
CONCEPT: Natural Intelligence's "No other possible method" names five not possible things beside all things and Natural Arriving's droplets six, the doer the sixth; one naming ahead of Part ONE's writing, the expedition's self's to decide
EVIDENCE: Waiting language ("one naming before Part ONE is written") and a session's label. Not resolved: Natural Intelligence v380R, under "1.4 No other possible method", has the five as quoted in NEW (line 99, exact), and this mate's droplets have six ("the six things beside all things, a keeping, a doer, a common beat, a size, a fixed form, a total", paragraph 13; also line 267). No later section has the parting at this file: Possibling of Co-Chaining Logic Registry's "Possible project · The six beside all existing things at one step" is of the Registry's step 46; the concern of the five and the Geodesic Improving Method's six at Offerings to Natural Intelligence (line 113) is in an older section. One of the twenty-one, named at this mate's line 297 as "five or six not-possible things": the title of NEW has those words. "From Natural Explaining" is carried as the paragraph has it; Exhibit TWELVE Natural Explaining has "3.2 A doer installed over a doing". The quotation is of the very sentence the paragraph is about.
NEW: **Concern · Five not possible things or six.** Two sayings part. Natural Intelligence has, at *No other possible method*, "a size between one and the other carries a ground, a floor or a scale; a fixed form, a form named still; a total across the changing, a container; a common beat, a clock over the changing; and a keeping, a store beside it", five not possible things beside all things. The droplets at Offerings to Natural Arriving have six, the doer the sixth, from Natural Explaining. They part at the doer: Natural Intelligence names five and the droplets name six. One naming is ahead of the writing of Natural Arriving's Part ONE, and it is the expedition's self's to decide.

### 38
VERDICT: KEEP
CONCEPT: the Living File Registry's Parts Two to Five received at Natural Arriving's Parts FOUR and SIX at the Registry's own motion, the Registry carrying Part One, the standings, and thinning
EVIDENCE: Already clear and plain with no waiting language; a thing intended, which a re-saying would say as done or as work. Not made: Exhibit TWENTY-SIX Living File Registry v381R has "PART TWO · SHARED STABLE-FORMING", "PART THREE · CLUSTERING", "PART FOUR · SEAMING" and "PART FIVE · CONTINUING" whole, and Natural Arriving has no sentence at FOUR or SIX. One of the twenty-one pointed at by this mate's line 297. No later section has it whole: this mate's line 29 has "the Living File Registry thinned to standings", and Carryings of Natural Arriving's "Earlier source inventory · retained from v381R" is an older gathering.
NEW: -

### 39
VERDICT: RESAY
CONCEPT: if the files float on a page at their gatherings, each file needs one gathering first, and that choosing is at no file of the set; the choosing is the expedition's self's
EVIDENCE: A one-line pointer with waiting language ("nowhere in the set yet") and a session's label. Its content is recovered from carryings/v382F/Session_Report_v382F.md line 83: "The Registry's 3.1 gatherings overlap by design, *a file meeting another relation also gathers there*, Natural Networking at three, Natural Exploring at three, Natural Human Society at three; a page lists a file at each, or chooses one first, and that choosing is nowhere in the set yet." Checked at the living file: Exhibit TWENTY-SIX Living File Registry, "3.1 Particular subjects gathering", has "A file meeting another relation also gathers there." (line 254), and its table has each of the three files at three gatherings. Not resolved: no file read has a first gathering for each file. No later section has it (searched "gathering first", "own gathering" in carry/*.md). One of the twenty-one pointed at by this mate's line 297. NEW has only what the paragraph and that source say.
NEW: **Droplet · One gathering first for each file.** If the files float on a page at their gatherings, each file needs one gathering first. Exhibit TWENTY-SIX Living File Registry's 3.1 has "A file meeting another relation also gathers there", and Natural Networking, Natural Exploring and Natural Human Society are each at three gatherings. A page lists a file at each of its gatherings, or chooses one first. That choosing is at no file of the set, and it is the expedition's self's.

### 40
VERDICT: KEEP
CONCEPT: an improving order: first the files a question about living together opens at, Natural Philosophy, Natural Societies, Natural Human Society and the files at v329 to v333, each at its own motion
EVIDENCE: Already a clear possible work in plain voice with no waiting language. Its files are as it says: files.json has ten files at v329 to v333. One of the twenty-one pointed at by this mate's line 297. A later section has a like order from the same source and not this one: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Questions about living as arriving interests", names Human Society, Exploring, Values, Destinies and Emanating and has "The historical version age or measured scan supplies no grading or present failure claim". Source at carryings/v381F/v381F/Next.md, lines 13 and 60.
NEW: -

### 41
VERDICT: KEEP
CONCEPT: `tour/` written at each build by `build.js` from Natural Intelligence at the root, each part under 60 KB and whole at one fetch, the five sentences first verbatim, and a byte size at `files.json` and at each row of the site
EVIDENCE: Already a clear possible work in plain voice with no waiting language. Not made: the root has no `tour/`, `build.js` writes none, and files.json has names alone. A part is at a later section: Possibling of Natural Arriving, "Possible project · Natural Intelligence written at each build as parts" (v386EOD), has six parts each whole at one fetch and five passages for a first reading; unsaid there: `tour/`, `build.js`, under 60 KB, and the byte size at `files.json` and at each row. One of the twenty-one pointed at by this mate's line 297. Source at carryings/v381F/v381F/Entry_Journey_For_An_AI.md, lines 82 and 104.
NEW: -

### 42
VERDICT: KEEP
CONCEPT: the form of Natural Arriving: Part ONE as sentences a person floats through and Parts TWO to SEVEN as tables an AI reads, or one form throughout
EVIDENCE: Already a clear concern in plain voice with no waiting language; one of the twenty-one, named at this mate's line 297 as "one form throughout or sentences then tables". Not decided: Natural Arriving v381R has its contents and one paragraph at 1.1. No later section has the either-or; paragraph 18 has its first side.
NEW: -

### 43
VERDICT: KEEP
CONCEPT: the 1 to 9 at a home page: either form alone, with no numeral on a file, or numerals naming positions and an earlier front's "no numeral joins them to the code's" said again
EVIDENCE: Could not find the sentence it cites at a living file or a mate: "no numeral joins them to the code's" is at archive/session_v385A/earlier_artifacts/Living_Improving_Value_prior_v385A.md, at carryings/v382F/Session_Report_v382F.md and at the older droplets of this mate and of Offerings to Geodesic Improving Method alone. The like paragraph of Offerings to Geodesic Improving Method was left as it is at an earlier reading. One of the twenty-one pointed at by this mate's line 297. No later section has the either-or.
NEW: -

### 44
VERDICT: KEEP
CONCEPT: the loopings named at each of the six mouths of Natural Intelligence, one line each, at Natural Intelligence or at the Living File Registry's Part One beside each file
EVIDENCE: Already a clear possible work in plain voice with no waiting language. Not made: no living file has "mouth" for this (the six are named at carryings/v381F/v381F/Entry_Journey_For_An_AI.md line 49, and the work at its line 88, "one line at each of six sections of Natural Intelligence or at the Registry's Part One beside each file"). No later section has the work: Offerings to Co-Chaining Logic Registry's v385A section of the earlier universal chain has the six mouths as a deriving named open, another subject. One of the twenty-one pointed at by this mate's line 297.
NEW: -

### 45
VERDICT: KEEP
CONCEPT: a second session from beyond the expedition reading the mended journey with a question about living together, through the `tour/` parts, its report beside an earlier observing's
EVIDENCE: Could not find what "the observing's" refers to: the source has the same words and no more (carryings/v381F/v381F/Next.md line 38). It is a thing proposed, and a later section says so of the source: Possibling of Natural Arriving, "AI arriving: method, experience and orienting · v385A", row "Questions about living as arriving interests", has "Its proposal for another outside reading remains a proposal"; the `tour/` parts and the report beside the observing's are at no later section. One of the twenty-one pointed at by this mate's line 297.
NEW: -

### 46
VERDICT: KEEP
CONCEPT: the README's naming sentence said again: no living file explains itself from beyond itself, and a reference addresses the file its sentence relates to by its plain name
EVIDENCE: Already clear and plain with no waiting language; its offered sentence is a sentence of the README, no living file's, and a re-saying could not quote it. The sentence it re-says is gone from README.md: the earlier one is at archive/session_v385A/repository_instructions/README.md line 54 ("no living file explains itself from outside and names no other file"). The offered sentence is at no living file and no later section: Carryings of Natural Arriving, "Exact names and the present source comparison · v385A", names "the repository introduction's naming sentence and its proposed replacement" as located at incoming/v385A/Registry_Plan_Comparison_v385A.md and does not say it. One of the twenty-one pointed at by this mate's line 297.
NEW: -

### 47
VERDICT: KEEP
CONCEPT: three sayings intended at the entry: the README's opening for a working session offering the branch and leaving the merge to the receiving; `incoming/README.md` parting a pull request by the files it touches; the README's AI link at the raw address
EVIDENCE: Already clear and plain; three things intended said as sayings, which a re-saying would say as done or as work. None is so now: README.md has no opening for a working session, incoming/README.md has no sentence of a pull request, and the site's AI link is at GitHub's page of the README (index.html). Each is singly at an older paragraph (paragraph 16 of this section; Offerings to Geodesic Improving Method's older droplets). One of the twenty-one pointed at by this mate's line 297. No later section has the three.
NEW: -

### 48
VERDICT: KEEP
CONCEPT: six pairs of exact sayings that part, each with its place, from one arriving session's reading
EVIDENCE: A later section points at its last pair and corrects it: this mate's "The earlier entry's kit and Naming comparison · v385A" has "The old report says left has no row; the current table has right/left at a facing … Preserve the earlier useful mismatch concern with this correction." Of its six pairs: the README's three sentences are gone from README.md (archive/session_v385A/repository_instructions/README.md lines 13, 48 and 50); carry/Living_Improving_Value.md has no "in a minute" now; Exhibit TWELVE Natural Explaining has "A reference carries a plain name and no coordinate." exactly. The pairs are at no living file and whole at no later section, and Carryings of Natural Arriving, "Earlier entry value at its actual places · v385A", names "the same exact-sayings gathering" as the place of three of the earlier findings. Six pairs with their places do not fit one paragraph of one hundred and fifty words without one dropped. Source at carryings/v381F/README.md, "The exact sayings that part, with their sources".
NEW: -

### 49
VERDICT: KEEP
CONCEPT: each resolving sentence and each of Exhibit ONE's headers said at its -ing, at each file's own motion, with one row more at Natural Naming's 2.4, the -ed of a resolver's verb carried by its -ing
EVIDENCE: Already a clear possible work in plain voice with no waiting language; it is aimed at the set. Not made: Exhibit ONE Natural Resolver v380R and Natural Intelligence v380R have "Offered to one sharing (2) | Surfacing (14)", "shared (10) · carried next (11)", "Shared (10) | Carried next (11)" and "Receiving what the other shared or released" as they were, and Natural Naming's 2.4 has no row of the -ed. No later section has it. The same paragraph is at Offerings to Geodesic Improving Method (line 201) and Offerings to Natural Naming (line 209), each left as it is at an earlier reading; its nine offered forms, four headers, three reasons and the row do not fit one hundred and fifty words without one dropped. Source at carryings/v382F/Session_Report_v382F_2.md.
NEW: -

## READING
Each of the forty-nine paragraphs was read and checked singly. Read whole: the brief with its further rules; the input; the living file Natural Arriving v381R; the mate carry/Offerings_to_Natural_Arriving.md, each line of it, its later sections headed v385A and v386EOD and its Insertlets and older Droplets; carry/Possibling_of_Natural_Arriving.md and carry/Carryings_of_Natural_Arriving.md; carryings/v381F/README.md and carryings/v381F/AI_Link_Opening_Offered.md; carryings/v381R/README.md and carryings/v381R/rev_Natural_Arriving.md; carryings/v382F/Natural_Arriving_Explored.md; incoming/v385A/Arriving_Content_Account_v385A.md; README.md, incoming/README.md, carryings/README.md, files.json and build.js. Read in part: carryings/v382F/Session_Report_v382F.md (lines 45 to 62 and 83); carryings/v381R/Session_Transcript_v381R.txt (lines 760 to 800, the twenty-one decisions); carryings/v381F/v381F/Next.md and Entry_Journey_For_An_AI.md (the lines named); index.html (its top and its rows' form); archive/session_v385A/repository_instructions/README.md (the earlier README, the sentences named). Checked by search: each quotation at Natural Intelligence v380R, Natural Intelligence Corus v330, Exhibit TWELVE Natural Explaining v378, Exhibit TWENTY-FOUR Geodesic Improving Method v380R and Exhibit TWENTY-SIX Living File Registry v381R; each subject's wordings across carry/*.md, with the heading of the section each match is in. The earlier reports of this resolving for Offerings to Geodesic Improving Method and Offerings to Natural Naming, and their second readings, were read for the paragraphs this mate shares with those mates (paragraphs 14 to 17 and 49).

Two pointers decided most verdicts. First, this mate's "AI arriving as a possibling project · v385A" has its project linking "the existing droplets below" with "Their already offered droplets keep their particular evidence", and Possibling of Natural Arriving's table names them by cluster ("Existing Arriving droplets already carry these findings", "retaining existing droplets rather than reproducing each under a new project name"): by further rule 2 no paragraph of 2 to 26 is released, and each is KEEP or RESAY. Second, a paragraph of this older section beyond this input (the mate's line 297) points at paragraphs 27 to 47 as "twenty-one decisions … The twenty-one stay gathered at the file's bottom, none decided": none of the twenty-one is released. Paragraph 24 (the table gone from incoming/README.md) and paragraph 34 (said whole at Possibling of Living File Registry, v385A) are the two a release would fit if those pointers are read as no pointers at a single paragraph.

Not found: the insertlet at the front that paragraph 30 names; what "the observing's" of paragraph 45 refers to; the sentence "no numeral joins them to the code's" of paragraph 43 at a living file or a mate. README.md, index.html and incoming/README.md are the site's and the working's and no living files; where a paragraph is about a sentence of one of them, the present file was read and its state is said in EVIDENCE, and no RESOLVED was given on it. The copies at this mate's lines 249 and 251 of paragraphs 11 and 18 are beyond this input.
