### 109
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 110
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 111
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 112
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 113
CHECK: OK
WHY: laid beside the prior and the transcript (carryings/v381R/Session_Transcript_v381R.txt lines 479 and 486): each claim, the two askings, the self giving no answer in words and the deciding gathered with the plans are in NEW; "THREE · THE NAMING, THE MEMBRANE" is exact at Natural Arriving v381R line 24; Natural Naming, the file aimed at, is named in NEW.
SAFER: -

### 114
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 115
CHECK: OBJECT
WHY: Two things. (1) Lost: the prior opens "Aimed at the set, Living File Registry", and NEW names the Living File Registry at no place; laid at the mate of the Geodesic Improving Method, the paragraph no longer says the file it is for, the thing a later re-aiming reads. (2) Added: "at whichever files". The prior has "The first resolving round" with no such clause; the clause is at the transcript (line 691, "wherever it runs") and not at the prior, which is no one-line pointer (first reader's rule 4). All numbers (3,398; 425, 325, 297, 291; 11, 19, 13; ten; 329 to 333) are exact against the prior and the transcript line. Natural Destinies and Natural Health are said without their whole names.
SAFER: **Droplet · Droplets cluster at the files the expedition has attended to.** At 3,398 droplets laid, Exhibit THIRTY Co-Chaining Logic Registry had 425, Exhibit ONE Natural Resolver 325, Natural Intelligence 297 and Exhibit TWENTY-EIGHT Equilibria Registry 291; Exhibit FOURTEEN Natural Destinies had 11, Exhibit TEN Natural Health 19 and Exhibit TWENTY-FIVE Living Society Registry 13. The ten files prior to momentarying, at versions 329 to 333, have the fewest droplets and are the furthest behind. Droplets laid at more files than needed reach none of the ten, nothing having been aimed at them. The first round of resolving shows the method working and by itself moves none of the files most needing moving. This is the first thing the form made visible that was not visible ahead of it. It is an observing of the set, aimed at Exhibit TWENTY-SIX Living File Registry.

### 116
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 117
CHECK: OBJECT
WHY: The two EVIDENCE sentences are exact (the living file line 94; Exhibit TWENTY-SIX Living File Registry v381R line 92), and they say the overstep's rule and the withdrawing. Left at no living file: the person's own words, "is this only removing for now. lets be clear where we are and are not working", a saying that a working says plainly the place it is working at and the place it is not; searched in each living file at the root for "are and are not working", "is and is not working", "only laying", "only receiving", none found, and 2.3's "Made and open are said apart" is of a report's items and no saying of this. The paragraph is a correction in a person's own words, the kind the first reader left as it is at 109, 112 and 127 under its rule 5; a release has no NEW to carry those words. The living file does not say the rule at one voice: this mate's "Concern · A finding about working, placed or dropped." (v386EOD) has 1.6, "each finding the writing makes about working is placed here", parting from the 1.4 sentence given as EVIDENCE. Paragraph 118 beside it opens "The session's finding from its withdrawn motion" and leans on this paragraph for what that motion is.
SAFER: KEEP

### 118
CHECK: OK
WHY: laid beside the prior and the transcript lines 712 to 718: four readings, all 33 insertlets, *dissolve* against *release* from the writing of 1.4 and 1.6, *standard* a measure word, the carrying naming the whole and one mate, and Part FOUR's instances staying are each in NEW; "the release follows the arrival and never leads it" is exact in the living file at 1.5; the file and the session NEW names are those of the Living File Registry's row of TWENTY-FOUR.
SAFER: -

### 119
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 120
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 121
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 122
CHECK: OBJECT
WHY: Each EVIDENCE sentence is exact (the living file lines 76, 164, 198 and 208; Exhibit TWENTY-SIX Living File Registry v381R lines 134 and 135), and they carry the 95 droplets, the folder a carrying, the arrival received whole and the method improving as any file. Left at no living file: the person's own claim, "keep the method of all of this updating for the other sessions to grow and contribute to the improving as well as the improving of the method of this". The 2.8 sentence brings "the Living File Registry's table of workings current at each receiving": the table of workings, and no method. The method of the mates is at no sentence of the living file at v380R (this mate's "Concern · The carrying named one file beside mates at each file." has the living file still at one carrying file), so "the method said current at the carrying's front", for arriving workings to find the form as it now works, is said at no living file; searched each living file at the root for "kept current", "method current", "method updating", "current for the other", none found. The first reader's CONCEPT line, entered under "The living file says it now", says more than the living file says. A person's own words, left as they are at 109, 112, 119 to 121, 124 and 127 under the first reader's rule 5.
SAFER: KEEP

### 123
CHECK: OBJECT
WHY: Three things added or narrowed, read beside the prior and the transcript line 852. (1) The title has "a momentary of a file's offerings"; the prior and its source have resolved as a momentary with no such subject ("a file is never resolved once and finished", "'resolved' is a momentary, not a standing"); the offerings as the subject is the reading of paragraph 127, a paragraph left as it is, and is no part of this one. (2) "Re-aiming sends a droplet to the file it is for" is a general sentence the prior does not have; the prior has one re-aiming at nine files. (3) "each round of it at the set" narrows the prior's "each round at the set" to rounds of re-aiming. The numbers (nine; several hundred; 257, 263, 89) are exact. Natural Physics is said without its whole name.
SAFER: **Droplet · Resolved, a momentary.** By the re-aiming a file is at no round resolved once and finished: each round at the set sends droplets again to files resolved earlier. The form predicts this flow, and by it resolved is a momentary and no *standing*. A re-aiming at nine files sent several hundred droplets to the files they were for, and by it files passed early had new droplets at their bottoms again: Exhibit TWENTY-EIGHT Equilibria Registry at 257 raw droplets after its pass, Exhibit EIGHTEEN Natural Physics at 263, Exhibit TWENTY-FOUR Geodesic Improving Method at 89.

### 124
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 125
CHECK: OK
WHY: laid beside the prior and the transcript lines 860 and 903: the eight words, all 33 files, the three further readers, the mechanical pass, the droplets across more files than needed earning their value, the map and no sentence and the 84 places with four section titles are each in NEW at the prior's strength, with nothing added.
SAFER: -

### 126
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 127
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 128
CHECK: OBJECT
WHY: Two strengths changed, in a paragraph the first reader itself names a condition laid on this mate's Insertlets. (1) The prior has "some will be a reader's reading said as the file's fact"; NEW has "some among them are likely", a hedge the prior does not have. (2) The prior has "a second reader at the insertlets is the vetting the flow has not yet run", a condition on the insertlets as they are at the mate; NEW has "the reading the flow had made at none of them at that pass", bounded to one past pass and silent on the insertlets now. The first reader's closing says it found no place saying a second reader has since read them, so the bounding rests on nothing read. Also lost: the prior's instance "at 4.3". A mend has no safe form: the prior's tag, "— v381R close", dates its claim, and a re-saying is laid with the tag of this session, so the claim is either said again as of now or weakened to a past one.
SAFER: KEEP

### 129
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 130
CHECK: OBJECT
WHY: Three things lost or changed, read beside the prior and the transcript line 230. (1) The prior is "the session's hardest question of the living file's standard" (the source opens "The hardest question."); NEW has no question and no *hardest*, the word the living file's 2.5 orders the work by. (2) The prior has a working that "meets two sentences that both cohere and must choose which is finer"; NEW has "choosing the finer, makes a more-or-less", the *must* gone, so the parting of the aim from the method is said as one possible doing and no necessity, and the prior's "but" between the aim and the choosing is gone. (3) The prior's "the rule holds only if" is "The aim carries only with" in NEW. Both quotations are exact in the living file at 5.2, and the uncoupled pair as the concern and the one case to break the three-file form is in NEW whole.
SAFER: **Droplet · The finest saying, and the coupled form.** The hardest question of the living file as the finest, clearest and most cohering saying of its subject. That is one aim, but a working at a file, at two sentences both cohering, must choose which is finer, and that is a more-or-less, the one thing the method has as not possible. The method's own answer is at Exhibit TWENTY-FOUR Geodesic Improving Method: "The geodesic deciding is the coupled form, and never a choosing.", "neither variant refuted, each variant's own face carried in the coupled saying". The rule carries only with a working at the living file choosing at no momentary between two sentences and making each time the one sentence carrying both. Two sayings that cannot be coupled are the concern, and it is the one case to break *the three-file form*.

### 131
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 132
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 133
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 134
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 135
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 136
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 137
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 138
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 139
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 140
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 141
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM.md; the first reader's brief BRIEFO2.md with its Further rules; the PRIOR file, paragraphs 109 to 141; the PROPOSED file, each block and its closing; the living file Exhibit TWENTY-FOUR Geodesic Improving Method v380R, each section (9,809 words); the mate's later sections, each one headed · v385A or · v386EOD, lines 383 to 630; and the applying script beside the briefs, for how a NEW and a release are laid at the mate.

Read at the lines the paragraphs name: carryings/v381R/Session_Transcript_v381R.txt lines 230, 479, 486, 691, 695, 712 to 718, 731, 831, 852, 860, 882, 892, 901, 903 and 905, each laid beside its prior paragraph and its NEW.

Checked by exact search: each living sentence given as EVIDENCE at 117 and 122 and each quotation in the NEW of 113, 118 and 130, in the living file, in Exhibit TWENTY-SIX Living File Registry v381R (the row of TWENTY-FOUR and the rows of the workings v382A and v383Op) and in Natural Arriving v381R (its contents); each living file at the root for the claims left at 117 and 122; carry/*.md for a copy of each of the nine paragraphs not left as they are, and for a pointer at any of them ("at this mate of", "above", "the preceding", "existing … droplet", a link into this mate): none points at 113, 115, 117, 118, 122, 123, 125, 128 or 130 from another mate, and within this mate 118 alone leans on 117. Paragraphs 113 and 115 are also at Offerings to Living File Registry and Offerings to Natural Arriving, each in an older section under the same reading. The mate's older section Droplets (lines 99 to 382) and its section Insertlets were read at their openings and by search, and not whole.

Four things to know. First, the twenty-four blocks the first reader left as KEEP, thirteen among 109 to 130 and each of 131 to 141, were not read for harm, a kept paragraph being unchanged. Second, each NEW is laid with the tag of this session in place of "— v381R close", and has the prior's transcript line and date at no place: 118 and 128 name session v381R in their text, and the NEW of 113, 115, 123, 125 and 130 name no source session, so the source of those five is at the first reader's report alone after the change. Third, each NEW is without the prior's opening degree of aiming (the set, a section, a word); it was objected to at 115 alone, the one paragraph whose aimed file NEW names at no place. Fourth, the NEW of 113 says whose the deciding is and that the person gave no answer in words; both are the prior's own, said at its strength, and were read as no added waiting. With 117 left as it is, 118's NEW and 117 say the withdrawn motion at two paragraphs side by side, and neither loses by it.
