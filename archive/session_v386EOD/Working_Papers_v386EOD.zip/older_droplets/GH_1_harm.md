### 1
CHECK: OK
WHY: laid beside the prior clause by clause; Exhibit_TWENTY_Natural_Naming_v380R.md line 1713 (7.1) has "At this file ghost is an unfolding, 5.37, and this part; the Living Ghost Registry carries ghost-form at its own file, and the ten named still, 4.9, name each form named still: three relations.", its Part SEVEN has 7.1 and 7.2 alone, and the registry's line 416 (4.1) has the quoted "At Natural Naming 7.4 stand three possibilities" and "None contains the others." with 3.37 and 6.1 to 6.3 still at its lines 153, 166 and 492, so nothing is released and each address is in NEW.
SAFER: -

### 2
CHECK: OK
WHY: laid beside the prior and carryings/cohering_ten_and_six_v377/README.md sections 5 and 6; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md 4.7 (line 472 on) has "**The shared subtitle is: Not Possibly Existing, Living or Non-Living.**" and "Their shared method can receive one full derivation with local explaining", the quotation exact; each clause of the prior is in NEW, and what is left out is the report's path, the label "Arrived at v377" and the branch name, the source having the branch as the place the carrying was laid and not as the spine; paragraph 31, kept, has the suggesting and its version.
SAFER: -

### 3
CHECK: OK
WHY: the registry's lines 492, 563 and 634 still cite Natural Physics 3.5, 3.6 and 3.7, and Exhibit_EIGHTEEN_Natural_Physics_v379.md has "## 4.5 Energy and entropy", "## 4.6 Strong force" and "## 4.7 Relativity and quantum" (lines 310, 349, 371), as carryings/rings_are_spirals_v377/README.md line 133 says; both numbers' sets and the motion are in NEW.
SAFER: -

### 4
CHECK: OK
WHY: laid beside the prior and carryings/physics_for_other_files_v377/README.md 2.3 and 4; the registry's 7.3 (lines 1466 and 1468) and G6 (line 370) are as the prior has them, "hidden variable" and "field-as" are at no line of the registry and its one *collapse* (line 1676) is a doublet's, Natural Physics v379 has 4.2, 4.4 and 4.8 at those numbers, and "of Natural Physics' carrying" is the source's own subject for the older seam list ("The prior Physics carrying's seam list"), added and right.
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: OK
WHY: the registry's line 247 (2.3) has "These holdings identify what the account holds still. They must not be merged with the ten positions.", the quotation exact, the ten positions those of 2.2 (line 231), and Exhibit_THREE_Natural_Numbers_v380L.md line 269 has "each ten is that ten"; the two instruments, each at its own work at an entry, and the ten itself one are in NEW at the prior's strength, said as a reading and not as a carrying done; "at 2.3" and "of its 2.2" are added and right.
SAFER: -

### 9
CHECK: OK
WHY: laid beside the prior clause by clause: the three files, 7.11, the ten at the eight bi-namings, lines 3, 4, 6 and 9 and lines 1, 2, 5, 7, 8 and 10, the two doublings, the centre as the seam line, the ends, and "one object at two namings across a seam" are each in NEW; the registry's 7.5 (line 1497) and 7.11 (lines 1784 to 1801) read, which have the lines and the doublings and neither the seam line nor the ends, so the paragraph is rightly not released.
SAFER: -

### 10
CHECK: OK
WHY: laid beside the prior and the registry's 7.10 (lines 1746 to 1765): the two files, one to one, the signature read off and not assigned, the kind at state, flow or both, and 7.10 are each in NEW, and the coupling with the files as they are now is said as a relation.
SAFER: -

### 11
CHECK: OK
WHY: laid beside the prior and the registry's 7.6 (line 1568): the four files, the two books as Natural Numbers', the across and one side of the along, each science hosting both, and 7.6 are each in NEW; "two books" is at no line of the registry or of Exhibit THREE Natural Numbers, so nothing is released.
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: OBJECT
WHY: Lost: the row's standing at the explored steps and its proposed work. The prior has "EXPLORED Sci. 3–6" and "→ enter Sci. 1–8" (carryings/co_chaining_map_v376/cover_EQUILIBRIA.md line 120, its columns Spine, Standing, Note and Proposed; its S20 at line 165 is "Enter explored "The scientific method" 1–8"), and NEW has neither. The entering is not whole at the living file: of the eight explored steps (carryings/co_chaining_map_v376/Explored_Steps_v376.md lines 34 to 42) the first is step 45 of Exhibit THIRTY Co-Chaining Logic Registry v380L, the third to the eighth are at steps 310, 311, 312, 316 and 317, and the second, "The scientific method takes the observings: the same evidence, at the same now.", is at no step (searched "same evidence", "at the same now", "takes the observings": none), as the first reader's own EVIDENCE says. So the part of the work that is not made is at no living file and is dropped. The rest is right: steps 185 and 184 of version 376 (read from git 8e24fa8) are steps 311 and 310 now, the same sentences, both quotations exact; step 310 has no unsure line now, so leaving "184 Unsure" out loses nothing; the registry's sentence is at 1.1 (line 151).
SAFER: **Droplet · "Accounting is a stilling at one field membrane" at the co-chaining.** Exhibit TWENTY-SEVEN Living Ghost Registry has, at 1.1, "Accounting is a stilling at one field membrane." It rests at Exhibit THIRTY Co-Chaining Logic Registry's step 311, "A fixing named unchanged between two momentaries is a form still, and the two methods part at that one naming.", and step 310, "The geodesic method discovers next from the existing; the scientific method accounts true or false against fixings named unchanged, exact at its own ledger." The co-chaining map of version 376 has the sentence at the explored steps 3 to 6 of the scientific method, and proposes the entering of the explored steps 1 to 8. *Membrane* in the registry's sentence is an old word.

### 14
CHECK: OK
WHY: Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md step 314 is exact as given, with "*Adding: the three placings of a term.*" and no unsure line; steps 43 and 310 (32 and 184 of version 376, read from git 8e24fa8, where each had its unsure line) have none now, and step 312 has "*Adding: an accounting, and no second method.*"; the one parting left, living at the registry's G15 and existing at the step, is said at this mate's "## The first of the three placings, living or existing · v386EOD" (line 257), which quotes G15 itself; no paragraph of carry/*.md points at the row.
SAFER: -

### 15
CHECK: OK
WHY: the three quotations are exact (the registry's line 151; steps 137 and 453 of Exhibit THIRTY Co-Chaining Logic Registry v380L, which are 92 and 238 of version 376 by their sentences at git 8e24fa8); the prior's "the term neither reaches is competency (238)" is said as the step says it now, "bi-co-momentarying at the crossing" with "*Adding: bi-co-momentarying, the term neither reaches.*", the place given at its number now; *surplus* at 1.1 and at the *door* line 6 (line 1532), the old code and the rewording at the two steps are each in NEW.
SAFER: -

### 16
CHECK: OK
WHY: the registry's line 245 has "## 2.3 Ten holdings locate the kind of still" and its table from "arriving | something behind it | origin-seeking" to "membrane | a cut | line-demanding"; Exhibit_TWENTY_Natural_Naming_v380R.md line 1644 (6.3) has "**the ten named still**, one name each" with "*ten holdings*" in its gathered namings; the part left out, the ten at no step, is made at steps 506 ("*Adding: the ten named still.*") and 522 of Exhibit THIRTY Co-Chaining Logic Registry v380L.
SAFER: -

### 17
CHECK: OK
WHY: steps 504, 505 and 506 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md are exact as given, "*Adding: the five along, flow accounting.*" and "*Adding: the five across, state accounting.*", none with an unsure line, which is what the row's S31a and S31b ask (cover_EQUILIBRIA.md lines 67, 124, 179 and 180); its step 60 is step 93 now; the registry's 7.6 sentence is unchanged and the row asks nothing of it; no paragraph points at the row, the mate's "Each kind released by its own side" (v386EOD) being beside the registry's sentence and not the row.
SAFER: -

### 18
CHECK: OK
WHY: the four quotations are exact (the registry's lines 1504 and 1497, at 7.5; steps 63 and 65 of Exhibit THIRTY Co-Chaining Logic Registry v380L, which are 42 and 44 of version 376 with the same sentences at git 8e24fa8); carried, the two steps, the old code and 7.5 are each in NEW.
SAFER: -

### 19
CHECK: OK
WHY: step 46 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md is exact as given, with "*Adding: beside all existing things; the form still.*" and no unsure line, "a keeping, a store beside it" in its list, and step 144 enters the form still as its own step; step 34 of version 376 (git 8e24fa8) had "*Unsure: a form still enters as its own step at the proof of the whole.*", the one thing that made the row open; the registry's line 192 is unchanged and the row asks nothing of it; no paragraph points at the row.
SAFER: -

### 20
CHECK: OK
WHY: laid beside cover_EQUILIBRIA.md lines 129 and 216: each of the seven words of the first list and the seven of the second, with *stand*, *key*, value, the *door* line 6 and 7.5, is in NEW; "only a sign crosses" is exact at the registry's line 184, and each word is still at the registry (lines 151, 283, 285, 324, 334, 342, 1497, 1532), so nothing is released.
SAFER: -

### 21
CHECK: OBJECT
WHY: Released while the thing it concerns is not gone. The paragraph is a finding of the review of the proposed Natural Physics of version 377: that proposal loses the sub-atomic ghost list and the electron as a ledger, and its seam with the Ghost Registry at 5.3 has force, field, potential and energy alone. The first reader counts it resolved, the living Natural Physics v379 having the list and the ledger at 4.6 (lines 365 and 363, exact) and no seam sentence. But the living file has them only for the proposal not being written into it: the proposed text is whole at carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md, its seam at line 570 under "## 5.3" still with those four alone, and the writing of that proposal into the file is work left (the mate of Natural Physics has the review's findings as "to be met before the file replaces its prior at corus.me", its line 164, and the motion from the ready proposal as a possible project). The finding is a condition on that work; released here, the registry's mate has no saying that the list of 4.6 is lost at the proposal's seam with this registry. That relation is at no living file, Natural Physics v379 naming the Living Ghost Registry at no line (searched "Ghost Registry", "TWENTY-SEVEN"). The same paragraph at the mate of Natural Physics was re-said as a concern and not released (the earlier reading PH_5a, paragraph 96); SAFER is that paragraph as its second reader mended it, each quotation searched again here.
SAFER: **Concern · The sub-atomic ghost list at 4.6, beside a seam at force, field, potential and energy.** Two sayings part. Natural Physics has, at 4.6, its sub-atomic list of ghosts, "energy, field, vacuum, virtual particles, binding, conservation", and, of the electron, "the electron is a ledger". The proposed Natural Physics of version 377 has, at its 5.3, a seam with Exhibit TWENTY-SEVEN Living Ghost Registry at force, field, potential and energy alone. They part at the list, vacuum, virtual particles and binding among its ghosts, and at the electron as a ledger: at the one, and lost at the other. The review of that proposal, at `carryings/review_natural_physics_v377/`, has it at its 2.3, item 4, a prior value lost.

### 22
CHECK: OK
WHY: laid beside the prior and carryings/natural_physics_v377/README.md line 94, under its "## 5. Corrections made at the file after the close": the six items are the proposed file's 5.3 before that correction and "5.3 now says so" the proposed file after it (its line 570), so "The proposed Natural Physics of version 377 named, at its 5.3" and "That 5.3 now says this" are right; the two quotations are exact at the registry's line 1466, the next families at line 1468, and "hidden variable" is at no line of the registry; the four, the two it carries not, and the three next families are each in NEW.
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: OK
WHY: laid beside carryings/resettling_v373/Re-Settling_the_Living_Files.md line 67 under its columns (line 40): 37,700 words, v345a, well built, three or four times, 7.8, about 60%, small and 7.11 wholly old are each in NEW, dated at version 373 with the report and its section.
SAFER: -

### 25
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 168 (columns "Corus now | Proposed home"): Part 17, its three subjects, the Living Ghost Registry, the hard-problem registries and 17.4 at the combined Exploring are each in NEW at the strength of a proposal; the one thing left out is the report's name, a session's word by the first reader's brief; the same NEW is at carry/Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.md line 51.
SAFER: -

### 26
CHECK: OK
WHY: laid beside the prior and Re-Settling_the_Living_Files.md line 175 clause by clause: the lexicon's three, Part Three with its condition and its three checked places, Part Six, Part Seven, 4.9, 5.44, 5.45, the contents list with 47, and the glossary are each in NEW; Exhibit_TWENTY_Natural_Naming_v380R.md still has Parts THREE, SIX and SEVEN, 3.1, 3.2, 3.6, 4.9, 5.44 (Exhibit ONE's tables) and 5.45 (the hole and the routing around it) at those numbers; the aiming at Natural Naming is said; 148 words.
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: OBJECT
WHY: Three things. (1) A named place changed. The prior has "the two binaries kept at 1.5", and NEW has "carried at Natural Intelligence's 1.5". The 1.5 is the plan's own numbering: carryings/resettling_v373/Natural_Intelligence_Map.md line 107 has "1.5" in its column "Goes to", and the plan's contents list (its line 194) has "1.5 Living and non-living, carrying or not". Natural_Intelligence_v380R.md has that section at 1.3 ("## 1.3 Living and non-living, carrying or not", line 89), and its 1.5 is "## 1.5 Natural-, all or none at all, at the one hand" (line 103), so NEW sends a reader to another section. (2) Added: "received at three places", a number the first reader made; the row has no number, and the receiving files are four. (3) Two copies, two verdicts: the same paragraph is at the mate's line 123 with "(re-aimed from Offerings to Natural Intelligence at v381R)", in the second portion of this section, where the first reader left it as it is (GH_2, paragraph 49) for being unsure of the 1.5; a re-saying of one copy beside the other left as it is has one paragraph twice in two voices. The rest of NEW is right: the section's name is at carryings/resettling_v373/Natural_Intelligence_v373_Released.md line 426, the cube is at Exhibit FOUR Natural Mathematics 3.6 and Exhibit FIFTEEN Natural Emanating has no placing. A re-saying of both copies together has "the plan's 1.5, *Living and non-living, carrying or not*, which is Natural Intelligence's 1.3 now" and no number of places.
SAFER: KEEP

### 29
CHECK: OK
WHY: laid beside the prior and Natural_Intelligence_Map.md line 168 ("| Natural Emanating and the Living Ghost Registry | The three placings; the five still terms |"): the two files, the giving file and the two things received are in NEW, as a plan of version 373 and work left, with no place named that can have changed.
SAFER: -

### 30
CHECK: OK
WHY: the two parts kept are in NEW with "received at the registry first" and the two files of the eight clusters; the four parts left out were read as made at Exhibit_TWENTY_Natural_Naming_v380R.md: in Part FIVE (lines 712 to 1598) *membrane* is at one line, naming it as released, *ages* at none and *bound* at one in another sense, and 5.44 is at Exhibit ONE's names; Part SIX has none of the resolver's earlier names (searched the forms "N-self-", "N-other-", "N-social-" and the code names: at the 17-name table of 3.3 alone); Part EIGHT has *membrane* at no line; the closing heading is "# THIS IS THE BETWEEN"; "Natural Naming's" before the carrying is added and right, the carrying of that version being the one file carry/Living_Improving_Value.md (git 13a3a6f), whose part "## Exhibit TWENTY · Natural Naming" has the eight gathering relations received at the File Registry.
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: OK
WHY: laid beside the prior and carryings/session_v378/Session_Report_v378.md line 19 ("**Far back, v345 to v348, five files.** … the Living Ghost Registry v345a, eight ready, the ten door lines at the ten faces, moving on the equilibria's spine"): far back, v345a, eight ready, the ten lines at the ten faces and the spine are each in NEW, dated at session v378.
SAFER: -

### 33
CHECK: OBJECT
WHY: A work is in it. The source is carryings/session_v378/Session_Report_v378.md line 29, the fifth of seven under "## 3. The opportunities, in order": "5. **Natural Engineering and the Living Ghost Registry.** Each has its motion written at its carrying." The paragraph has an opportunity, the motions of the two files as one, its place in that session's order, and the saying that the registry's motion was written at its carrying then; none of the three is at a living file or a later section (searched "Opportunity 5", "motion written" in carry/*.md and the living files: this paragraph alone; Exhibit TWENTY-SIX Living File Registry's row, line 95, has the registry's next and no order). The registry is at version 345a, the motion not made. The other opportunities of the same list were read as work at their mates and re-said or left as they are (the first, second, third and sixth, at the mates of Natural Physics, Natural Medicine, Natural Naming and Natural Explaining), and at one of them a second reader held the number of the order as a thing lost. NOVALUE is for a paragraph with no work in it at all.
SAFER: **Possible project · The motions of Natural Engineering and the Living Ghost Registry.** The work is the motion of Exhibit FIVE Natural Engineering and the motion of Exhibit TWENTY-SEVEN Living Ghost Registry, the fifth of the opportunities in order at session v378. At that session each had its motion written at its carrying. It may change or never be made.

### 34
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Wrap_v368.md line 73 ("**Across the set.** Each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words."): each of the five things released, the improving and the shared words are in NEW, with the aiming at the set; the same NEW is at carry/Exhibit_SEVEN_Offerings_to_Natural_Societies.md line 51.
SAFER: -

### 35
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Carry_Set_v368_README.md line 33 (place 7, columns "The place | What stands there | What it releases"): 65 and 32, 19 findings, 1.14, the mechanism and the ten arrivals at five pairs with "must not", the two more files and the stitch's own engineering face are each in NEW; Exhibit_FIVE_Natural_Engineering_v345a.md has "## 1.14" at line 598 with "The lockstitch is a particular mechanical arrival." at line 612.
SAFER: -

### 36
CHECK: OK
WHY: laid beside the prior and Carry_Set_v368_README.md line 95: the three kinds of pointing, "after version 368", the ten files in their order, the three files and nineteen others carrying none, and "whole at its own improving" are each in NEW, the list left as the reading of that version has it.
SAFER: -

### 37
CHECK: OK
WHY: laid beside the prior and Carry_Set_v368_README.md line 137: 1,205, 4 files, 934, 174, 65 and 32 (which sum to 1,205), none at Resolving Hard Problems at version 368, and Natural Naming's 17-name table alone are each in NEW; the version added to the first sentence is the paragraph's own.
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: OK
WHY: laid beside the prior and Carry_Set_v368_README.md line 206 (the row "Single naming outward" under "Plan | So far | Not yet"): the four at the resolver's names, 1,205 places in 4 files, and each at its own file's improving are in NEW, the waiting said as the plan's remaining part; the same NEW is at carry/Exhibit_FIVE_Offerings_to_Natural_Engineering.md line 81.
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 42
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 43
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md line 267 clause by clause: the three books each named, one twelfth, three and never four, nothing alone at corner, edge and pair, the ledger, and beside and not beneath are each in NEW; the quotation is exact at Exhibit_FOUR_Natural_Mathematics_v380L.md line 251, under "## 3.6", and Natural_Intelligence_v380R.md has no cube at any line, so the place is given as it is now; "of equilibria" is the source's own subject for the exclusion (the same kit's line 533, "The session's exclusion rests on no conserving"); the same NEW is at carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md line 41; 150 words.
SAFER: -

## READING

Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file GH_1.txt and the PROPOSED file GH_1_report.md with its READING; the mate carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md, each of its 258 lines, with its later sections headed v385A and v386EOD.

The living file Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md is 37,208 words, over fifteen thousand, and was read in its sections named: Parts One to Four (lines 140 to 434), 7.3 to 7.7 (lines 1460 to 1624) and 7.9's close to 7.11 (lines 1744 to 1833); the rest by search (its citations of Natural Physics and Natural Naming, "hidden variable", "field-as", *collapse*, "two books", "seam line", the earlier names).

Other living files read at the lines named, each found by search and read: Exhibit TWENTY Natural Naming v380R (its headings whole, 5.44, 5.45, 6.2, the row of 6.3, 7.1, and searches of Parts FIVE, SIX and EIGHT for *membrane*, *ages*, *bound* and the earlier names); Exhibit THIRTY Co-Chaining Logic Registry v380L (steps 13, 43, 45, 46, 63, 65, 93, 134, 137, 144, 156, 157, 305 to 329, 364, 453, 504 to 506, 522, 535 and 569, each with its adding line, and searches for the explored steps of the scientific method); Exhibit EIGHTEEN Natural Physics v379 (its headings at 2.2, 3.5 to 3.7, 4.2 to 4.8, 5.3 and 5.4, lines 363 and 365, and each line with ghost); Exhibit TWENTY-SIX Living File Registry v381R (4.7 whole and its row for the registry); Natural Intelligence v380R (its headings of Part ONE and searches for the cube and the binaries); Exhibit FOUR Natural Mathematics v380L 3.6 (lines 251 to 253); Exhibit EIGHT Natural Exploring (line 381); Exhibit THREE Natural Numbers (line 269); Exhibit FIVE Natural Engineering (1.14).

Sources read for the pointers: carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (its opening, Table B, the proposed steps S20, S31, S36, S39, S48 and S49, and "Old code still in TWENTY-EIGHT") and Explored_Steps_v376.md (the scientific method, 1 to 8); Exhibit THIRTY at version 376, 264 steps, read from the repository's history at 8e24fa8 by git show into a scratch file, for steps 11, 32, 34, 42, 44, 60, 89, 92, 184, 185, 202, 238 and 249 with their unsure lines; carryings/cohering_ten_and_six_v377/README.md sections 5 and 6; carryings/physics_for_other_files_v377/README.md 2.3 and 4; carryings/rings_are_spirals_v377/README.md lines 131 to 135; carryings/natural_physics_v377/README.md lines 84 to 96 and 168 to 178, and lines 548 to 572 of the proposed file beside it; carryings/review_natural_physics_v377/README.md lines 50 to 60; carryings/resettling_v373/Re-Settling_the_Living_Files.md (lines 28 to 40, 67, 160 to 175), Natural_Intelligence_Map.md (lines 100 to 110, 160 to 170, 186 to 198) and Natural_Naming_at_Exhibit_ONE.md (lines 104 to 116 and its sayings of the carrying); the carrying as it was at the plan's commit, carry/Living_Improving_Value.md at git 13a3a6f, its part for Natural Naming; carryings/session_v378/Session_Report_v378.md lines 15 to 32; carryings/v368_sources/Carry_Set_v368_README.md (lines 18 to 33, 93 to 95, 135 to 137, 200 to 207), Wrap_v368.md line 73, Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md lines 257 to 267 and 533, and Living_Improving_Value_v368.md line 961; incoming/v385A/Registry_Plan_Comparison_v385A.md lines 20 to 35.

Checked by exact search: each quotation in a NEW paragraph, in the living files at the root, by script (each found whole); each EVIDENCE sentence of the four RESOLVED blocks, in the living file it names; each step number, in Exhibit THIRTY now and at version 376. For RESOLVED and NOVALUE blocks, and for each paragraph of which a part is left out of NEW, the mate, its two sister mates and carry/*.md were searched for a pointer: links into this mate, "the preceding", "at this mate", "the concern at", "the droplet at", "current droplet", "existing concern", "above", "Table B", "row G", "Opportunity 5", "motion written", and the subject words of each. Two pointers reach this portion and both reach paragraphs left as they are: carry/Carryings_of_Natural_Intelligence_Corus.md line 166 at paragraph 6, and the mate's paragraph tagged v385A with the plan comparison at paragraph 27. Each NEW paragraph was laid beside its prior clause by clause, and its length and the first reader's word list were checked by script (each within forty to one hundred and fifty words, none of the listed words in the first reader's own sentences); the three corrected paragraphs under SAFER were checked the same way.

Earlier readings of the same paragraphs at other mates were read after my own reading, for one verdict across copies: PH_5a (paragraph 96, the copy of 21), GH_2 (paragraph 49) and EM_1 (paragraphs 8 and 9), the copies of 28 and 29; HP_1, RR_1 and XP_1 for 25; EQ_5 and MA_1 for 43; ME_1, NN_2, PH_6b and EX_1 for the other opportunities of the list paragraph 33 is from.

Not settled here: the eleven blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 2 the flat saying of "the same stable form of equilibria hard probleming" has no version in NEW; the prior has "Arrived at v377" and its source "Suggested at v377", and I read no loss with paragraph 31 kept beside it. At 30 "Natural Naming's carrying of that version" names the carrying more closely than the prior does; I found it right and did not object. At 28 the second copy is outside this portion, and its own second reading is another reader's.
