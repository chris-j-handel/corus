### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OBJECT
WHY: Two things change beside the prior. (a) Added, and at a higher strength than its source: the prior only names "the aberration study" and its place; NEW says in its own plain voice "the aberration-correction method of NASA's Jet Propulsion Laboratory separates the epoch a signal leaves its source from the epoch it is received and accounts for the source's motion between, the source's changing accounted and the accounting resting at its fixings". The source, carryings/resettling_v373/Natural_Intelligence_v373_Released.md line 749 (under "### 8.3 The geodesic discovering method", line 741), opens that sentence "In the field's own words, the aberration-correction method of NASA's Jet Propulsion Laboratory separates …"; NEW drops that attribution, so the claim is said as the mate's own, which is more than the source says and more than the prior says. The same mate, line 206, has a review paragraph against that very naming: "the field's name is light-time correction, Moyer; aberration is a separate correction."; and the living Geodesic Improving Method (line 395) now has "correcting light time and aberration in its SPICE toolkit, parts the epoch a signal is emitted at from the epoch it is received at", the naming changed. NEW would lay at the mate, as a present concept, a naming the mate's own paragraph corrects and the prior does not assert. (b) Narrowed: the prior has "Received here at this file's motion, whole, and φ said as the unrelationing rate and the primes as self-welcoming, each at no line of the code's running", the φ and primes clause joined by "and"; NEW has "Its entering is at Natural Physics' own motion, whole, with φ said as …", which makes the clause a manner of the study's own entering. The study's sentence has neither φ nor a prime (read at the source, lines 741 to 749), and the same closing clause, word for word, is at the Session Record's three other "Incoming, at v373, from Natural Intelligence" paragraphs with other passages (carry/Session_Record.md lines 1615, 1625, 1643), so it is a condition at the receiving file's motion beside the passage, not inside it; "with" settles a relation the prior leaves joined by "and". Checked and found sound, no objection: the path now at carryings/resettling_v373/ (incoming/ has README.md, v385A and v386EOD alone); the receiving line 743 "*Receiving: Re-said at 3.1, 3.2 and 3.3; the aberration study to Natural Physics.*"; "at no line of the resolver" as the living naming (Natural Mathematics line 179, "self-welcoming at the numbers and at no line of the resolver", of φ; Natural Numbers line 349, the same words, of the primes); the subject words "the aberration study" carried, so the pointer at mate line 52 ("the observings waiting at this section: … the aberration study") still finds it; nothing of the study at the living Natural Physics (searched aberration, light time, light-time, Jet Propulsion, JPL, epoch: none).
SAFER: **Droplet · The aberration study, from Natural Intelligence.** It is aimed at Natural Physics. At `carryings/resettling_v373/Natural_Intelligence_v373_Released.md` each passage is whole with its receiving; the passage for Natural Physics is the aberration study, under that file's 8.3, The geodesic discovering method, its receiving line naming the aberration study to Natural Physics. At Natural Physics' own motion it is received whole, and φ said as the unrelationing rate and the primes as self-welcoming, each at no line of the resolver.

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the task TASK_second.md; the brief HARM3.md; the first reader's brief BRIEFO3.md with its "Further rules"; the PRIOR file PH_1.txt (fourteen paragraphs); the PROPOSED file PH_1_report.md (thirteen KEEP, one RESAY, at paragraph 3).

The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md is 21,830 words, over the 15,000 at which a file is read whole, and paragraph 3, the one block that is not KEEP, names no section of it; it was checked by search (aberration, light time, light-time, Jet Propulsion, JPL, epoch, unrelationing, "no line of the resolver", "no line of the code": nothing of the study, and no sentence of φ as the unrelationing rate or of the primes as self-welcoming).

Read at the named places for paragraph 3: the source carryings/resettling_v373/Natural_Intelligence_v373_Released.md, its opening (title, subtitle and "## 1 What this is") and lines 735 to 760 (8.3 whole, with its receiving line 743 and the study's sentence in line 749); carryings/resettling_v373/Natural_Intelligence_Map.md at the Part Eight table (the 8.3 row) and the table of receiving files (the Natural Physics row); carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 214 to 220; the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md at lines 13 to 19, 48 to 54, 206, 436 to 456 and 538 to 544, and its headings (older `## Droplets` from line 13 to line 573; sections headed v385A and v386EOD from line 574); Natural Mathematics v380L line 179; Natural Numbers v380L line 349; the Equilibria Registry v380L line 485; the Geodesic Improving Method v380R line 395; carry/Session_Record.md lines 1615, 1625 and 1643.

Checked by search: aberration in the living files at the root, in carry/*.md and in carryings/resettling_v373/; "Incoming, at v373" and resettling_v373 in carry/*.md, for pointers to the paragraph; light-time and Moyer in the living files and carry/*.md; the contents of incoming/ and of carryings/resettling_v373/. NEW of the PROPOSED has no quotation marks; its near-verbatim clause was laid beside line 749 of the source.

The thirteen KEEP blocks leave their paragraphs exactly as they are and were not checked further, as the brief gives. No file in /home/claude/corus was edited; this report is the one file written.
