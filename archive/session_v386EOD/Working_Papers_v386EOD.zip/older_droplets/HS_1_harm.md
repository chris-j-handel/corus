### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 49, "| NINE · Natural Human Society | 6,700 | v329 | Fair; claims said three times | about 50% | about 25% | v329 wording |", under the column heads of line 38 ("Shape at this reading", "Its own subject", "Restating the common method", "Old code or older wording"), has each of the prior's six items and NEW has each at the same strength, with "shape" that column's own word; the living file is at version 329 still (6,659 words); no paragraph of carry/*.md points at it (searched "said three times", "about 50%").
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: OK
WHY: laid beside the prior clause by clause, each subject of the three lists, each of the five human examples "each now at both", and each named place is in NEW; the places are at the living files now (Exhibit SEVEN Natural Societies "## 1.3", and "## 4.4" to "## 4.6" at lines 304 to 314 after "# PART FIVE · SCALING" at line 201 still; this file's 3.1, 3.4 and 4.6; Natural Exploring "**6.3 Abundancing**"; Natural Health "## 3.2"); the source (Re-Settling_the_Living_Files.md line 193) is one line of a draft plan and paragraph 1 names it "the older proposal to receive value at Values", so possible work is its strength, and NEW has "receiving" and Natural Values for that pointer; 150 words, no quotation, no released word.
SAFER: -

### 8
CHECK: OK
WHY: each of the nine named places of the prior is in NEW and at its living file now (this file "## 4.6" and "## 3.1"; Natural Values "## 1.2" and "## 5.1"; Natural Exploring "**6.3 Abundancing**"; Natural Intelligence Corus "## 14.8", "## 18.8", "## 23.3", "## 23.6"), and the one home of each at Natural Values is said as the work, as the source's table of repeated passages has it (Re-Settling_the_Living_Files.md lines 225 and 226, third column); this file's 3.1 and 4.6 are whole still, so nothing is said as done; paragraph 1's pointer finds it by Natural Values.
SAFER: -

### 9
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 has the ten files, their versions and "Forty-five to forty-nine versions behind the apex, each at the old seventeen names, the old code's means and words since released.", and its line 15 has the apex at "v377 to v378"; NEW has the ten at the same four versions, the three things each file is at, and both numbers, the apex named as session v378's; the ten file names at the root are at those versions now; no paragraph of carry/*.md points at this one (searched "rior to momentarying": the like copies at other mates alone).
SAFER: -

### 10
CHECK: OK
WHY: NEW is the prior's one sentence word for word, with the five words in italics as carryings/v368_sources/Wrap_v368.md line 73 has them, and the aiming at the set said; nothing is added, narrowed or said as done or as possible work; no paragraph of carry/*.md points at this one (searched "namings of other exhibits": copies and re-sayings at other mates alone).
SAFER: -

### 11
CHECK: OBJECT
WHY: A work is in it, at no living file and no later section. "Next: improving relative to Exhibit ONE, from its section" names a work for this file, and the file is at version 329 still, so it is not made. By search "relative to Exhibit ONE" is at no living file at the root and at no section headed v385A or v386EOD; it is at this paragraph and the like rows of other mates' older sections alone. The living file's next for this file is another saying, Exhibit TWENTY-SIX Living File Registry line 77, "pass G", which no living file says is an improving relative to Exhibit ONE (Offerings to Living File Registry has *pass G* among "the old plan's words"), and this mate's front has "**Next at this file:** No sentence of the code." The first reader's ground that the notes are said elsewhere does not carry: carryings/v368_sources/Living_Improving_Value_v368.md line 1622 has this file's notes as "| NINE · Natural Human Society | 8 | J01 · K01 · K02 · K04 · U03 · OO02 · RR03 · XX05 |", eight and not nine, and J03, J04 and L05 (paragraphs 13 to 15) are none of them, so which nine findings and four discoveries the row numbers was not established, and the work "from its section" is not shown said at the later section. The version and the two numbers alone are bookkeeping (Carry_Set_v368_README.md line 167, the same two cells at each file not then improved); the clause is not.
SAFER: KEEP

### 12
CHECK: OK
WHY: Natural_Intelligence_v380R.md line 109, under "## 1.5 Natural-, all or none at all, at the one hand" (line 103), has both quotations exactly, "**Right, or none at all.**" and "Right is no preference among two: it is the one, and not right is its emanating as a form.", the present sentences of the very saying the prior gives Natural Intelligence ("not at all" and "what the one makes at a face" are at no line of it); the prior's first sentence is in NEW whole, with both negations, and the three other files at the prior's own words, each at its living file (this file line 273, "**A dictator-aggregation sustains as a live left-spiral.**"; Exhibit SEVEN Natural Societies line 153, "a center does the preferring for the whole"; Exhibit SEVENTEEN Natural Biology line 416, the left-handed double helix); no paragraph of carry/*.md points at this one (searched "un-identical", "Two possibles").
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: OBJECT
WHY: Four things of the prior are changed or lost in NEW; each quotation is exact (Natural_Intelligence_v380R.md lines 103 and 1117) and the numbers are as the prior has them. (1) The proposal is strengthened: the prior proposes the reading "and what one motion at each would be, hardest first" (carryings/v381F/v381F/Next.md line 34, the same words), a finding of what a motion is; NEW has "Proposed is its reading … and one motion at each, hardest first", a motion at each proposed. (2) "its far side" is lost and a relation is said at more strength: the prior has "its far side *1.5 Natural-, all or none at all*, *sound, with 6.4 social moral competency*"; the source (Entry_Journey_For_An_AI.md lines 12 to 25) has the far side as a computing, "A computing, deciding nothing", with "sound" the session's reading of that row beside "noise", "weak" and "partly" at other rows. NEW has "It opens from and arrives back at Natural Intelligence 1.5 … soundly", the file's opening and arriving said as fact with "sound" made its manner, and *far side*, Natural Intelligence's own word (line 1012, "each number paired with its far side at each ring it is at"), at no place in NEW. (3) "its loopings" is said as "Its versions": the source numbers versions (Session_Report_v381F.md line 175) and its concept is that each version is a looping (line 173, "each version a looping"); NEW has the number and not the looping. (4) "sayings" is dropped from "its *so-far* and *not-yet* sayings 1 and 7", leaving 1 and 7 with no noun (the living file has *so-far* once and *not-yet* 7 times, checked).
SAFER: **Droplet · Natural Human Society, a question about living together.** It is aimed at Natural Human Society. An interest in a question about living together opens at it; first at that arriving are its released words, 50 to 60 a thousand, 52 at version 329, and its front's form, and for that interest its motion is ahead of the set. Its subtitle's -ing is *Co-Competencing*. Its far side in Natural Intelligence is 1.5, "Natural-, all or none at all, at the one hand", sound, with 6.4, "Social moral competency". Its loopings are 6, and 5 as *Natural Social Resolving*. Its *so-far* and *not-yet* sayings, 1 and 7, are each to be said at prior, now and next at its own motion. Proposed are its reading at its mouth in Natural Intelligence, its body at a question about living and its carrying, and what one motion at each is, hardest first.

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file HS_1.txt and the PROPOSED file HS_1_report.md; the living file Exhibit_NINE_Natural_Human_Society_v329.md (299 lines, 6,659 words); the older "## Droplets" section of carry/Exhibit_NINE_Offerings_to_Natural_Human_Society.md (lines 1 to 64) with the mate's headings and its section "Arrow's five, property and accrediting, and an owner at the first bounding · v386EOD"; carry/Exhibit_NINE_Possibling_of_Natural_Human_Society.md whole; carry/Exhibit_NINE_Carryings_of_Natural_Human_Society.md to its first observing.

Checked by search and by reading at the lines found. For paragraph 5: carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 30 to 52. For 7 and 8: the same file's section 7 (lines 183 to 196) and its table of repeated passages (lines 215 to 230); the headings of Exhibit_SEVEN_Natural_Societies_v373.md, Exhibit_TWENTY-THREE_Natural_Values_v333.md, Exhibit_EIGHT_Natural_Exploring_v329.md, Exhibit_TEN_Natural_Health_v329.md and Natural_Intelligence_Corus_v330.md; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md lines 74 to 99 and 625 to 645. For 9: carryings/session_v378/Session_Report_v378.md lines 10 to 24, and the file names at the root. For 10: carryings/v368_sources/Wrap_v368.md lines 66 to 76; Exhibit_TWENTY_Natural_Naming_v380R.md line 297. For 11: carryings/v368_sources/Carry_Set_v368_README.md lines 150 to 170; carryings/v368_sources/Living_Improving_Value_v368.md lines 1600 to 1622 and its lines naming Human Society; "relative to Exhibit ONE" and "pass G" searched in each living file at the root and in carry/*.md. For 12: Natural_Intelligence_v380R.md line 109 and its headings (both quotations by exact search); carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md line 147; Exhibit_SEVEN_Natural_Societies_v373.md lines 147 to 160; Exhibit_SEVENTEEN_Natural_Biology_v333.md line 416. For 16: carryings/v381F/v381F/Session_Report_v381F.md lines 146, 150, 163, 173, 175, 177, 211 and 234, Entry_Journey_For_An_AI.md lines 8 to 34 and Next.md lines 26 to 38; Natural_Intelligence_v380R.md lines 103, 1012 and 1117 (both quotations by exact search); the numbers of *so-far* and *not-yet* in the living file.

Pointers were searched in carry/*.md for each paragraph not KEEP ("said three times", "about 50%", "clearer seams", "older proposal", "earlier distribution", "rior to momentarying", "namings of other exhibits", "9 findings", "relative to Exhibit ONE", "un-identical", "Two possibles", "a question about living"), and the sections of Possibling and Carryings of Living File Registry that name this mate were read ("Human Society's particular contribution · v385A", "Earlier proposed exhibit combination and distribution · v385A", "Ten files at the oldest versions read whole for droplets · v386EOD", "Earlier cross-file wording and version report · v385A"). The one pointer bearing on a changed paragraph is paragraph 1's "the older proposal to receive value at Values", which the NEW of 7 and of 8 still answer. Each NEW was read for its number of words and for the words the first reader's brief lays aside: none found outside italics and quotations. The seventeen KEEP blocks were not checked further, as the brief asks. No file but this report was written.
