### 1
CHECK: OK
WHY: Exhibit TWENTY Natural Naming v380R line 605 (4.9) and lines 282 and 283 (2.4, "Released words, each with its carrying") read, both quotations exact; the living file's lines 29 and 35 have middling and rating as the prior has them.
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OK
WHY: the living file's lines 35 and 740 read, each quotation exact and each seat, pair and condition of the prior in NEW; concern 5 is at carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md line 63.
SAFER: -

### 4
CHECK: OK
WHY: carryings/review_networking_engineering_2026-09-30/README.md line 23 and its session report's line 533 ("Offer tri-bi-co-momentarying as its explicit resolving-face correspondence") read; the folder is at carryings/ now and at incoming/ no more, and both branch names, the sections and the receiving are in NEW.
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: OBJECT
WHY: Added and narrowed. The prior has "the illustrating draws one square until one does"; NEW has "a second square at Exhibit TWENTY-NINE Natural Illustrating, which draws one, follows a file's sentence of it". "A second square" is at no sentence of the prior and at none of Exhibit TWENTY-NINE Natural Illustrating v379, whose 2.2 (line 192) has "the correspondence of the two is said at a file's sentence before one square is drawn for the other" and whose 2.3 (line 204) has three readings of four corners; with three readings, what follows a file's sentence is a guess. The rest was read and is whole: the 4.10 sentence at Natural Intelligence v380R line 1000, the 1.2 sentence at Exhibit TWENTY-EIGHT Equilibria Registry v380L line 66, the corners and the +1 at the living file's lines 20 to 22, findings 3 and 10 at archive/session_v379/Session_Report_v379.md lines 17 and 24.
SAFER: **Concern · Four corners at three readings, and the part headings' pairing of the ten.** Exhibit TWENTY-TWO Resolving the Hard Problem Registry's front draws four corners 2, 3, 3 and 4 with the +1 at the centre. Natural Intelligence's 4.10 has "a unit square of four dots, 2, 6, 14 and 10, its empty centre the between", the four across connectors. Exhibit TWENTY-EIGHT Equilibria Registry's 1.2 has "Three overlapping momentaries use four positions." No file says the correspondence of the three, and Exhibit TWENTY-NINE Natural Illustrating draws one square for as long as no file says it. Beside it is the part headings' pairing of the ten at Exhibit TWENTY-TWO Resolving the Hard Problem Registry, against the two seatings. It is a concern for both.

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: OK
WHY: the living file's lines 802 and 3614 read, the four quotations exact; Exhibit THIRTY Co-Chaining Logic Registry v380L has no "thirteen" and has "settling" at step 335 alone, of another subject; the subject words paragraph 19 gives for row G25 are in the title.
SAFER: -

### 15
CHECK: OK
WHY: the living file's lines 3558, 3560 and 3568 (the opening of part 11, and 11.1) and Exhibit THIRTY Co-Chaining Logic Registry v380L steps 407 and 408 read, each quotation exact; "carried as one" is at step 181 alone, of the co-chaining at 17.
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: OBJECT
WHY: A named place lost and a relation dropped. The prior gives the places "(part 8 title, 16 entries, the given)" for its two phrases; NEW gives "A rate named as a value" its places and gives "the eighth value the circle reaches at none" none (it is at *The given*, line 778 of the living file). And the prior has the item under the map's "Other re-sayings", which carryings/co_chaining_map_v376/cover_REGISTRIES.md line 264 heads "Other re-sayings (the registries' voice against a spine step)": it is laid for re-saying; NEW has a parting alone and no re-saying. The rest read and exact: the part 8 title at line 2588 with sixteen entries (8.1 to 8.16), "**A rate named as a value.**" at line 768 within *The given*, and step 137 of Exhibit THIRTY Co-Chaining Logic Registry v380L (the map's 92).
SAFER: **Concern · *Value*, a rate named as a value and the eighth value, beside existing arriving.** Two sayings part. Exhibit TWENTY-TWO Resolving the Hard Problem Registry has "A rate named as a value" at the title of its part 8, of sixteen entries, and at *The given*, and has "the eighth value the circle reaches at none" at *The given* also. Exhibit THIRTY Co-Chaining Logic Registry has, at step 137, "Existing arriving at each observing is the value." They part at *value*: a still a rate is named as, and an eighth the circle reaches at none, at the one; existing arriving at each observing at the other. The parting is laid for re-saying.

### 22
CHECK: OBJECT
WHY: A relation dropped. The prior has the item under the map's "Other re-sayings" (cover_REGISTRIES.md line 264, "Other re-sayings (the registries' voice against a spine step)", its line 268 this item): it is laid for re-saying; NEW has a parting alone, and nothing of a re-saying. Nothing else is lost: the living file's line 736 and steps 81 and 226 of Exhibit THIRTY Co-Chaining Logic Registry v380L read and the three quotations exact (the map's 139, "each face one way", is the sentence "Six connectors, four across at 2, 6, 10 and 14 and two along at 9 and 17, each face one way", step 226 now).
SAFER: **Concern · *No one-way running*, beside six one-way steps and six names each facing one way.** Two sayings part. Exhibit TWENTY-TWO Resolving the Hard Problem Registry has, at *The given*, "There is no one-way running: only co- runs, so a one-way is in the naming, and the co-offering goes on underneath unchanged." Exhibit THIRTY Co-Chaining Logic Registry has, at step 81, "six one-way steps forward, three at each side, within the four momentaries", and, at step 226, "each facing one way". They part at one-way: no *one-way running* at the one, and one-way steps and one-way facings at the other. The parting is laid for re-saying.

### 23
CHECK: OK
WHY: the living file's line 736, step 538 of Exhibit THIRTY Co-Chaining Logic Registry v380L and cover_REGISTRIES.md lines 228 to 230 (P7, "after 252; re-says", its sentence word for word) read; P7's sentence is at no step of the Registry now by search.
SAFER: -

### 24
CHECK: OBJECT
WHY: A named place changed, and a relation dropped. The prior has "connectors at 139, not faces at 141". The map's 141 is the sentence "One entry, six connectors and ten faces are the seventeen names, and ten roots are the two sides' ten positions" (carryings/co_chaining_map_v376/Co_Chaining_Groups_v376.md line 192, two steps on from its "Six connectors … each face one way" at line 190, as 141 is two on from 139; cover_REGISTRIES.md line 36 has "141's ten faces"). That sentence is step 250 of Exhibit THIRTY Co-Chaining Logic Registry v380L now, "The seventeen names are the entry at 1, six between selves and ten within one self, and ten roots are the two sides' ten positions." (archive/carrying_v380L/Exhibit_THIRTY_Co-Chaining_Logic_Registry.md line 29: "Entered at step 250"). NEW names step 252, another step. And the item is under "Other re-sayings" as at 21 and 22, and NEW has nothing of a re-saying. The seven pairs and the two part titles were read at the living file's lines 842 to 3206 and are right.
SAFER: **Concern · The ten parts at seven name pairs eight apart, beside the Registry's ten names within one self.** Two sayings part. Exhibit TWENTY-TWO Resolving the Hard Problem Registry's ten parts are at seven name pairs eight apart: 12 and 4, 16 and 8, and 13 and 5 each have two parts, and its parts 1 and 2 are at "10-other-social-self-tunneling and 2-other-self-offering" and "14-other-social-surfacing and 6-other-self-surfacing". Exhibit THIRTY Co-Chaining Logic Registry has, at step 226, "Six names are between selves, four across at 2, 6, 10 and 14", and, at step 250, "six between selves and ten within one self". They part at the seats of the ten: 10 and 2, and 14 and 6, are names between selves at the Registry and none of its ten within one self, and the parts' seating is other than that ten. The parting is laid for re-saying.

### 25
CHECK: OK
WHY: carryings/natural_physics_v377/README.md line 108, the living file's line 736, Exhibit FOUR Natural Mathematics v380L line 137 (2.3) and the proposed file's headings 3.4 and 3.5 read; the 776, the 216, the four tables, line 736 and each file's own resolving are in NEW.
SAFER: -

### 26
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 168 read, its row whole in NEW and no more; Natural Intelligence Corus v330 has Part 17 in place.
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: OK
WHY: carryings/session_v377/Session_Report_v377.md lines 190 and 250 read; the three seats' six members, the entering and surfacing faces, pairs 3, 4 and 5, pairs 2 and 6, the three-way asking and the asking open at the lead are each in NEW.
SAFER: -

### 30
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 27 read; step 522 of Exhibit THIRTY Co-Chaining Logic Registry v380L is the ten one-way readings at the ten by the four-cycles, the number unchanged from version 378.
SAFER: -

### 31
CHECK: OBJECT
WHY: Added. The prior has only: Natural Naming 4.9 against the seating eight apart, parting at six of the ten. NEW adds a reason, "Natural Naming has one name of 1 to 8 by its four-cycle, and Exhibit TWENTY-TWO Resolving the Hard Problem Registry two names eight apart", which is at no sentence of the prior (the first reader's rule 11). It also reads against the prior's number: one name beside two names eight apart differs alike at each of the ten, while the parting is at six, four of the ten being at one of their two names (the first reader's own EVIDENCE). The two quotations are exact (Exhibit TWENTY Natural Naming v380R line 613; the living file's line 740) and the opening is one of the six paragraph 5 lists.
SAFER: **Concern · Natural Naming's 4.9 beside the seating eight apart.** Two sayings part. Natural Naming, at 4.9, has "an opening named as a place" at "even, 1 of 1-2-co-bi-offering, torusing's". Exhibit TWENTY-TWO Resolving the Hard Problem Registry, at its seating eight apart, has "an opening named as a place, at 14-other-social-surfacing and 6-other-self-surfacing". They part at the seating of the ten, at six of the ten.

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: OBJECT
WHY: Lost: two of the fold's four. The prior names the four, "a reference held, a rate held, a magnitude driven, a returned sign entered as cost"; NEW names two, a rate named still and a magnitude driven, and drops "A reference named still" and "A released parity entered as cost" (the living file's line 742), the two the inexact ledgers lie beside. NEW is at 149 words; with the four positions, the six, the four ledgers, the fold's four, the two exact pairings and the parting it came to 155 to 172 words at four tries, over the first reader's one hundred and fifty, the reason that reader gives for KEEP at 2 and 5. What NEW has was read and is right: Exhibit TWO Natural Networking v371 lines 957 to 965 (6.2, *running order* for the older *turn*, the taking and the refusing) and line 989 (6.6), and the source's G03 (Kit_Exhibits_ONE_and_TWO_v365.md lines 628 to 638), whose "Held-bounding falls inside a reference held, and held-vantage reaches a middle held as an end and a membrane held as a cut" confirms the four older ledger names at the four of 6.6 in order.
SAFER: KEEP

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: OK
WHY: carryings/natural_physics_v377/README.md line 93 and the proposed file's "## 5.11 Register, the field's arrivals at their namings" (line 612) read; the negation, the 48 rows, the six and the tenth are in NEW.
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: OK
WHY: the living file's line 740 and its ten part titles (lines 842 to 3206) read: each of the ten is named and at its number names; the version living at v368 (v344, git 34bbcb1) had "an arriving, held from behind" and part titles with no number names, and Exhibit TWENTY-SIX Living File Registry v381R line 90 has "its parts at the ten things named still" at v375; Exhibit TWENTY-ONE Hard Problem Registry has none of the ten; no paragraph in carry/*.md points at it.
SAFER: -

### 38
CHECK: OK
WHY: the living file's line 13 ("Two hundred and fifty-five arrivals stand at the incoming face, each of them deployed here") read, "held as" at no line, and each of the ten at one name across the file by a tally of the ten names; "37 findings and 17 discoveries" is a number of the carry's notes at v368, at its source carryings/v368_sources/Carry_Set_v368_README.md lines 29 and 154; no paragraph in carry/*.md points at it.
SAFER: -

### 39
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md, the first reader's brief BRIEFO3.md with its Further rules, the PRIOR file RR_1.txt, the PROPOSED file RR_1_report.md, and the mate carry/Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md from its `## Droplets` (line 85) to its end (line 301), each later section headed · v385A and · v386EOD among them.

The living file Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md (about 65,000 words) was read at its front (lines 1 to 50) and at *The given* whole (lines 724 to 837), and by search at lines 2588, 3556 to 3568 and 3614, at its twelve part titles, at the number of entries of part 8, and at a tally of each of the ten names across the file. The version living at v368 was read from git (34bbcb1, v344) at its lines 35 and 740 and its part titles, for 37 and 38.

Other living files, by section or search: Exhibit TWENTY Natural Naming v380R (2.4's rows of *middling* and *rating*, 4.9 whole); Exhibit THIRTY Co-Chaining Logic Registry v380L (steps 81, 83 to 88, 137, 181, 226, 248 to 253, 335, 405 to 409, 522, 523, 538, 540, and searches of "thirteen", "settling", "carried as one", "at once", "offering at words of a form still"); Natural Intelligence v380R (4.10, line 1000); Exhibit TWENTY-EIGHT Equilibria Registry v380L (1.2, line 66); Exhibit TWENTY-NINE Natural Illustrating v379 (lines 190, 192, 204, 240); Exhibit TWO Natural Networking v371 (6.2 and 6.6 whole); Exhibit FOUR Natural Mathematics v380L (2.3); Exhibit TWENTY-SIX Living File Registry v381R (the row of this file and the rows of the workings of v377 and v378); Exhibit TWENTY-ONE Hard Problem Registry v375 (searched for the ten and the older names); Exhibit EIGHTEEN Natural Physics v379 and Natural Intelligence Corus v330 (headings).

Sources: carryings/co_chaining_map_v376/cover_REGISTRIES.md (its opening key, table A, lines 215 to 275) and Co_Chaining_Groups_v376.md (lines 186 to 200, and the sentences the map's steps 54, 92, 139 and 141 name); archive/carrying_v380L/Exhibit_THIRTY_Co-Chaining_Logic_Registry.md lines 13 to 49; carryings/review_networking_engineering_2026-09-30/ (README and the report's lines on this file); archive/session_v379/Session_Report_v379.md lines 15 to 26; carryings/session_v377/Session_Report_v377.md lines 15, 62, 190, 250; carryings/session_v378/Session_Report_v378.md lines 20 to 30 and 47; carryings/natural_physics_v377/README.md and the proposed file's headings and 5.11; carryings/resettling_v373/Re-Settling_the_Living_Files.md line 168; carryings/v368_sources/Wrap_v368.md (lines 38 and 60 to 73), Carry_Set_v368_README.md (lines 20 to 36, 55, 113, 150 to 156), Living_Improving_Value_v368.md by search, and Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 622 to 640.

Checked by search: each quotation of each NEW against the living files at the root (each is an exact sentence or part of one of the file it names); carry/*.md for a paragraph pointing at 37 or 38 ("registry pair", "named and numbered", "one name each", "ten holdings": none but the two paragraphs themselves); the sister mates Carryings of and Possibling of Resolving the Hard Problem Registry for their pointers at this section (the Carryings mate's lines 7 and 9, "these prior offerings remain whole" and "remain existing concerns", name the resolver-name, marker, locator, ten-correspondence, fourth-settling and retired-ledger paragraphs, each of which is KEEP or a RESAY with its subject words); carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md line 63 (concern 5) and its section "The older and newer ten and their unresolved correspondence · v385A"; and the set's use of "the expedition's self" in carry/*.md for the lead.

The twenty-one KEEP blocks were not checked against their sources beyond what the others needed. Not established: whether "the illustrating" of paragraph 6 is the living Exhibit TWENTY-NINE Natural Illustrating or its working at version 379; both NEW and SAFER name the living file, whose 2.2 and 2.3 have the saying. In 21, 22 and 24 the closing sentence of SAFER rests on the map's heading "Other re-sayings (the registries' voice against a spine step)", which the prior paragraphs cite by its first two words.
