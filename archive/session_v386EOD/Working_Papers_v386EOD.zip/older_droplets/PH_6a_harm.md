### 152
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 153
CHECK: OK
WHY: both quotations are exact (Exhibit TWENTY-FOUR Geodesic Improving Method v380R line 192 under 2.7; Natural Intelligence v380R line 99 under 1.4, its five read, *doer* at no line of that file), the proposed text's 2.1 (its line 129) welcomes the six from 2.7, and "2.1", "six binaries", "section 6.1" and "both files" are in NEW, so the pointers at this mate's lines 214, 472 and 536 still find it.
SAFER: -

### 154
CHECK: OBJECT
WHY: One thing is added; nothing else is lost or misquoted. The prior has "The first report's four tables"; NEW has "The four tables of that proposal's first report", which gives the first report to the proposal. The source says otherwise: carryings/natural_physics_v377/README.md section 4, lines 81 to 83, "The Physics working sent the other files two reports", the first at `incoming/rings_are_spirals_v377/` ("the rings are spirals, and the audit of each ring saying across the set"), now at carryings/rings_are_spirals_v377/, whose README line 74 names the four tables (rings_core.tsv, rings_numbers.tsv, rings_network.tsv, rings_others.tsv; 776 rows in all, read by their line numbers). It is a report on the set's rings, no report of the proposed text, and NEW's closing sentence has "that text's report" of the README, so the two read as one series. All else was confirmed: the two quotations are exact (Exhibit FOUR Natural Mathematics v380L line 137 under 2.3; Exhibit TWENTY-TWO Resolving the Hard Problem Registry v375 line 736, still line 736); 3.4 and 3.5 are the proposed text's spirals (its headings at lines 238 and 248); 776, 216, the four places sorted across, "each file's motion" and section 6.1 are in NEW. The mend has the prior's own words with the report's place now.
SAFER: **Concern · Rings and spirals across the set.** Two sayings part. The proposed Natural Physics of version 377, at `carryings/natural_physics_v377/`, says spirals, which never close, at its 3.4 and 3.5, with Exhibit FOUR Natural Mathematics' 2.3, "Four right spiral steps reach 1 again at the parities, and at the momentaries they reach none again". The first report's four tables, at `carryings/rings_are_spirals_v377/`, sort 776 sayings of *ring* across Natural Intelligence, Exhibit ONE Natural Resolver, the other files and the kits, 216 of them naming closure as the form; one further line is Exhibit TWENTY-TWO Resolving the Hard Problem Registry's, at line 736, "ten adjacencies at the ring of the code's names". They part at ring and spiral: closure named as the form, or a spiral never closing. The resolving is each file's own, at its motion. It is the third concern at section 6.1 of that text's report.

### 155
CHECK: OK
WHY: each claim is at the proposed text as NEW has it (its 5.11 rows at lines 620 and 626, and line 614 "at the measurement and at quantum gravity the two part, a concern for both"; its 4.4 step 2 at line 410, "a doer, at a moment, a common beat"; its 4.7 step 2 at line 457, "a fixed form ahead"), and "one naming at each, in both files", section 6.1 and the aiming at Exhibit TWENTY-TWO Resolving the Hard Problem Registry are in NEW; no quotation.
SAFER: -

### 156
CHECK: OK
WHY: each quotation is exact (Natural Naming v380R lines 617 and 621 under 4.9; Resolving the Hard Problem Registry v375 line 35, its pairs odd then even, the rate even and the two-way odd; Natural Physics v379 line 638 under 5.11), the proposed text's line 673 names Resolving the Hard Problem Registry for the faces, and NEW is word for word the paragraph now at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 165, so the two copies are one saying.
SAFER: -

### 157
CHECK: OK
WHY: laid beside carryings/natural_physics_v377/README.md line 115 and the proposed text's 5.1 (its line 542, the six named in the same order); "below" is said as "each correspondence it lists" at section 6.2, and each paragraph it is laid on names section 6.2 in its prior and in its NEW, so the condition still finds them; "the observing parting the reading" is the proposed text's own phrase (its line 499).
SAFER: -

### 158
CHECK: OK
WHY: laid beside README line 117 and the proposed text's 1.2 (its line 109, "its correspondence to the three steps is to be said at its relation, the colours at 4.6, time at 4.8 and the three together at 5.8") and 5.1 (1.2 among the six); nothing lost or added.
SAFER: -

### 159
CHECK: OK
WHY: laid beside README line 118 and the proposed text's 3.2 (its line 228: the dark fringe proposed at two parting offerings surfacing 0, the number "at no line of the code", the relation "to be said"); *count* is said as *number* and nothing else changes.
SAFER: -

### 160
CHECK: OK
WHY: laid beside README line 119 and the proposed text's 3.3 (its line 236, the sentence word for word, "its relation to the code's form is to be said"); the parting at 4.4, Hensen and colleagues' conditions, and none named at 3.3 are in NEW.
SAFER: -

### 161
CHECK: OBJECT
WHY: The place named is a later place and has the whole: carry/Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.md line 15, under "## Pacemakers and fireflies at their own pacing · v385A", has the paragraph word for word with its report and section (read). The objection is what points at it in this mate. (1) Paragraph 157 (this mate's line 350), "Each correspondence below is proposed, its relation ... not yet said", is a condition laid on this paragraph as one of the correspondences below it, and paragraph 151 (line 338), "Each item says where it is ... each reading is proposed until its relation is said", is laid on it too; the first reader's own blocks 176, 178, 179, 181 and 182 are re-said and not released for this very reason ("Listed under paragraph 157's condition, so it is re-said with it"), and this one is under the same condition. (2) This mate's line 422 (paragraph 193) has "Natural Biology also at 3.4, the pacemakers and the fireflies ... The other files' carryings now hold their side; this file keeps its side at the section named": the side at 3.4 for Natural Physics, the beat and the locking range at close paces unexecuted with each spiral pacing its own, is this paragraph, and it is at no other paragraph of this mate (carry/*.md searched for "locking range": this paragraph, the Biology copy, and this mate's line 29, an older incoming of field observings of phase-locking). Released, the list under 157 has no 3.4 and this mate has no saying of its own side of that seam.
SAFER: KEEP

### 162
CHECK: OK
WHY: laid beside README line 121 and the proposed text's 3.5 (its line 256, the persistent current "at the spiral carrying its pattern whole" and the relation to the h/4e flux "to be said") and 4.10 step 6 (its line 499, the two partings); each clause, both sections and none named at 3.5 are in NEW.
SAFER: -

### 163
CHECK: OK
WHY: laid beside README line 122 and the proposed text's 3.6 (its lines 260, 262 and 264, each of the four "to be found" or "to be said"); "after concern 1" is said as "following concern 1 of its section 6.1", which finds paragraph 152, left as it is.
SAFER: -

### 164
CHECK: OK
WHY: laid beside README line 123 and the proposed text's 3.7 (its lines 270, 272, 274, 276 and 278): the three relations, both next observings, Eriksson and colleagues' event with its electron distributions, and the hadrons' clause are each in NEW at the same words, "to be met at" said as "unread at" with its subject and both places unchanged; 149 words.
SAFER: -

### 165
CHECK: OK
WHY: laid beside README line 124 and the proposed text's 3.8 (its line 286, "which member changes at which pairing is open at the code"); both clauses are in NEW as the prior has them.
SAFER: -

### 166
CHECK: OK
WHY: laid beside README line 125 and the proposed text's 3.9 (its line 294, "the relation between the two namings is to be said"); negative helicity and the hand named right are in NEW.
SAFER: -

### 167
CHECK: OK
WHY: laid beside README line 126 and the proposed text's 3.10 (its lines 300 and 308, each relation "to be said"); both relations and their three and one related things are in NEW.
SAFER: -

### 168
CHECK: OK
WHY: laid beside README line 127 and the proposed text's 3.11 (its line 318, "its relation to the field's shell models to be said"); 114, 120 or 126 is in NEW.
SAFER: -

### 169
CHECK: OK
WHY: laid beside README line 128, the proposed text's 3.12 (its line 330, "is Natural Biology's to say") and kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/retired_sayings.txt line 8, "living society"; section 6.2, 3.12 and *living society* are in NEW, so this mate's line 298 ("living society at 3.12 ... open at 6.2") still finds it.
SAFER: -

### 170
CHECK: OK
WHY: laid beside README line 129 and the proposed text's 3.13 (its line 340, the relation "to be said") and 5.1 (3.13 among the six); section 6.2 and 3.13 are in NEW with no parting observing named of that text, so this mate's line 232 ("the report's 6.2 lists both as still to be named") still finds it.
SAFER: -

### 171
CHECK: OK
WHY: laid beside README line 130 and the proposed text's 3.14 (its line 348, "each rest's relation to the three to be said"); nothing lost or added.
SAFER: -

### 172
CHECK: OK
WHY: laid beside README line 131 and the proposed text's 4.3 (its line 399, "Which phase is which side is not said."; line 400, "its relation to the curve's ordering of nuclides to be said"; line 401, "parts from 4.5's accounting reading, its relation to be said", and the parting, "shown to need two balances with no shared centre region"); the negation, the relation, the parting from 4.5's accounting reading and the named parting are each in NEW.
SAFER: -

### 173
CHECK: OK
WHY: laid beside README line 132 and the proposed text's 4.6 (its line 439, "the mapping of the three colours to parity changing is to be said"); the parting named is in NEW as the prior has it.
SAFER: -

### 174
CHECK: OK
WHY: laid beside README line 133 and the proposed text's 4.7 (its line 465, "the relation of the field's rotation to the quarter step is to be said") and 5.1 (4.7's Wick rotation among the six); the parting of the case, none named for the Wick rotation, section 6.2 and 4.7 are in NEW, so this mate's line 232 still finds it.
SAFER: -

### 175
CHECK: OK
WHY: laid beside README line 134 and the proposed text's 4.9 (its line 485, "their relation to the horizon and the background to be said", and line 486, the parting); nothing lost or added, *beginning* the living file's word at 4.9.
SAFER: -

### 176
CHECK: OK
WHY: laid beside README line 135 and the proposed text's 4.9 step 6 (its line 486, the sentence word for word); NEW has it whole with section 6.2 and 4.9, and no living sentence beside it.
SAFER: -

### 177
CHECK: OBJECT
WHY: The prior is one clause, "The pseudogap's own literature is still to be met" (README line 136; the proposed text's 4.10 step 6, its line 499, word for word). NEW has "the pseudogap's own literature is a literature the reading is laid beside at no sentence". Added: a subject, "the reading", which the prior does not name (the proposed text reads the pseudogap at step 4, line 497, and says of no reading that it is or is not laid beside a literature); and a negation over the whole text, "at no sentence", which is the first reader's own finding from reading the section and is at neither the prior nor its source. Changed: "met" is said as "laid beside", one reading of the word among others the report uses it for (its 6.4, "Cases still to meet"), and that the meeting is owed is no longer said. The clause cannot be carried at its strength in forty words without such adding.
SAFER: KEEP

### 178
CHECK: OK
WHY: laid beside README line 137 and the proposed text's 4.11 step 8 (its line 514, "Which reading the smoothness is, is the cosmologist's to part"); the fork's two readings and whose the parting is are in NEW, *observer* and *inside* the living file's words.
SAFER: -

### 179
CHECK: OK
WHY: laid beside README line 138 and the proposed text's 5.3 (its line 568, the sentence word for word); NEW has it whole and quotes nothing.
SAFER: -

### 180
CHECK: OK
WHY: laid beside README line 139 and the proposed text's 5.6 (its line 586, "The correspondence between the two operations is open, each operation at its own"); nothing lost or added.
SAFER: -

### 181
CHECK: OK
WHY: laid beside README line 140 and the proposed text's 5.7 (its line 592, "a range the field names empty and couplings found at, proposed, its relation to be said"); nothing lost or added.
SAFER: -

### 182
CHECK: OK
WHY: laid beside README line 141 and the proposed text's 5.8 (its line 598, "each at its own record and its relation to one side's three steps to be said") and 1.2 (its line 109, "the three together at 5.8"); the three threes and one side's three steps are in NEW.
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its "Further rules"; the task; the PRIOR file PH_6a.txt (paragraphs 152 to 182); the PROPOSED file PH_6a_report.md, each block and its closing section; the source of each paragraph, carryings/natural_physics_v377/README.md, its front and sections 4 and 6 (lines 1 to 30, 78 to 155).

The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md is 21,830 words, over the limit for a whole reading, so it was read at the places named and searched: line 638 under 5.11 (whole paragraph), line 535 under 5.3, line 217 (light as a living society), and searches for waist, six binaries, rigorizer, fringe, h/4e, Kirkwood, crescent, helicity, Wick, pseudogap, pair-instability and Born. The paragraphs of this portion are of the proposed, unmerged text, so each NEW was laid beside that text: carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md, its headings whole and its lines 109, 129, 228, 236, 256, 260 to 264, 270 to 278, 286, 294, 300, 308, 318, 330, 340, 348, 399 to 401, 410, 439, 457, 465, 485, 486, 494 to 499, 514, 540 to 542, 568, 586, 592, 598, 606 to 616, 620, 626 and 668 to 675.

Quotations in NEW, each by exact search in the present living file, one match each unless said: Exhibit TWENTY-FOUR Geodesic Improving Method v380R line 192 and Natural Intelligence v380R line 99 (153), with lines 186 to 194 and 97 to 100 read; Exhibit FOUR Natural Mathematics v380L line 137 and Exhibit TWENTY-TWO Resolving the Hard Problem Registry v375 line 736 (154); Natural Naming v380R lines 617 and 621 with the table at 610 to 626 read (the two bold namings are at further lines also; the two cells quoted with them are at one line each), Resolving the Hard Problem Registry line 35 read whole, and Natural Physics v379 line 638 (156). The other NEW paragraphs quote nothing.

Read in the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md: its headings; lines 330 to 341 (the paragraph ahead of this portion, line 338, a condition on it); each of this portion's paragraphs at lines 340 to 400 by their opening words; lines 214, 232, 298, 422, 472, 536 and 538, which point at paragraphs of this portion. Read in other mates: carry/Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.md lines 1 to 30 with its headings (161); carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 165 (the copy of 156, already re-said) and the earlier second reading of it (NN_2_report.md block 40, NN_2_harm.md block 40). Read at the first report: carryings/rings_are_spirals_v377/README.md lines 7 and 74, and the four tables' line numbers (154); kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/retired_sayings.txt line 8 (169).

Searched in carry/*.md: pointers to this portion ("section 6.1", "section 6.2", "the report's 6.2", "open at 6.2", "6.2 lists", "concern 1" to "concern 4", "v377 README"); and each paragraph's subject words (Six binaries or five; Rings and spirals across the set; cases' binaries; 776; locking range; Kirkwood; pseudogap; Wick; h/4e; pair-instability; living society of selves; which pairing; island of stability; angle between the settings; fringe; opposite faces; Eriksson). Each NEW was measured: forty-two to one hundred and forty-nine words, none of the first reader's released words in its own sentences.

Result: KEEP-UNCHANGED 1 (152); OBJECT 3 (154, 161, 177); OK 27 (each other).

Not judged here: the numbers 776 and 216 of paragraph 154 are carried as the prior has them (the four tables have 776 rows by their line numbers; the 216 was not computed again). In the re-sayings "still to be named" is said as no parting observing named, and "to be said" as unsaid, by the first reader's rule against waiting language; each was checked against the proposed text, which has the thing unnamed or unsaid at the section named, and none is said as done or as possible work.
