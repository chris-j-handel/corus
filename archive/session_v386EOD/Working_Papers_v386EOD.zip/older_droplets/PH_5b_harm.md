### 120
CHECK: OK
WHY: laid beside the prior and carryings/review_natural_physics_v377/README.md lines 55 and 79, each thing is in NEW (the Bell relation; lost as the review's 2.3, item 2 has it; sayable with no overclaim; said or released with its reason; the review's section 3, item 6), and the review's line 73 has the items of its section 3 parted at "a file's motion", which bears "said at that proposal"; no quotation, 64 words, none of the listed words.
SAFER: -

### 121
CHECK: OK
WHY: laid beside the prior and the two places it names: the review's line 80, and carryings/natural_physics_v377/README.md line 111, the paragraph of its 6.1 next after concern 4, which has "put the two-way and the rate at opposite faces", the one source of the two names NEW has; the parting is at the living files as said, Natural Naming v380R 4.9 lines 617 and 621 ("a two-way named to one side" at even, "a rate named as a value" at odd) beside Exhibit TWENTY-TWO line 740; the named places 4.9, 6.1 with its concern 4, and section 3, item 7 are each in NEW.
SAFER: -

### 122
CHECK: OK
WHY: the one quotation is exact at Natural_Intelligence_v380R.md line 222, within 3.5 (heading at line 218); the promise is at the proposed file's 3.4, line 246, "are to be executed at each spiral pacing its own"; each thing of the prior is in NEW at its strength (17 stepping each self together, the common beat of 3.5, the pacing the code does not carry, said as needing it or released), with the review's section 3, item 8.
SAFER: -

### 123
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 124
CHECK: OK
WHY: laid beside the prior and carryings/natural_physics_v377/README.md lines 6, 7 and 14 to 20: the branch, pull request 106, `main` e85b7c0, the file's name, five parts, forty-nine sections, 19,824 words, the five part names, and forty sections and 20,973 words at version 348 are each in NEW; the folder is at `carryings/natural_physics_v377/` now with the proposed file, `executions/` and its `outputs.txt` (listed), the proposed file has 19,824 words and forty-nine section headings (numbered by search), and the branch has `Exhibit_EIGHTEEN_Natural_Physics_v377.md`.
SAFER: -

### 125
CHECK: OK
WHY: laid beside the prior and the README's line 40, each of the five released is in NEW with its condition (by naming alone, no relation said); the three places NEW gives for "the prior carrying's line 84" are true as read: the README's line 7 has the path, the file is on the branch `working/physics-motion-v377` and at no folder of this tree, and its line 84 is the paragraph "At 5.7, the primes" with "the correspondence of fifty-nine to light a numeral alone"; Exhibit THREE Natural Numbers v380L has 1.3 at line 116 ("Twenty-three and twenty-five are facing across twenty-four at one") and 5.8 at line 289, the numbers unchanged; the words paragraph 126 points at, "readings at a numeral alone", remain.
SAFER: -

### 126
CHECK: OK
WHY: the quotation is exact at Exhibit_EIGHTEEN_Natural_Physics_v379.md line 304, within 4.4 (290 to 309), the very sentence the paragraph is about; laid beside the README's line 41, "listed at pass 6", no reason recorded, a reading at a numeral, 23, like those released as readings at a numeral alone, and the reason to be recorded are each in NEW at their strength.
SAFER: -

### 127
CHECK: OK
WHY: laid beside the README's line 42, both readings and both reasons are in NEW; the living file has "Born probability as the landed softmax" at line 553 (5.6) and "**Completest inversions.**" at line 497 (5.1), so neither is gone, and the proposed file's line 586 has "the code carries no normalizing and no softmax"; "reaches" for the prior's "meets" is the living file's own verb of a depth at line 304, "the depth a reversal reaches".
SAFER: -

### 128
CHECK: OK
WHY: laid beside the README's line 43, both readings are in NEW word for word; the living file has them still at line 485 (4.12, "a screening constant laid over the vacuum", "past the eighty-sixth balance") and line 333 (4.5, "exterior discard is perfect", "the largest surplus sits"), and *surplus* is that file's own word.
SAFER: -

### 129
CHECK: OK
WHY: the quotation "A frame standing outside" is exact at the living file's line 509 (5.3); laid beside the README's lines 44 to 47, the three released and where each is re-said are in NEW (the binaries of the proposal's 2.5, heading at the proposed file's line 159; its 4.9 pairing the black hole with the background; "its evaporation the carrying thinning" at its line 484), and each of the three places named is the proposal's own, so "at other places of it" narrows nothing.
SAFER: -

### 130
CHECK: OK
WHY: laid beside the README's line 48, both released and both reasons are in NEW; the proposed file's 3.16, line 364, has "two engineering choices with no coupling between them, are released as a rhyme", and the living file has both still at lines 243 and 245 (3.7), *geotensioning* its own word.
SAFER: -

### 131
CHECK: OK
WHY: laid beside the README's lines 53 to 56, the four checks and each result are in NEW as the report's (all passing; nothing to say; no released word but *keeping*, the name of a binary; one retired saying, living society at the proposal's 3.12, from version 348, open at the report's 6.2), the proposed file's line 330 has the saying at 3.12, the report's 6.2 lists 3.12, and *keeping* is at Natural_Intelligence_v380R.md line 99, "a keeping, a store beside it".
SAFER: -

### 132
CHECK: OK
WHY: laid beside the README's line 58, each thing is in NEW (each execution executable again at the report's folder, at Exhibit ONE Natural Resolver's code of version 376; `executions/outputs.txt`; the 3.7 output's place; the matching of a later executing, said as the report's; the three choices each script says), and both places are present now at `carryings/natural_physics_v377/executions/outputs.txt` and `carryings/physics_at_the_code_v376/resolver_crossings_returned.txt` (listed).
SAFER: -

### 133
CHECK: OK
WHY: laid beside the README's line 62, the three results are in NEW word for word with the script, its part, the proposal's 3.2 and the table's place; `forms.py` is at `carryings/natural_physics_v377/executions/` (listed), and the words paragraph 150 points at, the table of executions at section 3, remain.
SAFER: -

### 134
CHECK: OK
WHY: laid beside the README's line 63, the result and its three openings are in NEW with the script, the proposal's 3.3 and the table's place, nothing added from the first reader's own CONCEPT line; `two.py` is at the folder (listed).
SAFER: -

### 135
CHECK: OK
WHY: laid beside the README's line 64, two to six selves, one relation, alike at 2 to 64 patterns for each pairing and opposite at the rest are in NEW with both scripts, the proposal's 3.4 and the table's place; both scripts are at the folder (listed), and the proposed file's line 242 has "two to sixty-four of a pairing's patterns".
SAFER: -

### 136
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 137
CHECK: OK
WHY: laid beside the README's line 66, each result and each number is in NEW (2; 4n with 12, 20, 28, 36, 44; −, −, +, +; one like pair), with the script, its three parts, the proposal's 3.5 and the table's place, and "an execution" is right, the 3.5 having two rows.
SAFER: -

### 138
CHECK: OK
WHY: laid beside the README's line 67, the spiral of five, the 0 released at 10 at the like pair's self, and one self on at each second momentary are in NEW, with the script, the proposal's 3.5 and the table's place; `zero_tunnelling.py` is at the folder (listed).
SAFER: -

### 139
CHECK: OK
WHY: laid beside the README's line 68, the four tori and the six parting are in NEW number for number with both scripts, the proposal's 3.6 and the table's place; "true at some tori and parting at others" says the prior's "meeting and parting" at its strength, the proposed file's line 260 having the rule "met at the tori executed here" and parting at the six.
SAFER: -

### 140
CHECK: OK
WHY: laid beside the README's line 69, the script, the proposal's 3.7 and "the crossing and the trace" are in NEW; the script is at `carryings/physics_at_the_code_v376/resolver_crossings.py` now (listed), the prior's `incoming/` folder being at no place.
SAFER: -

### 141
CHECK: OK
WHY: laid beside the README's line 70, the three results are in NEW number for number (1,024 to one; 65 with 64; 1,024 with 512), with the script, its two parts, the proposal's 3.8 and the table's place.
SAFER: -

### 142
CHECK: OK
WHY: laid beside the README's line 71, each number is in NEW (500, 341, 159, 0, and −1, +1, +1, −1), with the script, the proposal's 4.5 and the table's place; `sums.py` is at the folder (listed), and the proposed file's 4.5, line 426, names it.
SAFER: -

### 143
CHECK: OK
WHY: laid beside the README's lines 73 to 77, each script and each condition is in NEW (docstring added, ring re-said spiral in names and printed labels, the three labels, the computation unchanged, byte for byte); read by comparing the two folders: `joined_alike.py`, `zero_tunnelling.py`, `torus_waist.py` and `sums.py` are the same byte for byte, `two.py`, `torus.py` and `spirals_joined.py` part by a docstring and the re-said names alone, and `forms.py` has the three labels as NEW gives them; the two folders are named as paragraph 144's NEW names the first and the second report.
SAFER: -

### 144
CHECK: OK
WHY: laid beside the README's lines 81 to 85, each thing is in NEW (two reports, the branch, each folder and what it has, seven findings at 2.1 to 2.4, 3, 4 and 5, the subtitle's six, the two commits); both folders are at `carryings/` now (listed), the second report's line 3 has "six findings for files other than Natural Physics" and its headings have the sections named, the branch and both commits are in the repository, and "the first" and "the second", by which paragraphs 136, 145 and 146 find it, remain.
SAFER: -

### 145
CHECK: OK
WHY: laid beside the README's line 87, forty-seven, forty-eight, the fifty less the file's own two, all forty-eight agreeing and the mass gap at 5.16 are in NEW; carryings/physics_for_other_files_v377/README.md line 20, within its section 2, has "all forty-seven rows at a naming were compared … and all forty-seven agree", and Exhibit TWENTY-TWO v375 has "## 5.16 Riemann, Hodge, Birch–Swinnerton-Dyer, Yang–Mills" at line 2057.
SAFER: -

### 146
CHECK: OK
WHY: laid beside the README's line 87, each claim is in NEW (the saying, at the second report's section 3, line 32 as read; false; the three sections each saying their seam; the search requiring text after the name; the carrying receiving the three seams with no such sentence and nothing at it leaning on the saying; 3.4, 3.7 and 3.29 named); the living Natural Physics has the word Philosophy at no line (searched), so the three sections are the proposal's, whose lines 416, 475 and 532 end at "Natural Philosophy 3.4, subject and object", "3.7" and "3.29" now, which bears "ended".
SAFER: -

### 147
CHECK: OBJECT
WHY: Lost: the place of the correcting. The prior has "(corrected at commit 5e84a84)", and NEW has no commit; the first reader's EVIDENCE says it was left out as a session's mark. It is a number and a named place of the prior (the first reader's rule 4), the one of the four corrections of the report's section 5 made ahead of the report (carryings/natural_physics_v377/README.md line 91, "The first was made before this report, at commit 5e84a84"), the second report names the same commit for it (carryings/physics_for_other_files_v377/README.md line 20, "Physics is corrected at 5e84a84"), the commit is in the repository, and the same first reader carries each commit at 124 and 144. Added, small: "a register of the field's arrivals", the words of the section's heading and at no word of the prior, which has "the register's namings". All else is whole as read: the namings, their pairs and each seat at Exhibit TWENTY-TWO at version 375; 48 rows agreeing; six at their one names at Natural Naming 4.9; the tenth, an opening named as a place; Exhibit TWENTY-ONE Hard Problem Registry has none of the namings (searched), and the proposed file's line 614 has the namings as Resolving the Hard Problem Registry's ten.
SAFER: **Droplet · The register of the proposed Natural Physics of version 377, at another file's namings, pairs and seats.** The proposed Natural Physics of version 377 has a register at its 5.11. The namings, their pairs and each arrival's seat are at Exhibit TWENTY-TWO Resolving the Hard Problem Registry at version 375, and not at Exhibit TWENTY-ONE Hard Problem Registry. Each of the 48 rows at a naming agrees with the seats of Exhibit TWENTY-TWO. Six of the namings are at their one names, as Natural Naming's 4.9 has them, and the tenth is named: an opening named as a place. That proposal's report, at `carryings/natural_physics_v377/`, has this at its section 5, with the correcting at commit 5e84a84.

### 148
CHECK: OK
WHY: both quotations are exact at Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md line 1466, within 7.3 (heading at line 1462), and line 1468 has "wavefunction, probability, time, arrow, and observer remain next physics families", *observer* that file's own word; laid beside the README's line 94, six named, four at the 7.3 families, neither of the two others, the next families, and the proposal's 5.3 saying it now (its line 570) are each in NEW.
SAFER: -

### 149
CHECK: OK
WHY: laid beside the README's line 95, the sections named at the proposal's 4.4, 4.8 and 4.12 and the naming bearer and bundle are in NEW; the proposed file's line 532 has "Natural Philosophy 3.29, which names the two bearer and bundle", and section 5 of the report is headed as corrections made at the file after the close.
SAFER: -

### 150
CHECK: OK
WHY: laid beside the README's line 96, each claim is in NEW (the 3.1 naming the report's folder for the executions of 3.2 to 3.8 and 4.5 and the 3.7 script at its own place; the 4.5 naming `sums.py` at its path; the bare name and the other session's branch earlier; no script named at the sentences of 3.2 to 3.6 and 3.8; the table giving each); the proposed file's lines 216 and 426 have the two namings under `incoming/natural_physics_v377/`, the folder is at `carryings/natural_physics_v377/` now (listed), and the table's words are those of the NEW lines of 133 to 142.
SAFER: -

### 151
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: HARM3.md; BRIEFO3.md with its Further rules; TASK_second.md; the PRIOR file PH_5b.txt, its thirty-two paragraphs; the PROPOSED file PH_5b_report.md, each block and its closing section; the paragraphs' source carryings/natural_physics_v377/README.md, lines 1 to 111; carryings/review_natural_physics_v377/README.md, lines 40 to 89 (its 2.1 from item 13, 2.2 to 2.6, and sections 3, 4 and 5).

The living file Exhibit_EIGHTEEN_Natural_Physics_v379.md has 21,830 words, over the 15,000, and was not read whole: its headings were read, and it was searched for each sentence a NEW line quotes or names, each read at its line and laid within its section by the headings (lines 243, 245, 304, 333, 485, 497, 509, 553, and 277 to 283 for the fit of 23 and 55), and for the word Philosophy, at no line.

Read at the places named, by search: Natural Intelligence v380R line 99 and 3.5 (lines 218 to 222); Natural Naming v380R 4.9 (lines 603 to 624); Exhibit TWENTY-TWO Resolving the Hard Problem Registry v375 lines 740 to 810 and the heading of 5.16; Exhibit TWENTY-ONE Hard Problem Registry v375, searched for each naming, none found; Exhibit TWENTY-SEVEN Living Ghost Registry v345a 7.3 (lines 1462 to 1468); Exhibit THREE Natural Numbers v380L 1.3 and 5.8; Exhibit TWENTY-FOUR Geodesic Improving Method v380R line 192. In carryings/: the proposed file, its headings (five parts, forty-nine sections, 19,824 words) and its lines 216, 242, 246, 330, 364, 416, 426, 475, 484, 532, 570, 586, 614 and 673; carryings/physics_for_other_files_v377/README.md, its opening, headings and lines 20 and 32; the opening and headings of carryings/rings_are_spirals_v377/README.md; the file names of the five folders the NEW lines name. The scripts of `executions/` were compared with those of the two earlier folders, by reading alone; none was executed.

In the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md: its opening, its headings, the head of its `## Droplets` section, the twins of 120 to 122 at lines 148 to 152, the paragraphs at lines 346, 348, 358 and 426, and the line of each paragraph of the two sources (lines 156 to 432). carry/*.md was searched for pointers at this mate ("the concern at this mate", "the droplet at this mate", "above", "the preceding", links to it): the links found are to its sections headed v385A and to `#droplets` for the concern of the gravitational wave, none at paragraphs 120 to 151. The re-said copy of 147 at carry/Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md line 155 was read.

From the repository's history, reading only: the branch `working/physics-motion-v377`, its file names and lines 80 to 86 of `archive/carrying_v377/Exhibit_EIGHTEEN_Natural_Physics.md` (for 125); that the branch `working/geodesic-improving-method-v381` and the commits 059e022, f1fc071, 5e84a84 and e85b7c0 are in it.

No block of the PROPOSED is RESOLVED, SAID or NOVALUE: twenty-nine are RESAY and three KEEP. Each NEW line and the one SAFER paragraph were numbered for words (47 to 127; the SAFER 118) and searched for the listed words, none found apart from quotations, italics and code marks. Not checked: pull request 106, which no file read here shows; the outputs of the scripts, carried as the report's; the checks of the kit at 131, carried as the report's.

One thing noted and left as it is, at 121: the two names, the two-way and the rate, are at the paragraph of the report's 6.1 next after its concern 4 (line 111), and at no sentence of concern 4 itself; the prior has "as the report's 6.1.4 says", NEW has that place as the prior has it, and this mate's paragraphs at lines 346 and 348 have the two places apart.
