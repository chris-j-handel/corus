# Brief for a second, independent reader checking a proposed change for harm

Do not edit any file in /home/claude/corus. You write exactly one file, your report, at the path your task names.

A file set called natural intelligence has living files at the root of /home/claude/corus and mates in /home/claude/corus/carry/. Your task names a PRIOR file (numbered paragraphs of one mate's older `## Droplets` section), a PROPOSED file (a first reader's verdict for each paragraph), the mate, and the living file. The verdicts: RESOLVED (the living file now says it, or the thing it concerns is gone; the paragraph would be released), SAID (a later section says the whole concept; released), NOVALUE (bookkeeping; released), RESAY (replaced by the NEW paragraph), KEEP (left exactly as it is). The first reader's brief is at /tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/older/BRIEFO2.md; read it first, with its "Further rules". Read the living file whole if it is under 15,000 words; otherwise read the sections the paragraphs name.

The rule above all is do no harm: a paragraph released or re-said wrongly loses value; a paragraph kept costs nothing. Find each place the PROPOSED would lose or change something the PRIOR has. Be strict, and check by reading with Grep and Read, never by trusting the first reader's EVIDENCE line.

For each block that is not KEEP:
- RESOLVED: find the EVIDENCE sentence in the living file by exact search. Does the living file now say everything the prior paragraph asks, or is the thing it concerns wholly gone? If any reading, number or relation of the prior is at no living file, object.
- SAID: open the place named and read it. Is it a living file or a section headed `· v385A` or `· v386EOD` (not an older `## Droplets` section)? Does it say the prior's whole concept, each relation, condition, number and negation? If not, object.
- For RESOLVED, SAID and NOVALUE alike: search the mate and carry/*.md for another paragraph pointing at this one ("the concern at this mate of …", "above", "the preceding", a link). If one does, or if this paragraph is a condition laid on the paragraph beside it, object.
- NOVALUE: read the prior for any concept, concern, condition or work in it. If there is one, object.
- RESAY: lay the prior beside NEW. Is each claim, condition, negation, number and named place of the prior in NEW at the same strength? Does NEW add or narrow anything, or deny anything the prior says? Is each quotation in NEW an exact sentence of the living file it names (exact search)? Does NEW narrate a session, promise later work or wait on anything? If anything is lost, added, narrowed, contradicted or misquoted, object and say exactly what.

Your report, plain text, one block for each paragraph number of the PRIOR file, in order:

```
### <number>
CHECK: <OK | OBJECT | KEEP-UNCHANGED>
WHY: <for OBJECT: exactly what would be lost, added, contradicted or misquoted, and what you read to find it; for OK: the place you read that confirms it, in one clause; for KEEP-UNCHANGED: a dash>
SAFER: <for OBJECT alone: the word KEEP, or a corrected NEW paragraph on one line, beginning with ** , that mends the objection and follows the first reader's rules for NEW; otherwise a dash>
```

Then a closing section `## READING` saying what you read whole and what you checked by search. Return, as your final message, only: the path of your report and the numbers OK, OBJECT and KEEP-UNCHANGED, with the list of objected numbers.
