### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: OBJECT
WHY: Three things of the prior are lost or changed; nothing is misquoted. The four quotations in NEW are exact strings of the living file (Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md line 197, the heading "5.3 An origin, living from living", and line 199, each searched and found once). (1) A person's exact words are lost. The prior has *explore this as much of it could be unhelpful or less than natural method*, the person's message as carryings/v380L/Progress.md line 40 and line 150 (transcript line 2666) have it. NEW has "that session offered the saying for exploring, much of it possibly unhelpful or less than natural method": the direction "explore this" is said as an offering, and its reason ("as much of it could be") is said as a description. By the first reader's rule 5 a person's words that NEW cannot quote mean KEEP, and the same first reading kept the sister paragraph for that reason (Offerings to Natural Intelligence line 127, the same words; NI_1_report block 8, KEEP, "a person's own words ... which cannot be quoted"). The one later place, Offerings to Co-Chaining Logic Registry, "Concern · A thing carrying none, collided" (v386EOD, line 444), has "itself offered as possibly unhelpful or less than natural method", a paraphrase too; the exact words are at no living file and no section headed v385A or v386EOD (searched "explore this as much" in carry/*.md: this paragraph and two more paragraphs of older sections, Offerings to Natural Intelligence line 127 and Offerings to Equilibria Registry line 91). (2) A named place is lost: the prior's link to carryings/v380L/Progress.md, "the earlier closing account". That file's part Three, "Sentences of living files resting on a saying of the session alone, for testing", is the one table saying which of these sayings was followed by hand and which is the saying alone, and it has the person's message whole; NEW names no place for it, and this paragraph is the only link to it in this mate (searched "carryings/v380L/Progress.md" in carry/*.md: this paragraph and one in Carryings of Natural Networking). (3) An exact former sentence is said indirectly, with a reading added. The prior has "The section before said *Living is carrying from the first changing on*", the section's own former sentence in italics (confirmed at carryings/v380L/Gathered_Value_4.md line 156, "entered in these lines in place of", and carryings/co_chaining_map_v376/cover_THIRTEEN.md line 73, which quotes it at 5.3). NEW has "The section, ahead of that saying, said living is carrying from the first changing on": the italics are gone, and "ahead of that saying" reads as a place within the section as readily as an earlier wording of it. The rest of the prior is in NEW at its strength: the three sayings, "each", of no authority, for testing at the method, no word is authority, and the last sentence worked at no case. The two places that point at this paragraph (Carryings of Resolving Hard Problems line 37; Carryings of Living File Registry line 514) find it either way.
SAFER: KEEP

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file; the PROPOSED file; the living file Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md (each section, 1.1 to 6.3). Read in part: the mate's `## Droplets` section and its list of headings; carryings/v380L/Progress.md, part Two's table, part Three's table and the transcript lines listed near its line 150; carryings/v380L/Gathered_Value_4.md lines 150 to 160; Offerings to Co-Chaining Logic Registry, "Concern · A thing carrying none, collided" and the droplet beside it; the sister paragraphs at Offerings to Natural Intelligence line 127 and Offerings to Equilibria Registry line 91; the first and second readings of that sister paragraph (NI_1_report and NI_1_harm, block 8).

Checked by exact search: each of the four quotations of NEW in the living file; "Living is carrying from the first changing on" across the repository (at no living file now; at Gathered Value 4, at the v376 cover of this file and at an archived copy of this paragraph); "explore this as much", "session v380L", "on the session's saying", "earlier closing account" and "carryings/v380L/Progress.md" in carry/*.md; pointers at paragraph 2 in the mate and in carry/*.md ("origin, carrying-none and colliding", "living from living, carrying none and colliding").

One block of the PROPOSED is not KEEP (2, RESAY) and it alone was laid beside its prior. The fifteen KEEP blocks leave their paragraphs exactly as they are and were not checked further; block 14's note, that a second reading may find it SAID at Offerings to Co-Chaining Logic Registry, was left at KEEP, which costs nothing. The pages at github.com and the comparisons at incoming/v385A/ were not opened. No file in /home/claude/corus was edited.
