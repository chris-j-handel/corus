### 174
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 175
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 176
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 177
CHECK: OBJECT
WHY: OBJECT grounds, found by laying the prior beside NEW and reading the source note (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md, lines 810 to 820) and Exhibit_FOUR_Natural_Mathematics_v380L.md 2.4 (lines 143 and 149). (1) Changed: the prior's "the sine arc and the cosine arc each absent at its own turn" is NEW's "each absent at its own quarter". The source has "cos and sin pass through zero by turns, cos, sin, cos, sin: at each quarter point one of the two is zero while the other is whole": "its own turn" is the alternating order, the same sense NEW says as "alternately" at its two other places. NEW has already fixed "a quarter" as the step θ → θ + 90° ("a quarter of the circle", "inverting at each quarter"), so "absent at its own quarter" reads as an arc absent through one quarter step, which the prior does not say. (2) A distinction lost: the prior has two words, the mathematics' *sign* (the signs of cos θ and sin θ, the sign of tan θ, sin 2θ's own sign, tan's sign) and the journey's *parity* ("the parity tips to its opposite at every step"), and its claim is that the one is the other. NEW says each as *parity* ("the parities of (cos θ, sin θ)", "the parity of tan θ", "as its own parity", "the parity of tan"), so "the parity inverts at each step" can now be read of P and Q, of which one alone inverts at a step (Natural Mathematics 2.4: "one parity inverted at each step"). The living file itself carries *sign* at this very mathematics: "Two parities (P, Q), the signs of cos t and sin t" and "the sign of P × Q, the sign of tan t"; "the parity of tan" is at no living file. (3) The prior's "So in the mathematics" is NEW's "In the mathematics": the yes following from the three identities is no longer said. Checked and found whole: θ → θ + 90°, tan(θ + 90°) = −1 / tan θ, sin 2θ = 2 sin θ cos θ, "decided by the step alone", "locally", "never both", yes at both questions, and the two things of the next opening; "1.5" is the kit's own 1.5, "The podaling journey, and the equilibria at it" (line 141 at v366, the same heading at the kit's v365), which has F(P, Q) = (−Q, P) and "The moving form."; NEW has no quotation in quotation marks; no paragraph of carry/*.md points at this one (Grep "EEE05": mate line 405 alone). NEW's text is about 166 words, over the first reader's one hundred and fifty.
SAFER: KEEP (a paragraph mending the three, with *sign* cited as Natural Mathematics' own word and each identity and both things of the next opening carried, is over one hundred and fifty words, so no NEW within the first reader's rules carries the whole)

### 178
CHECK: OBJECT
WHY: OBJECT ground, found by laying the prior beside NEW and reading the source note (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Natural_Illustrating_v366.md, lines 177 to 189), the living file whole, and carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 319. A thing intended is said as done. The prior closes "Carried into the first place to travel, so the boundary declarations and the equilibria definitions meet as one working.", with no tense; at the source this sentence is the note's part "**The next opening.**", work intended. NEW names the place as the living file and says it in the indicative: "It is carried into that file", that file being Exhibit TWENTY-EIGHT Equilibria Registry. The living file has no boundary declaration (Grep "boundary": one line, 5.2's "an unchanged boundary comparison"), and the later section "Illustrating contributions and their particular destinations · v385A" has the Equilibria Registry still "to receive the boundary and bounding ambition with the continuing still to demonstrate". So NEW says as a present fact of the living file what the prior has as an opening, the first reader's own rule 4. "It" also has no sure subject: by its place it is the binary examination or the file, where the prior carries the whole paragraph. Checked and found whole, clause by clause: the distinction; "is to be received" and "must show" at the strength of intending; the six places and "however declared"; the one question; "built neither the complete demonstration nor a universal exclusion"; the finite collection; the face gained and nothing executed; "intended and not opened". "The work arriving with Natural Illustrating at v366" and the file's name for "the first place to travel" are from the source (its title line "Work arriving from another expedition", its Standing, and "Equilibria Definitions is the first place to travel, the hardest"), and deny nothing of the prior. NEW has no quotation in quotation marks. No paragraph of carry/*.md points at this one (mate lines 337, 473, 475 and 489 say the same subject from other sources and are no pointers); its copy at mate line 487 is outside this input and is left as it is by this change.
SAFER: **Droplet · A boundary declared unchanging, and living bounding.** A boundary declared as unchanging stable-form naming is distinguished from bounding as living changing. Any conceivable declaration is to be received with no privileged class: within, around, across, along, at an entrance or at an exit, however declared. At each is one question: can the specified co-sequential resolving continue under that declaration; and the drawing must show the actual continuing or its failure at the transition. The work arriving with Natural Illustrating at v366 clarified the aim and the terms and built neither the complete demonstration nor a universal exclusion, and a finite collection of illustrations does not complete the universal claim. Exhibit TWENTY-EIGHT Equilibria Registry, the first place to go, gains a face it can be drawn at and nothing executed: the binary examination is intended and not opened. Its next opening: carried into that file, for the boundary declarations and the equilibria definitions to be one working.

### 179
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 180
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 181
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 182
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 183
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 184
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 185
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 186
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 187
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 188
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 189
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 190
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 191
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 192
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 193
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 194
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 195
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 196
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 197
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 198
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 199
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 200
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 201
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 202
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 203
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 204
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 205
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 206
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 207
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 208
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its Further rules; the PRIOR file EQ_6.txt (paragraphs 174 to 208); the PROPOSED file EQ_6_report.md, each of its thirty-five blocks and its READING; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (542 lines, about 12,300 words, both pages). The PROPOSED has thirty-three KEEP and two RESAY (177 and 178), with no RESOLVED, SAID or NOVALUE; the thirty-three KEEP are left exactly as they are and were given no further check. Read at the places named, for 177 and 178: the source notes EEE05 (Kit_Rings_in_Motion_v366.md, lines 805 to 822) and that kit's 1.5 (lines 139 to 150), with the section headings of the kit at v365 under kits/; the source note TTT10 and the front of Kit_Natural_Illustrating_v366.md (lines 1 to 12 and 170 to 192); Exhibit_FOUR_Natural_Mathematics_v380L.md lines 143 and 149; Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md lines 122 and 124; Exhibit_TWENTY_Natural_Naming_v380R.md 2.4's rows for *turn*, *travel*, *sign* and *run*; the mate at lines 337, 399 to 409, 471 to 475 and 485 to 491; carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 319. Checked by search in the mate and carry/*.md: "EEE05", "TTT10", "quarter turn", "boundary declared", "privileged class", "first place to travel" for copies and pointers; the pointer wordings "the preceding", "concern above", "droplet above", "at this mate of", "current droplet is at", "existing concern" in the mate (none found); "boundary" in the living file; "tan(θ", "−1 / tan", "by turns" and "never both" in Natural Mathematics, Natural Intelligence and Natural Illustrating (none at each); each NEW for the first reader's words not to be used (none found) and for its number of words. Neither NEW has a quotation in quotation marks, so no exact search of a quoted sentence was needed. Nothing was written but this report, and nothing in /home/claude/corus was edited.
