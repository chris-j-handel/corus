### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 42
CHECK: OK
WHY: laid beside the prior, each claim is in NEW at its strength (the aiming at the word, 2.4 releasing *in disequilibria* into the opening sentence, the subtitle parting at this phrase, one line laid ready at the file's carrying at the file's own motion, said as laid ready and not as done); both quotations are exact by search (Natural_Intelligence_Corus_v330.md line 9; Exhibit_TWENTY_Natural_Naming_v380R.md line 245, a row under "## 2.4 Released words, each with its carrying", line 228, ahead of 2.5 at line 303); "subtitle" in the laid-ready line is the source's own, carryings/v381F/v381F/Session_Report_v381F.md line 127 ("SIXTEEN's subtitle at *carrying* for *Traveling*; Corus's at the opening sentence for *in Disequilibria*") and Next.md line 58 ("One line each at the subtitle"), and the prior's own title has "at the subtitle"; nothing of the living file is added beside the two sentences the paragraph is about; no paragraph of carry/*.md points at it (searched "in Disequilibria", "at the subtitle", "opening sentence", "Aimed at a word, Natural Intelligence Corus"), and the title has the prior's subject words; 128 words, no released word outward of a quotation.
SAFER: -

### 43
CHECK: OK
WHY: laid beside the prior, each claim is in NEW in the prior's words (the front at one of the four older forms, a `## Contents` heading with *doors*; *door* released at Natural Naming 2.4 into *a self-bounding*; the aiming at the word); read at Natural_Intelligence_Corus_v330.md lines 17 to 21 ("## Contents", "a self couples at whichever door its interest opens", "ONE  The offering, and six doors each opening on the whole") and Exhibit_TWENTY_Natural_Naming_v380R.md line 249, "| *door* | a self-bounding, the self's own, nothing passing it or refused at it |", under 2.4; NEW has no quotation and adds no list of the four forms, and the four older forms are named whole at carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md line 153, a paragraph its own reading left as it is (GM_1 paragraph 27, KEEP), so the leaving of "Session_Report_v381F.md part 2.3, Finding 4" (read at its line 67) loses no content; no paragraph of carry/*.md points at it (searched "older forms", "Contents` heading", "*doors*", "self-bounding"); 52 words, *door* and *doors* cited in italics alone.
SAFER: -

### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 46
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 47
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 48
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 49
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 50
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 51
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 52
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 53
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 54
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 55
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file CO_2.txt, each of its seventeen paragraphs, 40 to 56; the PROPOSED file CO_2_report.md, each block and its READING.

The living file Natural_Intelligence_Corus_v330.md is 61,779 words, over 60,000, and was not read whole. Read: its front and contents, lines 1 to 64 (the title, the subtitle at line 9, "## Contents" at line 17 with its entries, the two notes beneath, and the opening of Part ONE with the second subtitle at line 61). By search: each line with *disequilibria* (lines 9, 75, 79, 117, 123, 165, 682), the subtitle as an exact string, and the number of lines with *door* (45).

Other living files, by section and search: Exhibit_TWENTY_Natural_Naming_v380R.md, the headings 2.1 to 2.7 (2.4 at line 228, 2.5 at line 303), the opening rows of 2.4, the rows of *in disequilibria* (line 245, exact string) and *door* (line 249), and each line with "opening sentence" (226, 245, 299) and "self-bounding"; Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md and Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md for "steady form", "older form" and "front form".

Mates, by search with each match read: carry/Offerings_to_Natural_Intelligence_Corus.md (its headings; lines 111 and 113, the two paragraphs re-said; each line with "subtitle", "opening sentence", "in Disequilibria"); carry/Carryings_of_Natural_Intelligence_Corus.md and carry/Possibling_of_Natural_Intelligence_Corus.md ("subtitle", "opening sentence", "disequilibria": line 50 of the Carryings alone, of another subject); carry/*.md for pointers at 42 and 43 and for their subject words ("in Disequilibria" at seven mates, each match read; "at the subtitle", "Aimed at a word, Natural Intelligence Corus", "older forms", "steady form", "Contents` heading", "*door*", "*doors*", "self-bounding"). No paragraph points at 42 or 43.

Sources: carryings/v381F/v381F/Session_Report_v381F.md lines 55 to 69 (Findings 1 to 5) and 120 to 130 (the Ready paragraphs), and Next.md line 58. The repository's history was read for the laid-ready line: it entered this mate at commit fd7f875 (v381R), from the report's "Ready, at the carryings of SIXTEEN, Corus, TWENTY-ONE and TWENTY-FIVE".

Sibling reports in the same folder, read for the like cases alone: GM_1_report.md and GM_1_harm.md paragraph 27 (the paragraph naming the four older forms, KEEP and KEEP-UNCHANGED); CH_1_report.md line 137 and LS_1_report.md line 71 (the same finding's lines at Natural Chemistry and the Living Society Registry, said in the same form); the form of EQ_4a_harm.md.

Checked for the two RESAY blocks, 42 and 43: each claim, condition, number and named place of the prior laid beside NEW; each quotation by exact search; the section number 2.4 at Natural Naming now; narrating, promising or waiting language; length (128 and 52 words) and the released words. The fifteen KEEP blocks are left exactly as they are and were not re-judged.

Things seen and not objections. At 42 the line laid ready is at no line of Carryings of Natural Intelligence Corus by search; the paragraph itself, at this mate, is where it lies, in the prior and in NEW alike, so NEW changes nothing of it. At 43 "the four older forms" is named whole at Offerings to Geodesic Improving Method line 153 alone, an older paragraph left as it is by its own reading; NEW rests on it as the prior does.

Numbers: OK 2 (42, 43); OBJECT 0; KEEP-UNCHANGED 15 (40, 41, 44 to 56).
