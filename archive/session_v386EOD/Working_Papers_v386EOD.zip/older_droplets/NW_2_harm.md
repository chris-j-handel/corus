### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: OK
WHY: each of the five EVIDENCE sentences is an exact line of Exhibit_TWO_Natural_Networking_v371.md (lines 307, 232, 553, 291 and 287, each found once by exact search and read in its paragraph): three columns at 307, no third self and one through nine at 287, six joining two at 291, and the sign carrying nothing else at 232 ("An arriving sign is its sign alone"), 553 and again at 737 and 893 ("carries the sign alone"), which is "no beat, time or source" by its sense and not by those words; the two sections are gone from Exhibit_ONE_Natural_Resolver_v380R.md (its bold headings read, lines 104 to 692, and "Returning and releasing", "The code at its names", "three columns", "third self", "no beat" searched there and at Natural_Intelligence_v380R.md: none); the row is at carryings/resettling_v373/Re-Settling_the_Living_Files.md line 148 and the released sentences at Exhibit_ONE_v372_Released.md lines 174 to 227, read; no paragraph of carry/*.md points at this one (the only other places of "Returning and releasing" and "three columns" are this mate's line 117, the same row in the same older section, Offerings to Natural Values line 45, of other sections, and Session_Record.md), and Possibling of Living File Registry, "Earlier Exhibit ONE explaining at its subject destinations · v385A", has Natural Networking receiving its share of Exhibit ONE's sentences.
SAFER: -

### 42
CHECK: OK
WHY: laid beside the prior and its source (carryings/resettling_v373/Re-Settling_the_Living_Files.md line 189, read), NEW has each number (172 of 173, 10,000 to 12,000), each destination and each named place (6.2 to 6.6, 6.12, 1.8, 4.6, 4.7, 5.1, 5.2, 5.4, each a heading of the living file at that number now, lines 572 to 1056), adds only "a plan" and "version 373" from the prior's own source, has no quotation, and has the words by which this mate's line 411 ("An earlier plan at this mate has this file carrying its 1.8 and the hole, 4.6's podal surface, 4.7, 5.1 and 5.2's securities and 5.4's seam") finds it.
SAFER: -

### 43
CHECK: OK
WHY: carry/Exhibit_TWO_Possibling_of_Natural_Networking.md line 15 is its own heading "## Instruments, callers and diagnostics at their proposed home · v385A" and its line 17 is this paragraph word for word with its source (compared whole: the same once the re-aiming note is left out); the two links to it (Possibling of Natural Exploring line 27, Possibling of Natural Engineering line 48) go to that section, no paragraph of carry/*.md points at this mate's copy, and it is no condition on paragraphs 42 or 44.
SAFER: -

### 44
CHECK: OK
WHY: laid beside the prior and its source (carryings/resettling_v373/Exhibit_ONE_at_its_Stable_Forms.md line 163, under "## 7 Concerns for both", read), NEW has whose the demonstration is, the connectors, the fractal of co-chaining and bi-tunneling, the society at `_17` inward and outward, "the same connectors at both with the parity changing" and the carrying's section receiving it with pass F, each at the prior's strength, adds only "a concern of version 373" from the prior's own citation, and has no quotation; it is work laid and not done, the living file's line 307 still having "the code gives 17 no expression of its own, so the running through it is the caller's composition"; no paragraph of carry/*.md points at it.
SAFER: -

### 45
CHECK: OK
WHY: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 363 is its own heading "## The earlier Natural Intelligence object-and-kit arrangement · v385A" and its line 365 is this paragraph word for word with its source (compared whole: the same once the re-aiming note is left out); the links at Possibling of Co-Chaining Logic Registry line 21 and Carryings of Living File Registry line 538 go to that section, no paragraph of carry/*.md points at this mate's copy, and it is no condition on paragraphs 44 or 46.
SAFER: -

### 46
CHECK: OK
WHY: laid beside the prior and its source (carryings/v368_sources/Carry_Set_v368_README.md line 30, place 4 with its two columns, read), NEW has each claim at its strength: the one beat at each ring checked, the own-turn round as the one beat at each node but the seam, "by one at most", both an order over the nodes, the open thing at the seam and both things released; "here" is said as version 368 from the prior's own citation; *own-turn* is at Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 324, within 4.4 ("The one-beat and the own-turn instruments both impose an order, and they part at the seam the round closes at.", exact), *travelling* at the living file's lines 612, 618 and 813, and "Conserving belongs within the momentary sequencing." at its line 839; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 47
CHECK: OK
WHY: laid beside the prior and its source (Carry_Set_v368_README.md line 36, place 10, and lines 98 to 104, read), NEW has each of the things the conforming is at, the three arriving instruments and what it releases, with "here" said as version 368 and the kit named as the source's table names it (line 190); the kit is as the prior has it (kits/Natural_Networking_TWO_Improving_Kit/Natural_Networking_Test_Kit_v368/ has the v265 file names and ring_crossval_v265.py line 10 has five engines; instruments_waiting/ has three instruments), so the work is not done; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 48
CHECK: OK
WHY: laid beside the prior and its source (Carry_Set_v368_README.md lines 80 to 82, "### 5 · The seam, where the one beat and the own turn part", under "Concerns we can address together", read), NEW has both questions, the reason ("both … being one"), "Nothing in the method decides it" and the nothing executed at each ring, with "here" said as version 368; "the concern" is the source's own heading; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 49
CHECK: OK
WHY: laid beside the prior and its source (Carry_Set_v368_README.md line 104, under "At the test kit, conforming to Exhibit ONE", read), NEW has the function at its code form, the standard's reserving at file scope for the compiler's own use, no warning under gcc and each trace identical; the kit's ring_pure_v265.c line 20 has `_1_self_coupling` still; the name is at no living file and no other mate (searched); no pointer at it.
SAFER: -

### 50
CHECK: OBJECT
WHY: NEW adds a clause the prior does not have and its citation does not name: "one of those worked a few at a time as the improving plan of version 368 continues". The prior is one line with the citation "(Carry_Set_v368_README.md, Mutual considerations, Across the living file set)"; the clause is carryings/v368_sources/Carry_Set_v368_README.md line 86 ("Worked a few at a time as the improving plan continues."), the lead sentence over the whole list of considerations (read, lines 84 to 139), and no part of this consideration at line 139. Said in NEW it is a carry set's own plan told in the present and a promise of later work, which the first reader's rules for NEW leave out, and it says as so now a plan of version 368 continuing. Nothing of the prior is lost; "a mutual consideration across the living file set" is the prior's own citation and stays. The SAFER paragraph is NEW without the clause, with the carry set and its version named from the citation alone, forty-three words with its title.
SAFER: **Droplet · Exhibit ONE Natural Resolver and Natural Networking cohering together.** Exhibit ONE Natural Resolver and Natural Networking together cohering into natural resolving social torusing is a mutual consideration across the living file set, among those of the carry set of version 368.

### 51
CHECK: OK
WHY: laid beside the prior and its source (Carry_Set_v368_README.md line 190, the table "The living file set, and what is happening to each file", read), NEW has corus.me, the 16 names, identical to version 368, the 15 checks, the four languages, no build folder, the checksums whole and the kit's next, the state said as of version 368 and the next as a relation now; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 52
CHECK: OK
WHY: laid beside the prior and its source (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md line 7, "Standing", read), NEW has the two files carried together and why, one Python and one naming, "seven instruments" as the prior has it and each of the eight things listed with what each is (59, three nodes, N phases, three full momentaries); the kit is named from the prior's own citation; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 53
CHECK: OK
WHY: laid beside the prior and its source (Kit_Exhibits_ONE_and_TWO_v365.md lines 112 and 115, read), NEW has the six instruments by name, the kernel whole through its own interface as Natural Networking's test kit does, the two things alone read, none of the ten internal positions, the seven checks at the six connectors alone as version 3621 asks, and the seventh instrument with twelve identifiers, seventeen positions, the roots, the successors and the proposals 2003 and 2195, "held for both to agree" said as a relation; *parity* for *sign* is Natural Naming 2.4's row (line 255); the instruments' names tie it to paragraph 52's kit beside it; no quotation, no pointer at it.
SAFER: -

### 54
CHECK: OK
WHY: laid beside the prior and its source (Kit_Exhibits_ONE_and_TWO_v365.md line 301, "## 4.1 Where TWO stands", and line 83, "ONE v3621 §6.101 reviewed it", read), NEW has version 359 with version 333 whole and seventeen changes, the review of 1.4 and 1.5 and the test kit at Exhibit ONE's 6.101, the thing received at its 6.76, and the relation of the two files with each improving at the connectors received; 1.4 and 1.5 are headings of the living file at those numbers still (lines 498 and 523); no quotation, no pointer at it in carry/*.md.
SAFER: -

### 55
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 58
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 59
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 60
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 61
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 62
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 63
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 64
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 65
CHECK: OK
WHY: laid beside the prior and its sources (Kit_Natural_Illustrating_v366.md lines 107 to 117 and carryings/illustrating_v366/Session_Report_v366.md lines 37 to 47, read), NEW has each claim and negation: three observations not supplying the proof and the five things supplying it, three node states not automatically three momentaries, the method's matching, three nodes at one beat at three selves, two things with one alone the momentary, the along and the across of the same number, the sentence reaching a conclusion neither carries, the caution at each writing of the three and the aiming at Natural Naming as two namings; "this proof" is the reduced ring rule's by the report's own order (its line 41 to 47), the rule being at paragraph 62, left as it is; *running* is at Exhibit_TWELVE_Natural_Explaining_v378.md line 360 (exact); no quotation, no pointer at it.
SAFER: -

### 66
CHECK: OK
WHY: laid beside the prior and its source (Kit_Exhibits_ONE_and_TWO_v365.md line 311, under "## 4.2 What the kit carries for TWO", and "## 2.1 The standing rule" at lines 136 to 143, read), NEW has each of the six improvings with its place (1.7, 5.2, 6.2, 1.8 twice, nine places in version 359), each word list's releasing, Exhibit ONE naming its four by their boundings, and the rule setting bi-tunnelling across society said as the kit's, which the source's 2.1 is; 1.7, 1.8, 5.2 and 6.2 are headings of the living file at those numbers still; the words in italics are among Natural Naming's released words at its lines 222 to 224 and 249; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 67
CHECK: OK
WHY: laid beside the prior and its source (Kit_Exhibits_ONE_and_TWO_v365.md lines 790 to 800, PP07, read), NEW has nine places, the grade column with its three, the grade column of the table at 6.7, three times at version 333, what each use named, the file's own word register with correction and received as motions, and the carrying of the column for both to agree, the state said as of version 359; 6.3 and 6.7 are headings of the living file at those numbers still (lines 967 and 995), and the file has *grade* once now, at line 973; no quotation, no pointer at it in carry/*.md.
SAFER: -

### 68
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file (paragraphs 40 to 68); the PROPOSED file with its READING; the mate carry/Exhibit_TWO_Offerings_to_Natural_Networking.md, each of its 473 lines, its first v385A sections, its Insertlets, its older Droplets and each later section headed v385A and v386EOD. Each paragraph of the PRIOR was compared whole with the mate and is one line of it (lines 169 to 225, the odd lines).

The living file Exhibit_TWO_Natural_Networking_v371.md is 24,802 words, over fifteen thousand, and was not read whole. Read in it: lines 232 to 236, 287, 291, 307 and 553 (the five sentences of paragraph 41, each in its paragraph), and its headings at 1.4 to 1.8, 4.6, 4.7, 5.1, 5.2, 5.4, 6.2 to 6.7 and 6.12 (the places paragraphs 42, 54, 66 and 67 name). Searched in it: each EVIDENCE sentence of paragraph 41 by exact search; beat, "sign alone", "carries no", history; travelling and traveling; "Conserving belongs within the momentary sequencing."; counting; rung, doors, "gate first", bothboth, grade; sign/carry and "local continuation".

Seventeen blocks are not KEEP and were checked: one RESOLVED (41), two SAID (43, 45), fourteen RESAY (42, 44, 46 to 54, 65 to 67). Twelve are KEEP at the PROPOSED (40, 55 to 64, 68) and were read in the prior and not checked further; nothing of them changes.

Read at other living files: Exhibit_ONE_Natural_Resolver_v380R.md, its bold headings (lines 104 to 692), and it and Natural_Intelligence_v380R.md searched for "Returning and releasing", "The code at its names", "three columns", "third self", "no beat"; Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 324 and its headings 4.1 to 4.5; Exhibit_TWELVE_Natural_Explaining_v378.md line 360; Exhibit_TWENTY_Natural_Naming_v380R.md lines 222 to 224, 235 to 281 (its rows for sign, met, run, take, count and keep) and 249; each living file at the root searched for "no beat", own-turn and own turn.

Read at other mates: carry/Exhibit_TWO_Possibling_of_Natural_Networking.md, its headings and lines 5 to 17; carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, its headings and lines 149 to 173 and 363 to 367; carry/Exhibit_TWO_Carryings_of_Natural_Networking.md, its headings; carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md, each line naming Natural Networking. The two SAID paragraphs were compared whole line against whole line with the sections named (43 with Possibling of Natural Networking line 17; 45 with Possibling of Living File Registry line 365): the same, the re-aiming note alone left out, and each section is headed v385A.

Read at the sources: carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 140 to 150 and 185 to 192; Exhibit_ONE_v372_Released.md lines 170 to 230; Exhibit_ONE_at_its_Stable_Forms.md lines 160 to 165; carryings/v368_sources/Carry_Set_v368_README.md lines 22 to 37, 76 to 106, 136 to 140 and 184 to 192; carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 5 to 9, 106 to 118, 136 to 143, 297 to 315 and 788 to 801, with its headings and its lines of 2195, 6.101, 6.76 and "for both to agree"; Kit_Natural_Illustrating_v366.md lines 105 to 118; carryings/illustrating_v366/Session_Report_v366.md lines 35 to 48; the kit at kits/Natural_Networking_TWO_Improving_Kit/ (its file names, its README by search, ring_pure_v265.c line 20, ring_crossval_v265.py lines 7 to 18, instruments_waiting/ listed).

Checked by search, for a pointer at each changed paragraph, over this mate and carry/*.md: each link into this mate by its anchor (twelve anchors, each a section headed v385A or v386EOD, none into the older Droplets); "at this mate", "this mate's", "the concern above", "existing concern", "the preceding", "current droplet is at", "droplet above", "earlier plan" at the three mates of Natural Networking; "Returning and releasing", "three columns", "Instruments, callers and diagnostics", "Proposed Part 5", "object-and-kit", "one beat", own-turn and own turn, "social torusing", "seven instruments", `_1_self_coupling`, kernel_correspondence, v3621, "nine places", "seventeen rungs", "six doors", "gate first", "15 checks", "three consecutive observations", "kit conforming", sign/carry, grade. One pointer found, at paragraph 42, from this mate's line 411; NEW has its words. No pointer at any other changed paragraph. "The preceding configuration" at paragraph 63 is of its own example and no pointer.

Each NEW was measured and searched: fifty-one to one hundred forty-nine words, split at spaces; none of the words the first reader's brief rules out is in a NEW outside italics or code; no NEW has a quotation, so no quotation was left to verify. Each word in italics was found at the living file the first reader names for it.

Not said as an objection, and for the one deciding: the fourteen re-sayings are each without the prior's parenthesis of source and its closing tag; each names its working another way (a plan made at version 373, a concern of version 373, version 368, the kit of Exhibits ONE and TWO at version 365, version 366's working), and they were passed as the first reader's brief has a report's name as a session's word. At 53, 54 and 67 the kit itself is unnamed and the version or the file's own version alone is given; 53 is tied to the kit by its instruments' names and by paragraph 52 beside it. Paragraph 42's NEW says "Part One is released at its re-teaching of the resolver" for "Part One releases where it re-teaches the resolver"; read as the places of its re-teaching it is the same, and the same NEW has the file carrying 1.8, a section of Part One. Paragraph 44's NEW has "with selves that are 1–17s inward and that is itself a self outward", the second clause of the society as the prior has it. The first reader has one NEW serving each copy of paragraphs 42, 44, 46 and 48 elsewhere in the same older section, outside this input; those copies were not checked here.

No file but this report was written, and nothing was executed beyond searching, reading, comparing lines and taking lengths.
