# Task for a second reader of one portion

Your message names a portion tag, for example PH_1. Every path here is under
/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/older/ unless it begins with /home/claude/corus.

1. Read the brief HARM3.md whole and follow it exactly.
2. PRIOR file: <TAG>.txt. Its first three lines name the mate (under /home/claude/corus/), the paragraphs it holds, and the living file (at the root of /home/claude/corus).
3. PROPOSED file: <TAG>_report.md.
4. Read the living file whole if it is under 15,000 words; otherwise read the sections named and search. Never read a file over 60,000 words whole. Other living files are at the root of /home/claude/corus.
5. Write your report to <TAG>_harm.md in the brief's exact form, one block for each paragraph number of the PRIOR file. Do not edit any other file, and do not edit anything in /home/claude/corus.
