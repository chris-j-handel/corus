### 1
CHECK: OK
WHY: laid beside the prior clause by clause, NEW has the Chebyshev net with its reference (Chebyshev, 1878, on the cutting of garments), the two families of threads, the plain weave at its two parities, "pattern matching, no correspondence shown", the helper's own carrying with no search and no reference at session v379, and "its reference first, its section named at its improving"; the file NEW names for the section is the file whose own carrying had the paragraph (archive/carrying_v381R/Exhibit_FOUR_Natural_Mathematics_v380R.md line 12, "its section named at its motion"), the source is archive/session_v379_exhibit_one_first/Session_Transcript_v379.md line 494 and has nothing NEW lacks or adds, what NEW leaves out is the session's own words and the transcript's path, whose folder is still named at carry/Exhibit_FOUR_Carryings_of_Natural_Mathematics.md line 11, and *cloth* and *correspondence* are in NEW for the pointer at carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md line 431.
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: OK
WHY: the quotation is an exact string of Exhibit_FOUR_Natural_Mathematics_v380L.md line 349 under 6.1 (the sentence the prior shortens with its ellipsis), and NEW has the place 6.1, the one naming of the three fixings, and each of the five places of the prior (Natural Intelligence, the Equilibria Registry, 6.1, 6.2 and 7.1), with the wait said as its resolving and nothing of paragraph 3 or of another living sentence added; the three are named apart still at lines 349, 359 and 377, at Natural Intelligence line 1089 and at the Equilibria Registry line 485.
SAFER: -

### 5
CHECK: OK
WHY: both quotations are exact strings of the living file under 1.4 (line 93, the one sentence of 1.4 with *a floor*, and line 91), Natural Naming's row at line 221 has *floor* among its released words, and NEW has the place 1.4, the word Natural Naming releases, Natural Naming's word in its stead, and across or along said at the bound, each as the prior has it.
SAFER: -

### 6
CHECK: OK
WHY: the quotation is an exact string of the living file at line 195 under 3.1, and NEW has the place 3.1 to 3.3, Exhibit ONE Natural Resolver's torus of selves at its own numbers (its line 645, "**A torus of selves.**") and chaining the prior on said beside involuting, both parts of the wait as the prior has them; "from the entry before" is the words of the list paragraph 3 is from (archive/carrying_v381R/Exhibit_FOUR_Natural_Mathematics_v380R.md line 20) and stays at paragraph 3, which is kept.
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: OK
WHY: each thing the row names is at a living file by exact search, "φ's continued fraction is all ones, the slowest nearing and the widest straddle." and "√5 is the largest constant for all irrationals together, and it is at φ" at Exhibit FOUR Natural Mathematics 2.8 (line 181), "Five to cohere and six to run" at its 5.2 (line 327), and "the four boundings with a floating third are the five at a naming" at Natural Naming 4.6 (line 589); Natural Intelligence's 1.4 is "No other possible method" now with no continued fraction, √5 or straddle at any line; the passage (carryings/resettling_v373/Natural_Intelligence_v373_Released.md lines 125 to 135) was read beside these, and its five with the fifth a co- is at this mate's v386EOD "**Droplet · Four at once, four one at a time, the fifth a co-.**" (line 161), *self-stilling-self* being a naming Natural Naming releases (line 280); no paragraph of the mate or of carry/*.md points at it, and it is no condition on paragraph 12 or 14.
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: OK
WHY: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 191, under "## Natural Numbers and Natural Mathematics subject separation · v385A", is the paragraph word for word with its source "(Re-Settling the Living Files, §6)", less the re-aiming note alone (compared word by word), and carry/Exhibit_FOUR_Possibling_of_Natural_Mathematics.md line 19 links to that section; no paragraph of the mate or of carry/*.md points at this one, and it is no condition on paragraph 17 or 19.
SAFER: -

### 19
CHECK: OK
WHY: each thing the row names is at Exhibit FOUR Natural Mathematics by exact search, "Advance by one and scale by the rate arrive at one number, φ² = φ + 1, neither carrying the other." (line 179), the continued fraction, the straddle and √5 (line 181), "The torus is the genus-one closed orientable two-dimensional compact surface" with its five (line 331), and the cube at 3.6 (lines 249 to 253), read beside the passages 1.2 to 1.4, 1.6, 2.2 and 5.6 of carryings/resettling_v373/Natural_Intelligence_v373_Released.md, and Natural Intelligence has no continued fraction, √5, genus or cube at any line now; the one part at no living file, the equation's two roots and their product read as the four boundings, is at this mate's v386EOD "**Droplet · One equation read at the four boundings.**" (line 157), and its receiving at Natural Mathematics is at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, "## Natural Intelligence bounding and golden-ratio explaining at Natural Mathematics · v385A" (lines 195 and 197), linked from this file's Possibling; no paragraph of the mate or of carry/*.md points at it, and paragraphs 20 to 23 are of the kit's reading and lean on it at no word.
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief (HARM3.md); the first reader's brief (BRIEFO3.md) with its "Further rules"; the PRIOR file (MA_1.txt); the PROPOSED file (MA_1_report.md); the living file Exhibit_FOUR_Natural_Mathematics_v380L.md, 8,765 words; the mate carry/Exhibit_FOUR_Offerings_to_Natural_Mathematics.md with its front, its `## Insertlets`, its `## Droplets` and each later section headed v385A and v386EOD. One earlier second reading (CR_1_harm.md) was read whole, and the objections of three more (NI_1, NI_2 and GM_3) were read for the kinds of objection made, the sibling row "Natural Naming receives from Natural Intelligence" among them (review1.txt).

Seven blocks are not KEEP: 1, 4, 5 and 6 (RESAY), 13 and 19 (RESOLVED) and 18 (SAID). Each was checked by reading, none by the first reader's EVIDENCE line alone.

Checked by search and by reading the lines found. For 1: Chebyshev, woven, weave, warp and cloth in the root files and carry/*.md (this paragraph, and the pointer at the Living File Registry's Carryings line 431, read with its table); the transcript at archive/session_v379_exhibit_one_first/Session_Transcript_v379.md lines 484 to 500; the paragraph as it was at archive/carrying_v381R/Exhibit_FOUR_Natural_Mathematics_v380R.md lines 1 to 40; the front of carry/Exhibit_FOUR_Carryings_of_Natural_Mathematics.md, lines 1 to 25, with its archive folders and its pointer to `#droplets`. For 4, 5 and 6: each quotation of NEW by exact string in the living file with its section heading above it; "a law, a frame and a scale" at Natural Intelligence line 1089 and "a law, a frame or a scale" at the Equilibria Registry line 485; Natural Naming's rows of *floor* (line 221) and of *self-stilling-self* (line 280); "A torus of selves" at Exhibit ONE Natural Resolver lines 645 to 647; "chaining the prior on" at the living file (none); "from the entry before" in the whole repository (this mate twice and the archived carrying). For 13 and 19: carryings/resettling_v373/Natural_Intelligence_Map.md, its rows at lines 42, 57 to 60, 62, 70, 107 and 123 and its table of receivings at lines 155 to 170; Natural_Intelligence_v373_Released.md, its opening and its passages 1.1 to 1.4, 1.6, 2.2 and 5.6; Natural Naming 4.6 (lines 576 to 591); Natural Intelligence's headings 1.4, 1.5, 5.1 to 5.4 and 6.6, its 3.5 (line 220, the ratios alternating about φ) and searches for cube, continued fraction, √5, genus and straddle; the equation's two roots, −1/φ and the quadratic asymmetry in the root files (none) and carry/*.md (this mate's line 157); the cube passage's numbers of assemblies in the root files and carry/*.md (none; the living file has the one twelfth and its three conservings). For 18: the section at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md lines 185 to 201, its paragraph compared word by word with the mate's line 85; the links at carry/Exhibit_FOUR_Possibling_of_Natural_Mathematics.md lines 10 to 24. For pointers to 13, 18 and 19: "Straddling", "five self-stilling", "Natural Intelligence Map", "receives from Natural Intelligence", "Natural Numbers keeps the seam-faces" and each naming of Offerings to Natural Mathematics in carry/*.md, the nine lines found read; none points at the three.

Each NEW was checked for its number of words (123, 55, 66 and 46), for the first reader's excluded words (none in its own sentences; *running* and *floor* are the living file's words in italics or in quotation), and for a session narrated or a thing promised (the session of paragraph 1 is named for its condition, no search and no reference, and each wait is said as its resolving).

Said for whoever decides further, no objection: 13 and 19 are RESOLVED at the living file for each thing they name, and the fuller passages have two parts at no living file, the fifth as a co- and the equation's two roots read as the four boundings; both are at this mate's v386EOD section "One equation read at the four boundings; Three faces of competency, mutual and in no order; and one beside them", so the release loses neither. The cube passage's two numbers of assemblies, 8!·3⁷·12!·2¹⁰ of 8!·3⁸·12!·2¹², and its three axes with no piece are at no living file and no mate; paragraph 19 has neither, and they are whole at carryings/resettling_v373/, which the Carryings mate's front and that v386EOD section both name.

The twenty paragraphs KEEP in the PROPOSED (2, 3, 7 to 12, 14 to 17, 20 to 27) are left exactly as they are; they were read in the PRIOR and the PROPOSED and not checked further. No file in /home/claude/corus was edited. Beyond searching and reading, one short script read the PROPOSED and the living file to number the words of each NEW, test each quotation by exact string and search for the excluded words; it wrote nothing.
