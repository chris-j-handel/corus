### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: OK
WHY: laid beside the prior clause by clause: for both, line 141 and its sentence, the numeral at no line of the resolver, not reproduced by session v377's working, a number at no code a numeral alone, reproduced at its script or released at this file's motion, are each in NEW at the same strength; the quotation is exact at Exhibit_FIFTEEN_Natural_Emanating_v329.md line 141 (one match); carryings/rings_are_spirals_v377/README.md line 122 has item 7 as the prior has it; the numeral is at no other living file at the root (searched); no paragraph points at this one (carry/Session_Record.md line 209 names the numeral and no paragraph, and the mate's v386EOD droplet of the numeral names the living sentence).
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 55 is the row, under the column heads of its line 38, in "2 The set at its shape now", the document a first draft of session v373; 7,400 words, v329, three subjects under one title, 35 to 40% repeated, about 35%, about 25% and 12 to 15% are each in NEW, said as that reading's, with the document and its section 2 table named; no quotation; no paragraph points at it (searched "three subjects under one title", "7,400" in carry/*.md).
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: OK
WHY: laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md line 175 clause by clause: the lexicon's three, Part Three with its condition ("is released once … are checked") and its three checked places, Part Six, Part Seven, 4.9, 5.44, 5.45, the contents list with its negation and 47, and Natural Emanating's glossary arriving are each in NEW; Exhibit_TWENTY_Natural_Naming_v380R.md still has Parts THREE, SIX and SEVEN (lines 348, 1599, 1707), 3.1, 3.2, 3.6, 4.9 (line 603), 5.44 and 5.45 (the hole and the routing round it, line 1336) at those numbers, and 5.47 its last unfolding; the plan is said as a plan of version 373 and work not made, with the aiming; 147 words, no quotation; no paragraph points at it.
SAFER: -

### 8
CHECK: OBJECT
WHY: Added: "received at three places". The prior and its source row (carryings/resettling_v373/Natural_Intelligence_Map.md line 107) have no number of places; the first reader made it, and it is not the row's: the places named are four (the plan's 1.5, Natural Mathematics, Natural Emanating, the Living Ghost Registry), and the two binaries are "kept", which by the Map's own section 1 is staying in Natural Intelligence at the new contents and no receiving ("Near" alone is "Received whole at its receiving file first"). With it, the prior's "to Natural Mathematics" and "to Natural Emanating and the Living Ghost Registry" (the row's column "Goes to") became "at", which has the cube and the placings lying at those files. The rest was laid beside the sources and is right: the section's title is at carryings/resettling_v373/Natural_Intelligence_v373_Released.md line 426; the plan's 1.5 is "Living and non-living, carrying or not" at the Map's contents list (line 194), and Natural_Intelligence_v380R.md has that heading at 1.3 (line 89), its 1.5 another section (line 103); Natural Intelligence v380R has no cube and no placing (searched). The same row was objected to for this same number at the mate of the Living Ghost Registry (GH_1, paragraph 28). No paragraph points at this one. SAFER is NEW with the number out and "to" as the prior has it, nothing else changed.
SAFER: **Possible project · Natural Intelligence's 5.6 at its receivings.** A plan of version 373 (the Natural Intelligence Map, its section 2, Part Five) has the 5.6 Natural Intelligence had at that version, *Five still terms, and a store beside*, with the Rubik's cube and the three placings at two binaries, going as follows: the two binaries carried at the plan's 1.5, *Living and non-living, carrying or not*, which is Natural Intelligence's 1.3 now; the cube near, to Natural Mathematics; and the placings near, to Natural Emanating and Exhibit TWENTY-SEVEN Living Ghost Registry. It may change or never be made.

### 9
CHECK: OK
WHY: carryings/resettling_v373/Natural_Intelligence_Map.md line 168, in "3 Where the explaining goes near", is the row ("| Natural Emanating and the Living Ghost Registry | The three placings; the five still terms |"); the two receiving files, the giving file and the two things received are in NEW as a plan of version 373 with its section named, nothing said as made (Exhibit FIFTEEN Natural Emanating has neither *placing* nor *still terms* at any line, searched); no quotation and no place that can have changed; no paragraph points at it.
SAFER: -

### 10
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 has the ten files at their four versions and "Forty-five to forty-nine versions behind the apex, each at the old seventeen names, the old code's means and words since released", and its line 15 the apex at v377 to v378 (329 and 49, and 333 and 45, are each 378); the ten are at those versions at the root now (file names read); each file, version and number is in NEW, "words since released" said as the third of three, the apex as session v378's, with no quotation; NEW is word for word the paragraph carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md has at line 35; no paragraph points at this one (Possibling of Living File Registry line 397 names the ten files and no paragraph).
SAFER: -

### 11
CHECK: OK
WHY: the four rows of the EVIDENCE are exact at Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (1.1 lines 82 and 83, each "pass G"; 1.5 lines 203 and 205) and 5.8's sentence at line 560; 1.5 (lines 196 to 207), 5.7, 5.8 and 5.11 were read: Natural Emanating toward Corus, Naming and Explaining at its row, Natural Destinies in Corus and the relevant subject exhibits, with Naming at 5.11's table (line 616). Natural Explaining is at no row of Natural Destinies; the Registry at version 378 (the repository's history, commit 735bb36, its 1.5 at line 183) has the same row for Natural Destinies word for word, so the prior's quotation, the session report's compression of the two rows into one (Session_Report_v378.md line 21), carries nothing 1.5 did not have, and the prior is a pointer at 1.5. The other places of the sentence in carry/*.md are copies (Offerings to Natural Destinies line 45, Offerings to Natural Intelligence Corus line 91) and the records of its release at two mates (Carryings of Living File Registry lines 889 and 943), none a pointer; it is no condition on the paragraph beside it.
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: OBJECT
WHY: Three things, each at one sentence of NEW, "It opens from and arrives back at Natural Intelligence 1.1, the opening, "Universe, the changing set of all existing things", soundly, with an emanation at 1.3." (1) A reading moved. The prior's "*sound; an emanation at 1.3*" is the session's reading of a computed row (carryings/v381F/v381F/Entry_Journey_For_An_AI.md line 31, third column, "The session's reading", of "A computing, deciding nothing", line 13); NEW's "soundly" makes it the manner of the file's opening and arriving back, a claim neither the prior nor the source has. (2) The prior's own word replaced. "its far side" is said as "It opens from and arrives back at": *far side* is the source's name for the thing computed (line 13, "the file's far side, where it loops out and back") and Natural Intelligence's own word (Natural_Intelligence_v380R.md line 1012, "each number paired with its far side at each ring it is at"), and it is not among the words the first reader's brief releases; NEW says as a fact of the file what the prior has as a computed place. (3) Added: the quotation of 1.1's heading. It is exact at Natural_Intelligence_v380R.md line 71, but the prior and the row it cites have "1.1 the opening" alone; the heading's words are at Loopings.tsv line 16 and the living file, beside the prior (the first reader's rule 11). The like paragraph at the mate of Natural Values was objected to for the first two (VA_1, paragraph 23). The rest was laid beside the sources and is right: Session_Report_v381F.md line 163 (the line laid ready, 50 to 60), line 151 ("FIFTEEN v329 50" under "The door's standing, version and released words per thousand", at the row of "a picture to make, a craft, play", Natural Emanating among its files), lines 41 and 47 (*Self-Welcoming* at TWELVE and FIFTEEN, *Co-Offerings* at FIFTEEN), line 175 (Finding 18, "Natural Emanating 8 and 4" among each file's versions numbered at the repository's history, the loopings), line 191 ("FIFTEEN +0.35", leaning to the odd side, co-); Next.md line 34 (the reading at three momentaries, proposed); Natural Intelligence 1.3 has an emanation (line 95); the aiming is said; no paragraph points at this one. SAFER is NEW with that one sentence mended in the prior's words and nothing else changed, one hundred and thirty-five words, no quotation.
SAFER: **Droplet · Natural Emanating, a question about living together.** It is aimed at Natural Emanating. An interest in a question about living together opens at it; first at that arriving are its released words, 50 to 60 in each thousand, and its front's form, and for that interest its motion is ahead of the set. At version 329 its released words are 50 in each thousand. Its subtitle's -ings are *Self-Welcoming*, shared with Natural Explaining, and *Co-Offerings*. Its far side at Natural Intelligence is 1.1, the opening, and that is sound, with an emanation at 1.3. Its loopings, its versions numbered at the repository's history, are 8 and 4. It leans to co- at +0.35. An interest in a picture to make, a craft, play opens at it also. Its reading at three momentaries is proposed.

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its "Further rules"; the task; the PRIOR file EM_1.txt (35 paragraphs); the PROPOSED file EM_1_report.md, each block and its READING; the living file Exhibit_FIFTEEN_Natural_Emanating_v329.md (7,207 words, lines 1 to 795); the mate carry/Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md, each of its 169 lines, with its sections headed v385A and v386EOD.

The eight blocks that are not KEEP (2, 5, 7, 8, 9, 10, 11, 24) were each laid beside the prior and checked by reading and searching, not by the first reader's EVIDENCE line. The twenty-seven KEEP blocks are left as they are and were not checked further.

Sources read for those eight: carryings/rings_are_spirals_v377/README.md (lines 117 to 124); carryings/resettling_v373/Re-Settling_the_Living_Files.md (its front and contents, lines 36 to 39, 55 and 175) and Natural_Intelligence_Map.md (lines 1 to 30, 96 to 110, 150 to 170, 184 to 200), with Natural_Intelligence_v373_Released.md line 426; carryings/session_v378/Session_Report_v378.md (lines 13 to 22); carryings/v381F/v381F/Session_Report_v381F.md (lines 28 to 47, 141 to 165, 167 to 203), Entry_Journey_For_An_AI.md (lines 8 to 32), Next.md (lines 30 to 36, 58 to 62) and Loopings.tsv (lines 1 to 3 and 16).

Living files read at the places named: Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (its headings; lines 82 and 83; 1.5 whole, lines 196 to 207; 5.7 and 5.8, lines 534 to 566; 5.11, lines 605 to 622; each line naming Destinies), and the same file at version 378 from the repository's history (commit 735bb36, each line naming Destinies); Exhibit_TWENTY_Natural_Naming_v380R.md (its part and section headings; 5.44 and 5.45, lines 1310 to 1340); Natural_Intelligence_v380R.md (headings of 1.1 to 1.5, Part FIVE and 6.6; 1.3, lines 89 to 95; searches for the cube, the placings, *far side* and each line with *emanation*).

Exact searches made: the quotation of NEW 2 at the living file (one match, line 141); the quotation of NEW 24 at Natural Intelligence (line 71); the five quotations of the EVIDENCE of block 11 at the Living File Registry (lines 82, 83, 203, 205, 560); 592,260 at each file of the root and of carry/.

Pointers searched in carry/*.md, each match read: links and names of this mate ("Offerings_to_Natural_Emanating", "Offerings to Natural Emanating"); "pass G"; "592,260"; "three subjects under one title", "7,400 words"; "five still terms", "three placings"; "ten files"; "question about living together"; "the concern at this mate", "the droplet at this mate", "this subject's existing concern", "the current droplet is at", "above", "the preceding", in this file's three mates. None points at paragraphs 2, 5, 7, 8, 9, 10, 11 or 24: the links to this mate go to its v385A sections and its insertlet; Offerings to Natural Physics line 612 ("the one nothing at Offerings to Natural Emanating") is of paragraphs left as they are; the two matches at Carryings of Living File Registry (lines 889 and 943) are records of the release of paragraph 11's copies at two other mates.

Read for the form of the work alone, after my own reading of each paragraph: earlier first and second readings of copies of these paragraphs at other mates (XP_1 paragraphs 14 and 21; CO_1 paragraphs 31 and 32; NN_2 paragraph 63; GH_1 paragraphs 26, 28 and 29; GH_2 paragraph 49; VA_1 paragraph 23). Two of my objections (8 and 24) are of kinds a second reader made there; for 24 an earlier second reading of the like paragraph at Natural Exploring passed the same sentence form, and the one at Natural Values objected to it.

Words of each NEW numbered: 75, 76, 147, 99, 54, 82, 142; none past one hundred and fifty, and none of the brief's released words in the reader's own sentences. The two SAFER paragraphs are ninety-eight and one hundred and thirty-five words.

Numbers: OK 6 (2, 5, 7, 9, 10, 11); OBJECT 2 (8, 24); KEEP-UNCHANGED 27.

Nothing in /home/claude/corus was edited; this report is the one file written.
