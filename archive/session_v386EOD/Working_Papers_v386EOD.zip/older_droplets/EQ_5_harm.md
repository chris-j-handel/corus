### 147
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Carry_Set_v368_README.md lines 203 and 204 (the two rows under "Plans, bothboth: so far and not yet") and line 141 ("Equilibria Definitions' 1,594 folded sections, 758,359 words of journey, and the earlier versions, read into the file sections and dissolving"): 348 of 369, the three files with sections, the housekeeping at the whole set, a section at each of the 31 files, the archive, the separate working, and the folded sections and the earlier versions read into the file sections are each in NEW, dated "at version 368", the remaining part said as remaining and not as done; "its folded sections" is given as Equilibria Definitions' from line 141, and "once its value stands" is "after its value is in place", read as no change of strength; NEW has no quotation.
SAFER: -

### 148
CHECK: OK
WHY: laid beside the prior and carryings/v368_sources/Carry_Set_v368_README.md line 206: the four things at the resolver's names, 1,205 places, 4 files and each at its own file's improving are each in NEW, dated "at version 368"; line 137 of the same file has Equilibria Definitions as the first of the four files (934 places), so the paragraph lies at its own file's mate; the same words are at carry/Exhibit_FIVE_Offerings_to_Natural_Engineering.md line 81; NEW has no quotation.
SAFER: -

### 149
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 150
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 151
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 152
CHECK: OBJECT
WHY: Parts of the prior are at no living file, and one of the EVIDENCE claims is not so. (1) Lost: the four labels at their numbers. The prior has the table of Equilibria Definitions v363 "with inseparating, tunneling, inversioning and abundancing at thirteen to sixteen"; that file at git d246ca5^ has them so (its line 575, "| 13 inseparating; 15 inversioning | 14 tunneling; 16 abundancing |"). The EVIDENCE says the names it supersedes are at Natural Naming 3.3; they are not: Exhibit_TWENTY_Natural_Naming_v380R.md lines 432 to 448 have other things at those numbers, the names gathered 13-social-neutralling, 14-social-crossing, 15-social-corusing and 16-social-torusing, and the code names `bi_co_tunneling` at 12, `bi_co_inversioning` at 14 and `bi_co_inseparating` at 16, with no abundancing at 16. A search of each file at the root and of carry/*.md for the four labels at thirteen to sixteen finds this paragraph alone. (2) Lost: the negation "It opens at v3621's table and not at v345a's two counts or v363's earlier roots". Its source (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 462 to 472) has the two counts as Exhibit ONE v345a's six depth changes and ten naming adjacencies, and those are not gone: Exhibit_TWENTY-SEVEN_Living_Ghost_Registry_v345a.md line 1824 has "The six depth changes, ten naming adjacencies and eight bi-namings keep their objects throughout that explaining", and Exhibit_FIVE_Natural_Engineering_v345a.md lines 1247 and 1483 have them as ONE's. That the naming to conform to opens at the table of seventeen and not at those two is at no living file; the nearest, this file's 3.2 (line 195), is of the ten's earlier seatings at the naming ring alone. (3) "persistent" of the six connectors and "untouched" of the ten positions are at no living file as words, as the first reader's READING says of the second. Confirmed and not objected: each EVIDENCE sentence is exact (this file's lines 182 and 235; Natural Naming line 428; Exhibit ONE Natural Resolver's table "**Seventeen names.**" with the six "between selves" at 2, 6, 9, 10, 14 and 17); the living file has no table of the four labels (read whole); the co and bi spelling of each full name is at Exhibit ONE's table now; no paragraph of carry/*.md points at this one (searched "HH03", "v3621", "conform to", "supersedes the table", "spelling of each full name", "the preceding", "above"), and it is no condition on 151 or 153. The first reader's rule 3 has this as RESAY for that part, or KEEP; a re-saying could name none of the three earlier versions' places at a living file now.
SAFER: KEEP

### 153
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 154
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 155
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 156
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 157
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 158
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 159
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 160
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 161
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 162
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 163
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 164
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 165
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 166
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 167
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 168
CHECK: OK
WHY: laid beside the prior clause by clause: the three books each named, one twelfth, three and never four as Natural Exploring says of each accounting, nothing alone at corner, edge and pair, the ledger, and beside and not beneath are each in NEW; the quotation is exact at Exhibit_FOUR_Natural_Mathematics_v380L.md line 251, under "## 3.6", whose line 253 has the six centres and the three conservings the source's sentence names (Kit_Rings_in_Motion_v366.md line 267), while Natural_Intelligence_v380R.md 6.6 is "## 6.6 One form at each scale, our now" with no cube at any line, and Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 396 says the cube "is at Natural Mathematics 3.6"; the subject given to "the exclusion" is its source's (the same kit's lines 533 and 539; carryings/v368_sources/Living_Improving_Value_v368.md line 961, "What the exclusion is, said plainly", and line 1020, of each equilibria definition) and this file's own.
SAFER: -

### 169
CHECK: OBJECT
WHY: Lost: one named place and its claim, small. The prior names two places for what is had already, "Natural Intelligence 6.6 already carries the cube's three conservings, none of them a total, and Equilibria Definitions v363 its corner and edge parities, so the note dissolves into those two"; NEW has one, Natural Mathematics 3.6, and "Equilibria Definitions v363" and "parities" are in no word of it ("the corners' and the edges' among them"). At this mate that place is this file's own earlier version, and the claim is so: Equilibria Definitions v363 at git d246ca5^, under "#### What Rubik's cubing supplies" (its line 1455), has "total corner twist0 modulo3, total edge flip0 modulo2, and equal corner/edge permutation parity". The living file has no cube and no corner (read whole), so with NEW as proposed the claim is, in this mate, at paragraph 159 alone, an older paragraph. An earlier second reading passed these same words at Offerings to Natural Exploring (XP_1_harm.md, block 20), weighing this very omission as "the place now and not as a loss"; laid beside this prior at this file's own mate it is a named place of the prior not in NEW, and SAFER has it at its version with the rest as proposed. Confirmed and not objected: both quotations of Natural Exploring are exact sentences under "**5.4 The state-three and the flow-three**" (Exhibit_EIGHT_Natural_Exploring_v329.md lines 379 and 381); "none of them a size" is exact at Exhibit_FOUR_Natural_Mathematics_v380L.md line 253, under 3.6, which has "two totals modulo three and modulo two and one parity" beside it (the prior's own "none of them a total" is at Natural Illustrating 4.11, line 396); one twelfth, the twelve parting by three conserved books, three and not four, and the join alone carried on are in NEW; no paragraph points at this one (searched "BB05", "KK03", "conserved books").
SAFER: **Droplet · The cube's three conserved books, a field instance of Natural Exploring 5.4.** Natural Exploring has, at 5.4, "A three carries as a state or as a flow and never both, and the two alternate." and "This is why an accounting returns three and never four." The moves a cube admits reach one twelfth of the ways a cube can be assembled, and the twelve part by three conserved books: the cube's impossibility is an accounting of three and not four, as Natural Exploring says each accounting is. Natural Mathematics 3.6 has the cube's three conservings, "none of them a size", and Equilibria Definitions at version 363 had the cube's corner and edge parities. Carried on from this is the join at Natural Exploring alone: 5.4's three and never four with the cube's three books as a field instance of it.

### 170
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 171
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 172
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 173
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_5.txt and the PROPOSED file EQ_5_report.md; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (542 lines, about 12,300 words).

Read in part: the mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md at its headings and at lines 325 to 413 (this portion, now at lines 345 to 397, with the paragraphs ahead of it and after it); carryings/v368_sources/Carry_Set_v368_README.md lines 130 to 145 and 194 to 210; carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 455 to 475 (HH03); carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md lines 117 to 120, 262 to 270, 517 to 543 and 660 to 675 (1.3, 3.1, BB05, BB06, KK03, KK04); Exhibit_TWENTY_Natural_Naming_v380R.md 3.3 (lines 422 to 456); Exhibit_ONE_Natural_Resolver_v380R.md, the diagram's key and the table "**Seventeen names.**"; Exhibit_FOUR_Natural_Mathematics_v380L.md 3.6 (lines 241 to 255); Exhibit_EIGHT_Natural_Exploring_v329.md 5.4 (lines 377 to 381); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md 4.11 (line 396); the applied re-sayings at carry/Exhibit_FIVE_Offerings_to_Natural_Engineering.md line 81, carry/Exhibit_TWO_Offerings_to_Natural_Networking.md line 143 and carry/Exhibit_EIGHT_Offerings_to_Natural_Exploring.md lines 41 and 43; the earlier second readings EQ_4a_harm.md (whole, for the form), EQ_4b_harm.md (its objections) and XP_1_harm.md (blocks 19 and 20 and its closing), read after my own laying of 168 and 169 beside their priors.

Checked by exact search: each quotation of the NEW paragraphs of 168 and 169 in the living file it names (one hit each); each EVIDENCE sentence of 152 in this living file, Natural Naming and Exhibit ONE Natural Resolver; "cube", "corner", "diagonal", "v363", "v345a" and "3621" in this living file (none); the four older labels at thirteen to sixteen in each file at the root and in carry/*.md (this paragraph alone); "depth changes", "naming adjacenc" and "co-changings" at the root (Natural Engineering v345a, the Living Ghost Registry v345a, Resolving the Hard Problem Registry v375; none at Exhibit ONE Natural Resolver v380R); the deleted Exhibit_TWENTY-EIGHT_Equilibria_Definitions_v363.md, searched in git at d246ca5^ and not read whole (about 825,000 words), for its labels at thirteen to sixteen and for its cube; carry/*.md for pointers to 152 ("HH03", "v3621", "conform to", "supersedes the table", "spelling of each full name", "the preceding", "the concern above", "at this mate of", "current droplet") and to 168 and 169 ("BB05", "KK03", "conserved books", "three books"), none found. Each NEW paragraph and the SAFER paragraph of 169 was laid beside its prior clause by clause, and its length and the first reader's word list were checked by script (59 to 150 words; none of the listed words in the first reader's own sentences or in mine).

Not settled here: the twenty-two blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 147, "once its value stands" said as "after its value is in place" is read as no loss. At 168 and 169, Natural Intelligence 6.6 given as Natural Mathematics 3.6 is read as the place now, the same sentences being at that section; the objection at 169 is to the second place alone. One scratch copy of the deleted v363 file was written outside this folder for searching and removed at once; the later searches read it from git without a copy. No file in /home/claude/corus was edited, and this report is the one file left written.
