### 1
CHECK: OBJECT
WHY: The thing the paragraph concerns is not wholly gone, and the living files do not say what the EVIDENCE has them say. Exhibit_TWENTY_Natural_Naming_v380R.md line 590, at 4.6, has "the five named each at its own, self, other, society, the between and the carry continuing, are a gathering at Resolving Hard Problems." (exact search, one match): the five faces are still named at a living file, the fourth as *the between*, the earlier wording's descendant (archive Resolving_Hard_Problems_v368_Released_Whole_v375.md line 423, "self, other, society, the opportunity space between, and the carry continuing"). The EVIDENCE did not find this sentence. It rests the release on Natural Intelligence 3.2's fourth dimension, "4. **Bi-momentarying now**" (line 185, found exact), but the same line 590 of Natural Naming parts the two as "two concepts at two names": *a side's five* (the five dimensions) and the five named each at its own. The five dimensions are therefore no wording of the fourth face, and the first reader's own READING note says no living sentence makes them one. What would be lost: the choice still unmade between the fourth as the living sentence has it and the carry's *existing things unrelated* (carryings/v368_sources/Living_Improving_Value_v368.md lines 59 to 66, "existing things unrelated, the tunneling inside the bi-folding"), a wording at no living file (Grep of "existing things unrelated", "things unrelated" at each root file: none). A second open thing sits at the same living sentence: it names its gathering at Resolving Hard Problems, and Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md has no such sentence (Grep "self, other, society", "five named", "carry continuing": none). The sibling concerns of the same five, carry/Offerings_to_Natural_Intelligence.md lines 157 and 163 (the fifth, *the carry living*) and carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 187 (*the two fives under one word*), are kept company by this paragraph; none points at it by words.
SAFER: KEEP

### 2
CHECK: OBJECT
WHY: Laid beside the prior, the four things, their numbers (five centres, two axes, two one-ways at each side, twenty-three, twenty-four and twenty-five), the named places in the figure and the open strength are all in NEW, and the source (carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md lines 202 to 205, 2.2's first four items) says no more than NEW has; *parity* for *sign* and *couple with* for *meet* are Natural Naming 2.4's own rows (lines 255 and 258); NEW has no quotation, no session, no promise. One thing is lost: the prior's named place, "(Kit_Rings_in_Motion_v366.md, 2.2 What still reaches)". NEW names neither the kit nor its version nor its 2.2, and with that "the image", "the rings", "the figure" and "the commutator" have no owner in the paragraph: each is the rings kit's (its image A and image B, its measured rings, its ring figure, the cube's commutator at its BB03 and CC04). And NEW's "Each of these is open" says as the set's own present state what the prior says as that kit's list at version 366. Also "the same way" is thinned to "the way". The pointer at carry/Exhibit_TWENTY-NINE_Possibling_of_Natural_Illustrating.md line 13 ("further diamond, axis and numbering comparisons") still finds NEW; the sibling of the same opening words, carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md line 385 ("What still reaches at the moving form: the sin and cos traces …"), has the other items of 2.2 and no pointer here. The living file has none of the four (Grep "five-diamond", "four-connector", "commutator", "twenty-three": none; 2.8 and 2.9 read, lines 240 to 262), and no kit under kits/ has the formation as numbers (the one match is the inherited Kit_Rings_in_Motion_v365), so the four are open as said.
SAFER: **Droplet · Open at the moving form.** The Rings in Motion kit at version 366 has each of these open at the moving form, at its 2.2: the right-side five-diamond formation read from the image the same way the rings were, and with that its five centres and two axes as numbers; the four-connector square across the empty along centre, with its two one-ways at each side, found in the figure; which station of the figure is twenty-three, twenty-four and twenty-five in the five-diamond formation's own numbering; and how the commutator's odd and even powers, place changing and facing changing, couple with the parity changing at the connectors.

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file; the PROPOSED file; the mate carry/Exhibit_TWENTY-NINE_Offerings_to_Natural_Illustrating.md, each of its 143 lines; the possibling mate carry/Exhibit_TWENTY-NINE_Possibling_of_Natural_Illustrating.md, each of its 79 lines. The living file Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md is 17,794 words, over fifteen thousand, and was read at the sections the two changed paragraphs concern: 2.8 and 2.9, lines 240 to 262; paragraph 1 names no section of it. Read at the sources: carryings/v368_sources/Carry_Set_v368_README.md lines 40 to 80 (the paragraph 1 source at "### 2 · The namings arriving with the illustrating work"); carryings/v368_sources/Living_Improving_Value_v368.md lines 36 to 70 (the table "Its face at the five" and the sentence after it); carryings/v368_sources/Findings_To_Lay_By_File/Kit_Rings_in_Motion_v366.md, its headings whole and lines 178 to 222 (2.1, 2.2 and 2.3 whole); Exhibit_TWENTY_Natural_Naming_v380R.md lines 584 to 592 (4.6) and rows 235, 255, 258 and 314 of 2.4 and 2.5; carry/Offerings_to_Natural_Intelligence.md lines 155 to 165.

Checked by search: "opportunity space", "existing things unrelated", "things unrelated", "five faces", "own faces", "carry living", "carry continuing", "face at the five", "fourth face", "five named", "named each at its own", "self, other, society" at each living file at the root and at carry/*.md; "opportunity space between" at archive/carrying_v375_resolving_hard_problems/; the first reader's quoted sentence of Natural Intelligence 3.2 by exact search (line 185); "five-diamond", "four-connector", "commutator", "twenty-three", "one-way" at the living file, at each root file and at carry/*.md; "five-diamond" under kits/; "what still reaches", "moving form", "namings arriving" at carry/*.md for pointers to paragraphs 1 and 2.

Paragraphs 3 to 8 are KEEP at the PROPOSED and were not checked further; nothing of them changes. The first reader's two notes at paragraph 5 (one hundred thirteen for one hundred ten, and the quotation of Natural Naming at no line) change nothing, the paragraph being left in its own words.

Paragraph 1: the objection rests on one sentence the first reader did not find, Natural Naming 4.6 at line 590. A reader holding *the between* at that sentence as the wording decided could release the paragraph by that sentence; the carry's *existing things unrelated* and the gathering named at Resolving Hard Problems, at no line of it now, are then at no file, and KEEP is the verdict that loses nothing.

Paragraph 2: the objection is to the lost named place alone; the SAFER paragraph is the first reader's NEW with the kit, its version and its 2.2 named and "the same way" restored, one hundred and seven words with its title, and none of the words the first reader's brief rules out is in it (checked by search).
