### 37
CHECK: OK
WHY: Laid beside the prior, each claim and the one negation are in NEW; Exhibit TWENTY-SIX Living File Registry has *paused* at four places and *pass G* at eight by search, and "released-word load" is at no living file and at no later section of the mate.
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: OK
WHY: Laid beside the prior clause by clause, the three momentaries, `carry/<file>.md`, "those three and no more" and the last sentence are each in NEW, with "meet" said as coupling and nothing added; the later sections of the mate (lines 383 to 630, read whole) have no reading form of a file.
SAFER: -

### 40
CHECK: OK
WHY: Laid beside the prior, the three spans 3 to 11, 10 to 14 and 9 into the next 2, the three kinds of evidence, "binary at each sharing" and "improved and never replaced" are each in NEW; the mate's "A droplet's aiming at one of six degrees · v386EOD" has the evidence alone and no journey.
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 42
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 43
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: OBJECT
WHY: Lost, three things. (1) The named place "3.3": the prior has "The Registry 3.3", NEW has the file with no section; the two sentences are at line 298 under "## 3.3 Substrate, scale and explaining face" of Exhibit TWENTY-SIX Living File Registry, both exact. (2) The relation "says it already": NEW has "has", and the prior says the Registry says the finding already. (3) The aiming "Aimed at the set": the paragraph is in the Geodesic Improving Method's mate and without those words reads as aimed at that file. The five numbers, the 136, the script and the last sentence are in NEW as the prior has them, and nothing is added.
SAFER: **Droplet · The exhibit numbers do not podal, and the subjects do.** The exhibit numbers do not podal, and the subjects do. By `forms_at_the_files.py`, the word-likeness of each pair of the seventeen exhibits ONE to SEVENTEEN, weighted at the words few files carry, is 0.082 at all 136 pairs; 0.086 at the eight pairs 17 less, 1 with 16 to 8 with 9; 0.040 at the four pairs 9 less; 0.061 at the eight pairs 8 up; and 0.122 at the sixteen pairs of n with n+1. Exhibit TWENTY-SIX Living File Registry's 3.3 says it already: "The number belongs with the thing counted." and "A prime assignment, the order of a symmetry, a momentary cycle and an exhibit number each name their own relation." The files pair at their subjects, the across, and a podaling at the exhibit numbers is a shared numeral alone. It is aimed at the set.

### 46
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 47
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 48
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 49
CHECK: OBJECT
WHY: A work and a relation are in it, at no living file and no later section. (1) "Next: improving relative to Exhibit ONE, from its section" names a work for this file; by search "relative to Exhibit ONE" is at this paragraph alone among the living files and this mate, the mate's own "Next at this file" (line 21) names another next, and the work is open at this file still (paragraphs 53, 54 and 55 are three places of it). (2) "the Method Improving Value findings aim here with Natural Explaining" is a relation of aiming that paragraph 50's last sentence leans on ("with the Method Improving Value findings already aimed there"), and the NEW of 50 drops that sentence, so with 49 released it is at no place in carry/. The version and the number of findings are bookkeeping, as the first reader says; the row is at carryings/v368_sources/Carry_Set_v368_README.md line 182, the same label at each row of that table. No paragraph points at it.
SAFER: KEEP

### 50
CHECK: OK
WHY: Each living sentence the EVIDENCE names is found by exact search (2.2 line 142, 2.8 lines 198 and 204, 4.1 line 290, 1.5 line 106), and the parts at no living file (the naming by file and value, one method at two wordings, the comparing with understandings retained, local and upstream) are each in NEW; one word differs, the prior's "next drawing relation" against the living "next relation", the wider saying.
SAFER: -

### 51
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 52
CHECK: OBJECT
WHY: Lost: the named place "2.8". The prior aims at "the Geodesic Improving Method 2.8" and says "2.8 says"; NEW has the file with no section. All else was confirmed: the quotation is exact at 2.8 (line 202); *met* 52, *carried* 45, *taken* 24 and *placed* 10 are found by a whole-word search with capitals included (22 and 8 without them); "is its standing" and "Arriving, Improving, Living" are at no line of carry/Living_Improving_Value.md, so the front's two sentences and its 52 forms concern a text gone, and the three steps are at the living file's 1.4. The 268 is the prior's own and was not numbered again.
SAFER: **Possible project · An arrival's *standings* at their -ing.** Exhibit TWENTY-FOUR Geodesic Improving Method's 2.8 has an arrival's "standing said at each event: offered on a branch, arrived at `main`, received at the carrying as ready or concern, entered at a file, or released". The work is the *standings* at their -ing: a droplet offering on a branch, arriving at `main`, rising at a file's offerings, entering at the file's motion, or chaining at none, the file's prior carrying on. A reader of the carrying then sees each thing's place in its motion and not what was done to it, and the *standings* say the three steps, arriving, improving, living, at the steps' own form; that file has 268 forms at the -ed, *met* 52, a released word besides, *carried* 45, *taken* 24, *placed* 10, each at its -ing at the file's motion. It may change or never be made.

### 53
CHECK: OBJECT
WHY: Lost: the named place "2.6". The prior aims at "the Geodesic Improving Method 2.6"; NEW has the file with no section (the sentence is in the second paragraph of 2.6, line 178). All else was confirmed: the four quotations are exact (Exhibit ONE Natural Resolver line 322, row 10 of *Prior and next*; Natural Naming line 414), and "sharing is across at each even name, 10 among them" and the offered *shared across* are in NEW.
SAFER: **Concern · Released across at 10.** Two sayings part. Exhibit TWENTY-FOUR Geodesic Improving Method's 2.6 has "At 10 the resolving is released across to each file it touches". Exhibit ONE Natural Resolver has "the changing shared across now, the other's offering next, the possible" at 10. They part at the word for the across at 10: sharing is across at each even name, 10 among them, Natural Naming having "shared across at 6 and 10, released along at 9" and "Each even name is across and each odd name along". *Shared across* is offered at the first saying.

### 54
CHECK: OK
WHY: Both quotations are exact (the living file's 5.3, line 391; Natural Intelligence line 1057 under "## 5.1 A prior between momentaries", the same words at Natural Naming lines 289 and 1381), the two named places 5.1 and 5.48 are in NEW, and the offered words are as the prior has them; the prior's "5.x" names no one section.
SAFER: -

### 55
CHECK: OK
WHY: *the code* is at twelve places of the living file by search, three in the first paragraph of 2.6 and two in the second; the four quotations are exact (lines 176 and 178; Exhibit TWENTY-SIX Living File Registry's rows of Natural Intelligence and Natural Naming), forty-six and forty-five are in NEW, and the three offered wordings are as the prior has them.
SAFER: -

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 58
CHECK: OK
WHY: The whole paragraph up to its note of re-aiming, with its source note and tag, is at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 223 under "## Natural Exploring and Geodesic Improving Method proposed combination · v385A" by exact search; no paragraph in carry/ or incoming/ points at this one.
SAFER: -

### 59
CHECK: OBJECT
WHY: Three named places are changed and one pointer is at its subject. (1) "the AI link part" is said as "the opening an arriving AI reads"; README.md still has the heading "## AI link to Living Natural Intelligence" (links alone under it), and NEW's words name no place a search finds. (2) The bold lead "A joining asks a deriving" is said as "a joining asking a deriving"; the lead is at carryings/v381F/AI_Link_Opening_Offered.md line 27 and archive/session_v385A/repository_instructions/README.md line 17, and an exact search for it no longer finds the paragraph. (3) `incoming/v381F/spiral_check.py` is replaced by `carryings/v381F/`, a place the prior does not name: it is right now (the script is at carryings/v381F/spiral_check.py and incoming/v381F/ is gone), and it is an adding. (4) incoming/v385A/Arriving_Content_Account_v385A.md, "The whole opening proposal beside exact repeated paragraphs", names "the proposed joining/check relation" of that opening as located by "the method's 2.9/helping and check offerings"; that account is linked from this mate's "The earlier entry's kit and Naming comparison · v385A". The prior is plain already, with no waiting language.
SAFER: KEEP

### 60
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 61
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 62
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 63
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 64
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 65
CHECK: OBJECT
WHY: Changed and narrated. (1) A person's own words: the prior has "From the self: *why are we trying to make numbers hold.*", an asking against the trying; NEW has "It is from the other self's asking, the reason for trying to make numbers *hold*", which reads two ways, the second being the asking as the reason for the trying, the reverse of the prior. *hold* is in italics as a living file's word; the living file has "both hold" at 5.3 of another thing, and here the word is the person's. (2) NEW narrates a session: "At one working eight executings found one changing, the seven 0s reported as work before the other self said it"; the prior's "until the self said so" becomes "before the other self said it" with the thing said named at no word. The first reader left paragraphs 63 and 64 as they are for this same reason, an instance being a session's doing with a number in it. The quotation "No proof of the whole is sought" is exact (2.7, line 188), and the places 2.7, 4.1 and Natural Arriving 8.2 are in NEW.
SAFER: KEEP

### 66
CHECK: OBJECT
WHY: Nothing was found lost, added or misquoted: each of the four things said at a breath, the session's number, "no question is posed as binary", the three things named and both aimed places are in NEW. NEW narrates a session: "at one working the other self named Natural Explaining, the claims of Exhibit THIRTY Co-Chaining Logic Registry and the -ed, and at each naming the order changed for the better". The first reader's rule for NEW has no narrating of a session, and the first reader left paragraph 63 as it is for the same thing; with the sentence out, the prior's instance is lost.
SAFER: KEEP

### 67
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 68
CHECK: OK
WHY: The last paragraph of the living file's 4.5 is still "**This is naturally intelligent exploring**: the helpers assist the gathering, ..." (line 354), the quotation is exact, and each clause of the offered sentence and of its reason is in NEW; "measure of a session" is at no later section of the mate.
SAFER: -

### 69
CHECK: OBJECT
WHY: Nothing was found lost, added or misquoted: the quotation is exact (4.5, line 340), and "said and not aimed", the two readers and "at 4.5" are in NEW. NEW narrates a session: "one session's reading found eleven such sayings, most of them the other self's words". The first reader's rule for NEW has no narrating of a session, and the first reader left paragraph 63 as it is for the same thing, a session's doing with a number in it; with the sentence out, the instance the prior says the file's sentence gains is lost.
SAFER: KEEP

### 70
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 71
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 72
CHECK: OBJECT
WHY: Lost: the aiming "Aimed at the set"; the paragraph is in the Geodesic Improving Method's mate and without those words reads as aimed at that file. Added and right: "Natural Intelligence's" before 6.5; the quoted words are at Natural Intelligence line 1140, under "## 6.5 Non-living existing things included", read whole. The session narrating of the prior (which working laid the concern, its fetch cut) is left out by the first reader's rule, and the two sayings and their not parting are in NEW.
SAFER: **Droplet · A session carries nothing session to session, and its number is the expedition's.** A session reads the Session Record and opens at a number one on, and that can be read as a prior carried. Natural Intelligence's 6.5 read whole has the session reading within its own momentary and carrying none of it to the next session; the things carrying are the living files and the carrying, "the carrying theirs, the AI carried"; and the number is handed at the opening, as 17 hands each self its momentary. The two sayings do not part. It is aimed at the set.

## READING
Read whole: the brief for this reading; the first reader's brief with its further rules; the PRIOR file, thirty-six paragraphs, 37 to 72; the PROPOSED file, each block and its closing section; the living file Exhibit TWENTY-FOUR Geodesic Improving Method v380R, from its first line to its last (9,809 words); of the mate, Offerings to Geodesic Improving Method, its front and its Insertlets (lines 1 to 98) and each later section headed v385A and v386EOD (lines 383 to 630). Of the mate's older Droplets section, the thirty-six paragraphs of the input were found in the mate by exact search of each whole paragraph, and the paragraphs at lines 105 to 111 were read for the earlier copy of 72.

Checked by search and by reading the passage found: each sentence in quotation marks in a NEW paragraph, by exact search over the living files at the root (each found in the file NEW names); Exhibit TWENTY-SIX Living File Registry (*paused*, *pass G*, the two sentences at 3.3, the rows of Natural Intelligence and Natural Naming); Exhibit ONE Natural Resolver (row 10 of *Prior and next*; no line with "the code"); Natural Naming (line 414, and the sentence of 5.48 at lines 289 and 1381); Natural Intelligence (5.1; 6.5 read whole); Natural Arriving (its contents, 8.2); the number of "the code" in the living file (twelve) and of *met*, *carried*, *taken* and *placed*; carry/Living_Improving_Value.md (its front, for the sentences paragraph 52 names); carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md lines 215 to 230 (paragraph 58, by exact search of the whole paragraph) and its headings; Possibling of Geodesic Improving Method (its section on the combining); Offerings to Natural Exploring line 13; README.md (its opening); carryings/v381F/ (the script and AI_Link_Opening_Offered.md at "A joining asks a deriving"); carryings/v368_sources/Carry_Set_v368_README.md (the table of the file set) and Findings_To_Lay_By_File/Kit_Natural_Illustrating_v366.md (TTT14); incoming/v385A/Arriving_Content_Account_v385A.md (both tables of earlier findings and the section on the opening proposal) and Registry_Plan_Comparison_v385A.md at the combined title.

Pointers: carry/*.md and incoming/ were searched for the subject words of each paragraph with a verdict other than KEEP. One was found, at paragraph 59's subject, in incoming/v385A/Arriving_Content_Account_v385A.md. None was found at 49 or 58. Offerings to Natural Exploring line 13 (v385A) has "No source file or droplet is released merely because this combined destination is planned"; paragraph 58 leaves for another reason, its whole text at a later section, and is OK by that.

The mended NEW paragraphs at 45, 52, 53 and 72 are the first reader's own with the words named in WHY put in and nothing else changed; each is under one hundred and fifty words and has no word of the first reader's list in its own sentences.

Not checked or not confirmed: the 268 of paragraph 52 was not numbered again; the sources of 37, 39 and 40 were not opened, each NEW being laid beside its prior alone; the section numbers of Natural Naming's sentence at line 414 were not read. The paragraphs with the verdict KEEP were not checked, as the brief has it. At paragraphs 66 and 69 the one objection is NEW narrating a session with nothing lost; the one laying the changes may read those two as the lightest. No file of /home/claude/corus was edited.
