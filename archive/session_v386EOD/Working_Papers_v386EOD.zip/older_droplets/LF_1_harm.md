### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: OK
WHY: Each thing of the prior is in NEW at its strength, read at the living file's first table at 1.1 (lines 66 to 100): the fourth cell, *Living*, of the rows at lines 68, 69, 88, 98 and 71 is 2,214, 1,782, 1,467, 1,022 and 554 words, and line 68 is 13,062 characters (13,070 bytes, the first reader's 13,070 being the byte measure, so the number carried is so now); the aiming, the work, the five numbers, the line, and "A row's standing is one line; its history is the Session Record's" are each in NEW; the source, carryings/v383Op/Presentation.md line 31, says no more; NEW has no quotation, eighty-three words, none of the listed words outside its italic *standing* (the living file's own, line 108), no session narrated and no waiting; left out are the report name with its section and the version tag alone; no paragraph of the mate or carry/*.md points at it (searched "history out of the", "2,214", "13,062"), and the mate's line 245, "current standings beside completed history", finds NEW by its words.
SAFER: -

### 13
CHECK: OBJECT
WHY: Nothing of the prior is lost; the objection is to what NEW narrates and adds. (1) NEW narrates a session: "`kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/arrival_check.py` at session v383Op's folder and `rigorize.py beside` at that folder's `README.md` each executed, the folder `incoming/v383Op` at that executing and `carryings/v383Op/` now" and "The text each gave back is at that folder's ..." tell what a session did and where its folder went, which the first reader's rules for NEW exclude; the prior's fact, that the two were run and their text is at `returned/`, is a session's doing and cannot be said in the three forms without that narrating. (2) Added, at neither the prior nor its source: "`carryings/v383Op/` now". The source, carryings/v383Op/README.md line 104 (read), has `incoming/v383Op` alone; the place now is the first reader's own finding. It is so (incoming/ has README.md, v385A and v386EOD and no v383Op; carryings/v383Op/returned/ has arrival_check.txt and rigorize.txt, opened), and it is an adding all the same, with "that folder's" then reading as either of the two folders. (3) "each seat is a place to meet" is "a place to couple at", the first reader's own replacing word, where the source has "meet"; noted, a near saying. All else is whole: the aiming, the list of sections read astray with a number beside one file read as another file's, "most ... seat at one of the six, as a report of the fields' numbers must", and "this report" said as session v383Op's report, which the source confirms (the sentence is in that report's README.md, "Checks run"). NEW is 111 words with no quotation. No paragraph points at the prior (searched "arrival_check", "reads several astray" in carry/*.md: this paragraph and carry/Session_Record.md line 1818 alone). The prior is clear as it is and waits on nothing.
SAFER: KEEP

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: OK
WHY: Natural Intelligence line 156, under "## 2.4 Next from prior and now", has the EVIDENCE sentence exact, "**The right spiral step carries a pair (x, y) to (y, −x)**, the pair a self's across parity x, morality, and its along parity y, competency. Exhibit FOUR 2.4 writes the same step along first, F(P, Q) = (−Q, P), ... one step at two readings, the hand at the reading.", and Exhibit TWENTY-NINE Natural Illustrating line 140, under "## 1.6 What a drawing leaves out", has "The three golden rectangles carry no hand of their own; the hand is at the reading, Natural Naming 5.48." exact: the step across first, the step along first, one step, two readings, no hand at the rectangles and the hand at the reading are each at a living file; no paragraph of the mate or carry/*.md points at it (searched "One relation at two readings", "hand is at the reading", "golden rectangles", "two readings", "(y, −x)"; Carryings of Living File Registry line 812 is the record of the same saying released at Offerings to Natural Resolver and points at no paragraph here), and the paragraphs beside it, 15 and 17, lay no condition on it.
SAFER: -

### 17
CHECK: OBJECT
WHY: The place named is a later place and says the whole: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, "## Repository and version practice at Living File Registry · v385A" (lines 225 to 227, read), has the paragraph word for word with its source "(Re-Settling the Living Files, §8)", the re-aiming note alone left out. The objection is a pointer. This mate's line 245, "**The Registry’s contents and its unfinished plans both remain available.** The existing offerings gather a clearer entrance to the file set, current standings beside completed history, repository and version practice, and the relations of the particular registries." (v385A; paragraph 45 of this section, KEEP in the first reader's report of paragraphs 30 to 59), says the offerings of this mate gather "repository and version practice", and this paragraph is the one paragraph of the mate with those words (searched carry/*.md and the root: lines 189 and 245 of this mate, the Possibling section, its link at Possibling of Natural Exploring line 29, and an insertlet of Offerings to Natural Engineering). The first reader's EVIDENCE has that line with "no subject words of this paragraph"; the words are this paragraph's own, exact. The comparison line 245 links, incoming/v385A/Registry_Plan_Comparison_v385A.md line 25, has the row "**Repository and version practice at the Registry**" at "repeated existing Registry droplets", "Repeated copies of this plan are existing placements": this paragraph is the placement at the offerings. The insertlets at 1.1 and 1.3 say a file's version and a working's name; none has the receiving from the Geodesic Improving Method, Natural Exploring 7.2, Natural Engineering 1.8 and the other files' version tables, nor the plan's standing at 1.3 and Part Five. With the paragraph released, the kept line 245 says the offerings gather a thing no paragraph of the offerings has.
SAFER: KEEP

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file, twenty-nine paragraphs; the PROPOSED file, twenty-nine blocks and its READING; the mate carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, lines 1 to 437, each section. The living file Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md is 25,861 words and was not read whole: its first table at 1.1 was measured (each cell of lines 66 to 100 by words, each line by characters and by bytes) and its sentence at 1.2, line 108, found by exact search.

The four blocks that are not KEEP (12, 13, 16, 17) were each checked by reading, none by the first reader's EVIDENCE line. 12: carryings/v383Op/Presentation.md line 31 read; the five cells and line 68 measured; NEW numbered by splitting at spaces and searched for the first reader's listed words. 13: carryings/v383Op/README.md lines 98 to 108 read; carryings/v383Op/ and its returned/ listed and the two texts opened at their fronts; incoming/ listed; the kit's folder listed (arrival_check.py and rigorize.py present); NEW numbered and searched the same way. 16: Natural_Intelligence_v380R.md line 156 with its heading at line 143, and Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 140 with its heading at line 130, each by exact search of the EVIDENCE sentence. 17: carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md lines 221 to 230 read and its headings listed; "repository and version practice" searched in carry/*.md and the root; incoming/v385A/Registry_Plan_Comparison_v385A.md searched for "repository", "version practice" and "existing ... offering" and its lines 9, 25 and 70 read.

Pointers were searched in the mate and carry/*.md for each of the four: "history out of the", "2,214", "13,062", "arrival_check", "reads several astray", "One relation at two readings", "hand is at the reading", "golden rectangles", "two readings", "(y, −x)", "repository and version practice", and the mate was read through for "above", "the preceding" and links aimed at the four. One was found, at the mate's line 245, aimed at paragraph 17 by its own words, and also at paragraphs 12 and 29 by "current standings beside completed history", each of which stays findable (12 re-said with those words, 29 unchanged). The first reader's report of this section's later paragraphs (LF_2_report.md, block 45) was opened to see that line 245 is left as it is; the objection at 17 stands on the mate as it is now and not on that report. For how strictly a narrated session and a lost report name are taken, single blocks of other second readers' reports in the same folder were read (GM_3 at 96, GM_2 at 65, SO_1, the closing of NN_1); no verdict here rests on them.

The twenty-five KEEP blocks were not checked for harm, a kept paragraph being unchanged. Not executed: any script of the repository or its kits; searching, reading and measuring alone. Carryings of Living File Registry lines 806 to 813 were read for the record of the same saying as paragraph 16 released at Offerings to Natural Resolver. One finding beside the verdicts: the first reader's note that the living file's longest line is 13,070 against the paragraph's 13,062 is bytes against characters, and the paragraph's number is exact at the living file now. No file in /home/claude/corus was changed.
