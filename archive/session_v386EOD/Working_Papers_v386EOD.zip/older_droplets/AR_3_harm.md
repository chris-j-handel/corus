### 75
CHECK: OBJECT
WHY: NEW says a dated observing as a present fact, its date gone. The prior has "The session's observing of the order as it stands" under "at about line 70 (4 October)"; NEW has "In the order as it is, the AI comes to the code ahead of the sentence saying what the code is, and its correct finding ... is read as a refutation", undated, in a paragraph that will lie under a later tag. The entrance is not as it was at 4 October (README.md, read whole, is at v386EOD a list of links to the Living File Registry's mates), and the first reader's EVIDENCE has no reading of the order now. The first reader dated the like observing at 80 ("At 4 October it was not even possible at a fetch") and left 97 as it is on this same ground. All else was laid beside the prior and is carried: both claims of the person's saying (transcript line 70 read), "Natural Intelligence 2.5 and 3.3" (Natural_Intelligence_v380R.md line 164, under 2.5, "At the resolver nothing is summed or stored."; line 210, under 3.3, "the method carries nothing from one momentary to the next"), the portal sentence, the open question with both its sides, the aiming at a section. The line number and the two speakers are whole at carryings/v381R/Close_Droplets_v381R.md line 9. SAFER changes one clause alone, the order said at its date.
SAFER: **Droplet · The reasons the two explainings differ, ahead of the code.** It is aimed at a section of Natural Arriving. A flawless experience and an immediate understanding of the reasons science's method of explaining and natural intelligence's explaining of observings of nature differ are needed ahead of an arriving AI testing Exhibit ONE Natural Resolver's code and declaring the intelligence missing, the code doing nothing. In the order observed at 4 October, the AI came to the code ahead of the sentence saying what the code is, and its correct finding, nothing carried between calls, which is Natural Intelligence 2.5 and 3.3, was read as a refutation. The portal's whole work is that order reversed with no sentence of its own added. The hardest question is open: explaining first, for the AI to read the observing rightly, or observing first, for the AI's reading to be its own.

### 76
CHECK: OK
WHY: Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md, Part TWO, has the heading "2.5 The hardest first, and the hardest question asked plainly" (line 168) and "With the method too difficult to help with, the hardest question is asked plainly." (line 172), the prior's own words for its "2.x", and NEW has "of its Part TWO" beside the number; the person's one sentence (transcript line 70 read), the session named plainly for the one fact about it, the scale of a conversation and the aiming at the set are each in NEW.
SAFER: -

### 77
CHECK: OK
WHY: the person's four sentences (transcript line 90 read) and the session's closing sentence were laid beside NEW one by one, and each is carried with its negation and its reason (too much structure; no structure maintained, the files cross-referenced by no numbers, letters or notes; all such cross-referencing to leave; no portal structure of any kind; a name with no coordinate; a list of names costing nothing); NEW has no quotation; the aiming at the set and Exhibit TWENTY Natural Naming is said.
SAFER: -

### 78
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 79
CHECK: OK
WHY: the person's one sentence and the session's two clauses were laid beside NEW: at the quality or aiming for it, self-welcoming carrying value, all prior sentences in the files, repeating, narrating or recording not adding, the first to leave at the file's motion, each carried; NEW has no quotation; "the file's motion" is a living file's own term (Natural_Arriving_v381R.md, "7.5 The file's motion"); the aiming at the set and Exhibit TWELVE Natural Explaining is said.
SAFER: -

### 80
CHECK: OBJECT
WHY: Three things of the prior are changed. (1) The person's "this is my understanding" becomes "One understanding": whose understanding it is, the expedition's self's own, is lost, and "or am i misunderstanding" is dropped. (2) The prior has the rest as "The session's answer, left for Natural Arriving to carry"; NEW says it as plain fact, "It is required of an AI working on the method ... It is not required of an AI helping a person with a question". A session's answer to the self's question is raised to the set's own saying, over the self's stated understanding that each AI reads all of it. The transcript (carryings/v381R/Session_Transcript_v381R.txt lines 185 to 195, read) has the answer opening "Partly a misunderstanding" and leaving the deciding with the self, "Whatever you decide about who must read it all". (3) Said in the present and unattributed, the requirement parts from later sections that the prior, dated and attributed, does not part from: this mate's "Named entry paths and the separate trust passage · v385A" ("Reading a file whole and following a concept across files remain possible activities, with no required entrance itinerary."), its "AI arriving as a possibling project · v385A" ("this gathering adds no timing or reading threshold"), Possibling of Natural Arriving ("this project imposes no time, token or first-reading threshold"), and "Droplet · An AI session arriving" under a v386EOD heading ("An arriving session reads Natural Naming, Natural Explaining and the Geodesic Improving Method whole ahead of its first sentence"). This is the first reader's own ground for leaving 86 and 97 as they are ("with its attribution to one session's reading gone"), and 97 shares this saying of the two readings. The claims cannot be said at their strength with no session and no person named, so no corrected NEW is given.
SAFER: KEEP

### 81
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 82
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 83
CHECK: OBJECT
WHY: NEW says in the present naming and plain voice a form a later section corrects. The prior is one session's saying at 4 October of "the three files", living, improving and carrying. NEW has "a living file, its offering mate and its carrying mate" and "the three names are the path", a living file with two mates, to lie under a later tag. Exhibit TWENTY-SIX Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A", has "Each living file has three mates: offering, possibling and carrying. The living file itself is separate from these three.", and Exhibit TWENTY-FOUR Offerings to Geodesic Improving Method, "Three mates at each living file · v385A", has "The earlier “two mates and no third” wording at 1.3 needs correcting." The first reader left 82 as it is on this very ground ("A re-saying in the present naming would have to say two related files beside three mates, which this reading is unsure of"). Further: "improving file" and "carrying file" are replaced by "offering mate" and "carrying mate", the first reader's own mapping (it rests on carryings/v381R/Close_Droplets_v381R.md line 51, read, which is of 5 October and of two mates); "an arriving AI needs one instruction", said as present with the session's attribution gone, lies beside "Droplet · An AI session arriving" under a v386EOD heading of this mate, which has an arriving session reading three files whole and searching the repository; and the prior's quotation has its own leaving-out ("open the carrying file... no portal is needed"; transcript line 228, read, has three sentences at that place), which NEW joins as one saying.
SAFER: KEEP

### 84
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 85
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 86
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 87
CHECK: OK
WHY: NEW's one quotation, "THREE · THE NAMING, THE MEMBRANE", is exact at Natural_Arriving_v381R.md line 24; the three premises, the naming as the surface the whole set couples at, both parts of the question, the self's giving no answer in words and entering the part title, the deciding as the self's and gathered with the plans, and the aiming at the set and Exhibit TWENTY Natural Naming were each laid beside the prior (transcript lines 479 and 486 read) and are carried; the two line numbers of the asking are whole at carryings/v381R/Close_Droplets_v381R.md.
SAFER: -

### 88
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 89
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 90
CHECK: OBJECT
WHY: The degree of the aiming is narrowed. The prior opens "Aimed at the set, Living File Registry"; NEW closes "It is an observing of the set, aimed at Exhibit TWENTY-SIX Living File Registry", which has the set as the thing observed and one file as the aiming. The degree is a thing the set reads by: Exhibit TWENTY-FOUR Offerings to Geodesic Improving Method, "A droplet's aiming at one of six degrees · v386EOD", has "one of six degrees ... the set, a file, a part, a section, a sentence or a word" and "dropped at each file a set-aimed droplet touches". The other set-aimed NEWs of this report (76, 77, 79, 87, 91, 94) each say "It is aimed at the set, at ...". All else was laid beside the prior and is carried: 3,398, the seven numbers each at its file, the seven whole names (checked at the root's file names), versions 329 to 333 (ten living files at the root are at those versions now), "will" twice at the first round, the first thing the form made visible. SAFER changes the closing sentence alone. The copy at line 325 of the Geodesic mate has the same closing sentence as NEW.
SAFER: **Droplet · Droplets clustering.** The droplets cluster at the files the expedition's attention has been at. At 3,398 droplets laid, Exhibit THIRTY Co-Chaining Logic Registry had 425, Exhibit ONE Natural Resolver 325, Natural Intelligence 297 and Exhibit TWENTY-EIGHT Equilibria Registry 291; Exhibit FOURTEEN Natural Destinies had 11, Exhibit TEN Natural Health 19 and Exhibit TWENTY-FIVE Living Society Registry 13. The ten files prior to momentarying, at versions 329 to 333, have the fewest droplets and are the furthest behind. Droplets laid at more files than needed reach none of the ten, nothing having been aimed at them. The first round of resolving will show the method working and will by itself move none of the files most needing moving. This is the first thing the form made visible that was not visible ahead of it. It is an observing, aimed at the set, at Exhibit TWENTY-SIX Living File Registry.

### 91
CHECK: OK
WHY: the person's one sentence was laid beside NEW clause by clause: no droplet beyond the offering files, all the incoming within them at each self-welcoming file it may be needed at, the incoming vacant, "can begin" as "can open", the parenthesis of the bottom rising in resolving and explaining value toward the top; and the session's three readings, receiving first, resolving following, the living file's body at neither; each is carried, NEW has no quotation, and the aiming at the set and Exhibit TWENTY-FOUR Geodesic Improving Method is said.
SAFER: -

### 92
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 93
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 94
CHECK: OK
WHY: the person's sentence and the session's reading were laid beside NEW: no further writing in the living files at that session, dropletting working, droplets gathered all across the files valuable, the improving passes a similar familiar method, the living files' bodies not written, each later pass the same method at each file, each carried at its strength; session v381R is named plainly for the fact about it, as the prior's tag and carryings/v381R/ have it, and the prior's own reading says the not writing as present; the aiming is said.
SAFER: -

### 95
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 96
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 97
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 98
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file; the PROPOSED file; Natural_Arriving_v381R.md (391 words); README.md; carry/Possibling_of_Natural_Arriving.md; and of carry/Offerings_to_Natural_Arriving.md its opening sections (lines 1 to 40) and each section from "Named entry paths and the separate trust passage · v385A" to its close (lines 309 to 653). Its older Droplets section (lines 111 to 308) was read at each paragraph's opening words, and paragraphs 75 to 98 whole in the PRIOR, each found by exact search to be in the mate word for word. Its older Insertlets section was read at 1.3, 1.4, 6.1, 6.3 and 7.1 alone; carry/Carryings_of_Natural_Arriving.md at its opening sections alone.

Read in part: Natural_Intelligence_v380R.md at 2.5 and 3.3; Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md at its headings and 2.5; Exhibit TWENTY-FOUR Offerings to Geodesic Improving Method at "Three mates at each living file · v385A", lines 315 to 330 and "A droplet's aiming at one of six degrees · v386EOD"; Exhibit TWENTY-SIX Offerings to Living File Registry at "Gathering and aiming incoming before file cohering · v385A"; Exhibit TWENTY-SIX Possibling of Living File Registry at "Ten files at the oldest versions read whole for droplets · v386EOD"; carryings/v381R/Close_Droplets_v381R.md at lines 1 to 14 and 51; carryings/v381R/Session_Transcript_v381R.txt at lines 66 to 92, 183 to 200, 224 to 232 and 476 to 488.

Checked by search: each prior paragraph 75 to 97 is whole at carryings/v381R/Close_Droplets_v381R.md with its line number, its date and its speakers, so a line number or a speaker's name left out of a NEW was not by itself counted a loss; 98 is at this mate alone. NEW's one quotation (87) by exact search in the living file. The sentences of later sections quoted in the objections at 80, 83 and 90 by exact search. The ten NEW paragraphs for the first reader's excluded words and for forty to one hundred and fifty words (each within; the two SAFER paragraphs are 149 words each). The root's file names for each whole name in the NEW paragraphs, and for the ten living files at versions 329 to 333. The living files for links to other files (none) ahead of leaving 77 as OK.

No verdict of RESOLVED, SAID or NOVALUE is in the PROPOSED, so no search for a pointer at a released paragraph was owed; the fourteen KEEP blocks leave their paragraphs as they are and were not checked further.

Not read: the remaining older Droplets and Insertlets paragraphs of the mate, the body of the carryings mate, and the other living files beyond the sections named above.
