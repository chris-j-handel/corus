### 98
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 99
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 100
CHECK: OK
WHY: Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md 3.2 read (lines 182 and 195): it says the differing itself, "Natural Naming 4.9, with the Co-Chaining Logic Registry step 522, seats each of the ten at one name of 1 to 8", beside its own "Each pair sits at its name, the entering way at the self's face and the surfacing way at the other's, 3.3, and at the society eight up"; the old names are at neither file (Natural Naming line 605 and this file's names checked as exact strings of the living files); no paragraph of carry/*.md points at it (searched "ten's addresses", "different addresses"; the one other hit, Carryings of Living File Registry line 888, is the record of the same paragraph's release at Offerings to Natural Naming); the concern is carried on at 101, which stays.
SAFER: -

### 101
CHECK: OK
WHY: both quotations are exact (Exhibit_TWENTY_Natural_Naming_v380R.md line 605, under 4.9; this file's line 182, under 3.2); "one name of 1 to 8" and "2 to 6 ... eight up" are this file's own words at lines 182 and 195, no number the first reader's; "both at the earlier names" was read as no longer so at either file (Natural Naming 4.9 has 8-bi-co-bi-torusing and its own names at two numbers, 1-2-co-bi-offering and 3-4-co-bi-sharing, said at its line 367; this file has 2-bi-co-bi-offering to 14-bi-tri-bi-moralizing), and the one home at one scheme at the v372 faces is at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md line 349, "## Earlier ten-conception gathering and address arrangement · v385A", which says of itself "This is the earlier arrangement proposal"; the subject words "4.9 and the ten" are in the title.
SAFER: -

### 102
CHECK: OK
WHY: laid beside the prior and carryings/session_v377/Session_Report_v377.md lines 21 and 198: this file and its carrying, the two other files' carryings and the Session Record are each in NEW, dated "At version 377", and the work is said as work, nothing of the living file added.
SAFER: -

### 103
CHECK: OK
WHY: laid beside the prior and carryings/session_v377/Session_Report_v377.md lines 36 to 39: each of the three is in NEW in the prior's words, with "as suggested" and "both, one at a time", and the session is named; the first of the three, the two sorts of the ten, was searched in the living file ("sorts") and is at no line of it, so nothing is released.
SAFER: -

### 104
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 105
CHECK: OBJECT
WHY: Lost: the version of the front's entering. The prior has the subtitle, the five parts and the thirty-two sections, "each body whole and in order", under "What entered the Equilibria Registry at v377"; NEW says them undated, as what the file "has", and carries "at version 377" at the spine alone. The subtitle (line 5), the five parts and the thirty-two sections (5, 4, 4, 14 and 5, read at the contents, lines 7 to 52) are so at v380L, but "each body whole and in order" is a saying of the working of version 377, of its bodies beside those of v375, and no reading of the file now gives it; said undated it becomes a present saying nobody read, in a paragraph that will lie under a later tag. The first reader dated the like fact at 102 ("At version 377 ..."). The rest is safe: the quotation is exact; the spine keeps "as suggested at version 377"; and leaving out "replaces v375 on its branch, in passes. Nothing is at corus.me until the lead decides." loses nothing now, the file at the root being v380L, files.json line 30 listing it, and carry/Session_Record.md line 2022 having the working "merged at `main` at v377, pull request 113". No paragraph points at this one (searched "front and spine", "front and the spine" and "hard probleming" in carry/*.md; no hit but this paragraph has the front or the spine of this file).
SAFER: **Droplet · The front and the spine of the Equilibria Registry.** At version 377 the front of Exhibit TWENTY-EIGHT Equilibria Registry entered: the subtitle "Not Possibly Existing, Living or Non-Living", five parts and thirty-two sections, each body whole and in order. Its spine is as suggested at version 377: equilibria is hard probleming, and resolving follows.

### 106
CHECK: OK
WHY: the living file's closing lines read (line 541): "Each saying at the resolver is at Exhibit ONE v380R at the tables it cites, by hand at v380L at its sayings of a carrying of none, or executed at v377 at Exhibit ONE v376 at the script and part it cites" and "The older resolver's derivations, 32 of 32 met at its own code, are whole at `archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_older_resolver.md`"; that archive file is at its path; no paragraph points at this one (searched "Each saying at the code", "section 2 item 2"; the one other hit is the Session Record's own line 1974).
SAFER: -

### 107
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 108
CHECK: OK
WHY: 3.2 and 3.4 of the living file read (lines 182, 188 to 193 and 219): the five pairs at 2 to 6 and eight up at 10 to 14 at the names now, the table's rows for the moralizing, competencing and corusing four-cyclings, its torusing row "none: the entry, the momentarying at 9 and the two windings, the loop the ten are inside", and "The ten sit at three of the four four-cyclings, 3.2"; the sections are still 3.2 to 3.4; no paragraph points at it (searched "section 2 item 4").
SAFER: -

### 109
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 110
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 111
CHECK: OK
WHY: 1.3 of the living file read (line 76): the heading sentence "**Natural intelligence at the between as the universe is, as suggested at v377.**" and the words whole from "in the same way the universe is described" to "in sixteen parity changings", marked "Suggested at v377"; the prior's one omission mark is, at carryings/session_v377/Session_Report_v377.md line 180, the aside "(below my tweet post)", no part of the saying; no paragraph points at this one (searched "as the universe is, as suggested", "section 2 item 5").
SAFER: -

### 112
CHECK: OK
WHY: 1.3 of the living file read (line 78): "**The between travelling, along and across, as suggested at v377.**" and the words whole, "the between is traveling through the natural torusing tunneling co sequencing as the bounding 0 centerline of along and as the sequential faces of across bothboth", marked "Suggested at v377"; no paragraph points at this one (searched "between travelling, as suggested", "bounding 0 centerline"; the one other hit, the older paragraph "8. The between's face", has the words itself and names no other paragraph).
SAFER: -

### 113
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 114
CHECK: OK
WHY: 2.2 of the living file read (line 138): the suggestion whole from "the man is in the river" to "answer your concern.", "As suggested, at each observing a momentary stable form and at the next a different carrying", the observing at steps 135 and 136 and the stable form beside step 390, each with its sentence; the three old numbers were laid beside the Registry of version 376 at git 5e5b1ab (125, 126 and 284 there are the same three sentences as 135, 136 and 390 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md); 4.2 item 1 (line 253) has the column carried "as it stood, its *that can change* said at 2.2 as stable forming", and an exact search finds "can change" at the tables' column and that one citing alone; no paragraph points at this one (the older "1. Met at v377" and "9. The largest" name concern 1 and its own archive file). A second copy of this paragraph is at the mate's line 525, re-aimed from Offerings to Co-Chaining Logic Registry, in another portion (paragraph 237), where the first reader's verdict is the same, RESOLVED.
SAFER: -

### 115
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 116
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 117
CHECK: OK
WHY: laid beside the prior and carryings/session_v377/Session_Report_v377.md lines 105 to 119: each of the ten concepts is in NEW in the prior's words and order, the seven files each at its whole name and in the prior's order (each a file at the root), "wherever" as "at each place" with nothing narrowed, and the session's cohering named; NEW has no quotation of a living file to check.
SAFER: -

### 118
CHECK: OK
WHY: each step laid beside the Registry of version 376 at git 5e5b1ab and Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md: 68 there is 80 now ("the self's momentaries 1–2 and 3–4 go into 4"), 69 is 81 ("the self steps 1 to 3 to 5 to 7 and the other 2 to 4 to 6 to 8") and 65 is 76 ("each number pairs with its podal, 9 less"), the same sentences; each number of the prior is in NEW, the suggestion is said as a suggestion and the reading as "Read, as suggested"; the living file's 3.2 (line 186) has the pairing at step 81 and none of the going into 4, the suggestion or its reading, so nothing is released.
SAFER: -

### 119
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 120
CHECK: OK
WHY: each of the six names in NEW is an exact string of Exhibit_ONE_Natural_Resolver_v380R.md at the prior's number (5, 12, 4, 6, 14, 3; its lines 594 and 595 have the two four-cycles 3-11-6-14 and 4-13-5-12); "nine less in two steps" and the two routes are as the prior has them; "Of the five pairs of the ten" is the subject of the same section of the source (carryings/session_v377/Session_Report_v377.md line 141, "Each of the five pairs") and of this file's 3.2 ("The ten are five pairs at the numbers 2 to 6"), and says nothing the prior does not rest on.
SAFER: -

### 121
CHECK: OK
WHY: step 522 of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md read whole (line 2296; step 380 of the Registry of version 376 at git 5e5b1ab is the same sentence, and the mate's own older paragraphs have "380 at 522"): it seats the arriving at 2, the completing at 6, the middle at 5, the sequencing at 4, the two-way at 3, the opening at 1 and the between at 5, as the prior has them; each of the seven names in NEW is an exact string of Exhibit ONE Natural Resolver v380R at its number; "do not" and "and three are not" are in NEW at the same strength; the subject words *surfacing faces* stay for the link line that follows this paragraph in the mate (line 295).
SAFER: -


## READING

Read whole: the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_4a.txt and the PROPOSED file EQ_4a_report.md; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (542 lines, about 12,300 words).

Read in part: the mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md at lines 1 to 110 (its opening, its `## Insertlets` and the older numbered concerns of `## Droplets`) and lines 293 to 342 (the paragraphs after this portion), with its headings; carryings/session_v377/Session_Report_v377.md at the lines the paragraphs are from (19 to 22, 34 to 40, 50 to 53, 86 to 100, 105 to 120, 135 to 151, 160 to 173, 180, 196 to 199); carryings/resettling_v373/ at the two rows of 100 and 101; carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md lines 349 to 354; carry/Session_Record.md lines 2014 and 2022; the earlier readings of the same two paragraphs at Offerings to Natural Naming (NN_2_report.md and NN_2_harm.md, blocks 44 and 45), read after my own reading of 100 and 101.

Checked by exact search: each quotation in a NEW paragraph and each EVIDENCE sentence of a RESOLVED block, in the living file it names (Exhibit TWENTY-EIGHT Equilibria Registry; Exhibit TWENTY Natural Naming line 605); each resolver name in the NEW paragraphs of 120 and 121 in Exhibit_ONE_Natural_Resolver_v380R.md; each step number of 114, 118 and 121 in Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md, and its old number in the Registry of version 376 read from git 5e5b1ab; "can change" in the living file; the archive file of 106 at its path; files.json for 105. For each RESOLVED block the mate and carry/*.md were searched for a pointer to the paragraph by its subject words and by "above", "the preceding", "at this mate", "the concern at", "the droplet at", "current droplet" and links into this mate; none points at a paragraph of this portion. Each NEW paragraph was laid beside its prior clause by clause, and its length and the first reader's word list were checked by script (each within forty to one hundred and fifty words, none of the listed words in the first reader's own sentences).

Not settled here: the ten blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 103 the prior's "were met as both" is said in NEW as "are each read, as suggested, as both"; the prior's own quotation has "each read, as suggested", and I read no loss in it.
