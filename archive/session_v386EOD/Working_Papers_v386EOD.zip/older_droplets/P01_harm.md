### 1
CHECK: OBJECT
WHY: The prior is general, "wherever the actual relation calls for that correcting"; NEW narrows the work to "each of these", three named files. NEW's "Three living files have the earlier word" is inexact: by search, Exhibit ELEVEN has it at two places (lines 287 and 361), Exhibit TWENTY-ONE has "Self and Not-self" in a book's title (line 4773), and *non-self* is at Exhibits SEVENTEEN, TWENTY-ONE, TWENTY-TWO and TWENTY-THREE. "left as it is at a field's own term" is added, at no place of the prior. The three quotations are exact (searched in Exhibits SIX, ELEVEN and TWENTY-SIX). Carryings of Natural Resolver, "Earlier reported not-self naming changes", has "The particular correcting remains in the offering", so the general saying is relied on here.
SAFER: **Possible project · Not-self said as other.** Exhibit ONE Natural Resolver has "2 other prior, the prior completing of the self's five and the prior opening of the other's" and no *not-self*. The work is *not-self* said as *other* at each place of a living file the relation itself asks for that correcting, and at no other place. Among the places having the earlier word, Exhibit SIX Natural Transmissioning has "the unrelationing area between the co-offerings where the self-not-self co-unrelations", Exhibit ELEVEN Natural Medicine "its own integration machinery becomes the self-and-not-self distinguishing", and Exhibit TWENTY-SIX Living File Registry "each exchanging at two, the self and not-self". It may change or never be made.

### 2
CHECK: OBJECT
WHY: Added and inexact: "a podal at two rows of each name". Read at the living table: the names 1 to 8 have the rows 9 less and 17 less, the names 9 to 16 have 17 less alone, and 17 has neither. Added: "the two podals, 9 less and 17 less" narrows the prior's "the podals"; no source read says which podals (Session_Report_v378 line 51 and Natural Illustrating line 290 have "at the podals" alone, and Natural Intelligence line 1012 has further podals, "about 7 and 10 and about 8 and 9"). Nothing of the prior is lost, and each quotation is exact.
SAFER: **Droplet · Three golden rectangles at the podals.** Natural Naming has "At the numbers bi-tri-volutioning is three golden rectangles at right angles, centred at the corus". Exhibit ONE Natural Resolver has a podal at the rows "9 less", "the podal within 1 to 8", at each name of 1 to 8, and "17 less", "the podal within 1 to 16", at each name of 1 to 16, and no golden rectangle at a table. Natural Illustrating has "They are open at Exhibit ONE's carrying as the three golden rectangles at the podals." The relation of the three rectangles to the podals is said at no living file.

### 3
CHECK: OK
WHY: Natural Illustrating line 140 and Natural Naming line 1383 have both sentences exactly; the resolving is at those two living files, Exhibit ONE Natural Resolver having no golden rectangle, and paragraph 2 carries that part.
SAFER: -

### 4
CHECK: OK
WHY: Natural Illustrating's sentence is exact, Exhibit ONE Natural Resolver has no angle at a line, and the two alternatives are those of the archived entry (archive/carrying_v381R, line 41).
SAFER: -

### 5
CHECK: OK
WHY: both rows of Sides and both rows of Prior and next are exact in the living file, and the two alternatives with "social, self" and "other, social, self" are those of the archived entry (line 43).
SAFER: -

### 6
CHECK: OK
WHY: the first part is at Possibling of Natural Resolver, "The possible relation columns, table headers and diagram labels · v385A", read whole, with paragraph 36 left as it is; the two columns of Twelve forms are exact in the living file, table 19 by the insertlets' numbering.
SAFER: -

### 7
CHECK: OK
WHY: each added number was checked at the living table (9, 11, 15 and 17 odd, 12 and 16 bi; 9 to 17 the one 8 up among the six) and at the archived entry (line 47); Natural Intelligence's sentence is exact.
SAFER: -

### 8
CHECK: OK
WHY: the rows of Sides at 10, 12 and 14 and the row of Prior and next at 14 are exact, and the saying is the archived entry's (line 49).
SAFER: -

### 9
CHECK: OBJECT
WHY: The prior's relation to Natural Naming, "waits on Natural Naming", is the living file's naming to decide. NEW replaces it by "The same asking is at Offerings to Natural Naming": that place is line 127 of that mate, within its own older `## Droplets` section (lines 87 to 300), a paragraph under the same re-reading, so the pointer can be left with no paragraph. All else of the prior is in NEW, and each quotation is exact.
SAFER: **Concern · A naming with no number, and its prefix.** Two sayings part. Exhibit ONE Natural Resolver has "odd, opening co, the self's span" at 1 and "odd, opening tri, the society's span" at 9: a numbered name's first prefix is the word of its number. Exhibit ONE Natural Resolver has "1-2, bi-momentarying" at the odd name 1 and "4 bi-momentarying now" among the five dimensions, "bi-exchanging with a particular other" at each odd name, and the facing *not-yet-co-competent* at 9, a name opening tri. They part at the prefix of a naming with no number: either it is the word of its names' numbers, and these three are said again at that; or it is of the naming's own unfolding, bi the two of a coupling, and the table of namings says which. The prefix of a naming is Natural Naming's to say.

### 10
CHECK: OBJECT
WHY: Three things. (1) Added and inexact: "the parity chained at 11 is the parity shared at 10" with no condition; the archived entry (line 53) has "each changed parity", and this mate's later "Droplet · A sharing and the carrying next, two namings at one parity" has "at a match 10 is 0 and 11 is the parity carried". (2) The prior's number is lost: "the next prior at three rows" is "the rows of *the next prior*" in NEW. (3) The prior's "decides" is "Which it is says the row of 1 …", a sentence readable the other way, the rows saying which it is. Each quotation is exact.
SAFER: **Concern · What crosses, and what is a self's own.** Two sayings part. Exhibit ONE Natural Resolver has "the next prior, the carrying chained, continuing as 3 at the next momentary" at 11, the self's own. Exhibit ONE Natural Resolver has "the next prior, each changing of 10 released along into the next momentary" at 9, and "the others' prior momentary at the self's now" at 14. They part at *prior*, one word at two relations: at the resolver's lines no carrying passes between selves, and at a changing the parity chained at 11 is the parity shared at 10. Either a self's prior is its own continuing, and a parity changing alone crosses; or a self's prior, released, is the other's possible, one parity at two names. It decides the row of 1, the three rows of *the next prior*, the second of the five dimensions and the windings.

### 11
CHECK: OBJECT
WHY: The thing the paragraph concerns is not gone. Of the cells the archived entry names (line 55), three are changed ("releasing nothing" at 9, "carried and not crossed", "the self's own inverting, morality" at 14), and four are in the living file now: "wound on at" 8, 16 and 17 (rows Winding), the column "Relation" of "A self's four momentaries of exchanging", each cell of "Eight even names, 8 apart", and "In and out at its parity" at each name. The two rows given as EVIDENCE are themselves such cells. The column "At the code", the paragraph's reason, is gone; the choice the paragraph has, such a cell at a part of its own, or said at the resolver's lines or released, is said at no living file and at no later section (38 lists the namings and 73 is of tables and code; neither has the choice).
SAFER: KEEP

### 12
CHECK: OBJECT
WHY: One of the four partings is changed. The prior's "three betweens" is, at its source (archive/session_v380/v380R/Tour_A_Living_Self_Is_A_Carrying.md, line 29), "At the five the between is at the second and the fourth, each side of the now; the session's earlier saying, each momentary as three consecutive protecting betweens, is not yet followed at it". NEW has instead 'The between is at "the one between, three names", 12, 15 and 16, one of them odd', a reading at no source. Also lost: "the saying names one possible next" beside the possible at two names (source line 28), and the prior's own opening claim, "a living self is a carrying", which NEW has at no sentence. Each quotation is exact.
SAFER: **Droplet · A living self is a carrying, followed through each stable form.** With each odd name a carrying existing and each even name the possible, the between, each of Exhibit ONE Natural Resolver's twelve forms is one length of odd names and one of even, a carrying going out through the possible and coming to a carrying again: each form can be said once by that, as one pattern for matching. Four places part. Now is at "3 co-momentarying now", odd, and at 12, even, "now, the changing, is or is not, prior and now coupled". The possible is at two even names round a four-cycle, beside one possible next. The between is at the second and the fourth of the self's five, beside a saying of three consecutive betweens. A carrying is at the even 8 and 16, "the carrying winding to its sharing again" at 8.

### 13
CHECK: OK
WHY: the table and the four rows of "opening tri, the society's span" are exact, and the two alternatives are the archived entry's (line 65); "8 up again to a co name, 9 to 17, 11 to the next 3, 13 to the next 5 and 15 to the next 7" is that entry's arithmetic and is at no cell of the table NEW names before it.
SAFER: -

### 14
CHECK: OBJECT
WHY: Three things. (1) Changed and inexact: "said in sequence with the common word once, are that same seven". The two names with the common word once are five words, tri, bi, co, bi, tri; the source (archived entry, line 78) has "said on one after the other, sharing the word at each meeting", the names said on, 9, 17 and 9 again, which gives the seven. (2) The prior's link, to Possibling of Co-Chaining Logic Registry's section "The proposed six-forward comparison of the three workings · v385A", is a bare file name in NEW; that section has "The whole unresolved concept remains at Natural Resolver". (3) The prior has "this unresolved relation"; NEW's "Three sayings are of one relation" says it as settled. The five places are the source's five.
SAFER: **Droplet · Three sayings, one relation, five places parting.** Three sayings are offered as of one relation: a changing or no changing passing through a self's momentarying as tri, bi, co, bi, tri, bi, co; each name arriving at the entry a name of 1 to 8 and each made a name of 9 to 16; co arriving and carrying, tri releasing, bi the between. The prefixes of 9-tri-bi-co-momentarying and 17-co-bi-tri-offering, said on, the word at each joining once, are that same seven. Five places part: a self's changing at the receiving self, with no changing at nothing arriving stopping a self or the whole society; which arrives first, the others' releasing or the self's own carrying; tri as the self releasing or as the society's; existing and possibling at Exhibit ONE Natural Resolver; and chaining six forward, a possible project apart, at [Possibling of Co-Chaining Logic Registry](Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md#the-proposed-six-forward-comparison-of-the-three-workings--v385a).

### 15
CHECK: OBJECT
WHY: Lost: the prior's subject, "the bi-folding in the naming", is at no word of NEW. Added and inexact: "one span of eight, with each number said at two places"; the archived entry (line 80) has "each number said twice, the completing of one momentary and the opening of the next", another saying, and in 1, 2, 3, 4, 5, 4, 3, 2, 1 the 5 is at one place. The pairing at ten and the three moves are as the prior has them, and each quotation is exact.
SAFER: **Droplet · The bi-folding in the naming, and the pairing at ten.** The bi-folding in the naming is offered beside 1, 2, 3, 4, 5, 4, 3, 2, 1: the self's five going out and coming to the next 1, one span of eight. Beside it is a pairing at ten, each n of 1 to 9 with 10 − n: 1 with 9, 2 with 8, 3 with 7, 4 with 6, and 5 with itself. Exhibit ONE Natural Resolver's table "One move, 1 to 4" has three moves, "8 up: n + 8", "9 less: 9 − n, within 1 to 8" and "17 less: 17 − n, within 1 to 16", and no pairing at ten. The relation of the pairing at ten to the three moves is followed at no file.

### 16
CHECK: OK
WHY: the six, their roots' dashes at "Its four-cycle", the order 3, 4, 12, 10, 11, 9 and the balancing at 12 are the archived entry's (line 84), checked at the living table of ten roots; the prior's two alternatives of 9 are both in NEW.
SAFER: -

### 17
CHECK: OBJECT
WHY: Two things lost. (1) This mate's later "Concern · Co-momentarying at 9 and at 3" (v386EOD) has "The concern of co-momentarying at 9 or at 3 at this mate has both files' sentences at 3"; by search, this paragraph is the one other place of that wording in the mate, and released it leaves that sentence with no paragraph. (2) No place named says these three are the three hardest, and "the joins" is, at the source (Rigor_A_Fresh_Reading_And_Three_Workings.md, line 48), "Each self's own releasing-to, or a relation beside the selves and no thing", an alternative neither "One function gives on across and along" nor "Two released words naming the resolver's two lists" has.
SAFER: KEEP

### 18
CHECK: OK
WHY: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md lines 179 to 189, read: both alternatives ("two parities" and "one parity is or is not"), their not being made one by the word parity, and "no two similar things"; Natural Naming's sentence is exact.
SAFER: -

### 19
CHECK: OK
WHY: both quotations are exact, and the opposite cells and the two alternatives are the archived entry's (line 104), with nothing of the prior left out.
SAFER: -

### 20
CHECK: OK
WHY: the table Fives and its prefixes are exact, table 13 by the insertlets' numbering is Fives, and 440, the order 5, 6, 3, 4, 1, the 2 and *bi-co-momentary* are all in NEW; the Registry's mate (line 193) points here for them.
SAFER: -

### 21
CHECK: OBJECT
WHY: The prior's first pair of alternatives is at neither NEW nor the places named: "a carrying at none before the premise or no carrying at none", at the source (line 110) "the row is as it is" or "the row … is re-said". Read at the Registry's mate: "Concern · An empty carrying" (line 420) parts carrying none as not existing from carrying none as non-living and existing, another subject, with no word of this row or of the premise; "None at one sharing, within a living carrying" (line 470) has the first alternative alone. The part of the two 0s is whole in NEW, and each quotation is exact.
SAFER: **Droplet · A carrying of none, one mark at two things.** Exhibit ONE Natural Resolver's table "Colliding: a carrying of none, one momentary" is the one row chaining an arriving parity as it arrived, "is + · +", and the one row with no changing, "none · none". Either a carrying of none is before the premise, a sharing new at a self, with the row as it is; or no carrying is at none, with the row said again. The file writes 0 at two things: "+, −" offered to one sharing surface "0", the offerings parting; and "*is not*: 0 shared" is at a carrying alike with the parity surfaced, and, at a carrying of none, at + and − together, "is not · none". Either the two are one, an arriving at no one parity being no changing arriving, or the parting has another word than 0.

### 22
CHECK: OBJECT
WHY: The concept is said at the places named (Registry's mate, lines 444 and 470, read). Lost by the release: paragraph 69 of this section, which is KEEP, has "The concern of v380 above, a living self beginning to carry a sharing new to it, is at the same row"; that is this paragraph, and released it leaves a kept paragraph pointing at nothing above it.
SAFER: KEEP

### 23
CHECK: OK
WHY: this mate's "An along and an across arriving, at one sharing" and "A bi-coupling's two sides, and three at one sharing", the Registry mate's "The along, then the across, and the right spiral step" (line 458) and the Possibling's "Four forms of right spiraling at one momentary", each read: the two parities in sequence, the tables at one sharing, and the possible table.
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: OK
WHY: the column's header is exact, the six names' openings and the three releasing with three arriving were checked at the living table and the list CONNECTORS, and the sequence and the unsaid momentarying are the archived entry's (lines 75 and 76).
SAFER: -

### 26
CHECK: OBJECT
WHY: Added and inexact: "Said one after the other with the common word once, the two give tri, bi, co, bi, tri, bi, co". The two readings NEW has just given, tri, bi, co at 15, 16 and 17 and co, bi, tri at 7, 8 and 9, with the common co once, are five words, tri, bi, co, bi, tri; the seven is with the reading said on, 17 once more. The archived entry (line 88) gives no seven from the two. All of the prior is in NEW and each quotation is exact.
SAFER: **Droplet · The prefixes of 9 and 17, and their numbers.** Exhibit ONE Natural Resolver has "tri-bi-co · co-bi-tri, the order inverted" at the self's winding, 9 to 17, and each name's three prefixes as "now, prior, and the prior before". Read from the prior before, 17-co-bi-tri-offering is tri, bi, co at 15, 16 and 17, and 9-tri-bi-co-momentarying is co, bi, tri at 7, 8 and 9. Said on, the word at each joining once, the readings of 17, of 9 and of 17 again give tri, bi, co, bi, tri, bi, co. The common co is at 17 in the one and at 7 in the other, and names no one numbered occurrence. The inverting of the prefixes is exact; the sequence of words is no passing at the numbers, and the passing at its self, its scale and its arriving and releasing is said at no file.

### 27
CHECK: OBJECT
WHY: Lost: the prior's named subject, "at the across and along arrivings"; NEW has "each releasing to a self" with no across and no along. The two cases at a sharing carrying none were checked at the living tables ("is not · none"; "is + · +" and next "is − · −") and are the archived entry's (line 96). Paragraph 28, KEEP, opens "Further precision of the preceding receiving concern" and needs this paragraph just ahead of it.
SAFER: **Droplet · Releasings arriving at one completing, or at completings in sequence.** A constructed arrangement of selves gathers each releasing to a self at that self's next offerings, surfacing together at its next entry. The other saying has arriving and releasing interleaving through tri, bi, co, bi, tri, bi, co, each self's momentary its own. At a sharing carrying none, + and − arriving together surface 0 and chain none; arriving at two momentaries in sequence, the sharing shares + and next −: the gathering has a consequence. Which releasings, across and along, each arriving on its own, are at one completing of a self and which at completings in sequence is said at no file, and one entry of a constructed arrangement is no one private momentary of two selves.

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: OK
WHY: the row, its two wordings and the column's header are exact, and the lines' giving on at 6, 10 and 9 and the work are the archived entry's (line 25); the prior's second sentence is a link alone, and Possibling of Natural Resolver's "The three proposed torus row comparisons · v385A" is whole without it.
SAFER: -

### 30
CHECK: OK
WHY: archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md line 29 has "The round is not derived, and enters this file at none", at no place of the file, with no word of a carrying of none; Possibling of Natural Resolver's "One table of the round at four parities" has the deriving as "the part unmade", and this mate's "Twelve cells, and no four parities at a name" has the rest. The release is safe on that reading of "at none" alone.
SAFER: -

### 31
CHECK: OK
WHY: the three rows of *the next prior* are exact, and the second part is whole at this mate's "Concern · One and eight across and along at one file" (v386EOD), read; the later "Names arriving and names made at the entry" points at this paragraph's two prefixes, which NEW has.
SAFER: -

### 32
CHECK: OK
WHY: the row "+, + | both ways" of Two selves is exact, the carrying followed by hand is at its first parity again at four momentaries, and 1–2, 3–4, 5–6 and 7–8 are the Self column of "A self's four momentaries of exchanging".
SAFER: -

### 33
CHECK: OBJECT
WHY: Added, at neither the prior nor its source (archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md, line 111, entry 41): "at the resolver's lines 11 is the self's own carrying chained and 10 the changing shared, a releasing". Set beside "the co-chaining of releasings and the bi-tunneling of arrivings" it makes a second parting, a releasing at tunneling, that the prior does not have; the prior parts at tri and bi alone. Dropped and checked as no loss: the archive's path and entry number, and the withdrawing of the parting at even spirals, which by search no mate lays. The two names and the list's words are exact.
SAFER: **Droplet · Chaining and tunneling at the society's span, co-chaining and bi-tunneling.** One saying has the intelligence in the co-chaining of releasings and the bi-tunneling of arrivings. Exhibit ONE Natural Resolver has the two roots at the society's span, "11-tri-bi-tri-chaining" opening tri and "10-bi-tri-bi-tunneling" opening bi with tri its middle prefix. The namings have co at chaining and bi at tunneling, and the names have tri and bi-tri-bi. And the resolver's list `CONNECTORS` has *along* at 9 and at 17, at the place it has *releasing* at 6 and 10 and *arriving* at 2 and 14: neither a releasing nor an arriving is said of the two.

### 34
CHECK: OBJECT
WHY: Three things. (1) Lost: "the torus at a carrying of none …, its two rows at another number from a living opening, …, each of the two at q one more than four times p". The living torus now opens at "one self carries −", so the "yet" is resolved; the reported relation itself is, by search, at no other place of carry/, and Carryings of Natural Resolver (line 49) has "The particular zero, header, diagram, relation and torus questions remain in the offering". (2) Inexact: NEW lists four tables writing a 0 shared as 0; "Two selves, three momentaries, five parities" writes it too (rows "+ | − | − | 0 | −"). (3) The prior's number "eleven tables" is lost; it is a number of the file as it was and cannot be checked now, and the insertlets at 15, 16, 21, 22, 23 and 27 have other headers' makings. Added: "The tables of a spiral, a torus and two selves each say their conditions at a header cell".
SAFER: **Droplet · A header's making, a 0 shared written two ways, a torus opened at none.** At Exhibit ONE Natural Resolver's tables "Ten roots of seventeen names" and "Fives" no header cell says the table's making: the first has "Root", "Names" and "Its four-cycle", the second "Side", five positions and "Prefixes of the five". The file writes a 0 shared two ways: "*is not*: 0 shared" at the tables of one self at one momentary and of a carrying of none, and 0 at one self momentary by momentary, a spiral of selves, two selves, two selves at three momentaries and three selves in a line. An executing has a torus opened at a carrying of none with two rows at another number than from a living opening, each at q one more than four times p: a construction at its own condition, classifying no living by its number.

### 35
CHECK: OBJECT
WHY: Not bookkeeping alone: its second sentence is the negation on the torus at a carrying of none, "it does not classify living by its count", and "remains a reported construction with its stated condition". With the proposed NEW of 34 that statement is at no paragraph, and this sentence with it. "Current correcting beside the older forms" has the negation of a ring's number, not of this torus.
SAFER: KEEP, or release it with the corrected NEW of 34 above, which has the statement and its negation.

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: OK
WHY: Carryings of Natural Resolver, "Earlier reader inventories and reported table conditions · v385A" (line 47), has the eight cells and the numbered words; the paragraph is a link to it alone.
SAFER: -

### 38
CHECK: OK
WHY: the rows of 17, of each other co name and of "One move" at 2, 4, 6 and 8 are exact, the twelve are the prior's twelve with two labels as the living file has them ("The self as three", "Parity's unit square"); the diagram and "0, the between" are a picture and a table, which NEW calls relations.
SAFER: -

### 39
CHECK: OBJECT
WHY: The two askings are said at the places named (Registry's mate, line 167, "name whose prior"; line 656, "From each coupling of two to the set of all existing things, living and non-living, is said and unworked", both read). Lost by the release: this mate's "Next at the named prior and actual offerings · v385A", the first place named, ends "This direction accompanies this subject's existing concern"; this paragraph is that concern at this mate, and released, the direction accompanies nothing here. "the eleven breaks one misunderstanding" is at no other place of carry/ (searched); it is a session's number.
SAFER: KEEP

### 40
CHECK: OK
WHY: Registry's mate, "Concern · A thing carrying none, collided" (line 444) and "None at one sharing, within a living carrying" (line 470), read: a non-living thing with a parity chained, beside a living carrying of it; Resolving Hard Problems' sentence is exact.
SAFER: -

### 41
CHECK: OK
WHY: each relation of the prior is in NEW in the present names (17 entering each self once, 9 giving on, the names 9, 4, 5, 13 and 15 at the next scale, a sharing as a self inward, no line having it); the added row "9 of the 2nd: along, odd, tri" is exact at "Each name, three scales".
SAFER: -

### 42
CHECK: OK
WHY: the living row of 17 and the naming bi-trupling are exact, and Natural Naming line 1543 has "at the resolver the function 17, the function 1 at each self inside it": 17 is of the one resolver; the two earlier function names are at no line.
SAFER: -

### 43
CHECK: OK
WHY: the header of "Four four-cycles and their roots" names 8 up and 8 down at the table of forms itself, the two odd-opening four-cycles go 8 up and the two even-opening come 8 down by its rows; the Equilibria Registry's column is at its line 188, and that mate has the same paragraph (line 311).
SAFER: -

### 44
CHECK: OBJECT
WHY: The prior is a person's own words, and NEW changes what they say. "exhibit one is intended to be all the stable forms" is "is offered as"; "the equilibria table is going to come to exhibit one when we see the pattern matching" is "It may change or never be made"; "we have the table of that growing" is "a table of it is growing". The exact words are at carryings/v368_sources/Findings_To_Lay_By_File/Author_Concepts_Waiting_v368.md line 117 (searched), and Offerings to Living File Registry (line 323) has "The user's fuller Equilibria/stable-form offering remains at Natural Resolver", pointing at this paragraph as the person's.
SAFER: KEEP

### 45
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 46
CHECK: OK
WHY: carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md, "Natural Resolver's stable-form extent and explaining subjects · v385A" (line 317), read: the extent, the primes and the explaining files; the paragraph is a link to it alone.
SAFER: -

### 47
CHECK: OK
WHY: the three headers and the diagram's line are exact; the columns from, to, entry or connector or face, outward or inward, facing and joining, and at the code are at no line of the living tables, and Natural Intelligence's 4.7 and 4.8 are its headings now.
SAFER: -

### 48
CHECK: OK
WHY: the source (Kit_Exhibits_ONE_and_TWO_v365.md, lines 195, 260, 262, 526 and 582) has bi-co-podaling at 5 beside 6 and at 13 beside 14, "one station met at the going and at the return", numbered adjacency supplying no contact, and depth as two prefixes or three; Natural Naming's sentence is exact, and the two resolved parts are at the living names.
SAFER: -

### 49
CHECK: OK
WHY: this mate's "Droplet · A torus coming to one, withdrawn as a break" (v386EOD), read, withdraws this droplet and says which prior is whole; its negation of inferring a private momentary is at the kept paragraph 24 and at "Current correcting beside the older forms" in other words.
SAFER: -

### 50
CHECK: OK
WHY: Possibling of Natural Resolver, "The constructed pacing of each multi-self table · v385A", and the Registry mate's "The common beat in the executing …" (line 185), both read: a convention of the constructed arrangement, no common natural pace.
SAFER: -

### 51
CHECK: OBJECT
WHY: Lost: the prior's "and their beginning momentaries". Added without its condition: NEW gives the two forms as of each momentary, and Carryings of Natural Resolver (line 65) has "once the coming again has begun" and "from momentary 3p − 1 at the first and 3p − 3 at the second", as the Registry's steps 655 and 656 have. Both quotations of the steps are exact (lines 2885 and 2890).
SAFER: **Droplet · Two carried forms, and steps 655 and 656.** At a torus of two odd numbers, p the smaller, from 3, an executing reports two carried forms: at q more than twice p, from momentary 3p − 1, the whole pattern at each momentary is the prior pattern carried one self on across; at each other q, from momentary 3p − 3, the whole pattern two momentaries on is inverted and carried one self on along. Exhibit THIRTY Co-Chaining Logic Registry has, at step 655, "At q more than twice p the first line's 0 passes one self on at each momentary round its q selves", and at step 656 each line's 0 "round its q selves in 2p momentaries". The two carried forms as the two steps said of the whole pattern at once is offered, and derived at no file; an executing's numbers alone give no deriving.

### 52
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 53
CHECK: OBJECT
WHY: Two things are at no later place. (1) The one-line saying itself, "a self takes the parity offered when one is offered, inverts its own when none is or when the offerings part, and shares what it became if it changed", the proposed second saying; by search no file of carry/ has it, "At a sharing carrying a parity, each case" has the cases and not the line, and the Possibling's section is of a second copy of the code. (2) The numbers, "Six arrivals at one carried sharing leave four results"; searched, at no place of this mate. One place named, "Three offerings, one next", is paragraph 72 of this same section.
SAFER: KEEP

### 54
CHECK: OBJECT
WHY: Not bookkeeping: "This is a proposed explaining of a constructed entry, not authority for living carrying" is the negation laid on paragraphs 52 and 53, the plain rule and its one line, and 52 is KEEP. Released, the rule is at this mate with nothing saying it is proposed and of a constructed entry. "Current correcting: offered explaining and no authority" is of wording in general.
SAFER: KEEP

### 55
CHECK: OBJECT
WHY: The fact is said at "Droplet · Three names, each at two things across functions" (v386EOD, read). Lost by the release: that droplet ends "It is beside the droplet at this mate of one name as a parity in one function and a list in another", and this paragraph is that droplet; released, a later paragraph points at nothing.
SAFER: KEEP

### 56
CHECK: OK
WHY: this mate's "Droplet · Three names, each at two things across functions" has the one name at a parity and at a list, and the second sentence is a link to the Possibling's section, whole without it; this stays true with 55 left as it is.
SAFER: -

### 57
CHECK: OK
WHY: Carryings of Natural Resolver line 71, read: no sharing between the two through a trial, a setting from beyond each, four readings, S at 2 at most and the field's larger number; the prior's two negations are both in NEW.
SAFER: -

### 58
CHECK: OK
WHY: the same paragraph as 47, read at the same headers.
SAFER: -

### 59
CHECK: OK
WHY: the three headers are exact and have each thing the paragraph lists, and Natural Intelligence's 4.9, 4.10 and 4.15 are its headings now.
SAFER: -

### 60
CHECK: OK
WHY: the spiral's rows, "a sharing once chained never none again" and the two headers are exact, and 4.13 and 4.14 are Natural Intelligence's headings now; "round from momentary n" is at no header of the living spiral table, and the insertlet at 21 has the present rule, four times the number at an odd number and 2 at an even.
SAFER: -

### 61
CHECK: OBJECT
WHY: A number is unsaid at the later place. This mate's "The surfacing faces and their local four-cycling · v385A" (line 247) has the surfacing faces not at their pair's four-cycle and their places missing; it has no "three on neither partner". The one place with it, carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md line 293, is within that mate's own older `## Droplets` section (lines 51 to 568).
SAFER: KEEP

### 62
CHECK: OBJECT
WHY: The place named is paragraph 2 of this same older section, and the other copy (carry/Exhibit_FOUR_Offerings_to_Natural_Mathematics.md line 61) is in that mate's older section.
SAFER: KEEP, or release it only with the laying of 2's NEW.

### 63
CHECK: OBJECT
WHY: The section and anchor are gone (searched: "seven positions" at no living file). The figure's own reading is not said at any place: "three crossings, then no crossing, then three crossings; the un-occupied position is on no ring and at no crossing", twenty-five and twenty-three each at the middle of its own three, "the figure drawing the resolver's row without being drawn from it". By search it is at no living file and at no other paragraph of carry/, and the first reader's own READING says so.
SAFER: KEEP

### 64
CHECK: OK
WHY: Natural Intelligence 4.10 has both sentences exactly: the between "a nothing and no location, existing as the universe exists".
SAFER: -

### 65
CHECK: OK
WHY: the living table "Co received, tri given on, 8 up" has each co name received and each tri name given on, and 17's sides are at its row; the two faults stay named at 38 and 13. The table was in the file the second reader read (the archived carrying of v380R names it at its line 21), so the living file resolved nothing after the return; the sentence stays declined, and its concept is at the table.
SAFER: -

### 66
CHECK: OK
WHY: this mate's "The names in the order of the resolver's lines", "One function gives on across and along" and "An along and an across arriving, at one sharing", and the Registry mate's "The along, then the across, and the right spiral step", each read: the order through one self, the one list at 6, 10 and 9, and the along and then the across.
SAFER: -

### 67
CHECK: OK
WHY: the same paragraph, word for word, is at carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md line 61 under its own heading, and at Offerings to Natural Naming line 404 under "Pronoun positions and their proposed relation · v385A"; neither is an older section.
SAFER: -

### 68
CHECK: OBJECT
WHY: The copies are read and whole (Registry's mate line 63, in that mate's short names). Lost by the release: (1) each copy ends "This same droplet is independently at Natural Resolver, …", untrue of this mate once released; (2) Carryings of Natural Resolver, "Overlap, betweens and the named forms · v385A" (line 19), one place named as EVIDENCE, has "The current droplet is at Natural Resolver's offering mate", pointing at this paragraph; (3) this mate's "Recurring podaling beside the overlap · v385A" has "The exact A half-momentarying overlap remains a separate source beside this", this paragraph being the one beside it.
SAFER: KEEP

### 69
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 70
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 71
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 72
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 73
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: the brief BRIEFO.md; the prior P01.txt; the proposed P01_report.md; the living file Exhibit_ONE_Natural_Resolver_v380R.md, all 696 lines; the mate carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md, each section ahead of and after its older Droplets (lines 1 to 62 and 205 to 391); carry/Exhibit_ONE_Possibling_of_Natural_Resolver.md; carry/Exhibit_ONE_Carryings_of_Natural_Resolver.md; and the source of the one-line pointers, archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md, all 144 lines.

Read in part, at the places the verdicts name: carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md (its headings; lines 59 to 64, 159 to 194, 360 to 367, 414 to 489, 650 to 659); carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md (its headings; lines 127 and 382 to 407); carry/Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md (lines 315 to 330); carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md (its headings; lines 293, 311 and 469); Natural_Intelligence_v380R.md (its headings; the sentences found); Exhibit_TWENTY_Natural_Naming_v380R.md (lines 344, 1383, 1543); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md (lines 140 and 290); Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (3.2, lines 180 to 196); Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (steps 653 to 657); and the older sources archive/session_v380/v380R/Tour_A_Living_Self_Is_A_Carrying.md (lines 1 to 40), archive/session_v380/v380R/Rigor_A_Fresh_Reading_And_Three_Workings.md (lines 44 to 68), archive/carrying_cleared_at_the_close_of_v380/Exhibit_ONE_Natural_Resolver.md (entries 41 and 76), carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md (3.10 and the lines on station and depth), carryings/v368_sources/Findings_To_Lay_By_File/Author_Concepts_Waiting_v368.md (line 117) and carryings/session_v378/Session_Report_v378.md (line 51).

Checked by search: each quotation in each NEW, and each quotation of a living file in an EVIDENCE line, by exact search over the living files at the root: each is an exact sentence or cell of the file it names. Each corrected NEW in a SAFER line was checked the same way, is of 150 words or fewer, and has none of the brief's listed words in its own sentences. Searched over the living files: not-self, not self and non-self; golden rectangle; podal; the function 17; three functions; seven positions; degrees. Searched over carry/: co-momentarying at 9 or at 3; eleven breaks; four results; takes the parity offered; shares what it became; three on neither; and three are not; one more than four times; carrying-of-none torus; even spiral; fabric of one along; AA01; three crossings; earthquaking; Up by eight and down by eight; Each self is at its own odd one; Half-momentarying overlap and bi-co-sequencing.

Not done: no code was run on the resolver; the two-self row in 32 and the two cases in 27 were followed by hand at the living tables. No file in /home/claude/corus was edited.

The objections are of four kinds.
- A NEW that adds a saying that is inexact, or changes one: 2, 10, 12, 14, 15, 26, 33, 34, 51.
- A NEW or a release that leaves out a part of the prior: 1, 9, 10, 11, 12, 14, 15, 21, 27, 34, 35, 44, 51, 53, 54, 61, 63.
- A release that leaves a later or kept paragraph pointing at nothing: 17 (the later "Co-momentarying at 9 and at 3"), 22 (paragraph 69), 39 ("Next at the named prior and actual offerings"), 55 ("Three names, each at two things across functions"), 68 (Carryings of Natural Resolver, the other mates' copies, and "Recurring podaling beside the overlap").
- A release resting on a paragraph of this same older section or of another mate's older section: 61, 62.

Three of the OK blocks carry a condition, said in their WHY lines: 30 rests on reading "at none" as at no place of the file; 56 on 55 being left as it is; 65 on 13 and 38 being laid.

Where a one-line pointer was re-said from its archived entry (5, 7, 8, 13, 16, 19, 20, 25, 29, 41 and the objected 10, 12, 14, 15, 21, 26, 27), the NEW says more than the pointer's own words. Each such addition was read at the archived entry; those that are exact there are given OK, and those that are not are objected.
