### 1
CHECK: OK
WHY: Exhibit_TWENTY_Natural_Naming_v380R.md, "## 4.9 The ten named still, one name each" (line 603) and its table, has each of the ten names word for word; carryings/physics_for_other_files_v377/README.md 2.3 has "Natural Biology v333 1", the prior's one place, and the living file still has it at line 334 ("a two-way held to one side"); NEW has Natural Naming 4.9, the ten, the older *held* forms, the one place and "each offered for local naming correction" at the prior's strength, and leaves out only the report's path and its 2.3, a source's own section.
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OK
WHY: each quotation is an exact string at the living file named, in the section NEW names (Natural Biology line 799 under 7.5, line 812 under 7.6, line 232 under 1.4, line 715 under 6.1, which has "The ingression" also; Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md line 500, step 103, and line 140, step 20); the three items, their order and "same-scale harm" are the prior's, the Registry as the other side at the second and the other sense at the third are what the source the prior names says (carryings/co_chaining_coverage_v378/readings/09_chemistry_biology_health_medicine.md, B at line 37 and item 8 at line 21) and no more, and the wait is said as a relation at the Registry in the closing sentence.
SAFER: -

### 4
CHECK: OK
WHY: Natural Biology line 655, under "## 5.3 Morphogenesis", has the quotation exactly, of the planarian's neoblast; carryings/v380R/Natural_Networking_From_v380A.md line 47 has the sentence beside "a self's carrying its own" and no more; NEW has 5.3, the neoblast, both sayings and "Neither is chosen", and the v386EOD droplet at the mate's line 400 ("Beside the concern at this mate of ...") still finds it by the quoted sentence and the word Concern.
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: OK
WHY: archive/session_v380/v380G/README.md line 16 has the row "Plants in wind | Growth halting at motion, light carried as form | An observing from a field, said more strongly than the field says it. For Natural Biology only as the field's own finding, sourced."; the prior is a one-line pointer naming that file, the two clauses NEW has beside the prior are that row's own words and nothing else (first reader's rule 4), and the receiving at the field's finding of growth changing under mechanical stress, the releasing, "Neither is chosen" and the file it is for are each in NEW.
SAFER: -

### 7
CHECK: OBJECT
WHY: The third saying is changed, and a relation with its negation is lost. The prior has "Natural Physics 1.1 says the difference among societies is scale alone". That sentence was at version 348's 1.1 (git 0eef2d2, Exhibit_EIGHTEEN_Natural_Physics_v348.md, "one living torusing at three prime societies and the difference among them scale alone") and is at no line of Exhibit_EIGHTEEN_Natural_Physics_v379.md now (1.1, lines 66 to 91, read whole; "scale alone", "three prime societies" and "difference among" searched in that file and in each living file at the root: none). NEW puts in its place five words of another sentence, "**Chemistry and Biology are the same method at their own subjects, the same form at each scale**" (line 90), whose subject is two sciences as one method; it says nothing of a difference among societies and has no "alone". So NEW gives Natural Physics 1.1 a saying the prior does not give it (an adding under the first reader's rule 11, the sentence quoted not being the one the paragraph is about) and drops the prior's claim, which is at no living file and no later section. The third sentence also closes NEW after "They part at" with no relation to the parting said, where the prior lays it as the third of three. The rest holds: "Below the atom no self closes" and "Atom is the floor, the first closing of the co-agency into a self" are exact at Natural Physics line 363 under "## 4.6 Strong force, three phases of one coupling" (3.6 at version 348), and "there is no fundamental self anywhere and no floor to the counting" is exact at Natural Biology line 221 under 1.3. No NEW in the first reader's form can carry the third saying, its sentence being gone, without narrating a version.
SAFER: KEEP

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: OK
WHY: Natural Biology line 375, under "## 3.1", and Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 393, under "## 5.4" (of omega-six and omega-three proportions), have the two quotations exactly; NEW has both files, both sections, cardiolipin, 1/φ² and the negation at the prior's strength.
SAFER: -

### 10
CHECK: OK
WHY: NEW's sentence is the prior's sentence word for word, with the words in italics as carryings/v368_sources/Wrap_v368.md line 73 has them, the releasing said as the prior says it and the aiming at the set said; it is the paragraph already checked sound for the same sentence at SO_1 and EQ_4b, and only the report's name and section are left out.
SAFER: -

### 11
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: OK
WHY: carryings/illustrating_v366/Session_Report_v366.md line 130 has the sentence and NEW has its five things in the prior's words and order with "a shared interest"; "supplied" is the source's own word for the transcript (line 128) and the v385A heading's; only the report's name, the kit's file and the re-aiming note are left out, and paragraph 18 beside it is re-said with it.
SAFER: -

### 18
CHECK: OK
WHY: NEW's three sentences are the prior's word for word (carryings/illustrating_v366/Session_Report_v366.md line 132), with *memory* in italics as a word Natural Naming has at its line 277; the two lists of four, Natural Intelligence by its name and the negation "do not by themselves establish the same operation" are each at the prior's strength.
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 39
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: TASK_second.md; the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file BI_1.txt (forty-one paragraphs); the PROPOSED file BI_1_report.md (forty-one blocks and its READING); the mate carry/Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md from its first line through the end of its older `## Droplets` section (lines 1 to 153), its headings to the last, and its section "Intelligence across scales and the supplied biology transcript · v385A" (lines 360 to 364).

The living file Exhibit_SEVENTEEN_Natural_Biology_v333.md is 35,858 words and was not read whole: its headings were read, and the lines of each quotation in a NEW were found by exact search and read with their sections (line 221 under 1.3, 232 under 1.4, 334 under 2.3, 375 under 3.1, 655 under 5.3, 715 under 6.1, 799 under 7.5, 812 under 7.6). Other living files, by exact search and the place read: Exhibit TWENTY Natural Naming (4.9 and its table, lines 603 to 622; the row of *memory*, line 277); Exhibit THIRTY Co-Chaining Logic Registry (step 20 at line 140, step 103 at line 500); Exhibit EIGHTEEN Natural Physics (1.1 whole, lines 66 to 91; line 363 under 4.6; its headings; and version 348 at git 0eef2d2 for the older 1.1 and 3.6); Exhibit SIXTEEN Natural Chemistry (line 393 under 5.4; the headings of part 5).

Sources read at the lines the first reader names: carryings/physics_for_other_files_v377/README.md (2.1 to 2.4); carryings/co_chaining_coverage_v378/readings/09_chemistry_biology_health_medicine.md (items 5 to 12 and contradictions A and B); carryings/v380R/Natural_Networking_From_v380A.md (lines 40 to 47); archive/session_v380/v380G/README.md (lines 1 to 34) and the record's own line on a plant in wind; carryings/v368_sources/Wrap_v368.md (line 73); carryings/illustrating_v366/Session_Report_v366.md (section 6).

Checked by search: carry/*.md for a pointer at this section's paragraphs ("concern at this mate", "droplet at this mate", "in this list", "the preceding", a link to this mate's #droplets): the v386EOD paragraphs at the mate's lines 400, 422 and 436, Carryings of Natural Biology line 162, Carryings of Living File Registry line 465 and Living Improving Value line 289 (both rows read; each NEW has the subject words those rows use); "scale alone", "three prime societies" and "difference among" in each living file at the root (none); each NEW for the barred words outside quotations and italics (none) and for its number of words (48 to 148); the same set-wide paragraph and the like pointers at other portions' reports and second readings (SO_1, EQ_4b, HP_1, NW_1, NN_3, EX_1, NI_1, CR_1, XP_1) for how each was judged.

The thirty-two KEEP blocks (2, 5, 8, 11 to 16, 19 to 41) change nothing and were not checked further. No block is RESOLVED, SAID or NOVALUE, so nothing is released.

Numbers: OK 8 (1, 3, 4, 6, 9, 10, 17, 18); OBJECT 1 (7); KEEP-UNCHANGED 32.
