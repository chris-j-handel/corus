### 109
VERDICT: KEEP
CONCEPT: The resolver's 0, a concern kept open at a mate with a kind of authority, has no place in the droplet method: a file at its motion couples each droplet one at a time, is or is not, and each dissolves; the 0 is the code's and not the working's.
EVIDENCE: A person's own words (rule 5): the correction "0 is a meaningless strange addition…" cannot be said at its strength without quoting it. Its negation is at no living file and at no later section: the living file still has "At 14 they surface at one sharing: agreeing, one; parting, 0, the concern, said with its reason." at 2.6, and the later sections (line 472 "Three files of the form, three places"; Offerings to Living File Registry, "Value visible at its place, and nothing waiting · v386EOD") say nothing of the 0 nor of two disagreeing droplets each coupled on its own. No pointer to it found.
NEW: -

### 110
VERDICT: KEEP
CONCEPT: The dropper's rule: each improving word may be duplicated as droplets at all, many or one mate; the dropper judges none, says only the file a droplet is for, and drops it whole with its source; and a task is measured ahead of its plan.
EVIDENCE: A person's own words (rule 5). Parts are said later (Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A": "A general improving droplet … can be repeated at every affected offering mate", "No grade or required execution precedes gathering."; this mate, "A droplet's aiming at one of six degrees · v386EOD"), but "dropped whole with its source" and the measuring of a task ahead of any plan are said at no later section or living file, so not SAID whole.
NEW: -

### 111
VERDICT: KEEP
CONCEPT: Pace and harm: no rush; each stopping point leaves the set healthy; droplets laid at more files than needed resolve away later; harder content is left for later; the plan is redone at each few steps.
EVIDENCE: A person's own long unpunctuated saying (rule 5), carrying more claims than a re-saying of the allowed length can carry at their strength. Later sections say only parts (this mate, "Droplet · Nothing vanishing, nothing finished." under "A next work understood by both… · v386EOD"). The living file's 1.6 has "a session closes at any pass and harms nothing", which is one of its several claims only.
NEW: -

### 112
VERDICT: KEEP
CONCEPT: A conversation about the method stays at the method; a working's doings at the repository are said in one line or not at all.
EVIDENCE: A person's own words (rule 5), a correction whose claims ("stay on this subject and be valuable in this plan", the method as a stable form of the set and the ways it is accessed, used and improved by humans and AI) cannot be said at their strength without quoting. Not said whole at the living file (2.3 has "The report at each handing on is this momentary" only) nor at a later section.
NEW: -

### 113
VERDICT: RESAY
CONCEPT: A question unanswered in words: the naming is what makes an interest an interest at the set, so Natural Naming is the surface the whole set couples at; does that change Natural Naming's place.
EVIDENCE: Value at no later section (searched carry/*.md for "surface the whole set couples", "one exhibit among thirty": only older Droplets sections of this mate, Offerings to Natural Arriving and Offerings to Living File Registry). The paragraph is a session's question with waiting language ("left standing", "A decision for the self, gathered with the plans"). The fact it names is verified: Natural Arriving v381R has "THREE · THE NAMING, THE MEMBRANE" among its contents. Source checked at carryings/v381R/Session_Transcript_v381R.txt lines 479 and 486. No pointer to it found.
NEW: **Droplet · The naming as the *membrane* of the set.** A question at the point the stable form of the set rests on. The files' form makes an interest self-welcoming, and the files' form is the naming: an interest arriving in its own words is no interest at the set, and it becomes one at its saying in the set's one name for each concept. By this the naming is the *membrane*, and Natural Naming is no one exhibit among thirty and is the surface the whole set couples at. The expedition's self gave no answer in words and entered "THREE · THE NAMING, THE MEMBRANE" at Natural Arriving's contents. Two things are asked: is this right; and, being right, does it change the place of Natural Naming. The deciding is the expedition's self's, and it is gathered with the plans.

### 114
VERDICT: KEEP
CONCEPT: The Geodesic Improving Method is itself to be redone by the mates' method and is no special case: it is the first file the method thins, its lesson log leaving for the carryings if the form coheres; file size and the tags are set aside.
EVIDENCE: A person's own words (rule 5): an intention ("is going to be redoing itself as this method") and a setting aside ("file size is meaningless as we are the only ones using this") that cannot be said at their strength without quoting. The living file still has "This file is the method, and it empties at no pass." Later sections say parts only: this mate, "Concern · Emptying at no pass beside a record named a store." (v386EOD), and Possibling of Geodesic Improving Method, "Possible project · Part FOUR's worked instances at the carryings mate." (v386EOD).
NEW: -

### 115
VERDICT: RESAY
CONCEPT: Droplets cluster at the files the expedition has attended to; the ten files at versions 329 to 333 have the fewest and are the furthest behind; a first round of resolving does not by itself move them.
EVIDENCE: Part is said later: Possibling of Living File Registry, "Possible project · Ten files at the oldest versions read whole for droplets." (v386EOD) has "Droplets aimed across the set by a working's own interest reach these ten least". Left unsaid there and at each living file: the numbers at each file, the first round of resolving moving none of the files most needing it, and this as the first thing the form made visible. The paragraph is in a session's words with a transcript line; source checked at carryings/v381R/Session_Transcript_v381R.txt line 691. No pointer to it found.
NEW: **Droplet · Droplets cluster at the files the expedition has attended to.** At 3,398 droplets laid, Exhibit THIRTY Co-Chaining Logic Registry had 425, Exhibit ONE Natural Resolver 325, Natural Intelligence 297 and Exhibit TWENTY-EIGHT Equilibria Registry 291; Natural Destinies had 11, Natural Health 19 and Exhibit TWENTY-FIVE Living Society Registry 13. The ten files prior to momentarying, at versions 329 to 333, have the fewest droplets and are the furthest behind. Droplets laid at more files than needed reach none of the ten, nothing having been aimed at them. A first round of resolving, at whichever files, shows the method working and by itself moves none of the files most needing moving. This is the first thing the form made visible that was not visible ahead of it.

### 116
VERDICT: KEEP
CONCEPT: An arrival dissolves from incoming as it is dropletted into the offering mates it aims at; the dissolving completes only at the folder's address changing too, a folder named a carrying and still at incoming being unmoved.
EVIDENCE: A person's own words (rule 5), a question whose own concept (the offering mate as "the next incoming") cannot be said at its strength without quoting. The work the answer names is done (the folders are at carryings/, and incoming/ has README.md, v385A and v386EOD alone), but the relation, moved in standing and unmoved in address, is at no living file and no later section.
NEW: -

### 117
VERDICT: RESOLVED
CONCEPT: A living file is not changed by the working that receives its droplets; the Geodesic Improving Method's motion at v381R was an overstep, withdrawn to version 380R with the proposal laid whole at carryings.
EVIDENCE: Exhibit TWENTY-FOUR Geodesic Improving Method v380R, 1.4: "nothing enters a living file at its arriving, and nothing enters it in the working that receives it." Exhibit TWENTY-SIX Living File Registry v381R, the row of TWENTY-FOUR: "v381R: a motion at the form proposed and withdrawn to `carryings/geodesic_improving_method_v381R_proposed/`, the file at v380R and its insertlets at its offerings". The living file is at v380R at the root. What is left in the paragraph is that session's saying of its own work at that momentary (only laying, receiving). No pointer to it found; this mate's "Concern · A finding about working, placed or dropped." (v386EOD) has the same living sentence.
NEW: -

### 118
VERDICT: RESAY
CONCEPT: What four fresh readings found at the proposed and withdrawn motion: many things entered as one; a conversation's word entered over the file's own word for one concept; a measure word; one word naming the whole carrying and one mate; and instances staying, their release not leading their arrival.
EVIDENCE: Parts are said later, each further than here: this mate's "Concern · The carrying named one file beside mates at each file." and "Concern · One word, release, at a value entered and a concern out." (v386EOD), and Possibling of Geodesic Improving Method, "Possible project · Part FOUR's worked instances at the carryings mate." (v386EOD). Left unsaid at each later section and living file: four readings making the motion one thing, the first form entering all 33 insertlets, the file's name over the conversation's, and *standard* found a measure word. In a session's words with a transcript line; source checked at carryings/v381R/Session_Transcript_v381R.txt lines 712 to 718. The living file's sentence is "A delivery is an adding at each receiving file and never a sweep at its source, so the release follows the arrival and never leads it." No pointer to it found.
NEW: **Droplet · A motion made one thing at four fresh readings.** An observing of resolving. The motion proposed for Exhibit TWENTY-FOUR Geodesic Improving Method at session v381R, later withdrawn, became one thing at four fresh readings. Its first form entered all 33 insertlets, and its reader found many things and no one thing. A reader found the word *dissolve*, the expedition's self's word, entered at a file having *release* as its own word for nothing in its place from the writing of 1.4 and 1.6: one name for each concept, and the file's name prevailed over the conversation's. A reader found *standard* a measure word. A reader found the carrying naming both the whole and one mate. A sentence of the file carried, "the release follows the arrival and never leads it": Part FOUR's instances stayed, the carryings having none of them at that motion.

### 119
VERDICT: KEEP
CONCEPT: The order of the work: receiving completes and incoming is vacant, then the offerings are improved toward the living files, bottom rising; the living file's body is at neither.
EVIDENCE: A person's own words (rule 5). The order is said in part at Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A", and its saying of a step coming only after another is later corrected at "Value visible at its place, and nothing waiting · v386EOD"; "bottom rising in resolving and explaining value toward top" and the living file's body at neither are at no later section, so not SAID whole.
NEW: -

### 120
VERDICT: KEEP
CONCEPT: No decisions are made at a session of receiving: plans and options gather as droplets near each other for a session whose one work is deciding, and good and bad ideas find their own way in and out by the method.
EVIDENCE: A person's own long unpunctuated saying (rule 5), with more claims than a re-saying of the allowed length carries at their strength. Later sections say parts only (Offerings to Living File Registry, "The floating plan of the living expedition · v385A": "Plans may differ and remain near one another").
NEW: -

### 121
VERDICT: KEEP
CONCEPT: A droplet's language is read for its naming at resolving and not at receiving; a session's last report is laid as it is, marked as its last, and re-said at the file's naming or dissolved at resolving.
EVIDENCE: A person's own words (rule 5); the claim "the incoming vetting may pick that up next round" is at a strength (may) and a naming (incoming vetting) not sayable without quoting. Parts are at Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A" ("No grade or required execution precedes gathering."); the marking of a session's last report is at no later section or living file.
NEW: -

### 122
VERDICT: RESOLVED
CONCEPT: The method is brought current for the other workings as they work, their arrivals (session v382A's droplets expected, session v383Op's 95 droplets) are received whole, and the method's own improving is received as any file's is.
EVIDENCE: Exhibit TWENTY-FOUR Geodesic Improving Method v380R, 2.8: "**One working manages the set.** It receives each working's files whole at `main`, offers each motion to each working at one share in its own folder at `incoming/`, and brings the Living File Registry's table of workings current at each receiving." and "Work arriving from another working is taken in whole, at do-no-harm."; 2.4: "Their files are files of the set, met at the same binary."; 1.3: "A finding about working rides there, at this file's own section, and arrives here as its next." Exhibit TWENTY-SIX Living File Registry v381R, table of workings: "| The session v383Op | v383 | Through the AI link, asked to break the method: thirty findings at the code, the logic, the observings and the presentation, eight scripts; its folder at `carryings/v383Op/` | `working/exploring-v383Op` | Arrived; its 95 droplets received at the offerings at v381R |" and, at the row of the logic working v382A, "its droplets expected at their offerings". The rest is that session's saying of its own doing. No pointer to it found.
NEW: -

### 123
VERDICT: RESAY
CONCEPT: Resolved is a momentary of a file's offerings and no lasting condition: each round of re-aiming at the set sends droplets again to files resolved earlier.
EVIDENCE: Part is at the living file, 1.6: "Each file is floating neutralling and improving, and none is ended or complete."; and at this mate's "Droplet · Nothing vanishing, nothing finished." (v386EOD). Left unsaid at both (rule 3): the relation to re-aiming, the form predicting the flow, and the numbers after the re-aiming at nine files. In a session's words with a transcript line; source checked at carryings/v381R/Session_Transcript_v381R.txt lines 852 and 905. No pointer to it found.
NEW: **Droplet · Resolved, a momentary of a file's offerings.** Re-aiming sends a droplet to the file it is for, and each round of it at the set sends droplets again to files resolved earlier: a file is at no round resolved once and finished. The form predicts this flow, and by it resolved is a momentary and no *standing*. At a re-aiming at nine files, several hundred droplets went to the files they were for, and files passed early had new droplets at the bottoms of their offerings again: Exhibit TWENTY-EIGHT Equilibria Registry at 257 raw droplets after its pass, Natural Physics at 263, Exhibit TWENTY-FOUR Geodesic Improving Method at 89.

### 124
VERDICT: KEEP
CONCEPT: At a session of dropletting the living files are not written; the value is droplets gathered across each file, each later improving pass being one familiar method.
EVIDENCE: A person's own words (rule 5). Its first part is a plan of that session, but its reason, that each later improving pass is similar and familiar across the files, is a saying of the method at no living file and no later section, so not NOVALUE (rule 6).
NEW: -

### 125
VERDICT: RESAY
CONCEPT: The scan across the set: one reader for one released word or dissolved naming reads each file and drops at each file having it; a scan droplet is a map of places and no sentence.
EVIDENCE: At no living file. Later sections say parts only: Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A" ("A general improving droplet, such as dissolving a name and its explaining wherever it occurs, can be repeated at every affected offering mate"); the one reader for one word, the four kinds of reader and a scan droplet as a map are at none. This mate's paragraph on a scanning reader at 3.3 is in the older Droplets section and is no later place (rule 1). In a session's words with a transcript line; source checked at carryings/v381R/Session_Transcript_v381R.txt lines 860 and 903. No pointer to it found.
NEW: **Droplet · A scan across the set, one reader for one word.** Session v382F's scanning, made set-wide, has one reader for each released word or dissolved naming, *run*, *sign*, *face*, *connector*, *membrane*, *ring*, *count* and *store*: the reader reads all 33 files for it and drops at each file having the word at the file's own voice. One reader reads for the old resolver names at each file still carrying them, one for *ring* said as closure, and one for the five dimensions and the ten. Each is a mechanical pass landing droplets at exactly the files needing them, and droplets laid across more files than needed earn their value at it. A scan droplet is a map and no sentence, *membrane* at 84 places with four section titles and their line numbers among them: the right form for a motion touching 84 places at once.

### 126
VERDICT: KEEP
CONCEPT: The clusterings of droplets show how to cohere the learnings across each file, the longest unimproved among them: the scans make a second map, nearly uniform across the sciences and the files at versions 329 to 333, so their first motions are one motion.
EVIDENCE: A person's own words (rule 5): "we will be able to see how to cohere this set of learnings" is a saying of a next not sayable at its strength without quoting, and the session's numbers (7 of 7 concepts at nine named files, 2 of 7, 1, twenty-six files) are of one momentary of the scans. Part only is at Possibling of Living File Registry, "Possible project · Ten files at the oldest versions read whole for droplets." (v386EOD).
NEW: -

### 127
VERDICT: KEEP
CONCEPT: The aim is the quality of the incoming offerings in front of each living file and not resolved living files; a pass at a file's offerings raises raw droplets into insertlets, dissolves what the file has, sends on what is another file's and gathers plans.
EVIDENCE: A person's own words (rule 5): the correction "our aim is the quality of all the incoming offerings into the living files, not resolving living files" is not sayable at its strength without quoting. Parts are at Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A" ("Aiming alone supplies no insertlet or completed resolving."); the aim itself is at no later section.
NEW: -

### 128
VERDICT: RESAY
CONCEPT: A condition on the insertlets and dissolvings of session v381R's pass: each was one reader's, read by no second; about twenty droplets were not re-aimed.
EVIDENCE: A condition laid on other paragraphs, this mate's section Insertlets among them (rule 6), at no living file. This mate's "Droplet · A second reader's one question at each insertlet." (v386EOD) says what a second reader asks and how an insertlet fails; it does not say that these insertlets and dissolvings had one reader each, nor the twenty droplets left at their first mates. In a session's words with waiting language ("for the next resolving round", "has not yet run"); source checked at carryings/v381R/Session_Transcript_v381R.txt line 905. No pointer to it found.
NEW: **Droplet · Insertlets and dissolvings of one reader.** The insertlets laid at the offerings at session v381R were each written by one reader, with no second reader, and some among them are likely a reader's reading said as the file's fact, the failing the readers of session v377 named most often. The dissolvings of that pass, each saying its file has a droplet's value already at a named section, are one reader's judging, read by no second. Re-aiming matched droplets by their first words; about twenty across the set matched none and stayed at the mates they were laid at. An insertlet of one reader is an insertlet tagged in all but name. A second reader at the insertlets is the reading the flow had made at none of them at that pass.

### 129
VERDICT: KEEP
CONCEPT: An observing of the set at session v381R's close: the numbers of insertlets, raw droplets, scan droplets and plans at the mates, nothing discarded, each dissolved droplet whole at its carrying, and what the form made visible.
EVIDENCE: Its numbers (92,000; 576,000; 454; 1,222; 178; 492; fifteen files) are one session's account of one momentary, and its conditions (nothing discarded, each dissolved droplet whole at its carrying; each file's next motion in one paragraph at the front of its offerings, hardest first) are at no living file and no later section, so not NOVALUE (rule 6). A re-saying within the allowed length does not carry each number and relation at its strength without narrating the session; left as it is. Source checked at carryings/v381R/Session_Transcript_v381R.txt line 901.
NEW: -

### 130
VERDICT: RESAY
CONCEPT: The living file as the finest saying of its subject is a more-or-less unless a working never chooses between two cohering sentences and makes the one carrying both; two sayings that cannot be coupled are the concern, and the one case to break the three-file form.
EVIDENCE: The answer is at the living file, 5.2: "The geodesic deciding is the coupled form, and never a choosing." and "neither variant refuted, each variant's own face carried in the coupled saying". This mate's "Concern · A sentence at the method alone, and at Exhibit ONE." (v386EOD) names the ranking words as a second parting and gives it no resolving. Left unsaid at both: the aim carrying only with no choosing between two sentences, and the uncoupled pair as the one case to break the form. In a session's words with a transcript line; source checked at carryings/v381R/Session_Transcript_v381R.txt line 230. Exhibit TWENTY-SIX Living File Registry has "The three-file form at each living file, living, offerings and carryings". No pointer to it found.
NEW: **Droplet · The finest saying, and the coupled form.** The living file as the finest, clearest and most cohering saying of its subject is one aim. A working at a file with two sentences both cohering, choosing the finer, makes a more-or-less, the one thing the method has as not possible. The method's own answer is at Exhibit TWENTY-FOUR Geodesic Improving Method: "The geodesic deciding is the coupled form, and never a choosing.", "neither variant refuted, each variant's own face carried in the coupled saying". The aim carries only with a working at the living file choosing at no momentary between two sentences and making each time the one sentence carrying both. Two sayings that cannot be coupled are the concern, and it is the one case to break *the three-file form*.

### 131
VERDICT: KEEP
CONCEPT: An uncertainty coming again is followed at its actual relation: the same assertion at the same subject and conditions, or a relation changed by a source, an observing or a correcting; recurrence alone gives neither precision nor a verdict.
EVIDENCE: Another paragraph points at it (rule 2): this mate's "The Method is the Resolver at the Expedition Scale · v385A" has "This extends the existing uncertainty-and-return droplet", and Carryings of Living File Registry has "Whole droplet aimed beside the existing uncertainty-and-return concept." Its subject word is one the present naming releases, so a re-saying loses the pointer; its named places (Corus 16.4, THIRTY 570 and 571, 2.2 and 2.6, the linked 16.4 comparison) stay with it. The living file has what it cites: "A correction belongs at the first relation that departed." and "A missing relation, a special case and a contradiction are three different findings."
NEW: -

### 132
VERDICT: KEEP
CONCEPT: A later correcting laid beside the older concerns at 2.6 and 2.7: equilibrium as unchanging social competency parted from a stable form, and a break named as observed competency lacking alternating or natural torusing; one session's closure removes no other session's passages.
EVIDENCE: It qualifies paragraphs ahead of it in the same older section ("The older stable-form, recognizable-break and framing concerns remain whole above"), which are outside this input, and it stays with them (rule 2). Carryings of Living File Registry points at the same concerns as whole at this mate. Its negation ("M's closure does not remove v383Op's distinct passages or supply v385A's independent scientific verification") is a condition on them (rule 6), and its linked sources cannot be carried in a re-saying.
NEW: -

### 133
VERDICT: KEEP
CONCEPT: A comparison of a source with its placements carries the whole relation: the source and its extent, its contribution, what a living passage has, the remaining improving at each mate and any unlocated value; a same-named concept establishes no complete receiving.
EVIDENCE: Already a concept in plain voice, of session v385A. Part is at the living file, 1.5: "Word-streaming locates a loss of words and no more: every word surviving is no relation surviving". The rest is at no living file; Offerings to Living File Registry, "Gathering and aiming incoming before file cohering · v385A", has only "Only actual resolving in that living file removes its local offering". Its named places (three linked files at incoming/v385A/, verified present) and its many conditions do not fit a re-saying without narrowing (rule 4).
NEW: -

### 134
VERDICT: KEEP
CONCEPT: A sentence entered and replaced within one session can be absent from both the opening and the final version; the offering, the intermediate explaining, the later correcting and the present passage are compared together.
EVIDENCE: Already a concept in plain voice, of session v385A, at no living file and no later section (the living file's 4.5 has "a saying corrected later in the session arrives as corrected, with its correcting", which is a part only). Carryings of Living File Registry's row for this mate names it ("intermediate-source preservation"). Its instance and its linked source (incoming/v385A/Protecting_Source_Comparison_v385A.md, verified present) stay with it.
NEW: -

### 135
VERDICT: KEEP
CONCEPT: A concern is said in the files' own names ahead of any absence said; a link a reading adds between two sayings is the reading's; a newer report locates a difference and has no value by its newness.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Session v384A's working gathered · v386EOD", names it by its title as placed at this mate (rule 2). Said whole at no other later section.
NEW: -

### 136
VERDICT: KEEP
CONCEPT: A logical gap found is carried on as another relation is followed; a thing unread is next exploring and no concern, and a concern is a thing unresolving.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Session v382A's logical working, gathered · v386EOD", names it by its title as placed at this mate (rule 2).
NEW: -

### 137
VERDICT: KEEP
CONCEPT: The logical pass between a droplet and an insertlet: one subject, relation, extent and momentary followed through both sides, bothboth first, the first departing relation found, and what the pass brings.
EVIDENCE: Another paragraph points at it by its title (rule 2): this mate's "Following a concern: its subject, its conditions, and its correcting beside it · v386EOD" has "It is beside [The logical pass between a droplet and an insertlet]", and Carryings of Living File Registry names it as placed at this mate. Already a clear concept in plain voice.
NEW: -

### 138
VERDICT: KEEP
CONCEPT: Nothing is outside natural intelligence; a further bridge asked between a living process and natural intelligence adds nothing.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Session v382A's logical working, gathered · v386EOD", names it by its title as placed at this mate (rule 2).
NEW: -

### 139
VERDICT: KEEP
CONCEPT: An either this or that and not both remaining is parity alternated, as the two were already; no word decides between them.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Natural Intelligence Corus and Gathered Value 3 and 4, gathered · v386EOD", names it by its title as placed at this mate (rule 2). The insertlet at 2.6 of this mate that says a like thing is no later place.
NEW: -

### 140
VERDICT: KEEP
CONCEPT: An explaining to improve is no incohering of concept; an incohering is two sentences, or a sentence and a row, giving one case two parities; a working is no regulator of an offering.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Natural Intelligence Corus and Gathered Value 3 and 4, gathered · v386EOD", names it by its title as placed at this mate (rule 2). The living file's 2.6 has three findings ("A missing relation, a special case and a contradiction are three different findings."), not this fourth.
NEW: -

### 141
VERDICT: KEEP
CONCEPT: A reply says the next one thing, how the working does it and the one concern another self can help with; a saying of nothing unresolved is read by a fresh reader asked to break it, and a mended sentence by a reader other than its mender.
EVIDENCE: Already a clear concept in plain voice and the present naming, with no waiting language. Carryings of Living File Registry, "Natural Intelligence Corus and Gathered Value 3 and 4, gathered · v386EOD", names it by its title as placed at this mate (rule 2). The living file's 2.3 has "The report at each handing on is this momentary" and its 2.6 has "Concerns ride visible and are worked one at a time, the most concerning first.", parts only.
NEW: -

## READING
Each of the thirty-three paragraphs, 109 to 141, was read whole and checked. Read whole: the brief; the living file Exhibit TWENTY-FOUR Geodesic Improving Method v380R; this mate's front sections, its section Insertlets, and each of its later sections headed · v385A and · v386EOD (lines 1 to 97 and 383 to 630); the paragraph openings of the whole older section Droplets, for pointers; Offerings to Living File Registry's front sections and each of its later sections; Natural Arriving v381R's contents. Read in part by search: Exhibit TWENTY-SIX Living File Registry v381R (its table of files, its table of workings and its sentence on the three standings), Carryings of Living File Registry (the placement tables of its sections headed · v386EOD and its rows for this mate), Carryings of and Possibling of Geodesic Improving Method, Possibling of Living File Registry (its section from session v381R's carrying), Offerings to Natural Arriving and Offerings to Natural Naming (headings and the sections drawn from session v381R), and each file of carry/ by search for the titles and pointers named above. Sources: paragraphs 109 to 130 are in carryings/v381R/Close_Droplets_v381R.md, and the session-quoted sentences of 113, 115, 118, 123, 125, 126, 128, 129 and 130 were read at carryings/v381R/Session_Transcript_v381R.txt at the lines the paragraphs name. Each living-file sentence quoted in a NEW or as RESOLVED evidence was verified by exact search in the present living file.

Three things to know. Paragraphs 131 to 141 are within the older section Droplets but carry the tags of sessions v385A and v386EOD and are in those sessions' naming; none was treated as an older pointer. For paragraphs 109 to 130 the later sections drawn from session v381R's carrying say of themselves that a thing a mate says already is not said again, so few of these paragraphs are said whole at a later place; of the fourteen with a person's own unpunctuated words, twelve were left as they are under rule 5, and two (117 and 122) are RESOLVED, each claim of theirs at a living-file sentence given exactly. Not found: the seven concepts of the scans that paragraph 126's numbers are of are named in the transcript (line 882) with an eighth beside them, so the paragraph's "7 of 7" could not be laid at seven named things with certainty; and no place was found that says whether a second reader has since read the insertlets paragraph 128 is a condition on, so its NEW says that pass alone.
