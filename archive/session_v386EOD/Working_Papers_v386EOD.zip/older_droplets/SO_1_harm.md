### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: OK
WHY: The prior at the mate's line 51 laid beside NEW: NEW's second sentence is the prior's one sentence word for word (Across the set; each file; read, turn, held and holding; stable form as a noun; its namings of other exhibits; at its own improving; in the shared words), with the italics of its source, carryings/v368_sources/Wrap_v368.md line 73, read there; the releasing is said as the prior says it, neither as done nor as possible work; NEW has no quotation, no number, no session narrated and no waiting; its title says no more than the sentence; "It is aimed at the set." re-says the prior's own "Across the set" (rule 10) and narrows nothing; NEW is forty-eight words; the only thing left out is the report name and section "(Wrap_v368.md, §4 What each file carries next, Across the set) — v368_sources", a source pointer the first reader's brief sets apart from the concept and bars from NEW, the source sentence still at that file by exact search; no paragraph of the mate or of carry/*.md points at this copy by "above", "the preceding" or a link to its wording, and the Living File Registry carrying's row linking to `#droplets` still finds it by the same subject words.
SAFER: -

### 7
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its "Further rules"; the PRIOR file SO_1.txt; the PROPOSED file SO_1_report.md; the living file Exhibit_SEVEN_Natural_Societies_v373.md (about 6,500 words); the mate's `## Droplets` section, lines 39 to 57 of carry/Exhibit_SEVEN_Offerings_to_Natural_Societies.md, with the mate's list of headings.

Checked by search and by reading the lines found, for paragraph 6, the one block that is not KEEP: carryings/v368_sources/Wrap_v368.md lines 65 to 73 (the source sentence, with its italics, and the sentence following it on Natural Naming and Natural Explaining, which the prior does not have and NEW does not add); every copy of "namings of other exhibits" across the repository (about twenty mates' older sections, and the already re-said copies at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md lines 199 to 219); carry/Exhibit_SEVEN_*.md for "Wrap_v368", "What each file carries next" and "shared words" (the one place is the paragraph itself); the mate and its two fellow mates for pointer phrases ("the concern at this mate of", "the droplet at this mate of", "above", "the preceding", "existing concern", "current droplet": two found, at the mate's lines 211 and 277, both of other subjects); carry/*.md for links to this mate (each to a later headed section, save the Living File Registry carrying's row at line 492 linking to `#droplets`, read whole); carry/Exhibit_SEVEN_Possibling_of_Natural_Societies.md line 46; Exhibit_TWENTY_Natural_Naming_v380R.md lines 223, 232, 239 and 297 (the released words NEW cites in italics are that living file's own). In the living file read whole, *read*, *turn*, *held* and *holding* are still at its own voice (5.1, 5.6, 4.6, 2.3), so the paragraph is not resolved and a re-saying, not a release, is the fitting change.

The eight KEEP blocks leave the mate's paragraphs exactly as they are and were not checked further. No file other than this report was written or edited.
