### 88
CHECK: OK
WHY: the proposed file's 5.9 (line 604, "are each proposed at their form and at their relation") and its 4.3, 4.6 and 4.7 (lines 400, 439 and 465, each "to be said"), with the review's 2.2 (README line 51); each claim and place of the prior is in NEW, and NEW has no quotation.
SAFER: -

### 89
CHECK: OK
WHY: the proposed file's 2.1 (line 129) and 3.4 (line 240), the proposal's report at its 6.1, "Concerns shared with another file", items 2 and 3 (README lines 102 to 108), and the review's 2.2; *the white paper* is Natural Intelligence (the proposal's own 3.4 cites Natural Intelligence 4.13), "of concerns with another file" is the heading of the place the prior names and no claim, and NEW is word for word the paragraph at carry/Offerings_to_Natural_Intelligence.md line 137 with the review's place beside it.
SAFER: -

### 90
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 91
CHECK: OK
WHY: the proposed file's 3.15 (line 360, "One ordering is checkable at public archives") and the review's 2.2; "about half" is said as about one in two, the same number, and the contested ordering and the foreshocks are carried at the prior's strength.
SAFER: -

### 92
CHECK: OBJECT
WHY: Added. NEW has "at a drying drop's rings: a spacing at a ratio read as the alternating floating, and a spacing at a fixed step as the alternating fixed". The prior has none of it, and its source, the review's 2.2 (carryings/review_natural_physics_v377/README.md line 51), has only "3.16's *ratio against a fixed step* is no discriminator without its model, the stick-slip model already giving a radius-dependent spacing". The clause is the first reader's own re-saying of the proposed file's line 368, which has "is read as the floating alternating", its words in another order than NEW's; two readings of the proposal are laid beside the prior that the prior does not carry (the first reader's rules 4 and 11). The rest of NEW is the prior whole: 3.16, the ratio against a fixed step, no discriminator without its model, the stick-slip model, the spacing dependent on the radius, the review's 2.2.
SAFER: **Droplet · A ratio against a fixed step, no discriminator without its model.** The proposed Natural Physics of version 377 has, at its 3.16, a ratio against a fixed step. The ratio against a fixed step is no discriminator without its model: the stick-slip model already gives a spacing dependent on the radius. The review of that proposal, at `carryings/review_natural_physics_v377/`, has it at its 2.2.

### 93
CHECK: OK
WHY: Natural Physics 2.5, lines 148 to 154, the column "the refusal" and its five rows, both cells quoted exactly; the proposed file's 2.5 table (line 163, "the binary it carries"); the review's 2.3, item 1; version 348's 2.5 is at 2.5 now (version 348's headings read from the repository's history).
SAFER: -

### 94
CHECK: OK
WHY: Natural Physics 2.7 (line 172, the Bell sentence) and 4.4 (line 304, the sentence quoted exactly); version 348's 2.6 and 3.4 are at 2.7 and 4.4 now (version 348's headings read); the proposed file's 4.4 step 6 (line 414, "the field's exclusion … its own result"); the review's 2.3, item 2, which paragraph 120's "lost at 2.3.2" still finds.
SAFER: -

### 95
CHECK: OK
WHY: Natural Physics 2.6, line 164, both quotations exact and in one sentence; version 348's 2.7 is at 2.6 now; the proposed file's 2.6 (line 183, "is consistent with the theory") and 2.8 step 7 (line 205); the review's 2.3, item 3.
SAFER: -

### 96
CHECK: OBJECT
WHY: Two things, found at Natural Physics 4.6. (1) Changed by its place: the quotation "the electron is a ledger beside them" is exact (line 363), but at the living file *them* is the proton and the neutron ("the proton and neutron are the coupling's two faces … and the electron is a ledger beside them"), and NEW lays it straight after the list of ghosts of line 365, a sentence of another paragraph, so that *them* reads as the ghosts; the prior has only "the electron as a ledger". (2) Narrowed: the prior has the lost value as the list, "vacuum, virtual particles and binding among them", three named among more; NEW's "They part at vacuum, virtual particles and binding" has the parting at those three alone, and the list NEW itself quotes has *conservation* beside them, which is at the proposal's seam no more than they are (proposed 5.3, line 570: force, a field, a potential and energy). The places are right: version 348's 3.6 is at 4.6 now, the proposal's seam is at its 5.3, the review's 2.3, item 4.
SAFER: **Concern · The sub-atomic ghost list at 4.6, beside a seam at force, field, potential and energy.** Two sayings part. Natural Physics has, at 4.6, its sub-atomic list of ghosts, "energy, field, vacuum, virtual particles, binding, conservation", and, of the electron, "the electron is a ledger". The proposed Natural Physics of version 377 has, at its 5.3, a seam with Exhibit TWENTY-SEVEN Living Ghost Registry at force, field, potential and energy alone. They part at the list, vacuum, virtual particles and binding among its ghosts, and at the electron as a ledger: at the one, and lost at the other. The review of that proposal, at `carryings/review_natural_physics_v377/`, has it at its 2.3, item 4, a prior value lost.

### 97
CHECK: OK
WHY: Natural Physics 4.7, line 389, both quotations exact ("one form at the crystallographic substrate — is the reading"); version 348's 3.7 is at 4.7 now; the proposed file's 3.10 (line 308) has the lattice and no diamond form; the review's 2.3, item 5.
SAFER: -

### 98
CHECK: OK
WHY: Natural Physics 4.7 (line 387, of the Wick rotation) and 3.4 (line 221, of the light-cone), both quotations exact; version 348's 3.7 and 5.8 are at 4.7 and 3.4 now; the proposal's report at its 6.2 (README lines 113 to 133, 3.13 and "4.7's Wick rotation" each "still to be named"); the review's 2.3, item 6, whose "to be named" NEW carries as the prior has it.
SAFER: -

### 99
CHECK: OK
WHY: Natural Physics 4.9, line 427, both quotations exact, the first at DESI and the second at JWST; version 348's 3.9 is at 4.9 now; the proposed file's 4.9 step 8 (line 488, "each contested at its sources"); the review's 2.3, item 7.
SAFER: -

### 100
CHECK: OK
WHY: Natural Physics 5.3, line 509, both group names exact; version 348's 4.5 is at 5.3 now; the proposal's report (README line 45, "The old sorting at *a frame standing outside*, now at 2.5's binaries"); the review's 2.3, item 8; fifteen, four and nineteen are said as the review's, as the prior has them.
SAFER: -

### 101
CHECK: OK
WHY: Natural Physics 4.2 (line 261) and 3.3 (line 217), both quotations exact; version 348's 3.2 and 5.7 are at 4.2 and 3.3 now; the proposed file's 4.2 (line 386), its 4.5 heading and its 3.12 (line 334); the review's 2.3, item 9; both reversals and both *unmarked* are in NEW.
SAFER: -

### 102
CHECK: OBJECT
WHY: Lost: Natural Biology. The prior has "4.1's four-level partner of Natural Biology's five-level table", the review's own naming of whose table it is (README line 63). NEW has only the living file's words, "the four-level partner of biology's five-level table" (Natural Physics 3.1, line 197, exact), and *biology's* in a small letter names no file; the first reader's own EVIDENCE has this paragraph's copy at this mate's line 492 as re-aimed from Offerings to Natural Biology, the relation the name carries. The living Exhibit SEVENTEEN Natural Biology has no *five-level* at any line (searched), so the naming is the review's and is said as the review's. The rest is right: version 348's 4.1, 4.3 and 5.10 are at 3.1, 3.5 and 3.2 now (lines 197, 229 and 213, each quotation exact), 114, 120 and 126, the review's 2.3, item 10, and minor.
SAFER: **Droplet · Lesser sayings of Natural Physics lost at the proposed version 377.** Natural Physics has, at 3.1, the periodic table as "the four-level partner of biology's five-level table"; at 3.5, "the one place the seeking ends is the apex"; and at 3.2, of 114, 120 and 126, "Couples to the trefoil and to the classification reading above." The review of the proposed Natural Physics of version 377, at `carryings/review_natural_physics_v377/`, has the three at its 2.3, item 10, the first as the four-level partner of Exhibit SEVENTEEN Natural Biology's five-level table, each a prior value lost at that proposal, and minor.

### 103
CHECK: OBJECT
WHY: Two things, found by laying NEW beside the prior and the review's 2.4 (README line 65). (1) Changed: the things found are the proposal's own words of itself, and NEW re-says two of them with the word that is the finding taken out. The prior has "5.4's this part gathers the file's cases" and "2.5 and 5.11's this file's own, at no registry entry" (proposed lines 574, 618 and 619, "This part gathers the file's cases", "this file's own, at no registry entry"); NEW has "its 5.4 has the part gathering the file's cases" and "its 2.5 and 5.11 have the file's own". *This part* and *this file's* are the file speaking of itself; *the part* and *the file's* are not. (2) A place made unsure: NEW's one sentence has "at its 2.4" of the review and then "its 3.1", "its 3.6", "its 4.1" and on of the proposal, one word for two files; the review has a section 3 with numbered items of its own (paragraph 120 of this same section says "2.3.2" for an item), so "its 3.1" can be read as the review's. The rest was checked and is carried: the two folders, eleven, 4.13 at v379, the reviewer's verdict, the case still to come, step 319, 7.3, coordinates for names, Exhibit TWELVE Natural Explaining 1.4 (line 84, "no voice but the file's"). Paragraph 104 qualifies this one and is RESAY as well, so the two still go together.
SAFER: **Droplet · The proposed Natural Physics of version 377 speaking of itself from beyond its own voice.** The review of that proposal, at `carryings/review_natural_physics_v377/`, has at its 2.4, beside Exhibit TWELVE Natural Explaining's 1.4, these of that proposal: 3.1 names `incoming/natural_physics_v377/executions/` and `incoming/physics_at_the_code_v376/`, two folders that leave at their receiving; executed at v377 is said eleven times; 3.6 cites Natural Intelligence 4.13 at v379, a version at no file; 4.1 has the order the cases opened at; 4.10 has declined as natural intelligence evidence, a reviewer's verdict; 5.4 has this part gathers the file's cases; 5.10 promises a case still to come; 2.5 and 5.11 have this file's own, at no registry entry; and, coordinates for names, 3.7 and 3.14 have Exhibit THIRTY's step 319, and 5.3 has Exhibit TWENTY-SEVEN, 7.3, at that file's motion.

### 104
CHECK: OK
WHY: the review's 2.4, "To be re-said" (README line 65), and the proposed file's 4.5 (line 426, 341 and 159), 3.8 (line 282, 65 and 129) and 3.5 (line 252, 4n); each choice, the living path, the kit's, the versions as sections and the three outputs are in NEW, "to be re-said" is said as the review's and at its strength, and it lies with 103 under one verdict.
SAFER: -

### 105
CHECK: OK
WHY: the proposed file's 3.10 (line 300, "one between at three faces … Natural Intelligence 4.10") and 3.14 (line 348); Natural Intelligence 4.10 (line 1000, "at 14 … the between of self and other, and at 12 … the between of momentaries"); the review's 2.5; *inside* is said as within, and NEW has no quotation.
SAFER: -

### 106
CHECK: OK
WHY: the proposed file's 3.7 (line 268, "selves joined along a chain at 6-bi-moralizing and 10-bi-tri-co-tunneling"); Natural Intelligence 4.7 (line 971), the quotation exact; the review's 2.5.
SAFER: -

### 107
CHECK: OK
WHY: the proposed file's 2.3 (line 149, "A tipping is the parity changing at a coupling's between"); Natural Intelligence v380R searched for *tipping*, *participant* and *member*, none at any line; the review's 2.5.
SAFER: -

### 108
CHECK: OK
WHY: the proposed file's 4.12 (line 526, "a society of selves the same one scale out, and nothing is inside either"), from which *either* is said as a self or a society of selves; Natural Intelligence 6.6 (line 1144), the quotation exact; *inside* is Natural Physics' own word at 4.12 (line 479); the review's 2.5.
SAFER: -

### 109
CHECK: OK
WHY: Natural Physics 1.1 (line 76), the quotation exact, and the proposed file's 1.1 (line 85), the same sentence word for word; the proposed file's 3.4 (lines 242 to 246), with no saying of each second momentary; the review's 2.5.
SAFER: -

### 110
CHECK: OK
WHY: the proposed file's 5.3 (line 558, "the offerings excluded and the offerings not yet arrived read alike") and the review's 2.5 (README line 67), the two results at 10 and "alike only at the receiver's 12 and 11" carried in the prior's order.
SAFER: -

### 111
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 112
CHECK: OK
WHY: the review's 2.6, "The explaining" (README line 69), and the proposed file's subtitle (line 5); four and sixty-four are said as the review's.
SAFER: -

### 113
CHECK: OK
WHY: the review's 2.6 (README line 69) and the proposed file at 1.1, 1.2, 2.3, 3.5 and 5.3 (lines 77, 107, 149, 250, 252 and 562); twelve and each of the five places are in NEW.
SAFER: -

### 114
CHECK: OK
WHY: the review's 2.6 (README line 69); ten and each name of the prior's list are in NEW in the prior's order, and no number is added.
SAFER: -

### 115
CHECK: OK
WHY: Natural Intelligence 1.4 (line 99), five, and Exhibit TWENTY-FOUR Geodesic Improving Method 2.7 (line 192), six, both quotations exact; the proposed file's 2.1 (line 129); the review's section 3, item 1 (README lines 73 and 74).
SAFER: -

### 116
CHECK: OK
WHY: the review's section 3, "Open at the carrying", item 2 (README lines 73 and 75), the proposed file's 3.4 (line 240), and the proposal's report at its 6.1, item 3 ("Resolve at each file's motion"); the set, the asserting at 3.4 and each file's motion are in NEW.
SAFER: -

### 117
CHECK: OK
WHY: the review's section 3, item 3 (README line 76), with its 2.1, item 3 ("a halving at each step is a common beat"), and the proposed file's 3.8 (line 282, "goes to one member in two at each pairing"); a halving is said as a going to one in two, and *stands or releases* as remains or is released.
SAFER: -

### 118
CHECK: OK
WHY: the review's section 3, item 4 (README line 77), and the proposed file's 4.11 (lines 509, 510 and 512); the three readings and "at the field's kind or released" are in NEW.
SAFER: -

### 119
CHECK: OK
WHY: the review's section 3, item 5 (README line 78), and the proposed file's 3.5 (line 256, "the persistent current at the spiral carrying its pattern whole") and 4.10 (line 498); *keep* is said as carry, and the h/4e flux open and the transport not are in NEW.
SAFER: -

## READING
Read whole: HARM3.md; BRIEFO3.md with its Further rules; the PRIOR file PH_5a.txt (paragraphs 88 to 119); the PROPOSED file PH_5a_report.md, each block and its READING; the review the paragraphs are drawn from, carryings/review_natural_physics_v377/README.md (lines 1 to 89).

The living file, Exhibit_EIGHTEEN_Natural_Physics_v379.md, is 21,830 words and was not read whole. Read at the sections the paragraphs name: its headings (lines 3 to 577), and 1.1 (line 76), 2.5 (lines 144 to 156), 2.6 (line 164), 2.7 (line 172), 3.1 (line 197), 3.2 (line 213), 3.3 (line 217), 3.4 (line 221), 3.5 (line 229), 3.7 (line 245), 4.2 (line 261), 4.4 (line 304), 4.6 (lines 363 and 365), 4.7 (lines 387 and 389), 4.9 (line 427), 4.12 (line 479) and 5.3 (line 509).

Checked by search and by reading at the place:
- Each quotation of each NEW line, by exact search across the living files at the root of /home/claude/corus: each is found, at the file and the section NEW names (Natural Physics for 93 to 102 and 109; Natural Intelligence v380R 1.4, 4.7 and 6.6 for 115, 106 and 108; Exhibit TWENTY-FOUR Geodesic Improving Method v380R 2.7 for 115). None is misquoted.
- The numbers of sections. The review's 2.3 names sections at version 348's numbers. The mate's map (its line 17) was checked against the headings of version 348 itself, read from the repository's history (reading only, the file before commit 33458cc), and against the living headings: 2.6 at 2.7, 2.7 at 2.6, 3.2 at 4.2, 3.4 at 4.4, 3.6 at 4.6, 3.7 at 4.7, 3.9 at 4.9, 4.1 at 3.1, 4.3 at 3.5, 4.5 at 5.3, 5.7 at 3.3, 5.8 at 3.4, 5.10 at 3.2. Each is as the first reader has it.
- The proposed file, carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (19,824 words, not read whole): its headings, and the lines named in the blocks above, each read at its section. The proposal's report, carryings/natural_physics_v377/README.md: its headings, line 45, and its 6.1 and 6.2 (lines 98 to 136).
- Natural Intelligence v380R at 1.4, 4.7, 4.10, 4.13 and 6.6, and searched for *tipping*, *participant*, *member* (none) and *white paper*; Exhibit TWELVE Natural Explaining v378 at 1.4; Exhibit SEVENTEEN Natural Biology v333 searched for *five-level* (none).
- The mate, carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md (31,477 words, not read whole): its lines 1 to 20, 90 to 104 and 160 to 166, its headings, and searches for pointers ("this mate", "the concern above", "the preceding") and for copies. carry/*.md was searched for "Offerings to Natural Physics" and for the re-saying of 89's twin (carry/Offerings_to_Natural_Intelligence.md line 137). The pointers found are those the first reader names: the mate's paragraph of the review's section 2 (line 164, "each finding of 2.1 to 2.6") and lines 95 and 103, each laid on the class and found still by the review's place in each NEW; and paragraph 120 on 94. No other pointer at 88 to 119 was found.
- Each NEW line and each SAFER line was searched for the first reader's excluded words apart from quotations, italics and code marks (none found), and its words numbered (51 to 139; the SAFER lines 65, 118, 101 and 135).

No block of this portion is RESOLVED, SAID or NOVALUE: thirty are RESAY and two are KEEP. The proposal is unmerged at the living file (its Parts TWO to FIVE are the earlier text at the numbers now), which is why each value the review has as lost is quoted from the living file.

Accepted, and said here for the caller to weigh: three NEW lines say, from the proposed file, what a word of the prior refers to, and add no claim of their own: 106's "selves" (line 268), 108's "a self or a society of selves" for *either* (line 526), and 119's "has it … at a cyclic pattern" (lines 256 and 498). 92 is objected to and these are not, the difference being that 92 lays two readings of the proposal beside a prior that has neither. 94 says "with no overclaim" for the prior's "without the overclaim"; the living sentence is quoted beside it, and it was let through. 109 says the living 1.1 has the sentence the review found at the proposal's 1.1; the two are one sentence word for word.

Not checked: the numbers the review gives (fifteen, four of nineteen, eleven, four, sixty-four, twelve, ten) and the two results at 10 in 110 were not computed again; each is carried in NEW as the review's. No code was run beyond searching, reading and numbering words. No file in /home/claude/corus was edited.
