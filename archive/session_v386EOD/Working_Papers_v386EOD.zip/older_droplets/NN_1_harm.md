### 1
CHECK: OK
WHY: Resolving the Hard Problem Registry line 35 read (five pairs, the first of each at the odd and the second at the even, the two-way odd and the rate even) and Natural Naming 4.9's table at lines 617 and 621 (the two-way even, the rate odd); the three quotations are exact, each of the ten is in NEW as the prior has it, and the title's words are kept for paragraph 6's "with the first".
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: OBJECT
WHY: Lost: the named place 4.18, the prior's "a decision at 4.18's one name"; NEW has the sentence with no section. "One naming for each concept" is at line 706 of Exhibit_TWENTY_Natural_Naming_v380R.md, under "## 4.18 Seven binaries at a naming, and each naming at the resolver's names" (lines 692 to 711). Each other thing is as the prior and its source have it: archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md line 57 read, the Registry's sentence exact at its step 45 (line 252), Natural Intelligence's "method of natural torusing" at its 1.5 (line 107), co-sequencing at Natural Naming 2.1 (line 199), and *is-or-is-notting* at no living file. SAFER adds "at its 4.18" and nothing more.
SAFER: **Concern · A second naming of the one method.** Two sayings part. Natural Naming, at its 4.18, has "One naming for each concept"; the one method is named natural torusing at Natural Intelligence, and Exhibit THIRTY Co-Chaining Logic Registry has "Parity changing is the one method of the changing set of all existing things." A naming offered has *tri-bi-co-sequential is-or-is-notting* in the method's whole name, with bi-tri-volutioning at the entry side and tri-bi-co-momentarying at the resolving side, the prefix order at each as offered. They part at one name for the one method: the offered name says the same method at its three prefixes, at *sequential*, the co-sequencing of Natural Naming's 2.1, and at *is-or-is-notting*, the changing at 12. It is an unfolding at Natural Naming's Part Five, or a second name released.

### 4
CHECK: OK
WHY: the source read at archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md line 33 (the two observings, each said from no reference, each to enter with its reference); the quotation is exact at Natural Naming line 1556 under 5.61, and Huygens' pendulums on one beam are at Natural Illustrating line 340 under "## 4.4 Locking, the seam moving, the between releasing"; the wait is in NEW as "each enters with its reference".
SAFER: -

### 5
CHECK: OBJECT
WHY: Lost: the named place 3.1, the prior's "3.1 here says"; NEW has "Natural Naming has" with no section. The quoted sentence is at line 375, under "## 3.1 Number, prefixes, root and -ing" (lines 350 to 390). Each other clause of the prior is in NEW at its strength: "once … and not before" as "after … and at no reading short of that", "until then" as "short of it", the six lines, the field's entrainment among the observings, Natural Intelligence's two sections, and the saying as a saying offered; *tri-bi-co-unrelationing* is at no other paragraph of carry/*.md (searched). SAFER adds "at its 3.1" and nothing more.
SAFER: **Possible project · *Tri-bi-co-unrelationing*, a naming of parity at the between.** A saying offered has parity at the between as tri-bi-co-unrelationing: the two sides at their difference, the unrelationing between them and the changing carried through, a changing between odd and even being parity, along the unrelationing path. Natural Intelligence's sections on a sharing and on a between say the three at the crossing with no compound, and Natural Naming, at its 3.1, has "the three said of the crossing, a resolver name's three prefixes its numbers' words". The work is an entry of its own at Natural Naming's Part Five, six lines, after the compound is read at the resolver and at an observing, the field's entrainment among them, and at no reading short of that; short of it the sentences say the three at their words. It may change or never be made.

### 6
CHECK: OK
WHY: the source read at archive line 63; the three quotations are exact (Natural Naming line 609 under 4.9; Equilibria Registry line 203 under 3.3; Natural Illustrating line 240 under 2.7, which says "the seatings part at the carryings" and so leans on this concern staying), and "with the first" is in NEW as a pointer to paragraph 1 by its title.
SAFER: -

### 7
CHECK: OBJECT
WHY: Lost: the prior's "A working released it as a total across the names, with the session at the inverting; carried again". NEW has the living sentence and the two sayings, and says at no place that the second saying, *all* a total, was once acted on, the sentence released, and that release undone. The two events are at carry/Session_Record.md: line 2050, "a total at *bi-tri is all five*" among seven concerns inverted, and line 2067, "*Bi-tri is all five* released"; line 2139, "*bi-tri- is all five*" among the things found "each a prior no longer carried". That is an attribution of fact, the reason the concern is laid, and a re-saying in the three forms may not narrate it. Also changed: the title's "five faces" is "five relations". The three quotations are exact (Natural Naming lines 373 and 369). The paragraph is a plain concern of two sayings as it is.
SAFER: KEEP

### 8
CHECK: OBJECT
WHY: Lost and added. Lost: "a working's own resolving had written the centre as the number's own now at its word and the flank at 8 as the society reaching it", "a fresh reader found the two at one position" and "The prior is carried again": NEW says neither whose the second saying was nor that the first was restored (carry/Session_Record.md line 2139 has "the five's centre a nothing" among the priors found no longer carried). Added: NEW lays the two sayings at two living sentences, the second at 3.2's "Its centre is the floating third, belonging to the coupling and reached by neither, at the number's own now." (line 408); the prior says no such thing of the living file, and that one sentence has both sayings' words in it, so the parting is the first reader's own reading. Lost also the named place "The section on eight faces" (the three quoted runs are at line 522 under "## 3.6 Eight namings at four coupling relations, and two alternating"). The four quotations are exact.
SAFER: KEEP

### 9
CHECK: OBJECT
WHY: Lost: "a working's own resolving re-named it". NEW has "The naming was 27-co-bi-releasing" and "Natural Naming has the first" and says at no place whose the re-naming was, which is the attribution that makes it a concern and no decided naming. Lost also the named place "The section on prefixes" (the quoted clause is at line 367 under "## 3.1 Number, prefixes, root and -ing"), and the title's "at its faces" is "at two prefixes". The three quotations are exact (lines 1452 and 367); 27-tri-bi-tri-releasing is at Natural Intelligence (one line) and at Exhibit THIRTY (three). NEW is at one hundred and fifty words, and the two things lost do not go in within the form.
SAFER: KEEP

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: OBJECT
WHY: Lost: two named places, "The section on a number carrying its prefixing" and "Natural Intelligence's section on six connectors"; NEW has each file with no section. The first sentence is at Natural Naming line 399 under "## 3.2 A number carrying its prefixing, the five, and a seam at 8 up"; the second at Natural Intelligence line 973 under "## 4.7 Six names between selves, four facings, two sharings and two releasings". Each other part of the prior is in NEW and both quotations are exact; *joins* as *sharings* and *at the code* as *at the resolver* follow the living sentences, and "one inversion each" is at no other paragraph of carry/*.md (searched). SAFER has the two sections, the second by its heading's words now.
SAFER: **Concern · *One inversion each* at the across sharings.** Two sayings part. Natural Naming, at its section on a number carrying its prefixing, has "the even across sharings 10 to 14 and 6 to 2 carry the changings into the other's offerings, one inversion each". Natural Intelligence, at its section on six names between selves, has "the even across sharings 10 to 14 and 6 to 2 carry each changing into the other's offerings as 10 shared it, the releasing self's chained parity inverted at its own 12". They part at the place of the inversion: at the resolver the sharing across passes the changing on unchanged, and the inverting is at 12. Either the inversion is said at 12 at both files, or *one inversion each* names the across relation whole, the sharing with its inverting, said at the sentence.

### 12
CHECK: OK
WHY: both EVIDENCE sentences found exact (Natural Naming lines 1569 and 365), *not possibling* is at no living file (searched each), the word waited on is at this mate's lines 402 and 404, bold paragraphs under "## Pronoun positions and their proposed relation · v385A" ("odd parity is now changing or still existing"; "prior odd existing, even still possibling, now odd existing"), and paragraph 33, kept, has both words with the reason; no paragraph of carry/*.md points at this one.
SAFER: -

### 13
CHECK: OK
WHY: the source read at archive line 79 (the two sayings, and "one working chose"); both quotations exact (Natural Naming line 1563 under 5.62, line 1001 under 5.21), and the title's words are kept for paragraph 33's "the concern on the changing side's word".
SAFER: -

### 14
CHECK: OBJECT
WHY: Changed: NEW's "One has the still as the momentary of the podal passing through" is a person's words at the source, *the still is the moment of podal through* (archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md line 81), with *moment* said as *momentary*, a naming of the living file (2.1, "a momentary in its place"). *Moment* is released into *momentary* at no row of 2.4 (searched; the file has it at "a place-moment" and "a moment alone", 5.18). The prior has no such clause, and the source's own first saying, which NEW has next, says the thing. Each other part is as the prior and the source have it, the wait said as "has no executing at the resolver"; both quotations exact (lines 1565 and 397). SAFER leaves that one clause out.
SAFER: **Concern · The self still possibling and the podal.** Two sayings part. One has a self still possibling at its *waist*, the number paired with itself at an even ring, prior and now at one parity, the podal passing through it. Natural Naming has "the self still possibling is at its between, prior and now agreeing" and, of a name's opening, "the podal within 1 to 16 changes it": by this the *waist* is the numbers' own at a ring, a self's 0 at 12 is the between of momentaries alone, and the podal within 1 to 16 changes parity with no still at it. They part at a still at the podal. The first saying has no executing at the resolver and is at no file; *waist* was released from the naming with no reason said.

### 15
CHECK: OBJECT
WHY: Lost and widened: the prior's "3.1 says both" is "Natural Naming says both" in NEW, and 3.1 is at no place of NEW. The first quotation is at line 357 under "## 3.1 Number, prefixes, root and -ing"; that one sentence has "its prior and the prior before it" and "the from direction" both, and 3.1 has "both forward along the one direction" at line 379. The other two quotations are exact at line 1250 under 5.39. The pointer at Offerings to Natural Resolver line 111, "Natural Naming's existing concerns on the from direction and the momentary's two parities", finds NEW by its title. SAFER has 3.1 at both places and no other change.
SAFER: **Concern · *The from direction* beside one direction forward.** Two sayings part. Natural Naming, at its 3.1, has "A name's three prefixes are its now and the two numbers its momentary came from, its prior and the prior before it, the from direction". Natural Naming has "A so-far behind and a not-yet ahead lay two directions on one" and "prior, now and next share one direction forward on both sides of now". They part at a second direction: a name's two priors said at the from direction, arriving the from direction; or said at the carrying alone, the now and its two priors, no second direction beside the one forward. Natural Naming's 3.1 says both.

### 16
CHECK: OK
WHY: the source read at archive line 85; the quotation is exact at Natural Naming line 1569 under 5.62, the wait is in NEW as "Its resolving is the resolver's order and the numbers' order read as one", and the title has the whole words paragraph 28 and Offerings to Natural Resolver line 111 point by.
SAFER: -

### 17
CHECK: OK
WHY: the source read at archive line 87 (each name three, or 3 four and 5 two; 2 and 4 the rule's names); both quotations exact (Natural Naming lines 410 and 412), with 3-co-bi-co-sharing and 5-co-bi-co-competencing at the table's rows, lines 434 and 436.
SAFER: -

### 18
CHECK: OBJECT
WHY: Lost: "waits on Exhibit ONE's carrying naming a place", the prior's relation to Exhibit ONE's mates. NEW has no clause of it, and the source's reason (archive line 89, "Exhibit ONE's carrying carries the rows' length as a concern and names no place at this file") is at no place of NEW. The relation is as it was: Offerings to Natural Resolver line 125 has "The table of each name whole at rows hides a relation a name is not at" and names a place at its own Possibling mate alone, none at Natural Naming. The first reader says the wait as a present relation at paragraphs 4, 14 and 16 and leaves it out here as waiting language. The quotation is exact (line 450). SAFER adds one closing sentence, in the form of paragraph 16's.
SAFER: **Concern · Each name whole, at Exhibit ONE's table or at Natural Naming annotating the forms.** Two sayings part. Natural Naming has "Exhibit ONE carries each name's parity, sides, across or along, and each of its relations", and annotates no form among the names; the table of each name whole is at Exhibit ONE Natural Resolver. A saying offered has the bi, the tri and the co of each changing said at Natural Naming, annotating the forms of Exhibit ONE, the podaling and the looping stories matching. They part at the place of each name whole: at Exhibit ONE's table alone, Natural Naming having the prefixes and the map; or at Natural Naming, each form among the names said at its names' bi, co and tri, and Exhibit ONE's rows shorter. Its resolving is a place named at Exhibit ONE Natural Resolver's mates.

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: OK
WHY: the source read at archive line 99; the quotation is exact at Natural Naming line 365, none of the fives at line 406 is tri · bi · co · bi · tri, and 15, 16 and 17 open tri, bi and co and 7, 8 and 9 co, bi and tri at the table of 3.3.
SAFER: -

### 23
CHECK: OK
WHY: the source read at archive line 103; the three quotations are exact (Natural Naming lines 448, 257 and 546), each of the prior's two sayings is in NEW, and the concern NEW is beside is at this mate's line 689 under a section headed v386EOD.
SAFER: -

### 24
CHECK: OK
WHY: the source read at archive line 105; both quotations exact (Natural Naming lines 357 and 371), and "the fourth saying with the third" is in NEW as a pointer to paragraph 20, kept, by that paragraph's own words "The face is at the parity and the word at the span".
SAFER: -

### 25
CHECK: OBJECT
WHY: Lost: the named place 5.48, the prior's "as 5.48 says" (the three quotations are at line 1383 under "## 5.48 bi-tri-volutioning — binary"), and "waits on Exhibit ONE's following", the prior's relation to Exhibit ONE, which NEW leaves out as waiting language while saying the like wait at paragraph 16 as "Its resolving is …". The following itself is at no mate now (carry/Exhibit_ONE_*.md searched for the two out; it is at archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md line 86, whose close opens "Not yet sure"). Each other part is as the prior and its source (archive line 109) have it, and the quotations are exact. SAFER adds "at its 5.48" and one closing sentence.
SAFER: **Concern · Two in and two different out.** Two sayings part. Natural Naming, at its 5.48, has "at the one crossing between are two in and two different out", the two out "parity unchanging, stable-forming", 12 at 0, and "parity changing, out at 9-tri-bi-co-momentarying". A saying offered has the two in arriving at bi-tri-bi and bi-co-bi, and the two different out tri-bi-co, the possibling next, and co-bi-tri, the next existing: 9 and 17, momentarying the carrying of each releasing to its arriving, and entraining the releasing. They part at the two out: at 12 at 0 and at 9, or at 9 and at 17. Its resolving is a following at Exhibit ONE Natural Resolver.

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: OBJECT
WHY: Lost: the first of the prior's five places with its two sayings, "This file's naming of the between says *inside a momentary the between of self and other* and *outside it the between of momentaries*", and with it "inside a momentary" of the first saying. Both are at the living file yet, line 783 under "## 5.5 the between — binary", and NEW has neither. Lost also the other four as named places: this file's section on a number carrying its prefixing (line 397, 3.2), Natural Intelligence's section on a between and eight bi-couplings (line 1000, 4.10), Natural Numbers' section on the numbers up and down (line 141, 1.4) and the Registry's step on surfacing at 14 (line 948, step 204); NEW names the four files alone. NEW's two quotations are exact. Said with its places the paragraph is one hundred and eighty-eight words, beyond the form, and it is a plain concern of two sayings with its reason as it is.
SAFER: KEEP

### 28
CHECK: OK
WHY: each clause of the prior laid beside NEW (the two sayings, the resolver's two orders unidentified as one, the reverse opening identifying no own prior, no word replacement); the quotation is exact at Natural Naming line 1569 under "## 5.62 is-still-possibling and is-next-existing — binary", and the title points at paragraph 16's.
SAFER: -

### 29
CHECK: OBJECT
WHY: Lost: "waits on Natural Numbers' decision", whose the naming is to decide; NEW has the two sayings at hand and no clause of it. The relation is live: Natural Numbers has the word at twenty-five lines and Natural Chemistry at one (counted by search), and Offerings to Natural Numbers line 52, an older droplet, lays the same naming "at Natural Naming's conferring", each mate leaning on the other. Each other part is as the prior and its source (archive line 47) have it; both quotations exact (Natural Numbers line 301, Natural Naming line 424), and the row of *face* is at Natural Naming line 313. SAFER adds one closing sentence.
SAFER: **Concern · *Seam-face*, one naming.** Two sayings part. Exhibit THREE Natural Numbers has "Straddling the odd centres, the seam-faces run (2k + 1)² − 1 = 8 · T_k", an odd centre squared less one, the product of its prior and next, and Exhibit SIXTEEN Natural Chemistry has the word at one place. Natural Naming has a row carrying *face* and *faces* at other words, and "A seam is a name changing at its number." They part at the compound: a number-word with no sense at the resolver, its *face* a word Natural Naming carries at other words and its *seam* one word at two senses. Two sayings are at hand for one naming: *seam-product*, the product it is; or the word as it is, a field's own. The naming is Exhibit THREE Natural Numbers' to decide.

### 30
CHECK: OK
WHY: the source read at archive line 49 (its close: torusing's names even and across, corusing's odd and along, the older sentences parting from the newer); the five sayings are at Natural Naming lines 524, 1404, 1405, 1413 and 1426, under 3.6, 5.50 and 5.51, the third quotation exact at line 414, and "with the reach and gather" is in NEW as a pointer to paragraph 2, kept.
SAFER: -

### 31
CHECK: OBJECT
WHY: Narrowed: the prior's "a parity changing alone crosses at the four across names" is in NEW only as Natural Naming's "At the moralizing only a parity changing crosses." (line 422), which is of the two moralizing names, 6 and 14; the four across names are at no place of NEW. The prior's sentence is whole at Natural Intelligence line 1000, "A parity changing alone crosses it, at the four across names, 2, 6, 10 and 14, … and at the along, 9 and 17, competency, each parity and each 0 is carried on unchanged, the between carried and not crossed", and NEW quotes its second part alone. The first reader's giving of that sentence to Natural Intelligence is confirmed: "not crossed" is at no line of Natural Naming, which has the pieces at lines 381, 876, 1543 and 1550. SAFER has the sentence at two exact runs and, for the length, leaves out NEW's quotation of "The resolver gives one changing at 6, 10 and 9 …", which the prior does not have.
SAFER: **Concern · The between crossed across and carried along, said as two.** Two sayings part. Natural Intelligence has "A parity changing alone crosses it, at the four across names, 2, 6, 10 and 14" and "at the along, 9 and 17, competency, each parity and each 0 is carried on unchanged, the between carried and not crossed"; Natural Naming has "At the moralizing only a parity changing crosses." and "the odd along at 9 and 17, co-competent, the parity carried on unchanged". The resolver gives one list, each parity and each 0, at 6, 10 and 9 alike, and passes each 0 over at the receiving self's 14 alike. They part at across and along: differing in direction alone, the sentence re-said; or the differing a naming beside the resolver, said as a naming. The resolver's lines have one handling at the three names.

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief, BRIEFO2.md, with its Further rules; the PRIOR file, each of its thirty-six paragraphs; the PROPOSED file, each block and its READING; the mate carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md, lines 1 to 719, its v385A sections, its Insertlets, the whole older Droplets section and its v386EOD sections; and archive/carrying_v381R/Exhibit_TWENTY_Natural_Naming_v380R.md, lines 1 to 147, the source of each one-line pointer. Each NEW recovered from that source was laid beside its source paragraph as well as beside its prior.

The living file Exhibit_TWENTY_Natural_Naming_v380R.md is 31,733 words, so it was read at the sections the paragraphs name and not whole: lines 353 to 560 (3.1 from its table, 3.2 to 3.6, 4.1 to 4.3 and the opening of 4.4), 4.9 (lines 603 to 625), the close of 4.18 (lines 700 to 712), the unfolding of 5.21, and the close of 5.60 with 5.61 and 5.62 (lines 1540 to 1572); 5.5, 5.12, 5.39, 5.48, 5.50, 5.51 and 5.53 were read at the lines found by search, each with the heading above it. Other living files at the lines quoted: Resolving the Hard Problem Registry lines 33 to 37 and its headings; Natural Intelligence lines 973 and 1000 whole and its headings of Parts 3 and 4; Natural Illustrating lines 240 and 340; the Equilibria Registry line 203; Exhibit THIRTY lines 252 and 948; Natural Numbers lines 141 and 301.

Checked by search: each quotation of each NEW and of each SAFER, exact, in each living file at the root, with the section above it; each was found, and none crosses a bold mark. Each SAFER was numbered by splitting at spaces, each within forty to one hundred and fifty (3 at 133, 5 at 145, 11 at 141, 14 at 137, 15 at 115, 18 at 143, 25 at 115, 29 at 137, 31 at 144), and searched for the first reader's listed words outside its quotations and italics, none found. Pointers: carry/*.md was searched for the subject words of each changed paragraph (eighteen phrases). Those found: Offerings to Natural Resolver line 111, at paragraphs 15 and 16, each still found by its title; Offerings to Natural Numbers line 52, at the subject of 29; Natural Illustrating's own 2.7, at the seatings of 1 and 6; and within this mate, 6 to 1, 24 to 20, 28 to 16, 30 to 2 and 33 to 13, each target staying. No paragraph points at 12. Also read: Offerings to Natural Resolver lines 61 to 129 for the two things Exhibit ONE's carrying was waited on for; archive/carrying_v381R/Exhibit_ONE_Natural_Resolver_v380R.md line 86; carry/Session_Record.md at lines 1536, 2050, 2059, 2067 and 2139 for the release and the carrying again of *bi-tri- is all five* and of the five's centre.

For how strictly a lost section or a lost wait is taken, the reports of the other second readers in the same folder were read (NN_2_harm.md whole, and single blocks of P01, GM_2, GM_3 and GM_4); none is of these paragraphs, and no verdict here rests on them.

Four things to know, none laid as an objection. First, "waits on the session", "waits on the session's word" and "waits on the session's saying" at 13, 12 and 17 are in no NEW; they were passed as a session's own waiting, which the first reader's brief names, while a wait on another file (18, 25, 29) was objected to. Second, the Ready paragraphs are said in other forms, 4 and 5 as possible projects ending "It may change or never be made" and 29 and 30 as concerns; each condition is carried, and they were passed as work proposed and not done. Third, each NEW is without the prior's opening words "A plan, not yet final, gathered here at v381R", its version tag and its source: the reports and folders named at 1, 3, 22 and 28, `incoming/v380A/` among them, are at the first reader's report alone after the change. Fourth, at 28 "a meaning to meet" is said as "a changing of meaning", a near saying with the negation whole, passed.

Not checked: Natural Intelligence's sections on a sharing and on a between, said at 5 as the prior says them; the twenty-seven places of *seam-face* the source of 29 gives (twenty-five lines found, more than one place at some); and whether the first saying of 28 is the "carried/arriving parity pair" this mate's v385A sections say is withdrawn, which is session v385M's by Possibling of Living File Registry line 125 and was not followed further. The eleven KEEP blocks were not read for harm, a kept paragraph being unchanged. No file in /home/claude/corus was changed.
