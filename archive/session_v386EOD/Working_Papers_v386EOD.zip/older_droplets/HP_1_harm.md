### 1
CHECK: OBJECT
WHY: NEW adds the word "checks" and so makes C12 and C17 the Hard Problem Registry's own checks; the prior has "C12 and C17 beside" with no noun, and the source the first reader names (archive/carrying_v381R/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v380R.md line 19, "no engineering entry numbered without the full intake, its C12 and C17 beside") points the other way. That sentence was written at commit b9674cc (v378) together with three sibling paragraphs from the same review, each citing the review's own numbered concerns: "Its concerns C14 and C15 beside them" (Natural Engineering), "its concern C9 ... C10" (Natural Networking), "the report's concerns C1 to C7 beside them" (Natural Intelligence). The review (carryings/review_networking_engineering_2026-09-30/Natural_Networking_Engineering_Session_Report_2026-09-30.md, section 12, lines 569 and 579) has its own "C12 — Entry and resolving were prematurely called conflicting subjects ... The exact compound naming remains a proposed reception" and "C17 — File-level reforming must preserve the field's record", the two of its concerns that are of TWENTY-ONE, matching its row for TWENTY-ONE at line 532. So "its C12 and C17" is most likely the review's concerns, and NEW would turn them into the registry's checks C12 (conserving relation) and C17 (the field's statement of hardness), a different thing. The rest of NEW was laid beside the prior and the source and loses nothing (the review's sections 6.4, 8 and 9 read; no *bi-tri-volutioning* and no engineering entry at the living file, searched).
SAFER: **Possible project · Engineering arrivals at the full intake, and bi-tri-volutioning as the entry face.** The review of Natural Networking and Natural Engineering of 30 September 2026, at its sections 6, 8 and 9, has engineering arrivals in their field's own terms and offers bi-tri-volutioning as the entry face of Exhibit TWENTY-ONE Hard Problem Registry. The work is the entering of the engineering arrivals at that registry, none entered short of the full intake at the form, with C12 and C17 beside. Bi-tri-volutioning as the entry face is the expedition's self's to decide. It may change or never be made.

### 2
CHECK: OK
WHY: the living Hard Problem Registry was searched for each of the seventeen names at the old code and at the code now (self-other, other-self, social-other, other-social, surfacing, tunneling, chaining, abundancing, neutralling, momentarying, corusing, torusing, co-bi, bi-co, tri-, seventeen, resolver, Exhibit ONE) and has none at its own voice, so the first saying is of no line of it; the three sayings entered are at Exhibit THIRTY Co-Chaining Logic Registry v380L by exact search, steps 322 (line 1447), 315 (line 1419) and 330 (line 1479), each with an Adding line and no Unsure line; their entering from this file is whole at carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md items 4 to 6 and contradiction 8; no paragraph of carry/*.md points at this one (the like paragraphs at the mates of Natural Chemistry, Equilibria Registry and Resolving the Hard Problem Registry are those files' own copies).
SAFER: -

### 3
CHECK: OK
WHY: NEW laid beside the prior and its source, archive/carrying_v381R/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v380R.md line 29, and archive/session_v379/Session_Report_v379.md finding 4: each claim of NEW is that source's, the two ways and "neither chosen" are carried, and the one quotation, "prior, now and next", is exact at line 13 of the living file and at no other line (searched); the living file has no "named still" at any line.
SAFER: -

### 4
CHECK: OK
WHY: Exhibit THIRTY Co-Chaining Logic Registry v380L has, by exact search, step 312 "Accounting against forms named still, the scientific method carries no changing of its own: no method of existing, and no second method beside the one." (line 1407) with its Adding line and no Unsure line; the explored steps "The scientific method" 4 to 6 (carryings/co_chaining_map_v376/Explored_Steps_v376.md) are entered at steps 311, 312 and 316; each Unsure line of that file was listed and none is of the scientific method; the row T1 is whole, word for word, at carryings/co_chaining_map_v376/cover_REGISTRIES.md line 15. Paragraph 7 names this row ("as T1") and has the same verdict; the two leave together or stay together.
SAFER: -

### 5
CHECK: OK
WHY: Exhibit THIRTY Co-Chaining Logic Registry v380L has, by exact search, step 17 "Two existing things at their difference alone are bi, and two existing things with their difference carried together are co." with "*Adding: bi and co.*" (line 128), ahead of step 18 on stable-forming as bi-co, and step 327 with the lead's saying (line 1467), none with an Unsure line; no Unsure line of that file has "bi and co"; the row T3 is whole at cover_REGISTRIES.md line 17; no paragraph of carry/*.md points at it (searched "row T3", "P21").
SAFER: -

### 6
CHECK: OK
WHY: Exhibit THIRTY Co-Chaining Logic Registry v380L has, by exact search, step 330 (line 1479) with "*Adding: the form named still and the form resolving.*" and no Unsure line, entered from this file's lead "One learning at two faces" by reading 05 item 4 of carryings/co_chaining_coverage_v378; the explored "Cohering with nature" 1 and 2 are at step 595; the row T4 is whole at cover_REGISTRIES.md line 18; no paragraph of carry/*.md points at it.
SAFER: -

### 7
CHECK: OK
WHY: Exhibit THIRTY Co-Chaining Logic Registry v380L has, by exact search, steps 310, 312, 315 ("*Adding: the refutation as one.*") and 322 ("*Adding: the conditions prior, and the sixth.*"), none with an Unsure line, and the explored "The scientific method" 3 to 5 are at steps 310, 311 and 312; the three sentences the row quotes are still at the living Hard Problem Registry (lines 37, 75 and 101); the row T7 is whole at cover_REGISTRIES.md line 21. Its "(as T1)" names paragraph 4, of the same verdict; the two leave together or stay together.
SAFER: -

### 8
CHECK: OK
WHY: NEW laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md line 168: each named thing (Part 17, its three subjects, the Living Ghost Registry, the hard-problem registries un-narrowed, 17.4, the combined Exploring) is in NEW at the strength of a proposal; Natural_Intelligence_Corus_v330.md still has Part 17 and 17.4 (lines 1635 and 1840). The one thing NEW does not have is the source's name, "(Re-Settling the Living Files, §6 Corus table)", which the first reader's brief has as a session's word; the same paragraph with that name is still at four other mates' older sections.
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: OK
WHY: NEW laid beside the prior and carryings/session_v377/Session_Report_v377.md line 259 (its section 8) and line 103 ("## 3. What was found across the files: the ten and the six"): the four places are those of the prior, "both hard-problem registries" being the two registries by name, "section 3 above" is carried as section 3 of that report by its path, and Natural Naming's 4.9 is still "## 4.9 The ten named still, one name each" (line 603 of Exhibit_TWENTY_Natural_Naming_v380R.md); no quotation, no waiting.
SAFER: -

### 12
CHECK: OK
WHY: NEW's sentence is the prior's sentence word for word, with the words named in italics, and it is the sentence at carryings/v368_sources/Wrap_v368.md section 4, "Across the set"; "It is aimed at the set." carries the aiming. The one thing NEW does not have is the source's name, "(Wrap_v368.md, §4 What each file carries next, Across the set)", which the first reader's brief has as a session's word.
SAFER: -

### 13
CHECK: OBJECT
WHY: Two things. First, NEW adds "checks" to "C12 and C17 beside"; the prior has no noun, the phrase is the same hand's phrase of paragraph 1, and at paragraph 1 its source has C12 and C17 as the engineering review's own concerns (see block 1), so which C12 and C17 are beside the entering is not settled by any file read (no file but the two paragraphs and the v380R archive line has "C12 and C17" beside an intake; searched the repository). Second, NEW's closing sentence, "Others of the same physics droplets are insertlets at this mate.", has no physics droplets ahead of it to be the same as, and drops that this paragraph is "the remainder of the v376 and v377 physics droplets"; the reader of NEW cannot find which droplets. The rest was laid beside the prior and the source (archive/carrying_v381R/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v380R.md lines 15 and 17): the parting into two tensions and the wider collection is that source's, each of the nine is in NEW, none of the nine is at a line of the living file (each searched), and the others of that incoming are insertlets at this mate (at 153, 252, 182, 173, 157, 183, 49 and 26, read). "At A" itself is defined at no file found; the mate as it was at commit 121dc12 has "Resolving moves a droplet up into an insertlet", which bears the first reader's reading of it.
SAFER: **Possible project · Two tensions changed and the wider collection, at no entry.** Two tensions changed, the 2026 proton radius and the 2025 muon magnetic-moment assessment, and the wider collection, the W boson's mass, the BEST gallium deficit, MicroBooNE, Auger's muon fluctuations, the EMC effect, H1 diffraction and ALICE's small systems, are at no entry of Exhibit TWENTY-ONE Hard Problem Registry. They are the remainder of the physics droplets of versions 376 and 377, others of those droplets insertlets at this mate. The work is the entering of each at the full intake at the form alone, each at its own statement, with C12 and C17 beside. The ten screening questions go to Exhibit THIRTEEN Resolving Hard Problems. It may change or never be made.

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the harm brief; the first reader's brief with its further rules; the PRIOR file; the PROPOSED file; the mate carry/Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.md (4,716 words, each section); carry/Exhibit_TWENTY-ONE_Possibling_of_Hard_Problem_Registry.md; carryings/co_chaining_coverage_v378/README.md and its reading 05; the opening of the living Hard Problem Registry (lines 1 to 60).

Read in part, by search and by reading the lines found: the living Exhibit_TWENTY-ONE_Hard_Problem_Registry_v375.md (never whole: its front, line 13, the checks C12 and C17 at lines 10687 and 10697, lines 37, 75 and 101, and searches for each of the seventeen names at either code, *bi-tri-volutioning*, *intake*, "prior, now and next", "named still", "the ten", and each of the nine physics subjects of paragraph 13); Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (steps 12 to 18, 310 to 316, 322, 326 to 330, 595, each quoted step by exact search, and each line with *Unsure* listed); Exhibit_TWENTY_Natural_Naming_v380R.md (the title of 4.9); Natural_Intelligence_Corus_v330.md (the titles of Part 17); archive/carrying_v381R/Exhibit_TWENTY-ONE_Hard_Problem_Registry_v380R.md (lines 10 to 32); archive/session_v379/Session_Report_v379.md (its part 2); carryings/review_networking_engineering_2026-09-30/Natural_Networking_Engineering_Session_Report_2026-09-30.md (its headings, 6.4, sections 11 and 12 whole, and each line naming TWENTY-ONE); carryings/co_chaining_map_v376/cover_REGISTRIES.md (Table A whole, the proposed steps, the old-code table) and Explored_Steps_v376.md ("Cohering with nature", "The scientific method"); carryings/resettling_v373/Re-Settling_the_Living_Files.md (the Corus table of its section 6); carryings/session_v377/Session_Report_v377.md (its headings, section 8, the opening of section 3); incoming/v385A/Hard_Problem_Plan_Comparison_v385A.md (each line with "ten", "C12"); carry/Exhibit_TWENTY-ONE_Carryings_of_Hard_Problem_Registry.md (lines 1 to 31); carry/Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md ("The earlier paired-registry coverage records · v385A", whole); carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md ("Earlier proposed extent of the living subjects · v385A" and the two sections after it). With git, read only: the commit b9674cc (v378) for each paragraph it added citing a numbered concern, and the mate as it was at commit 121dc12 (v381R).

Checked by search in carry/*.md for pointers: "row T" with a number, "P21", "P8", "seventeen names", "pass B", "Part 17", "17.4", "control ghost", "full intake", "C12 and C17", "screening question", "resolved in part at A", "paired-registry coverage records", and each link to this mate from another mate.

Three things to know. First, the objection at 1 and 13 is one finding: "C12 and C17" at this mate began at session v378 as the engineering review's own concerns C12 and C17, written beside three sibling paragraphs that cite that review's concerns by number, and the first reader took them for the registry's checks of the same numbers; the mended paragraphs carry "C12 and C17" as the prior has it, with no noun. If the review's concerns are to be named, paragraph 1 is "with the review's concerns C12 and C17 beside"; at paragraph 13 no file settles it. Second, Carryings of Hard Problem Registry, "Earlier source inventory · retained from v381R", has "its findings at the offerings as droplets" of each working and "each of its paragraphs now a droplet at the offerings" of the v380R carrying: a saying of the older Droplets section as a whole, retained from v381R and already inexact (paragraphs of that carrying are insertlets now); it points at no one paragraph, and no objection was made on it, but each release at 2 and 4 to 7 makes it less exact. Third, the pointers found that bear on the released paragraphs are within this section alone: paragraph 7's "(as T1)" at paragraph 4, both RESOLVED together; "The earlier paired-registry coverage records · v385A" at Carryings of Co-Chaining Logic Registry is of twenty-two rows of Resolving the Hard Problem Registry and names none of the rows T1, T3, T4 or T7.

Not settled: what "A" names at paragraph 13 (no file read defines it).
