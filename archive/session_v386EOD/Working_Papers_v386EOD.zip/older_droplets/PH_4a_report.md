### 37
VERDICT: RESAY
CONCEPT: Natural Physics 1.1 has *at no line of the code* at a sentence whose twins at three files have *at no line of the resolver*, the name Natural Naming carries; one saying is ready.
EVIDENCE: Not resolved: Exhibit_EIGHTEEN_Natural_Physics_v379.md line 82, within 1.1, still has "is bi-co-momentarying, at no line of the code, Natural Intelligence 6.1". The twins: Exhibit_FOUR_Natural_Mathematics_v380L.md line 179, Exhibit_THREE_Natural_Numbers_v380L.md line 349 (7.1) and Natural_Intelligence_v380R.md line 220 (3.5), each with "at no line of the resolver"; Exhibit_TWENTY_Natural_Naming_v380R.md line 270 has "code executing is said *at the resolver*". At no later section (searched "at no line of the code" and "at no line of the resolver" in carry/*.md). The paragraph's "Line 82" is said as 1.1, the section that line is in. No pointer to this paragraph found.
NEW: **Concern · *The code* at Natural Physics 1.1, beside *the resolver* at its twins.** Two sayings part. Exhibit EIGHTEEN Natural Physics has, at 1.1, "is bi-co-momentarying, at no line of the code, Natural Intelligence 6.1". Its twins at Exhibit FOUR Natural Mathematics, Exhibit THREE Natural Numbers and Natural Intelligence have "at no line of the resolver", as Exhibit TWENTY Natural Naming carries it. They part at the one name: *the code* at the one sentence and *the resolver* at the three. One saying of it is ready at Natural Physics' sentence.

### 38
VERDICT: KEEP
CONCEPT: a session's offering of the torus's two openings as one tunnel's two ends and of prime loops as twisted figure 8s, worked by hand at the resolver's lines, beside Natural Physics 1.2's sentence of the large and the small opening.
EVIDENCE: Kept under rule 5 and do no harm: it has a person's own unpunctuated words (two sayings) and by-hand workings (twice and four times the number of momentaries, a spiral of three, Exhibit ONE's eight rows, the names 8 and 16, 7 and 15) that a re-saying could not carry each at its strength. Its living sentence is as it was (Exhibit_EIGHTEEN_Natural_Physics_v379.md line 96, within 1.2: "The torus carries two openings, the large opening the hole the tunneling self winds through and the small opening the tube's own round"). Parts are at later places: Exhibit THIRTY Co-Chaining Logic Registry step 644 ("A routing at the odd momentaries alone or at the even alone, each at its own opening, is at no line of the resolver."); carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The offered two openings and the resolver's two routings · v385A" and "Droplet · One tunneling, two ends" (v386EOD); carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md, "Possible project · The rows In and out at its parity". None aims at Natural Physics 1.2's sentence and none has the names' parities, so it is not SAID whole.
NEW: -

### 39
VERDICT: RESAY
CONCEPT: sixty is said a position that carries at Natural Physics 3.1 and a between at Natural Numbers 7.1 and Natural Chemistry 4.4; one saying is the three files' to make at their motions.
EVIDENCE: Not resolved, each sentence at its living file now: Exhibit_EIGHTEEN_Natural_Physics_v379.md line 205 (3.1), "The going runs 2 to 59, a turn stands at 60" and "a turn is a position that carries"; Exhibit_THREE_Natural_Numbers_v380L.md line 349 (7.1), "sixty is between the going and the returning, at no prime"; Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 313 (4.4), "no position in the elements carries at sixty". A later section says part: carry/Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md, "The element count and the turn at sixty · v385A", without the three named places and without whose the one saying is; this mate's "The gravity statement and its actual observing · v385A" only says the turn-at-sixty question is retained at another mate. So RESAY, not SAID. The same concern is re-said in carry/Exhibit_THREE_Offerings_to_Natural_Numbers.md (line 43, within its older Droplets, no later place by rule 1); NEW here is the same wording, its four quotations searched exact. Source: archive/session_v379/Session_Report_v379.md, finding 6. No pointer to this paragraph found.
NEW: **Concern · Sixty a position or a between.** Two sayings part. Exhibit EIGHTEEN Natural Physics has, at 3.1, "a turn stands at 60" and "a turn is a position that carries". Exhibit THREE Natural Numbers has, at 7.1, "sixty is between the going and the returning, at no prime", and Exhibit SIXTEEN Natural Chemistry has, at 4.4, "no position in the elements carries at sixty". They part at sixty: a position that carries, or a between. One saying of sixty, position or between, at the three places is the three files' own to make, each at its motion.

### 40
VERDICT: KEEP
CONCEPT: a proposed five-part form of Natural Physics, each part with its contents, co-chaining from the one opening.
EVIDENCE: Kept: a possible project in plain voice, and it points at another paragraph of this mate ("the forms above", the list under *Its explaining at Exhibit ONE's forms*, mate line 56 to 67), which a re-saying could not carry without that list. Part of it is at the living file (parts ONE to FIVE at these titles but THREE, "PHYSICAL OBSERVINGS"; 1.1 and 1.2 written), the rest is not: 2.1 is the older text and no section of THREE is at the code's forms. The proposed text at carryings/natural_physics_v377/ carries the plan out and is not entered. Paragraph 41 gives this paragraph's order and stays with it. At no later section.
NEW: -

### 41
VERDICT: KEEP
CONCEPT: the order of the motions that enter the proposed parts, each prior section's value carried to its new place and a fresh reader comparing.
EVIDENCE: Kept with paragraph 40, which it qualifies ("Its order", of the parts 40 lists): rule 2, the same verdict for both. The front, the contents, 1.1 and 1.2 are at the living file; Part TWO to Part FIVE are not. At no later section.
NEW: -

### 42
VERDICT: KEEP
CONCEPT: the asteroid belt emptied at the rational resonances, the Kirkwood gaps, the irrational orbits carrying on.
EVIDENCE: Kept under rule 2: three places point at it or quote it whole. This mate's "Aimed at a saying, Natural Physics, *The asteroid belt emptied at the rational resonances, the Kirkwood gaps, the irrational orbits carrying on*: Beside the incoming from the prior Natural Numbers in this list" (mate line 568, v386EOD); carry/Exhibit_EIGHTEEN_Carryings_of_Natural_Physics.md line 29, "This file's offering mate has, as incoming from the prior Natural Numbers: …" with the sentence quoted; and the living Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 446, "Natural Physics' carrying, the belt emptied at the rational resonances and the irrational orbits carrying on". The living Natural Physics has no sentence of the Kirkwood gaps.
NEW: -

### 43
VERDICT: KEEP
CONCEPT: the trajectory and the ensemble as an accounting, with ergodicity-breaking; and the golden-mean invariant torus the last to break at the standard map by computation, at its field's conservative scope.
EVIDENCE: Kept under rule 2 and rule 3. A living file points at it: Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 446, "Natural Physics' carrying, … the golden-mean torus the last to break". Its first part is at the living Natural Physics 4.5 (line 322, "the trajectory, one system followed along its time, and the ensemble, many read across at once — the ergodic claim being that the two books agree"); its second is at no sentence of Natural Physics (it is at Exhibit THREE Natural Numbers line 201 and at carry/Exhibit_THREE_Offerings_to_Natural_Numbers.md "Droplet · A winding found last to break", neither aimed at Natural Physics). Already a clear concept in plain voice.
NEW: -

### 44
VERDICT: KEEP
CONCEPT: two studies of two-frequency forcing of a fluid surface, externally vibrated with no autonomous networking, the stated condition parity and coprimality, not primality.
EVIDENCE: Kept: already a clear concept in plain voice with no waiting language. Most of it is at a living file, Exhibit_FOUR_Natural_Mathematics_v380L.md line 219 ("its condition is parity and coprimality, not primality"), but the years and journal, "Faraday" and "no autonomous networking" are at no living file, and no sentence of Natural Physics has it, so neither RESOLVED nor SAID whole (rule 3). At no later section of a mate (searched Arbell, Silber, Faraday).
NEW: -

### 45
VERDICT: KEEP
CONCEPT: a resemblance is no mechanism: an eddy, a surface wave and a chemical excitation wave are three transports, and a like picture opens a comparison of their couplings, never of pictures.
EVIDENCE: Kept: already a clear concept in plain voice with no waiting language. Most of it is at a living file, Exhibit_TWELVE_Natural_Explaining_v378.md line 362 within 4.7 ("a fluid eddy is a flow circulating, a surface wave an interface changing and a chemical excitation wave an activity propagating, three transports at one likeness"), but "the releasing, arriving and continuing at each" and "A resemblance is no mechanism" are at no living file and no sentence of Natural Physics has it, so not SAID whole. At no later section of a mate.
NEW: -

### 46
VERDICT: KEEP
CONCEPT: Natural Physics' seam with Chemistry at bonds and with Biology at their physical changing, the particular subjects carried and no living and non-living division; the proposed three-science contents carried as an opportunity.
EVIDENCE: Kept: I could not find what "the proposed three-science contents" refers to (searched carry/, carryings/ and archive/: the phrase is in this paragraph's own earlier copies alone, archive/registry_v371/Living_Improving_Value_v371_registry_working.md line 522 and archive/carrying_v381R/Exhibit_EIGHTEEN_Natural_Physics_v380R.md line 59). The living 1.1 has the seam in part ("Chemistry and Biology are the same method at their own subjects"), not the opportunity. At no later section.
NEW: -

### 47
VERDICT: KEEP
CONCEPT: Natural Physics' particular two-way seams with Natural Philosophy and with the Living Ghost Registry, a field's released naming and a correspondence still reaching kept two, and the older k-bound relation laid at Natural Numbers as it is now.
EVIDENCE: Kept under do no harm: it is intended work in an advising voice, and re-said as a possible project it would be weakened (rule 4). Its last relation, "the older k-bound, iron-centreline and pair-creation relation" with "current Numbers", I could not place at one sentence: the living Natural Physics has the k = 1 bound at 4.3 and the pair at 4.12, and Exhibit THREE Natural Numbers has no saying of a k = 1 bound (searched). The living Natural Physics names neither Natural Philosophy nor the Living Ghost Registry. At no later section.
NEW: -

### 48
VERDICT: KEEP
CONCEPT: findings of Exhibit THIRTY's paragraphs P1 to P28, at older wording, scientific-method descriptions, field results and the file's own table numbers, carried toward the paused science working.
EVIDENCE: Kept: I could not find what it refers to. "THIRTY P1–P4, P6–P8, P13, P15–P18 and P24–P28" names labels at no present file (searched Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md, carry/, carryings/ and archive/: only this paragraph's own earlier copies). At no later section.
NEW: -

### 49
VERDICT: KEEP
CONCEPT: the order of the next whole motions at Natural Physics as an improving report proposed it, with the readers' difference at the first case carried.
EVIDENCE: Kept under do no harm and rule 8: each section number in it is at the numbering before version 377 (this mate's paragraph *The sections' places, v348 to v377* has 3.1 to 3.12 at 4.1 to 4.12, 5.4 at 5.6, 5.7 at 3.3 and on), and a re-saying would need each of some twenty numbers given as it is now. 1.1 and 1.2 are at the living file; the rest of the order is not. It carries a condition ("the list marks no unlisted passage verified") and a difference between readers, no bookkeeping alone. At no later section.
NEW: -

### 50
VERDICT: RESAY
CONCEPT: the proposed Natural Physics of version 377 is whole at its working's branch, with what its review found whole, and it enters as the file's next version at its working's motion with section 2 of the review answered first.
EVIDENCE: Not resolved: the living file is Exhibit_EIGHTEEN_Natural_Physics_v379.md, forty sections; the proposed text is at carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (five parts, forty-nine sections, searched its headings) and at the branch `working/physics-motion-v377` (this mate's last section names it). Its numbers are those of carryings/review_natural_physics_v377/README.md lines 15 to 21 and line 85. At no later section: this mate's front line names the proposed text at the file's own motion but not the condition, and is no v385A or v386EOD section. "Met first" is said as a relation (rule 9). No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, whole, and its entering.** The proposed Natural Physics of version 377 is whole at the Natural Physics working's branch: five parts and forty-nine sections, each execution executing again at Exhibit ONE Natural Resolver's code and each output matching, fifteen of sixteen claims at the code true, the released words fallen to none at nearly each word, fifty-one records of the field correct at their numbers and sources, thirty of the prior's forty sections whole, and each correction of the prior's overclaimings rightly made. Its entering as Natural Physics' next version is at its working's motion, section 2 of its review answered first.

### 51
VERDICT: RESAY
CONCEPT: five things beside all existing things at Natural Intelligence 1.4, six binaries at the Geodesic Improving Method 2.7, the proposed Natural Physics asserting six at its 2.1; one list at both files, at the observings.
EVIDENCE: Not resolved: Natural_Intelligence_v380R.md line 99 (1.4) names five, and Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md, 2.7, has "is met at six binaries, the rigorizer". Which file has five and which six is in neither the paragraph nor its source line (carryings/review_natural_physics_v377/README.md line 74); it is in carryings/natural_physics_v377/README.md, 6.1 concern 2 ("Natural Intelligence 1.4 names five"), and is here shown by the two living sentences themselves. The proposed 2.1 is "Scientific method, its fixings and the six binaries met at physics". No later place says it whole: carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md has "Droplet · Six binaries at 2.7, and five things at Natural Intelligence 1.4" within its older Droplets (rule 1), and its v386EOD section "At 2.7 · An observing brought as a break…" is a sentence offered, without the proposed 2.1 and without the one list. No pointer to this paragraph found.
NEW: **Concern · Five binaries or six.** Two sayings part. Natural Intelligence, at 1.4, has "a size between one and the other carries a ground, a floor or a scale; a fixed form, a form named still; a total across the changing, a container; a common beat, a clock over the changing; and a keeping, a store beside it". Exhibit TWENTY-FOUR Geodesic Improving Method, at 2.7, has "is met at six binaries, the rigorizer". The proposed Natural Physics of version 377 asserts six at its 2.1. They part at the number: five or six. Its resolving is one list at both files, at the observings.

### 52
VERDICT: RESAY
CONCEPT: the proposed Natural Physics asserts the rings as spirals at its 3.4, a saying open across the set, at each file's motion.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 75 ("the file asserting it at 3.4; each file's motion"), the file being the proposed text; its 3.4 (proposed file line 240) has "the white paper's rings at 4.13 are these spirals". The living Natural Physics' 3.4 is the light-cone and has no such sentence. Not resolved across the set: Natural Intelligence 4.13 is now "Spirals, co-spiraling and crossing" and Natural Naming 2.4 has the row of *ring* at *spiral*, but the living Natural Physics still has "And the ring's own binary runs here and does not close" (line 638). At no later section of this mate; carry/Offerings_to_Natural_Intelligence.md has it within its older Droplets (rule 1). No pointer to this paragraph found.
NEW: **Droplet · The rings as spirals, open across the set.** The proposed Natural Physics of version 377 asserts the rings as spirals at its 3.4. The saying is open across the whole set, and its resolving is at each file's own motion.

### 53
VERDICT: RESAY
CONCEPT: the proposed Natural Physics reads decay as pairing at its 3.8, while alpha and beta decay are single-nucleus events with no partner and a halving at each step is a common beat; the reading carries on at its relation or is released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 76. The 3.8 is the proposed text's ("A society receding at each pairing, and levelling at others joining", proposed file line 280); the living Natural Physics has no 3.8 and no section of decay. At no later section (searched "single-nucleus", "pairing" in carry/*.md: this mate's older paragraphs alone). No pointer to this paragraph found.
NEW: **Droplet · Decay read as pairing, at the proposed Natural Physics of version 377.** The proposed Natural Physics of version 377 reads decay as pairing at its 3.8. At the field's record alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat. The reading carries on at its relation or is released.

### 54
VERDICT: RESAY
CONCEPT: the proposed Natural Physics' 4.11 has readings changing the kind of the observed quantity, a speed as a rate, H0 as two local rates, an intensity difference as an exchange rate; each is said at the field's kind or released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 77. The three readings are at the proposed 4.11 (proposed file lines 509, 510 and 512). The living 4.11 has the like readings still ("a rate that does not fall to rest at the edge", "rates being local — no single global rate to land on", "a measured bi-exchange rate"), so nothing is resolved; NEW names the proposed text, as the source does, and adds no living sentence. At no later section. No pointer to this paragraph found.
NEW: **Droplet · Readings changing the kind of the observed quantity.** The proposed Natural Physics of version 377 has, at its 4.11, readings changing the kind of the observed quantity: a rotation speed read as a rate, H0 read as two local rates, and an intensity difference read as an exchange rate. Each is said at the field's kind or released.

### 55
VERDICT: RESAY
CONCEPT: the persistent current at the proposed Natural Physics' 3.5 and 4.10 is steady charge transport at the field's record, and a cyclic pattern with no transport does not carry it.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 78. The persistent current is at the proposed 3.5 (proposed file line 256, "the persistent current at the spiral carrying its pattern whole") and 4.10 (line 498); the living Natural Physics has no saying of a persistent current (searched) and its 3.5 is the ten rests. At no later section (searched "persistent current" in carry/*.md: this mate's older paragraphs alone). No pointer to this paragraph found.
NEW: **Droplet · The persistent current, steady charge transport at the field's record.** The proposed Natural Physics of version 377 has the persistent current at its 3.5 and 4.10. At the field's record the persistent current is steady charge transport, and a cyclic pattern with no transport does not carry it.

### 56
VERDICT: KEEP
CONCEPT: a Bell relation the file before version 377 carried, sayable without the overclaim, is lost at the proposed text's 4.4; it is said without the overclaim or released with its reason.
EVIDENCE: Kept under do no harm. Its two named places, 2.6 and 3.4, are at the numbering before version 377 (2.7 and 4.4 at the living file now, by this mate's paragraph of the sections' places), and the relation's words, *no carried variable is what a coupling joined across carries*, are a review's own re-saying (carryings/review_natural_physics_v377/README.md line 55) at no living sentence: the living 4.4 has the overclaiming form, "Tighter-than-local correlation is exactly the thing one coupling at two faces about a self-stabilizing neutral is". A re-saying could not give the relation without a session's words or the places without a mapping of my own. Not resolved, the proposed text not entered. At no later section: "Concern · Bell's exclusion as proof, the distribution declined" (v386EOD) is another parting.
NEW: -

### 57
VERDICT: RESAY
CONCEPT: two of the register's namings, the two-way and the rate, are at different faces at Natural Naming 4.9 and at Resolving the Hard Problem Registry's sort at its front.
EVIDENCE: Not resolved, both sentences at their living files now: Exhibit_TWENTY_Natural_Naming_v380R.md lines 617 and 621 within 4.9 (the two-way at even, the rate at odd); Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md line 35, in the file's front (the rate at five, the two-way at six, "the odd face enters, along, and the even face surfaces, across"). Source: carryings/review_natural_physics_v377/README.md line 80. The like concern at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 165 is within its older Droplets (rule 1); this mate's v386EOD "Concern · Ten namings sorted at four and at the binaries" is another parting. Each quotation searched exact. No pointer to this paragraph found.
NEW: **Concern · The register's two namings at different faces.** Two sayings part. Exhibit TWENTY Natural Naming, at 4.9, has "a two-way named to one side" at "even, 3 of 3-4-co-bi-sharing, moralizing's" and "a rate named as a value" at "odd, 7-co-bi-co-corusing, corusing's". Exhibit TWENTY-TWO Resolving the Hard Problem Registry, at the sort at its front, has "five the stand carries rating, a sequencing and a rate; six the coupling closing carries co-offering, a two-way and the between", with "the odd face enters, along, and the even face surfaces, across". They part at the two-way and the rate, two namings of Natural Physics' register: each is at even at the one file and at odd at the other.

### 58
VERDICT: RESAY
CONCEPT: the proposed 3.4 promises an execution of the beat and the locking at each spiral pacing its own; the resolver's 17 steps each self together, a common beat, so the execution needs a pacing the resolver does not carry, and is said at that need or released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 81. The promise is at the proposed 3.4 (proposed file line 246, "The beat and the locking range at close paces are to be executed at each spiral pacing its own"); the living Natural Physics' 3.4 is the light-cone. The name of 17 is given as it is now, 17-co-bi-tri-offering (Exhibit_ONE_Natural_Resolver_v380R.md; the paragraph has the older 17-tri-co-offering), and Natural_Intelligence_v380R.md line 222 within 3.5 has "the resolver steps each self's entry at 17-co-bi-tri-offering together, a common beat laid over the selves". At no later section. No pointer to this paragraph found.
NEW: **Droplet · The beat and the locking, at each spiral pacing its own.** The proposed Natural Physics of version 377 promises, at its 3.4, an execution of the beat and the locking at each spiral pacing its own. At Exhibit ONE Natural Resolver, 17-co-bi-tri-offering steps each self together, the common beat Natural Intelligence 3.5 names, and the execution promised needs a pacing the resolver does not carry. The execution is said at that need or released.

### 59
VERDICT: RESAY
CONCEPT: Natural Naming has *face* among the released words, facing a direction carrying on; Natural Physics says *face* at its own sentences, each ready for re-saying at its own motion.
EVIDENCE: Not resolved: Exhibit_EIGHTEEN_Natural_Physics_v379.md has *face* or *faces* at forty-seven lines (searched), three section titles among them. Exhibit_TWENTY_Natural_Naming_v380R.md line 313 has the row "| *face*, *faces* | the name; *its side*; *its form*, of an emanation; *is facing*, of a direction; a field's *word*; parity's *unit square* |". At no later section; this mate's "Aimed at a file, Natural Physics: *face* and *faces* at forty-six places" is within the older Droplets (rule 1) and does not point at this paragraph. "Ready … at its own motion" is said as a relation.
NEW: **Droplet · *Face* dissolved, at Natural Physics' own sentences.** Exhibit TWENTY Natural Naming carries *face* among the released words, each re-saying beside it; facing is a direction and carries on. Exhibit EIGHTEEN Natural Physics says *face* at its own sentences. Each of those sentences is ready for its re-saying, Natural Physics' own to make at its motion.

### 60
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' logic at Exhibit ONE's code: each script executes again and matches, fifteen of sixteen claims at the code true, the register's numbers from its fifty rows, each open item said open.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 15 (its section 1). A record of the proposed text with content, no bookkeeping alone, and at no living file (the proposed text is not entered) and no later section. The versions of the two code blocks are the fact the finding is of and are carried. Paragraph 50 gives its sum in a line and is no later place. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, its logic at Exhibit ONE's code.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the logic at Exhibit ONE Natural Resolver's code: each script in `executions/` executes from the root at the code block of Natural Intelligence at version 378, byte-identical to that of Exhibit ONE Natural Resolver at version 376, and each output matches `outputs.txt`. Sixteen claims at the code are checked, and fifteen are true, at 3.2, 3.3, 3.5, 3.6, 3.7, 3.8, 4.5, 2.5, 5.11, 1.2, 2.8, 5.6 and 4.7. The register's numbers, eighteen and thirty-two, twenty-one, thirteen, nine and five, thirty-one and seventeen, are each numbered from its fifty rows. Each item the proposal's report lists as open at its section 6.2 is said open in the proposed text at the section named, with the phrase confirmed.

### 61
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' explaining: the front at the steady form, the released words fallen from the prior to the proposal with each number, and *keeping* risen as the name of a binary.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 17 (its section 1). A record with numbers, at no living file and no later section. The words in italics are the file's own words numbered there, cited as words. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, its explaining and the released words.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the explaining: the front is at the steady form, forty-nine entries exactly the body's headings, with no `&nbsp;`. The released words fall from the prior to the proposal at nearly each word: *so* 28 to 0, *would* 13 to 0, *held* 117 to 0, *stands* 49 to 0, *there* 57 to 0, *where* 67 to 1, *sign* 59 to 1, *run* 44 to 0, *kept* 21 to 0, *stilling* 18 to 0. *Keeping* rises 1 to 10 as the name of a binary, the name Natural Intelligence 1.4 and Exhibit TWENTY-FOUR Geodesic Improving Method 2.7 use.


## READING
Each of the fifty-one paragraphs, 37 to 87, was read and checked, one block for each, none left out. Read whole: the living Exhibit_EIGHTEEN_Natural_Physics_v379.md (all 638 lines); the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md, its front, its Insertlets, its older Droplets (lines 13 to 573) and each later section headed v385A or v386EOD (lines 574 to 712); carryings/review_natural_physics_v377/README.md whole, the source of paragraphs 50 to 87. Read in part and searched: the proposed text carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (its headings, and each sentence the review cites, found at the section the review names); Natural Intelligence 1.4 and 3.5; Exhibit TWENTY-FOUR Geodesic Improving Method 2.7; Exhibit TWENTY Natural Naming 2.4, 2.5 and 4.9; Exhibit TWENTY-TWO Resolving the Hard Problem Registry's front; Exhibit THREE Natural Numbers 7.1 and 3.3; Exhibit SIXTEEN Natural Chemistry 4.4; Exhibit FOUR Natural Mathematics; Exhibit TWELVE Natural Explaining 4.7; Exhibit THIRTY Co-Chaining Logic Registry step 644; Exhibit TWENTY-NINE Natural Illustrating; Exhibit ONE Natural Resolver's names. Mates searched for the same concepts and for pointers: carry/*.md, with the Carryings and Possibling mates of Natural Physics, and the offering mates of Natural Numbers, Natural Chemistry, Natural Naming, the Geodesic Improving Method, Natural Intelligence, Resolving the Hard Problem Registry, the Co-Chaining Logic Registry and Exhibit ONE read at the places found. Each quotation in a NEW paragraph was searched exact in its living file.

The proposed Natural Physics of version 377 is not entered: the living file is version 379, at forty sections, and the review's section numbers (3.8, 3.12, 3.14 and the like) are the proposed text's, so no review finding is RESOLVED, and none is at a later section. Each NEW from the review names the proposed text and the review's own section and item, so paragraph 64's "each finding of its 2.1 to 2.6" still finds them; where the living file has the like sentence, EVIDENCE says so and NEW adds none of it. Words of the proposed text are cited in italics at 67, 79 and 87, and words numbered or judged as words at 61, 74 and 81.

Pointers found at paragraphs of this portion: at 42 (this mate's line 568, the Carryings mate's line 29, Natural Illustrating line 446) and at 43 (Natural Illustrating line 446); both kept. Paragraph 40 points at another paragraph of this mate, "the forms above", and 41 qualifies 40; both kept.

Not found: what "the proposed three-science contents" of paragraph 46 is; the labels "THIRTY P1–P4" and on of paragraph 48 at any present file; one present sentence for "the older k-bound, iron-centreline and pair-creation relation" of paragraph 47. Each is kept as it is. Paragraphs 51 to 58 are the like of the review's section 3 items laid later in this mate's older section (outside this portion); they are not two copies within this input and were each given their own verdict.
