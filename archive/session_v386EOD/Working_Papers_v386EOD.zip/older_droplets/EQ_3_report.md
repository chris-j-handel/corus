### 46
VERDICT: RESAY
CONCEPT: the registry's sentence of a hard problem with its hardness ignored, the competency of existing a given, is at no step of the Co-Chaining Logic Registry, and a step is proposed for it.
EVIDENCE: Row 26 of carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 52), a pointer in the map's shorthand with no step number to carry; its proposed step S19 is at that file's line 164, and NEW has only that step's sentence, its place left out as the paragraph leaves it out. Checked now: the living file's 2.1 (line 126) has both sentences, exact. Each of the 661 steps of Exhibit THIRTY Co-Chaining Logic Registry v380L was read: "hardness" is at step 335 alone ("the field's own account of its hardness"), "as a given" at none; step 504 has "no accounting for the changing's competency", another saying. No later section says it: this mate's "Droplet · Equilibria, competency said as a stable form" (v386EOD) quotes the second sentence for another concept. No paragraph points at it (searched "item 26" and "S19" in carry/*.md; paragraphs 90 and 91 name neither).
NEW: **Droplet · A hard problem with its hardness ignored, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 2.1 has "Each proposed conception of equilibria is a hard problem with its hardness ignored." and, of that conception, "It takes the competency of existing as a given". No step of Exhibit THIRTY Co-Chaining Logic Registry has a hard problem's hardness ignored, or the competency of existing as a given. A step is proposed for it: a conception naming existing's continuing as given, and accounting against it, is a hard problem with its hardness left out. The step may change or never be made.

### 47
VERDICT: KEEP
CONCEPT: the registry's true-and-false conserving accounting, read against the Registry of version 376: carried by a step with an unsure line alone, with conserving named at no step.
EVIDENCE: Paragraph 90 of this section names it by its item ("These carry items 27, …") and stays, so under rule 2 it stays as it is. What it is now: the three sentences are at the living file as quoted (2.1, 1.5 and 4.1). The map's steps 184 and 185 are steps 310 and 311 of Exhibit THIRTY Co-Chaining Logic Registry v380L; the unsure line is gone and step 312 says what it asked ("Accounting against forms named still, the scientific method carries no changing of its own: no method of existing, and no second method beside the one."). "Conserving" is still at no step (searched "conserv": none). Part resolved, part not; no later section says the part left.
NEW: -

### 48
VERDICT: RESAY
CONCEPT: the registry's unstable deforming at non-living scale is at no step of the Co-Chaining Logic Registry, the step of scale beside it has an unsure line, and a step is proposed for it.
EVIDENCE: Row 28 of cover_EQUILIBRIA.md (line 54), a pointer in the map's shorthand; its proposed step S22 is at that file's line 167, and NEW has only that step's sentence. Checked now: the living file's 2.1 (line 128) and 3.4 (line 221; the map's "§3") have the two sentences, exact. The map's steps 13 and 212 are of the Registry of 264 steps it was read against (git 8e24fa8); found by their sentences they are steps 15 ("Carrying none of prior, a non-living thing is changing with the existing things at now: co-changing.") and 379 ("At each scale and momentary an existing thing is living or non-living, and a living self and its non-living emanation are each at a scale.") of Exhibit THIRTY Co-Chaining Logic Registry v380L, and step 379 still has its line "*Unsure: the saying may need its own steps once scale is fuller.*" "Deforming" is at no step (searched; each step read). At no later section. No paragraph points at it (searched "item 28", "S22").
NEW: **Droplet · Unstable deforming, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 2.1 has "stable-forming, and unstable deforming at non-living scale, are observably existing", and its 3.4 has "the non-living exist, arrive and change, deforming at their own scale, and carry nothing". The steps of Exhibit THIRTY Co-Chaining Logic Registry beside them are 15 and 379: unstable deforming is at no step, and step 379, of scale, has an *Unsure* line. A step is proposed for it: carrying none of the prior, a non-living existing thing's form co-changes at each momentary, unstable deforming, the non-living's. The step may change or never be made.

### 49
VERDICT: KEEP
CONCEPT: the registry's sentences of the non-living (carrying nothing, forms continuing through their changing, offering its signs), read against the Registry of version 376: carried once reworded, a conflict at two of its wordings, and an older word.
EVIDENCE: Unsure of what it is now. The living file's 2.1 (lines 130 and 132) still has "carrying nothing, their forms continuing through their changing" and "offering its signs and carrying nothing". The Registry has moved at both readings: Exhibit THIRTY Co-Chaining Logic Registry v380L has, at step 24, "a non-living thing is an existing thing carrying nothing into next", at step 391 "A non-living existing thing carries nothing into next.", and at step 43 "a non-living existing thing, a stable form, its form continuing through its changing and carrying none of the prior". Whether the map's conflict is still a conflict beside these steps could not be settled by reading, and "reword at 13" could not be read with certainty (the map's step 13 is step 15 now). The mate's older `## Insertlets` has a re-wording of the sentence, under the same reading as this section and no later place. No later section says it.
NEW: -

### 50
VERDICT: KEEP
CONCEPT: the registry's sequence of an equilibrium's ending at the occurrence that fails, read against the Registry of version 376: ending at the first failing next at no step, with three of its words noted.
EVIDENCE: Part resolved, part not, and the part left could not be said at its strength. Exhibit THIRTY Co-Chaining Logic Registry v380L now has the step, "150. Named still, the changing's first next differing from the naming is the naming's one failing momentary, the momentaries before it arriving as they arrived and the changing continuing past it." with "*Adding: the one failing momentary.*" and no unsure line; its entering from this passage is at carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md, item 8. The word note is not met: the living file's 2.1 (line 134) still has "The equilibrium holding ends", "The sequence keeps one subject" and "the holding ends there". A release drops the word note (rule 3), and "Words: holding, keeps, ends" gives no claim a re-saying could carry beyond the three words. The mate's older `## Insertlets` has the passage re-worded, no later place. The map's steps 100 and 176 are steps 149 and 297 now.
NEW: -

### 51
VERDICT: RESAY
CONCEPT: of the registry's three things a naming still is placed at, the part left is one reading: the dynamical-mathematics clause is field wording at the field's result.
EVIDENCE: Row 33 of cover_EQUILIBRIA.md (line 59). Three of its parts are resolved and the fourth is re-said (rule 3). (1) "The stability can change, the form can change, the relation can change" is gone from the living file: 2.2 (line 138) now has "A mathematical conception of equilibria names a stability, a form or a relation still, each read, as suggested, as stable forming." (2) "The three objects of a naming still are at no step" is met, the proposed step S24 (cover line 169) entered: Exhibit THIRTY Co-Chaining Logic Registry v380L has "339. A changing named still is named at a stable-forming, at a stable form or at a relation between existing things, each of the three changing." with "*Adding: the three namings still.*" and no unsure line; its entering from this sentence is at carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md, item 16. (3) The map's steps 97 and 99 (steps 144 and 148 now) had nothing asked of them. (4) The reading of the dynamical-mathematics clause is at no living file and no later section; NEW says it whole. The clause is at 2.2 (line 138), exact, the same sentence the map read (the file at version 375, git 920a6f0, line 151); "at the field's result" is the Registry's own naming (steps 316 and 319). The second sentence the paragraph quotes, "it places the still a conception names at the stability, the form or the relation", is unchanged at 2.2. No paragraph points at it (searched "item 33", "S24"; paragraphs 90 and 91 name neither).
NEW: **Droplet · The dynamical-mathematics clause, field wording at the field's result.** Exhibit TWENTY-EIGHT Equilibria Registry 2.2 has "In dynamical mathematics a stability is a pattern's response to a disturbance, its departures staying small or shrinking, and not its constituents stopping: an oscillation can be stable as an oscillation, and an instability, its departures growing, can lead to another organized form." The clause is field wording at the field's result.

### 52
VERDICT: RESAY
CONCEPT: the registry's surviving, binary and shown by each conception at prior, now and next: its move is carried by three steps of the Co-Chaining Logic Registry, its definition is at no step, and a step is proposed for it.
EVIDENCE: Row 35 of cover_EQUILIBRIA.md (line 61), a pointer in the map's shorthand; its proposed step S25 is at that file's line 170, and NEW has only that step's sentence. Checked now: the living file's 2.2 (lines 142 and 144) has the sentences, exact. The map's steps 5, 18, 44 and 97 are of the Registry of 264 steps (git 8e24fa8); found by their sentences they are steps 6 ("Momentary by momentary, three sequential momentaries are prior, now and next."), 25 ("Possible at prior, existing at now and living at next are three places, and the universe is changing through the three together."), 65 ("Each resolving is all or none at all, of no size beside another resolving.") and 144 ("The same at all momentaries at once is a form still, step 46, not possibly existing in the changing set.") of Exhibit THIRTY Co-Chaining Logic Registry v380L, none with an unsure line. "Surviving" is at step 567 alone, of an offering at a file's improving, another subject; no step defines it (each step read). At no later section. No paragraph points at it (searched "item 35", "S25").
NEW: **Droplet · Surviving, its definition at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 2.2 has "Surviving is binary." and "A conception of equilibria shows its own surviving." with "It exists at prior, now and next, or it is not possible at the momentarying." The steps of Exhibit THIRTY Co-Chaining Logic Registry beside them are 6, 25, 65 and 144: the move is carried by steps 6, 65 and 144, and the definition of surviving is at no step. A step is proposed for it: all existing things at now arriving at next together, all or none at all, is surviving. The step may change or never be made.

### 53
VERDICT: RESAY
CONCEPT: the registry's one general description, each conception a membership (a fixed value, a range, opposition): membership is at no step of the Co-Chaining Logic Registry, the set rests on its step 2, and a step is proposed for it.
EVIDENCE: Row 36 of cover_EQUILIBRIA.md (line 62), a pointer in the map's shorthand; its proposed step S26 is at that file's line 171, and NEW has only that step's sentence. Checked now: the living file's 2.3 (line 148) has both sentences, exact. "Membership" is at no step of Exhibit THIRTY Co-Chaining Logic Registry v380L (searched; each step read). Step 2 is step 2 still, "A set is an existing thing." One part is resolved and left out of NEW: the map's "(OPEN)" named that step's unsure line of version 376, "whether the universe, the set, is one of its existing things waits on a step of its own"; the line is gone, and step 3 now has "The universe is both the set of all existing things and an existing thing within the set of all existing things: the fractal inward and outward of itself." At no later section. No paragraph points at it (searched "item 36", "S26"); paragraph 79 has the same clause of the set and is re-said the same way.
NEW: **Droplet · Membership, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 2.3 has "One general description receives each conception: a stated relation continuing through the comparisons its claim names." and "A fixed value is membership in a collection of one, a range is membership in a larger collection, and opposition is membership among opposite pairs." Membership is at no step of Exhibit THIRTY Co-Chaining Logic Registry, and the set rests on its step 2. A step is proposed for it: a form named still is a relation named the same at each comparison it names, membership in a set of one or more. The step may change or never be made.

### 54
VERDICT: RESAY
CONCEPT: the registry's one conception with its added requirements, and a changed receiving a further conception, are at no step of the Co-Chaining Logic Registry, and a step is proposed for them.
EVIDENCE: Row 37 of cover_EQUILIBRIA.md (line 63), a pointer in the map's shorthand; its proposed step S27 is at that file's line 172, and NEW has only that step's sentence. Checked now: the living file's 2.3 (line 150) has both sentences, exact. The map's step 44 is step 65 of Exhibit THIRTY Co-Chaining Logic Registry v380L, the same sentence ("Each resolving is all or none at all, of no size beside another resolving."). No step has a conception with a requirement added or a changed receiving ("requirement" is at step 248 alone, of a form named still failing at its own requirements; each step read). At no later section. No paragraph points at it (searched "item 37", "S27").
NEW: **Droplet · One conception with its added requirements, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 2.3 has "A conception and its added requirements are one conception." and "A changed receiving is a further conception." The step of Exhibit THIRTY Co-Chaining Logic Registry beside them is 65, and neither saying is at a step. A step is proposed for them: a form named still with a requirement added is one form named still, its requirements together, all or none at all. The step may change or never be made.

### 55
VERDICT: KEEP
CONCEPT: the registry's one shape of the claim, natural torusing carrying its whole participation, 12345, read against the Registry of version 376: carried by steps with unsure lines alone.
EVIDENCE: Paragraph 91 of this section names it by its item ("with S28, item 38") and stays, so under rule 2 it stays as it is. What it is now: the first two sentences are at the living file's 2.3 and 2.4 as quoted; the third, "Opposition and its receiving alone name part of the carrying as the whole", is gone from it. The map's steps 70 and 241 are steps 217 and 479 of Exhibit THIRTY Co-Chaining Logic Registry v380L, each with no unsure line now; "participation" and "12345" are at no step. Part resolved, part not.
NEW: -

### 56
VERDICT: KEEP
CONCEPT: the registry's ordering chain closing at the two faces and its one exclusion, a binary retaining and inverting at one next, read against the Registry of version 376: the exclusion carried, its premise resting on two steps with unsure lines, one older writing.
EVIDENCE: Paragraph 91 of this section names it by its item ("carry items 18, 20, 22 and 39") and stays, so under rule 2 it stays as it is. What it is now: the sentences are at the living file's 2.3 and 5.2 as quoted, and 5.2 still has "with p either +1 or −1". The map's steps 39 and 31 are steps 57 and 42 of Exhibit THIRTY Co-Chaining Logic Registry v380L, each with no unsure line now, the sixteen ways of a next entered at steps 53 to 56.
NEW: -

### 57
VERDICT: KEEP
CONCEPT: the registry's still named as the complete continuing, its continuing a renewing, and group C's renewal excluded, read against the Registry of version 376: renewing at no step, a tension with the step of a sharing once chained, and older words.
EVIDENCE: Paragraph 91 of this section names it by its item ("These carry items 40, …") and stays, so under rule 2 it stays as it is. What it is now: 2.4 has "Its continuing is renewing" as quoted; group C's "Presence beyond its retaining bound requires renewal" is gone, 5.1 now having "Presence carries renewal, and the conception excludes that renewal." and "A carrying once chained is carried at each momentary and is never none again."; of the older words it lists, "second sign", "fresh writing", "counts couplings" and "co-bi-exchanging" are gone from the living file. "Renew" is at no step of Exhibit THIRTY Co-Chaining Logic Registry v380L; the map's step 136 is step 210 now. Part resolved, part not.
NEW: -

### 58
VERDICT: KEEP
CONCEPT: the registry's state accounting and flow accounting each leaving one side out, read against the Registry of version 376: state and flow at no step, the reading agreeing with the Living Ghost Registry's 7.6.
EVIDENCE: Paragraph 90 of this section names it by its item ("These carry items 27, 41, …"), and carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md points at it ("This is item 41"); under rule 2 it stays as it is. What it is now: the sentence is at the living file's 2.4 as quoted, and Exhibit THIRTY Co-Chaining Logic Registry v380L now has state and flow at steps 504 to 506 ("the flow accounting leaving out the continuing, and the state accounting leaving out the changing."), with no unsure line. The agreeing with the Living Ghost Registry's 7.6 is at no living file.
NEW: -

### 59
VERDICT: KEEP
CONCEPT: the registry's "Coupled, each releases", read against the Registry of version 376: at the explored steps of the scientific method alone, to be entered.
EVIDENCE: Paragraph 90 of this section names it by its item ("These carry items 27, 41, 43, …") and stays, so under rule 2 it stays as it is. What it is now: the sentence is at the living file's 2.4 as quoted; the explored step is entered at Exhibit THIRTY Co-Chaining Logic Registry v380L as step 317 ("the fixings released, the observings carried at the opening sentence"), and the map's step 189 is step 345 now.
NEW: -

### 60
VERDICT: KEEP
CONCEPT: the registry's each momentary completing in co-releasing, geodesic co-releasing, read against the Registry of version 376: the naming co-releasing at no step, and an older word, sign.
EVIDENCE: Part resolved, part not, and unsure of the part left. Exhibit THIRTY Co-Chaining Logic Registry v380L now names co-releasing, at step 466 ("… goes forward: co-releasing." with "*Adding: co-releasing.*"); whether that step says the living file's "Each momentary completes in co-releasing" could not be settled by reading, and "geodesic co-releasing" is at no step. The older word is still at the living file's 2.4 (line 168): "whether a sign changed, stayed, crossed or nothing crossed". The map's steps 67, 182 and 189 are steps 108, 306 and 345 now. A release drops the word note and the second naming (rule 3). No later section says it.
NEW: -

### 61
VERDICT: KEEP
CONCEPT: the registry's hard problem and its resolving as one form at two faces, natural intelligence between them, read against the Registry of version 376: the two faces at no step, and an older word, membrane.
EVIDENCE: Paragraph 90 of this section names it by its item ("These carry items 45, …") and stays, so under rule 2 it stays as it is. What it is now: the living file's 3.1 has "natural intelligence at the between of them", the older word gone; Exhibit THIRTY Co-Chaining Logic Registry v380L has the step, 330, "… are one form as two: the form named still and the form resolving.", with no unsure line. On its own reading it is resolved.
NEW: -

### 62
VERDICT: KEEP
CONCEPT: the registry's proposed conception of equilibria as the sixth condition after five conditions prior, read against the Registry of version 376: the five and the sixth at no step, and a word noted, stand on.
EVIDENCE: Paragraph 90 of this section names it by its item ("46 (with S34)") and stays, so under rule 2 it stays as it is. What it is now: Exhibit THIRTY Co-Chaining Logic Registry v380L has the step, 322, "The accounting's fixings are five conditions prior, each named unchanged: … and a problem's own relation named still over its reach is its sixth, an equilibrium."; the living file's 3.1 still has "is the one the first four stand on". Part resolved, part not.
NEW: -

### 63
VERDICT: KEEP
CONCEPT: the registry's numerical bridge and its sayings in numbers, read against the Registry of version 376: at no step, two tensions with steps of the four momentaries and of the six, older words, and one clause to re-say or release.
EVIDENCE: Mixed, and unsure of the whole now. Resolved parts: the retained-carrying clause is gone (3.3 now has "and it carries no number of its openings"), and "second sign", "9-other-releasing" and "downstream" are gone from the living file; the bridge is now at steps 124 and 125 of Exhibit THIRTY Co-Chaining Logic Registry v380L ("the gap exactly one at each centre"). Parts not met: 3.3 still has "The three openings 1+3+5 sum to 9 = 3²", "three at three is nine" and "Six consecutive changings from 3 complete at 8"; the two tensions are with steps 73, 75 and 81 now, and whether each is still a tension could not be settled by reading. A release drops the tensions and the word *sum* (rule 3); a re-saying of so many parts, some met, could not be made with each at its strength. The mate's older `## Insertlets` has "sum to 9" re-worded, no later place.
NEW: -

### 64
VERDICT: KEEP
CONCEPT: the registry's addresses of the ten at the resolver's names, a ring of ten names, read against the Registry of version 376: adjacencies of the older resolver's names, at no step.
EVIDENCE: Paragraph 90 of this section names it by its item ("These carry items 45, 48, …") and stays, so under rule 2 it stays as it is. What it is now: the sentence and the ring are gone from the living file; its 3.2 has "This file's naming ring before, whole at `archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_the_ten_seated_v375.md`, seated each at an edge of two names". On its own reading it is resolved.
NEW: -

### 65
VERDICT: KEEP
CONCEPT: the registry's ten as five places from two faces, read against the Registry of version 376: the two faces carried, the five pairs and the ten at no step, a tension at co-offering's place.
EVIDENCE: Three places point at it and stay: paragraph 90 ("items 45, 48, 49, …"), paragraph 70 ("Also waits on the ten (item 49)"), and carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md ("This is item 49"); under rule 2 it stays as it is. What it is now: the living file's 3.3 has the five places with no pair names (ageing, middling, rating and co-offering are gone from it); Exhibit THIRTY Co-Chaining Logic Registry v380L has the ten named still at steps 334 and 504 to 523, and seats them at the names 1 to 8 by the four-cycles (step 522), a seating the living file's 3.2 itself sets beside its own. The five places at 2 to 6 are at no step. Part resolved, part not.
NEW: -

### 66
VERDICT: KEEP
CONCEPT: the registry's placing of a conception at the ten by its own declared relation, a matched word placing it at none, with its sixty-three conceptions, read against the Registry of version 376: placing at no step, the numbers checked.
EVIDENCE: Paragraph 90 of this section names it by its item ("items 45, 48, 49, 50, …") and stays, so under rule 2 it stays as it is. What it is now: the sentences are at the living file's 3.2 and 4.1 as quoted, and its 4.3 to 4.12 give 2, 5, 8, 10, 6, 9, 5, 5, 7 and 6 arrivals; Exhibit THIRTY Co-Chaining Logic Registry v380L has, at step 335, a hard problem "at the naming still its statement carries", and no step has a matched word placing at none. The map's step 252 is step 538 now.
NEW: -

### 67
VERDICT: RESOLVED
CONCEPT: the registry's four-cycles partnering at the momentaries, each round the other way, read against the Registry of version 376: the four four-cycles carried, the partnering at no step, two older names.
EVIDENCE: Each part is met. The step asked for is at Exhibit THIRTY Co-Chaining Logic Registry v380L: "602. A form's partner is the form its names make, each exchanged with the name beside it: at the momentaries opening odd, 1 with 2 on to 15 with 16, and at the momentaries opening even, 2 with 3 on to 16 with 17, steps 70, 73 and 166. Each partner other than the form itself is spiraling the other hand, steps 257 and 521; …" with "*Adding: a form's partner, at the momentaries opening odd and opening even.*" and no unsure line, and "521. At 1 to 17 the four-cycle through 3 and the four-cycle through 4 partner round the other way: …"; the four four-cycles are at step 257 (the map's 144). The two older names, 6-other-crossing and 14-social-crossing, are gone from the living file (searched: none), whose 3.4 now has "Exhibit ONE's four-cycles pair at the momentaries, each partner round the other way." and "the middle four-cycle 7-11-6-10, through 6-bi-co-bi-moralizing, and the eight-cycle 2-15-7-11-3-14-6-10, through both, partner themselves at the even momentary: at that momentary the fold meets itself, Exhibit ONE's table of twelve forms." The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 83). No paragraph points at it (searched "item 52", "S37" in carry/*.md; paragraphs 90 and 91 name neither).
NEW: -

### 68
VERDICT: KEEP
CONCEPT: the registry's one sign offered once co-chaining through the whole with no forcer, and its ring table, read against the Registry of version 376: carried by a step with an unsure line alone, with older words.
EVIDENCE: Paragraph 91 of this section names it by its item ("items 40, 23, 53, …") and stays, so under rule 2 it stays as it is. What it is now: the living file's 3.4 has "One parity offered once co-chains through the whole.", the old names gone; its ring table still has "+, 0, −, 0" and "neighbours opposite". The map's step 82 is step 230 of Exhibit THIRTY Co-Chaining Logic Registry v380L, of a spiral of selves, with no unsure line now. Part resolved, part not.
NEW: -

### 69
VERDICT: KEEP
CONCEPT: the registry's rest returning at no coupling, no ring meeting rest across 5,000 couplings, read against the Registry of version 376: a result of the resolver's executing, at no step.
EVIDENCE: Paragraph 91 of this section names it by its item ("items 40, 23, 53, 54, …") and stays, so under rule 2 it stays as it is. What it is now: the sentences are at the living file's 3.4 as quoted; Exhibit THIRTY Co-Chaining Logic Registry v380L has a showing at the resolver's executing at step 248 and the break's rest at steps 308 and 611, and whether these say the proposed step could not be settled by reading. The map's step 182 is step 306 now.
NEW: -

### 70
VERDICT: KEEP
CONCEPT: the registry's common clock as the seventh way, a sequencing named to one beat, read against the Registry of version 376: carried by a step with an unsure line alone, and resting on the ten.
EVIDENCE: Paragraph 90 of this section names it by its item ("items 45, 48, 49, 50, 56, …") and stays, and it points at paragraph 65 ("item 49"), which stays; under rule 2 it stays as it is. What it is now: the sentence is at the living file's 3.4 as quoted; the map's step 34 is step 46 of Exhibit THIRTY Co-Chaining Logic Registry v380L, "… a fixed form, a form still, the same at all momentaries at once; … a common beat, a clock over it; …", with no unsure line now, and step 522 has "4 a sequencing named to one beat".
NEW: -

### 71
VERDICT: KEEP
CONCEPT: the registry's "Nothing moving is complete fixing, meeting several of the ten at once", at no step of the Registry of version 376, with a step proposed.
EVIDENCE: Paragraph 90 of this section names it by its item ("items 45, 48, 49, 50, 56, 57 …") and stays, so under rule 2 it stays as it is. What it is now: the sentence is at the living file's 3.4 as quoted, and "complete fixing" is at no step of Exhibit THIRTY Co-Chaining Logic Registry v380L.
NEW: -

### 72
VERDICT: RESOLVED
CONCEPT: the registry's ten names and six connectors as the seventeen, carried at the Registry of version 376, with the file's own sentence leaving their correspondence with the ten ways open.
EVIDENCE: The sentence it concerns, "Their correspondence with the ten ways is the next discovering", is gone from the living file (searched "next discovering": none; it was at the file of version 375, git 920a6f0, line 223), and the living file's 3.4 now says the correspondence: "The ten ways sit at 2 to 6 and 10 to 14, 3.2: the four across connectors, 2, 6, 10 and 14, the square of parity's face, Exhibit ONE's naming of parity's square and triangles, and Exhibit ONE's faces 3, 4, 5, 11, 12 and 13; its faces 7, 8, 15 and 16, the along connectors 9 and 17, the two triangles of parity's face, and the entry 1 carry none of them." The rest of the paragraph asks nothing: the item was carried, and its steps (136, 139, 141, 143 and 147 of 264) are steps 210, 226, 250, 255 and 264 of Exhibit THIRTY Co-Chaining Logic Registry v380L, none with an unsure line. The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 89). No paragraph points at it (searched "item 58"; paragraphs 90 and 91 do not name it). Other paragraphs of this section on the ten's seatings are their own subjects and are not touched.
NEW: -

### 73
VERDICT: RESAY
CONCEPT: the registry has a fixing named unchanged naming its subject still through one further step, from a fixing to an equilibrium; the Co-Chaining Logic Registry has the fixing named unchanged as the form still itself; the further step is at no step, and a step is proposed.
EVIDENCE: Row 61 of cover_EQUILIBRIA.md (line 97), a pointer in the map's shorthand; its proposed step S41 is at that file's line 198, and NEW has only that step's sentence. Checked now: the living file's 4.1 (line 243; the map's "§4") has the sentence, exact. The map's step 185 is of the Registry of 264 steps (git 8e24fa8); the same sentence is step 311 of Exhibit THIRTY Co-Chaining Logic Registry v380L, exact, with no unsure line. The map's "explored Sci. 4" (carryings/co_chaining_map_v376/Explored_Steps_v376.md, "A fixing named unchanged between two momentaries is two momentaries taken as one: a form named still, an equilibrium.") is entered at that same step, so NEW names step 311 for both. The parting is still open: carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md, contradiction 10, has it at version 378, and no step has a step from a fixing to an equilibrium (each step read). At no later section. No paragraph points at it (searched "item 61", "S41"; paragraphs 90 and 91 name neither).
NEW: **Concern · A fixing and an equilibrium, one further step or none.** Two sayings part. Exhibit TWENTY-EIGHT Equilibria Registry has, at 4.1, "A law, a frame or a scale named unchanged is such an expression, and it names its subject still through one further step, the step from a fixing to an equilibrium". Exhibit THIRTY Co-Chaining Logic Registry has, at step 311, "A fixing named unchanged between two momentaries is a form still, and the two methods part at that one naming." They part at the fixing named unchanged: at the Registry it is the form named still itself, and the one further step is at no step. A step is proposed: a fixing's expression is an offering at words, a non-living existing thing, and named of its subject, unchanged at the next its subject's continuing changes, it is a form named still. It may change or never be made.

### 74
VERDICT: KEEP
CONCEPT: the registry's placing of the scientific method at its fixings, read against the Registry of version 376: carried by a step with an unsure line alone, at the explored steps to be entered.
EVIDENCE: Paragraph 90 of this section names it by its item ("62, 64 (with S43)") and stays, so under rule 2 it stays as it is. What it is now: the sentence is at the living file's 4.14 as quoted (the map's "§4"); the map's steps 184 and 185 are steps 310 and 311 of Exhibit THIRTY Co-Chaining Logic Registry v380L, the unsure line gone and the explored steps entered at steps 310 to 312. On its own reading it is resolved.
NEW: -

### 75
VERDICT: RESAY
CONCEPT: the registry has evidence giving the prior as possible and as actual, from non-living sources; the Co-Chaining Logic Registry's step gives the prior's possible, from a living self at prior; as actual, and evidence from a non-living source, are at no step, and two steps are proposed.
EVIDENCE: Row 63 of cover_EQUILIBRIA.md (line 99), a pointer in the map's shorthand; its proposed steps S42a and S42b are at that file's lines 199 and 200, and NEW has only those two sentences. Checked now: the living file's 4.14 (line 485; the map's "§4") has both clauses, exact, in the sentences after "NASA/JPL's aberration correction separates the epoch a signal leaves its source from the epoch it is received". The map's step 183 is of the Registry of 264 steps (git 8e24fa8); the same sentence is step 309 of Exhibit THIRTY Co-Chaining Logic Registry v380L, exact, with no unsure line. "Actual" is at no step (searched), and "evidence" is at steps 309 and 321 alone, neither of a non-living source (each step read). At no later section. No paragraph points at it (searched "item 63", "S42").
NEW: **Droplet · Evidence giving the prior as actual, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 4.14 has "Evidence arriving now and the prior event it expresses are two, each at its own momentary", and "evidence gives the prior as possible and as actual", said beside NASA/JPL's aberration correction, of non-living sources. Exhibit THIRTY Co-Chaining Logic Registry has, at step 309, "Evidence is an emanation arriving now from a living self at prior that has continued: evidence gives the prior's possible." *As actual*, and evidence from a non-living source, are each at no step. Two steps are proposed for them: evidence gives the prior as possible at now and as existing at its own momentary, two momentaries and not one; and an emanation arriving now from a non-living existing thing at prior, carrying none of the prior, is evidence of it. The steps may change or never be made.

### 76
VERDICT: KEEP
CONCEPT: the registry's four proof groups carrying the exact local exclusions, read against the Registry of version 376: carried by a step with an unsure line alone, a tension with the step of a proof of no possible value, a local exclusion at no step.
EVIDENCE: Paragraph 90 of this section names it by its item ("64 (with S43)") and stays, so under rule 2 it stays as it is. What it is now: the sentence is at the living file's 5.1 as quoted; the map's steps 96 to 98 are steps 143 to 145 of Exhibit THIRTY Co-Chaining Logic Registry v380L, step 145 unchanged ("A proof of a form not possibly existing is a proof of no possible value."); step 248 now has a form named still "shown not possible at the numbers, at those requirements alone", and whether that says the local exclusion whole could not be settled by reading.
NEW: -

### 77
VERDICT: KEEP
CONCEPT: the registry's groups A and B and its four-state orbit leaving each proper subset, carried at the Registry of version 376, with two writings noted as the older resolver's: F(P,Q)=(−Q,P) and ++/−+.
EVIDENCE: Unsure of what the note is now. The living file's 5.1 and 5.2 have the sentences as quoted, and 5.2 still has "F(P,Q)=(−Q,P)" and "{++,−+,−−}". The Registry has moved at the first writing: Exhibit THIRTY Co-Chaining Logic Registry v380L itself has "F(P, Q) = (−Q, P)" at steps 424 and 524. Whether "++/−+" is still the older resolver's writing beside the present one could not be found by reading, so neither a release nor a re-saying of the note is safe. The map's steps 40, 42 and 158 are steps 58, 63 and 276 now, none with an unsure line.
NEW: -

### 78
VERDICT: KEEP
CONCEPT: the registry's group D, a required arrival or offering unreachable, with its two cases, is at no step of the Registry of version 376, and a step is proposed.
EVIDENCE: Still open, and not re-said for one reason: the living file has moved at the group's cases. Its 5.1 has the group, "D · Required arrival or offering unreachable", with "Finite zero departure from a nonzero predecessor under a nonzero multiplier; the older resolver's case at its opposed aggregate route is at `archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_older_resolver.md`": the paragraph's first case, a nonzero offering from the opposed route, is no longer said at the living file, and a NEW naming the two cases says more or less than the paragraph or than the file (rules 4 and 11). "Unreachable" is at no step of Exhibit THIRTY Co-Chaining Logic Registry v380L; the map's steps 37 and 196 are steps 51 and 357 now. This section's paragraph "4. Group D's aggregate route" is of the same row and is not in this portion.
NEW: -

### 79
VERDICT: RESAY
CONCEPT: the registry's proof carrying to a conception whose stated set is carried into itself: a set carried into itself is at no step of the Co-Chaining Logic Registry, the set rests on its step 2, and a step is proposed.
EVIDENCE: Row 67 of cover_EQUILIBRIA.md (line 108), a pointer in the map's shorthand; its proposed step S45 is at that file's line 203, and NEW has only that step's sentence. Checked now: the living file's 5.1 (line 500) and 5.5 (line 537; the map's "§5") have the three sentences, exact. No step of Exhibit THIRTY Co-Chaining Logic Registry v380L has a set carried into itself (searched "into itself": none; each step read); step 248, a form named still "failing at its own requirements", is near the third sentence and is not the set's. Step 2 is step 2 still. One part is resolved and left out of NEW, as at paragraph 53: the map's "(OPEN)" named step 2's unsure line of version 376, gone now, step 3 having "The universe is both the set of all existing things and an existing thing within the set of all existing things". This mate's "Concern · Each conception, at one saying and at its own" (v386EOD) quotes 5.5 for another concern. No paragraph points at it (searched "item 67", "S45").
NEW: **Droplet · A set carried into itself, at no step.** Exhibit TWENTY-EIGHT Equilibria Registry 5.1 has "A proof carries to a conception whose complete requirement supplies its premises." and "For each x in the conception's stated set S, its required next is in S, or the conception is left within its succession.", and its 5.5 has "Each conception meets a proof by its own requirements." A set carried into itself is at no step of Exhibit THIRTY Co-Chaining Logic Registry, and the set rests on its step 2. A step is proposed for it: a form named still over a set of forms is possible at a next only with that next within the set, the set carried into itself, or left. The step may change or never be made.

### 80
VERDICT: KEEP
CONCEPT: the registry's two maps F and G as the only square roots of the complete return, and 6 and 10 at one parity, carried at the Registry of version 376, with older names and older words noted.
EVIDENCE: Mixed. Gone from the living file: "At the resolver's code the joint forms run one way", "run by G", "6 and 10 release at one parity" (5.4 now has "At the numbers two maps return the four pairs at two steps." and "6 and 10 share one changing"), the two older names and "fresh 7/8". Still at 5.4: "while both its signs invert" and "Two neighbouring pairs (a,b) and (b,z) of nonzero signs". "Also signs, 'fresh 7/8', 'neighbours'" is a list with no claim a re-saying could carry at its strength, and a release drops the two words still at 5.4 (rule 3). The map's steps 40, 41, 135, 139, 140 and 146 are steps 58, 62, 209, 226, 229 and 263 now.
NEW: -

### 81
VERDICT: KEEP
CONCEPT: the registry's agreement and opposition alternating through the overlapping momentaries, read against the Registry of version 376: carried by a step with an unsure line alone, the alternation at no step.
EVIDENCE: Unsure of what it is now. "The release pair and the fresh carrying are complementary" is gone from the living file; "Agreement and opposition alternate through the overlapping momentaries." is at 5.4 as quoted. The map's step 132 is step 204 of Exhibit THIRTY Co-Chaining Logic Registry v380L, with no unsure line now, and step 61 has "and the pair's relation, agreeing or opposing, is changing at each step, decided by the step alone." Whether step 61 says the alternation at the overlapping momentaries whole could not be settled by reading, so it is neither released nor re-said as at no step. The map's steps 26 and 29 are steps 37 and 40 now.
NEW: -

### 82
VERDICT: RESOLVED
CONCEPT: the registry's "The full carrying determines the next", carried at the Registry of version 376, with the older resolver's writing noted: s = sign(r − c) and (+,−).
EVIDENCE: The writing it concerns is gone from the living file. At version 375 (git 920a6f0, line 350) the passage was "**The full carrying determines the next.** The surface is s = sign(r − c), … gives agreement from (+,−) and opposition from (−,+) …"; the living file's 5.4 now has "**The carrying and the offerings determine the next at each sharing**, as Exhibit ONE's table of one self at one momentary carries each cell of a living carrying, and its table of colliding a carrying of none: a carried parity offered its own stays and shares 0; offered the other, a parting or nothing, it is chained inverted; a sharing carried none is chained at the offered parity, or stays open at 0 or none." "sign(r" and "full carrying" are at no line of it (searched). The rest asks nothing: the item was carried, its steps 37 and 187 of 264 being steps 51 and 343 of Exhibit THIRTY Co-Chaining Logic Registry v380L, neither with an unsure line. The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 112). No paragraph points at it (searched "item 71"; paragraphs 90 and 91 do not name it).
NEW: -

### 83
VERDICT: RESOLVED
CONCEPT: the registry's derivations at the resolver, 32 of 32 met, read against the Registry of version 376: an executing at the machine as proof at no step.
EVIDENCE: The step asked for is at Exhibit THIRTY Co-Chaining Logic Registry v380L: "248. A form named still carried to the resolver and failing at its own requirements is shown not possible at the numbers, at those requirements alone: a showing at the resolver's executing." with "*Adding: a showing at the resolver.*" and no unsure line; its entering from this file's "32 of 32 are met" is at carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md, item 12 ("a run at the code as a showing at the numbers"). Step 638 adds "the finding is at its executing alone". The sentence itself is gone from the living file, whose closing now has "The older resolver's derivations, 32 of 32 met at its own code, are whole at `archive/carrying_v377/Exhibit_TWENTY-EIGHT_Equilibria_Registry_older_resolver.md`." The map's steps 104 to 109 and 91 are steps 159 to 164 and 136 now, with nothing asked of them. The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 113). No paragraph points at it (searched "item 72", "S47"; paragraphs 90 and 91 name neither). Paragraph 96 names "32 of 32 are met" for its own subject and stays.
NEW: -

### 84
VERDICT: KEEP
CONCEPT: the registry's use of sign at many places, at each of which the Co-Chaining Logic Registry says parity, with eleven of its writings listed.
EVIDENCE: Mixed, part resolved and part not. Gone from the living file: "A 0 at two signs meeting", "the changing of two signs" (1.3 now has "the changing of two parities"), "One sign offered once" (3.4 now has "One parity offered once"), "its released sign arriving next downstream", the release pair, "s = sign(r − c)", "sign polarity" and "stable-forming among changing signs". Still at it: `(+,+) → (−,+) → …` at 1.5, "+, 0, −, 0" at 3.4's ring table, "with p either +1 or −1" at 5.2, and *sign* in its own voice at 2.1, 2.4, 3.4, 5.1 and 5.4. Its number, 57, is of version 375 and could be re-said by no reading now (rule 4). A release drops the writings still at the file; KEEP. Exhibit TWENTY Natural Naming v380R still re-says *sign* as *parity*.
NEW: -

### 85
VERDICT: RESOLVED
CONCEPT: second sign, to re-say at parity changing or release by Natural Naming, at two writings of the registry: a fourth at a positive second sign, and fresh writing inverting its nonzero second sign.
EVIDENCE: The words it concerns are gone from the living file: "second sign" is at no line of it (searched), at In numbers, at group C or at the renewal table. In numbers, 3.3, now has "At Exhibit ONE's resolver a carrying once chained is carried at each momentary, 11 the next 3, and is never none again, and it carries no number of its openings"; group C at 5.1 has "A carrying named unchanged at each momentary; each surface zero at a carried sharing."; the renewal table at 5.3 has "Offered its own parity at each momentary it stays, the offering from beside; offered nothing, the other parity or a parting, it is chained inverted; once chained it is never none." "Fresh writing" is at no line. The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 212). No paragraph points at it; paragraph 63 names the same older word in its own list and stays.
NEW: -

### 86
VERDICT: RESOLVED
CONCEPT: four older names of the resolver at the registry: 9-other-releasing, 6-other-crossing, 14-social-crossing and 10-other-surfacing, each with the name it was to be re-said at.
EVIDENCE: The words it concerns are gone from the living file: none of the four is at any line of it, and none of the four names it gives after the arrows (searched "other-releasing", "other-crossing", "social-crossing", "other-surfacing", "other-self", "social-other", "other-social": none). The living file has the names of Exhibit ONE now, at 3.4: "9-tri-bi-co-momentarying", "6-bi-co-bi-moralizing", "14-bi-tri-bi-moralizing" and "10-bi-tri-bi-tunneling". The row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md (line 213). No paragraph points at it; paragraph 80 names two of the same older names in its own list and stays.
NEW: -

### 87
VERDICT: KEEP
CONCEPT: sum and count at the registry: the openings and completings said as sums at In numbers, and count at twenty-two places.
EVIDENCE: Part resolved, part not. Still at the living file: "The three openings 1+3+5 sum to 9 = 3²" at 3.3, and "at count 1" at 5.2. Gone: "counts couplings"; *count* is at two lines now (5.2, and "B-counts" in NY31's own words). Its number, 22, is of version 375 and could be re-said by no reading now (rule 4). A release drops the two writings still at the file; KEEP. The mate's older `## Insertlets` has "sum to 9" re-worded, no later place.
NEW: -

### 88
VERDICT: KEEP
CONCEPT: older words at the registry: membrane, neighbour, half momentaries, co-bi-coupling and co-bi-exchanging, and carrying nothing for the non-living; and the absence of keys and surplusing.
EVIDENCE: Part resolved, part not. Gone from the living file: "membrane", "co-bi-coupling" and "co-bi-exchanging" (searched: none). Still at it: "overlapping neighbours" (3.1), "neighbours opposite" (3.4), "eight half momentaries" (1.5), "two and one half momentaries" (3.3), and "carrying nothing" for the non-living at 2.1. Its numbers are of version 375. A release drops the words still at the file; a re-saying gives new numbers or none (rule 4); KEEP. The mate's older `## Insertlets` has three of these re-worded, no later place.
NEW: -

### 89
VERDICT: KEEP
CONCEPT: seven released words in the registry's own voice, with the number of places of each: so, when, hold, keep, stand, half and neighbour.
EVIDENCE: Not resolved: each of the seven is still at the living file in its own voice (*so* at 2.1, 3.4 and 5.2; *when* at 1.5, 4.1 and 5.4; *holding* at 2.1, *holds* at 1.3 and *hold* at 4.14; *keeps* and *keep* at 2.1; *stand on* at 3.1; *half* at 1.5 and 3.3; *neighbours* at 3.1 and 3.4). Its numbers are of version 375 and differ now; a re-saying gives new numbers of a reader's own or drops them (rule 4), so it stays as it is. No later section says it.
NEW: -

### 90
VERDICT: KEEP
CONCEPT: of the steps the map proposed, the two groups carrying the most items: the ten things named still with placing, and the explored steps of the scientific method with conserving and state and flow.
EVIDENCE: Could not be re-said by reading, and not resolved whole. It is the map's own list (cover_EQUILIBRIA.md lines 221 and 222), in the map's item numbers and step keys. Of the steps it names, Exhibit THIRTY Co-Chaining Logic Registry v380L now has the ten named still (steps 334 and 504 to 523), the explored steps of the scientific method (310 to 317), state and flow (504 to 506) and the five conditions with the sixth (322); it has no step of the five places at 2 to 6 and none of conserving. It points at paragraphs 47, 58, 59, 61, 62, 64, 65, 66, 70, 71, 74 and 76 of this section by their items, and stays with them.
NEW: -

### 91
VERDICT: KEEP
CONCEPT: of the steps the map proposed, the three further groups carrying the most: parity at each existing thing with next as inversion and further occurrence; the torus as the one surface; and renewing, ring parity and the between.
EVIDENCE: Could not be re-said by reading, and not resolved whole. It is the map's own list (cover_EQUILIBRIA.md lines 223 to 225), in the map's item numbers, step keys and step numbers of version 376 (31, 39, 65, 73, 80, 82, 19 and 241). Of what it names, Exhibit THIRTY Co-Chaining Logic Registry v380L now has parity at each existing thing (step 42), the sixteen ways of a next (53 to 57), the torus from four edges at each point (113), the spirals (230 to 232) and the between as the crossing (99 to 105), and none of the unsure lines it names is at those steps now; it has no step of renewing and none of the whole participation. It points at paragraphs 55, 56, 57, 68 and 69 of this portion, and at paragraphs of the portion before, by their items, and stays with them.
NEW: -

### 92
VERDICT: KEEP
CONCEPT: the registry measured and read at version 371: 8,100 words, no numbered sections, its first section Natural Intelligence again, and shares of its own subject, the common method and older wording.
EVIDENCE: Already plain, with no waiting language; it is a row of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 68), a measuring and a reading of the file at version 371. The file has moved: the living file is 12,261 words at v380L with numbered sections 1.1 to 5.5. The shares (about 35%, about 15%, 25 to 30%) and "§1 is Natural Intelligence again" are readings at no living file, so it is not released (rule 3), and a re-saying could carry them only as they are said.
NEW: -

### 93
VERDICT: KEEP
CONCEPT: the common method restated in nearly every file, some passages word for word at several files, the registry among them at two passages. It is aimed at the set.
EVIDENCE: Already a clear concern in plain voice, with no waiting language; it is a finding of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 75). Not resolved at this file: the living file still has "Non-living existing things are included in discovering social moral competency among the living." at 2.1 and the aberration-correction sentences at 4.14. The set has moved at other files (the aberration paragraph is at two living files by search now, this one and Exhibit TWENTY-FOUR Geodesic Improving Method), and each of its named places at ten other files was not read; a re-saying naming them now is not safe (rule 8). No later section of this mate says it.
NEW: -

### 94
VERDICT: KEEP
CONCEPT: registry-like lists within subject files, each file with its own: the still-point veins at six files, hard-problem lists at four, the ten things named still at five wordings with two address schemes.
EVIDENCE: Already a clear concern in plain voice, with no waiting language; it is a finding of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 78). Parts of it are at carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md, "Still-point passages at Equilibria Registry · v385A" and "Earlier ten-conception gathering and address arrangement · v385A", which name the six files and the places of the ten; the hard-problem lists at four, the five wordings and the two address schemes are not said in them, so it is not SAID whole.
NEW: -

### 95
VERDICT: KEEP
CONCEPT: proposed homes for Natural Intelligence's Part Five, Invisibling, and Part Six, Unrelationing, 4,200 words: Natural Intelligence Corus, with 5.6's five still terms at the Equilibria Registry, 6.1 at Resolving Hard Problems, and 5.1 and 5.4 staying.
EVIDENCE: Could not find what it is now. It is a row of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 128). Natural Intelligence v380R has no Part Five · Invisibling and no Part Six · Unrelationing (its FIVE is Discovering Next and its SIX Intelligence), so the parts it names are gone from that living file; where 5.6's five still terms are now, and whether they arrived at this registry, could not be found by reading (the living file has no "still terms"). The proposed home is a relation at no living file, so it is not released (rule 3). The same paragraph is at carry/Offerings_to_Natural_Intelligence_Corus.md.
NEW: -

### 96
VERDICT: KEEP
CONCEPT: the registry as proposed at version 373: numbered and with the exclusions, its first section released to a citation of Natural Intelligence, its tables of 63 whole, its proof groups executed again at the resolver of version 372 before Natural Intelligence cites them, and its version line with the title.
EVIDENCE: Plain voice with no waiting language; it is a paragraph of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 181). Part is met at the living file: sections numbered 1.1 to 5.5, part FIVE the exclusions, sixty-three arrivals whole at 4.3 to 4.12, the version line "Exhibit TWENTY-EIGHT Equilibria Registry v380L", and its closing "Each saying at the resolver is at Exhibit ONE v380R at the tables it cites, by hand at v380L at its sayings of a carrying of none, or executed at v377 at Exhibit ONE v376 at the script and part it cites". Part is not: part ONE is at the file whole and is released to no citation. Whether that releasing is still proposed could not be found by reading, so it is neither released nor re-said. The same paragraph is twice more in this section, outside this portion (paragraphs 236 and 243 by their lines 523 and 537); the three want one verdict.
NEW: -

### 97
VERDICT: KEEP
CONCEPT: the Living Ghost Registry and the Equilibria Registry as two registries of one derivation: what they share, how their entries differ, the derivation once at the Equilibria Registry's opening with the other pointing to it, matching entries indexed across, and the Living Ghost Registry's own reshaping.
EVIDENCE: Already a clear concept in plain voice, with no waiting language; it is a paragraph of carryings/resettling_v373/Re-Settling_the_Living_Files.md (line 206). Its saying of now is still so: Exhibit TWENTY-EIGHT Equilibria Registry v380L names the Living Ghost Registry at no line, and Exhibit TWENTY-SEVEN Living Ghost Registry v345a names the Equilibria Registry at none (searched). The pointing, the index across and the reshaping are at no living file, and their strength in the source, a first draft of a plan, could not be said as done or as possible work without changing it (rule 4). No later section says it; the same paragraph is at the Offerings mates of Exhibit TWENTY-FIVE and Exhibit TWENTY-SEVEN.
NEW: -

## READING
Each of the fifty-two paragraphs, 46 to 97, was read and checked. Read whole: the brief with its further rules; the input; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (12,261 words); the mate's later sections headed v385A and v386EOD, its older Insertlets, and the opening of each paragraph of its older Droplets section; the Possibling and Carryings mates of this file; carryings/co_chaining_map_v376/cover_EQUILIBRIA.md, the source of paragraphs 46 to 91, and Explored_Steps_v376.md; carryings/co_chaining_coverage_v378/README.md and its readings/05_hard_problems_and_equilibria.md; each of the 661 step sentences and the 17 unsure lines of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (33,825 words; its adding and entering lines were searched, not read whole); the sections of carryings/resettling_v373/Re-Settling_the_Living_Files.md the paragraphs 92 to 97 are from; the later sections of carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md that the Possibling mate links; the contents of Natural_Intelligence_v380R.md. Searched: carry/*.md for each item number and step key; the living file for each older word and each sentence quoted; Exhibit TWENTY Natural Naming and Exhibit TWENTY-SEVEN Living Ghost Registry for single words.

The map's step numbers are of the Registry as it was read against, 264 steps with 41 unsure lines; that file is at no path now and was read from the history alone (git 8e24fa8, Exhibit_THIRTY_Co-Chaining_Logic_Registry_v376.md; its 41 unsure steps are the map's own list), and each step named in a NEW or in EVIDENCE was found at the living Registry by its sentence. The living file as the map read it, version 375, was read from the history (git 920a6f0) for the sentences now gone. No code was executed beyond searching and reading.

Rule 2 decided seventeen verdicts: paragraphs 90 and 91 name twelve and five paragraphs of this portion by their item numbers, paragraph 70 names paragraph 65, and the Living Ghost Registry's Offerings mate names paragraphs 58 and 65; each of the seventeen is KEEP, and what each is now is said in its EVIDENCE. Five of them (59, 61, 64, 74, and 58 but for its agreeing with the Living Ghost Registry's 7.6) are met on their own readings and could leave together with paragraphs 90 and 91 if those two are resolved.

Could not find or settle: whether the map's conflict at paragraph 49 is still a conflict beside the Registry's steps 24, 43 and 391; whether step 466 says the living file's co-releasing (60), step 61 the alternation at the overlapping momentaries (81), steps 248, 308 and 611 the rest at no coupling (69), and step 248 the local exclusion (76); whether "++/−+" is still the older resolver's writing (77); where the five still terms of Natural Intelligence's former 5.6 are now (95); and whether part ONE's releasing to a citation is still proposed (96). The paragraph 96 is three times in the section, twice outside this portion.
