### 1
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 2
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 3
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 4
CHECK: OBJECT
WHY: Lost: the concern's own source and the manner of its reading, "received from `incoming/co_chaining_coverage_v378/`, the living files read against the co-chaining", and a later section says of this very paragraph that it is retained. carry/Exhibit_TWENTY-THREE_Carryings_of_Natural_Values.md, "## Discovery economy and expedition contributing · v385A", line 15, has "The older common method, institution and universal-set concerns retain their exact sources and later correcting." With NEW that sentence is no longer so at this mate for the universal-set concern: paragraph 2 (left as it is) links the reading for the institution half alone ("v378 Reading 10, item 15 and C"), and no other paragraph of the mate names the source of the parting at 4.1 (B, line 49 of carryings/co_chaining_coverage_v378/readings/10_engineering_to_values.md, read). The first reader's rules bar a source from NEW, so no re-saying mends it. The rest of NEW was laid beside the prior and is sound: the two quotations of Natural Values are exact at 4.1 (line 147) and 2.2 (line 107); the four of Exhibit THIRTY Co-Chaining Logic Registry are exact at steps 3, 137 and 213 (lines 68, 656, 984); the three addings are at its lines 2090, 2186 and 2314; "the field's own", "entered at version 378" and "for both" are carried; the title has the subject words by which paragraphs 2 and 33 find it. NEW is at one hundred and fifty words with its title, at the bound.
SAFER: KEEP

### 5
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 6
CHECK: OK
WHY: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 63, under the column heads at line 38, has each of the six things NEW says (2,000 words, v333, the best of its group, plain and short, about 75%, about 8%, about 8%) and no more; the living file is unchanged at version 333 and at 1,986 words, so the present form is so now; NEW has no quotation; no paragraph of carry/*.md points at this one (searched "best of its group", "plain and short", "about 75%").
SAFER: -

### 7
CHECK: OBJECT
WHY: Two things. First, a present finding about this file is said as a past measure. The prior says in the present that the core coupling sentence is at four files "and said again at Natural Values 4.1"; NEW, word for word the re-saying made at the Natural Naming mate, opens "At version 373" and has "was at … and said again at Natural Values' 4.1". Each of the five places has it now: Natural Societies line 95 under 1.1, Natural Health line 57 under 1.1, Natural Medicine line 87 under 1.1, Natural Destinies line 39 under "## The core — the bi-moral co-agency", and Natural Values 4.1, line 143, "It is sign-only. It sums to a bounding-zeroing the coupling itself makes." Natural Values is unchanged at version 333, so at this mate the part of the finding that is about this file is unresolved and present, and the first reader's own block 12 says the same five places as "is at". The past form fits what has moved (Natural Intelligence has no 7.2, its sentence now at 6.5, line 1134; *aberration* is at two files; Natural Physics is at version 379) and not this part. Second, the source "(Re-Settling the Living Files, §2 Five findings)" leaves, while carry/Exhibit_TWENTY-THREE_Carryings_of_Natural_Values.md, "## Discovery economy and expedition contributing · v385A", line 15, has "The older common method, institution and universal-set concerns retain their exact sources and later correcting."; the first reader's rules bar a source from NEW. The rest was read and is sound: both quotations are exact (the first at Natural Intelligence line 1134 and Natural Naming line 1163, the second at the four files above); each file, section and percentage of the prior is in NEW (source line 75 read).
SAFER: KEEP

### 8
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 9
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 10
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 11
CHECK: OK
WHY: laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md line 193: each subject of the three files, 4.4 to 4.6 within their part, the five human examples "each now at both", and the six places Natural Values receives are in NEW; the places were read at the living files now (Natural Societies 4.4 to 4.6 at lines 304 to 314, after "# PART FIVE · SCALING" at line 201, and 1.3 at line 107; Natural Human Society 3.1, 3.4 and 4.6 at lines 167, 191 and 243; Natural Exploring 6.3 at line 425; Natural Health 3.2 at line 75); the form of possible work is the strength the later places give it ("the older proposal to receive value at Values" at paragraph 1, "the proposed receiving at Values" at Possibling of Natural Human Society line 9), and those two pointers still find it by "receiving" and the files' names; no quotation; one hundred and fifty words with its title, at the bound.
SAFER: -

### 12
CHECK: OBJECT
WHY: Changed strength, and contradicted by the living files. NEW closes "The sentence is released: it is old code.", a release said as done, one sentence after saying the same sentence "is at" five places; it is at each of them now (Natural Societies line 95, Natural Health line 57, Natural Medicine line 87, Natural Destinies line 39, each exact with *itself*; Natural Values 4.1 line 143 says it again). The prior's "released, old code" is the third cell of a plan's row: carryings/resettling_v373/Re-Settling_the_Living_Files.md line 219, table "Passage | Where it stands now | One home", "Released: old code", in a file headed "first draft, session v373". It is the one home the draft gives the passage, a release not made. The later place that has it says no more than "The v373 source already identifies the repeated selecting/sign-only/summing/+1 sentence as old code; its presence is not a newly missing common paragraph" (carry/Exhibit_FOURTEEN_Offerings_to_Natural_Destinies.md line 77, and the same at three other mates). The two rows beside it in that table (lines 225 and 226) the first reader re-said at block 13 as possible work; here the release is said as done. Whether the prior's release is intended or possible is not said at the prior, so I offer no re-saying at its strength (rule 4). The quotation and the five places are sound.
SAFER: KEEP

### 13
CHECK: OK
WHY: laid beside the prior and carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 225 and 226: the two places of currency, the seven places of abundancing and the *discovery economy*, and the one home of each at Natural Values are in NEW; the sections are at Natural Human Society lines 167 and 243, Natural Values lines 73 and 157, Natural Exploring line 425 and Natural Intelligence Corus lines 1043, 1466, 2228 and 2482; the row's third column is "One home" in a first draft, and the later places call the receiving at Natural Values proposed, so possible work is its strength; paragraph 3's "Human Society 4.6's route to Values" still finds it; no quotation.
SAFER: -

### 14
CHECK: OK
WHY: opened this mate's "## Three improvings spiralling, one triple at each coupling · v386EOD" (lines 254 to 258), a later section: its opening names "its released Natural Intelligence, its map" as the source, and its droplet has "generosity, curiosity and gratitude at a living human, and cheaper, faster and better at a contribution" and "The three are the moral spiral", which is the whole of the passage (carryings/resettling_v373/Natural_Intelligence_v373_Released.md lines 233 to 237, "### 2.6 Moral spiralling, three improvings", "*Receiving: Natural Values, the three improvings.*"); 2.6 is gone from Natural Intelligence v380R, whose part TWO closes at 2.5 (line 158), and no living file has "moral spiral" or "generosity"; "near" is the map's sort of a passage for a file near (Natural_Intelligence_Map.md lines 23 and 74), and the droplet lies at that file's own mate; no paragraph of carry/*.md points at this one (searched "moral spiral", "Moral spiralling", "three improvings").
SAFER: -

### 15
CHECK: OK
WHY: the same later section read (mate lines 254 to 258): it is at Offerings to Natural Values, names the released Natural Intelligence and its map as its source, and says the three improvings and the moral spiral whole; the prior is one row of a table (Natural_Intelligence_Map.md line 171) with no more in it than the passage's name and its receiving file; the receiving is also at carry/Session_Record.md line 1643, which points at the released file and not at this paragraph; the same verdict as its copy at 24; no pointer found.
SAFER: -

### 16
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 17
CHECK: OK
WHY: carryings/session_v378/Session_Report_v378.md line 21 has the ten files at their four versions and "Forty-five to forty-nine versions behind the apex, each at the old seventeen names, the old code's means and words since released", and its line 15 the apex at v377 to v378; the ten files are at those versions at the root now (file names read); each is in NEW, the number said as of session v378's apex, with no quotation.
SAFER: -

### 18
CHECK: OK
WHY: NEW's second sentence is the prior's one sentence word for word, with the italics of its source (carryings/v368_sources/Wrap_v368.md line 73, read); the releasing is said as the prior says it, neither as done nor as possible work; "It is aimed at the set." re-says the prior's own "Across the set" and narrows nothing; forty-nine words, no quotation, no number.
SAFER: -

### 19
CHECK: OK
WHY: carryings/v368_sources/Carry_Set_v368_README.md line 181 is one row of a table whose two cells are the same form at each file not then improved ("… findings and … discoveries waiting", "Improving relative to Exhibit ONE, from its section"): a number with no finding in it and a table's next; the file's next now is at Exhibit TWENTY-SIX Living File Registry 1.1, line 91 ("pass G"), and at this mate's line 5; the bundle the number is of was gathered at this mate's "## A discovering economy, and abundancing by a fixing released · v386EOD"; no paragraph of carry/*.md points at this one (searched "5 findings", "findings and 5", "relative to Exhibit ONE").
SAFER: -

### 20
CHECK: OK
WHY: Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 64, under "## 1.2 Moral is do-no-harm improving, decided at each pass" (line 62), has "**Moral is do-no-harm improving, decided at each step, and at a file the step is one pass.**", the whole of the prior in its words; the prior has no number, reading or relation beside the sentence and names no file it is for; its source says the standing went to that file (Carry_Set_v368_README.md lines 213 and 219); no paragraph of carry/*.md points at this one (searched "Moral is do no harm", "do no harm improving", "decided at each step").
SAFER: -

### 21
CHECK: OK
WHY: Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 256, under "## 2.9 The six diamonds and the compass face" (line 254), has both quotations exactly, and they are the very sentence the prior is about; the three things at no living file are each in NEW at the prior's strength: the expressing through inner and outer relations as intended, "This is the intended social moral competency illustrating", and the diamond-to-route and pair-to-dot placement as undrawn (the file's line 260 has the first of the two still to explain); no session is narrated and nothing is promised; seventy-four words.
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: OBJECT
WHY: Two of the prior's own words, each a concept, are replaced, and one reading is moved. (1) "its loopings 4" is said as "Its versions are 4". The source has both: carryings/v381F/v381F/Session_Report_v381F.md line 175, Finding 18, "the files loop, each at its own pacing", numbers "Natural Values 4" among each file's versions and has "each version a looping", "Each file loops out and back at its own rate"; NEW has the number of versions and loses that they are loopings. (2) "its far side *1.5 Natural-, all or none at all*" is said as "It opens from and arrives back at Natural Intelligence 1.5"; *far side* is Natural Intelligence's own word (4.11, line 1012, "each number paired with its far side at each ring it is at") and the source's name for what was computed (Entry_Journey_For_An_AI.md line 13, "the file's far side, where it loops out and back", "A computing, deciding nothing"), and it is not on the first reader's list. (3) "*sound, with 6.4*" is the reading of that computed row (Entry_Journey_For_An_AI.md line 39, third column, "The session's reading"); NEW's "soundly, with 6.4" makes it the manner of the file's arriving back, a claim neither the prior nor the source has. The rest was laid beside the prior and its sources and is sound: 50 to 60 and 58 (report lines 163 and 150), *Co-Abundancing* shared with Natural Destinies (line 39; the Living File Registry lines 82 and 91), the two titles (line 177), the seven files naming no other (line 97), the reading at three momentaries proposed (Next.md, Explorings proposed next, 3), and the quotation exact at Natural Intelligence line 103. SAFER has NEW with these three alone mended, in the prior's words: one hundred and thirty-one words, the quotation unchanged.
SAFER: **Droplet · Natural Values, a question about living together.** It is aimed at Natural Values. An interest in a question about living together opens at it; first at that arriving are its released words, 50 to 60 in each thousand, and its front's form, and for that interest its motion is ahead of the set. At version 333 they are 58. Its subtitle's -ing, *Co-Abundancing*, is shared with Natural Destinies. Its far side at Natural Intelligence is 1.5, "Natural-, all or none at all, at the one hand", and that is sound, with 6.4. Its loopings are 4, each a version, and its titles are *Engineering Method of Explaining Valuable Hard Problems* and *Natural Values*. It is among the seven files naming no other. Its reading at three momentaries is proposed.

### 24
CHECK: OK
WHY: the copy of 15 with one label more, "(re-aimed from Offerings to Natural Intelligence at v381R)", a record of its placing with no concept, condition or work in it; the same later section (mate lines 254 to 258) says it whole, as at 15; no pointer found.
SAFER: -

### 25
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 28
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 29
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 30
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 37
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 38
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Thirty-eight blocks: OK 11 (6, 11, 13, 14, 15, 17, 18, 19, 20, 21, 24), OBJECT 4 (4, 7, 12, 23), KEEP-UNCHANGED 23 (1, 2, 3, 5, 8, 9, 10, 16, 22, 25 to 38).

Read whole: HARM3.md and BRIEFO3.md with its further rules; the prior VA_1.txt; the proposed VA_1_report.md; the living file Exhibit_TWENTY-THREE_Natural_Values_v333.md (1,986 words); the mate carry/Exhibit_TWENTY-THREE_Offerings_to_Natural_Values.md with its Insertlets, its Droplets and each section headed v385A and v386EOD; carry/Exhibit_TWENTY-THREE_Carryings_of_Natural_Values.md.

Read at the lines found by search: Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (steps 3, 137, 213 and the three addings); Natural_Intelligence_v380R.md (its part headings, 1.5, 2.5, 4.11, 6.4, 6.5); Exhibit_TWENTY_Natural_Naming_v380R.md (line 1163); Exhibit_SEVEN_Natural_Societies_v373.md (its part headings, 1.1, 1.3, 4.4 to 4.6); Exhibit_NINE_Natural_Human_Society_v329.md (3.1, 3.4, 4.6); Exhibit_TEN_Natural_Health_v329.md (1.1, 3.2); Exhibit_ELEVEN_Natural_Medicine_v331.md (1.1); Exhibit_FOURTEEN_Natural_Destinies_v333.md (the core); Exhibit_EIGHT_Natural_Exploring_v329.md (6.3); Natural_Intelligence_Corus_v330.md (14.8, 18.8, 23.3, 23.6); Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md (1.2); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md (2.9 whole); Exhibit_TWENTY-SIX_Living_File_Registry_v381R.md (the rows of 1.1); carry/Session_Record.md (line 1643); carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md (lines 343 to 347); carry/Exhibit_FOURTEEN_Offerings_to_Natural_Destinies.md (line 77). Sources read at the lines cited: carryings/resettling_v373/Re-Settling_the_Living_Files.md (its opening, section 2's table and five findings, section 7, section 9's table), Natural_Intelligence_Map.md and Natural_Intelligence_v373_Released.md; carryings/co_chaining_coverage_v378/readings/10_engineering_to_values.md; carryings/session_v378/Session_Report_v378.md; carryings/v368_sources/Carry_Set_v368_README.md and Wrap_v368.md; carryings/v381F/v381F/Session_Report_v381F.md (parts 2.2, 4.1, 9 and 10), Entry_Journey_For_An_AI.md (parts 1 and 2) and Next.md.

Checked by exact search: each quotation of each NEW paragraph and each EVIDENCE sentence of 20 in the living file it names; each named section at its living file now; the root's file names for the ten versions of 17. For 14, 15, 19, 20 and 24, the mate and carry/*.md were searched for a pointer by the paragraph's subject words and by "this mate of", "droplet at this mate", "concern above", "the preceding", "existing concern", "current droplet", "above" and links into this mate (each link found is to a section headed v385A, none to the Droplets section); none points at those five. The length of each NEW paragraph and the first reader's word list were checked by script: each is within forty to one hundred and fifty words (4 and 11 at the bound with their titles) and none of the listed words is in a NEW paragraph's own sentences, the corrected paragraph at 23 among them.

The reports of second readers at other mates on the re-sayings copied here word for word (the Natural Exploring portion at 11, 12, 14 and 17, the Natural Naming portion at 43, the Natural Societies portion at 6) were read after my own reading. At 7 I part from the one at the Natural Naming mate, for the two reasons given, each of this mate alone: Natural Values is unchanged, and this mate's carryings say the concern's source is retained.

Not settled here: the twenty-three blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 4 and 7 the objection rests on one sentence of the mate's carryings (line 15); a reader who takes that sentence as a record of version 385A and no condition on these paragraphs would pass 4, and at 7 would still have the first reason. At 12 a re-saying that has the row's "One home" as a release not made could be written from the source; I did not offer one, the prior not saying whether the release is intended or possible work.
