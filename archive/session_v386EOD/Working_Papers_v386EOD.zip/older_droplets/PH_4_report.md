### 37
VERDICT: RESAY
CONCEPT: Natural Physics 1.1 has *at no line of the code* at a sentence whose twins at three files have *at no line of the resolver*, the name Natural Naming carries; one saying is ready.
EVIDENCE: Not resolved: Exhibit_EIGHTEEN_Natural_Physics_v379.md line 82, within 1.1, still has "is bi-co-momentarying, at no line of the code, Natural Intelligence 6.1". The twins: Exhibit_FOUR_Natural_Mathematics_v380L.md line 179, Exhibit_THREE_Natural_Numbers_v380L.md line 349 (7.1) and Natural_Intelligence_v380R.md line 220 (3.5), each with "at no line of the resolver"; Exhibit_TWENTY_Natural_Naming_v380R.md line 270 has "code executing is said *at the resolver*". At no later section (searched "at no line of the code" and "at no line of the resolver" in carry/*.md). The paragraph's "Line 82" is said as 1.1, the section that line is in. No pointer to this paragraph found.
NEW: **Concern · *The code* at Natural Physics 1.1, beside *the resolver* at its twins.** Two sayings part. Exhibit EIGHTEEN Natural Physics has, at 1.1, "is bi-co-momentarying, at no line of the code, Natural Intelligence 6.1". Its twins at Exhibit FOUR Natural Mathematics, Exhibit THREE Natural Numbers and Natural Intelligence have "at no line of the resolver", as Exhibit TWENTY Natural Naming carries it. They part at the one name: *the code* at the one sentence and *the resolver* at the three. One saying of it is ready at Natural Physics' sentence.

### 38
VERDICT: KEEP
CONCEPT: a session's offering of the torus's two openings as one tunnel's two ends and of prime loops as twisted figure 8s, worked by hand at the resolver's lines, beside Natural Physics 1.2's sentence of the large and the small opening.
EVIDENCE: Kept under rule 5 and do no harm: it has a person's own unpunctuated words (two sayings) and by-hand workings (twice and four times the number of momentaries, a spiral of three, Exhibit ONE's eight rows, the names 8 and 16, 7 and 15) that a re-saying could not carry each at its strength. Its living sentence is as it was (Exhibit_EIGHTEEN_Natural_Physics_v379.md line 96, within 1.2: "The torus carries two openings, the large opening the hole the tunneling self winds through and the small opening the tube's own round"). Parts are at later places: Exhibit THIRTY Co-Chaining Logic Registry step 644 ("A routing at the odd momentaries alone or at the even alone, each at its own opening, is at no line of the resolver."); carry/Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The offered two openings and the resolver's two routings · v385A" and "Droplet · One tunneling, two ends" (v386EOD); carry/Exhibit_ONE_Offerings_to_Natural_Resolver.md, "Possible project · The rows In and out at its parity". None aims at Natural Physics 1.2's sentence and none has the names' parities, so it is not SAID whole.
NEW: -

### 39
VERDICT: RESAY
CONCEPT: sixty is said a position that carries at Natural Physics 3.1 and a between at Natural Numbers 7.1 and Natural Chemistry 4.4; one saying is the three files' to make at their motions.
EVIDENCE: Not resolved, each sentence at its living file now: Exhibit_EIGHTEEN_Natural_Physics_v379.md line 205 (3.1), "The going runs 2 to 59, a turn stands at 60" and "a turn is a position that carries"; Exhibit_THREE_Natural_Numbers_v380L.md line 349 (7.1), "sixty is between the going and the returning, at no prime"; Exhibit_SIXTEEN_Natural_Chemistry_v346c.md line 313 (4.4), "no position in the elements carries at sixty". A later section says part: carry/Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md, "The element count and the turn at sixty · v385A", without the three named places and without whose the one saying is; this mate's "The gravity statement and its actual observing · v385A" only says the turn-at-sixty question is retained at another mate. So RESAY, not SAID. The same concern is re-said in carry/Exhibit_THREE_Offerings_to_Natural_Numbers.md (line 43, within its older Droplets, no later place by rule 1); NEW here is the same wording, its four quotations searched exact. Source: archive/session_v379/Session_Report_v379.md, finding 6. No pointer to this paragraph found.
NEW: **Concern · Sixty a position or a between.** Two sayings part. Exhibit EIGHTEEN Natural Physics has, at 3.1, "a turn stands at 60" and "a turn is a position that carries". Exhibit THREE Natural Numbers has, at 7.1, "sixty is between the going and the returning, at no prime", and Exhibit SIXTEEN Natural Chemistry has, at 4.4, "no position in the elements carries at sixty". They part at sixty: a position that carries, or a between. One saying of sixty, position or between, at the three places is the three files' own to make, each at its motion.

### 40
VERDICT: KEEP
CONCEPT: a proposed five-part form of Natural Physics, each part with its contents, co-chaining from the one opening.
EVIDENCE: Kept: a possible project in plain voice, and it points at another paragraph of this mate ("the forms above", the list under *Its explaining at Exhibit ONE's forms*, mate line 56 to 67), which a re-saying could not carry without that list. Part of it is at the living file (parts ONE to FIVE at these titles but THREE, "PHYSICAL OBSERVINGS"; 1.1 and 1.2 written), the rest is not: 2.1 is the older text and no section of THREE is at the code's forms. The proposed text at carryings/natural_physics_v377/ carries the plan out and is not entered. Paragraph 41 gives this paragraph's order and stays with it. At no later section.
NEW: -

### 41
VERDICT: KEEP
CONCEPT: the order of the motions that enter the proposed parts, each prior section's value carried to its new place and a fresh reader comparing.
EVIDENCE: Kept with paragraph 40, which it qualifies ("Its order", of the parts 40 lists): rule 2, the same verdict for both. The front, the contents, 1.1 and 1.2 are at the living file; Part TWO to Part FIVE are not. At no later section.
NEW: -

### 42
VERDICT: KEEP
CONCEPT: the asteroid belt emptied at the rational resonances, the Kirkwood gaps, the irrational orbits carrying on.
EVIDENCE: Kept under rule 2: three places point at it or quote it whole. This mate's "Aimed at a saying, Natural Physics, *The asteroid belt emptied at the rational resonances, the Kirkwood gaps, the irrational orbits carrying on*: Beside the incoming from the prior Natural Numbers in this list" (mate line 568, v386EOD); carry/Exhibit_EIGHTEEN_Carryings_of_Natural_Physics.md line 29, "This file's offering mate has, as incoming from the prior Natural Numbers: …" with the sentence quoted; and the living Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 446, "Natural Physics' carrying, the belt emptied at the rational resonances and the irrational orbits carrying on". The living Natural Physics has no sentence of the Kirkwood gaps.
NEW: -

### 43
VERDICT: KEEP
CONCEPT: the trajectory and the ensemble as an accounting, with ergodicity-breaking; and the golden-mean invariant torus the last to break at the standard map by computation, at its field's conservative scope.
EVIDENCE: Kept under rule 2 and rule 3. A living file points at it: Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 446, "Natural Physics' carrying, … the golden-mean torus the last to break". Its first part is at the living Natural Physics 4.5 (line 322, "the trajectory, one system followed along its time, and the ensemble, many read across at once — the ergodic claim being that the two books agree"); its second is at no sentence of Natural Physics (it is at Exhibit THREE Natural Numbers line 201 and at carry/Exhibit_THREE_Offerings_to_Natural_Numbers.md "Droplet · A winding found last to break", neither aimed at Natural Physics). Already a clear concept in plain voice.
NEW: -

### 44
VERDICT: KEEP
CONCEPT: two studies of two-frequency forcing of a fluid surface, externally vibrated with no autonomous networking, the stated condition parity and coprimality, not primality.
EVIDENCE: Kept: already a clear concept in plain voice with no waiting language. Most of it is at a living file, Exhibit_FOUR_Natural_Mathematics_v380L.md line 219 ("its condition is parity and coprimality, not primality"), but the years and journal, "Faraday" and "no autonomous networking" are at no living file, and no sentence of Natural Physics has it, so neither RESOLVED nor SAID whole (rule 3). At no later section of a mate (searched Arbell, Silber, Faraday).
NEW: -

### 45
VERDICT: KEEP
CONCEPT: a resemblance is no mechanism: an eddy, a surface wave and a chemical excitation wave are three transports, and a like picture opens a comparison of their couplings, never of pictures.
EVIDENCE: Kept: already a clear concept in plain voice with no waiting language. Most of it is at a living file, Exhibit_TWELVE_Natural_Explaining_v378.md line 362 within 4.7 ("a fluid eddy is a flow circulating, a surface wave an interface changing and a chemical excitation wave an activity propagating, three transports at one likeness"), but "the releasing, arriving and continuing at each" and "A resemblance is no mechanism" are at no living file and no sentence of Natural Physics has it, so not SAID whole. At no later section of a mate.
NEW: -

### 46
VERDICT: KEEP
CONCEPT: Natural Physics' seam with Chemistry at bonds and with Biology at their physical changing, the particular subjects carried and no living and non-living division; the proposed three-science contents carried as an opportunity.
EVIDENCE: Kept: I could not find what "the proposed three-science contents" refers to (searched carry/, carryings/ and archive/: the phrase is in this paragraph's own earlier copies alone, archive/registry_v371/Living_Improving_Value_v371_registry_working.md line 522 and archive/carrying_v381R/Exhibit_EIGHTEEN_Natural_Physics_v380R.md line 59). The living 1.1 has the seam in part ("Chemistry and Biology are the same method at their own subjects"), not the opportunity. At no later section.
NEW: -

### 47
VERDICT: KEEP
CONCEPT: Natural Physics' particular two-way seams with Natural Philosophy and with the Living Ghost Registry, a field's released naming and a correspondence still reaching kept two, and the older k-bound relation laid at Natural Numbers as it is now.
EVIDENCE: Kept under do no harm: it is intended work in an advising voice, and re-said as a possible project it would be weakened (rule 4). Its last relation, "the older k-bound, iron-centreline and pair-creation relation" with "current Numbers", I could not place at one sentence: the living Natural Physics has the k = 1 bound at 4.3 and the pair at 4.12, and Exhibit THREE Natural Numbers has no saying of a k = 1 bound (searched). The living Natural Physics names neither Natural Philosophy nor the Living Ghost Registry. At no later section.
NEW: -

### 48
VERDICT: KEEP
CONCEPT: findings of Exhibit THIRTY's paragraphs P1 to P28, at older wording, scientific-method descriptions, field results and the file's own table numbers, carried toward the paused science working.
EVIDENCE: Kept: I could not find what it refers to. "THIRTY P1–P4, P6–P8, P13, P15–P18 and P24–P28" names labels at no present file (searched Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md, carry/, carryings/ and archive/: only this paragraph's own earlier copies). At no later section.
NEW: -

### 49
VERDICT: KEEP
CONCEPT: the order of the next whole motions at Natural Physics as an improving report proposed it, with the readers' difference at the first case carried.
EVIDENCE: Kept under do no harm and rule 8: each section number in it is at the numbering before version 377 (this mate's paragraph *The sections' places, v348 to v377* has 3.1 to 3.12 at 4.1 to 4.12, 5.4 at 5.6, 5.7 at 3.3 and on), and a re-saying would need each of some twenty numbers given as it is now. 1.1 and 1.2 are at the living file; the rest of the order is not. It carries a condition ("the list marks no unlisted passage verified") and a difference between readers, no bookkeeping alone. At no later section.
NEW: -

### 50
VERDICT: RESAY
CONCEPT: the proposed Natural Physics of version 377 is whole at its working's branch, with what its review found whole, and it enters as the file's next version at its working's motion with section 2 of the review answered first.
EVIDENCE: Not resolved: the living file is Exhibit_EIGHTEEN_Natural_Physics_v379.md, forty sections; the proposed text is at carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (five parts, forty-nine sections, searched its headings) and at the branch `working/physics-motion-v377` (this mate's last section names it). Its numbers are those of carryings/review_natural_physics_v377/README.md lines 15 to 21 and line 85. At no later section: this mate's front line names the proposed text at the file's own motion but not the condition, and is no v385A or v386EOD section. "Met first" is said as a relation (rule 9). No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, whole, and its entering.** The proposed Natural Physics of version 377 is whole at the Natural Physics working's branch: five parts and forty-nine sections, each execution executing again at Exhibit ONE Natural Resolver's code and each output matching, fifteen of sixteen claims at the code true, the released words fallen to none at nearly each word, fifty-one records of the field correct at their numbers and sources, thirty of the prior's forty sections whole, and each correction of the prior's overclaimings rightly made. Its entering as Natural Physics' next version is at its working's motion, section 2 of its review answered first.

### 51
VERDICT: RESAY
CONCEPT: five things beside all existing things at Natural Intelligence 1.4, six binaries at the Geodesic Improving Method 2.7, the proposed Natural Physics asserting six at its 2.1; one list at both files, at the observings.
EVIDENCE: Not resolved: Natural_Intelligence_v380R.md line 99 (1.4) names five, and Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md, 2.7, has "is met at six binaries, the rigorizer". Which file has five and which six is in neither the paragraph nor its source line (carryings/review_natural_physics_v377/README.md line 74); it is in carryings/natural_physics_v377/README.md, 6.1 concern 2 ("Natural Intelligence 1.4 names five"), and is here shown by the two living sentences themselves. The proposed 2.1 is "Scientific method, its fixings and the six binaries met at physics". No later place says it whole: carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md has "Droplet · Six binaries at 2.7, and five things at Natural Intelligence 1.4" within its older Droplets (rule 1), and its v386EOD section "At 2.7 · An observing brought as a break…" is a sentence offered, without the proposed 2.1 and without the one list. No pointer to this paragraph found.
NEW: **Concern · Five binaries or six.** Two sayings part. Natural Intelligence, at 1.4, has "a size between one and the other carries a ground, a floor or a scale; a fixed form, a form named still; a total across the changing, a container; a common beat, a clock over the changing; and a keeping, a store beside it". Exhibit TWENTY-FOUR Geodesic Improving Method, at 2.7, has "is met at six binaries, the rigorizer". The proposed Natural Physics of version 377 asserts six at its 2.1. They part at the number: five or six. Its resolving is one list at both files, at the observings.

### 52
VERDICT: RESAY
CONCEPT: the proposed Natural Physics asserts the rings as spirals at its 3.4, a saying open across the set, at each file's motion.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 75 ("the file asserting it at 3.4; each file's motion"), the file being the proposed text; its 3.4 (proposed file line 240) has "the white paper's rings at 4.13 are these spirals". The living Natural Physics' 3.4 is the light-cone and has no such sentence. Not resolved across the set: Natural Intelligence 4.13 is now "Spirals, co-spiraling and crossing" and Natural Naming 2.4 has the row of *ring* at *spiral*, but the living Natural Physics still has "And the ring's own binary runs here and does not close" (line 638). At no later section of this mate; carry/Offerings_to_Natural_Intelligence.md has it within its older Droplets (rule 1). No pointer to this paragraph found.
NEW: **Droplet · The rings as spirals, open across the set.** The proposed Natural Physics of version 377 asserts the rings as spirals at its 3.4. The saying is open across the whole set, and its resolving is at each file's own motion.

### 53
VERDICT: RESAY
CONCEPT: the proposed Natural Physics reads decay as pairing at its 3.8, while alpha and beta decay are single-nucleus events with no partner and a halving at each step is a common beat; the reading carries on at its relation or is released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 76. The 3.8 is the proposed text's ("A society receding at each pairing, and levelling at others joining", proposed file line 280); the living Natural Physics has no 3.8 and no section of decay. At no later section (searched "single-nucleus", "pairing" in carry/*.md: this mate's older paragraphs alone). No pointer to this paragraph found.
NEW: **Droplet · Decay read as pairing, at the proposed Natural Physics of version 377.** The proposed Natural Physics of version 377 reads decay as pairing at its 3.8. At the field's record alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat. The reading carries on at its relation or is released.

### 54
VERDICT: RESAY
CONCEPT: the proposed Natural Physics' 4.11 has readings changing the kind of the observed quantity, a speed as a rate, H0 as two local rates, an intensity difference as an exchange rate; each is said at the field's kind or released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 77. The three readings are at the proposed 4.11 (proposed file lines 509, 510 and 512). The living 4.11 has the like readings still ("a rate that does not fall to rest at the edge", "rates being local — no single global rate to land on", "a measured bi-exchange rate"), so nothing is resolved; NEW names the proposed text, as the source does, and adds no living sentence. At no later section. No pointer to this paragraph found.
NEW: **Droplet · Readings changing the kind of the observed quantity.** The proposed Natural Physics of version 377 has, at its 4.11, readings changing the kind of the observed quantity: a rotation speed read as a rate, H0 read as two local rates, and an intensity difference read as an exchange rate. Each is said at the field's kind or released.

### 55
VERDICT: RESAY
CONCEPT: the persistent current at the proposed Natural Physics' 3.5 and 4.10 is steady charge transport at the field's record, and a cyclic pattern with no transport does not carry it.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 78. The persistent current is at the proposed 3.5 (proposed file line 256, "the persistent current at the spiral carrying its pattern whole") and 4.10 (line 498); the living Natural Physics has no saying of a persistent current (searched) and its 3.5 is the ten rests. At no later section (searched "persistent current" in carry/*.md: this mate's older paragraphs alone). No pointer to this paragraph found.
NEW: **Droplet · The persistent current, steady charge transport at the field's record.** The proposed Natural Physics of version 377 has the persistent current at its 3.5 and 4.10. At the field's record the persistent current is steady charge transport, and a cyclic pattern with no transport does not carry it.

### 56
VERDICT: KEEP
CONCEPT: a Bell relation the file before version 377 carried, sayable without the overclaim, is lost at the proposed text's 4.4; it is said without the overclaim or released with its reason.
EVIDENCE: Kept under do no harm. Its two named places, 2.6 and 3.4, are at the numbering before version 377 (2.7 and 4.4 at the living file now, by this mate's paragraph of the sections' places), and the relation's words, *no carried variable is what a coupling joined across carries*, are a review's own re-saying (carryings/review_natural_physics_v377/README.md line 55) at no living sentence: the living 4.4 has the overclaiming form, "Tighter-than-local correlation is exactly the thing one coupling at two faces about a self-stabilizing neutral is". A re-saying could not give the relation without a session's words or the places without a mapping of my own. Not resolved, the proposed text not entered. At no later section: "Concern · Bell's exclusion as proof, the distribution declined" (v386EOD) is another parting.
NEW: -

### 57
VERDICT: RESAY
CONCEPT: two of the register's namings, the two-way and the rate, are at different faces at Natural Naming 4.9 and at Resolving the Hard Problem Registry's sort at its front.
EVIDENCE: Not resolved, both sentences at their living files now: Exhibit_TWENTY_Natural_Naming_v380R.md lines 617 and 621 within 4.9 (the two-way at even, the rate at odd); Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md line 35, in the file's front (the rate at five, the two-way at six, "the odd face enters, along, and the even face surfaces, across"). Source: carryings/review_natural_physics_v377/README.md line 80. The like concern at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 165 is within its older Droplets (rule 1); this mate's v386EOD "Concern · Ten namings sorted at four and at the binaries" is another parting. Each quotation searched exact. No pointer to this paragraph found.
NEW: **Concern · The register's two namings at different faces.** Two sayings part. Exhibit TWENTY Natural Naming, at 4.9, has "a two-way named to one side" at "even, 3 of 3-4-co-bi-sharing, moralizing's" and "a rate named as a value" at "odd, 7-co-bi-co-corusing, corusing's". Exhibit TWENTY-TWO Resolving the Hard Problem Registry, at the sort at its front, has "five the stand carries rating, a sequencing and a rate; six the coupling closing carries co-offering, a two-way and the between", with "the odd face enters, along, and the even face surfaces, across". They part at the two-way and the rate, two namings of Natural Physics' register: each is at even at the one file and at odd at the other.

### 58
VERDICT: RESAY
CONCEPT: the proposed 3.4 promises an execution of the beat and the locking at each spiral pacing its own; the resolver's 17 steps each self together, a common beat, so the execution needs a pacing the resolver does not carry, and is said at that need or released.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 81. The promise is at the proposed 3.4 (proposed file line 246, "The beat and the locking range at close paces are to be executed at each spiral pacing its own"); the living Natural Physics' 3.4 is the light-cone. The name of 17 is given as it is now, 17-co-bi-tri-offering (Exhibit_ONE_Natural_Resolver_v380R.md; the paragraph has the older 17-tri-co-offering), and Natural_Intelligence_v380R.md line 222 within 3.5 has "the resolver steps each self's entry at 17-co-bi-tri-offering together, a common beat laid over the selves". At no later section. No pointer to this paragraph found.
NEW: **Droplet · The beat and the locking, at each spiral pacing its own.** The proposed Natural Physics of version 377 promises, at its 3.4, an execution of the beat and the locking at each spiral pacing its own. At Exhibit ONE Natural Resolver, 17-co-bi-tri-offering steps each self together, the common beat Natural Intelligence 3.5 names, and the execution promised needs a pacing the resolver does not carry. The execution is said at that need or released.

### 59
VERDICT: RESAY
CONCEPT: Natural Naming has *face* among the released words, facing a direction carrying on; Natural Physics says *face* at its own sentences, each ready for re-saying at its own motion.
EVIDENCE: Not resolved: Exhibit_EIGHTEEN_Natural_Physics_v379.md has *face* or *faces* at forty-seven lines (searched), three section titles among them. Exhibit_TWENTY_Natural_Naming_v380R.md line 313 has the row "| *face*, *faces* | the name; *its side*; *its form*, of an emanation; *is facing*, of a direction; a field's *word*; parity's *unit square* |". At no later section; this mate's "Aimed at a file, Natural Physics: *face* and *faces* at forty-six places" is within the older Droplets (rule 1) and does not point at this paragraph. "Ready … at its own motion" is said as a relation.
NEW: **Droplet · *Face* dissolved, at Natural Physics' own sentences.** Exhibit TWENTY Natural Naming carries *face* among the released words, each re-saying beside it; facing is a direction and carries on. Exhibit EIGHTEEN Natural Physics says *face* at its own sentences. Each of those sentences is ready for its re-saying, Natural Physics' own to make at its motion.

### 60
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' logic at Exhibit ONE's code: each script executes again and matches, fifteen of sixteen claims at the code true, the register's numbers from its fifty rows, each open item said open.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 15 (its section 1). A record of the proposed text with content, no bookkeeping alone, and at no living file (the proposed text is not entered) and no later section. The versions of the two code blocks are the fact the finding is of and are carried. Paragraph 50 gives its sum in a line and is no later place. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, its logic at Exhibit ONE's code.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the logic at Exhibit ONE Natural Resolver's code: each script in `executions/` executes from the root at the code block of Natural Intelligence at version 378, byte-identical to that of Exhibit ONE Natural Resolver at version 376, and each output matches `outputs.txt`. Sixteen claims at the code are checked, and fifteen are true, at 3.2, 3.3, 3.5, 3.6, 3.7, 3.8, 4.5, 2.5, 5.11, 1.2, 2.8, 5.6 and 4.7. The register's numbers, eighteen and thirty-two, twenty-one, thirteen, nine and five, thirty-one and seventeen, are each numbered from its fifty rows. Each item the proposal's report lists as open at its section 6.2 is said open in the proposed text at the section named, with the phrase confirmed.

### 61
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' explaining: the front at the steady form, the released words fallen from the prior to the proposal with each number, and *keeping* risen as the name of a binary.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 17 (its section 1). A record with numbers, at no living file and no later section. The words in italics are the file's own words numbered there, cited as words. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, its explaining and the released words.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the explaining: the front is at the steady form, forty-nine entries exactly the body's headings, with no `&nbsp;`. The released words fall from the prior to the proposal at nearly each word: *so* 28 to 0, *would* 13 to 0, *held* 117 to 0, *stands* 49 to 0, *there* 57 to 0, *where* 67 to 1, *sign* 59 to 1, *run* 44 to 0, *kept* 21 to 0, *stilling* 18 to 0. *Keeping* rises 1 to 10 as the name of a binary, the name Natural Intelligence 1.4 and Exhibit TWENTY-FOUR Geodesic Improving Method 2.7 use.

### 62
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics' observings: fifty-one records of the field checked and correct at their numbers and sources, each named.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 19 (its section 1). A record with its names and numbers, at no living file and no later section. No pointer to this paragraph found.
NEW: **Droplet · Fifty-one records of the field, correct at the proposed Natural Physics of version 377.** The review of the proposed Natural Physics of version 377 has, at its section 1, of the observings read as a physicist: fifty-one records checked and correct at their numbers and their sources: Hensen's S = 2.42 ± 0.20 at 245 trials and 1.3 kilometres, Aspect, File and Mills, Tsuei's h/4e, the Kirkwood gaps, Greene, Jung's 47 days and Bosch's 33 years, Ohtsuki's 0.83 percent, Wu, Goldhaber, the shell capacities, the IUPAC group-three report, Bakun and Lindh, Deegan, the AME2020 masses, Noether, Onsager, Jaffe and Witten, the ALICE and CMS papers, Gibbons and Hawking, Steinhauer, DESI, GW190521 and GW231123, KiDS-Legacy, the muon g-2 lattice result, Eriksson, Phan, Torbert and the Magnetospheric Multiscale events.

### 63
VERDICT: RESAY
CONCEPT: a review's finding of the proposed Natural Physics read fresh beside its prior: thirty of forty sections whole, the corrections of the prior's overclaimings rightly made, the released readings released with their reasons and rightly.
EVIDENCE: A quotation of a report, carryings/review_natural_physics_v377/README.md line 21 (its section 1). A record with its named readings, at no living file and no later section; this mate's last v386EOD section, from the physics motion of version 377, has five concerns from the released readings and not this finding. No pointer to this paragraph found.
NEW: **Droplet · The proposed Natural Physics of version 377, read fresh beside its prior.** The review of the proposed Natural Physics of version 377 has, at its section 1, of a fresh reading beside the prior: thirty of the prior's forty sections are whole at the proposal; the corrections of the prior's overclaimings, gravity is nothing, relativistic simultaneity, the simulation inadmissible, are each rightly made; and the released readings the proposal's report names, 23 and 55, the capstone, the singularity as the Navier–Stokes seam, the genus with no φ, the softmax, the completest inversions, the screening constant, the clean conservings, the dark matter and black-hole pairing, ageing, the rhyme, geotensioning and fifty-nine as light, are released with their reasons and rightly.

### 64
VERDICT: RESAY
CONCEPT: each finding of the review's 2.1 to 2.6 is a harm at do no harm in the proposed text as it is, of three kinds, and is answered ahead of the proposed text replacing its prior at corus.me.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md lines 23 to 25 (its section 2). It is a condition laid on the paragraphs after it (rule 6), paragraphs 65 to 87 here and the items of 2.2 to 2.6 after them, so it is re-said with them (rule 2): it keeps its subject words, "each finding of its 2.1 to 2.6", and each of 65 to 87 names the review's 2.1 or 2.2 and its item, so each still finds the other. "To be met before" is said as a relation (rule 9). At no living file and no later section.
NEW: **Droplet · Each finding of the review's 2.1 to 2.6, a harm at do no harm.** The review of the proposed Natural Physics of version 377 has, at its section 2, each finding of its 2.1 to 2.6 as a harm at do no harm, the proposed text being as it is: a field's record said wrongly, a prior value lost with no reason named, or a reading asserted while the proposed text says at another section it is open. Answering each is ahead of the proposed text replacing its prior at corus.me.

### 65
VERDICT: RESAY
CONCEPT: the proposed 3.8 has decay departing from the exponential at Wilkinson and at Rothe; neither is nuclear decay, and no departure has been measured at radioactive decay.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 28 (2.1 item 1, under "The field's record said wrongly, twenty-two places … with the record beside it"). The sentence is at the proposed file's line 284, within its 3.8. Not resolved: the proposed text is not entered, and the living Natural Physics has no section of decay. At no later section (searched "Wilkinson", "Norman and colleagues" in carry/*.md: this mate's older paragraphs and the Session Record alone). Paragraph 64 frames it and is re-said with it; no other pointer found.
NEW: **Droplet · A departure from the exponential, measured at no radioactive decay.** The proposed Natural Physics of version 377 has, at its 3.8, decay departing from the exponential at short times, at Wilkinson, and at long times, at Rothe. Its review, at item 1 of its 2.1, has this as the field's record said wrongly, with the record beside it: neither is nuclear decay; Wilkinson 1997 is cold sodium atoms tunnelling in an optical lattice, and Rothe 2006 is luminescence of organic molecules in solution; no departure from the exponential has been measured at radioactive decay, Norman and colleagues 1988 setting limits.

### 66
VERDICT: RESAY
CONCEPT: the proposed 3.8 has the decay rate changing at the atom about the nucleus opening or closing; the field's account of the two cases is bound-state beta decay, and the text states neither the account nor the reading as proposed.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 29 (2.1 item 2). The sentence is at the proposed file's line 286, within its 3.8. Not resolved, the proposed text not entered; the living Natural Physics has no section of decay. At no later section (searched "bound-state beta"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A decay rate changing at the atom, beside bound-state beta decay.** The proposed Natural Physics of version 377 has, at its 3.8, the rate changing at the atom about the nucleus opening or closing. Its review, at item 2 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's account of the dysprosium-163 and rhenium-187 cases is bound-state beta decay, the electron emitted into an empty shell, and the proposed text states neither the account nor the reading as proposed.

### 67
VERDICT: RESAY
CONCEPT: the proposed 3.8's form of pairing, one member in two at each pairing; alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat, a thing the text releases at its other places.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 30 (2.1 item 3). The words in italics are the proposed text's own, at its line 282 within 3.8 ("meeting in pairs at an empty carrying, with no others joining, goes to one member in two at each pairing"), cited as the review cites them. Not resolved, the proposed text not entered. At no later section. Paragraph 53 is the like concern from the review's section 3 and is no later place. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A form of pairing at decay, beside single-nucleus events.** The proposed Natural Physics of version 377 has, at its 3.8, the form *meeting in pairs, one member in two at each pairing*. Its review, at item 3 of its 2.1, has this as the field's record said wrongly, with the record beside it: alpha and beta decay are single-nucleus events with no partner, and a halving at each step is a common beat, the thing the proposed text releases at its other places.

### 68
VERDICT: RESAY
CONCEPT: the proposed 3.3 has the two sides' clicks perfectly correlated at equal settings; Hensen's pairs are anti-correlated there and Aspect's photons correlated, one fact stated for both.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 31 (2.1 item 4). The sentence is at the proposed file's line 234, within its 3.3. Not resolved, the proposed text not entered; the living Natural Physics' 3.3 is light and has no such sentence. At no later section (searched "anti-correlated", "singlet"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Clicks at equal settings, correlated and anti-correlated.** The proposed Natural Physics of version 377 has, at its 3.3, the two sides' clicks perfectly correlated at equal settings. Its review, at item 4 of its 2.1, has this as the field's record said wrongly, with the record beside it: Hensen's pairs are a singlet, anti-correlated at equal settings; Aspect's cascade photons are correlated; and one fact is stated for both.

### 69
VERDICT: RESAY
CONCEPT: the proposed 3.4 has nothing passing between the spirals but the changings at Huygens' clocks; the field's account has momentum exchanged through the common beam, the mechanism dropped, while at Bell, 3.3, the same phrase carries no-signalling intact.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 32 (2.1 item 5). The sentence is at the proposed file's line 242, within its 3.4, and the like phrase at its line 232, within 3.3. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of Huygens. At no later section (searched "common beam"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Nothing passing but the changings, at Huygens' clocks and at Bell.** The proposed Natural Physics of version 377 has, at its 3.4, nothing passing between the spirals but the changings, at Huygens' clocks. Its review, at item 5 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's account has momentum exchanged through the common beam, and the mechanism is dropped. At Bell, at its 3.3, the same phrase carries no-signalling intact.

### 70
VERDICT: RESAY
CONCEPT: the proposed 3.7 has the flow between two quark jets differing with the third at OPAL; the string effect was first observed by JADE in 1983, and OPAL's photon comparison of 1991 is the later test.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 33 (2.1 item 6). The sentence is at the proposed file's line 278, within its 3.7. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of OPAL. At no later section (searched "JADE"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The string effect, first observed by JADE.** The proposed Natural Physics of version 377 has, at its 3.7, the flow between two quark jets differing with the third, at OPAL. Its review, at item 6 of its 2.1, has this as the field's record said wrongly, with the record beside it: the string effect was first observed by JADE, 1983, Physics Letters B 134, 275, and OPAL's photon comparison, 1991, is the later test.

### 71
VERDICT: RESAY
CONCEPT: the proposed 4.9, step 4, has the cold both approach from opposite sides; a black hole's Hawking temperature rises as it evaporates, and only the background cools.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 34 (2.1 item 7). The sentence is at the proposed file's line 484, step 4 of its 4.9. Not resolved: the proposed text is not entered, and the living 4.9, step 4, has the like sentence still ("the cold both approach and neither lands on is the 0"), which NEW does not add. At no later section: "Concern · Two horizons, each with a temperature, at the field" (v386EOD) is another parting. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The cold both approach, beside a black hole's temperature rising.** The proposed Natural Physics of version 377 has, at step 4 of its 4.9, the cold both approach from opposite sides. Its review, at item 7 of its 2.1, has this as the field's record said wrongly, with the record beside it: a black hole's Hawking temperature rises as it evaporates, T proportional to 1/M, and only the background cools.

### 72
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 1, has the field naming dark matter, dark energy or a reconciliation at the Hubble tension; the field names systematics or physics beyond ΛCDM, and dark energy is at cosmic acceleration, a row at 5.11.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 35 (2.1 item 8). The sentence is at the proposed file's line 507, step 1 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 1, has the like sentence still ("Each is taken as an anomaly demanding a substance (dark matter, dark energy) or a reconciliation."). At no later section (searched "ΛCDM"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The field's names at the Hubble tension.** The proposed Natural Physics of version 377 has, at step 1 of its 4.11, the field naming dark matter, dark energy or a reconciliation at the Hubble tension. Its review, at item 8 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field names systematics or physics beyond ΛCDM, and dark energy is at cosmic acceleration, a row at 5.11.

### 73
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 6, has S8's difference closing at the KiDS-Legacy analysis; one survey is consistent with Planck, two are still low, and the field says eased.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 36 (2.1 item 9). The sentence is at the proposed file's line 512, step 6 of its 4.11. Not resolved, the proposed text not entered; the living 4.11 has S8 as not agreeing and no KiDS-Legacy. At no later section; this mate's droplet aimed at the living S8 sentence (session v383Op's) is within the older Droplets and is of another sentence. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · S8's difference at the KiDS-Legacy analysis.** The proposed Natural Physics of version 377 has, at step 6 of its 4.11, S8's difference closing at the KiDS-Legacy analysis. Its review, at item 9 of its 2.1, has this as the field's record said wrongly, with the record beside it: one survey is consistent with Planck, DES Y3 and HSC Y3 are still low, and the field says eased.

### 74
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 1, has pulsars' pulses matching the Hellings–Downs pattern; NANOGrav's fifteen-year set reports three to four sigma evidence, and *matching* overstates.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 37 (2.1 item 10). The sentence is at the proposed file's line 507, step 1 of its 4.11. Not resolved, the proposed text not entered; the living 4.11 has no Hellings–Downs. *Matching* is the word judged, cited as a word, as the review cites it. At no later section (searched "Hellings"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Pulsars' pulses at the Hellings–Downs pattern.** The proposed Natural Physics of version 377 has, at step 1 of its 4.11, pulsars' pulses matching the Hellings–Downs pattern. Its review, at item 10 of its 2.1, has this as the field's record said wrongly, with the record beside it: NANOGrav's fifteen-year set reports three to four sigma evidence, and *matching* overstates.

### 75
VERDICT: RESAY
CONCEPT: the proposed 4.11, steps 3 and 4, has a rate not falling to rest at the edge; the expected Keplerian curve falls as r to the power −1/2, not to rest, and a rotation speed is no rate in the text's sense.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 38 (2.1 item 11). The sentence is at the proposed file's line 509, step 3 of its 4.11, with step 4 at line 510. Not resolved: the proposed text is not entered, and the living 4.11 has the like sentences still ("a rate that does not fall to rest at the edge", "Kepler, a landing toward zero"). The review's "r to the minus one half" is given in numerals, the same power. At no later section (searched "Keplerian"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A rate not falling to rest at the edge.** The proposed Natural Physics of version 377 has, at steps 3 and 4 of its 4.11, a rate not falling to rest at the edge. Its review, at item 11 of its 2.1, has this as the field's record said wrongly, with the record beside it: the expected Keplerian curve falls as r to the power −1/2, not to rest, and a rotation speed is no rate in the proposed text's sense.

### 76
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 4, reads the two expansion rates as rates local to their couplings; H0 is one present-day parameter with two measured values, and local variation is bounded to one or two percent.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 39 (2.1 item 12). The sentence is at the proposed file's line 510, step 4 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 4, has the like sentence still ("Both-scale expansion difference is rates being local — no single global rate to land on."). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Two expansion rates read as local, beside H0 as one parameter.** The proposed Natural Physics of version 377 has, at step 4 of its 4.11, the two expansion rates read as rates local to their couplings, no one global rate. Its review, at item 12 of its 2.1, has this as the field's record said wrongly, with the record beside it: H0 is one present-day parameter with two measured values, and local variation is bounded to one or two percent.

### 77
VERDICT: RESAY
CONCEPT: the proposed 4.11, step 6, has a temperature difference as a measured exchange rate; the Cold Spot and the hemispheric asymmetry are intensity differences on one surface at one epoch.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 40 (2.1 item 13). The sentence is at the proposed file's line 512, step 6 of its 4.11. Not resolved: the proposed text is not entered, and the living 4.11, step 6, has the like sentence still ("the equilibrium framing of a measured bi-exchange rate"). At no later section (searched "Cold Spot"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A temperature difference as a measured exchange rate.** The proposed Natural Physics of version 377 has, at step 6 of its 4.11, a temperature difference as a measured exchange rate. Its review, at item 13 of its 2.1, has this as the field's record said wrongly, with the record beside it: the Cold Spot and the hemispheric asymmetry are intensity differences on one surface at one epoch.

### 78
VERDICT: RESAY
CONCEPT: the proposed 4.8 has presentism and eternalism at McTaggart; McTaggart gave the A and B series, and the two terms are later, Prior and Putnam.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 41 (2.1 item 14). The sentence is at the proposed file's line 469, within its 4.8. Not resolved: the proposed text is not entered, and the living 4.8 has the like words still ("(presentism and eternalism, McTaggart)", line 399), which NEW does not add. At no later section (searched "McTaggart"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Presentism and eternalism, later than McTaggart.** The proposed Natural Physics of version 377 has, at its 4.8, presentism and eternalism at McTaggart. Its review, at item 14 of its 2.1, has this as the field's record said wrongly, with the record beside it: McTaggart gave the A and B series, and the two terms are later, Prior and Putnam.

### 79
VERDICT: RESAY
CONCEPT: the proposed 2.2 has a force at the field's account as a doer applying from outside; the field defines force as the rate of change of momentum, with no doer, and the sentence is the text's reading said as the field's account.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 42 (2.1 item 15). The sentence is at the proposed file's line 139, within its 2.2. The words in italics are the proposed text's, and a living file's own as well (Exhibit TWENTY-FOUR Geodesic Improving Method 2.7, "or a doer applying from outside"). Not resolved, the proposed text not entered; the living 2.2 has no such sentence. At no later section (searched "rate of change of momentum"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · A force at the field's account, with no doer.** The proposed Natural Physics of version 377 has, at its 2.2, a force at the field's account as *a doer applying from outside*. Its review, at item 15 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field defines force as the rate of change of momentum, with no doer, and the sentence is the proposed text's reading said as the field's account.

### 80
VERDICT: RESAY
CONCEPT: the proposed 2.3 and 4.4 have Copenhagen, many worlds, decoherence and objective collapse each moving the cause; many worlds denies collapse and seeks no cause, and Copenhagen posits none.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 43 (2.1 item 16). The sentence is at the proposed file's line 409, within its 4.4, and "each candidate moving the cause" at its line 147, within 2.3. Not resolved: the proposed text is not entered, and the living 4.4, step 1, has the like sentence still ("each relocate the cause and none terminates the question"). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Interpretations each moving the cause, beside many worlds and Copenhagen.** The proposed Natural Physics of version 377 has, at its 2.3 and 4.4, Copenhagen, many worlds, decoherence and objective collapse each moving the cause. Its review, at item 16 of its 2.1, has this as the field's record said wrongly, with the record beside it: many worlds denies collapse and seeks no cause, and Copenhagen posits none.

### 81
VERDICT: RESAY
CONCEPT: the proposed 4.5, step 1, has the field naming two hard parts, energy's being among them; the field names no such standing problem.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 44 (2.1 item 17). The sentence is at the proposed file's line 422, step 1 of its 4.5 ("names two hard parts: energy's being, only the conserved number given; and time's direction"). *Standing* is the review's word and a living file's own (Natural Physics 4.5, "the standing problem"), cited in italics. Not resolved: the proposed text is not entered, and the living 4.5, step 1, has "Hard parts: energy's being" still. At no later section; this mate's droplet aimed at the living sentence of energy as a stuff (session v383Op's) is within the older Droplets and of another sentence. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Energy's being, at no problem the field names.** The proposed Natural Physics of version 377 has, at step 1 of its 4.5, the field naming two hard parts, energy's being among them. Its review, at item 17 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field names no such *standing* problem.

### 82
VERDICT: RESAY
CONCEPT: the proposed 4.3, step 1, has the field calling the curve the most important diagram in nuclear physics; a textbook flourish, no claim of the field.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 45 (2.1 item 18). The sentence is at the proposed file's line 396, step 1 of its 4.3. Not resolved: the proposed text is not entered, and the living 4.3, step 1, has the like sentence still ("This is, in the field's words, the single most important diagram in nuclear physics."). At no later section (searched "most important diagram", "textbook flourish"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The most important diagram in nuclear physics, a textbook flourish.** The proposed Natural Physics of version 377 has, at step 1 of its 4.3, the field calling the curve the most important diagram in nuclear physics. Its review, at item 18 of its 2.1, has this as the field's record said wrongly, with the record beside it: a textbook flourish, and no claim of the field.

### 83
VERDICT: RESAY
CONCEPT: the proposed 3.12 has each changing making the other at the field's account; in a plane wave the two fields are in phase and both sourced by the charges, and the curl equations relate and cause nothing.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 46 (2.1 item 19). The sentence is at the proposed file's line 328, within its 3.12. Not resolved: the proposed text is not entered, and the living 3.3 has the like sentence still ("a changing electric offering sourcing a magnetic one, a changing magnetic offering sourcing an electric"). At no later section (searched "plane wave"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Each changing making the other, beside a plane wave's two fields.** The proposed Natural Physics of version 377 has, at its 3.12, each changing making the other at the field's account. Its review, at item 19 of its 2.1, has this as the field's record said wrongly, with the record beside it: in a plane wave the two fields are in phase and both sourced by the charges, and the curl equations relate and cause nothing.

### 84
VERDICT: RESAY
CONCEPT: the proposed 3.14 has physics having sought rest at ten subjects; the field sought rest at neither the critical point nor the inertial frame, and the ten are the text's framing.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 47 (2.1 item 20). The sentence is at the proposed file's line 344, within its 3.14. Not resolved: the proposed text is not entered, and the living 3.5 has the ten still, the inertial rest frame and the critical point among them. At no later section: "Concern · Thermal equilibrium among the ten rests" and "Droplet · A rest sought, at a sphere's form" (v386EOD) are of other rests and another reading. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Rest sought at ten subjects, the ten a framing.** The proposed Natural Physics of version 377 has, at its 3.14, physics having sought rest at ten subjects. Its review, at item 20 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field sought rest at neither the critical point nor the inertial frame, and the ten are the proposed text's framing.

### 85
VERDICT: RESAY
CONCEPT: the proposed 3.1 has the Jet Propulsion Laboratory's aberration correction; the field's name is light-time correction, Moyer, and aberration is a separate correction.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 48 (2.1 item 21). The sentence is at the proposed file's line 220, within its 3.1. Not resolved, the proposed text not entered; the living Natural Physics has no sentence of the Jet Propulsion Laboratory. At no later section (searched "light-time correction", "Moyer"). Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Light-time correction, the field's name.** The proposed Natural Physics of version 377 has, at its 3.1, the Jet Propulsion Laboratory's aberration correction. Its review, at item 21 of its 2.1, has this as the field's record said wrongly, with the record beside it: the field's name is light-time correction, Moyer, and aberration is a separate correction.

### 86
VERDICT: RESAY
CONCEPT: the proposed 4.7, step 1, has quantum theory describing the small scale as discrete and probabilistic; the wavefunction evolves continuously, and discreteness is at spectra and outcomes.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 49 (2.1 item 22). The sentence is at the proposed file's line 456, step 1 of its 4.7. Not resolved: the proposed text is not entered, and the living 4.7, step 1, has the like sentence still ("quantum mechanics describes the small scale as discrete, probabilistic, granular"). At no later section. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · The small scale said discrete, beside a wavefunction evolving continuously.** The proposed Natural Physics of version 377 has, at step 1 of its 4.7, quantum theory describing the small scale as discrete and probabilistic. Its review, at item 22 of its 2.1, has this as the field's record said wrongly, with the record beside it: the wavefunction evolves continuously, and discreteness is at spectra and outcomes.

### 87
VERDICT: RESAY
CONCEPT: the proposed 5.1 lists Bell's correlated clicks and wave and particle under no contradiction found, and lists 3.3's angle dependence and 4.4's amplitudes under reaching, in one section.
EVIDENCE: Source: carryings/review_natural_physics_v377/README.md line 51 (2.2, "A reading asserted where the file says it is open, or where the record parts"). The two lists are at the proposed file's lines 540 and 542, within its 5.1; the two phrases in italics are those lists' own labels, cited as the review cites them. Not resolved, the proposed text not entered; the living 5.1 has other lists. At no later section: "Concern · Bell's exclusion as proof, the distribution declined" (v386EOD) is another parting. Paragraph 64 frames it; no other pointer found.
NEW: **Droplet · Bell's clicks and wave and particle, listed at no contradiction and at reaching.** The proposed Natural Physics of version 377 lists, at its 5.1, Bell's correlated clicks, 3.3, and wave and particle, 4.4, under *meets the field's records with no contradiction found*, and the same section lists 3.3's angle dependence and 4.4's amplitudes under *reaching*. Its review has this at its 2.2, as a reading asserted at a place the proposed text says is open, or at a parting of the record.

## READING
Each of the fifty-one paragraphs, 37 to 87, was read and checked, one block for each, none left out. Read whole: the living Exhibit_EIGHTEEN_Natural_Physics_v379.md (all 638 lines); the mate carry/Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md, its front, its Insertlets, its older Droplets (lines 13 to 573) and each later section headed v385A or v386EOD (lines 574 to 712); carryings/review_natural_physics_v377/README.md whole, the source of paragraphs 50 to 87. Read in part and searched: the proposed text carryings/natural_physics_v377/Exhibit_EIGHTEEN_Natural_Physics_v377_proposed.md (its headings, and each sentence the review cites, found at the section the review names); Natural Intelligence 1.4 and 3.5; Exhibit TWENTY-FOUR Geodesic Improving Method 2.7; Exhibit TWENTY Natural Naming 2.4, 2.5 and 4.9; Exhibit TWENTY-TWO Resolving the Hard Problem Registry's front; Exhibit THREE Natural Numbers 7.1 and 3.3; Exhibit SIXTEEN Natural Chemistry 4.4; Exhibit FOUR Natural Mathematics; Exhibit TWELVE Natural Explaining 4.7; Exhibit THIRTY Co-Chaining Logic Registry step 644; Exhibit TWENTY-NINE Natural Illustrating; Exhibit ONE Natural Resolver's names. Mates searched for the same concepts and for pointers: carry/*.md, with the Carryings and Possibling mates of Natural Physics, and the offering mates of Natural Numbers, Natural Chemistry, Natural Naming, the Geodesic Improving Method, Natural Intelligence, Resolving the Hard Problem Registry, the Co-Chaining Logic Registry and Exhibit ONE read at the places found. Each quotation in a NEW paragraph was searched exact in its living file.

The proposed Natural Physics of version 377 is not entered: the living file is version 379, at forty sections, and the review's section numbers (3.8, 3.12, 3.14 and the like) are the proposed text's, so no review finding is RESOLVED, and none is at a later section. Each NEW from the review names the proposed text and the review's own section and item, so paragraph 64's "each finding of its 2.1 to 2.6" still finds them; where the living file has the like sentence, EVIDENCE says so and NEW adds none of it. Words of the proposed text are cited in italics at 67, 79 and 87, and words numbered or judged as words at 61, 74 and 81.

Pointers found at paragraphs of this portion: at 42 (this mate's line 568, the Carryings mate's line 29, Natural Illustrating line 446) and at 43 (Natural Illustrating line 446); both kept. Paragraph 40 points at another paragraph of this mate, "the forms above", and 41 qualifies 40; both kept.

Not found: what "the proposed three-science contents" of paragraph 46 is; the labels "THIRTY P1–P4" and on of paragraph 48 at any present file; one present sentence for "the older k-bound, iron-centreline and pair-creation relation" of paragraph 47. Each is kept as it is. Paragraphs 51 to 58 are the like of the review's section 3 items laid later in this mate's older section (outside this portion); they are not two copies within this input and were each given their own verdict.
