### 11
CHECK: OK
WHY: the three quotations are exact (the living file's line 106 under 1.5 and line 512 under 5.2; Natural_Intelligence_v380R.md line 156 under 2.4); lines 123 and 327 of the file at version 375 (git ff6cdd6) are those two sentences, and its lines 214 to 219 are the table of 3.4 and the bold line after it, which now have "moving one self on at each second momentary" (line 227) and "one self at each second momentary" (line 229), with Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md 4.4 (line 172) saying the same, so the part left out of NEW is said at the living file; the order, "read from next to prior", "the forward order" and the entering at the file's own motion are each in NEW; carryings/rings_are_spirals_v377/README.md section 5 item 6 (line 121) read; no paragraph of carry/*.md points at it (searched "table's rows at the code").
SAFER: -

### 12
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 13
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 14
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 15
CHECK: OK
WHY: laid beside the prior and archive/session_v379/Session_Report_v379.md finding 20 (line 35): the rings kit alone, the kit's path, "as the version 363 registry's", no living file, no cube at this file and "is or is not, with the reason either way" are each in NEW; the sentence is at kits/Natural_Illustrating_TWENTY-NINE_Improving_Kit/Illustration_Kit_v366/inherited/Kit_Rings_in_Motion_v365/Kit_Rings_in_Motion_v365.md and at no file at the root (searched "cubing supplies"), and the living file, read whole, has no "cube" and no "Rubik"; NEW has no quotation.
SAFER: -

### 16
CHECK: OK
WHY: the three quotations are exact (the living file's line 203 under 3.3; Exhibit_TWENTY_Natural_Naming_v380R.md line 609 under 4.9; Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md line 240 under 2.7, which has "Natural Naming at one name of 1 to 8 by the four-cycles" and "the seatings part at the carryings", the sentence that names the parting); the third pairing, the drawing of 3.3's seating and "for both" are in NEW; finding 10 read at archive/session_v379/Session_Report_v379.md line 24; the twin at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md line 99 has the same saying.
SAFER: -

### 17
CHECK: OK
WHY: the file at the finding (Exhibit_TWENTY-EIGHT_Equilibria_Registry_v377.md at git e4b5b42) has *what* at its lines 80, 182 and 252, and line 252 there, "2. **The subject**: what the field says is changing", is line 254 now; the four quotations are exact at lines 80, 182 and 254 under 1.3, 3.2 and 4.2; the rule at kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/check_set.py lines 67 to 74 was read, and a search of the living file for each word of its list finds lines 80, 182, 253, 254 and 255 alone, 253 and 255 within a bold span the rule removes; "mechanical" is in NEW; finding 24 read at archive/session_v379/Session_Report_v379.md line 39.
SAFER: -

### 18
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 19
CHECK: OK
WHY: each of the four open things is in NEW at its strength, and the four quotations are exact (the living file's lines 76, 226 and 227; Natural_Intelligence_v380R.md line 1000); the instruments are at carryings/equilibria_registry_v377/executions/ and at incoming/ no more, each opening 'Exhibit_ONE_Natural_Resolver_v376.md' (line 2 or 3 of each of the eight); "as they were" is the source's (carryings/v380L/Progress.md line 35); the part left out, what entered, is at the living file by search: no "the code" at its own voice, Part FIVE's title, each of the twelve step numbers, no pointer by a line into Natural Intelligence, and the sayings at a carrying of none at 1.3 and 3.4 (lines 80, 221 and 231) and at 5.4 (line 533), none at 2.4, the "2.4" being the source's own word and whole at carryings/v380L/Progress.md line 232; the pointer "the entry below" finds paragraph 25 by its subject words, which the SAFER of 25 has unchanged.
SAFER: -

### 20
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 21
CHECK: OK
WHY: both quotations are exact (the living file's line 160 under 2.4 and line 221 under 3.4); "The Registry" is this file: the paragraph is of this file's own carrying from version 372 (git c7af45c; archive/carrying_v381R/Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380R.md line 13), and Exhibit_TWENTY-EIGHT_Equilibria_Registry_v368.md (git bdf5ef1) has both as entries of its contents and bold leads (lines 41, 59, 161 and 201), the second the entry of selves in a ring and one + offered once, 3.4's entry now; the earlier words stay in italics, the society named not changing and "the only possible existing" are in NEW, and "slightest tipping" is at no file at the root.
SAFER: -

### 22
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 23
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 24
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 25
CHECK: OBJECT
WHY: A condition widened. The prior has "*face*, *connector*, *join* and *the code*, each re-said as Natural Naming re-says it, one motion; and each pointer by line … said by its section": "one motion" is laid on the re-saying of the words, ahead of the semicolon, and the pointers by a line are a second thing after it. NEW has "Laid ready …, as one motion: *face*, *connector* and *join*, each re-said …; and each pointer by a line … said by its section", which lays "one motion" on both. The rest was read and is whole: the living file has no "the code" at its own voice (searched; the word is in the instruments' file names and in "its own code" of the older resolver, line 541) and no pointer by a line into Natural Intelligence, so those two are done; a search for "line" with a number finds four pointers alone, "Natural Mathematics line 85" twice at 1.3 (lines 74 and 78), "Resolving the Hard Problem Registry line 740" at 3.2 (line 195) and "Resolving the Hard Problem Registry, line 35" at 3.3 (line 203), each quoted exactly; *face*, *connector* and *join* are at the file's own voice still (lines 74, 203 and 235); the title has the subject words paragraph 19 points at.
SAFER: **Droplet · *Face*, *connector* and *join* re-said, and each pointer by a line said by its section.** Laid ready for Exhibit TWENTY-EIGHT Equilibria Registry: *face*, *connector* and *join*, each re-said as Natural Naming re-says it, one motion; and each pointer by a line into Natural Mathematics and Exhibit TWENTY-TWO Resolving the Hard Problem Registry said by its section. The pointers by a line are "Natural Mathematics line 85" at 1.3, "Resolving the Hard Problem Registry line 740" at 3.2 and "Resolving the Hard Problem Registry, line 35" at 3.3.

### 26
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 27
CHECK: OK
WHY: Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md has, by exact search, steps 2, 3, 47 and 88 as the first reader gives them (lines 64, 68, 260 and 436), step 88 with "*Adding: exclusivity.*", none with an Unsure line (the first Unsure line of that file is at its line 1000); the old step 2's Unsure line, "whether the universe, the set, is one of its existing things waits on a step of its own" (the Registry of 264 steps at git e0ba214, line 57), is answered by step 3; the living file's 1.1 (line 60) says the item at step 88's words; the row is whole at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md line 22; no paragraph of carry/*.md names item 1, S1 or S2 (searched; paragraphs 90 and 91 of this section name other items).
SAFER: -

### 28
CHECK: OK
WHY: the part left out is said at Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md steps 84 to 87 (lines 420 to 434), exhaustiveness, determinacy, reachability and "Existing is these three at once, at each momentary.", each with its Adding line and no Unsure line; both quotations are exact (the living file's line 64 under 1.2; the Registry's step 144, line 692); the old 96 and 97 (git e0ba214, lines 531 and 535) are the sentences of steps 143 and 144 now; "at each momentary together" is in NEW as offered; no paragraph names item 2 or S3.
SAFER: -

### 29
CHECK: OK
WHY: the living file has no "membrane" at any line (searched) and its line 68 has the sentence re-said with "The between is the protocol's centre at 1.3"; Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md has step 467 with "*Adding: inseparating.*" (line 2072) and the between at steps 27, 99, 103 and 105 (lines 172, 484, 500 and 508), step 103 with "it exists as the set exists, as its things exist", none with an Unsure line; the old step 19's Unsure line, "said through a nothing and a no; a positive saying not yet found" (git e0ba214, line 139), is gone from step 27, the same sentence; carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md line 3 has "inseparating 363" among the entered; no paragraph names item 4 or S4, and paragraph 91's "S5/S6 the between" lists items 40, 23, 53, 54, 6, 8 and 11, item 4 not among them.
SAFER: -

### 30
CHECK: OK
WHY: the three quotations are exact (the living file's line 70 under 1.2; the Registry's step 46, line 256, and "of no size" at steps 63 and 65, lines 332 and 340); each old step was laid beside the Registry of 264 steps (git e0ba214): 34 is 46, 42 is 63, 44 is 65, 49 is 75, 178 and 179 are 299 and 300, 210 and 211 are 372 and 374, the same steps; each of the Registry's steps with "universe" was read and none has a universe at each scale; "a not possible thing" is the prior's own; the step offered is S7 word for word at carryings/co_chaining_map_v376/cover_EQUILIBRIA.md line 144, with its "Release 'of each size'"; no paragraph names item 5 or S7.
SAFER: -

### 31
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 32
CHECK: OK
WHY: Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md has, by exact search, step 187 (line 876) with "*Adding: co-bi-unrelationing.*", the three namings at one step and co-bi-unrelationing "the one method at its two relations", beside step 48's "parity changing is the one possible method"; the old 190 and 80 (git e0ba214, lines 960 and 443, with their Unsure lines at 964 and 447) are steps 347 and 122 now (lines 1551 and 588), neither with an Unsure line; the living file's 1.3 (line 80) has the sentence; the row is whole at cover_EQUILIBRIA.md line 28; no paragraph names item 7 or S8.
SAFER: -

### 33
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 34
CHECK: OK
WHY: both quotations are exact (the living file's line 82 under 1.3; the Registry's step 63, line 332, the old 42 by its sentence); "slowing" and "slower" are at no line of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (searched); the implying of a size of rate, the parting from *of no size* and "unless it is said at is-or-is-not" are each in NEW; the step offered is S10 word for word at cover_EQUILIBRIA.md line 149; no paragraph names item 10 or S10.
SAFER: -

### 35
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 36
CHECK: OK
WHY: the living file's line 86 under 1.3 has "**The eight even names are bi-coupling at the between.** Four outward at the between, 2, 4, 6 and 8, and four inward, 10, 12, 14 and 16, each 8 up", with no "membrane" and no "within" at it; Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md step 254 (line 1151) is the old 142 word for word, with no Unsure line; the row is whole at cover_EQUILIBRIA.md line 33 with no proposed step; no paragraph names item 12.
SAFER: -

### 37
CHECK: OK
WHY: both quotations are exact (the living file's lines 102 and 106 under 1.5); the old 26, 37, 40, 38 and 142 (git e0ba214) are steps 37, 51, 58, 52 and 254 now by their sentences, and step 52 has no Unsure line; the notes left out are said or gone: "changing of two signs" is at no line of the living file (line 86 has "the changing of two parities"), and + and − are the set's own writing (Natural_Intelligence_v380R.md 2.4, line 156, "written at + and −"; Exhibit_TWENTY_Natural_Naming_v380R.md 2.4, line 255, "*+* and *−* a sharing's parity"); *half* is released at Natural Naming 2.4 (line 272), and "half" is at no step of the Registry (searched); no paragraph names item 13.
SAFER: -

### 38
CHECK: OK
WHY: the quotation is exact (the living file's line 92 under 1.4); "either order" is at no line of Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md and its four steps with "explaining" (553, 554, 560 and 561) say nothing of a scale's next; the step offered is S12 word for word at cover_EQUILIBRIA.md line 151; no paragraph names item 16 or S12.
SAFER: -

### 39
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 40
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 41
CHECK: OK
WHY: the three quotations are exact (the living file's line 116 under 1.5 and line 201 under 3.3) and the table's column "Its five" has "co bi co bi co" (line 112); the old 46, 55, 58, 141 and 146 (git e0ba214) are steps 70, 82, 91, 250 and 263 now by their sentences, none with an Unsure line, step 263 with "co bi co bi co at a self's odd" still; *half* is released at Natural Naming 2.4 (line 272); "1 to 6" is in NEW; no paragraph names item 19.
SAFER: -

### 42
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 43
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 44
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 45
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING

Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_2.txt and the PROPOSED file EQ_2_report.md; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (542 lines, 12,261 words, each line).

Read in part: the mate carry/Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md at lines 1 to 259 (its front, its `## Insertlets`, and the older `## Droplets` from its first paragraph through the rows of the map, the two paragraphs "Steps carrying the most" at lines 231 and 233, and the paragraphs after them) and its headings to the end; carryings/co_chaining_map_v376/cover_EQUILIBRIA.md lines 1 to 45 (its header, its numbers, Table A §1 whole) and lines 125 to 175 (the proposed steps S1 to S28c); carryings/rings_are_spirals_v377/README.md section 5; archive/session_v379/Session_Report_v379.md findings 6 to 15 and 18 to 25; carryings/v380L/Progress.md at each line naming this file, line 232 whole; archive/carrying_v381R/Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380R.md from its opening to concern 3; carryings/co_chaining_coverage_v378/readings/05_hard_problems_and_equilibria.md lines 1 to 12; kits/Living_File_Registry_TWENTY-SIX_Improving_Kit/check_set.py lines 55 to 95; the instruments' opening lines at carryings/equilibria_registry_v377/executions/. Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md (33,825 words) was never read whole: each step a block names was read at its line with its Adding line (2, 3, 27, 37, 46 to 48, 51, 52, 58, 63, 65, 70, 75, 82, 84 to 88, 91, 99, 103, 105, 122, 143, 144, 186 to 188, 243, 250, 254, 263, 299, 300, 347, 372 to 374, 459 to 468, 623), each of its lines with "Unsure" was listed, and each of its steps with "universe" and with "explaining" was read. Natural_Intelligence_v380R.md at 2.4 (line 156) and 4.10 (line 1000); Exhibit_TWENTY_Natural_Naming_v380R.md at 2.4 (lines 255 and 272) and 4.9 (line 609); Exhibit_TWENTY-NINE_Natural_Illustrating_v379.md at 2.7 (line 240); Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md at 4.4 (line 172).

From the repository's history, by reading alone: the Registry of 264 steps (git e0ba214), each step and each Unsure line a row names, laid beside the step of the same sentence now; this file at version 375 (git ff6cdd6) for lines 123, 214 to 219 and 327; at version 377 (git e4b5b42) for lines 80, 182 and 252; at version 368 (git bdf5ef1) for the two sentences of paragraph 21; at version 380R (git da7e3c2) for the sayings at a carrying of none before the working of version 380L.

Checked by exact search: each quotation of each NEW paragraph, thirty-two in all, in the living files at the root, each found at the file and the section NEW names; each EVIDENCE sentence of the four RESOLVED blocks in the living file it names; "membrane", "separable", "co-bi-coupling", "cube", "Rubik", "two knowings", "slightest", "the code" and each "line" with a number in the living file; "slowing", "slower", "either order", "half", "further occurrence" and "coverage" in the Registry; "cubing supplies" and "slightest tipping" in each file at the root. For each RESOLVED block, and for each RESAY whose row's number or key leaves, the mate and carry/*.md were searched for a pointer: "item" with each number, each S key (S1, S2, S3, S4, S7, S8, S10, S12), "cover_EQUILIBRIA", "the concern at this mate of", "the droplet at this mate of", "existing concern", "current droplet", "above", "below", "the preceding", and links into this mate; the links found are each to a section headed v385A or to the file whole, none to a paragraph of this portion, and of this map's items carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md names 41 and 49 alone, neither in this portion. Each NEW paragraph was laid beside its prior clause by clause; its length (68 to 146 words) and the first reader's word list were checked by a script, the one listed word found, *half*, being a living file's own word cited in italics.

Earlier second readings were read for the kinds of objection made and for the twin of paragraph 16: NN_1_harm.md block 6 and EQ_4a_harm.md whole, RR_1_harm.md and HP_1_harm.md in part.

Not settled here: the eighteen blocks the first reader left as KEEP were not read for a better verdict, as the brief has it. At 19 the source's "2.4" for one of the four sayings at a carrying of none is at no saying of the living file's 2.4; the sayings are at 1.3, 3.4 and 5.4, and the source keeps its own word at carryings/v380L/Progress.md line 232, so the leaving out loses nothing of the living file. At 29 the Registry's step 467 names inseparating of two, neither in the other, and the living file's sentence has it of a self and its momentaries; the row asks only that the name be at a step, which it is. At 16 "one name of 1 to 8" and "two of the ten at each" are no words of the prior; each is a living file's own sentence of the same parting (Natural Illustrating 2.7; this file's 3.3), and the twin at Offerings to Natural Naming has the same. At 17 the script was not run: its present notes at lines 80, 182 and 254 rest on its rule as read and on a search of the file.
