### 209
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 210
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 211
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 212
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 213
CHECK: OK
WHY: laid beside the prior and its source, carryings/illustrating_v366/Session_Report_v366.md line 167 under "## 8. Receiving next" ("| TWENTY-EIGHT | Receive the boundary/bounding visual ambition with the exact continuing still to demonstrate |"): "visual", "exact", "still to demonstrate", the receiving file and the section are each in NEW at the same strength, nothing of a living file is added, NEW has no quotation, and the path is the place now (incoming/ has no illustrating_v366; carryings/illustrating_v366/ has the file); the work is not made at the living file (no sentence of a declared boundary at the Equilibria Registry, read whole) and no paragraph of carry/*.md points at it (searched "boundary/bounding", "boundary and bounding", "Receiving next at TWENTY-EIGHT").
SAFER: -

### 214
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 215
CHECK: OBJECT
WHY: One named place is laid on a claim it does not have. NEW's last sentence says "That session's Next, at Opportunity 1 and Exploring 4, has the Equilibria Registry's Part THREE among what The ten and the six as one table reads whole." Read at carryings/v381F/v381F/Next.md: Exploring 4 (line 35) has it, "read whole beside TWENTY-TWO's front, TWENTY-EIGHT Part THREE, the Geodesic Improving Method 2.7 and Natural Intelligence 1.4"; Opportunity 1 (line 23) is "The ten said at the five, at Resolving the Hard Problem Registry and the Equilibria Registry … the v377 cohering report the material" and says nothing of Part THREE or of the one table. Opportunity 1 is a place of the resolved saying, which NEW gives to Session Report part 4.3, Finding 16 alone. The prior gives its four places at its close for the whole paragraph and assigns none to one clause, so NEW adds an assigning the prior has not, and one half of it is untrue of the source. The rest was checked and is sound: "each at its two names eight apart" is exact at Exhibit_TWENTY-TWO_Resolving_the_Hard_Problem_Registry_v375.md line 13 (the front); the Geodesic Improving Method 2.7 has "is met at six binaries, the rigorizer" (line 192); Natural Intelligence 1.4 has the five (line 99); the Equilibria Registry is at v380L and its part THREE is "THE TEN, FIVE PLACES AT TWO FACES"; Session Report v381F lines 111 and 113 have Finding 16 and the resolved saying under 4.3; no paragraph of carry/*.md points at this one.
SAFER: **Droplet · The ten, the six and the five, one subject at three files.** It is aimed at Exhibit TWENTY-EIGHT Equilibria Registry. The Equilibria Registry at v380L says the ten, with the front of Exhibit TWENTY-TWO Resolving the Hard Problem Registry, while Exhibit TWENTY-FOUR Geodesic Improving Method 2.7 says six and Natural Intelligence 1.4 five: one subject at three files. The ten were named at the old code, "each at its two names eight apart", a form of the old code named still. Session v381F has this resolved: each of the ten is said at the five at the two registries' own motions, the cohering report of version 377 the material; and the Equilibria Registry's Part THREE is among what The ten and the six as one table reads whole. Its places are Session Report v381F part 4.3, Finding 16, and that session's Next, Opportunity 1 and Exploring 4.

### 216
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 217
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 218
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 219
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 220
CHECK: OBJECT
WHY: A reading and a relation of the prior are at no living file. The four EVIDENCE sentences are exact at Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md (lines 100, 156 and 231), and Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md has no "rest" and no "round" (searched), so the sentence laid there, "Which is a round named as a rest" (archive/carrying_v375_resolving_hard_problems/Resolving_Hard_Problems_v368_Released_Whole_v375.md line 395), is gone. Two things are left unsaid. First, the reading itself: no living file says an equilibrium is a round read as a rest (searched "as a rest", "round read", "named as a rest", "read as a rest" at each file of the root: the Co-Chaining Logic Registry's step 62, "The same round read from next to prior is the other order", is another saying, and the Living Ghost Registry's "installed as a rest" has no round). The Registry's sentences say that a match at next is a further occurrence and that a spiral of selves at rest comes to rest at no coupling; none names the equilibrium as that round read as a rest, and the first reader says so in its own EVIDENCE. Second, the relation "for both to agree": the agreeing is both's, and no living file and no later section has this pattern agreed or opened for agreeing (carryings/v368_sources/Carry_Set_v368_README.md line 108, "Patterns laid for both to agree"); a like paragraph is carried on at a later section of this mate, "## The older and newer ten and their unresolved correspondence · v385A", opening "For both to agree", and at carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md "Droplet · The namings open for both to agree", so the relation is one the mates carry and do not release. No later section has the pattern: "Droplet · A completing, and a closing" (v386EOD) has "One form reached at next erases no next" and no rest, and "Droplet · An equilibrium as a rest, three neutrals fixed" (v386EOD) has the rest and no round. The same paragraph is at 235, and both have this check.
SAFER: KEEP

### 221
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 222
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 223
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 224
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 225
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 226
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 227
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 228
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 229
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 230
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 231
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 232
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 233
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 234
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 235
CHECK: OBJECT
WHY: The same paragraph as 220 with one re-aiming note more, and the same objection: the sentence laid at Resolving Hard Problems is gone (no "rest" and no "round" at Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md), and the three EVIDENCE sentences are exact at the Equilibria Registry (lines 100 and 231), but the reading, an equilibrium as a round read as a rest, is at no living file in any wording that names the equilibrium so (searched at each file of the root), and the relation "for both to agree" is at no living file and at no section headed v385A or v386EOD. Released, both copies of the pattern leave this mate, and no copy is at another mate (searched "round read as a rest" in carry/*.md: lines 491 and 521 of this mate alone).
SAFER: KEEP

### 236
CHECK: OBJECT
WHY: NEW changes the strength of each claim, and the form it is put in denies what the living file has. The prior says in plain indicative that the Equilibria Registry is numbered and has the exclusions, that its tables of 63 are whole and that its version line has the title; NEW puts all five items under "Possible project" and closes "It may change or never be made." Read at the living file whole, four of the five are made: sections numbered 1.1 to 5.5; "Four proof groups carry the exact local exclusions." at 5.1; "The sixty-three arrivals, forty-two proposed conceptions and twenty-one specified accounts and prior definitions" at 4.2; the version line "Exhibit TWENTY-EIGHT Equilibria Registry v380L". So NEW says of four made things that they may never be made, and the form itself is for work proposed and not done. NEW also adds beside the prior: "An earlier plan" in the title and "A plan made at version 373"; the prior has the place (Re-Settling the Living Files, §6) and its label and does not call itself a plan or earlier (the source does, carryings/resettling_v373/Re-Settling_the_Living_Files.md line 24, "a first draft of a re-settling plan", session v373; the prior is no one-line pointer, so rule 4 gives no leave to bring that in). The same paragraph is twice more in this section, at file lines 243 and 537 (paragraphs 96 and 243), and each of those readers gave KEEP (EQ_3_report.md, EQ_8_report.md; EQ_8_harm.md has 243 unchanged), the first writing "the three want one verdict"; re-said here alone, one copy of three parts from the other two and nothing is gained. What was checked and found sound: the words are line 181 of the source exactly; §1 and §5 are the registry's first and fifth parts at version 371 ("1 · Existing through momentaries", "5 · Shared exclusions, run at the code", read at the repository's history, commit f50cc74), part ONE and part FIVE now; no number, place or negation of the prior is missing from NEW; the pointer at this mate's line 553, "keeps this later plan beside the older resettling and existing local offerings", finds the paragraph either way.
SAFER: KEEP

## READING
Read whole: the brief HARM3.md; the first reader's brief BRIEFO3.md with its further rules; the PRIOR file EQ_7.txt, paragraphs 209 to 236; the PROPOSED file EQ_7_report.md, each block and its READING; the living file Exhibit_TWENTY-EIGHT_Equilibria_Registry_v380L.md, each of its 541 lines; and the mate's later sections from line 565 to line 681 (each section headed v385A and v386EOD to "The opposition conception SA01").

Five blocks are not KEEP and each was checked by reading and search, never on the EVIDENCE line alone: 213, 215 and 236 (RESAY), 220 and 235 (RESOLVED, one paragraph twice). The twenty-three KEEP blocks are unchanged.

Read at the places named: carryings/illustrating_v366/Session_Report_v366.md at "Boundaries and living bounding" and "## 8. Receiving next" (213); carryings/v381F/v381F/Session_Report_v381F.md lines 87 to 113 and Next.md lines 23, 35 and 54 (215); carryings/v368_sources/Carry_Set_v368_README.md lines 55 to 112, and the archive's line 395 at archive/carrying_v375_resolving_hard_problems/ (220, 235); carryings/resettling_v373/Re-Settling_the_Living_Files.md lines 1 to 30 and 175 to 181, and the registry at version 371 at the repository's history for its part headings (236); carry/Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md "## Illustrating contributions and their particular destinations · v385A" (213); this mate's line 553 (236).

Checked by exact search: "each at its two names eight apart" at the root (Exhibit TWENTY-TWO's front, line 13, alone); "six binaries" and "## 2.7" at Exhibit TWENTY-FOUR Geodesic Improving Method; "## 1.4" at Natural Intelligence v380R; "rest" and "round" at Exhibit THIRTEEN Resolving Hard Problems v380L (none); "as a rest", "read as a rest", "named as a rest", "round read" at each file of the root and in carry/*.md; "pattern laid", "patterns laid", "for both to agree", "round read as a rest", "boundary/bounding", "boundary and bounding", "Receiving next at TWENTY-EIGHT", "one subject at three files", "The Equilibria Registry is numbered and holds", "resettling" in carry/*.md for pointers and copies; and the other readers' blocks for paragraphs 96 and 243 at EQ_3_report.md, EQ_8_report.md and EQ_8_harm.md. Each NEW was measured: 56, 145 and 122 words, none with a word the first reader's brief withholds outside a file's own italics; the SAFER paragraph at 215 is 149 words.

Numbers: OK 1 (213); OBJECT 4 (215, 220, 235, 236); KEEP-UNCHANGED 23. No file of /home/claude/corus was edited; this report is the one file written.
