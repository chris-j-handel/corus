# Task for a first reader of one portion

Your message names a portion tag, for example PH_1. Every path here is under
/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/older/ unless it begins with /home/claude/corus.

1. Read the brief BRIEFO3.md whole, including its section "Further rules", and follow it exactly.
2. Your input file is <TAG>.txt. Its first three lines name the mate (under /home/claude/corus/), the paragraphs of that mate's older `## Droplets` section it holds, and the living file (at the root of /home/claude/corus). Then one `### n` block for each paragraph, numbered within the whole section.
3. Read the living file whole first if it is under 15,000 words; otherwise read the sections each paragraph names and search the rest. Never read a file over 60,000 words whole.
4. Read the mate file's later sections (headed `· v385A` and `· v386EOD`) before giving any verdict, since they say many of the same things in the present naming. Other living files are at the root of /home/claude/corus; the archive at /home/claude/corus/archive/ and the older reports at /home/claude/corus/carryings/ hold the sources of one-line pointers.
5. Write your report to <TAG>_report.md in the brief's exact form, one block for each paragraph of your input, with the paragraph's own number. Do not edit any other file, and do not edit anything in /home/claude/corus.
