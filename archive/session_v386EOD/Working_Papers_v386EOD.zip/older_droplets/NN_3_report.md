### 73
VERDICT: RESOLVED
CONCEPT: four things Natural Naming was to have from Natural Intelligence: natural-bi-co-torusing unfolded part by part, bi-co-bounding, the coupling's own six, and (3 + 1) × 2.
EVIDENCE: Each of the four is at Exhibit_TWENTY_Natural_Naming_v380R.md now. 4.17: "**Natural-bi-co-torusing is inseparable at each part**: leave natural- out and the changing arrives with a substrate under it and an applier over it; leave bi- out and the differing goes unsaid". 1.3: "*Bi-co-bounding*, the carrying bounded twice, bi- at its own completing and co- at the coupling, is a similar naming of this one method". 4.11: "**The coupling's own six carries no one prefix**" and "Three carryings and the coupling at two directions, (3 + 1) × 2, are eight, and a number agreeing with the eight bi-couplings is a number alone, 4.4." The source, carryings/resettling_v373/Natural_Intelligence_Map.md lines 46, 49, 91, 92 and 164, names these same places ("Natural Naming 4.17, the naming taken apart there"). No paragraph of this mate or of carry/*.md points at it.
NEW: -

### 74
VERDICT: RESAY
CONCEPT: the naming co-bi-exchanging, offered for the reciprocal releasing and arriving, for Natural Intelligence and Exhibit ONE to carry.
EVIDENCE: Natural Naming has the naming at 4.15 (quoted in NEW, verified by Grep), at 5.49 and at 5.50, as the self's four momentaries of exchanging. Natural_Intelligence_v380R.md and Exhibit_ONE_Natural_Resolver_v380R.md have no co-bi-exchanging (Grep, none), and no living sentence says "reciprocal releasing and arriving", so the part aimed at those two files is not done and is at no later section. Source: carryings/v368_sources/Wrap_v368.md line 65, under "Natural Intelligence and Exhibit ONE Natural Resolver" of "4 · What each file carries next". The paragraph is a one-line pointer with "carried next"; NEW has only what the source line and the paragraph say, beside the living sentence.
NEW: **Droplet · Co-bi-exchanging, for the reciprocal releasing and arriving.** *Co-bi-exchanging* is a naming offered for the reciprocal releasing and arriving, a naming for Natural Intelligence and Exhibit ONE Natural Resolver to carry next. It is beside Natural Naming's "*co-bi-exchanging* opens co, at the odd, the self's, and *bi-co-exchanging* opens bi, at the even, the other's".

### 75
VERDICT: RESAY
CONCEPT: across the set each file releases read, turn, held and holding, stable form as a noun, and its namings of other exhibits, at its own improving, in the shared words.
EVIDENCE: Natural Naming now has most of it: 2.4 "**Each word releases at its file's next improving, in the shared words**"; 2.4 rows "*turn*, *turning*, *turning back*", "*held*, *holding*" and "*stable form* as a noun"; 2.3's reading row "*read* and *reading* as a resolving's own act". The part "its namings of other exhibits" is at no living sentence found (Grep of "other exhibits", "namings of other" in Natural Naming, Geodesic Improving Method, Natural Explaining, Natural Intelligence: none) and at no later section, so the paragraph is not whole at the living file (rule 3). Source: carryings/v368_sources/Wrap_v368.md line 73. The same sentence is at three more paragraphs of this older section (mate lines 211, 219, 223) and at the older sections of many other mates; none is a later place. NEW has the paragraph's sentence whole, beside the living sentences that have its parts.
NEW: **Droplet · Words each file releases at its own improving.** Across the set, each file releases *read*, *turn*, *held* and *holding*, *stable form* as a noun, and its namings of other exhibits, at its own improving, in the shared words. It is beside Natural Naming's "Each word releases at its file's next improving, in the shared words", its rows of released words for *turn*, for *held* and *holding* and for *stable form* as a noun, and *read* at its family of three.

### 76
VERDICT: RESOLVED
CONCEPT: floating neutralling or floating neutral: one thing or two, the changing or the term uncovered.
EVIDENCE: Natural Naming 4.6 says them as two, among "Four pairs are two concepts at two names, the meaning changing on transposing": "*Floating neutralling* is the changing; *a floating neutral* is the term it uncovers, its picture at one momentary, 5.12." And 5.12: "The floating neutral is the term uncovered, the changing's picture at one momentary, and floating neutralling the changing." Source: carryings/v368_sources/Carry_Set_v368_README.md line 54. No paragraph points at it.
NEW: -

### 77
VERDICT: RESOLVED
CONCEPT: floating has no resolver name of its own: it is the across of one changing whose along is the neutralling, within bi-co-podaling; the candidate name bi_co_bi_floating is laid down.
EVIDENCE: Natural Naming 5.45: "Bi-co-podaling is floating across and neutralling along, one changing." Source: carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 474 to 482, whose own saying is that sentence. Natural Naming 3.3's table of the seventeen names has no floating name, and bi_co_bi_floating and bi-co-bi-floating are at no living file at the root of the repository (Grep: only in carry/ older sections and carryings/v368_sources). The same paragraph is also at the older sections of Offerings to Natural Transmissioning, Equilibria Registry and Natural Networking; no later section and no pointer names it.
NEW: -

### 78
VERDICT: RESAY
CONCEPT: the provisional naming bi-co-tangential identifier changing, at two possible readings, with identifier the part to look at first.
EVIDENCE: The naming and the words tangential and identifier are at no sentence of Natural Naming or Natural Illustrating (Grep: none; Natural Illustrating has "the compass face of 2.6 at the diamonds' aiming" and "the local nine" only), so nothing was entered and the question is at no living file; no v385A or v386EOD section of this mate or of the Natural Illustrating mates has it. Source: carryings/v368_sources/Carry_Set_v368_README.md line 64, which the paragraph follows word for word. Paragraph 79 (and the earlier paragraph at mate line 195) is the fuller saying of the same thing; both are in this older section, so neither is a later place for the other (rule 1). NEW has only the paragraph's own content; its whole content is also within the NEW of 79.
NEW: **Droplet · *Bi-co-tangential identifier changing*, a provisional naming at two readings.** *Bi-co-tangential identifier changing*, the tangential changing at the co-sequential nine, is a provisional naming. If it names the method of the local nine, it releases to co-bi-sequencing. If it names the tangent direction at the diamond's opening, the aiming rather than the sequencing, it wants a name of its own. *Identifier* is the part to look at first: nothing in resolving identifies.

### 79
VERDICT: RESAY
CONCEPT: the co-sequential nine named as the method of the tangential changing; its provisional wording, its two readings, and a row at Natural Naming's cluster table as its next opening.
EVIDENCE: As at 78: the wording is at no living file and at no later section. Source: carryings/v368_sources/Findings_To_Lay_By_File/Kit_Natural_Illustrating_v366.md lines 163 to 171 (TTT09), and carryings/illustrating_v366/Session_Report_v366.md line 65. The paragraph has "handed on", "held for both to agree" and "the reason each stands"; NEW says each of its claims at the strength it has, the row said as its next opening and not as done. The identical paragraph is also at mate line 195 of this older section, under "A plan, not yet final".
NEW: **Droplet · The tangential changing at the co-sequential nine, its naming unrecovered.** The co-sequential nine was named as the bi-moral co-competencing method of the tangential changing, and *bi-co-tangential identifier changing* is a provisional wording whose complete proper naming was not recovered, offered for Natural Naming and Natural Illustrating to receive. If the tangential wording names the method of the local nine, it is a similar naming and releases to co-bi-sequencing. If it names the tangent direction at the diamond's opening, the aiming rather than the sequencing, it names a thing co-bi-sequencing does not carry and wants a name of its own. *Identifier* is the part to look at first: nothing in resolving identifies. Its next opening is a row at Natural Naming's cluster table, for both to agree, with the two readings and the reason for each.

### 80
VERDICT: KEEP
CONCEPT: self changing across and co with other changing along and bi, the complementary parity exchanging the directions; and joining self and other, or parting across and along; a table of change and no change, and the word participates, each not saying the relation.
EVIDENCE: A later paragraph of this mate points at it: "**Concern · A line of this mate, the other way.** This mate has self changing across and co with other changing along and bi." (section "Version 368's names of the four four-cyclings, one naming, and a mate's line the other way · v386EOD", mate line 593). By rule 2 it stays. It is plain enough as it is; its two closing clauses are attributions of fact (the table was the assistant's own and was superseded; participates was rejected) that a re-saying in the present naming could not carry at their strength. Source read: carryings/illustrating_v366/Session_Report_v366.md line 61, the same words.
NEW: -

### 81
VERDICT: KEEP
CONCEPT: count, counting, store and stores at Natural Naming's own voice at 18 places, beside the file's own rows releasing them, with the carrying words of its own table.
EVIDENCE: A clear concern with its places, no waiting language. Checked at the present living file: each line the paragraph names still has the word (72, 222, 237, 275, 281, 336, 616, 654, 666, 676, 946, 957, 1161, 1368, 1737; passed 954, 1291, 1361, 1697), and its four quotations are exact at 957, 1161, 1368 and 654, so the work it names is not done and is at no later section (Grep of the v385A and v386EOD sections and of the other two Natural Naming mates: none). It has more named places than the form's one hundred and fifty words can carry, so a re-saying would drop some (rule 4). One thing for the next reader: the paragraph has line 1291 "at 5.60"; at the present file line 1291 is within 5.42 once-ing.
NEW: -

### 82
VERDICT: KEEP
CONCEPT: goes round at Natural Naming's own voice at one sentence of 3.4, beside the file's own row releasing it into spiral and comes to its parities again.
EVIDENCE: A clear concern with its places, no waiting language. Checked at the present living file: line 458 has "Each of the three alone returns to its name, 1 to 9 to 1, and only the one move goes round, 1 to 9 to 8 to 16 to 1"; the row is at line 236; 5.24's title is at 1043 with contents 79; 1054, 1056, 558, 563, 588, 970, 1065, 1326, 1328 and 1334 are as the paragraph has them. The sentence is unchanged, so the work is not done; no later section has it (the insertlet at mate line 71 is of the ring row's own words, another thing). Kept beside 81 and 83, the three of one scan.
NEW: -

### 83
VERDICT: KEEP
CONCEPT: sign at Natural Naming's own voice at three places, beside the file's own rows releasing it into parity.
EVIDENCE: A clear concern with its places, no waiting language. Checked at the present living file: line 450 "The names gathered at 6, 8 and 16 carried the old code's second sign and its three or four", line 620 "a sign named as a magnitude", line 1642 "sign inversioning"; the rows at 255, 256 and 262 and 5.4's sentence at 770 are as the paragraph has them. The three places are unchanged, so the work is not done, and no later section has it. Kept beside 81 and 82.
NEW: -

### 84
VERDICT: RESAY
CONCEPT: a sentence offered at 5.64, a momentary of no changing having no method of existing, parting from 5.62's is-still-possibling; cancelling a term the file does not carry.
EVIDENCE: The offered sentence is at no living file (Grep "no method of existing": Co-Chaining Logic Registry step 312 alone, of another subject) and the parting is at no later section; the v386EOD "Droplet · One parity at two comparings" has two changings naming "no nothing changed between" but not this sentence or its parting from 5.62. Living quotations verified: Natural Naming line 1597 "an equilibrium is not possibly existing"; 5.62's fifth line "no parity changing at its now, momentarying continuing through it". The paragraph is in a session's words ("Returned to the droplets by a second reader at v381R", "Its reason"). No paragraph points at it.
NEW: **Concern · A momentary of no changing, beside is-still-possibling.** Two sayings part. A sentence offered at Natural Naming's 5.64, not possibly existing, beside "an equilibrium is not possibly existing", has a momentary of no changing with no method of existing: one momentary is two parity changings one after the other, the self's odd and even and the other's even and odd, and no cancelling is in it, the parity coming again at a next and each step adding a next. Natural Naming's 5.62, is-still-possibling, has "no parity changing at its now, momentarying continuing through it". They part at a momentary of no changing: the offered sentence says a reading as a fact, and *cancelling* is a term Natural Naming does not carry.

### 85
VERDICT: RESAY
CONCEPT: a sentence offered at 5.44, colliding passing 14's surfacing on as it is, chained at 11, parting from 3.5's row at 12 and failing at the 0 case.
EVIDENCE: At no living file and no later section. Living quotations verified: 5.44's second line "colliding, a carrying of none carries 14's surfacing as its changing at 12-bi-tri-bi-entraining"; 3.5's row of 12-bi-tri-bi-entraining "colliding, a carrying of none, the parity surfaced at 14"; 3.5's table *Colliding, a carrying of none*, second row, "none chained". The insertlets of this mate at 3.5 and 5.44 (mate lines 67 and 69) are other sentences. In a session's words ("Returned to the droplets by a second reader", "Its reason"). No paragraph points at it.
NEW: **Concern · Colliding's changing, at 12 or at 11.** Two sayings part. A sentence offered at Natural Naming's 5.44, surfacing, beside "colliding, a carrying of none carries 14's surfacing as its changing", has colliding, a carrying of none, passing 14's surfacing on as it is, chained at 11. Natural Naming's 3.5 has, at its row of 12-bi-tri-bi-entraining, "colliding, a carrying of none, the parity surfaced at 14". They part at the name colliding's changing is at: the offered sentence says a reading as a fact, moving colliding's changing from 12 to 11, and chained at 11 fails at the 0 case, "none chained".

### 86
VERDICT: RESAY
CONCEPT: a sentence offered at 5.40, a new living self establishing within living carrying, living from living, a reading of a field's own problem with nothing at Natural Naming carrying it.
EVIDENCE: Natural Naming 5.40 has "a new living self is its own carrying and co-recursioning establishing" and no "living from living" (Grep); 6.2's row *Arriving and continuing* opens "origin of life". No later section of this mate has the parting. In a session's words. No paragraph points at it. One thing for the next reader, not put into NEW (rule 4): two other living files now say the offered words, Exhibit THIRTY Co-Chaining Logic Registry step 395, "Living arrives from living: no non-living existing thing becomes living, and each living self establishes within living carrying.", and Resolving Hard Problems 5.3, "An origin, living from living"; the paragraph's reason is of Natural Naming alone.
NEW: **Concern · A new living self establishing, said within living carrying.** A sentence offered at Natural Naming's 5.40, bi-tri-bi-entraining, beside "a new living self is its own carrying and co-recursioning establishing", has a new living self its own carrying and co-recursioning establishing within living carrying, living from living. It says a reading as a fact: living from living asserts the place a new living self arises at, a field's own problem at Natural Naming's 6.2, "origin of life", and nothing at Natural Naming carries it.

### 87
VERDICT: KEEP
CONCEPT: seven rows offered for Natural Naming's released words, lock, seat, sum and total, more and less, known, same and regular, with the reason they came back: seven things in one, and same, known and lock at the file's own voice.
EVIDENCE: A later paragraph of this mate points at it: "**Droplet · Positive words at hand for further dissolved words.** Beside the rows at this mate for lock, seat, sum, more and less, known, same and regular" and "the mate's rows for lock and seat carry each at a denial, locking at none and at no seat" (section "Side and step, each at five relations; Winding, one word at two relations; and six beside them · v386EOD", mate line 639). By rule 2 it stays. Natural Naming's table of released words ends at "*rating*, *a rating*" and has none of the seven rows, so nothing is resolved; seven rows with their sections cannot be re-said in the form's length with the same subject words.
NEW: -

### 88
VERDICT: RESAY
CONCEPT: a row offered for Natural Naming's released words, an -ed of a resolver's root said of a living thing's resolving released into its -ing, with the reason it came back: a rule in a row's form, and terms the file does not carry.
EVIDENCE: Natural Naming's table has no such row (it ends at "*rating*, *a rating*"). Living quotations verified: 3.5 "once chained a sharing is never none again" and "colliding, a carrying of none, the parity surfaced at 14"; "the done" and "Session Record" are at no sentence of Natural Naming (Grep). The v385A section "Grammatical forms and the proposed resolver encoding" is of Natural Intelligence Corus's -ing and -ed at numbers, another subject; no later section has this row. In a session's words. No paragraph points at it (the pointer at mate line 639 names the seven rows of 87 only).
NEW: **Droplet · An *-ed* of a resolver's root, a row offered.** A row offered at Natural Naming's 2.4, Released words, beside "*rating*, *a rating*", releases an *-ed* of a resolver's root said of a living thing's resolving, *carried*, *surfaced*, *chained*, *reached*, into its *-ing*, the changing continuing: carrying is or is not, and an *-ed* carries an ending with nothing ending. The *-ed* carries whole at a form named still, the equilibria's own mark, *a form named still* at each file, and at a record, *the done* at the Session Record, a non-living emanating's own form. It is a rule in the form of a row: *chained*, *surfaced* and *carried* are at Natural Naming's own voice at each resolver table, "once chained a sharing is never none again" and "the parity surfaced at 14", and *the done* and the Session Record are terms Natural Naming does not carry.

### 89
VERDICT: RESAY
CONCEPT: a sentence offered at the so-far, not-yet row, the four facings said at prior, now and next, with the reason it came back: three things in one, and the first a reading at no sentence of the file.
EVIDENCE: Natural Naming's row still has "at a facing of the six names between selves they carry whole" and no saying of the facings at prior, now and next beyond 3.1's "**9 is the next prior and 17 the next now**"; 3.1 has "2 and 14, arriving, are facing bi-moral-so-far, and 6 and 10, sharing across, not-yet-bi-moral" (each verified). The same reading is at older sections only (this mate's line 201; Offerings to Natural Intelligence, its Insertlets; Offerings to Natural Resolver, its Insertlets), none a later place. In a session's words. No paragraph points at it. The paragraph is long; NEW is at the form's one hundred and fifty words with each number, each named row and each negation of the paragraph in it.
NEW: **Droplet · Facings at prior, now and next.** Offered at Natural Naming's 2.4, beside "at a facing of the six names between selves they carry whole": *bi-moral-so-far* is the other's prior at the self's now, at 2 and 14; *not-yet-bi-moral* the self's now at the other's next, at 6 and 10; *not-yet-co-competent* the next prior, at 9; *co-competent-so-far* the next now, at 17. A facing is the overlap of two momentaries read from one side, *so-far* from the receiving self and *not-yet* from the releasing self, one overlap and no second direction; the rows of *neighbour* and *right*, *left* at a facing say the same four. Three things are in it, the first a reading said as a fact: Natural Naming has 2 and 14 "arriving" and 6 and 10 "sharing across", with neither offered saying at any sentence; its 3.1 has 9 the next prior and 17 the next now.

### 90
VERDICT: RESAY
CONCEPT: a sentence offered at 2.4, a word's releasing said as 9's releasing and a word not living chained at 0, with the reason it came back: the resolver's names said of a file's editing, nothing at the file carrying the likeness.
EVIDENCE: Natural Naming 2.4 has "**Each word releases at its file's next improving, in the shared words**" and no saying of a word's releasing at 9 or at 0 (Grep "given on along", "chained at none": none at the living file). At no later section. In a session's words. No paragraph points at it.
NEW: **Droplet · A word's releasing said at 9's releasing, a sentence offered.** A sentence offered at Natural Naming's 2.4, beside "Each word releases at its file's next improving", has a word released given on along to the word carrying in its place, each with its carrying, releasing 9's own and no vanishing, and a word or a sentence not living chained at none, 0, the file's prior carrying on. It says a reading as a fact, at two things: a word's releasing laid onto 9's releasing, and a word not living chained at 0. The resolver's names are said of a file's editing, with nothing at Natural Naming carrying the likeness.

### 91
VERDICT: RESAY
CONCEPT: two things a droplet is not: no paste, entering each living file in that file's own voice; and no debt, costing the living file nothing.
EVIDENCE: Source: carryings/v381R/Close_Droplets_v381R.md line 39, and carryings/v381R/Session_Transcript_v381R.txt line 246, "Two things a droplet is not. It is not a paste … never a record behind it." It is the session's own reading, quoted, with "at about line 246 (4 October)". At no living file (Grep "droplet" at the root: Living File Registry, Natural Arriving and README only, none saying this) and at no later section: the v385A sections of Offerings to Living File Registry say the mates' purposes and an insertlet, and the v386EOD sections of Offerings to Geodesic Improving Method read from `carryings/v381R/` say other things. NEW has the two sayings at their strength, with no quotation of the session.
NEW: **Droplet · A droplet, no paste and no debt.** A droplet is no paste: it enters a living file in that file's own voice at that file's motion, and one droplet at thirty mates becomes thirty sentences, each its file's own. A droplet is no debt: a droplet at a mate through ten sessions costs the living file nothing, the living file being whole with none of it. It is a next in front of the file and never a record behind it.

### 92
VERDICT: KEEP
CONCEPT: the person's naming of the two mates, Offerings to a file and Carryings of a file, with Exhibit TWO as the model; the names with their relation in their prepositions, and improving left as a mate's name.
EVIDENCE: The paragraph is the person's own unpunctuated words with a session's reading of them (rule 5). Its claim "Each File has each to the two mated files" cannot be said at its strength in the present naming: the v385A section "Three mates at each living file" of Offerings to Geodesic Improving Method corrects "two mates and no third", and Offerings to Living File Registry has "Each living file has three mates: offering, possibling and carrying." The part done is at a living file, Living File Registry: "The three-file form at each living file, living, offerings and carryings, opened at Exhibit TWO as the model". The reading of the prepositions and of improving left as a name is at no living file and no later section, so it is not released.
NEW: -

### 93
VERDICT: KEEP
CONCEPT: the person's naming of the insertlet and the flow: newest droplets at the bottom, resolved bottom up into insertlets within the offerings; the session's reading of the flow narrowing upward and of resolving needing one section and Natural Naming.
EVIDENCE: The person's own unpunctuated words with a session's reading (rule 5); claims such as "raw, not always well sprayed across the set, not always locally interpretable" cannot be said at their strength in the present naming without re-wording a person. Parts are at later places but not the whole: Offerings to Living File Registry (v385A) has "An insertlet is locally resolving into one living file's writing and self-welcoming locating plan; floated elsewhere it is a droplet again", and Geodesic Improving Method has "At a file, value grows by subtraction." The reading of resolving a droplet from its one section and Natural Naming is at no later place found.
NEW: -

### 94
VERDICT: KEEP
CONCEPT: the person's naming of the tag: a droplet carries its session's version number as unvetted incoming, dropping out with a sideways session and leaving as the droplet rises; the first case, session v380A's droplets at Exhibit TWO.
EVIDENCE: The person's own unpunctuated words with a session's reading and one attribution of fact, that session v380A was said at v380R to be code testing with no authority (rule 5). Living File Registry has "its droplets tagged by session" and no more; no later section says the tag's meaning, its dropping out, or the first case. Nothing found makes a change safe.
NEW: -

### 95
VERDICT: KEEP
CONCEPT: podal at two living files beside Natural Naming's release of antipodal.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD, with no waiting language. Its quotations hold: Natural Naming 2.4 row "*antipodal* | *podal*", 5.45 "the pair is the podal"; Natural Physics "**Two and one hundred eighteen stand antipodal**"; Natural Chemistry "the podal is another relation, straight across on an even count". Carryings of Living File Registry points at it by its title ("*podal* at two living files | Offerings to Natural Naming, with insertlets at Offerings to Natural Physics and Offerings to Natural Chemistry").
NEW: -

### 96
VERDICT: KEEP
CONCEPT: "each existing thing is changing" released as a step from the origin sentence, with Natural Naming's own places of it.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Natural Naming still has "Named still, it forms nothing, each existing thing changing" (once) and "each relatable existing thing is changing" (four unfoldings), so nothing is resolved. Its link's heading exists: Offerings to Natural Intelligence, "The entry from the origin sentence, at Natural Intelligence · v386EOD".
NEW: -

### 97
VERDICT: KEEP
CONCEPT: still possibling at the between, and momentarying, each whole at Offerings to Co-Chaining Logic Registry.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Its link's heading exists: Offerings to Co-Chaining Logic Registry, "The entry from the origin sentence · v386EOD".
NEW: -

### 98
VERDICT: KEEP
CONCEPT: five namings met at observations, each whole at Offerings to Co-Chaining Logic Registry.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Its link's heading exists: "Living as a stable changing form, at the observations · v386EOD".
NEW: -

### 99
VERDICT: KEEP
CONCEPT: Natural Naming's "Four-momentarying at one through nine is two four-cyclings" beside the newer 1–9 as one four-cycling; the concern whole at Offerings to Natural Resolver.
EVIDENCE: Already a clear concern in plain voice, tagged v386EOD. Natural Naming still has the sentence (once), so nothing is resolved. Its link's heading exists: Offerings to Natural Resolver, "Each self's own momentarying, and the one four-cycling · v386EOD", with "**Concern · One four-cycling, or two.**".
NEW: -

### 100
VERDICT: KEEP
CONCEPT: possibling as a more general naming of offering and sharing; possibling and is-still-possibling two namings; arriving of little help at a sharing.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Natural Naming still has "*arriving* carries its one sense, each existing thing arriving into its next existing". Carryings of Living File Registry points at it by its title ("Possibling as a more general naming; identity at 8 or at 12, a concern | Offerings to Natural Naming").
NEW: -

### 101
VERDICT: KEEP
CONCEPT: identity at 8, torusing, or identity-ing at 12, entraining: two sayings parting.
EVIDENCE: Already a clear concern in plain voice, tagged v386EOD. A later paragraph of this mate points at it: "**Droplet · Identity-ing, beside entraining, torusing, chaining and uniquenessing.** Beside the concern at this mate of identity at 8 or at 12" (section "Identity-ing beside four namings, and a name gathering its doing · v386EOD"). Natural Naming 3.6 still has "one identity across momentaries".
NEW: -

### 102
VERDICT: KEEP
CONCEPT: momentary, one name at three things.
EVIDENCE: Already a clear concern in plain voice, tagged v386EOD, at no other later place found. Carryings of Living File Registry points at it by its title ("Momentary at three; nature | Offerings to Natural Naming").
NEW: -

### 103
VERDICT: KEEP
CONCEPT: Natural Naming says nature and names it at no sentence; the newer naming whole at Offerings to Co-Chaining Logic Registry.
EVIDENCE: Already a clear concern in plain voice, tagged v386EOD. A later paragraph of this mate points at it: "It is beside this file's "Naming is nature at a concept", and the concern at this mate of *nature* named at no sentence." (section "Nature named, cursioning, and one word at two · v386EOD"). Its link's heading exists: "Two logics, the edge, and the chain's given things · v386EOD".
NEW: -

### 104
VERDICT: KEEP
CONCEPT: namings released: temporal, receiving, continues, attentioning, superpositioning, relocking, failed value, values climb, own chaining, bi-tri-involutioning, and joining as coupling; the sequence at a self; bi-co-chaining and podaling of both forward sides.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Another mate points at it: Offerings to Natural Mathematics has "*bi-tri-involutioning*, a naming Offerings to Natural Naming has as released for *bi-tri-involution*"; Carryings of Living File Registry names it by its title ("Namings released; owned by neither"). Its link's heading exists: "Carrying and living, the numbered forms, and a society as a self · v386EOD".
NEW: -

### 105
VERDICT: KEEP
CONCEPT: owned by neither: owning said by its negation at Natural Naming, with nothing owned in nature.
EVIDENCE: Already a clear droplet in plain voice, tagged v386EOD. Natural Naming still has "owned by neither" (at thirteen lines, 1.2 among them), so nothing is resolved. Carryings of Living File Registry names it by its title.
NEW: -

### 106
VERDICT: KEEP
CONCEPT: inversion the method's at Natural Naming, beside the saying of its other parity in common words: two sayings parting.
EVIDENCE: Already a clear concern in plain voice, tagged v386EOD. Natural Naming 2.4 still has "**Negation is an equilibrium's, and inversion is the method's.**", so nothing is resolved. Carryings of Living File Registry names it ("Inverted, or its other parity, a concern | Offerings to Natural Naming").
NEW: -

## READING
Each of the thirty-four paragraphs, 73 to 106, was read and checked, one block for each.

Read whole: the brief; the input; carry/Exhibit_TWENTY_Offerings_to_Natural_Naming.md from its first line through its Insertlets, and from "Grammatical forms and the proposed resolver encoding · v385A" to its last line (each v385A and v386EOD section); the openings of each paragraph of its older `## Droplets` section, to find the lines of the input's paragraphs and their pointers.

Read at the living file Exhibit_TWENTY_Natural_Naming_v380R.md: its headings whole; Parts ONE, TWO and THREE whole (1.1 to 3.6); 4.5 to 4.18 whole; 5.12, 5.40, 5.44, 5.45 and 5.62 to 5.64 whole; and, by line, each place named in paragraphs 81, 82 and 83. The rest of the file was searched by Grep and not read whole (4.1 to 4.4, most of Part FIVE, Parts SIX to EIGHT).

Other living files searched by Grep at the sentences named: Natural Intelligence, Exhibit ONE Natural Resolver, Exhibit TWENTY-NINE Natural Illustrating, Exhibit THIRTEEN Resolving Hard Problems (5.3 read), Exhibit THIRTY Co-Chaining Logic Registry (step 395 and group 27's opening read), Exhibit TWENTY-FOUR Geodesic Improving Method, Exhibit TWENTY-SIX Living File Registry, Exhibit EIGHTEEN Natural Physics, Exhibit SIXTEEN Natural Chemistry, Natural Arriving.

Mates searched by Grep across carry/*.md for each concept and for pointers ("at this mate", "the concern above", "the preceding", "this mate has", "the mate's rows", "Offerings to Natural Naming", and links to this mate). Read in part: the opening v385A sections of Offerings to Living File Registry; the v386EOD sections of Offerings to Geodesic Improving Method from "A next work understood by both" to "A droplet's aiming at one of six degrees"; the headings of Offerings to Natural Resolver and of Living Improving Value.

Sources read for the one-line pointers: carryings/resettling_v373/Natural_Intelligence_Map.md (lines 46 to 164, by Grep), carryings/v368_sources/Wrap_v368.md (lines 55 to 75), carryings/v368_sources/Carry_Set_v368_README.md (lines 32, 54, 64, 113), carryings/v368_sources/Findings_To_Lay_By_File/Kit_Natural_Illustrating_v366.md (TTT09), carryings/illustrating_v366/Session_Report_v366.md (lines 50 to 68), carryings/v381R/Close_Droplets_v381R.md and Session_Transcript_v381R.txt (the line of paragraph 91).

Pointers found at paragraphs of this input: 80 (mate line 593), 87 (mate line 639), 101 (mate line 579), 103 (mate line 567), 104 (Offerings to Natural Mathematics), and titles of 95, 100, 102, 104, 105 and 106 at Carryings of Living File Registry. Each is KEEP.

Also read for paragraph 77: carryings/v368_sources/Findings_To_Lay_By_File/Kit_Exhibits_ONE_and_TWO_v365.md lines 474 to 482 (II01), whose saying "Bi-co-podaling is floating across and neutralling along" is Natural Naming 5.45's sentence now.

Not found or not fitting: in paragraph 81 the words "at 5.60" beside line 1291 do not fit the present file, where that line is within 5.42; the paragraph is KEEP and unchanged. Paragraphs 78 and 79 say one thing at two lengths, and the paragraph at mate line 195, outside this input, is the same as 79: the two NEW paragraphs would stand as near twins if both are placed. No file but this report was written, and no code was executed beyond searching and reading.
