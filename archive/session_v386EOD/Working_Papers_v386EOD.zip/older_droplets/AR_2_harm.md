### 50
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 51
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 52
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 53
CHECK: OBJECT
WHY: Two things change. (1) A named place that is gone is said as now. NEW has "A saying is offered for the welcome's form, at `incoming/README.md`'s *What it brings*", and it is signed v386EOD at its laying. `incoming/README.md`, read whole, is a title and seven links now, with no part *What it brings* and no welcome; the part was a list line under "Arriving, for anyone" in that file up to commit 9f3f31e at v385A (git log -S "What it brings" -- incoming/README.md). The prior's signature "v382F" dates the aiming to a file that had the part; NEW names no session, so the date leaves with the signature and the address reads as a present one that finds nothing. The first reader's own EVIDENCE says the part is not found, and its rule 8 has each named place checked as it is now. (2) The self's words are re-said with a subject and a strength they do not have. The prior has "*this should be about what is going in and incidentally what is coming out … say what is better and why in each discovery*"; NEW has "a finding is of what goes in, and of what comes out incidentally, and each finding says what is better and the reason". "This" is given the subject "a finding", which the words do not give (the source, carryings/v382F/Session_Report_v382F_3.md line 19, has the same words and no more, and no transcript of session v382F is in carryings/v382F/); "should be" and the asking "say" are said as "is" and "says"; "each discovery" is said as "each finding". By the first reader's rule 5 a claim of a person's that cannot be said at its strength leaves the paragraph as it is. Nothing else was found lost: the offered saying, Natural Arriving 7.3 "the rising" (contents line "- 7.3 Resolving, a droplet rising") and the reason are in NEW.
SAFER: KEEP

### 54
CHECK: OK
WHY: laid beside the prior clause by clause, each of the three readings, "is or is not", "no droplet enters as dropped and none is refused", the self's reason said as its one claim, the three scales and the dropper's own reading are in NEW, with Natural Arriving 7.2 and 7.3 (contents lines "- 7.2 Dropping your interest", "- 7.3 Resolving, a droplet rising") and the offerings' header at each file named as the prior has them; NEW has no quotation and no session.
SAFER: -

### 55
CHECK: OBJECT
WHY: Three things, the first the heaviest. (1) A named place said as now is not at the files now, and its present place is found. NEW has "at its entry on the way a working speaks and writes" of "Exhibit TWENTY-FOUR Geodesic Improving Method's carrying". A search of carry/*.md for "speaks and writes" finds the two copies of this paragraph and one line of the Session Record, and no entry of that name; the first reader's EVIDENCE says the same and leaves the aiming as it was. The entry is at archive/carrying_v381R/Exhibit_TWENTY-FOUR_Geodesic_Improving_Method_v380R.md line 90 ("the way a working speaks and writes, for this file's section on opening a session"), and its sentences are now the insertlet "At 2.3 · A confident improving made, a meaning or a naming brought" at carry/Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md line 51 ("A working speaks with the other self in natural explaining, each thing at its one whole name"). The first reader's rule 8 asks the place as it is now, and its rule above all leaves a paragraph as it is if the thing it refers to is not found; NEW is at the form's one hundred and fifty words, so the present place cannot be added within the form. (2) The same paragraph is at Offerings to Geodesic Improving Method line 229, re-said at that mate's resolving, objected to at its second reading and left as it was (GM_2_harm.md, block 66); re-said here, the two copies part. (3) NEW says a session's doing, "as at session v382F, naming Natural Explaining, Exhibit THIRTY Co-Chaining Logic Registry's claims and the -ed, the order changing for the better at each naming", the thing the second reading objected to at the other copy. Nothing of the prior was found lost: the four things said at a breath, the session's number, "no question is posed as binary", the three things named and Natural Arriving 8.2 (contents line "- 8.2 Arriving") are in NEW.
SAFER: KEEP

### 56
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 57
CHECK: OK
WHY: laid beside the prior, the two sayings with each of their members, "the only intelligence" that can be offered anyone, the two readings at five and at three with "each a file", cohering at Exhibit THIRTY, naming within explaining and carrying "the expedition's and not the offering's", the reason of the portal's two lines and the file saying each concept once, both sayings the self's, the file's motion, and the aiming "Natural Arriving Part ONE, a concern for both" are each in NEW; NEW has no quotation, and no other paragraph of carry/*.md points at this one by name (searched "five or at three").
SAFER: -

### 58
CHECK: OK
WHY: laid beside the prior, the offered sentence whole, "an interest's or a breaker's", the order of the resolver's lines and Exhibit ONE's tables and then the files' sentences, "forty lines" in a second, session v382F's two partings each with its file, and "nowhere else" as "at no other place" are in NEW; Natural Arriving 1.4 and 5.4 are contents lines now ("- 1.4 A method is a non-living existing thing", "- 5.4 A claim about the method"), and *co-competent-so-far* is at Exhibit_THIRTEEN_Resolving_Hard_Problems_v380L.md lines 160 and 162.
SAFER: -

### 59
CHECK: OK
WHY: laid beside the prior, the offered sentence whole with its three negations (manages nothing, decides nothing, approves nothing), the session's part, the one word at the one irreversible changing, the self's asking and its three claims (not managing, no authority, do no harm improving alone), the gate and session v382F's three are in NEW; "at the membrane" is said as "at the between", the carrying Exhibit TWENTY Natural Naming 2.4 has for the word at line 260, and Natural Arriving 1.2 is a contents line now ("- 1.2 Your interest is a self, arriving carrying its prior").
SAFER: -

### 60
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 61
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 62
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 63
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 64
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 65
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 66
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 67
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 68
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 69
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 70
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 71
CHECK: OBJECT
WHY: Added: the kind. The prior is a droplet "Aimed at a word", a scan's finding that a released word is at one place of the file; it says of no saying that it parts from another. NEW lays it as "Concern · …" with "Two sayings part" and "They part at the word *membrane*". In this mate a concern is the kind laid for both selves (paragraph 57 of this same input says "a concern for both" in its own words; this paragraph does not), so NEW gives the paragraph a kind and a claim the prior does not have. At an earlier mate a scan's droplet of released words was re-said as a droplet and confirmed (NI_2, block 37). Also, NEW quotes Exhibit TWENTY Natural Naming 2.4 as having "the row" "| *membrane* | *the between*"; the words are exact as far as they go (line 260, under "## 2.4 Released words, each with its carrying"), and the row goes on after a colon, "*the between*: the empty centre of parity, …", so the opening of a row is given as the row; the prior quotes nothing of Natural Naming. Nothing of the prior was found lost: line 24, the contents, 3.1, 3.2 and 3.3 with their titles, "dissolved at v380R", *the between* at Natural Naming 2.4 and "nothing else in the file" are in NEW, and the four quotations of Natural Arriving are exact (line 24 "**THREE · THE NAMING, THE MEMBRANE**", lines 26 to 28; the word is at no other line of the file).
SAFER: **Droplet · *Membrane* at one part title of Natural Arriving.** The word *membrane*, dissolved at v380R, is at one place of Natural Arriving. Its contents have "THREE · THE NAMING, THE MEMBRANE" at line 24, over 3.1 "One name for each concept, and nothing similar", 3.2 "The released words" and 3.3 "Reading a sentence here". A part title carries the word, and nothing else in the file carries it. Exhibit TWENTY Natural Naming 2.4 carries *the between* for it. It is aimed at a word of Natural Arriving.

### 72
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 73
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

### 74
CHECK: KEEP-UNCHANGED
WHY: -
SAFER: -

## READING
Read whole: this brief; the first reader's brief with its further rules; the PRIOR file, each of its twenty-five paragraphs; the PROPOSED file, each block and its closing section; the living file Natural_Arriving_v381R.md (seventy lines, a shell: the contents, one opening paragraph and 1.1 with one paragraph); `incoming/README.md` as it is now, and as it was at its earlier commit with the part *What it brings*; carryings/v382F/Session_Report_v382F_3.md from its droplets to its close, the source of 52 to 59; the mate's opening sections down to the head of its older Droplets section.

Checked by search and by reading the lines found: each of the twenty-five prior paragraphs is in the mate once, word for word. For the seven paragraphs proposed for re-saying (53, 54, 55, 57, 58, 59, 71), each NEW was laid beside its prior clause by clause; each quotation in a NEW was searched exactly in Natural_Arriving_v381R.md (line 24 and lines 26 to 28) and in Exhibit_TWENTY_Natural_Naming_v380R.md (line 260, with the heading above it, 2.4); the words cited in italics were searched at their files (*co-competent-so-far* at Exhibit THIRTEEN Resolving Hard Problems lines 160 and 162; *membrane* at Natural Arriving line 24 alone; "its standing said at each event" at Exhibit TWENTY-FOUR Geodesic Improving Method line 202); each NEW was read against the first reader's list of words and its length (131, 145, 151 with the form's mark, 140, 126, 135 and 102 words by a split at spaces). carry/*.md was searched for a pointer at each of the seven by its subject words ("five or at three", "pair of eyes", "nothing but offer", "can steer", "file will carry", "line of the resolver", "installs a gate", "one irreversible", "forty lines", "part title", "THE MEMBRANE") and for the pointing phrases of the brief; no paragraph points at one of the seven by name, and the general pointers at this mate's and its possibling mate's v385A sections ("the existing droplets below", "Existing Arriving droplets", "Arriving's existing naming droplets") still find a re-said paragraph. For 55 the entry it names was searched at carry/*.md and at archive/carrying_v381R/, and the two places were read. The earlier second readings of other mates (GM_2_harm.md blocks 65, 66 and 69; NI_2 block 37) were read for how the same paragraphs and the same kind of paragraph were judged, and the mate Offerings to Geodesic Improving Method was read at lines 51, 229, 233 and 321 for the form of a re-saying already laid.

Not objected to, and said here for the one laying the changes: the closing tag "(the session's last report; its language read at the resolving)" at 53, 54, 55, 57, 58 and 59 is in no NEW. It was read as the receiving's note that the wording was unread at the receiving, which a re-saying in the present naming does; no later section or record explains the tag further (searched carry/Session_Record.md and the three Living File Registry mates). At 58 and 59 the session is named plainly (session v382F's two partings; session v382F's gate, three) as the first reader's rule 12 has it, and that was not held an objection by itself; at 55 it is the third of three reasons. Each NEW drops the signature "v382F" for the laying's own; at 54 and 57 no session is named in NEW and no claim of the prior was found to rest on the date, where at 53 the named place rests on it.

Not checked further: the eighteen blocks with the verdict KEEP, each left exactly as it is. No transcript of session v382F was found, so the self's words at 53, 54, 57 and 59 were read at the report's line alone. No file of /home/claude/corus was edited; this report is the one file written.
