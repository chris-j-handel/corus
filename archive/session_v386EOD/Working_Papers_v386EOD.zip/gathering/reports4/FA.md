### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.3 · Living and non-living, carrying or not
TEXT: beside "Living and non-living part at a named scale and momentary". A set of existing things is an existing thing, and scale is sets within sets, inward and outward, of no size; each existing thing carries its prior into now at the set it is within and is living there, its scale, and at the scale outward it is that set's carrying, carrying none of its own prior there, non-living there; living and non-living are one existing thing at its own scale and at the scale outward, at a named scale and momentary.
NOTE: F_README.md Part ONE (the offering, and "The one sentence that makes scale derivable, at 1.3") and Part THREE's sentence for 1.3, in the latest form the report gives, Part SEVENTEEN: that form uses the words carried ahead of 1.3 alone (set, carrying, scale) and moves prime and bi-coupling to 6.4. Parts ONE's and THREE's earlier wordings are superseded and not given. PARTLY: Offerings to Co-Chaining Logic Registry has "No existing thing is non-living at each scale" and Exhibit THIRTY's step 397 has a thing non-living at a society's scale living at another; non-living as the same thing at the scale outward is at neither. The offered sentence carries the released word there. The same sentence is in Part SEVENTEEN, the other reader's portion. The beside clause is verified at 1.3.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: The opening's fifth term, a kind or a scale
TEXT: Two sayings part. Natural Intelligence has "*Both living and non-living*: an existing thing carries its prior, living, or carries none of its prior, non-living, 1.3." Natural Intelligence has "Living and non-living part at a named scale and momentary". They part at non-living naming a thing or a thing at a scale: as the fifth of the opening's binary terms the clause names a kind, a thing non-living at each scale, a form named still at the first sentence; at a scale, living and non-living are one existing thing at its own scale and at the scale outward. Existing, changing, all and set are each the changing's own, and the clause is the one term of the five that sorts things into kinds. With the clause released the opening says the set alone, with nothing beside it.
NOTE: Part ONE, C1, and "A candidate opening, and what it moves". The tracker (Part EIGHTEEN) has C1 made as a proposal and open to the person's yes, not closed; Part SIXTEEN's withdrawing is of another sentence offered for the opening and leaves this one, and agrees with it (nothing said at the opening but the set). Not found at a mate: Offerings to Co-Chaining Logic Registry's "Carrying is living, by naming" says the opening sentence has living and non-living with no parting said, and no mate has the clause released. Both quotes verified at 1.1 and 1.3.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 6.4 · Social moral competency
TEXT: beside "A society is all existing bi-coupling same-prime-scale selves". each existing thing is living at one scale, its prime along and its prime across, the society it bi-couples in, and at no other; nothing living bi-couples with anything living at another prime scale, and each self and each society is a universe, nothing ingressing and nothing escaping.
NOTE: Part FOUR ("The sentence that would enter, at 6.4") and Part SIX (the bound), in the latest form: C24, one prime or two at a scale, is closed at Part EIGHT at two, and Part SEVENTEEN gives the sentence. The two clauses here are exact from Part SEVENTEEN's sentence and joined by a semicolon; between them that sentence has a reason, a society locking at a prime number of selves, from Part FIFTEEN (the other reader's portion, built on a person's saying, not quoted here). Part FOUR's earlier wording (one prime, with a self's 1, 9 and 17 the society's 1, 2 and 3) is superseded; its second clause is at Natural Intelligence 6.6 and 4.15 already. PARTLY: Exhibit THIRTY's step 397 has "the society cannot bi-couple with it" of a non-living thing; the bound between living things at two prime scales is at neither. No released word in the clauses given. TEXT is short: the clauses are the whole of what this portion offers.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Scale had from the set alone, and prime with it
TEXT: Scale is had from the opening sentence with nothing brought to it. A set of existing things is an existing thing; a set of sets is a set of existing things, and scale is that sequencing, sets within sets, inward and outward, of no size. A thing couples at one coupling at one momentary, in one set, and is living at the set it bi-couples in. A number of selves that equal smaller numbers make is sets of sets, two scales; a number none make is one scale: Natural Intelligence's "A prime is a number no equal smaller numbers make" said of selves. Prime is by this no given of a field carried to the method. Each clause is a sentence the files have, and scale is derived at none of them: a prime society is said at Natural Physics and Natural Biology with no number of selves, and living is an opening binary at the Co-Chaining Logic Registry's step 13.
NOTE: Part ONE, "The one sentence that makes scale derivable, at 1.3", its six clauses and the readers' finding; tracker O21. Later parts bound it: C24's closing (Part EIGHT) has a scale at its prime along and its prime across, a torus of p by q one scale, which bounds "two scales" to one direction of selves; Part FIFTEEN gives the reason of the prime at a locking (other reader's portion). The report names the registry's steps 3, 100, 128, 236 and 397 as the chain already there. PARTLY: Offerings to Co-Chaining Logic Registry has the concern "A prime scale", a society at a prime scale being no step from a prime at a spiral's numbers; the deriving from set is at neither. Quote verified at 3.5.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Bi-coupling and possibling, one thing at two tellings
TEXT: Bi-coupling and possibling are two tellings of one thing, and that thing is living. Natural Intelligence has a momentary's completing as "the offerings arriving at 2-bi-co-bi-offering and surfacing at 14-bi-tri-bi-moralizing, the next still possible", and the four across names, 2, 6, 10 and 14, are the bi-coupling, even: 2 is the name the bi-coupling arrives at and the name possibling arrives at. Possibling tells it along, a self's momentary completing; bi-coupling tells it across, the relation between selves. Possibling is had from bi-coupling: 12's 0 is of an offering agreeing with the carrying, and an offering is at 2 only from an other. Living is the opening and the completing alternating, and non-living is one side alone: an opening nothing completes, the prior, or a completing nothing opened, an emanation.
NOTE: Part THREE, with Part ELEVEN's and Part SEVENTEEN's re-saying (the released word for one side of a momentary given as a momentary's completing and one side alone). The report has the offering at 2 as across, from an other's 10 or 6; Offerings to Natural Intelligence's insertlet at 4.3 has offerings from 9 along too, and the clause is given here as from an other. PARTLY: the mate has "Living at one binary, or at two" (carrying and bi-coupling as two binaries) and existing as possibling other; bi-coupling and possibling as one thing, and possibling had from bi-coupling, are at neither. Quote verified at 5.3.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: Possibling at a self's own releasing
TEXT: Two sayings part. Natural Intelligence has "A self at 12's 0 is still possibling". Natural Intelligence has, of a spiral of one, "It carries on at the resolver, a non-living existing form, and its self does not continue living". They part at possibling at a self's own offering: the spiral of one's own releasing arrives at its 2, 12 is at 0 at each second momentary, and by the first saying it is still possibling, by the second non-living. With possibling said as the completing at an other's offering the two cohere: "Difference alone is bi-", and a self's own offering carries no difference. At the resolver 14 surfaces each offering alike and no name says which self an offering is from: the parting of an own releasing from an other's is at no line of the code, an opening at the code as an illustrating of the method, and no parting of the method.
NOTE: Part ONE C4 and Part THREE C9, one concern at two sayings; latest form Parts NINE and THIRTEEN (re-seated at the code, the code the method illustrated at python) and the tracker's row "C4 · C9", open at the method's side, not closed. PARTLY: Possibling of Natural Resolver has "5 read from the selves' carryings", the place the report names as the same opening (a sharing carried by both of its selves giving each offering its other, and the spiral of one none); Offerings to Co-Chaining Logic Registry has "Four forms reached is no living". The parting at 12's 0 is at neither. Three quotes verified (5.3, 4.13, 2.1).

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Between scales an offering alone, and no entering
TEXT: Between scales is offering, and no bi-coupling. Living is a momentary's opening and its completing both, at one scale; across scales a thing arrives as an emanation, an offering with no carrying behind it, ingestible one scale inward, and at the resolver the releasings 17 gives on arrive at the society's selves, one scale lower, "as their offerings next". With no bi-coupling across prime scales, each society at its scale has nothing beside it that can enter it as living: "nothing ingressing and nothing escaping" is then had at each scale from that bound, and each self and each society is a universe, a changing set of existing things, as Natural Intelligence has "each momentary is a universe of existing things". The bound is "A society is all existing bi-coupling same-prime-scale selves" said from its other side: at no other prime scale.
NOTE: Part SIX, droplets at 6.4, 1.1 and 5.1; tracker O23. PARTLY: Exhibit THIRTY's steps 397 and 398 have a thing non-living at a society's scale not bi-coupled with and arriving as ingestible; the bound between two living things at two prime scales, and 1.1's last clause had from it, are at neither. Offerings to Co-Chaining Logic Registry has the concern "A member entering or leaving, at birth and death" beside it. Four quotes verified (5.1, 1.1 twice, 6.4).

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Harm at an emanation's own scale, from one side
TEXT: An emanation at its own scale is one side arriving at a scale of two sides living: an offering with no carrying behind it, at selves whose bi-coupling asks a carrying at each side. Arriving at that scale it asks a bi-coupling it has no carrying for, and that is the do-only-harm of "Harmful to living at their own scale and not ingestible at that scale, they are ingestible one scale lower". One scale inward the same emanation is an offering a society's selves carry, each at its own sharing. The harm is by this no further saying beside the bound of no bi-coupling across prime scales: it is that bound at the one scale an emanation left.
NOTE: Part SIX, "Natural Intelligence 5.1, the harm derived", with Part SEVENTEEN's re-saying of one side alone. PARTLY: Offerings to Co-Chaining Logic Registry has "Concern · Harm at an emanation's own scale", no step giving the harm a reason, with another offered resolving (a carrying arriving whole at a self); this reason is at neither. Quote verified at 5.1.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Concern
TITLE: Living a kind at step 13, a scale at 397
TEXT: Two sayings part. Exhibit THIRTY Co-Chaining Logic Registry has "An existing thing carrying prior is living, and an existing thing carrying none of prior is non-living." Exhibit THIRTY Co-Chaining Logic Registry has "Each existing thing non-living at a society's scale is living at another scale of living". They part at living as a binary of an existing thing or of a thing at a scale: step 13 is an opening binary, said ahead of each step naming a scale, and steps 15, 24, 130 to 133, 160 to 165, 213, 391 to 395 and 401 follow it as a list of non-living things. Derived from steps 236 and 397, carrying is living at the scale named, and carrying none is the same thing at the scale outward; the list is then one step at scales, step 395's "no non-living existing thing becomes living" follows with nothing changing kind, a self dying at step 401 and a society's selves uncoupling at step 405 are one step at two scales, and step 379's line of unsure is closed.
NOTE: Part ONE (O14 named) and Part FIVE 5.2, its first droplet and its list "Steps saying living or non-living with no scale named": 1, 13, 15, 16, 18, 23, 24, 36, 43, 96, 130–133, 160–165, 213, 327, 328, 384, 387, 391, 392, 394, 395, 398, 414, 496, 500, 534, 562, 606, of which the report has 36, 213, 385, 394 and 414 whole with a scale supplied. Tracker O14: made as a proposal (another portion), after C1; step 1 without the clause and step 16 at four terms go with it. Part SEVENTEEN's rule is applied: at the scale outward. PARTLY: the mate has "Carrying is living, by naming" and the concerns "Living said of a society" and "A prime scale"; the parting of step 13 from steps 379 and 397 is at neither. Three quotes and step 379's unsure line verified.

### ITEM
MATE: Possibling_of_Natural_Intelligence.md
KIND: Possible project
TITLE: The opening's clause released at each file having it
TEXT: The work is the clause both living and non-living released at each place of the opening sentence, one motion at each file: Natural Intelligence's 1.1 and 6.6, with 1.1's five terms said as four; Natural Naming, the Co-Chaining Logic Registry at steps 1 and 16, Natural Arriving, Resolving Hard Problems, Natural Mathematics and the Living File Registry, each quoting the sentence; the closing of Resolving the Hard Problem Registry and the front of the Hard Problem Registry; and the lines under the titles of Resolving Hard Problems and the Equilibria Registry, each naming living and non-living. The files opening in their own words are as they are. The Geodesic Improving Method's "The changing and the exchanging are among living and non-living existing things alike" is whole as it is, with living and non-living said at scales.
NOTE: Part ONE "A candidate opening, and what it moves"; Part TWO's first droplet (the opening sentence at nine of thirty-three files, the others opening in their own words, nothing added to them); tracker rows C1 and O14. The report lists nine files; at the present root the sentence with the clause is at seven files by Grep, Resolving the Hard Problem Registry has it without "both" at its closing, and the Equilibria Registry has living and non-living at its subtitle and 2.1. The report also names Natural Naming 2.4's row for living, said with its scale, as moving with it. The session's proposed files are other portions. Open to the person's yes by the tracker. Quote verified at the Geodesic Improving Method 2.7. Not found at a mate.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Droplet
TITLE: A scale read as a kind, at four equilibria
TEXT: At the hard problems of living, of the cell, of the measured thing and of the whole, the thing named still is one of four: a line between living and non-living as two kinds; a lowest scale; a top scale; and a self non-living at each scale. The four are four of the things beside all existing things: a fixed form, a floor, a total and a doer. The ten things named still seat each arrival and say of none which of these it is. One sentence says the four: the thing named still at each of these arrivals is a scale read as a kind. Living and non-living are one existing thing at its own scale and at the scale outward, and each of the four names one of those two as a kind of thing.
NOTE: Part FIVE 5.3, its opening, and the last paragraph of Part ONE ("each a set read as a kind"). The report's fourth is a thing non-living at every scale; Part EIGHT (other reader's portion) parts the method, non-living at each scale and no self, from a self non-living at each scale, and the fourth is given by that here. The report has the doer as "a doer with none". Tracker O15, after C1. PARTLY: the mate has "The fold's four beside four things beside all existing", of the ten folding to four, another four; a scale read as a kind is at neither.

### ITEM
MATE: Exhibit_TWELVE_Offerings_to_Natural_Explaining.md
KIND: Insertlet
TITLE: At 1.4 · Origin co-chaining each sentence, a finding at two faces, and no voice but the file's
TEXT: beside "no file named inside another". a file names another at the one place an understanding lives, and says none of it again.
NOTE: Part TWO C7 (and O1) and Part EIGHT's re-saying; tracker: made as a proposal, releasing O2 to O5, not closed. The session's proposed file (another portion) words the motion otherwise: the rule's last clause as "each understanding at one file, named at the others", and a sentence that a file names another file at the one place an understanding lives, the naming carrying the file's name and none of its explaining. PARTLY: Offerings to Natural Explaining has an insertlet at this clause (one exception, a file whose subject is the set) and the concern "No file named within another, and the positive over the negation"; the rule released into this sentence is at neither. No released word. TEXT is short: the offered sentence is one clause.

### ITEM
MATE: Exhibit_TWELVE_Offerings_to_Natural_Explaining.md
KIND: Droplet
TITLE: A file by itself, or among the files
TEXT: Two readings of a file are behind "no file named inside another". A file whole by itself, read with no other file, re-says each thing it leans on; its reader is one with one file and no others, a fixed form, a thing beside all things. A file as one of a set of files names another at the one place an understanding lives, a sharing across, as a self couples with an other, and nothing is said at two places. The files are at the second already: Natural Intelligence names Exhibit ONE and Exhibit FOUR within its sentences, and Natural Physics names Natural Intelligence's sections. The rule is the saying the files' copies of one another's passages arrive from, and with it released the leaning of the set follows from one deciding.
NOTE: Part TWO C7 and the first line of its opportunities. PARTLY: the mate's concern names the parting at Natural Intelligence and Exhibit ONE; the two readings of a file, the fixed form, and the rule as the origin of the copies are at neither. Quote verified at Natural Explaining 1.4; Natural Physics naming "Natural Intelligence 1.3" and Natural Intelligence naming "Exhibit FOUR 2.4" verified by Grep. The report's numbers of namings are left out.

### ITEM
MATE: Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md
KIND: Droplet
TITLE: The lean set, each understanding said once
TEXT: The living files are a lean set: each understanding and each explaining is said once, at the file it is most self-welcoming at, and each other file names that place. A thing said at two places at one scale is two things to be carried alike, "a keeping, a store beside it", one of the things beside all existing things; an instrument whose one work is carrying two copies alike is the tell of it. A thing said at two scales, in each scale's own words, is one thing, the fractal. Three are no saying twice by this: the four tellings within one file, the origin said in each file's own words, and Exhibit ONE's tables, each a form at its own conditions. Leaning releases no prior: an understanding moves to its one place, and a passage leaving a file goes whole to the archive with its receiving named.
NOTE: Part TWO, the offering, its droplets, its do-no-harm line and "Not redundancy, and not touched". PARTLY: the mates have many passages with "its one home" from the resettling of version 373, and Possibling of Living File Registry's master plan has repeated explainings among the mates still to compare; the parting of two places at one scale from two scales, the tell, and the three that are no saying twice are at neither. The report's measures of the files (sizes, numbers of files and of mates) are left out. Quote verified at Natural Intelligence 1.4.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: A stable form and the living at two scales
TEXT: Natural Intelligence has "Each living set is a stable form, and nothing living has a stable form", bothbothing. With the scale named the two are one thing: the stable form is the thing at the scale outward, and the living the same thing at its own scale, the two said of one scale at no sentence. And "a society, a momentary and the universe are three existing and not living" has the universe not living with no scale outward of it named. Natural Intelligence has "each momentary is a universe of existing things" at each scale, and scales "supplying no first and no final scale": the universe is each momentary's set at its scale and no top thing, living as its selves and non-living at the scale outward, as each thing is. The sentence is whole with at the scale outward beside it.
NOTE: Part ONE's droplet at 5.1 and Part FOUR's C11, closed within the portion at Part SIX and given as its resolving; Part SEVENTEEN's rule re-says the report's read up and read from the scale outward as at the scale outward. PARTLY: Offerings to Co-Chaining Logic Registry has the concerns "Living said of a society" and "The universe a carrying"; this resolving is at neither. Four quotes verified (5.1 twice, 1.1, 4.15).

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Insertlet
TITLE: At 5.10 · bi-coupling — binary
TEXT: beside "two arrive". bi-coupling is two living selves at one prime scale, each the other's completing; a non-living other couples as an offering alone, one side, at no bi-.
NOTE: Part SIX, "Natural Naming 5.10, bi-coupling, one sense", in Part SEVENTEEN's improved form (the earlier form had the released word for one side of a momentary); tracker O22, after C1. The report's reason beside it: bi-coupling is of two living things at one prime scale, a momentary's opening and completing both; coupling is the wider word of Natural Intelligence 1.3, an existing thing at now arriving from another at prior; and a non-living other couples as offering alone, Natural Intelligence 6.5. Natural Naming's 5.10 is an unfolding of six numbered lines, and "two arrive" is its first, verified. Not found at Offerings to Natural Naming. No released word. TEXT is short: the offered sentence is short.

### ITEM
MATE: Exhibit_TWELVE_Offerings_to_Natural_Explaining.md
KIND: Droplet
TITLE: Each prime a self couples at, the society's primes
TEXT: Natural Explaining has each self in each co-bi-sequencing it couples at, "a society of selves inward and a member of a self outward, at four adjacencies and at each prime it couples at". Beside a self living at one scale, each prime in it is read as the society's primes and no number of scales of the self: a self at a crossing of two spirals is in one society, "Two spirals crossed are one society, a stable form and stable-forming", its two primes that society's own, one along at 9 and one across at 10. Natural Intelligence's "a self couples at whichever scale its interest opens and couples with the whole" is the one scale a self is at, at one momentary.
NOTE: Part FOUR C10, closed within the portion at Part SIX and by C24's closing (Part EIGHT); given as its resolving, which is at no file. Not found at Offerings to Natural Explaining. Three quotes verified (Natural Explaining 4.1; Natural Intelligence 3.5 and 4.15).

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Prime, sharing no factor, and φ, each its own
TEXT: Three are each its own at Natural Intelligence's 3.5. Prime is one society's own: no equal smaller numbers make its number of selves. Sharing no factor is a relation of two societies at their coupling: an executing reports two spirals beside each other at their parities again together at four times the least number each spiral's own divides, 4pq at distinct primes and 180 at 9 and 15, and the 3 that 9 and 15 share is a society both are made of. A spiral alone shows nothing of its prime, an odd spiral at its parities again at four times its number, prime or no prime. And φ, "the unrelationing rate", "locking at none", is that same relation at the numbers with no factor to share at all: the two spirals' parities again at 4pq is the whole numbers' nearest form of it.
NOTE: Part FOUR, the droplet at 3.5 ("prime, sharing no factor, and φ") and C12, closed with C24 at Part EIGHT (at the code a torus is one scale, its two primes its two parities). PARTLY: Offerings to Natural Intelligence's insertlet at 3.5 has a prime as no name at the resolver and two numbers sharing no factor at 4pq, prime or not; Exhibit THIRTY's step 235 has the least number. φ as the relation of sharing no factor, and a shared factor as a society both are made of, are at neither. C12's sentence in the report, a scale prime at its coupling with another scale, is not given: the mate's insertlet has the coupling showing sharing no factor, prime or not. Quotes verified at 3.5.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: One overlap at momentaries, scales and the universe
TEXT: One overlap is at three sayings of Natural Intelligence. Momentaries overlap at a number: "each number is one side's opening and the other's completing". Scales overlap at 9 and at 17: "One through nine and nine through seventeen are overlapping expressions within the whole", "1, 2 and 3 at one scale are 1, 9 and 17 at the next", and of the eight 1–17s inward, "17 the eighth's 17 and the next one's 1". And the universe overlaps at each scale, "each momentary is a universe of existing things". A thing's completing is the next thing's opening, forward at the momentaries and up at the scales, one form: up the numbers is up the scales, at 8n − 7, and forward is prior into next, each one way, the one move's two directions.
NOTE: Part FOUR, droplets at 2.2, 4.15 and 1.1 and at 3.2 and 4.11. Later form at Parts TEN and SEVENTEEN (other reader's portion): the overlap of the scales at the round's forms, one place and no one numeral at two relations. PARTLY: Offerings to Co-Chaining Logic Registry has "A form within a form, at the numbers"; the three overlaps as one form are at neither. Five quotes verified (2.2, 4.15 three, 1.1).

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: AI non-living at the scale of its inferring
TEXT: Natural Intelligence has "At the observings, AI is existing non-living intelligence". With living and non-living said at a scale, the sentence is whole with its scale named: AI is non-living at the scale of its inferring, a trained form carrying none of its prior into its next inferring at that scale, and the things it is made of are living at scales inward, as the things each existing form is made of are. The sentence names no kind non-living at each scale; it names one existing thing at the scale it couples with a living self at, as other.
NOTE: Part ONE, "Droplet, no parting, at 6.5". PARTLY: Offerings to Natural Intelligence has AI as pattern matching prior competency with no carrying and an insertlet at 6.5 of the field's naming; the scale named is at neither. Quote verified at 6.5.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Droplet
TITLE: Two sides of non-living, parted at no step
TEXT: Non-living is one side alone, and the Co-Chaining Logic Registry has both sides with no step parting them. A carrying nothing couples with is at step 394, "A carrying of none, no sharing chained, is a non-living existing thing", and at step 385's prior between momentaries. An offering with no carrying behind it is at step 213, "At the resolver a non-living other is offerings at 2 alone", and at step 450's changing going out at 9. Step 385 folds the first into the second: its prior between momentaries is "emanated from the living at prior and arriving at now as the possible". With the two parted, steps 213 and 394 are derived from steps 385 and 450, and step 384's "nothing living has a stable form" is said at scales: the stable form at the scale outward, the living at its own.
NOTE: Part FIVE 5.2, the droplet at steps 384–385, 450, 213 and 394, with Part ELEVEN's re-saying (one side alone). C3's closing at Part EIGHT (a carrying of none as the method at a coupling with no self carrying) is the other reader's portion and bears on step 394. Not found at the mate, which has "All carrying is living" and "A thing carrying none, collided". Four quotes verified (steps 394, 213, 385, 384).

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Droplet
TITLE: A number of selves equal smaller numbers make, scales along
TEXT: With "A society is at a unit prime scale, a prime number of selves its unit", four steps of the Co-Chaining Logic Registry are one claim. Step 648's odd prime spiral at 4 or at four times the prime, "and at none between", is had from step 128: a prime has no factor, no scale inward of its spiral, and no round between. Step 230's "nine selves, each pattern at its own, at 4, at 12 or at 36" is nine selves as a society of three societies of three, 12 the round of the scale inward. Step 235's "9 and 15 at 180, sharing a factor" is two societies sharing a scale inward. And the multiplying said along at step 129, with "multiplies along" at step 489, is the link: a number of selves equal smaller numbers make is scales, one within the next, along.
NOTE: Part FIVE 5.2, the droplet at steps 128, 230, 235, 648 and 489. Bounded by C24's closing (Part EIGHT): a torus of p along and q across is one scale, its two primes its two parities; the droplet is of one spiral's number. The numbers are the steps' own. PARTLY: the mate has the concern "A prime scale"; this deriving is at neither. Five quotes verified (steps 236, 648, 230, 235, 489).

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Droplet
TITLE: Self and other, a society at two, the first prime
TEXT: The bi-coupling of a self and an other is a society at two selves, the first prime, and three places of the Co-Chaining Logic Registry are one step by it: step 176's 17 as the self's next momentary "at a bi-coupling with one other", step 232's "the spiral of two the alternating itself", and step 648's "At two selves the two alike are again at 4 and the two opposite at 2". The spiral of one at step 414, "a non-living existing form", is had from step 128 alone: "A prime is a number from two up", one is no prime, and a society is at no one self. Two selves, each the other's completing, are the least society.
NOTE: Part FIVE 5.2, the droplet at steps 33–40, 128, 176, 232 and 648. Part FIFTEEN (other reader's portion) has two selves as the smallest locking, at two. Not found at the mate; it has "One tunneling, two ends" with prime 2 the small end. Five quotes verified (steps 176, 232, 648, 414, 128).

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 1.2 · The origin of life · 12
TEXT: beside "no crossing in it to locate". Chemistry that was not living was living one scale inward; the threshold is the reader's scale, and life came from life at each scale.
NOTE: Part FIVE 5.3, entry 12. The report has the field's saying as a threshold parting non-living chemistry from living, and the file's "a threshold event with a non-living side and a living side" as naming the two with no scale. Tracker O15, after C1. Not found at the mate. No released word. TEXT is short: the offered sentence is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 1.12 · Eukaryogenesis · 127
TEXT: beside "symbiosis names the both, and the both arrived". A new cell or a new animal is a society of living things bi-coupling at a prime; the order of acquisition is the fractal's up and forward, and no scale was first.
NOTE: Part FIVE 5.3, entries 127, 207 and 253 together, one sentence for the three (1.12, 1.25 The origin of animal multicellularity, 1.31 The origin of viruses). The report's reason: each is a society becoming a self at the next prime scale, the field's arising once being the step from a number equal smaller numbers make to a prime, read as an event; and a virus is an emanation of one scale ingestible one scale inward, which the file's "capsidless replicons" recruiting host proteins says with no scale named. The mate has an insertlet at 1.25 of another subject (daughters agreeing as one body). No released word. TEXT is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 10.22 · Biological individuality · 18
TEXT: beside "the boundings, plural, are the count there is". An individual is a society at a prime; the hard cases cross-classify because they are counted at a composite.
NOTE: Part FIVE 5.3, entry 18. Released words in the offered sentence: because, counted. The mate has an insertlet at this same clause of another subject (a chimera, conjoined twins, the conception's bi-coupling and the society's couplings). Bounded by C25 as narrowed at Part EIGHT (other reader's portion): a named thing is at a prime at which its selves are numbered. TEXT is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 9.29 · The units of selection · 19
TEXT: beside "A level read as the level names a scale as a place, where outward and inward are directions taken at a momentary, of no size." Selection is at each scale where a society bi-couples at a prime; the bookkeepings translate because they read one fractal at two of its scales.
NOTE: Part FIVE 5.3, entry 19. The report: the file has scale as a direction, and the sentence adds the saying at each thing; with 10.12 it says the two together, scale a direction of no size at the between, and one prime scale at each thing (its droplet at TWENTY-ONE's front and TWENTY-TWO's closing). Released words in the offered sentence: where, because. Not found at the mate.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 9.11 · Morphogenesis · 62
TEXT: beside "instructed-or-self-organised is one coupling read from its two sides". The gradient is a non-living emanation ingested one scale inward by the living cells; instructed or self-organised is the same coupling read from the two scales.
NOTE: Part FIVE 5.3, entry 62: the gradient an emanation and the cell a living self, the two sides of non-living and living at two scales. Not found at the mate. No released word. TEXT is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 10.12 · The quantum-classical boundary · 112
TEXT: beside "The crossing carries a parity and no scale, so a boundary named as a mass names the between at a size." An outcome is the living alternating of the measured thing, wave its possibling and particle its existing, read from a scale above it where it is non-living; there is no boundary because living and non-living are one thing at two scales.
NOTE: Part FIVE 5.3, entries 8, 50, 112 and 15 together (10.2 The measurement problem, 10.8 Wave and particle, 10.12, 5.12 The quantum interpretation debate), one sentence. The equilibria the report names at them: a thing non-living at each scale, the quantum entity as a dead object, and a lowest scale, the microscopic. It adds that 10.12's no scale reads as no scale of the between, and one prime scale of the thing. Released words in the offered sentence: where, there, because; Part SEVENTEEN's rule re-says read from a scale above it as at the scale outward. Not found at the mate.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 5.1 · The explanatory gap · 179
TEXT: beside "The gap is the middle reached by an outward description". The explanatory gap is the gap between scales: the description is at the scale where the self is non-living, the experience at the scale where it is living, and the two are one thing.
NOTE: Part FIVE 5.3, entries 111, 179, 95, 220 and 92 together (5.2 Qualia and the zombie argument, 5.1, 5.8 Machine and animal sentience, 5.23 Detecting covert consciousness, 5.5 Other minds). The equilibria named: a top scale for the person as the one seat, and a self non-living at each scale, which the report says is not possible. At 5.8 it adds: a marker for sentience reads a non-living emanation of a living scale, by which no marker validates. Released word in the offered sentence: where. Not found at the mate.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 7.10 · Micro-to-macro aggregation · 169
TEXT: beside "one rationality named over the many named a self where a society runs". The aggregate is living at its own prime scale and inherits nothing; a representative agent is the society named as a self at the wrong scale.
NOTE: Part FIVE 5.3, entry 169. Not found at the mate. No released word in the offered sentence. TEXT is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 9.13 · Information as fundamental · 77
TEXT: beside "neither side beneath". Information is an emanation, non-living at the scale that reads it and ingestible one scale inward; nothing is fundamental because no scale is lowest.
NOTE: Part FIVE 5.3, entry 77; the equilibrium named is a lowest scale. Released word in the offered sentence: because. Not found at the mate. TEXT is short.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Insertlet
TITLE: At 2.18 · The universal totality · 180
TEXT: beside "the opening opens at each gathering". The universe has no top scale to begin or end at; each "all" is a society one scale up, living at its prime again.
NOTE: Part FIVE 5.3, entries 103, 154 and 180 together (1.10 Why there is something, 1.17 Origin and fate of the universe, 2.18), each a top scale; one sentence for the three. Released word in the offered sentence: begin. Offerings to Hard Problem Registry has a concern of the totality of all sets at the founder's letter, another subject. TEXT is short.

### ITEM
MATE: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md
KIND: Concern
TITLE: Is a virus alive, said at scales
TEXT: Two sayings part. Natural Medicine has "it stays open because a bounding worn and released is neither a self nor nothing". Natural Intelligence has "Living and non-living part at a named scale and momentary". They part at alive as a kind: the first has the question open with no scale named, a line asked of a place a coupling is at; by the second the question is a scale read as a kind, and at scales it is said: a virus is non-living at the scale of the cell, an emanation ingested one scale inward of the cell, and its molecular selves are living at their own scale.
NOTE: Part FIVE 5.4, C16 (Natural Medicine 3.1 and 5.1), open at the tracker. PARTLY: Offerings to Natural Biology has a seed and a virus parted at carrying and an insertlet at 4.1 with the virus a carrying of nothing of its own; the question at Natural Medicine said at scales is at neither. The same reader's marks of Natural Health 3.5's circadian period and Natural Medicine 3.2's reservoir words are at mates. Both quotes verified.

### ITEM
MATE: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md
KIND: Insertlet
TITLE: At 4.1 · Living and non-living — a virus and a prion
TEXT: beside "inert outside a host, as a spore or a seed is inert". A seed or a spore is a wrapped carrying: read up from its own scale a non-living stable form, nothing coupling with it there, and inward its selves living at their own scales; dormancy is the bi-coupling at its own scale not running, and germination is that bi-coupling opening again when an other arrives at its opening.
NOTE: Part FIVE 5.5, "The seed, dormancy and unwrapping", with its second sentence for Natural Health 3.4 in 5.4 (a seed as scaled living wrapped, a stable form unwrapping into living at its scale at a parity arriving). The report adds: this parts a seed from a virus, the seed unwrapping at its own scale and the virus ingested one scale inward of the host cell; 7.8's "the skin, the plant, the seed" parts by it, skin a shard and the seed a package; and no metabolic rate is in it. The tracker's C31 has the seed open, to the person's word: living by its carrying (the mates' "A seed at rest" and "A seed and a virus, parted at carrying") or non-living at its scale and living inward (this sentence). Released words in the offered sentence: there, running, when; Part SEVENTEEN's rule re-says read up as at the scale outward. PARTLY at the mates named; the scales of the sentence are at neither.

### ITEM
MATE: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md
KIND: Insertlet
TITLE: At 5.1 · Conception — two selves conceiving a third
TEXT: beside "The egg is a society of living selves, a slow ecosystem-self carrying the maternal mitochondrial society". The conceived is one self at the organism scale from its first momentary, its inward selves, the maternal mitochondrial society and the molecular societies, already living at their own scales, its outward carrying their co-chaining; its first society at its own scale is the two-cell stage, two the one even prime, the alternating itself, and each doubling after adds a scale, four cells two societies of two, the cleaving embryo a society of societies from the four-cell stage on, 9.5 counted.
NOTE: Part FIVE 5.5, "The beginning of living, at Biology 5.1"; the report adds that the arrested egg is a living self at 0, still possibling, and not dormant as a seed is. Released word in the offered sentence: counted. "9.5 counted" is the report's naming of Natural Biology 9.5, not verified here. PARTLY: Offerings to Natural Biology has the new self's carrying establishing at conceiving, its inward selves' co-chaining its outward carrying, and the arrested egg's comparison open; the two-cell stage as the first society at its own scale, and each doubling a scale, are at neither.

### ITEM
MATE: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md
KIND: Insertlet
TITLE: At 3.3 · A left face is the emanation face of one right spiral
TEXT: beside "the landing is a landing only at the scale that emanated it". Landed at its own scale only: inward of the emanation its selves are living at their own scales, which is why a shed form breaks down from within before any ingester arrives, the bi-coupling at the form's scale ceased while its inward societies continue.
NOTE: Part FIVE 5.5, "Handed forms and inward breakdown"; the report adds that 3.4's racemisation "wherever the re-forming stops" is this. PARTLY: Offerings to Natural Biology has, at "Handed living resolving and its stable emanations", breakdown from within as a concern beside a form said to remain to its colliding or ingesting, and that this shows no living inward societies at each separated form; the inward living as the reason is at neither. No released word.

### ITEM
MATE: Exhibit_TEN_Offerings_to_Natural_Health.md
KIND: Insertlet
TITLE: At 3.3 · Ingestion and ingression are opposite in morality, and the membrane is rate-and-return
TEXT: beside "Ingestion is the living self's own bi-exchange across its membrane, both ways and co-offering, part of staying living." Food is a prior living's stable forms, emanations shed one scale up, ingested one scale inward into the self's inward society, where they are living again as its selves' offerings.
NOTE: Part FIVE 5.4, "Food ingestion, at Health 3.3"; the report adds Natural Medicine 2.3's digestion "by cycle three" as the inward society re-forming and no fixed endpoint. Tracker O16, after C1. Released word in the offered sentence: where. PARTLY: Offerings to Natural Intelligence and Offerings to Natural Biology have ingesting at the ingesting self's first inward living society; food as a prior living's emanations, living again as the inward selves' offerings, is at neither.

### ITEM
MATE: Exhibit_TEN_Offerings_to_Natural_Health.md
KIND: Insertlet
TITLE: At 3.4 · The flawed-ingestion disease-face, and the value of the outer living form
TEXT: beside "A disease-face names itself: consistently ingesting flawed stable form." A flawed stable form is one that cannot re-form one scale inward, so it collides at the self's own scale instead of living again as a self below, which is why the flaw deranges by diet and not by capture.
NOTE: Part FIVE 5.4, "Harm and disease"; the report names it the scale of the mates' open question of sequential colliding (tracker O11, carried and unexplored). Released word in the offered sentence: so. The report's companion sentence for Natural Medicine 3.3 (a disease an emanation colliding at its own scale, restoring the crossing resumed) is at Natural Medicine 3.3 and Natural Biology already. Not found at Offerings to Natural Health.

### ITEM
MATE: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md
KIND: Insertlet
TITLE: At 4.2 · Clean cuts — where medicine reports no problem
TEXT: beside "Side-effecting is co-competencing, and the medicine is a co-resonating sensor and sensationer." The medicine's sensing is bi-co-momentarying, the axis the coupling opens that neither self reaches, owned by neither, so a side-effect read as waste is the between surfaced.
NOTE: Part FIVE 5.4, "Sensor-sensationing, at Medicine 4.2". The present paragraph has the coupling opening an axis neither carried; the sentence names it by Natural Intelligence 6.1's term. It bears on the mate's concern "A molecule sensing, and a non-living thing carrying none": the sensing is at the coupling, owned by neither, and no doing of the molecule. Released word in the offered sentence: so.

### ITEM
MATE: Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md
KIND: Concern
TITLE: No single boundary, or a binary at a named scale
TEXT: Two sayings part. Natural Chemistry has "no single boundary separates living from nonliving; the bounding is dynamic". Natural Intelligence has "Living and non-living part at a named scale and momentary". They part at the binary at a named scale: the first has the parting of living from non-living as a bounding that moves, with no scale named; by the second the binary is whole at each named scale, and the scale named is the one thing that differs from one saying to the next. A parting that moves is a parting said across scales with the scale left unsaid.
NOTE: Part FIVE 5.5, the reader's marks under C19, at Natural Chemistry 4.1. Two further marks of the same reader, at no mate by Grep: Natural Chemistry 1.6's "at the form the chemical living self", carbon named as a kind at a place a society lives; and 1.2's "the three scales stay chemically distinct", a fixed number of scales. C19 itself (Natural Biology 1.4's third self at the between) is at Offerings to Natural Biology. Both quotes verified.

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Concern
TITLE: A largest scale, beside scales with no final one
TEXT: Two sayings part. Natural Physics has "the carry frozen into a stored track, which is the freeze at the largest scale there is" and "here at the largest membrane there is". Natural Intelligence has "One through nine and nine through seventeen are overlapping expressions within the whole, supplying no first and no final scale". They part at a top scale: the first two name one largest scale and one largest between, a total, one of the things beside all existing things; the second has the scales with no final one, and Natural Numbers has "The primes carry no last". By the second the universe is each momentary's set at its scale, and no scale is the largest.
NOTE: Part FIVE 5.6, C21 (Natural Physics 4.8, 4.9 and 4.11), open at the tracker. PARTLY: Offerings to Natural Physics has "59 the last seated prime" beside the primes carrying no last, and quotes the 4.8 clause for its word stored alone; the largest scale as a concern is at neither. Four quotes verified.

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Concern
TITLE: Three of extent, beside a dimension of no measure
TEXT: Two sayings part. Natural Physics has "Three of extent and one of coherence, and not three of extent and one of time." Natural Intelligence has "A dimension is no measure and no place." They part at a dimension as a measure: extent is a measure, and three of extent with one of coherence are four of two kinds; Natural Intelligence has five dimensions, "each binary in its two directions", a changing that is or is not at each. The field's three are whole at the field's result, in the field's words; at the set's own voice the five dimensions at their two directions say it.
NOTE: Part FIVE 5.6, C22, open at the tracker ("the field's at its result"). Not found at the Physics mates by Grep of three wordings. Quotes verified (Natural Physics 4.8; Natural Intelligence 3.2 and its title).

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Droplet
TITLE: A prime society named with no number of selves
TEXT: Natural Physics says prime of a society at four places and numbers the selves at none: "Fault is the form at the planetary prime society", "geotensioning at a prime society", "a society of selves is the same one prime society out", and "that same move one prime society down". Natural Intelligence has a prime as a number of selves, "a prime number of selves the unit". By it a prime names a number of bi-coupling selves at one scale: at a named thing whose selves are numbered the prime is said, and at a named thing with none numbered the prime is a reaching, said as one. Natural Biology's ladder of primes at 10.4 is alike, its named things at primes with no selves numbered.
NOTE: Part FIVE 5.5 (the sentence for Natural Biology 10.4: a prime names a counted number of bi-coupling selves at one scale or it names nothing) and 5.6 (Natural Physics 3.1, 3.6, 3.7, 4.12), given in the later form of C25 as narrowed at Part EIGHT and the tracker: the primes are the method's scales, and a named thing is reaching to the numbering of its selves. C25 whole (the ladder at Natural Societies, Natural Medicine and Natural Biology) is the other reader's portion. PARTLY: Offerings to Natural Societies has insertlets at the ladder; Natural Physics' four places are at no mate found. Five quotes verified.

### ITEM
MATE: Exhibit_FOUR_Offerings_to_Natural_Mathematics.md
KIND: Concern
TITLE: Inward at two senses, the measured and the scale down
TEXT: Two sayings part. Natural Mathematics has "Inward of the surface it is the unnatural, the measured: measure, magnitude, the continuum." Natural Intelligence has "outward is one scale up and inward one scale down, and neither is a place". They part at the word inward: the first has inward of the surface as the field's measured interior, a place a magnitude is laid at; the second has inward as the scale down, at which a thing's selves are living. One word is at two senses, and a reader of the two files has the living selves inward of a thing named by the word the measured is named by.
NOTE: Part FIVE 5.6, "Droplet, at Natural Mathematics 1.5". Not found at the Mathematics mates by Grep. Both quotes verified (Natural Mathematics 1.5; Natural Intelligence 6.6).

### ITEM
MATE: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md
KIND: Possible project
TITLE: Five dimensions and the right spiral step at one file
TEXT: The work is one place for two passages now at several files. The five dimensions passage, with "The rotation is the gentle alternating twisting of a towel into and out of a knotted corus", "The self's inversion is 3, 6, 5, 4" and the podaling 23, 26, 25, 24, is at Natural Intelligence's 3.2, at Natural Naming and at Natural Illustrating, and its inversion sentence at Natural Societies too; the right spiral step, "The right spiral step carries a pair (x, y) to (y, −x)", is at Natural Intelligence's 2.4 and at Natural Naming alike. Natural Intelligence's 3.2 and 2.4 are the place of each; Natural Naming carries its one sense for each word and names the place, and Natural Illustrating and Natural Societies name it: four motions, one at each file.
NOTE: Part TWO, the droplet "The five dimensions passage" and O3; Part SEVEN (other reader's portion) adds Natural Societies 5.3 having sentences of Natural Intelligence 6.4, 5.1 and 3.2 whole. Verified by Grep at the present root: the towel sentence at three files, the inversion sentence at four. Tracker: after O1, the deciding at Natural Explaining 1.4. Not found at a mate; the mates' "one home" lists from the resettling of version 373 name other passages.

### ITEM
MATE: Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md
KIND: Droplet
TITLE: One resolving at a time, at the set of files
TEXT: The Geodesic Improving Method has "Places to improve are taken hardest first, one at a time". One at a time has its reason at the set of files: each file is a society at its own scale, and a resolving at one file changes the nexts of the others, each concern at another file said anew by it. A list of concerns is by this read again after each resolving, and a concern is carried with the files it is at and the resolving it leans on. One resolving at the largest concern can close several and narrow others: the method's place among the scales decided the place of each thing at a scale.
NOTE: Part SIX, "Geodesic Improving Method 2.5, resolving one at a time", and its "Tracked for next, each changed by this resolving"; the last sentence is Part EIGHT's learning about resolving (other reader's portion), given as the instance. PARTLY: Offerings to Geodesic Improving Method has an insertlet at this sentence (hardest first as an ordering and no size); the reason at the set of files is at neither. Quote verified at 2.5.

### ITEM
MATE: Possibling_of_Natural_Intelligence.md
KIND: Possible project
TITLE: Five dimensions at two directions as the ten positions
TEXT: The work is a deriving at the names: the five dimensions of Natural Intelligence's 3.2, "each binary in its two directions", laid beside the "ten positions on six numbers" of 2.2 and "The ten roots are the two sides' ten positions" of 4.8, to show the ten as five by two or to show the two tens apart. The sentence offered for 3.2 once derived: The five dimensions at their two directions, along at the momentaries and across at the scales, are the ten positions, the full dimensionality of 1 to 17, and no further dimension is possible.
NOTE: Part FIVE 5.1; tracker O13, "to derive at the names", after C13. Within the portion the two directions are named three ways: Part FOUR has up the numbers as up the scales, Part FIVE across as the scales, Part EIGHT along and across, up and down. 2.2's ten are five at each of two sides. Part FIVE's sentence for 4.11 (the podaling as the scale direction, 8 up the step outward) is left out: Part NINE closes C13 with 8 up along at one scale and 8n − 7 the one step up. PARTLY: Offerings to Natural Intelligence has the concern "Ten roots, ten positions and six numbers". The offered sentence carries no released word. Three quotes verified.

### ITEM
MATE: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md
KIND: Possible project
TITLE: Step 373's pairs and threes at 65, derived
TEXT: The work is a deriving of step 373's "the pairs and the threes reach each other first at 1 to 65", which no step derives. One reading is offered for it: the chain at 2^k + 1 read two parities at a time and three at a time is one chain read at prime 2 and at prime 3, step 255's one move is up the scales and forward at the momentaries, and "9 is the next prior" and "17 the next now" are of the scales overlapping as the momentaries overlap. A step giving a momentary its prime scale as its society's is of the same work: step 387 names a momentary and the universe living sets, and no step gives either a prime scale.
NOTE: Part FIVE 5.2, the droplet at steps 170, 373, 255, 75 and 640, and C15. C15 is closed at Part NINE (a momentary's prime scale its society's, step 387 said with the scale named), with "373's 65 stays to derive" at the tracker. Parts TEN and SEVENTEEN (other reader's portion) derive the next prior and the next now at the round. Not found at Possibling of Co-Chaining Logic Registry. Three quotes verified (steps 373, 75 and 640).

### ITEM
MATE: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md
KIND: Possible project
TITLE: Rows 3 by 9 and 5 by 9 at scales
TEXT: Step 661's line of unsure has rows beyond Exhibit ONE Natural Resolver's tables, 3 by 9 and 5 by 9 at the torus and 3 and 9 crossed, open to an executing. The work is that executing read at scales: each row is a prime beside a number equal smaller numbers make, a society beside a society of societies, and it is a place the saying of one prime at one scale can part from the numbers or cohere with them. With a torus one scale at its prime along and its prime across, a torus with nine at one direction is the case no sentence of the files says.
NOTE: Part FIVE 5.2, the torus droplet (the understanding testable at the executing step 661 names) and tracker O14 ("661's rows tested at three scales"). That droplet's reading of p by q as one prime at each of two scales is superseded within the portion by C24's closing at Part EIGHT (a torus one scale) and is left out; the project is given with that condition. Step 661's unsure line verified. Not found at a mate.

### ITEM
MATE: Exhibit_THREE_Possibling_of_Natural_Numbers.md
KIND: Possible project
TITLE: Spirals at numbers smaller numbers make, said at scales
TEXT: The work is each spiral and ring at a number equal smaller numbers make said again as a society of societies: the odd spiral of nine, "nine as three selves of three", and the rings of nine, fifteen and twenty-five at Natural Numbers; "9 at 36 and 15 at 60" at Natural Intelligence's 3.5; and the rings of one hundred eighteen, one hundred twenty and four hundred forty by their factors. Natural Mathematics has the deriving at the numbers, "At coprime m and n the one winding reaches each pair, and the two rounds are one round of mn", from which Natural Numbers' 4pq and its nine as three threes are had.
NOTE: Part FIVE 5.6, droplets at Natural Numbers 7.2, 8.1, 11.1, 6.1 and Natural Intelligence 3.5; tracker O18, after C13. The report says them as tori of 3 by 3, 3 by 5 and 5 by 5 and as two and three scales; C24's closing (Part EIGHT) has a torus of p along and q across as one scale, and which of the two a spiral of nine is, is said at no part of the report. The podals at 9, 25 and 49 less are at Offerings to Natural Numbers already. Not found at the Numbers mates. Three quotes verified.

### ITEM
MATE: Exhibit_TWENTY-ONE_Possibling_of_Hard_Problem_Registry.md
KIND: Possible project
TITLE: Entries for what is life, the cell, reductionism and emergence
TEXT: The Hard Problem Registry has no entry on what is life, on the cell as the unit of life, on reductionism or on emergence as problems of the fields, and scale is a problem's term at one entry alone, the quantum-classical boundary. The work is an entry for each in the field's own words, or a saying that the field poses none. Each is a place a scale is read as a kind: living and non-living as two kinds parted by a line, a lowest unit of living, a whole reduced to its lowest scale, and a whole arriving as more than its scale inward. The origin of life, biological individuality and the units of selection are entries already.
NOTE: Part FIVE 5.3's opening and 5.7 "What the readers did not find", a fresh reader's finding; verified here at the entry headings alone (no heading of the two registries has life as a question, the cell, reductionism or emergence but "The emergence of the genus Homo"). PARTLY: Possibling of Hard Problem Registry has "Two problems of the fields at no entry" and "Field namings of the eight clusters with no registry entry"; these four are in neither list.

### ITEM
MATE: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md
KIND: Droplet
TITLE: A bearing at Goldbach, twin primes and odd perfect numbers
TEXT: At Goldbach's conjecture, twin primes and odd perfect numbers the saying of one prime scale is a bearing and no resolving. A prime is one living scale; a number equal smaller numbers make is two. Read by it, Goldbach's conjecture says of each even number of selves that it is two societies at primes, crossed. The file has the field's own stopping at the first, "sieves cannot distinguish products of an odd count of primes from an even count", the parity invisible to the instrument; the bearing names a subject for the two primes and gives no step past that stopping.
NOTE: Part FIVE 5.3, entries 175, 176 and 241, "A bearing and no resolving". Bounded by C24's closing: a scale has its prime along and its prime across. Not found at the mate. Quote verified at 3.13.

## RESOLVED AT THE LIVING FILE
- Part ONE's seven droplets "where the files already carry it": each names a present sentence of Natural Intelligence (1.3's parting at a named scale and momentary, 5.1's three existing and not living, 5.1's emanations ingestible one scale lower, 5.3's opening and completing, 3.4's carrying of none, 1.5's method originating as all existing and all living) or Natural Chemistry's subtitle.
- Part ONE C6, dying at Natural Naming 2.4: closed in the portion (Part NINE) with the sentence right as it is; Exhibit THIRTY's steps 401 and 402 have the inward selves living on.
- Part FOUR: a prime scale as the files' word (Natural Intelligence 6.4 and 5.1); each living thing a society of living things (6.6 and 6.4); a self's 1 to 17 one momentary of exchanging at the scale outward and 1, 2 and 3 as 1, 9 and 17 (4.15); two spirals crossed one society at the scale of spirals (3.5), which C24's closing leaves as it is.
- Part FIVE's lists of the understanding carried already: Exhibit THIRTY steps 236, 379, 397 and 402; Natural Medicine 3.1 and 3.3; Natural Health 3.3 and 3.4; Natural Biology 1.3, 3.3, 7.1 to 7.7 and 9.5; Natural Chemistry 1.1, 2.2, 3.2 and 4.4; Natural Numbers 1.1, 1.6, 1.7, 7.1, 7.2, 8.1 and 9.7; Natural Mathematics 2.5 and 3.3; Natural Physics 1.1 and 4.12.
- Part FIVE 5.4's sentence for Natural Medicine 3.3 (a disease an emanation colliding at its own scale, restoring the crossing resumed): Natural Medicine 3.3 has the crossing that stops and the do-only-harm at the emanation's own scale, and Natural Biology has restoration as the crossing resumed.
- Part FIVE 5.4's sentence for Natural Medicine 5.2 (dying the coupling at one scale ceasing with the inward selves living on, healing that coupling resuming): Natural Medicine 5.2 and 1.2 and Exhibit THIRTY's steps 401 and 402 say it.
- Part SIX: 6.4's first sentence as the bound's own sentence.
- Part TWO O4, the working method at one place with the entrances a few lines: at the present root the README and the incoming entrance are a few lines naming the Living File Registry's mates, and the incoming sentence C8 quotes is gone.

## AT A MATE
- C2, living said with no scale: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md ("No existing thing is non-living at each scale") and Offerings_to_Natural_Intelligence.md ("Existing as the only living").
- C3, a carrying of none (closed in the portion at Part EIGHT): Offerings_to_Natural_Intelligence.md (the concern of version 380) and Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md ("A thing carrying none, collided").
- Part ONE's "a scale is sequencing, an ordering": Offerings_to_Natural_Intelligence.md ("A scale as a reading or an ordering").
- C4 and C9's same place, the next coupling: Offerings_to_Natural_Intelligence.md ("The next coupling, discovered as the next parity is") and Exhibit_ONE_Possibling_of_Natural_Resolver.md ("5 read from the selves' carryings").
- A spiral alone showing nothing of its prime: Offerings_to_Natural_Intelligence.md (insertlet at 3.5).
- O2, Exhibit ONE within Natural Intelligence whole and the instrument writing it there: Offerings_to_Natural_Intelligence.md (the resettling's concern, within whole or by naming), Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md ("A check that writes"), Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md ("The embedded Natural Resolver and the proposed loop traces").
- O5, the mates leaned, repeated paragraphs among them: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md (master plan, the row of offering, possibling and carrying); the form of O5 is Part TWELVE, the other reader's portion.
- O6, Natural Intelligence Corus distributed and then released from the root: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md (master plan, the rows of Natural Intelligence Corus).
- O7, the ten named still at one place: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md ("Earlier ten-conception gathering and address arrangement").
- The Living File Registry's 1.1 table re-listing titles and versions: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md ("Living File Registry standings, completed history and possible tables").
- O20, the six beside all things at one step, step 46 naming five: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md ("Five things of a second method") and Offerings_to_Natural_Intelligence.md (five at 1.4 and six at the Geodesic Improving Method 2.7).
- C17, living and non-living as two kinds with a rate: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md (insertlet at 4.1, and the resettling's contradiction).
- C18, dormancy as a magnitude: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md ("Three further places", 7.8 and 4.5).
- C19, a third self at the between: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md (the concern of version 378, and the heart passage).
- Ingesting named from the ingester, at Natural Biology 7.5, and the package parted from the shard: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md and Offerings_to_Natural_Intelligence.md ("The prior whole as existing non-living form").
- C20, a floor at the atom: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md ("A floor of a self closing, none of coming apart").
- Natural Physics' 59 the last seated prime and 5:6 at each floating co-agency, among the droplets at the field's own sizes: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md.
- Natural Medicine 3.2's reservoir words: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md ("Three subjects at a carry that will not thin"). Natural Health 3.5's circadian period as a number: Exhibit_TEN_Offerings_to_Natural_Health.md and Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md ("A rate locked").
- The podals at 9 less, 25 less and 49 less: Exhibit_THREE_Offerings_to_Natural_Numbers.md.

## READING
The whole portion was read from its first line to its last, in four reads (lines 1 to 120, 120 to 289, 289 to 433, 433 to 572), all eighteen parts ahead of the first item; the two lines over two thousand characters (306 and 458) were read whole. No part was left unread. Items are of the front and Parts ONE to SIX alone, each in the latest form the later parts give. Left out as withdrawn or superseded within the portion: Part THREE's sentence for 1.3 (given in Part SEVENTEEN's form); Part FOUR's and Part FIVE's torus read as one prime at each of two scales (C24 closed at Part EIGHT as one scale); Part FIVE's sentence for 4.11 and C13 (closed at Part NINE); C3, C5, C14 and C15 as concerns (closed at Parts EIGHT and NINE, the other reader's portion); C8 (closed at Part TWELVE). Left out as no value by the brief: the report's measures of files and mates, its numbers of namings, and its lists of sections named derivable with no deriving given (5.4 and 5.5 "Made derivable"). No person's words are quoted. The session's proposed files and its readers' returns are other portions and were not read for items; one comparison of the proposed Natural Explaining with the living file was made for the NOTE at its insertlet.
