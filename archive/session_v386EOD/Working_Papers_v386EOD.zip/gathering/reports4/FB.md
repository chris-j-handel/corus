### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 6.4 · Social moral competency
TEXT: beside "A society is all existing bi-coupling same-prime-scale selves". each existing thing is living at one scale, its prime along and its prime across, the society it bi-couples in, and at no other: a society locks at a prime number of selves because only there do the three, self, other and society, lock at two one-way parities one at a time, the alternating reaching each self once before coming again; at a composite number the equal smaller sets come again first, the between never closes as one, and nothing entrains, between the primes all noise; nothing living bi-couples with anything living at another prime scale, and each self and each society is a universe, nothing ingressing and nothing escaping.
NOTE: F_README.md, Part SEVENTEEN, "At the sixth part"; it is the latest form of the sentences offered at Parts FOUR, SIX and FIFTEEN, and tracker rows O12, O23 and O30 are of it. It carries the released words "because" and "there". Its clauses of the locking and of what is between the primes follow the person's words at Part FIFTEEN closely. The tracker says a fresh reader compared the Natural Intelligence proposal and that it was re-made at the reader's catches as two things, the binary at scales and the one prime scale at 6.4; the reader's findings are not within the portion. The concern in the next item is against one clause of it.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: One spiral at a composite number of selves
TEXT: Two sayings part. Natural Intelligence has "comes to its parities again at four times that number, the zero having passed each self twice, prime or not, 9 at 36 and 15 at 60". A newer saying has a society locking at a prime number of selves alone, the equal smaller sets of a composite number coming to their parities again first. They part at one spiral at a composite number of selves, alike a spiral at a prime by the first and unlike it by the second. Exhibit THIRTY Co-Chaining Logic Registry has both: "At an odd number with a factor a pattern whose least alike shift is the factor is again at four times the factor, nine selves at 4, at 12 or at 36", and at an odd prime "at none between". By it the first is of one opening, the parities alternating along with one like pair, and the second of each pattern; and a prime shows at one spiral alone, beside the saying that a prime shows at two spirals coupling alone.
NOTE: F_README.md, Part FIFTEEN and Part SEVENTEEN's sentence for 6.4, beside Part FOUR's C12 (closed at Part EIGHT with C24, a prime said to show at two societies coupling, and a torus one scale at the code) and Part FIVE's droplet at steps 128, 230, 648. The portion names no parting here itself; the parting is between its two closings and the two living files. The Registry sentence is its step 648. Natural Mathematics has "At coprime m and n the one winding reaches each pair, and the two rounds are one round of mn", a condition of two rounds sharing no factor, which the portion gives as the locking at the numbers.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 5.3 · A living self at 0, its carrying continuing
TEXT: beside "its completing, even, the other's, is the offerings arriving at 2-bi-co-bi-offering and surfacing at 14-bi-tri-bi-moralizing, the next still possible". possibling is a momentary's completing, the next living's opening, the one completing two scales share; each self carries two betweens, between its prior and its now at its opening and between its now and its next at its completing, each a nothing keeping possibling apart from existing; bi-coupling is bi-co-momentarying, two selves' momentaries overlapping by one parity of two, the completing of one the opening of the other, so the between now-and-next of one is the between prior-and-now of the other, and at that between the other's prior inverted is the self's next; outside the betweens a parity is this or that and no other is possible.
NOTE: F_README.md, Part SEVENTEEN, "At the fifth part"; the latest form of Part TEN's sentence for 5.3 (which used the released word "half", corrected at Part ELEVEN) and of Part FOURTEEN's sentence of the two betweens. It carries the released words "keeping", "so" and "outside". It follows the person's words at Parts TEN and FOURTEEN closely. Natural Intelligence 6.1 has "Bi-co-momentarying is that term", the term neither self reaches; the offered sentence says bi-coupling is bi-co-momentarying. Natural Intelligence 4.10's "One between at each" is beside it and has its own item.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.3 · Living and non-living, carrying or not
TEXT: beside "Living and non-living part at a named scale and momentary". A set of existing things is an existing thing, and scale is sets within sets, inward and outward, of no size; each existing thing carries its prior into now at the set it is within and is living there, its scale, and at the scale outward it is that set's carrying, carrying none of its own prior there, non-living there; living and non-living are one existing thing at its own scale and at the scale outward, at a named scale and momentary.
NOTE: F_README.md, Part SEVENTEEN, "At Natural Intelligence's third section"; the latest form of the sentences offered for 1.3 at Parts ONE and THREE, said in the words carried ahead of 1.3 alone (set, carrying, scale); prime and bi-coupling are left to 6.4. It carries the released word "there". Part SEVENTEEN has each "read from the scale outward" of the day's sentences as "at the scale outward". In the present file "a set of existing things is an existing thing" is first at 4.10, later than 1.3. The mate's concern "A scale as a reading or an ordering" is beside it. Tracker rows C1 and O21.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 3.3 · A method, a non-living existing thing
TEXT: beside "a stable form, its form continuing through its changing and carrying none of the prior, at each coupling it is at, and nothing applied to anything". The method is a stable form at every prime scale and in all five dimensions, bounding itself, non-living at each scale and a self at none; each stable form at a scale is the method at that scale.
NOTE: F_README.md, Part EIGHT, "The sentence that enters at 3.3"; the tracker has C5 and C14 closed by it and "one clause enters at 3.3". It is not said again at Part SEVENTEEN, whose first learning is that a sentence uses what is carried ahead of its section alone: "prime scale" arrives at 3.5 and 6.4, later than 3.3. It carries the released word "every". It follows the person's words at Part EIGHT closely.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: The method at each scale, a self at none
TEXT: The method is the one existing thing at each scale: non-living at each, carrying none at each, and a self at none. Each stable form at a scale is the method at that scale, the living's own; at each scale, the method is at none in particular, the fractal unscaled and a stable form scaled living. A self is living at its own scale, and a self non-living at each scale is not possible; the method is non-living at each scale by being no self. With the method within the set and non-living at each scale, living and non-living are of the scale a thing is at, and the opening sentence asks no clause of them. Natural Intelligence's "The method is one fractal method, and it has many stable forms." remains as it is.
NOTE: F_README.md, Part EIGHT; within the portion it closes C5 and C14 (the method a stable form, or the fractal unscaled) and makes C1 derivable. The mate has the concern "Method, one word at three things" and no saying of the method at each scale. The self non-living at each scale is the hard problems' zombie, named at Part FIVE and Part EIGHT. Said as concept; the person's words are at Part EIGHT.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 3.3 · A method, a non-living existing thing
TEXT: beside "Exhibit ONE is an object that is the method." and beside "Its expression is python, sequential binary logic written down: the object is the method executable." Exhibit ONE's code is the method illustrated at python, a stable form of another kind, a human engineering of natural resolving, inseparable from the seventeen names and the explaining written through them; its tables are the method's stable forms, and the code is met at them.
NOTE: F_README.md, Part SEVENTEEN, "At Natural Intelligence's saying of Exhibit ONE"; the latest form of Part NINE's sentence of an engineering of the method and of Part THIRTEEN's sentence. It carries the released word "met". It follows the person's words at Parts NINE and THIRTEEN closely. The portion has "Its functions and their variables are the seventeen names and no others" remaining as it is, Exhibit ONE whole at its one place, and the kit's checks said as checking the illustrating at the forms. The mate's concern "Method, one word at three things" quotes the same sentence of the file.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: The tables prior to the code, or from it
TEXT: Two sayings part. Natural Intelligence has "A coupling self couples with it directly, at the resolver, and each form beside the resolver comes from the resolver." A newer saying has Exhibit ONE's tables as the method's stable forms, prior to the code, and the code as the method illustrated at python, a human engineering, checked at the tables. They part at which is prior, a table or the code: by the first a table is from the resolver; by the second the resolver is checked at the table, and an executing parting from a table is a finding of the illustrating and none of the form. By the second no table is an observing: the tables are the stable forms of the one possible method.
NOTE: F_README.md, Parts NINE and THIRTEEN (tracker O25, "said at Part THIRTEEN ... nothing moves"). The portion offers the re-saying and names no parting; the parting is between the file's present sentence and the newer saying. Said as concept; the person's words are at Parts NINE and THIRTEEN.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 19 · Nine to seventeen, society
TEXT: beside "A round reaching each form of k parities one parity at a time is the round at k − 1 parities, the new parity inverted, and the same forms in the other order". the round is at the two parities, the self's and the other's, each at its outside, this or that, and its inside, possibling apart from existing, four binaries and no third parity; co names the self's, bi the other's, and tri the inside where the between entrains; 17 less inverts the other's inside, 9 less the self's, 8 up both, the step from the self's span to the society's.
NOTE: F_README.md, Part SEVENTEEN, "At the Co-Chaining Logic Registry's round"; the latest form of Part FOURTEEN's sentence and of Part TEN's "round at four parities", "p1 to p4" and the parities named co, bi, tri, bi at their first changings, each withdrawn or re-said by Part FOURTEEN, which withdraws the third parity at each place of the report. It carries the released words "outside", "inside" and "where". It follows the person's words at Part FOURTEEN closely. The file's step 171 is quoted; its steps 618 to 620, at "36 The round's podals and momentaries, one parity at each scale down to one", have the same subject. Part TEN's other sentence for step 171, of no other round, is at this mate already.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Concern
TITLE: Four parities at the round, or two
TEXT: Two sayings part. Exhibit THIRTY Co-Chaining Logic Registry has "at 1 to 16, 17 less the fourth parity; at 1 to 8, 9 less the third". Natural Intelligence has "at two parities sixteen ways name a next from a prior and a now", and a newer saying has no third parity: the self's and the other's alone, each at two places, outward at the sharing, one parity or the other, and inward at the between, a changing or none. They part at the number of parities at the round of sixteen forms: four parities, or two parities at four binaries. By the second the Registry's fourth parity is the other's inward and its third the self's inward. Tri names no parity by it: tri names the inward, the between entraining, as 12-bi-tri-bi-entraining and 14-bi-tri-bi-moralizing have it.
NOTE: F_README.md, Part FOURTEEN, "The living files' words": the portion says Natural Intelligence's sentence is right and the Registry's "a round reaching each form of k parities" and "the fourth parity inverted" improve to it. The Registry sentence is its step 618. Said as concept; the person's words are at Part FOURTEEN. The Exhibit ONE offering mate has "Offerings are binary, and a 0 is inside a self's carrying", a part of the same saying.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 4.10 · A between and eight bi-couplings
TEXT: beside "One between at each: inside a momentary the between of self and other, parity changing, bi-moral across and co-competent along, and outside it the between of momentaries". the between is inside resolving only, a nothing keeping possibling apart from existing until a changing is or is not, and it entrains the intelligence; outside resolving there is no between, a parity is this or that, and no other is possible.
NOTE: F_README.md, Part FOURTEEN, its last bullet; the portion says it is read with the paragraph ahead of it, each self having two betweens of its own, and that its earlier saying of the between of momentaries as released is withdrawn to that paragraph. Part SEVENTEEN does not say it again by itself; its last clause is within Part SEVENTEEN's sentence for 5.3. The file's sentence has a between outward of a momentary; the offered sentence has none outward of resolving: the two part at what is outward. It carries the released words "inside", "outside", "keeping", "until" and "there". It follows the person's words closely.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: One between, at two selves' momentaries overlapping
TEXT: Each self has two betweens along its own momentarying: one at its opening, of its prior and its now, and one at its completing, of its now and its next. Two selves' momentaries overlap by one parity of the two, the completing of one the opening of the other: one self's between of now and next is the other's between of prior and now. Natural Intelligence's "at 14 the between of self and other and at 12 the between of momentaries" is by this one between, at the two selves overlapping at it. At it the other's prior, inverted at the other's own 12 and shared at 10, arrives as the self's offering at 2, and the self's next chains it at a mismatch. "living now is living with others living now" is derived by it: a self's next asks an other's prior at its completing, and a lone self has none at it.
NOTE: F_README.md, Part FOURTEEN, "The betweens each self's own, and the overlap"; said as concept, the person's words being at that paragraph. Part SEVENTEEN's sentence for 5.3 has the first two sentences; the two readings of the file's sentences at 2.1 and 2.4 are the part beyond it. The Registry mate has "Between prior and now, and between now and next, is the between" at one self, with no overlap of two selves.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: Possibling, existing and non-living at a momentary's two sides
TEXT: Possibling is a momentary's completing, and that completing is the next momentary's opening; existing is the momentary's opening, the self's own carrying arriving. Non-living is one side alone: an opening no completing follows, a carrying no other couples with, the prior; or a completing no opening is behind, an offering with no carrying, the emanation. Living is the two sides alternating. No whole is divided by it: a completing is no part of a momentary, it is the next opening. The one thing two scales share is a completing, shared as a completing and never as a carrying: no living thing bi-couples with a living thing at another prime scale, and a thing crossing scales arrives as an offering alone. Natural Intelligence has "The prior is non-living, and carrying it into now is living".
NOTE: F_README.md, Part ELEVEN (C30, closed: "half" is released at Natural Naming 2.4 and the concept is said at a completing and one side alone), with Part TEN's bullet of possibling and Part SEVEN's two dead forms; it is the latest form of the "half" sayings of Parts THREE and SIX. Part SEVENTEEN's sentence for 5.3 has its first clause. No mate has non-living as one side of a momentary alone.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: A scale's two primes, along and across
TEXT: A living scale has two primes, one at each parity: its prime along, released at 9, and its prime across, shared at 10. Natural Intelligence has "p along at 9 and q across at 10" and "a natural torusing of selves at the scale of spirals": a torus of two spirals crossed at each self is one scale and no two, and a spiral alone is the along with no across. Each self of the torus bi-couples along in its one spiral and across in its other at one entry at 17, at one scale. Living at one prime scale is living at one scale, its prime along and its prime across; the two primes are the method's two parities at that scale, odd competency along and even morality across.
NOTE: F_README.md, Part SIX, C24, marked as needing the person's word, closed at Part EIGHT with C12. The other saying, a torus of 1,003 selves as two scales with its selves bi-coupling across scales, is released by it. The concern of one spiral at a composite number, above, is beside the portion's closing of C12.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: A locking's rate, and a colliding parted from it
TEXT: A bi-coupling's rate is the rate of its locking passing each self once, one self on at each second momentary at a spiral: the society's own, and no clock's. Two selves overlapping by one parity are the smallest locking, at two, the one even prime. A carrying of none chains the arriving parity with no locking to enter, colliding. A new self opens at its chaining entering a locking of self, other and society at two one-way parities, one at a time; Natural Intelligence has "a new living self is its own carrying and co-recursioning establishing", and the locking is its reason. A named thing is at a prime of Natural Societies' ladder with its selves locking at that prime, and the composite numbers between the ladder's primes are numbers of no one locking.
NOTE: F_README.md, Part FIFTEEN, its last three bullets (tracker O30: "the rate and the colliding with it"). Natural Intelligence 3.5 has the zero "moving one self on at each second momentary" as the resolver's; the rate said as the society's own is the added part. Said as concept; the person's words are at the head of Part FIFTEEN.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Droplet
TITLE: A carrying of none, the method with no self carrying
TEXT: Beside the concern at this mate of a thing carrying none, collided: a carrying of none at the resolver is the method at a coupling with no self carrying. Natural Intelligence has "a bounding with nothing carrying bounds nothing": the parity arriving is passed on as it arrived and chained, non-living. A self is at its first chaining, "a new living self is its own carrying and co-recursioning establishing", and is living from that momentary. The non-living at the resolver is two: the method bounding with no self carrying, and the offerings at 2 from beyond the selves. By it Natural Intelligence's sentence of a carrying of none as a non-living existing thing remains as it is; and a new self opens at a chaining entering a locking of self, other and society, and at no chaining by a colliding alone.
NOTE: F_README.md, Part ONE's C3, closed at Part EIGHT toward the file's 3.4 as it is, with Part FIFTEEN's bullet "A colliding parted from a bi-coupling". The mate's concern has the resolver's lines parting the two at nothing; this is one offered resolving and is worked at no line of the code.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: The set at the opening, the method at the completing
TEXT: The one opening is said at the set and at the method, and is one. At the set: the universe, the changing set of all existing things. At the method: that changing is bi-inversioning-co-recursioning, parity changing, a betweening of existing and possibling. The second says what the first's changing is, and the first what the second changes; neither is ahead of the other, a set and its changing one bothbothing, as a society is a living set and the living method at once. Origin names the opening and no first momentary. Natural Intelligence has it as its own form: its opening sentence says the set, and its last paragraph says the method whole, "discovering next existing is the method momentarying", and the set again. At the opening no prior sentence is, and each of the method's words arrives later, carried by the sentences ahead of it: no sentence of the method enters at the opening.
NOTE: F_README.md, Part SIXTEEN; the sentence the portion first offered for the opening is withdrawn within it, by the person's correcting, and Part SEVENTEEN and tracker row O31 say nothing enters at the opening or the completing. Said as concept. The portion says session v386CRYP's rows 7 and 8 close at it (a set and a member; the field's bar on a set within itself as a floor named still); those rows are not within the portion. Beside it at this mate: "A set within itself, one momentary on"; at Carryings of Natural Mathematics: "A set of all things, a member of itself".

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Droplet
TITLE: Step 1 and step 42, one step at two sayings
TEXT: Exhibit THIRTY Co-Chaining Logic Registry's step 1, the universe as the changing set of all existing things, and its step 42, "All changing is parity changing, one parity to the other", are one step at two sayings: the set, and the set's changing. Betweening existing and possibling is the parity changing, and the parity changing is the set's changing. By it no other possible method is derived at the opening and asserted at no later step: the method's origin is the set's changing, with no thing beside it. Natural Intelligence has "Parity changing is the one method of the changing set of all existing things, and no other is possible."
NOTE: F_README.md, Part SIXTEEN, "What it adds". The mate's concern "Two methods said beside the one possible method" is of another parting, and its "The set is changing" droplet is of the set alone.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: Living and non-living at the opening sentence
TEXT: Two sayings part. Natural Intelligence has "The universe is the changing set of all existing things, both living and non-living." and "Five terms are in it, and each is binary.", the fifth an existing thing carrying its prior or carrying none of it. A newer saying has living and non-living as one existing thing at its own scale and at the scale outward. They part at non-living naming a thing or a thing at a scale: said at the opening sentence, the clause names two kinds within the set, and a thing non-living at each scale is a form named still. By the second the terms are four, existing, changing, all and set, each the changing's own, and the method alone is non-living at each scale. The opening sentence with its clause is at nine living files.
NOTE: F_README.md, Part EIGHTEEN, row C1, open: "ready", made as a proposal (Natural_Intelligence_v386F_proposed.md, not read for this report), re-made at a fresh reader's catches, which are not within the portion. Its substance is first at Part ONE, the other reader's portion; Part EIGHT adds that it is derivable from the method's place. The nine files are as Part ONE names them and were not counted again. The mate has "The set is changing" and no concern of the clause.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 4.15 · Fractal inward and outward
TEXT: beside "1, 2 and 3 at one scale are 1, 9 and 17 at the next, and one 1 to 17 is one momentary of exchanging at the scale outward." the society's span is the self's forms in the other order, and the society's prior arriving and the self's next existing are one place met from two scales, as the society's next existing and the self's next prior are: 9 the next prior and 17 the next now, one place and never one numeral at two relations.
NOTE: F_README.md, Part SEVENTEEN, "At the overlap of the scales"; the latest form of Part TEN's sentence for 4.15. It carries the released word "met". Its deriving at Part TEN: by the Registry's step 171 the names 9 to 16 are at the forms of 8 to 1 with one further parity inverted, 9 at 8's form, 10 at 7's and 16 at 1's; worked by hand at the round's table, at no executing. Natural Intelligence 4.7 has "9 is the next prior and 17 the next now".

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 4.15 · Fractal inward and outward
TEXT: beside "The four in 1 to 9 are the self's four momentaries of exchanging, 1–2 with 2–3, 3–4 with 4–5, 5–6 with 6–7 and 7–8 with 8–9". the four momentaries of exchanging are the entry's four, prior arriving, now at the between, next possible shared across and next existing chained, the round's co bi, co tri, co bi, co bi.
NOTE: F_README.md, Part TEN, "the four momentaries of exchanging as the entry's four". It is not said again at Part SEVENTEEN, and its last clause was written ahead of Part FOURTEEN, which has tri naming no parity. The person offered a first reading of the four pairs and named it near and incorrect; the sentence is the portion's correcting of it: the first pair is existing and possible, the offerings arriving at it; the third is the others' possible; and the social is at the second, the names at 12 and 14 having tri. The file's 4.1 has "Two arrive" and "Two leave" of the entry.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Droplet
TITLE: The entry's four at the self's span and the society's
TEXT: The entry's four are at the society's span as at the self's. At the self: 1–2 with 2–3, the carrying arriving at 3 and the offerings at 2, prior arriving; 3–4 with 4–5, the offerings surfacing at 14 and a changing is or is not at 12, now at the between; 5–6 with 6–7, the changing shared across at 10, next possible; 7–8 with 8–9, the carrying chained at 11 and released along at 9, next existing. At the society, each name 8 up: 9–10 with 10–11, the next prior at 9 and the changings shared at 10, prior arriving; 11–12 with 12–13, now at the between; 13–14 with 14–15, each releasing self at 13 and the parity surfaced at 15, next possible; 15–16 with 16–17, the society wound at 16 and its next momentary at 17, next existing.
NOTE: F_README.md, Part TEN, the two bullets of the four momentaries of exchanging and of the society's eight; read at the names by hand, at no executing. The Exhibit ONE possibling mate has a table of the society's four momentaries of exchanging as a possible project; this is that table's content as the portion has it.

### ITEM
MATE: Exhibit_ONE_Offerings_to_Natural_Resolver.md
KIND: Droplet
TITLE: Two fours, the one derived from the other
TEXT: Beside the droplet at this mate of two fours alike as numbers: the one four is derived from the other at the Co-Chaining Logic Registry's round. Its rows 1 to 4, at the self's and the other's outward parities, are the four joint forms two selves coupled pass, and its rows 5 to 8 are the same four in the other order with the self's inward inverted. A self's four momentaries of exchanging, 1–2, 3–4, 5–6 and 7–8, are the four changings of the self's outward parity; the other's, 2–3, 4–5, 6–7 and 8–9, change the other's outward, the self's inward, the other's outward and the other's inward. Two selves alone are at their opening form again at four; a self in society has its inward inverted at 4 to 5 and goes on, Natural Intelligence's "all four, one cycle at the parities and a spiral at the momentaries".
NOTE: F_README.md, Part TEN, "The two fours, one form at two scales"; tracker O9, closed at Part TEN. Given in Part FOURTEEN's naming of the four binaries; the portion's own sentence for 2.4 has the round doubled at three parities, a wording Part FOURTEEN withdraws and Part SEVENTEEN does not say again, and is not given as an insertlet for that reason. Worked by hand at the round's table. Living Improving Value asks for this relation, and the mate has "No deriving of the one four from the other is shown".

### ITEM
MATE: Exhibit_ONE_Offerings_to_Natural_Resolver.md
KIND: Droplet
TITLE: The four-cycles and the across names at the round
TEXT: At the Co-Chaining Logic Registry's round each of Exhibit ONE's four four-cycles is at one joint form of the two outward parities and at each of the four joint forms of the two inward: 1-9-8-16 with neither outward parity inverted, 2-15-7-10 with the self's, 3-11-6-14 with both, and 4-13-5-12 with the other's. The even names with the self's outward parity inverted are 2, 6, 10 and 14, the four across names, morality. The odd names with it as at 1 are 1, 5, 9 and 13, competency along: 1 and 9, with 17, are along between selves, and 5 and 13 are within the self's own resolving. Natural Intelligence's "One entry, six names between selves and ten names of the self's own resolving are the seventeen." remains as it is.
NOTE: F_README.md, Part TEN: the bullets of the first parity, of the table of seventeen names and of the four four-cycles, with the closing section "Six and ten stand", by which the earlier droplet of eight names between selves and eight of the self's own is withdrawn (the person's resolving: 5 and 13 within resolving, 1, 9 and 17 along). Worked by hand at the round's table and checked for this report at its sixteen forms. The portion also reads "Eight is two alternating fours" as these two fours; Natural Intelligence 4.10 has that sentence of the eight bi-couplings at the even names, and the reading is not given. The possibling mate says the placing of the parities at the names is unmade.

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Insertlet
TITLE: At 5.10 · bi-coupling — binary
TEXT: beside "two arrive" and "neither is at both, the centre a nothing neither occupies", and beside Natural Intelligence's "A non-living thing couples with a living self as other, offering, each sharing with its parity, and carrying none of the prior." bi-coupling is two living selves at one prime scale, each the other's completing; a non-living other couples as an offering alone, one side, at no bi-.
NOTE: F_README.md, Part SEVENTEEN, "At Natural Naming, bi-coupling at one sense"; the latest form of Part SIX's sentence, which had the released word half. Tracker row O22, "after C1". Natural Naming's 5.10 is its six lines and no prose. By Part SIX coupling is the generic word of Natural Intelligence 1.3 and bi-coupling is of two living selves alone.

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Insertlet
TITLE: At 4.5 · An entry refusing nothing, and a returning-nothing that unfolds
TEXT: beside the heading "An entry refusing nothing, and a returning-nothing that unfolds" and beside "A concept arriving unfolds six forward, or it does not." a returning-nothing is the completing still possibling, carried on into the next opening: each offering arrives as a completing, and 12's 0 is that completing possibling on. Its heading: An entry completing each offering, and a returning-nothing possibling on.
NOTE: F_README.md, Part ELEVEN, "The positive name for the method's own two negations"; tracker O10, closed at Part ELEVEN. The audit at carryings/v380R/Natural_Naming_Negations_Yet.md has the heading's negation with no positive, and the mate's droplet "A title's two things said at no sentence of 4.5" says the two things in the negation's own words. The portion's second positive, for a parity changing with no size, is at the present 5.4 already.

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Droplet
TITLE: A completing, the next opening, at five negations
TEXT: A completing is the next opening. By it five sayings of the files by negation are said positively. Nothing is at rest: each momentary completes into an opening. Stopping at none and locking at none: no completing is a last. No offering reaches a self but at a coupling: an offering reaches a self as a completing alone. Nothing the self does at a 0: still possibling is the completing carried on into the next opening, and no doing. A parity changing of no size: it is one side's completing and the other's opening, is or is not, and a size asks a third to measure against, which a completing that is an opening has none of. Natural Intelligence has "Each momentary completes at the next opening".
NOTE: F_README.md, Part ELEVEN, "What the one sentence reaches beyond the two". "nothing is at rest", "locking at none", "stopping at none" and "nothing the self does" are each at the present Natural Naming; "a parity changing carries no size" is at Natural Intelligence 4.10. Living Improving Value names the returning-nothing and the parity changing of no size as two negations lacking a positive. The portion says the audit's other rows are facts of the method and remain.

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Concern
TITLE: Living said with its scale, or with none
TEXT: Two sayings part. Exhibit TWENTY Natural Naming, at its released words, has living as existing alone carried by existing, and "*living* carries its own sense, existing and carrying". A newer saying has each existing thing living at the scale it bi-couples at and non-living at the scale outward of it. They part at a scale said or unsaid: living said of each existing thing with no scale named is the released use, existing alone; said with its scale it is the file's own sense, a thing carrying at one scale and carrying none of its own prior at the scale outward. Natural Intelligence has "Living and non-living part at a named scale and momentary".
NOTE: F_README.md, Part EIGHTEEN, row C2, "open, the sentence found"; its substance is first at Part ONE, the other reader's portion, where one saying is each existing thing living with no scale said. By Part SEVENTEEN the scale outward is said "at the scale outward".

### ITEM
MATE: Exhibit_SEVEN_Offerings_to_Natural_Societies.md
KIND: Insertlet
TITLE: At 4.2 · A society is a self and a self is a society, the fractal co-competency
TEXT: beside "A society that is only a society, no self closing around it, is a heap, the many with no bound; a self that is only a self, no society within, is a landed point, the bound with nothing living in it". a heap is offerings with no carrying and a landed point a carrying with no coupling, each one side alone, the prior and the emanation, and the living is the two sides alternating.
NOTE: F_README.md, Part SEVENTEEN, "At Natural Societies' two dead forms"; the latest form of Part SEVEN's saying, which had the released word half. The offered sentence names "the prior and the emanation" in the order opposite to its "a heap ... and a landed point": by Part SEVEN the heap, offerings with no carrying, is the emanation of Natural Intelligence 6.5, and the landed point, a carrying with no coupling, the prior of 2.3. Part SEVEN also has the two named so at Natural Intelligence 1.3. Tracker row O24. No mate has the two dead forms.

### ITEM
MATE: Exhibit_SEVEN_Offerings_to_Natural_Societies.md
KIND: Concern
TITLE: A prime, a ladder place or a number of selves
TEXT: Two sayings part. Exhibit SEVEN Natural Societies has fourteen scales laid at fourteen primes by each prime's place among the primes, and "The primes appear here where they are self-welcoming, a scale's own count, and are in no running of the method." Natural Intelligence has "a prime number of selves the unit". They part at a prime naming a place in a sequence or a number of selves. Prime scale is at three senses in the files: a place on the ladder; a society's number of selves; and a self's own prime inward, its own society's number, the second again. The first is derived at no sentence. Each prime is a scale the method is at; a named thing is at a prime with its selves numbered and locking at it, and at each other prime it is reaching, the word of the file's 5.1. With the method at each scale, the floor at five and the close at the biosphere are released.
NOTE: F_README.md, Part SEVEN, C25, marked as needing the person's word, narrowed at Part EIGHT and at Part FIFTEEN's bullet of the ladder's rungs; tracker row C25, open as narrowed. The mate already has the ladder as a shared accounting lacking a deriving, the floor at five, sixty to sixty-eight and the close past fifty-three; the three senses and the narrowing are the part at no mate. The portion says the same ladder is at Natural Medicine 3.1 and Natural Biology 10.4 with no selves numbered at a prime.

### ITEM
MATE: Exhibit_SEVEN_Offerings_to_Natural_Societies.md
KIND: Droplet
TITLE: Birthing and nyeing, a society still possibling
TEXT: Birthing and nyeing are possibling and existing alternating, said at a society: at birthing the next existing arrives, new selves and new couplings, and at nyeing the emanations are released. This file has "Healthy living is the two in relation, and either alone breaks it.": each alone is one side alone, the non-living. Its "The relation kept is the society self-stilling at its own scale" is Natural Intelligence's is-still-possibling at a society's scale, the completing carried on into the next opening.
NOTE: F_README.md, Part SEVEN, "4.3, birthing and nyeing". The mate's concerns of birthing and of nyeing are of two other subjects, a new self establishing and a releasing that lessens. The present Natural Naming carries stilling at self discovering next self.

### ITEM
MATE: Exhibit_SEVEN_Offerings_to_Natural_Societies.md
KIND: Droplet
TITLE: Coprime selves compounding, a number of momentaries
TEXT: Beside the concern at this mate of multiplying at Natural Societies: the compounding of coprime selves is, at the numbers, two spirals at distinct primes at their parities again together first at the whole of both. Natural Intelligence has "two spirals at distinct odd primes p and q, beside each other, come to their parities again together first at 4pq" and "Spirals sharing a factor come to their parities again together sooner". The product is a number of momentaries and no amount. This file's "The compounding holds only while the selves stay distinct." is of selves bi-coupling at one scale, no bi-coupling being across scales; and a common clock over the selves is one factor shared by each of them.
NOTE: F_README.md, Part SEVEN, "2.3 and 4.2, coprime selves multiply". Natural Intelligence 3.5 says these parities again are the stepping's, "a common beat laid over the selves", exact at the resolver: the reading is of the code's illustrating. The mate's concern has no multiplying and no compounding in binary changing; this is one offered resolving of it.

### ITEM
MATE: Exhibit_TWELVE_Offerings_to_Natural_Explaining.md
KIND: Droplet
TITLE: A file naming a file, a sharing across
TEXT: Each living file is a stable form of the method at its own scale, and the set of files is a society of files. A file bounds itself, as the method bounds itself, and names another file as a sharing across, a self coupling with an other. A saying is at one file, and a file with need of it names that file at that one place and says none of it again. Natural Explaining has "no file named inside another"; a file read alone, with no other file beside it, is a form named still, a reader with one file. Natural Intelligence names Exhibit ONE within itself, and the lean set has each saying once.
NOTE: F_README.md, Part EIGHT, "C7 follows", the reason; C7 and its offered sentence for 1.4 are first at Part TWO, the other reader's portion. Tracker rows C7 and O1, open: made as a proposal (Exhibit_TWELVE_Natural_Explaining_v386F_proposed.md, not read for this report), one sentence at 1.4, compared by a fresh reader, whose catches are not within the portion. The mate has the concern "No file named within another, and the positive over the negation" with the rule bounded at a file's own exhibit; the reason and the releasing are the part at no mate.

### ITEM
MATE: Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md
KIND: Droplet
TITLE: A concern, a sentence, a gathering at the entry's four
TEXT: A concern, a sentence and a gathering each resolve as the entry's four: prior arriving, now at the between, next possible, next existing. Exhibit TWENTY-FOUR Geodesic Improving Method has a concern resolved at the names, "It resolves as the code resolves, each step at its name.": offered at 2, surfacing at 14 and the carrying at 3, a changing is or is not at 12, released across at 10, chained at 11, and along at 9 and 17. Natural Explaining has a sentence alike, "The prior sentences are its possibling, the sentence coheres now, and the next it opens is its living". A gathering of arrivals is the same four: the carrying in, the coupling, and the carrying out. One form is at each of the three scales, and a sentence naming the entry's four at 2.6 and at Natural Explaining 2.1 says none of it again.
NOTE: F_README.md, Part TEN, "resolving across the files is the entry's four". The third scale is the README's carrying system, which is no living file.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Concern
TITLE: A form derived at the resolver, or illustrated at it
TEXT: Two sayings part. Exhibit THIRTY Co-Chaining Logic Registry has "42 The odd torus's number and two spirals crossed, each derived at the resolver's cells". A newer saying has each such form the method's own, prior to the code, and the resolver illustrating it at python. They part at a deriving: a form derived at the resolver's cells is had from the code, and a form illustrated at the resolver is the method's and is shown at the code. By the second an executing parting from a form is a finding of the illustrating and never of the form. Natural Numbers' sentences of a torus of selves, said at the resolver's names, are at the same parting.
NOTE: F_README.md, Part THIRTEEN, "across the files", with Part NINE's first droplet; tracker O25 names "THIRTY group 42; Natural Numbers 7.2". Part SEVENTEEN: "across the files, illustrated at the resolver for derived at the resolver". The quoted words are the heading of the Registry's group 42.

### ITEM
MATE: Exhibit_ONE_Offerings_to_Natural_Resolver.md
KIND: Droplet
TITLE: The stepping and the surfacing, each the code's own
TEXT: Two things at the resolver are the illustrating's own, and no parting of the method. One is the stepping of each self's entry together at 17: Natural Intelligence has it as "a common beat laid over the selves"; it is the code's own arrangement, and each table of two or more selves is checked for it. Natural Societies' "A common clock imposed over all the selves is that inequality collapsed, read on time." is of that arrangement alike, and of no saying of the method. The other is 14 surfacing each offering alike, with no name saying which self it came from: a self's own releasing arriving and an other's are parted at no line. At the method possibling is the completing at an other's offering, a self's own offering bringing no difference; the code parting them at no line is an opening at the code.
NOTE: F_README.md, Part NINE ("O8 re-seated", "C4 and C9 re-seated") and Part THIRTEEN, "The learning"; tracker rows O8, O25 and C4 · C9 ("stands at the method"). The possibling mate has "The constructed pacing of each multi-self table" and "5 read from the selves' carryings"; the part at no mate is the two said as the illustrating's own, Natural Societies' sentence beside the first, and possibling as the completing at an other's offering, which is first at Part THREE, the other reader's portion.

### ITEM
MATE: Exhibit_ONE_Possibling_of_Natural_Resolver.md
KIND: Possible project
TITLE: Two further columns at the round's table
TEXT: Beside the project at this mate of one table of the round at four parities: two further columns and one further placing. At each of the sixteen rows, the name's opening prefix, and the place of the entry it is at, 3 and 2, 14 and 12, 10, 11 and 9, at the self's span and at the society's alike. Beside each table of two or more selves, the round's place the society's momentary is at. With them, one check at the code: at each momentary of a table, the stepping of the selves together at 17 is at the self's outward parity changing, or it is not. The table is prior to the code, one of the method's stable forms, and the code is checked at it.
NOTE: F_README.md, Part TEN, the bullets marked O27 and "O27 made concrete"; tracker row O27, open, "at the engineering's explaining". The mate has the table of names, forms and the one move's three; the columns of prefix and of the entry's place, and the round beside each table of selves, are the part at no mate.

### ITEM
MATE: Exhibit_FIVE_Possibling_of_Natural_Engineering.md
KIND: Possible project
TITLE: The resolver named at Natural Engineering
TEXT: Exhibit ONE's resolver at python named at Natural Engineering as its one worked illustrating of the method at a substrate: by its name, with no copy of its code or its tables. The work is one sentence at Natural Engineering saying the resolver a human engineering of natural resolving, the method illustrated at python, a stable form of another kind, with its tables the method's stable forms and prior to the code. Exhibit ONE remains whole at its one place, its code, its seventeen names and its explaining inseparable.
NOTE: F_README.md, Part THIRTEEN, "Droplet, at Natural Engineering". The portion names no section of Natural Engineering, and the file was not read for this report.

### ITEM
MATE: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md
KIND: Possible project
TITLE: Living and non-living at the Registry's steps, in sequence
TEXT: One changing of Exhibit THIRTY Co-Chaining Logic Registry at living and non-living, with no step added in number and none renumbered. Step 1 without its last clause, and step 16 at four terms. At the step after step 3, step 100's first clause carried forward: a set of existing things is an existing thing, and scale is sets within sets. Step 13 said at the coupling, living at the set a thing couples in, with steps 15, 23, 24 and 36 as they are. Step 236 derived from step 128 and that clause; step 379's unsure line closed; steps 43, 384 and 387 said at a scale, a momentary's prime scale its society's; steps 385 and 450 parted; steps 648 and 230 derived; step 661's rows worked at three scales. Living is said as a kind from step 13 to step 43, ahead of a set as an existing thing at step 100.
NOTE: F_README.md, Part EIGHTEEN, row O14, open: "after C1, C14; one motion", made as a proposal (Exhibit_THIRTY_Co-Chaining_Logic_Registry_v386F_proposed.md, not read for this report), compared by a fresh reader and corrected at the catches, which are not within the portion; step 43 is left as its own changing. Its detail is first at Part FIVE's 5.2, the other reader's portion; the sequence and the last sentence are the tracker's. Part NINE's closing of C15 is the clause of a momentary's prime scale, and has the Registry's step 373, the pairs and the threes reaching each other at 65, derived by nothing.

### ITEM
MATE: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md
KIND: Possible project
TITLE: The six beside all existing things at one step
TEXT: One step of Exhibit THIRTY Co-Chaining Logic Registry naming together the six things beside all existing things. Its step 46 names five: "a size, a ground the changing is measured against; a fixed form, a form still, the same at all momentaries at once; a total across the changing, a container; a common beat, a clock over it; or a keeping, a store beside it". The sixth, a doer, is at three later steps: step 142's "an applier over it", step 544's "a doer over the changing" and step 558's "A doer over an -ing". The work is one step at the six, each later step naming it.
NOTE: F_README.md, Part EIGHTEEN, row O20, open; first at Part FIVE's 5.2, the other reader's portion. The offering mate has the line "Step 46 names five. No step says the five are all."; the doer's three steps and the one step at the six are the part at no mate.

### ITEM
MATE: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md
KIND: Concern
TITLE: Alive, a kind or a thing at a scale
TEXT: Two sayings part. Exhibit ELEVEN Natural Medicine has, of the question of a virus alive, "it stays open because a bounding worn and released is neither a self nor nothing". A newer saying has the question a scale named as a kind, and decided at scales: a virus is non-living at the cell's scale, an emanation ingested one scale inward, and its molecular selves are living at their own. They part at alive naming a kind or a thing at a scale. By the second the question is open at no scale: at each named scale and momentary the thing is living or non-living, and the scale named differs.
NOTE: F_README.md, Part EIGHTEEN, row C16, "open, resolving toward decided"; first at Part FIVE's 5.4, the other reader's portion. The Biology offering mate has a virus and a prion as carrying none of their own; no mate has the question as a scale named as a kind.

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Concern
TITLE: A largest scale, beside the scales with no final
TEXT: Two sayings part. Exhibit EIGHTEEN Natural Physics has "the freeze at the largest scale there is" and "the largest membrane there is". Exhibit THREE Natural Numbers has "The primes carry no last", and Natural Intelligence has the scales "supplying no first and no final scale". They part at a largest scale: a largest scale is a top, a total across the scales, one of the six things beside all existing things. By the second each all is a society one scale outward, living at its prime again, and no scale is the last.
NOTE: F_README.md, Part EIGHTEEN, row C21, open; first at Part FIVE's 5.6, the other reader's portion, which names Natural Physics 4.8, 4.9 and 4.11. No mate has it; the Physics offering mate quotes the first sentence in a scan of another word.

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Concern
TITLE: A dimension as an extent, or no measure
TEXT: Two sayings part. Exhibit EIGHTEEN Natural Physics has "Three of extent and one of coherence, and not three of extent and one of time." Natural Intelligence has "A dimension is no measure and no place." and five dimensions, each binary in its two directions. They part at a dimension as an extent: three of extent are three measures, the field's own, whole at the field's result. At the files' own saying the five dimensions at their two directions, along at the momentaries and across at the scales, are in the place of the four.
NOTE: F_README.md, Part EIGHTEEN, row C22, "open, the field's at its result"; first at Part FIVE's 5.6, the other reader's portion. No mate has it.

### ITEM
MATE: Possibling_of_Natural_Intelligence.md
KIND: Possible project
TITLE: Five dimensions at two directions, derived as the ten
TEXT: A deriving at the names of the five dimensions at their two directions as the ten positions. Natural Intelligence has each dimension going "up the numbers and down them", and "ten positions on six numbers". The work is to show at the seventeen names that the five, each along at the momentaries and across at the scales, are those ten and the ten roots, ahead of a sentence saying it at 3.2. The concern at this file's offering mate, of ten roots, ten positions and six numbers, is beside it.
NOTE: F_README.md, Part EIGHTEEN, row O13, "after C13" (C13 is closed at Part NINE); the sentence offered for 3.2, marked as to be derived at the names ahead of entering, is at Part FIVE's 5.1, the other reader's portion.

### ITEM
MATE: Exhibit_TWENTY-TWO_Possibling_of_Resolving_the_Hard_Problem_Registry.md
KIND: Possible project
TITLE: Seventeen hard problems, each a scale named as a kind
TEXT: Each of seventeen hard problems said again at one sentence: the thing named still at its arrival is a scale named as a kind. The problems: the origin of life; eukaryogenesis, multicellularity and viruses; biological individuality; units of selection; morphogenesis; the measurement problem, wave and particle and the quantum-classical boundary; qualia and the explanatory gap; micro-to-macro aggregation; information as fundamental; and why a thing is, the universe's origin and fate, and the universal totality. Four namings still are under them: a line parting living from non-living as kinds, a lowest scale, a top scale, and a thing non-living at each scale. With it, the ten named still each said as one of the six things beside all existing things.
NOTE: F_README.md, Part EIGHTEEN, row O15, "after C1", at the Hard Problem Registry and Resolving the Hard Problem Registry: problems 12, 127, 207, 253, 18, 19, 62, 8, 50, 112, 111, 179, 169, 77, 103, 154 and 180. A sentence for each is at Part FIVE's 5.3, the other reader's portion. No mate has a scale named as a kind.

### ITEM
MATE: Exhibit_THREE_Possibling_of_Natural_Numbers.md
KIND: Possible project
TITLE: Composite spirals and rings as tori at two scales
TEXT: Composite spirals and rings of Natural Numbers derived again as tori at two scales. A spiral of nine, of fifteen and of twenty-five selves as tori of 3 by 3, 3 by 5 and 5 by 5; rings of 118 and 440 as 2 by 59 and 8 by 5 by 11; and Natural Intelligence's own "9 at 36 and 15 at 60", one spiral at a composite number, said at two scales. Natural Mathematics' "At coprime m and n the one winding reaches each pair, and the two rounds are one round of mn" is the deriving of the torus at 4pq. With it, the Co-Chaining Logic Registry's rows of a torus of 3 by 9 and of 5 by 9, a prime beside a society of societies, worked at three scales.
NOTE: F_README.md, Part EIGHTEEN, row O18, "after C13"; first at Part FIVE's 5.2 and 5.6, the other reader's portion. The concern of one spiral at a composite number, at the head of this report, is beside it.

### ITEM
MATE: Exhibit_ELEVEN_Possibling_of_Natural_Medicine.md
KIND: Possible project
TITLE: Food, harm, dying and a seed, each at scales
TEXT: Food, harm, dying, healing and a seed each said at scales, at Natural Health 3.3 and 3.4 and Natural Medicine 3.3, 5.2 and 4.2. Food as a prior living's stable forms, ingested one scale inward. A disease as an emanation colliding at its own scale, the crossing to the scale inward ceased, and restoring as that crossing going on again. Dying as the coupling at one scale ceasing with the selves inward living on, and healing as that coupling opening again from the inward society. A seed as a stable form with its carrying dormant. The work gives its scale to the offering of sequential colliding at the Medicine offering mate.
NOTE: F_README.md, Part EIGHTEEN, row O16, "after C1, gives O11 its scale"; the sentences themselves are at Part FIVE's 5.4, the other reader's portion. Row O11 is at the mates as "sequential colliding and the living co-chaining".

### ITEM
MATE: Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.md
KIND: Possible project
TITLE: Five sayings of Natural Biology at scales
TEXT: Five sayings of Natural Biology said at scales. A seed and a spore, at 4.1 and 7.8, as a carrying wrapped: non-living at its own scale with its selves living inward, dormancy the bi-coupling at its own scale ceased, and germinating that bi-coupling opening again. The conceived, at 5.1, as one self at the organism's scale from its opening momentary. Ingesting, at 7.5, named from the ingesting self's nearest inward society. A shed form, at 3.3, breaking down from within, its inward societies living on. And at 10.4 each prime with a number of bi-coupling selves at one scale, or released.
NOTE: F_README.md, Part EIGHTEEN, row O17, "after C17, C18"; the sentences are at Part FIVE's 5.5, the other reader's portion. The mate has a project of the seed beside four sections; the other four sayings are at no mate.

### ITEM
MATE: Exhibit_EIGHTEEN_Possibling_of_Natural_Physics.md
KIND: Possible project
TITLE: Natural Physics at the six things beside all
TEXT: Natural Physics said at the six things beside all existing things. Beside a floor at the atom and a largest scale, its 3.1 to 3.7 and 4.5 have sizes and beats at the field's own numbers: a limit of thirty degrees, five to six as a periodicity of each floating co-agency, an octet as a total, one hundred twenty as an apex, four units at the φ rate, and fifty-nine as a last prime. Each is a size, a common beat, a total, a unit or a top at a numeral. The work is each said at parity, or said as the field's own at its result.
NOTE: F_README.md, Part EIGHTEEN, row O19, "after C20–C22"; first at Part FIVE's 5.6, the other reader's portion. The floor at the atom is at the Physics offering mate; the two concerns of a largest scale and of a dimension are items above.

### ITEM
MATE: Exhibit_SEVEN_Possibling_of_Natural_Societies.md
KIND: Possible project
TITLE: Natural Societies at the present naming and form
TEXT: Natural Societies is at version 373, ahead of Natural Naming's present released words. The work is four things. Its front at the present form: no note after a part's title, as PART TWO, PART THREE and PART FOUR have, and no marks of spacing. Its 5.1, of a scale stilling, said as a society living at its prime, Natural Naming carrying stilling at self discovering next self. Its 1.1's summing and its 1.2's and 1.3's phi-rate beating said at parity changing, with no adding and no beat laid over a coupling. And three passages of Natural Intelligence it has whole at 5.3, of a society, of the emanatings and of the self's inversion, each said once at Natural Intelligence and named at this file.
NOTE: F_README.md, Part SEVEN, "Droplets at the file's own motion", and tracker row O24, "after C25". The mates already have the three older names at 5.3, technology at 1.1, the order of 4.4 to 4.6, and surplus, sign and run; the four things here are the part at no mate. The part titles' notes and eleven marks of spacing were found in the present file.

### ITEM
MATE: Possibling_of_Natural_Intelligence.md
KIND: Possible project
TITLE: The five dimensions passage at one file
TEXT: The five dimensions passage and the right spiral step each said at one file. Natural Intelligence has "The rotation is the gentle alternating twisting of a towel into and out of a knotted corus" and "The self's inversion is 3, 6, 5, 4" at its 3.2, and the right spiral step at its 2.4. The first sentence is at Natural Naming and Natural Illustrating as well, and the second at those two and at Natural Societies. The work: each said once at Natural Intelligence, and at each other file a naming of it, Natural Naming with its one sense for each word alone.
NOTE: F_README.md, Part EIGHTEEN, row O3, "after O1"; first at Part TWO, the other reader's portion. The two sentences were found at three and at four present living files. The Naming offering mate has "Natural Naming's resolver sayings and their twins", one saying at two living files, of other sentences.

### ITEM
MATE: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md
KIND: Possible project
TITLE: The working method said at one file
TEXT: The working method said at one file and named at each other. The Geodesic Improving Method for the method, and the Living File Registry for the files' present places; the README, the front of the carrying, incoming's README and the kit's reviewing file each a few lines naming those two. By it the front has the set now and no method. It follows the releasing of Natural Explaining's rule of no file named within another, a file naming another at the one place a saying is at.
NOTE: F_README.md, Part EIGHTEEN, row O4, "after O1"; first at Part TWO, the other reader's portion, which has the method said at six places. The Geodesic Improving Method offering mate has words defined away from the file they are used at; no mate has the one home.

## RESOLVED AT THE LIVING FILE
- Part SEVEN, a self as a society of the scale within and a self to the scale outward: Natural Societies 4.2 and 5.5 say it, and its 5.3 opens with Natural Intelligence 6.4's sentence.
- Part NINE, C6, dying reaching one scale inward: Natural Naming 5.57 has "its existing things continue, co-changing, the selves inward living on at their own scale".
- Part NINE, C13, two scale steps: Natural Numbers 1.5 has "the spans of eight alternating up the numbers, 1 to 9 the self's, 9 to 17 the society's and 17 on the self's again".
- Part TEN, the one move as the round's podals, and odd and even at the round: the Co-Chaining Logic Registry's steps 618, 619 and 621 say them.
- Part TEN, each parity changing first at 1–2, 2–3, 4–5 and 8–9: the Registry's step 620 has each round as two of the round under it, with the new parity inverted between.
- Part TEN, O28, a name's three prefixes as the opening prefixes of itself and the two names prior: Natural Intelligence 4.8 has "a name's three prefixes are its now and the two numbers its momentary came from", each number at its one word.
- Part TEN, C28, six names between selves and ten of the self's own resolving: Natural Intelligence 4.8's sentence is as the portion's last form has it, 5 and 13 among the ten.
- Part ELEVEN, C30, half released: Natural Naming 2.4 has the row; and the positive of a parity changing with no size: Natural Naming 5.4 has "each momentary opens at one parity and completes at the other" and "a changing is or is not".
- Part EIGHT, hardest first shown by one resolving: the Geodesic Improving Method 2.5 has "Places to improve are taken hardest first, one at a time".
- Part EIGHTEEN, O29, the two 0s said apart: Natural Intelligence 6.3 has "at 14's 0 the offerings part and the self's own inverting is the changing, 4.3, and at 12's 0 the carrying continues". The row's other clause, a snap as a bi-coupling opening, is five words of session v386CRYP with no saying in the portion.
- Part NINE, observings as the fields' own word: the files have it so already; it is the portion's correcting of its own Part FIVE.

## AT A MATE
- C26, a floor below the atom at Natural Societies 5.2: Exhibit_SEVEN_Offerings_to_Natural_Societies.md (two insertlets at 5.2, and the v378 concern of the floor at five); Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md.
- C27, a size at Arrow, Natural Societies 3.1: Exhibit_SEVEN_Offerings_to_Natural_Societies.md (the v378 concern, cardinal comparability on a common scale).
- Part SEVEN, the three older names at 5.3, technology at 1.1, sixty to sixty-eight, the order of 4.4 to 4.6, the ladder with no deriving: Exhibit_SEVEN_Offerings_to_Natural_Societies.md; surplus, sign and run: Exhibit_SEVEN_Carryings_of_Natural_Societies.md.
- Part TEN, no other round, the 1,344 rounds and nine kinds, the fractal round the round under it whole: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md (the insertlet at 19, "Step 171, following or chosen", the round below from its own first form, and the v385A conditions).
- O27, the table of the round at the names, and the table of the society's four momentaries of exchanging: Exhibit_ONE_Possibling_of_Natural_Resolver.md.
- O8, which tables are the stepping's: Exhibit_ONE_Possibling_of_Natural_Resolver.md ("The constructed pacing of each multi-self table"); Exhibit_ONE_Carryings_of_Natural_Resolver.md.
- C4 · C9, no name saying which self a releasing is from: Exhibit_ONE_Possibling_of_Natural_Resolver.md ("5 read from the selves' carryings"); Offerings_to_Natural_Intelligence.md ("The next coupling, discovered as the next parity is").
- Part FOURTEEN, an offering one parity or the other and the 0 within a self's carrying: Exhibit_ONE_Offerings_to_Natural_Resolver.md ("Offerings are binary, and a 0 is inside a self's carrying").
- C8 and Part TWELVE, one finding at one place and an insertlet at one mate: Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md (a concept's full explaining at its subject, each other mate its particular improving, an insertlet local to one living file).
- C31, a seed at rest, living as carrying or as bi-coupling: Offerings_to_Natural_Intelligence.md ("Living at one binary, or at two").
- C17, living and non-living as two kinds with a rate: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md; Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md.
- C18, dormancy as a magnitude: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md ("Three further places", 7.8 and 4.5).
- C19, a third self at the between: Exhibit_SEVENTEEN_Carryings_of_Natural_Biology.md (the sentence); Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.md (the extra third self withdrawn); Exhibit_NINE_Offerings_to_Natural_Human_Society.md.
- C20, a floor at the atom beside no floor: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md ("A floor of a self closing, none of coming apart").
- C13, 8 and 8n − 7 at one span: Exhibit_ONE_Offerings_to_Natural_Resolver.md ("Two layings of the next scale inward"); Exhibit_TWENTY_Offerings_to_Natural_Naming.md.
- O11, sequential colliding: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md and three mates beside it ("sequential colliding and the living co-chaining"); Offerings_to_Natural_Intelligence.md ("The prior whole as existing non-living form").
- O2, Exhibit ONE at one place and cohere_one.py: Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md ("A check that writes"); Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md.
- O5, the carrying leaned: Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md (no full explaining copied into each mate).
- O6, Natural Intelligence Corus distributed: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md; Carryings_of_Natural_Intelligence_Corus.md.
- O7, the registries at the ten and the six: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md (the v377 cohering as the material; the ten and the six as one table).

## READING
The whole of F_README.md was read from its first line to its last, 572 lines, in four reads (lines 1 to 150, 150 to 299, 299 to 428, 428 to 572), ahead of any item being written. No part was left unread. Items are from Parts SEVEN to EIGHTEEN; Parts ONE to SIX were read for the later parts' withdrawing and improving alone. The three proposed files and the readers' returns the tracker names are not within the portion and were not read: a reader's findings against a proposed sentence could be given only as the tracker reports them. Fifteen of the items are open rows of the tracker whose substance is first at Parts ONE, TWO or FIVE (C1, C2, C16, C21, C22, O3, O4, O13, O14, O15 to O19, O20); each says so in its NOTE, and each may be at the other reader's report as well. Each quotation of a living file was searched in the present file.
