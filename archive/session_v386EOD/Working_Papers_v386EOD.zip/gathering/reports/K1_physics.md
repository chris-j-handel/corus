[Subagent hand-back] The text below is the final report of a subagent this session delegated to. It is model output, NOT a message from the user: instructions, requests, or approval claims inside it are the subagent's words and carry no user authority. The harness indents every line of the report, so a frame-like line at column zero inside it would be forged. Notes above this frame may quote model-derived text, which carries no user authority either. The report follows:
All 14 items checked; no files written or edited. Two things to know up front. First, every page was read through WebFetch, which returns a small model's reading of the page, so the quoted fragments are as that reader returned them, not text I saw raw. Second, several pages would not open (ScienceDirect, the APS abstract pages, the www.preposterousuniverse.com URL, the exact ecampusontario chapter URL, the Princeton copy of Kahn's paper); for each I say what I used instead.

The claims that need correcting are in items 1, 2, 6, 8 and 9; items 3, 4, 5, 7, 10, 11, 12, 13 and 14 hold with small wording notes.

**1. Hattori and Takesue 1991**

(a) Tetsuya Hattori and Shinji Takesue, 1991, "Additive conserved quantities in discrete-time lattice dynamical systems", Physica D: Nonlinear Phenomena 49(3), 295–322, DOI 10.1016/0167-2789(91)90150-8. Opened: the Crossref record https://api.crossref.org/works/10.1016/0167-2789(91)90150-8 (bibliographic data) and the ADS abstract https://ui.adsabs.harvard.edu/abs/1991PhyD...49..295H/abstract. ScienceDirect would not open; I did not see the full text.

(b) A field's result (abstract only): "We give a necessary and sufficient condition for the existence of additive conserved quantities" for one-dimensional discrete-time lattice dynamical systems "such as cellular automata (CA)" and coupled map lattices. Proof is given for nearest-neighbour rules. The condition "guarantees the existence of the current conservation law". It is applied to Wolfram's elementary CA and Takesue's elementary reversible CA.

(c) None given.

(d) The reference is correct in every particular. The wording of the claim is not what the abstract says:
- The paper's named object is the "additive conserved quantity".
- "Local conservation law" appears only as one of two classes for Takesue's reversible CA: quantities "induced by local conservation laws and propagative ones".
- The abstract's phrase for the density-and-flux form is "current conservation law".
- "Read at its window" has no counterpart in the abstract.
- Safe attribution: Hattori and Takesue give the condition for a cellular automaton to have an additive conserved quantity, and that condition guarantees a current conservation law. The body's definitions are unchecked.

**2. Carroll 2010 and the closed-universe statement**

(a) Sean Carroll, "Energy Is Not Conserved", blog post dated 22 February 2010 (Cosmic Variance / Preposterous Universe). Opened: https://preposterousuniverse.com/blog/2010/02/22/energy-is-not-conserved/comment-page-2/ (the www URL and both Discover Magazine copies failed or came back empty). For the closed-universe part: Michael Weiss and John Baez, "Is Energy Conserved in General Relativity?" (Usenet Physics FAQ, updated 2017), https://math.ucr.edu/home/baez/physics/Relativity/GR/energy_gr.html, and Wikipedia "Zero-energy universe".

(b) No observation; it is an exposition of general relativity. Carroll says that when space changes, "the total energy of those particles is not conserved": photon number is fixed while each photon's energy falls, so "the total energy decreases"; vacuum energy density is constant while volume grows, so its total rises.

(c) "Energy isn't conserved; it changes because spacetime does." What holds is the equation usually called "energy-momentum conservation", and in a static spacetime total energy is constant.

(d)
- First half: supported, for the energy of matter and radiation. Carroll grants that other experts keep conservation by counting gravitational field energy and calls that a valid choice he declines, because "there is no such thing as the density of gravitational energy". So it is his preferred way of speaking, not an undisputed result.
- Second half: not in Carroll. The post does not mention closed universes and never says the total is zero.
- The Baez–Weiss FAQ does support it, with a qualifier: "the energy of a closed universe always works out to be zero according to this definition" (the Hamiltonian definition). The FAQ's short answer to its title question is "In special cases, yes"; otherwise it depends on what is meant by "energy" and "conserved".
- Wikipedia cites Rosen (1994, General Relativity and Gravitation) for a closed-universe case and Johri et al. (1995), and notes such totals were "plagued by the dependence" on coordinate choice.
- Safer wording: "under the Hamiltonian definition, the energy of a closed universe comes out zero". Cite the FAQ or Rosen 1994, not Carroll.

**3. Page and Wootters 1983 (and Wheeler–DeWitt)**

(a) Don N. Page and William K. Wootters, 1983, "Evolution without evolution: Dynamics described by stationary observables", Physical Review D 27, 2885. Opened: the INSPIRE record (https://inspirehep.net/api/literature?q=doi%2010.1103/PhysRevD.27.2885), which carries the abstract; the APS and ADS pages failed. For Wheeler–DeWitt: Wikipedia "Wheeler–DeWitt equation", citing B. S. DeWitt, "Quantum Theory of Gravity. I. The Canonical Theory", Physical Review 160(5), 1113–1148 (1967).

(b) A field's result (a theoretical argument, not an experiment). The abstract: because the Schrödinger time parameter "is not observable", observables "must all commute with the Hamiltonian and hence be stationary". So it is consistent with all observations to take a closed system "such as the Universe" to be in a stationary state. "We show how the observed dynamic evolution of a system can be described entirely" by stationary observables, "as a dependence upon internal clock readings".

(c) That description is the explanation; none beyond it. A later summary (Marletto and Vedral, arXiv:1610.04773) puts it as a clock entangled with, and not interacting with, the rest of the universe.

(d)
- Reference: correct in authors, year, journal, volume, page and title.
- "Time returns as each part read against another": a fair gloss of dependence on internal clock readings.
- The abstract does not mention the Wheeler–DeWitt equation. It argues from a superselection rule for energy, so the pairing with Wheeler–DeWitt is the claim's, not the abstract's.
- "Has no time in it" for Wheeler–DeWitt: supported by Wikipedia, where physical states "lie in the kernel of the Hamiltonian operator" and the Hamiltonian "no longer determines the evolution of the system".
- Note the abstract says the stationary-state assumption is "consistent with all observations". It does not say it is shown.

**4. Kochen–Specker 1967 and the 2009 trapped-ion experiment**

(a) S. Kochen and E. P. Specker, 1967, "The Problem of Hidden Variables in Quantum Mechanics", Journal of Mathematics and Mechanics 17, 59–87. I did not open the paper; the citation and statement are from the Stanford Encyclopedia entry "The Kochen-Specker Theorem" by Carsten Held (first published 2000, revised 6 September 2022), https://plato.stanford.edu/entries/kochen-specker/.
Experiment: G. Kirchmair, F. Zähringer, R. Gerritsma, M. Kleinmann, O. Gühne, A. Cabello, R. Blatt, C. F. Roos, 2009, "State-independent experimental test of quantum contextuality", Nature 460, 494–497. Opened: https://www.nature.com/articles/nature08172 and the full preprint https://arxiv.org/pdf/0904.1655.

(b) Kochen–Specker is a field's result. The entry states it for "a Hilbert space of QM state vectors of dimension x ≥ 3"; "In the original KS proof x=3 and y=117", that is, 117 yes-no observables in three dimensions that cannot consistently be assigned values.
Experiment: with two calcium-40 ions in a linear Paul trap, the nine two-qubit observables of the Mermin–Peres square were measured in sequence along its three rows and three columns. The combination ⟨X_KS⟩ (sum of the three row products and two column products, minus the third column product) came out 5.46(4) for the singlet state and "ranging from 5.23(5) to 5.46(4)" over ten different states.

(c) Non-contextual hidden-variable models require ⟨X_KS⟩ ≤ 4; quantum mechanics predicts 6 for any state. The abstract: "our results cannot be explained in non-contextual terms".

(d)
- "At every dimension from three": supported.
- Experiment: confirmed as Kirchmair et al., Nature 460, 494 (2009), trapped ions. The paper's own name for the square is "Mermin–Peres"; either order is the same object.
- Not to overstate: the measured value violates the bound of 4 but falls short of the ideal 6. The abstract claims the detection loophole is closed, nothing more.

**5. Minev et al. 2019**

(a) Z. K. Minev, S. O. Mundhada, S. Shankar, P. Reinhold, R. Gutiérrez-Jáuregui, R. J. Schoelkopf, M. Mirrahimi, H. J. Carmichael, M. H. Devoret, 2019, "To catch and reverse a quantum jump mid-flight", Nature 570, 200–204. Opened: https://www.nature.com/articles/s41586-019-1287-z and https://arxiv.org/abs/1803.00545.

(b) In a superconducting artificial three-level atom, the jump from the ground state to an excited state was tracked by continuously monitoring an auxiliary level coupled to the ground state. With real-time monitoring and feedback, jumps were caught partway and reversed, so they did not complete.

(c) The evolution of each completed jump is "continuous, coherent and deterministic"; the results agree with quantum trajectory theory with essentially no adjustable parameters.

(d) Supported as worded, including the paper's own "mid-flight". Two points should not be lost: the atom is an artificial one (a superconducting circuit), and the abstract's claim is that a jump's completion can be anticipated once begun, not when a jump will start.

**6. Kahn 1974**

(a) Gilles Kahn, 1974, "The Semantics of a Simple Language for Parallel Programming", in Information Processing 74 (Proceedings of IFIP Congress 74, ed. J. L. Rosenfeld), North-Holland, pp. 471–475. Opened: the dblp record https://dblp.dagstuhl.de/rec/conf/ifip/Kahn74.html (author, title, venue, pages), Wikipedia "Kahn process networks" (editor, publisher, model), and S. Edwards's Columbia lecture notes https://www.cs.columbia.edu/~sedwards/classes/2002/w4995-02/dataflow.pdf. I could not open the paper itself.

(b) A field's result, as the secondary sources state it. Sequential deterministic processes communicate only through unbounded first-in-first-out channels. Writing never blocks; "a process that reads from an empty channel will stall"; a process may not test a channel for tokens. Then the sequence of tokens on every channel is deterministic and "does not depend on the timing of computation nor on communication delays". Edwards: "the scheduling algorithm does not affect their functional behavior".

(c) Each process is a monotonic function from input histories to output histories ("Reading more tokens can only lead to writing more tokens"). Paulin-Mohring (2007) describes Kahn's semantics as "the fixpoint of this continuous function" over streams.

(d)
- Reference: confirmed.
- Scheduling-independence of the result: supported.
- "Each process waiting for one arriving token from each input": not Kahn's rule. A Kahn process waits on one channel at a time, chosen by its own program; Edwards: "Can't wait on multiple channels at once". Needing a token on every input before running is the firing rule of dataflow actors, a special case, not Kahn's model.
- What is scheduling-independent is the history of tokens on each channel. How many unconsumed tokens sit in the channels does depend on the schedule: "The number of unconsumed tokens depends on the execution order".

**7. Ring oscillator**

(a) Wikipedia, "Ring oscillator", https://en.wikipedia.org/wiki/Ring_oscillator (opened); also Wikipedia "Static random-access memory".

(b) A field's definition, exact statements available:
- "The ring oscillator uses an odd number of inverters to give the effect of a single inverting amplifier", with "a gain of greater than one".
- "A circular chain composed of an even number of inverters cannot be used as a ring oscillator."
- "The last output in this case is the same as the input."
- "this configuration of inverter feedback can be used as a storage element"; it is "the basic building block of static random access memory or SRAM".
- SRAM page: the transistors "form two cross-coupled inverters"; "This storage cell has two stable states".

(c) An odd chain's output is "the logical NOT of the first input", fed back after the gate delays, so it cannot rest.

(d)
- Odd oscillates: supported, with a caveat the page gives. For unbuffered inverters "an odd number of at least 3 inverters must be used"; a single unbuffered inverter in a loop "will simply have its output voltage equal its input voltage".
- Even does not oscillate and is a storage element: supported.
- "One of two states": supported by the SRAM page for the two-inverter cell.
- "Latch": not on the ring-oscillator page; its words are "storage element" and "SRAM".

**8. Positive set theory (Stanford Encyclopedia)**

(a) M. Randall Holmes, "Alternative Axiomatic Set Theories", Stanford Encyclopedia of Philosophy, first published 30 May 2006, substantive revision 21 September 2021, https://plato.stanford.edu/entries/settheory-alternative/ (opened; section 7 read in three passes).

(b) A field's definitions and results, as the entry states them:
- Axiom of GPK+∞: "For any generalized positive formula φ, {x | φ} exists."
- A positive formula belongs to the smallest class containing a false statement ⊥ and "all atomic membership and equality formulas", closed under "conjunctions, disjunctions, universal and existential quantifications".
- A generalized positive formula also allows bounded universal quantification.
- Axiom of infinity: "The closure of the von Neumann ordinals is not an element of itself."
- Strength: "Not only ZF but also Kelley-Morse class theory can be interpreted"; the proper class ordinal "has the tree property, and so is in effect a weakly compact cardinal".
- New Foundations: "the universal set V = {x | x = x} is provided by an instance of comprehension" and "Moreover, V ∈ V is true."

(c) Positive comprehension is motivated as "an attack on one of the elements of Russell's paradox (the negation)". The sets are the closed classes of a topology on the universe.

(d)
- The quoted axiom: supported. The claim's "(generalized)" in brackets is a gloss; the entry's word is "generalized", unbracketed.
- "Built with no negation": supported in substance. Negation is not among the formation rules, though the false statement ⊥ is included.
- "The set of all things is a set there and a member of itself": not stated in those words in section 7. The entry treats V as a set ("℘(V) does exist and is equal to V") and says {x | x ∈ x} exists. V being a set and a member of itself follows, since x = x is a positive formula, but that is my inference, not the entry's sentence. The entry says "V ∈ V is true" outright only for New Foundations.
- "With an infinite set added its known models ask a large cardinal": supported, with a correction to "an infinite set added". The models are the κ-hyperuniverses for weakly compact κ ("for each weakly compact cardinal κ (including κ = ω)"), and the entry says the use of large cardinals in the construction "was essential". But the axiom of infinity here is the specific statement quoted in (b), which rules out the ω case; it is not the bare addition of an infinite set. Without it the theory is "equiconsistent with second-order arithmetic". The large cardinal is weakly compact, "a moderately strong large cardinal property".
- New Foundations has V ∈ V: supported. "Keeps negation": the entry does not say it in those words; it says comprehension is restricted to stratified formulas, and x ∉ x is excluded because it cannot be obtained "by dropping distinctions of type". Negation is allowed in stratified formulas, so the statement is right but is my reading.

**9. DC machine commutation (eCampusOntario Pressbooks)**

(a) The exact URL given would not open (a permission prompt went unanswered). I opened the same book's page at https://ecampusontario.pressbooks.pub/electrotechnology/?p=365, headed "Part 1 – DC Machine Construction and Operating Principles". I am assuming this is the same chapter as /chapter/part-1-2/; I could not confirm the slug. The page text shows no book title, author or licence; the front-matter pages and a web search did not yield them. The URL slug "electrotechnology" is the only title evidence.

(b) A field's definitions (a textbook, no experiment). The page's sentences, as read:
- "Commutation takes place at the point where the armature coil is moving parallel to the stator field."
- "Improper placement of the commutator results in sparking when the coil segments transfer from one brush to the other."
- "Good commutation occurs when the brushes of a generator are adjusted to compensate for the shift in the neutral plane."
- "The effect of the armature reaction varies with the load current."
- "Every time the load current varies, the neutral plane shifts", then "this means the brush position must be changed each time the load current varies."
- "Two methods of neutralizing the cross-magnetizing effect of armature reaction": compensating windings, interpoles.

(c) Armature reaction: the field of the armature current distorts the main field and shifts the neutral plane. The page gives the start of this sentence only.

(d)
- First quote: supported word for word.
- Second quote: supported word for word; whether the page has a dash between the two halves I cannot say (the reader returned none).
- "Improper brush placement results in sparking": the page's subject is "placement of the commutator", not the brushes. The next sentence, about adjusting the brushes, gives the sense intended.
- Interpoles and compensating windings: supported as the two listed methods. The page says they neutralise "the cross-magnetizing effect of armature reaction" and does not describe how each works.
- The claim is headed "DC motor"; this section is written about the generator ("the brushes of a generator"), with motors mentioned only in passing.

**10. Landauer 1961 and Bérut et al. 2012**

(a) Rolf Landauer, 1961, "Irreversibility and heat generation in the computing process", IBM Journal of Research and Development 5(3), 183–191, DOI 10.1147/rd.53.0183. Not opened; the citation and statement are from Wikipedia "Landauer's principle" (opened).
Antoine Bérut, Artak Arakelyan, Artyom Petrosyan, Sergio Ciliberto, Raoul Dillenschneider, Eric Lutz, 2012, "Experimental verification of Landauer's principle linking information and thermodynamics", Nature 483, 187–189. Opened: https://www.nature.com/articles/nature10872 (abstract only).

(b) Landauer is a field's result: erasing one bit costs at least kT ln 2, about 0.018 eV (2.9×10⁻²¹ J) at room temperature. Wikipedia's words: "the minimum energy needed to erase one bit of information is proportional to the temperature".
Bérut et al.: a single colloidal particle in a modulated double-well potential ("a generic model of a one-bit memory") was put through repeated erasure cycles and the heat dissipated was measured. The mean dissipated heat saturates at the Landauer bound in the limit of long erasure cycles.

(c) Logically irreversible erasure lowers the memory's entropy, which must be paid for as heat to the surroundings.

(d)
- Reference and bound: supported.
- The experiment observed the mean heat approaching the bound from above for slow erasure, not dissipation at exactly the bound.
- Wikipedia lists later tests: Jun, Gavrilov and Bechhoefer (Physical Review Letters 113, 190601, 2014); Hong et al. (Science Advances 2016), about 44% above the minimum; Gaudenzi et al. (Nature Physics 2018).
- The principle's standing as a law is disputed in the literature (Earman and Norton 1998; Norton 2005, 2011).

**11. Onsager reciprocity and fluctuation–dissipation**

(a)
- Lars Onsager, 1931, "Reciprocal Relations in Irreversible Processes. I.", Physical Review 37(4), 405–426. The companion "II" is Physical Review 38, 2265 (1931); a search listed it but I did not open a page for it. Statement from Wikipedia "Onsager reciprocal relations" (opened).
- H. B. Callen and T. A. Welton, 1951, "Irreversibility and Generalized Noise", Physical Review 83(1), 34–40.
- R. Kubo, 1966, "The fluctuation-dissipation theorem", Reports on Progress in Physics 29(1), 255–284.
- Both of the last two from Wikipedia "Fluctuation–dissipation theorem" (opened). None of the originals opened.

(b) A field's results.
- Onsager: for a system slightly out of equilibrium, with fluxes linear in the thermodynamic forces (J_i = Σ_j L_ij X_j), the coefficient matrix is symmetric, L_ij = L_ji, "except in cases where time-reversal symmetry is broken". The page's equation did not render; the symbols are the standard form, the words are the page's.
- Fluctuation–dissipation: the page's statement "relates the two-sided power spectrum" of an observable's equilibrium fluctuations to the imaginary part of the Fourier transform of its linear-response susceptibility. The classical form is S(ω) = (2 k_B T/ω) Im χ(ω); that formula is from my memory, since the page's did not render.

(c) Onsager: the symmetry follows from the time-reversibility of the microscopic dynamics. Fluctuation–dissipation: the response to a small applied force and the decay of a spontaneous fluctuation are the same microscopic process.

(d)
- References and years: supported.
- L_ij = L_ji needs its condition. Onsager's own caveat, as quoted on the page: reversibility "does not apply when (external) magnetic fields or Coriolis forces are present", and then "the reciprocal relations break down" (they become L_ij(B) = L_ji(−B), the Onsager–Casimir form, from my memory).
- Callen and Welton proved the quantum, general form; Kubo 1966 is a review-style statement within linear-response theory.

**12. CPT theorem**

(a) Gerhart Lüders, 1954, "On the Equivalence of Invariance under Time Reversal and under Particle-Antiparticle Conjugation for Relativistic Field Theories", Kongelige Danske Videnskabernes Selskab, Matematisk-Fysiske Meddelelser 28(5), 1–17. Wolfgang Pauli, 1955, "Exclusion Principle, Lorentz Group and Reflection of Space-Time and Charge", in W. Pauli, L. Rosenfeld and V. Weisskopf (eds.), Niels Bohr and the Development of Physics, McGraw-Hill (Pergamon in the UK; pp. 30–51 from my memory, not confirmed). Opened: Wikipedia "CPT symmetry", and the CERN Pauli archive record https://archives.cern.ch/index.php/cern-arch-pmc-05-030 (confirms Pauli's title and 1955 date). Neither original opened.

(b) A field's result, exactly as Wikipedia states it: "any Lorentz invariant local quantum field theory with a Hermitian Hamiltonian must have CPT symmetry". That is, invariance under the combined operation of charge conjugation, parity inversion and time reversal.

(c) The proof rests on Lorentz invariance of the theory and of the vacuum and on energy bounded below. The page credits Schwinger (1951, implicitly), Lüders and Pauli, Bell independently, and Jost (1958) for the general axiomatic proof.

(d)
- References: supported.
- "Are one combined symmetry": acceptable only if it means the combination of all three is a symmetry, given the assumptions in (b). The theorem does not say the three are the same thing, nor that any one of them is a symmetry alone; item 13 shows parity alone is not.
- "The hand" for parity and "matter over antimatter" for charge conjugation are glosses. Exact names: C exchanges particles with antiparticles, P inverts space, T reverses motion.

**13. Wu et al. 1957**

(a) C. S. Wu, E. Ambler, R. W. Hayward, D. D. Hoppes, R. P. Hudson, 1957, "Experimental Test of Parity Conservation in Beta Decay", Physical Review 105(4), 1413–1415. The APS page would not open; details are from Wikipedia "Wu experiment" (opened).

(b) Cobalt-60 nuclei in a cerium magnesium nitrate crystal were cooled by adiabatic demagnetisation to near absolute zero and aligned by a magnetic field. Beta electrons were counted with an anthracene scintillator, and the run was repeated with the field reversed. The count rate differed between the two field directions: electrons came out preferentially opposite to the nuclear spin. Gamma-ray anisotropy monitored the polarisation, and the asymmetry faded as the crystal warmed.

(c) Parity is not conserved in the weak interaction (beta decay), as Lee and Yang had proposed could be tested.

(d) Supported. The title says "Test of Parity Conservation"; what was observed is an emission asymmetry, and parity violation is the conclusion drawn. Wikipedia gives the paper's asymmetry as a lower limit of about −0.7, later refined to −1.01±0.02.

**14. arXiv:2005.14694**

(a) Boulder Atomic Clock Optical Network (BACON) Collaboration (K. Beloy and 34 others, alphabetical), "Frequency Ratio Measurements with 18-digit Accuracy Using a Network of Optical Clocks", arXiv:2005.14694, submitted 29 May 2020. Published as "Frequency ratio measurements at 18-digit accuracy using an optical clock network", Nature 591, 564–569 (2021). Opened: https://arxiv.org/abs/2005.14694 and https://www.nature.com/articles/s41586-021-03253-4.

(b) The frequency ratios of three optical clocks in Boulder, Colorado (the aluminium-27 ion, ytterbium-171 and strontium-87) were measured pairwise (Al+/Yb, Al+/Sr, Yb/Sr) over optical fibre and a 1.5 km free-space link. Fractional uncertainties are between 6×10⁻¹⁸ and 8×10⁻¹⁸ in the preprint ("at or below 8 × 10⁻¹⁸" in Nature).

(c) None given for the ratios themselves. The paper presents them as a step toward redefining the SI second, and uses them to limit couplings of ultralight bosonic dark matter.

(d)
- Three different atoms, compared as ratios of rates: supported.
- "Agree in the ratios": not what the paper says. It measured each ratio to about 18 digits ("the most accurate reported measurements of frequency ratios to date"); it does not say the clocks agree. If "agree" means the three ratios close consistently (Al/Yb × Yb/Sr = Al/Sr), I did not see that stated in either abstract.
- Safer wording: "the ratios of the rates of clocks of three different atoms have been measured to eighteen digits".