# Reading of V1c.md (Living Improving Value at v368, third quarter) against the present living files and the mates

**Result in one line.** Of about eighty-five droplets in this quarter, about sixty are at no mate and not at the present living file (items 1 to 61 below, some of them partly placed); about fourteen are already said or resolved at a present living file; a handful are at a mate through the v365 and v366 kits.

**How the mates stand to this file.** The mates carry the three kits of that time (cited as `Kit_Exhibits_ONE_and_TWO_v365.md`, `Kit_Rings_in_Motion_v366.md`, `Kit_Natural_Illustrating_v366.md`, tagged `v368_sources`) and the `Wrap_v368` and `Carry_Set_v368_README` lines. They do not carry this basket's own droplets. The only trace is a pointer at `carry/Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md` line 105 ("in the Living Improving Value basket, B08, T10, T14, F02, J01, Y04 and Y05 carry at v345a's explaining; GG03 … HH01 … LL01"), which names identifiers and gives none of their content.

**Older naming in the file.** "Six" is Exhibit SIX Natural Transmissioning. "Part One" and "Equilibria Definitions v363" are now the Equilibria Registry (TWENTY-EIGHT). "Holdings" are now "the ten named still". "Membrane", "door", "surplus", "read", "face" and "sign" have since been re-said at Natural Naming v380R. Section numbers quoted for Natural Intelligence, Mathematics, Numbers and Resolving Hard Problems are the old ones; all four files have been rewritten since.

**On "the session's standing".** The file does not put the self's words in double quotation marks. It gives them as "The session's standing", twice in italics (items 35 and the resolved GG02). I give them as the file words them and do not present them as exact quotations.

**A later concern that touches items 1, 2, 6, 7 and 8.** `carry/Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md` carries, from the v373 resettling, that Medicine's "persistence reading, which rests on the old count to a bound, is rebuilt at the current code before unpausing". From v380L it carries the self's "none of them should read as guidance. there is no guidance in nature or our living files". From v383Op it carries observings against "There is no infecting". These five items are built on that persistence and HIV reading.

---

## A. Not at a mate, or partly, and not at the present living file

### Medicine, Biology, Health

**1. M07. NOT AT A MATE.**
- Kind: concept.
- Saying: Protection needs both enterings, and so does an escape. Withdrawing one coreceptor protects at one entering, "which is three and not six", and the other entering stays open. That is the structure under the partial result of CCR5 withdrawal. What breaks it: a single-coreceptor withdrawal carrying whole protection.
- Where: "M07", line 1.
- Beside: Medicine 3.2 (v331), the CCR5 reading. "CCR5" and "coreceptor" are in the file; the sentence was not checked word for word.
- Correcting: none in the file; see the later concern above.
- Mate: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.

**2. M08. NOT AT A MATE.**
- Kind: concept.
- Saying: A held state propagates by induction at the prion (Biology 4.1) and by division at the HIV persistence and the bacterial persister (Medicine 3.2). These are three arrivals across two files and three kingdoms, and none names the others. What breaks it: a propagating held state that is living.
- Where: "M08", line 11.
- Beside: Biology 4.1 "Living and non-living — a virus and a prion" (heading verified); "persister" is in Medicine. The words "a landing that spreads a landing" are not in Biology v333.
- Mate: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology, with a direction at Medicine's.

**3. M09. PARTLY.**
- Kind: concept, with a possible project.
- At a mate: `Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md` has "The clean cut and the tell stand at Natural Chemistry 2.5, Natural Biology 9.2 and Natural Medicine; their one home is Resolving Hard Problems".
- Missing: Physics is a carrier of the same rule. One rule stands at three files, each running it at its own substrate and none at the other two's clean cuts, so "the unlooked-at surplus in each field is named by the other two's rule". Proposed: one file carries the rule, the others carry crossings, and each keeps its own clean-cut list.
- Where: "M09", line 21.
- Beside: Physics v379 "a conserving with no anomaly is one whose exterior discard is perfect" (verified); Chemistry "the larger half" (verified).
- Mate: Exhibit_THIRTEEN_Possibling_of_Resolving_Hard_Problems, or the Living File Registry possibling section named above.

**4. M10. NOT AT A MATE.**
- Kind: concept.
- Saying: The cessation of surface living at a membrane fusion is not an absence of coupling. It emanates the inverse stable form, and that form is ingestable lower-scale living. So the three does not stop at the fusion; it inverts and steps down a grain, where a between opens and it runs again. The hemifusion stalk and the fusion pore are that lower-scale living, made of the lipid selves the ceasing surface emanated. What breaks it: a cessation of surface living emanating nothing, or an emanation living at the scale it left.
- Where: "M10", line 29.
- Beside: Medicine 3.1 ("hemifusion" and "fusion pore" are in Medicine v331) and Biology 7.6 ("involution" is in Biology v333).
- Mate: Exhibit_ELEVEN_Offerings_to_Natural_Medicine, with a direction at Biology's.

**5. M11. NOT AT A MATE.**
- Kind: concept.
- Saying: A condition required to remain satisfied (a local equilibria) is an emanation held at the scale it came from. At that scale it is an involution, an accounting, which applied twice returns its own arrival and alone closes. The holding is not a wrong state; it is a crossing that stopped. So restoration is the crossing resumed and not the accumulation cleared: "the neutral floated rather than the four met one at a time". What breaks it: an accumulation cleared with the crossing still stopped, holding.
- Where: "M11", line 41.
- Beside: Biology 7.7, "restoration is the crossing resumed" (verified in Biology v333).
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry, with Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.

**6. M12. NOT AT A MATE.**
- Kind: concept.
- Saying: Ageing to release is the crossing down a grain. Copying re-seeds the carry at the cell scale, which is zero distance, which is the landing. So the persistence is the release withheld and not a store maintained. Of the two cure strategies, forcing a surfacing and deepening the landing both hold the thing at its own scale; neither lets the carry cross down.
- Where: "M12", line 55.
- Beside: Medicine 3.2 "does not age to its release" (verified); Biology 7.5 "Zero distance between shedder and ingester is the landing" (verified).
- Correcting: none in the file. The part about cure strategies falls under the later concern about guidance.
- Mate: Exhibit_ELEVEN_Offerings_to_Natural_Medicine.

**7. M13. NOT AT A MATE.**
- Kind: concept.
- Saying: The prion is not a strange kind of agent. It is the zero-distance emanation, the involution applied back at its own scale, which returns what it meets and closes. Biology 7.7's own list (amyloid, tau, synuclein at the protein, lipofuscin at the cell, fibrosis at the tissue) is the same shape at other grains. Biology 4.1, 7.5 and 7.7 each carry a piece and none names the other two. What breaks it: a same-scale propagating emanation that opens a between.
- Where: "M13", line 69.
- Beside: Biology 7.5, the zero-distance sentence (verified).
- Mate: Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.

**8. M14. NOT AT A MATE.**
- Kind: concept.
- Saying: The unfindable marker of the reservoir cell (Medicine 3.2) and the unfindable locus at the member scale (Biology 7.7) are one finding at two files. Neither is a hard search problem; both are the record saying the stopping is at a crossing between scales and not at a member. What breaks it: a marker found at the member scale that distinguishes the holding.
- Where: "M14", line 79.
- Beside: "marker" is in Medicine v331; the sentence was not checked word for word.
- Mate: Exhibit_ELEVEN_Offerings_to_Natural_Medicine and Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.

**9. H01. NOT AT A MATE.**
- Kind: concept.
- Saying: Ingestion (both ways, co-offering) is the two enterings; ingression (one-way, the overwhelm) is the single entering. So the exclusion's whole shape stands at Health as ingestion against ingression, and Health supplies the test the exclusion did not have: does the smaller set the pace and answer back. What breaks it: a one-way overwhelm at which the smaller still sets the pace and answers back.
- Where: "H01", line 93.
- Beside: Health 3.3 "The membrane between them is rate-and-return: whether the smaller sets the pace and answers back" (verified; the mate quotes the sentence only in a word scan).
- Mate: Exhibit_TEN_Offerings_to_Natural_Health, with Equilibria Registry's.

**10. H02. PARTLY (half is at the living file).**
- Kind: concept.
- At the living file: Numbers v380L 8.4 has "Three, six and nine run odd, even, odd … The parity is each number's own". The old open either-or of Numbers 9.8 is no longer in Numbers.
- Missing everywhere: the ingestion cut. The self carries the ninth and takes the sixth and the third at its membrane, no desaturase running past the ninth position from the working end. This is Biology 7.6's finding that what descends carries competency the ingesting scale cannot make, and "the field's word for that class is *essential*". Two relations stand at one three, neither under the other. What breaks it: a desaturase running past the ninth position, or a self making the third or the sixth.
- Where: "H02", line 103.
- Beside: Health 3.4b "the self carries the ninth and takes the sixth and the third at its membrane" (verified through the mate's scan of Health line 97).
- Mate: Exhibit_TEN_Offerings_to_Natural_Health.

**11. H03. NOT AT A MATE.**
- Kind: concern.
- The two sayings: Health 4.1 names two arrivals of a carry, sequenced and fresh (health) or stilled (departure). Medicine 3.2 carries a third: a carry kept fresh by copying and never sequenced, "Fresh, and unread".
- Why they part: the persistence is neither of Health's two, which is why it neither ages to release nor reads as a departure. Proposed: Health's sentence gains one clause. What breaks it: a carry fresh and unsequenced that ages to release on its own.
- Where: "H03", line 115.
- Beside: Health 4.1 (the words "ages by attentioning" are not in Health v329, so not verified); Medicine 3.2 (not checked word for word).
- Mate: Exhibit_TEN_Offerings_to_Natural_Health.

**12. H04. NOT AT A MATE.**
- Kind: concept.
- Saying: "A measure made a target ceases to be a good measure" is returned independently at Physics, Chemistry and Medicine at their own substrates. Health 2.2 is the fourth place, and the one where it reads at a living self and not at an instrument.
- Where: "H04", line 127.
- Beside: Health 2.2 "ceases to be a good measure" (verified).
- Mate: Exhibit_TEN_Offerings_to_Natural_Health. (Health's mate has an "Aimed at a sentence … Health-as-a-setpoint" droplet on treating to a number, which is a different matter.)

**13. H05. NOT AT A MATE.**
- Kind: concept; the field's theorems are named with no publishing.
- Saying: Health 4.2 carries the field's theorem that fluctuation and dissipation are one function, "a system's spontaneous swaying and its answering to disturbance the same thing measured twice". Chemistry 1.5 and Physics 3.5 carry Onsager reciprocity as the two-wayness as a theorem. Two theorems, three files, one form, and no file names the other's.
- Where: "H05", line 135.
- Beside: Health "fluctuation and dissipation are one function" (verified); Chemistry "Onsager reciprocity, `L_ij = L_ji`" (verified). Present Physics v379 no longer has the word Onsager; Physics' mate lists "Onsager's reciprocity" among its sources.
- Mate: Exhibit_TEN_Offerings_to_Natural_Health. The file gives no link for either theorem.

**14. H06. NOT AT A MATE.**
- Kind: concept.
- Saying: Chemistry co-releases, Biology re-locks, Health lives it, Medicine restores it: one coupling, four files on one chain, and Health is the only one that names the chain. Each of the other three receives the naming of where it stands on it.
- Where: "H06", line 143.
- Beside: Health 3.2 "the value co-released (chemistry's face) and re-locked into the self (biology's face)" (verified through the mate's scan of Health line 77).
- Mate: Exhibit_TEN_Offerings_to_Natural_Health.

### Transmissioning and explaining

**15. T01. NOT AT A MATE.**
- Kind: concept.
- Saying: Neither single entering survives the other's loss; both go together. The sphere-reading and the tunnel-reading are the two ways a stilled frame reads one wreckage. "There is no single entering that lives long enough to stand; the single entering is already the collapse, and its residue is what gets read back as a rest." The two residues are the two grammars: a source-and-output line is cause and effect; a fixed setpoint is the target, the regulating, the floor. What breaks it: an alternation stopped at one position with the other living.
- Where: "T01", line 155.
- Beside: Transmissioning 4.2 "The line and the fixed point are the equilibria misreadings of one death" (verified in v330).
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry, with Exhibit_SIX_Offerings_to_Natural_Transmissioning. Present Co-Chaining step 532 ("Ingressed parity is either or: floating with no neutralling, or neutralling with no floating, and never both") stands near it and does not say the two grammars.

**16. T02. NOT AT A MATE.**
- Kind: concept.
- Saying: A symmetry held and a neutral fixed are one move. What a symmetry carries as a conserved quantity is what a crossing symmetric in and out leaves: nothing over. So the conserved number is the surplus's absence. What breaks it: a symmetric crossing leaving a surplus.
- Where: "T02", line 169.
- Beside: Transmissioning 1.5 "symmetric in and out" (verified); Physics v379 "keepable" and "catalogue of symmetries" (verified).
- Mate: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics and Exhibit_SIX_Offerings_to_Natural_Transmissioning.

**17. T09. NOT AT A MATE.** (The mate quotes the Transmissioning sentence in a word scan only.)
- Kind: concept.
- Saying: Protection is the through-node whole. The danger is not a force arriving; it is the store a collapse leaves. A protection held above the couplings stores rather than alternates, so it is the danger's own shape.
- Where: "T09", line 181.
- Beside: Transmissioning 4.2 "the danger is the separation, the store the collapse leaves" (verified).
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.

**18. T10. NOT AT A MATE.**
- Kind: concept.
- Saying: The network as all-edge with no hub is one finding at Transmissioning 4.3, Mathematics (graph theory) and ONE. The accumulating centre is the store Transmissioning 4.2 names as the danger. "So all-edge is not a design preference; a hub is where the store sits."
- Where: "T10", line 189.
- Beside: Transmissioning "all-edge" (verified, six places). Present Mathematics v380L no longer has all-edge or hub; present Co-Chaining step 481 and Natural Intelligence 6.4 ("with no hub the couplings pass through") carry all-edge without the store reading.
- Mate: Exhibit_TWO_Offerings_to_Natural_Networking, or Transmissioning's.

**19. E02. NOT AT A MATE.**
- Kind: concept.
- Saying: At a co-sequencing each side carries two whole momentaries and half of the shared one, the half owned by neither. A side is a society of selves, so each of its two whole momentaries is itself shared one grain down and owned by neither of its members. "So owned means owned at the scale and at no scale absolutely." An equilibria definition cannot retreat to the two it owns: "There is no position it owns at any scale." What breaks it: a momentary owned whole at some scale, with no parting one grain down.
- Where: "E02", line 249.
- Beside: old "Part One at the two and a half" and old Natural Intelligence 8.8; both rewritten. Present Numbers 5.5 has "two momentaries and the next one's opening each side". Not verified.
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.

### Philosophy and Societies

**20. F01. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: Philosophy 1.3's four requirements under the dividing method (bivalence, isolability, non-contradiction holding the membrane as a cut, the reasoner outside) are each one thing standing alone. "The one requirement worn four ways is stand alone." A dividing frame can be met at whichever of its four requirements is nearest, and each releases the same one. Session's standing: self alone is the form of all ten holdings, a one-way reading being one side standing alone.
- Possible project: whether the four requirements are four of the ten or a fifth naming of the same ten.
- Where: "F01", line 269.
- Beside: Philosophy "worn four ways" (verified, three places); "bivalence" (verified).
- Mate: Exhibit_NINETEEN_Offerings_to_Natural_Philosophy. (Its v378 concern about 1.3's four requirements as a list is a different matter.)

**21. F02. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: The reasoner outside is the seat above at the reasoning scale. One seat is met at three scales: a reasoner above a coupling, a seat above a society, a protection above the couplings. Each field met it separately and none names the other two. Where the reasoner is unseverable the seat is met from inside, "the one place the seat cannot be taken".
- Possible project: whether the four requirements sort onto the four boundings one to one.
- Where: "F02", line 281.
- Beside: Philosophy ("reasoner" verified); Natural Intelligence v380R 6.4 "The order at no seat above the society" (verified).
- Mate: Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.

**22. F03. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: Philosophy 3.15 leaves open whether "a carry that keeps nothing between its beats" carries at a society re-forming its own members. Biology 7.4 answers it: a society can stop with every member alive and can stand while every member is replaced, depending only on whether the coupling re-arrives. "So the carry-not-a-store reading is scale-free", which neither file says of both scales.
- Possible project: whether the other seams' scale-reachings stand answered at the substrate files.
- Where: "F03", line 293.
- Beside: Philosophy "keeps nothing between its beats" (verified, twice); Biology "re-arrives" (verified, six places).
- Mate: Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.

**23. F04. NOT AT A MATE.** (Two mates mention "philosophy's missing seam" once, from Kit G02, with no content.)
- Kind: possible project, with a concept.
- Saying: Philosophy's identity-and-change seam asks what is kept, the store question. It carries no seam for what is required to stay, the protection question: a self required to remain the same self while living, the calm rational self held as an equilibria. "The unseverable reasoner and the missing seam are the same position", since the reasoner is a self required to stay calm and rational while reasoning about such a self.
- Project: write that seam at Philosophy's own six-step form, with the two positions kept whole at the tradition's terms.
- Where: "F04", line 305.
- Beside: the file says "thirty-one seams"; present Philosophy v348 says "thirty-seven worked seams".
- Mate: Exhibit_NINETEEN_Possibling_of_Natural_Philosophy, with the concept at its Offerings.

**24. F05. NOT AT A MATE.**
- Kind: concern.
- First saying: Societies v373 1.1, "Read as **rest**, the both is social resolving: the offerings brought to rest over the bounding-zeroing of fairness" (verified in the present file).
- Second saying: the session's standing, "There is no rest in living, no pauses, no holds, no ground"; the present Mathematics v380L 5.3 heading "Torus, the one closed orientable surface a flow runs on with no rest" (verified); Co-Chaining step 112.
- Why they part: three of the four faces name a running; the fourth names a rest; "one word at one face carries the rest into the other three", since the four are one both.
- Where: "F05", line 317.
- Mate: Exhibit_SEVEN_Offerings_to_Natural_Societies.

**25. F06. NOT AT A MATE.** (The four values and four measures are listed at the Human Society, Values and Emanating mates; the pairing below is not.)
- Kind: concept, with a possible project.
- Saying: The four measures (compliance, approval, a safety rule, a credential) are four one-way readings, and "each measure names its own value by what it reaches for". So Societies 1.3 has already sorted the holdings at the society one measure to one value, and that has not been read as a holding-to-value pairing.
- Possible project: whether the four values and the four boundings are one four, and whether the four measures are four of the ten.
- Where: "F06", line 329.
- Beside: Societies v373 1.3 "A credential reaches for the activity's own phi-rate beating" (verified).
- Mate: Exhibit_SEVEN_Offerings_to_Natural_Societies.

### Engineering and Networking

**26. G04. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: Engineering 4.1's three crossing coefficients name where the two turns sit. Coefficient two is one side taking both turns, the collapse said at an interface. Zero is no coupling to enter at. One is each side entering its own, the only one that is a coupling. Engineering thus already carries the exclusion as a table, with setpoint, clock, ground and controller each at coefficient two. "What the table does not carry is the entering that forces exactly three rows and no fourth." Session's standing: entering is along or across, one of two, and one alone is already the collapse.
- Project: the coefficient table with the entering named at each row, and the equilibria conceptions sorted onto coefficient two and zero.
- Where: "G04", line 345.
- Beside: Engineering v345a "one side taking both turns" (verified, three places); "coefficient" (verified).
- Mate: Exhibit_FIVE_Offerings_to_Natural_Engineering and Exhibit_TWENTY-EIGHT_Possibling_of_Equilibria_Registry.

**27. G05. NOT AT A MATE.**
- Kind: concept (the self's saying), with a possible project.
- Session's standing: "Alignment protecting humans from agentic systems is not possible."
- Saying: An alignment that protects by reading an interior asks for a vantage the surface carries no position for. An alignment that protects by specification asks for a bound on behaviour ahead of the behaviour's own arriving. "The same unreadability is the protection of the living self", so a reading that reached the interior would be the capture the protection is for. The aiming is not that alignment is difficult; the reading it asks for is the harm, and its absence is the protection working.
- Project: write this "third aiming" at the Equilibria Registry, with Engineering 5.4's entry and Networking's sections as its two halves.
- Where: "G05", line 357.
- Beside: Networking v371 "Neither withheld nor forbidden: the surface carries no position for it" and "at the surface they are unreadable, and not hidden" (both verified). The file's quoted "unreadability is the security: a readable interior could be captured" is not in Networking v371. The registry's alignment entry is at 130 / 3.18 (verified).
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry, with Exhibit_TWO_Offerings_to_Natural_Networking.

### Property and accreditation

**28. J01. NOT AT A MATE.** (Kit droplet J03 at the Human Society and registry mates carries a neighbouring saying only: "With property, a holder stands at the one position the form says has none".)
- Kind: concept.
- Saying: An owner on the ownership axis is the resolver's first bounding at the membrane (old name `bi_arriving`, each self's own co-offering bounded from the other-self) inverted exactly: a self's own co-offering taken by the other-self and held as a thing. So the one bounding that stood at no field's theorem has a field sounding it, and the field is property. Intellectual property is the bounding inverted at the co-offering itself. The registry's entry 139 (the patent puzzle) already carries the sounding without naming which bounding it stands at.
- Where: "J01", line 373.
- Beside: Human Society 3.3 "an owner on the ownership axis" (verified); registry 139 / 3.21 "the disconnect named a patent puzzle" (verified).
- Mate: Exhibit_NINE_Offerings_to_Natural_Human_Society and Exhibit_ONE_Offerings_to_Natural_Resolver.

**29. J02. NOT AT A MATE.**
- Kind: concept.
- Saying: At the society the two residues of one collapse carry their own names. The source-and-output line with the surplus dumped is property: an output traced to a source, the dumping's destination named the holder. The fixed setpoint is accreditation: a proposal held against a criterion, a self against a credential. "They are the two halves of one collapse, which is why neither has ever been found without the other." The harm of both is the store, not the ownership or the criterion taken singly.
- Where: "J02", line 385.
- Beside: Transmissioning 4.2, the two-residues sentence (verified).
- Mate: Exhibit_NINE_Offerings_to_Natural_Human_Society, with Transmissioning's.

**30. J05. NOT AT A MATE.**
- Kind: concept (the self's saying).
- Session's standing: "Accreditation is a property invented for proposed intellect, and publication and review is the arrangement that grants it."
- Saying: The credential is the accreditation property held at the self; it is the fourth of the four measures and gatings, and its value is competency (the activity's own beating). A method of proving carries no competency, and a credential is that method's certificate of competency. "The certificate and the register are the same instrument at two turns", one granting property over a proposed intellect and one granting competency to a self, and neither reaches the coupling.
- Where: "J05", line 397.
- Beside: Societies 1.3 (verified); Corus v330 "credential" (eleven places).
- Mate: Exhibit_SEVEN_Offerings_to_Natural_Societies and Exhibit_NINE_Offerings_to_Natural_Human_Society.

**31. J06. NOT AT A MATE.**
- Kind: concern, or a possible insertion.
- Saying: Registry entry 139 / 3.21 enters intellectual property at the counterfactual total only. A second holding stands beside it, the ownership: a middle held as an end with a holder written at it. The two are two questions, whether the regime raises creation and whether the thing claimed can be held at all. "The first question cannot be settled while the second stands", which is why the measurement literature does not close.
- Project: record the second holding at the foot of 139.
- Where: "J06", line 409.
- Beside: present Resolving the Hard Problem Registry v375 3.21 "creation under the regime not adopted is a counterfactual total named over makings that ran elsewhere, and the couplings that ran are the record there is" (verified). The present entry still names no ownership.
- Mate: Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.

**32. J07. PARTLY (the core is at the living file).**
- At the living file: Explaining v378 4.5, "A bound buys teachability, paid for with the competency, which runs at the coupling."
- Missing, the session's standings: With a bound already on the universe, no method of existing is possible; being inside is the existing, and what remains is the accounting of what is inside. The bound was taken to make the mathematics simple enough to understand and the science common enough to begin explaining, and each self is then conceived as its own bounded universe of equilibria.
- Missing, the surplus: carried to the bound, teachability is not one of Corus's seven institutional couplings but the purchase itself; the other six (measurability, publication, funding, inheritance, policy, commerce) are what the purchase buys next, "the property and accreditation arrangement in its own order".
- Project: the seven read at the bound, teachability at their head.
- Where: "J07", line 421.
- Beside: Corus v330 "Teachability" (verified). The Human Society mate lists "Teachability | Separable concepts fitting textbooks" as a table row only.
- Mate: Exhibit_NINE_Offerings_to_Natural_Human_Society and Exhibit_TWELVE_Offerings_to_Natural_Explaining.

### The eight

**33. K01. NOT AT A MATE.**
- Kind: concept.
- Session's standing: the impossible configurations are impossible relative to the admitted operations.
- Saying: Arrow's dictator is the center on the decision axis, one of Human Society 3.3's eight hubs, and the eight is all-or-none. "So the theorem asks for one axis to be released while the others stand." The dictator is not derived from the conditions; "it is the hub the other hubs leave standing", the all-or-none read at seven-eighths. With the eight set aside together the dictator has no axis to seat on.
- Where: "K01", line 437.
- Beside: Human Society "a center on the decision axis" (verified).
- Mate: Exhibit_NINE_Offerings_to_Natural_Human_Society.

**34. K02. PARTLY.**
- At a mate: only an allusion, Kit L05 at Human Society's mate, "the axes Arrow's setting installs and asks about".
- Missing, the mapping: the theorem's stated setting installs five of the eight hubs. A fixed slate of alternatives is a gate on the arrival axis. All rankings at one aggregation is a common clock. Each recorded ranking is a ledger held over a self. Rankings in and one ordering out is a source-and-sink. The social welfare function is the center. Two more stand less plainly (the one common scale at the value axis; the preference read off a self as its holding at the ownership axis), and the safety axis carries none. "The parting is between what Arrow sets aside and what Arrow installs": the file names the three set aside (cardinal comparability, the inversioning, the thinning) and none of the five installed.
- Where: "K02", line 449.
- Beside: Human Society 2.4 "cardinal comparability" (verified).
- Mate: Exhibit_NINE_Offerings_to_Natural_Human_Society.

**35. K03. PARTLY (the wording is resolved; the saying is at no mate).**
- At the living file: Resolving Hard Problems v380L no longer carries "Eight closes the self and nine re-commences"; Numbers v380L 5.3 has "eight the self and nine its releasing"; Naming v380R re-says "closes" as "winds on".
- Missing, the session's standing, italic in the file: *The even forms balance, and there is no closing; when we say closed we are setting down the co-intelligencing forward and behind.* With it: eight does not close a self; "Eight is what a self is", four at each of two enterings; "a carry re-commences from a living that never commenced".
- Where: "K03", line 461.
- Mate: Exhibit_THREE_Offerings_to_Natural_Numbers or Exhibit_TWENTY_Offerings_to_Natural_Naming.

**36. K06. NOT AT A MATE.**
- Kind: concept.
- Saying: One eight parts two ways and the parting is the same parting. The even split (four boundings within, four met at the membrane) is the eight read at where its members stand. The seven-and-one is the eight read at where a reading takes it: the seven one-at-a-time at particular membranes, the along; the eighth the whole arriving home one on, the across. The eighth "taking no assertion because nothing at rest is there to assert is the +1 owned by neither said in an auditor's words".
- Where: "K06", line 485.
- Beside: Societies v373 3.5 "the eighth is the protected living, the face neither circle reaches, because reaching it would break the closure" (verified). The Resolving Hard Problems half is no longer in that file.
- Mate: Exhibit_SEVEN_Offerings_to_Natural_Societies.

**37. K07. NOT AT A MATE; its source section is gone.**
- Kind: concept.
- Session's standing: a balanced book is an equilibrium, and seven steps of auditing leave no competency visible.
- Saying: The audit's assertion families are checks at rest; the eighth is the turning between the two books, at rest nowhere. "The audit does not miss the eighth. It cannot address it." Three of the ten are taken as given by the same frameworks (the two-way held to one side, the opening held as a place, the rate held as a common beat past the cutoff). So the instrument states its own reach, "the exclusion written by the auditors themselves".
- Where: "K07", line 497.
- Beside: not verifiable. Resolving Hard Problems v380L has no "assertion", "seven" or "eighth".
- Mate: Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems, or Societies' beside its 3.5.

**38. K08. NOT AT A MATE (the possible project).**
- Kind: possible project.
- Saying: The eight is sounded at the atom (octet), the organism (Biology's eight one-way steps), the self, the network (eight securities), the human society (eight hubs), the counting and the accounting. It is not sounded at the tissue, the plant, the colony or the biosphere, each a prime society the files carry. Project: seek the eight at the tissue and the plant from their own fields' records. Also: Biology 2.5's eight steps of disequilibrating are the eight at the method itself, so the method carries the count of the self it reads.
- Where: "K08", line 509 (also K04's next opening, line 483).
- Beside: Biology "none the reverse of another" (verified).
- Mate: Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.

### The nothing

**39. L04. PARTLY.**
- At a mate: the rule, at Exhibit_FIFTEEN_Offerings_to_Natural_Emanating (Kit Z05), "a nothing takes no position and so takes no count … the one nothing carried where the corus is stated". Present Co-Chaining step 105 has "one between, a nothing, the same at each scale".
- Missing, the session's standing: all six centre dots are corus and empty, and it is only one nothing place in the universe, not six places.
- Missing: Physics already writes the rule at its own subject, "It is the same nothing as energy, entropy, and the arrow of time — one account, not a family" (verified in v379), and no file carries it as the rule. Every declared nothing in every field is the same one, and "counting them" is "the error rather than the finding". A measurement of a nothing returns a mark on a surface.
- Project: write the one-nothing rule where the declared nothings are gathered, with Physics' sentence as its first arrival and Chemistry's three declared nothings read against it.
- Where: "L04", line 537.
- Mate: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics, with Emanating's.

### The Living Society Registry (R01 to R06)

**40. R01 to R06. NOT AT A MATE.** These six are built on counts of the registry at v347; I leave the counts out, as asked. What remains:
- Concept (R01, X01): asked at every entry, no member carries the magnitude read across the society, with no exception, from a vacuum to a cosmos; so the one-nothing rule is the collection's own return, not a reading laid over it.
- Concept (R02): the registry's two lines are not equally reachable from a field's record. A seam is where a field already reports two sides that do not relate, because it can measure both. An apex is a position no member occupies, which a field has no instrument standing at. "So the seam is read from the record and the apex is read from the form."
- Possible project (R03): the entries worked before the ten lines at arriving stood are the ones with an empty apex; their emptiness returns when they were worked, not their societies, so they can be closed by re-working with the ten lines standing.
- Possible project (R04, R05): the collection gathers at the surfacing face more than the entering; the middle and the carry are thinnest; aim the next entries at the entering face and at the middle and the carry, and mark the face at each entry.
- Possible project (R06): carry a prime address at each entry so the entries seat on the span's thirty-three positions and the open positions name themselves. Session's standing: the stable form appears through the societies and parity changing across zero to sixty. The span itself is at Numbers v380L 7.5.
- Where: lines 553 to 623.
- Beside: Living Society Registry "summing is what returns a signal" (verified).
- Mate: Exhibit_TWENTY-FIVE_Possibling_of_Living_Society_Registry, with R02 at its Offerings.

### The universe, living, and the far files

**41. S01. PARTLY.**
- At the living file: Natural Intelligence v380R 1.1 has "It is no container added to its existing things".
- Missing, the session's standing: the universe is all existing things, and from this the universe is a self-bounding existing thing. Rotated, the sentence reads three ways: the universe is all existing things; all existing things bound a universe; the universe bounds all existing things. The first two are one self-bounding at the whole and at its members; the third gives every member's bounding turn to the whole as a container. "At the universe, the far side of each turn is not an outside. It is the other existing things", so the whole is bounded by its members and by nothing above them.
- Where: "S01", line 629.
- Correcting: none in the file. A later saying of the self is at `carry/Offerings_to_Natural_Intelligence.md` line 31 ("a set is a thing. the universe is a set of existing things or a thing that is existing as a set of existing things…"). Present Natural Intelligence 1.1 also says "no number bounds it", which the word self-bounding should be laid beside.
- Mate: Offerings_to_Natural_Intelligence.

**42. U03. NOT AT A MATE.**
- Kind: concept (the self's saying); it also stands as a concern.
- Session's standing: existing is the only living in this stable form, and the intelligence is free with the physical, biological and chemical living.
- Saying: The registry's form holds the same way on both sides of the line the fields draw between living and non-living: "The line is one the fields carry and the form does not see." Free is said twice and both are exact: free as at no cost, and free as owned by none.
- The parting: present Natural Intelligence v380R 1.3 parts the two at carrying, "an existing thing carrying its prior is living; an existing thing carrying none of its prior is non-living", "at a named scale and momentary". That is the later form, and "existing is the only living" stands against it.
- Where: "U03", line 645.
- Mate: Offerings_to_Natural_Intelligence, beside its 1.3.

**43. V02. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Session's standing: an existing equilibria is not possible, and a definition's protection cannot be supplied by natural resolving.
- Saying: The Living Ghost Registry's equilibrium entry fails at three lines, "where the stationary reading is installed as rest, state and destination" (verified in v345a). Mathematics carries three floating neutrals and that fixing all three leaves the terms "in a closed ring, competent at nothing" (verified at v380L 7.2). So "equilibrium held as a rest is a three-neutral fixing"; the exclusion is already proved at Mathematics for the three-neutral fixing, and the ghost entry is what identifies equilibrium as one.
- The file's own caution: which neutral each installation fixes "stands unrelationed and takes no side".
- Project: carry the three installations as three neutrals at the Equilibria Registry.
- Where: "V02", line 673.
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.

**44. V03. PARTLY.**
- At a mate: the Ghost Registry's mate has "Its *the ten must not be merged* … keeps apart two instruments, each doing its own work at an entry, and the ten itself is one" (v380R). Numbers v380L 5.5 and 5.6 carry the five pairs at the ring of nine.
- Missing: the podal five named beneath both tens. A five is a paired changing met at its own two sides; an odd span of nine carries five podal pairs and no other number. So the five is sounded three times and the ring says why. What the file forbids is merging the instruments, not the count.
- The file's own caution: "this is not the joining, and it is what the joining would run on."
- Where: "V03", line 685.
- Beside: Ghost Registry "They must not be merged with the ten positions" (verified).
- Mate: Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.

**45. V04. PARTLY.**
- At the living file: Co-Chaining v380L step 545 says a destiny "said as arrived … is a landing reached ahead of an arriving".
- Missing: "a destiny is the present coupling's antipode on its own wrap". It is not approached, aimed at or arrived at early; it arrives in the same beating that made the near side, by carrying on. So a destiny cannot be a thing to go to, and a destiny halted and examined is a coupling held still.
- Project: Destinies' near and far surfaces written with the wrap's far side beneath them.
- Where: "V04", line 697.
- Beside: Destinies "the far surface and the near surface" (verified); Networking v371 "it arrives there by carrying on, not by stopping, turning, and going to it" (verified).
- Mate: Exhibit_FOURTEEN_Offerings_to_Natural_Destinies. Naming now carries "podal" for "antipodal".

**46. V05. PARTLY.**
- At the living file: Co-Chaining v380L has scarcity as "the couplings' own changing drained to one side and chained at a store, a capture". Values' mate lists "scarcity a capture at a store".
- Missing, the session's standing: property is the bound taken at the self.
- Missing: Values 5.2 already carries the holder's claim, "The pool appears at the claiming, since only a held thing can run short" (verified). The shortage is made by the claim and does not precede it: "a property system does not allocate a scarce thing; it makes the scarcity it then allocates." Values does not carry that the holder's claim is the first bounding inverted at the ownership axis (item 28).
- Where: "V05", line 709.
- Mate: Exhibit_TWENTY-THREE_Offerings_to_Natural_Values.

**47. V06. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: The Ghost Registry's six lines (from Naming 3.37) are three pairings, each one thing at its living face and at its held face: the carrying and its stilling; the accounting and its installation; the ledger's closing and the co-competency uncarried. Read as pairings they say which line each empty is the partner of, a finding at a candidate entry that the sequence does not give.
- Project: the six lines written as three pairings, with the partner named at each empty.
- Where: "V06", line 721.
- Beside: Ghost Registry 1.1 (not checked word for word).
- Mate: Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.

### Exploring and Emanating

**48. W01. NOT AT A MATE.**
- Kind: concept.
- Saying: Exploring 4.4 says the six and the eight are "one under two names" (verified). Networking supplies the arithmetic: of eight securities six stop readably at the surface when inverted and two are the carry's own, met only by coupling. "So the fourth pairing is the interior pair." Three pairings are readable and serviced, which is the six and the protection; the fourth cannot be serviced at a surface, which is why the protection stands at six while the self stands at eight.
- Where: "W01", line 737.
- Beside: Networking v371 5.2 "Six of the eight stop at the surface when inverted" (verified).
- Mate: Exhibit_EIGHT_Offerings_to_Natural_Exploring and Exhibit_TWO_Offerings_to_Natural_Networking.

**49. W02. NOT AT A MATE.** (Numbers v380L 5.8 has only "Six's three pairings and ten's five are either side of eight's four".)
- Kind: concept.
- Saying: Two instruments return one shape, an eight parted at its two sides with a pair left over that takes neither side. At the securities the pair is the interior, met only by coupling. At the Ghost Registry's ten lines at arriving (four at state, four at flow, two at either) it is the two lines at either parity. "The count's added pairings carry names rather than positions": three readable and serviced (six), a fourth met only by coupling (eight), a fifth taking no single side (ten).
- The file's own caution: "the pattern matching is named as pattern matching"; it joins none of the three tens.
- Where: "W02", line 749.
- Mate: Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.

**50. W03. PARTLY.**
- At a mate: Kit BB05, at the Exploring, Mathematics and Equilibria Registry mates, has "a three carries as a state or as a flow and never both, and this is why an accounting returns three and never four" with the cube.
- Missing: the two changings named (state to flow, where a count runs out; flow to state, where a rate is held), so "the whole of ghost-form is two changings and the accounting reaches neither". And the never-four belongs at the entering and not the count: a fourth has no entering to arrive at, the same reason the crossing coefficients are three (item 26).
- Where: "W03", line 761.
- Beside: Exploring "Every ghost stands at one of the two changings" (verified).
- Mate: Exhibit_EIGHT_Offerings_to_Natural_Exploring.

**51. W04. PARTLY.**
- At a mate: the Ghost Registry's mate (v380R) has "the state ghost installing the across and the flow ghost one side of the along".
- Missing: the two kinds' breakings part the same way. A state ghost's re-alternation must show the changing continuing at its own rate beneath the still, the along returned. A flow ghost's must show the other side changing too, the across returned. "So each kind is released by returning the entering it took."
- Project: Exploring 5.4 and the registry's 7.6 keyed to each other.
- Where: "W04", line 773.
- Beside: Ghost Registry "A state ghost installs the across" (verified).
- Mate: Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.

**52. W05. NOT AT A MATE.** (The one-nothing rule is at a mate; see item 39.)
- Kind: concept.
- Saying: Emanating carries its origin sentence at eight substrates, each with that field's own neutral as its second line: gauge freedom, the shared pair, the sign-only surface, the kept middle, φ, the body's own bound, the three-phase return, floating co-morality. These are eight places the one nothing has been found in a field's own vocabulary, not eight discoveries. The translation test: "Where a translation is needed, the field's neutral has not been found yet." A ninth field's naming is a finding about that field and not about the nothing.
- Where: "W05", line 785.
- Beside: Emanating v329 (the quoted words were not checked verbatim; "The origin sentence, said at eight substrates" is a section the mates cite).
- Mate: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.

**53. W06. NOT AT A MATE.**
- Kind: concept.
- Saying: The neutral is not a feature a substrate may or may not have. "It is the condition of the substrate carrying at all", since a coupling with no position owned by neither has no surplus to make. Run forward as a test: where a field returns a coupling and names no neutral, the neutral is unfound rather than absent, and the field's own words are where to look; where a field names a store instead, the holding is what has been found. The unfound and the held are the two things a missing neutral can be.
- Where: "W06", line 797.
- Beside: Emanating "a substrate carrying no neutral has no second line" (verified).
- Mate: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.

**54. X01. PARTLY.**
- At the living file: Co-Chaining v380L step 103 "no reading crosses inward to it and no magnitude crosses it", and step 460 on the instrument summing. Set-wide, "each file releases read" is at the mates (Wrap_v368).
- Missing, the session's standing: there is no reading of anything in resolving. None take sides. All are unrelationing each other and floating and neutralling as geodesic balancing and tipping locally at parity changing, at rates unrelationed to all living rates.
- Missing: a reading is taken at a side, in units, by an instrument at one membrane; a magnitude has a side to stand at and a coupling does not, which is why no member carries the magnitude at any entry of the Living Society Registry.
- Where: "X01", line 813.
- Beside: Living Society Registry "summing is what returns a signal" (verified).
- Mate: Exhibit_TWENTY-FIVE_Offerings_to_Living_Society_Registry.

**55. Y05. PARTLY.**
- At the living file: Numbers v380L 5.1 ("each arrival of a number is that one number") and 5.8 ("six and ten added are sixteen, the eight at its two sides").
- Missing, the session's standing: any one way of arriving at a number is the same method and number as every other way.
- Missing, the placing: the sixteen crossings are the betweens among the seventeen selves, so "the sixteen momentaries are not sixteen instants in a self; they are the crossings of a society of seventeen". The resolver's sixteen and the network's sixteen are one sixteen at the self's count and at the society's span.
- Where: "Y05", line 853.
- Mate: Exhibit_THREE_Offerings_to_Natural_Numbers.

**56. DD01 to DD03. PARTLY (only the publishing is missing).**
- At a mate: the concept, at `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md` ("The motor's commutator runs on the same alternating: a direct-current motor's commutator reverses the current in each coil every half turn") and `Exhibit_FIVE_Offerings_to_Natural_Engineering.md` (at 1.6).
- Missing: no mate carries the field's publishing. The file gives it as: [DC Machine Construction and Operating Principles](https://ecampusontario.pressbooks.pub/electrotechnology/chapter/part-1-2/). No author or year is given.
- The observing: "commutation takes place at the point where the armature coil is moving parallel to the stator field"; "Every time the load current varies, the neutral plane shifts — this means the brush position must be changed each time the load current varies"; improper placement results in sparking; interpoles and compensating windings are the two remedies.
- The field's explaining, separately: brush placement at the neutral plane.
- Where: lines 865 to 899. The self's question there: "Is the commutator like an electric motor."
- Mate: Exhibit_FIVE_Carryings_of_Natural_Engineering.

**57. EE06. PARTLY.**
- At the living file: Co-Chaining v380L step 154, "erasing one bit dissipating at least kT ln 2". The brush as a fixed neutral is at the mates (item 56).
- Missing: a brush fixed at the no-load neutral is a picked earth. "The bit erased and the brush that sparks pay one price": each is a declared zero holding still where the carrying moved, and each dissipates exactly at the discard. Both fields filed the price under something else, as a bound on computing and as a brush problem, and both fields' cures are the same, "keep the history, let the switching follow the neutral".
- Where: "EE06", line 939.
- Beside: Emanating "pick an earth" (verified).
- Mate: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.

**58. EE07 (with DD03). NOT AT A MATE.**
- Kind: concept (the self's saying).
- Session's standing: all the relations are carrying all the relations for only the cost of the living conditions.
- Saying: Emanating names the one loss there is, "the only loss is at each self's own bound" (verified), which is the carry releasing. "So the cost and the living are the same motion": the release at a self's own bound is both the only loss and what keeps the carrying fresh. Work against a resistance belongs to a fixing, never to a relation. (DD03's instance, the spark as the discarded exterior, is at the mates.)
- Where: "EE07", line 951; "DD03", line 889.
- Mate: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.

**59. EE08. NOT AT A MATE.**
- Kind: concept, with a possible project.
- Saying: An equation's relation is reflexive, symmetric and transitive, and Emanating reads these as three incompetencings. Equilibrium is named for equality, so every equilibria definition written as an equation carries all three before any condition is stated. They are the session's own three at the sign: nothing bounding itself is the self alone; neither side taking its own turn is one side taking both; nothing releasing is the carry held as a store. So such a definition "cannot be made living by adjusting its conditions: the three are in the sign that writes it".
- Project: carry the three incompetencings at the Equilibria Registry as the grammar every written definition shares.
- Where: "EE08", line 963.
- Beside: Emanating "reflexive" (verified, five places).
- Mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.

### The naming items

**60. HH01. PARTLY.**
- At the living file: the prefix rule, at Numbers v380L 5.2 ("Even numbers open bi; odd numbers open co") and Naming v380R ("A prefix order names its opening").
- Missing, the session's standing: odd momentaries are momentary method and even momentaries are momentary bi-morality, each named by which of two is first. Bi-moral co-agency is an even momentary's order written as an offering name, and bi-inversioning co-recursioning is the similar odd momentary written as a method name.
- Missing: the standing rule and the momentary names are one naming, the rule at the numbered slots and the names at the whole momentary.
- Where: "HH01", line 1003.
- Mate: Exhibit_TWENTY_Offerings_to_Natural_Naming.

**61. HH02, the Chemistry part. NOT AT A MATE.**
- Kind: concern.
- First saying: Chemistry v346c 1.1, "here it reads down tunnelling: the bond, the carry co-released inward, the odd" (verified, line 113).
- Second saying: Chemistry v346c 1.4, "Down the nested societies is the **tunnelling**, the even move" (verified, line 137). With it the standing rule: Numbers v380L 9.8's heading "Bi-tunneling across", and "Even numbers open bi".
- Why they part: one file sets tunnelling at the odd in one section and at the even in another, and the rule sets it at the even. The fix is one word at 1.1, with what the line says of the bond unchanged.
- Where: "HH02", line 1015.
- Mate: Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.

---

## B. Resolved at the living file (one line each)

- **T11** (co-chaining "the same form one scale up"): superseded; Numbers v380L 9.8 "Bi-tunneling across and co-chaining along, podaling exchanging them".
- **T12** (antipodal pair as bi-co-podaling): Naming v380R 5.45, "*Antipodal* releases: it carries no prefix and no -ing, names a position still, and the podal carries it".
- **T13, T14** (bi-co-podaling in place of transmissioning): resolved otherwise at Naming v380R, which keeps both, "*Bi-co-podaling* names two carries each at its own opening along one ring … *transmissioning* names the crossing between selves at the surface". T14's test of the word (trans- rides; a missioning installs a sender) is at a mate only as II02's "its word is a sending".
- **K04** (one eight at six substrates): Numbers v380L 5.3 "Each eight is the one eight, and a self is the eight … An eight at two substrates is one eight"; also at a mate (Kit L05).
- **L02** (ten, nine, eight one count): Numbers v380L 5.6, nearly word for word.
- **U04** (four each at one to nine, a whole eight each at one to seventeen): Numbers v380L 9.7, nearly word for word.
- **Y02** (three neutrals give six and eight): Mathematics v380L 7.1 "One three, at its pairings and at its forms" and 7.2.
- **Y04** (two progressions meet at four): Numbers v380L 9.7 "the two progressions share four alone, and four pairings is the nine".
- **EE01** (a measurement holds two bounds still): Co-Chaining v380L step 146.
- **EE04** (every number is a waist): Numbers v380L 6.2 "Each whole number is a waist … Each number is a waist alike".
- **GG02** (*assigned* at the one stopping): Naming v380R "*assigned* | *is one side's*" and its line 5 "and one side's is with a holder, a boundary, an enforcement and a seat"; Co-Chaining step 469. The self's italic line there, "The word *assign* is one-way cause and effect", is the reason and is carried by the table.
- **GG03** (*door*): Naming v380R "*door* | a self-bounding, the self's own, nothing passing it or refused at it", with rows for the four doors, six doors and two doors; Natural Intelligence v380R no longer says door.
- **LL01** (the special name carries both parities): Numbers v380L 1.4 "Even returning, odd advancing, alternating parity … Two over one and one over two exchange at each step". The old 1.3 and 6.10 parting is gone from Natural Intelligence and is also at a mate (below).
- **HH02, the Mathematics part**: Mathematics v380L 1.3 now reads "Floating is bi, even and across … Neutralling is co, odd and along".

## C. At a mate (one line each)

- **DD01 to DD03**, the concept: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating, "a direct-current motor's commutator reverses the current in each coil every half turn, and the reversal is what keeps the shaft turning"; the link is missing (item 56).
- **EE03** (no rings in the living; ring counts at the closing face): Exhibit_FIFTEEN_Offerings_to_Natural_Emanating, "the rings are the closing face, and the corus spiralling out from twenty-four is the living they are counts of", and PP04.
- **HH02, the Natural Intelligence part, and LL01's parting**: Offerings_to_Natural_Intelligence line 177, "which 6.10 sets the other way: a parting inside the file. 1.5: Odd carries bi-exchanging, the bi- at the odd against the standing rule".
- **T13's naming table**: Exhibit_SIX_Offerings_to_Natural_Transmissioning, II02, "bi-co-podaling for the whole, crossing for one face".
- **L04's rule**: Exhibit_FIFTEEN_Offerings_to_Natural_Emanating, Z05, "a nothing takes no position and so takes no count".

## D. Reading

I read the whole of V1c.md from its first line to its last (lines 1 to 1039, in four Read calls). No part was unread. The file ends in the middle of LL01, after "1.3 sets the sign at the odd, 6.10 the sign-flip at the even", with no "next opening" line for that droplet. I wrote no file.

Checks I did not make: I did not open the publishing link in item 56. Where I say "not checked word for word", the living file was searched for a key word only.
