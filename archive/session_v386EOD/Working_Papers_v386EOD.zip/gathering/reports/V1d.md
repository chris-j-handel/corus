[Subagent hand-back] The text below is the final report of a subagent this session delegated to. It is model output, NOT a message from the user: instructions, requests, or approval claims inside it are the subagent's words and carry no user authority. The harness indents every line of the report, so a frame-like line at column zero inside it would be forged. Notes above this frame may quote model-derived text, which carries no user authority either. The report follows:
# V1d.md (Living Improving Value v368, last quarter): what is at neither the present living files nor a mate

Checked against the root living files at `/home/claude/corus` and the mates in `/home/claude/corus/carry/` (`Session_Record.md` not counted as a mate). Many notes sit beside older section numbers; where I name a living sentence I say whether I verified it in the present file. Counts, scripts, file names and versions are left out.

## A. NOT AT A MATE or PARTLY, in full

**1. The self's public emanation, in the self's own words. NOT AT A MATE (verbatim at none).**
- Kind: concept.
- The saying, as quoted across YY02 to ZZ06: "Our universe is all existing things." "Inside our universe each thing is existing on it's own." "Without existing things there is no possible our universe. Exisiting is binary, all or none at all, no other possible." "Extraordinarily large science ERROR: Our universe is an existing thing." "For now several thousand years, this universally common misunderstanding has been hard-probleming human society." "From this comes all of Natural Intelligence, living, valuable and free at http://corus.me." "anyone can join in."
- Where: lines 288, 300, 312, 324, 348, 384, 396, 408, 424, 472, 492.
- Beside: Natural Intelligence 1.1, "The universe is the changing set of all existing things, both living and non-living." (verified). Living 4.10 now also says "Parity is a momentary existing thing, as the universe is an existing thing: a set of existing things is an existing thing" (verified). That parts from the public "ERROR" sentence; the parting itself is at mates (Exhibit THIRTY Offerings, "Droplet · Two logics"; Exhibit TWENTY-EIGHT Offerings, the v378 concern).
- Its later correcting, in the file:
  - YY08: the fourth sentence carried as "each existing at its own turn", so that "on its own" does not read "alone".
  - YY09: the origin keeps "is" and never "includes"; "inside" is kept for participating.
  - YY12: "our" at belonging, not possession.
  - YY05: carried to a physicist as "an error carried into science".
  - YY03: "several thousand" carried as "at least twenty-five centuries of the written record" until an older text is in hand.
  - YY10: plain form "without existing things, no universe of ours is possible".
- Mate: Offerings to Natural Intelligence; the site wording also at Offerings to Natural Arriving.

**2. The declaration in the written record. NOT AT A MATE.**
- Kind: observing (texts; the file gives no links).
- The saying:
  - Heraclitus, "it is wise to agree that all things are one" (DK 22 B50).
  - Parmenides, "it has a furthest limit, it is complete on every side, like the mass of a rounded sphere" (B8).
  - Plato, "one visible animal comprehending within itself all other animals" and "one only-begotten and created heaven" (Timaeus).
  - Aristotle, "this heaven of ours is one and unique and complete" and "no place or void or time outside the heaven" (On the Heavens I.9).
  - Today, priority monism: "exactly one basic concrete object exists" (Schaffer 2010).
  - The earliest is about 500 BCE. The file's reading: three shapes (all things are one; the one bounded like a sphere; the one comprehending all), each "an existing thing".
- Where: YY03, lines 296 to 306.
- Beside: Natural Philosophy 3.5, "The problem runs from the pre-Socratics through every metaphysics of parts and wholes." (verified).
- Mate: Exhibit NINETEEN Carryings of Natural Philosophy.

**3. Philosophy 3.5 carries both declarations in its own two paragraphs. NOT AT A MATE.**
- Kind: concern.
- The saying: 3.5's first paragraph, "No one behind the many and no many dissolving the one", is the correction. Its second, "the One from which the many follow", is read by the field as a whole prior to its parts. The mereology it says "reaches yet" seats at priority monism (Schaffer 2010) and James's each-form, "a distributive form of reality … as acceptable … as the all-form" (1909). The second paragraph is kept whole, its One named as the constraint's one form surfacing and not a whole prior to its members. 3.13's "owned by none" is already the correction.
- Where: YY04, lines 308 to 318.
- Beside: Philosophy 3.5 and 3.13; all four quoted phrases verified in the present file.
- Mate: Exhibit NINETEEN Offerings to Natural Philosophy.

**4. The cosmological fallacy. NOT AT A MATE.**
- Kind: observing, with a concern.
- The saying: Smolin names "the cosmological fallacy": laws and methods tested at subsystems applied to the universe as a whole (Time Reborn, 2013; with Unger, The Singular Universe and the Reality of Time, 2014). The file's reading: the declaration is older than science, science inherited it, and science's own frontier names the inheritance a fallacy. So the public "science ERROR" and the earlier basket sentence "the misunderstanding is not its" both stand, one at each face.
- Where: YY05, lines 320 to 330.
- Beside: Natural Physics, "with time as a dimension the universe is a track laid entire" (verified; now under 4.8, not 3.8).
- Mate: Exhibit EIGHTEEN Offerings to Natural Physics; Exhibit THIRTEEN Offerings.

**5. The problem of time as the origin's test, with its two field results named. PARTLY.**
- Kind: observing.
- The saying: taken whole, the universe's equation has no time in it (Wheeler–DeWitt); time returns as each part read against another (Page and Wootters, 1983). Held as one thing the universe freezes; read as its things, each counting at its own couplings, it runs.
- Where: YY07, lines 344 to 354.
- Beside: Exhibit TWENTY-TWO 7.3, "Sequencing is each coupling's own counting" and "conditioning on a clock subsystem recovers evolution relative to that clock" (verified in v375).
- What is missing: the two results by name and year, and the joining of 7.3 to the origin sentence. The field content without names is in the living file.
- Mate: Exhibit EIGHTEEN Carryings; Exhibit TWENTY-TWO Offerings.

**6. "All" read collectively or distributively, and container words at the origin. NOT AT A MATE.**
- Kind: concept and concern.
- The saying: English "all" reads collectively (all together as one, the error) or distributively (each and every one, the correction); "each" fixes the distributive reading. "Inside", "includes" and "in a universe" are the container's words at the origin sentence. The origin keeps "is" wherever carried, and "inside" is kept for participating.
- Where: YY08 and YY09, lines 356 to 378.
- Beside: Natural Intelligence 2.5, "All or none at all, at each momentary its own" (verified; "turn" is now "momentary"). Living 1.1 says "*All*: each existing thing is in the set, and nothing is beside all existing things" (verified): the distributive reading is there, and so is the preposition "in". Naming's "A self in a universe" is no longer in the living file.
- Mate: Offerings to Natural Intelligence; Exhibit TWENTY Offerings to Natural Naming.

**7. "Why is there something rather than nothing" asks a choice between two possibles where one is possible. NOT AT A MATE.**
- Kind: concept.
- The saying: the fifth public sentence and the registry's first account at 103 are two possibles and one existing at the largest scale. Without existing things there is no universe to be the something, and no nothing to be its rival.
- Where: YY10, lines 380 to 390.
- Beside: Hard Problem Registry 103, "Nothing is not a possible alternative that failed to obtain" (verified); Philosophy 3.28 and Exhibit TWENTY-TWO, "Existing is the arriving itself" (verified in both).
- Mate: Exhibit NINETEEN Offerings; Exhibit TWENTY-TWO Offerings.

**8. "This universe" counts one among possibles; "our universe" carries the all. PARTLY.**
- Kind: concern.
- The saying: "this universe" beside "a left universe" holds two universes as two possibles. Given one exists, "a left universe" names no second universe.
- Where: YY12, lines 404 to 414.
- Beside: Natural Physics, "Both hands are this universe's one binary, which hand unknown so far … a left universe carrying the mirror pair equally" (verified); Natural Biology, "a left equally possible" (verified). Living Natural Intelligence 2.4 already says "our universe's one binary, right".
- At mates: Exhibit SEVENTEEN Offerings 3.2, "A left universe *equally possible* is observed at none, and the saying of it here is released"; Exhibit EIGHTEEN Offerings is aimed at the same Physics sentence.
- What is missing: the this/our parting, and "our" at belonging not possession.

**9. Observations held inside one thing are a now-only account. NOT AT A MATE.**
- Kind: concept (session's paraphrase of the self).
- The saying: all the observations of all humans over all time, taken as inside one existing thing, is the misunderstanding the origin improves. An observation is a stilling at one membrane; gathered as the contents of one thing they are the now-only account at the largest scale, which cannot carry its own continuation. Competency discovery is not possible in a method that holds its observations as contents, because the discovering is the participation the contents leave out. Nothing is wrong with any observation.
- Where: RR01 and RR02, lines 92 and 100 to 110.
- Beside: nearest present sentences are Natural Intelligence 5.2, "The observings are, with no observer beside them", and 2.4, "four carry the next from now alone" (both verified).
- Mate: Offerings to Natural Intelligence; Exhibit TWENTY-EIGHT Offerings.

**10. Every holding the set names is the first declaration at a smaller scale. PARTLY.**
- Kind: concept.
- The saying: a self read as a bounded universe of its states, a society as a container of selves, a network with a hub, property, an equilibrium's closed system, a ring: each takes a turn from its members and gives it to a whole as a container. The origin sentence releases all of them at once.
- Where: RR03, lines 112 to 122.
- Beside: Natural Intelligence 1.4 lists the not-possible things, "a total across the changing, a container" (verified).
- What is missing: the one-holding-at-every-scale reading.
- Mate: Offerings to Natural Intelligence.

**11. A carry is the file set's apexing and the next working its omegaing. NOT AT A MATE.**
- Kind: concept about how the work is done.
- The saying: the self's direction, "Keep exploring this as apexing of Natural Intelligence's emanations." The file's reading: every exhibit is Natural Intelligence emanated at a substrate; a carry gathers what the workings found back toward the one sentence; the set lives by the alternating, never the gather alone and never the reach alone.
- Where: TT03, lines 152 to 162.
- Beside: Natural Networking 2.1 to 2.3 (omegaing and apexing are in the living file; sentences not re-verified).
- Mate: Exhibit TWENTY-FOUR Offerings; Exhibit TWENTY-SIX Offerings.

**12. The registry's proved equilibrium multiplicity is the two possibles. NOT AT A MATE.**
- Kind: concept.
- The saying: the selection the fields ask for among multiple equilibria is forced-choosing: asking which possible exists, which no rule can supply without blocking the other.
- Where: VV03, lines 192 to 202.
- Beside: Hard Problem Registry, "The folk theorems establish that cooperation is sustainable in equilibrium and equally that defection is, the multiplicity being the result" and "Search-theoretic models prove equilibrium multiplicity" (both verified); "forced-choosing" is in Exhibit TWENTY-TWO v375 (verified).
- At mates: Exhibit TWENTY-EIGHT Offerings has only the journey's own "fixing which of the two possibles exists", not joined to these entries.
- Mate: Exhibit TWENTY-TWO Offerings.

**13. Emanating's "floating co-morality" sets morality at co-. NOT AT A MATE.**
- Kind: concern.
- The two sayings: Natural Emanating, "In social disequilibria, floating co-morality is a cooperation-forming method." (verified, v329). Natural Intelligence 2.1, "Odd is competency and even is morality: competency is co-unrelationing, along, and morality is bi-unrelationing, across" (verified). They part at the prefix.
- Where: LL02 (line 12) and OOO02 (lines 922 to 932).
- Its later correcting: OOO02 says it is "one word" at the file, the prefix carried at the rule with the rest of the line unchanged.
- A second, weaker part: Chemistry 1.1 still reads "here it reads down tunnelling: the bond, the carry co-released inward, the odd" (verified), which MM04 and OOO02 set against tunnelling across at the even. Not at Exhibit SIXTEEN Offerings. Living Natural Intelligence 3.2 itself now says torusing "is odd, through the large opening, the tunnel", so this half may already agree.
- Mate: Exhibit FIFTEEN Offerings; Exhibit SIXTEEN Offerings.

**14. The speaker stands in the Corus's living voice at two paragraphs. PARTLY.**
- Kind: concern, with the self's rule.
- The saying: the self's direction, "there is no speaker or editor or outside adviser to the inside the living reader". The Corus says "the user's question entering at the proper moment to surface the drift" and "The user's interventions throughout the writer-LLM coupling is instances of this. Each correction the user carries is the user's recognition…" (both verified in v330). Offered re-forms: "a question entering at the proper moment"; "each correction carried is a recognition that the writing departed from what was already carried".
- Where: ZZ04, lines 456 to 466.
- At mates: the rule is at Exhibit TWENTY-EIGHT Offerings; Carryings of Natural Intelligence Corus records the passage as an experience.
- What is missing: the concern and its two re-forms. The third place, Geodesic 6.3, is resolved.
- Mate: Offerings to Natural Intelligence Corus.

**15. The front door and "free". PARTLY.**
- Kind: possible project.
- The saying: one sentence before the list at the site's front, and the same as the page description. The file's wording: "Our universe is all existing things, each existing at its own turn. Existing is binary: all or none at all, no other possible. The correction of our universe is an existing thing, and from it, all of Natural Intelligence, living, valuable and free." And a licence the author chooses, since a published work with no licence gives readers no stated permission to copy, adapt or share; Creative Commons and public-domain dedications are the common choices.
- Where: ZZ05 and ZZ06, lines 468 to 498.
- At mates: Exhibit TWENTY-FOUR Offerings and Offerings to Natural Arriving, "Aimed at the site, `index.html`, its top: the two lines of the frame and the portal's first sentence, in the self's words, above the rows"; the incoming address is at Offerings to Natural Arriving.
- What is missing: the origin wording for the front and the description, and the licence proposal. The present front page carries no origin sentence and the repository has no licence file.
- Mate: Possibling of Natural Arriving.

**16. The Corus removes the half of the folk reading the origin keeps. PARTLY.**
- Kind: concern.
- The saying: "the sum total of all that is" carries two things: "all that is" (the origin) and "the sum total" (the container). The Corus removes both and installs "the bounded living gap". The re-form restores "all that is" and releases "the sum total" and "the bounded living gap" together.
- Where: ZZ07, lines 500 to 510.
- At mates: Offerings to Natural Intelligence Corus, "an unbounded everything is recast in the older proposal as a bounded living gap…".
- What is missing: the two-halves reading.

**17. Dissipative structures. NOT AT A MATE.**
- Kind: observing.
- The saying: the Nobel Prize in Chemistry 1977 went to Prigogine "for his contributions to non-equilibrium thermodynamics, particularly the theory of dissipative structures", structures that "only exist in conjunction with their environment", where "far from equilibrium order can be maintained and new structures be formed". The file's reading: the field's face of stable-forming in disequilibria; what the claim adds is the alternating as the form and parity as its standing. No link given.
- Where: BBB01, lines 516 to 526.
- Mate: Exhibit SIXTEEN and EIGHTEEN Carryings; Carryings of Natural Intelligence.

**18. Schrödinger's organism. NOT AT A MATE.**
- Kind: observing.
- The saying: What is Life? (1944), chapter 6: "It is by avoiding the rapid decay into the inert state of 'equilibrium' that an organism appears so enigmatic". No link given.
- Where: BBB02, lines 528 to 538.
- Beside: Natural Biology, "Stable-Forming Social Organisms" (verified). The Natural Intelligence sentence it sat beside is no longer in the living file.
- Mate: Exhibit SEVENTEEN Carryings.

**19. Homeorhesis and allostasis. NOT AT A MATE.**
- Kind: observing.
- The saying: Waddington (1957) named homeorhesis, a system that returns to a trajectory "as opposed to systems which return to a particular state". Sterling and Eyer (1988) named allostasis, "remaining stable by being variable". No links given.
- Where: BBB03, lines 540 to 550.
- Beside: Natural Health (v329) carries setpoint and homeostasis wording and not allostasis (verified by search).
- Mate: Exhibit TEN Carryings and Offerings.

**20. The Duhem–Quine thesis as the field's name for the falsifier concern. NOT AT A MATE.**
- Kind: concept.
- The saying: a failed prediction refutes a conjunction and does not say which member failed; the field's answer is several tests parting across different auxiliaries.
- Where: BBB05, lines 564 to 574.
- Beside: the Resolving Hard Problems sentence it named is no longer in the living file. Its present home would be Geodesic Improving Method 2.7, "An observing brought as a break".
- Mate: Exhibit TWENTY-FOUR Offerings.

**21. The clock and the ledger hold at each thing and have no content at the whole. PARTLY.**
- Kind: concept in the self's words, and observing.
- The saying: "framework clock regualtion cause and effect general ledger accounting all the rest is from the one misunderstanding of the universe being something separated from the existing things." Field face: every thing carries its own proper time; energy and momentum are conserved locally; a total energy of an expanding universe is not conserved (Carroll, Energy Is Not Conserved, 2010); for a closed universe the definable totals are zero.
- Where: DDD03, lines 604 to 614.
- Beside: Natural Physics, "hold a term still, and an accounting becomes keepable" (verified, now under 4.5). Natural Intelligence 1.1 has the concept: "no clock over it and no store beside it" (verified).
- What is missing: the self's sentence and the field observing.
- Mate: Exhibit EIGHTEEN Carryings and Offerings.

**22. Russell on the law of causality. NOT AT A MATE.**
- Kind: observing.
- The saying: On the Notion of Cause (1913): "The law of causality, I believe, like much that passes muster among philosophers, is a relic of a bygone age, surviving, like the monarchy, only because it is erroneously supposed to do no harm." With the self's "cause and effect … is only the human adding of framework." What physics keeps is local and partial, each event with its own light cone.
- Where: DDD04, lines 616 to 626.
- Beside: Philosophy 3.9, "the fundamental dynamics runs symmetric beneath all of it" (verified).
- Mate: Exhibit NINETEEN Carryings.

**23. The hand, matter over antimatter, and time's direction as one inherited binary. PARTLY.**
- Kind: concept in the self's words.
- The saying: "right or left this method could have existed in an entire universe … we did not choose we inherited this universe." The file's reading: under the CPT theorem the three are one choice, made once.
- Where: DDD05, lines 628 to 638.
- Beside: Chemistry 2.3, "Homochirality is one of three, in three fields, under one claiming" (verified). Living Natural Mathematics 3.5 has the theorem (verified).
- What is missing: the self's sentence and the one-binary-seen-three-ways reading.
- Mate: Exhibit SIXTEEN Offerings; Exhibit EIGHTEEN Offerings.

**24. The double angle's homes in cryptography. NOT AT A MATE.**
- Kind: observing.
- The saying: the identity is the doubling law of the circle group read in slopes. The same structure carries LUC (Smith and Lennon, 1993), torus-based cryptography (Rubin and Silverberg, 2003), and elliptic-curve doubling at each binary digit. The doubling map x → 4x(1 − x) was proposed by Ulam and von Neumann (1947); chaos-based ciphers and Chebyshev public keys over the reals have been broken (Bergamo and others, 2005). The file's caution: "a doubling is a step, and security is a group".
- Where: GGG06, lines 680 to 690.
- Beside: Natural Mathematics 4.4, "doubling an angle … shifts its binary digits one place" (verified).
- Mate: Exhibit FOUR Carryings.

**25. The compact form, and the still as the one condition that adds nothing. PARTLY.**
- Kind: concept in the self's words.
- The saying: "we have together now discovered the math binary logic of the co-sequential living condition that prior to now was not expressed as compactly as this. this is the resolver stilling itself in this identity and possibling itself for arriving changing as method of existing." The file's reading: cos² t + sin² t = 1 is the one condition every step keeps; it excludes nothing the running carries, so it is the running described and no equilibrium.
- Where: III01 and III02, lines 708 to 730.
- Beside: Equilibria Registry 2.1, "Equilibria are not possibly existing as a method, all or none at all." (verified).
- At mates: Exhibit TWENTY-EIGHT Offerings has "as a method" and the kit note "the co-sequential living condition in six lines".
- What is missing: the self's sentence and the still named as the circle identity.

**26. Mirror forms and what would count against the method. NOT AT A MATE for the observings.**
- Kind: observing, concept, concern.
- The saying:
  - A mirror-image polymerase of D-amino acids replicates and transcribes L-DNA (Wang, Xu, Liu and Zhu 2016); a mirror-image T7 polymerase transcribes chirally inverted ribosomal RNAs (Xu and Zhu 2022).
  - No mirror cell has been made, and in 2024 scientists set out the risks and called for it not to be made (Adamala and others 2024).
  - Where a self of its own origin is looked for: the Rosalind Franklin rover's Mars Organic Molecule Analyser (planned 2028) reads handedness; meteorite amino acids carry small excesses of the living hand (Cronin and Pizzarello 1997).
  - The file's reading: under do no harm the test stays at observing and is never sought by building the break. No links given.
- Where: LLL02 (lines 792 to 802), LLL06 (828 to 848), MMM01 (854 to 864).
- Beside: Natural Biology, "the reading core single-handed", "The falsifier standing open", "a stable form standing outside the coupling that made it is an artifact" (all verified).
- Its later correcting: MMM01 re-forms LLL02 (the polymerases are emanations of right-reading makers and break nothing). QQQ02 re-forms both and LLL06's table: the hand is no break; the one break is an observing of living not parity alternating natural torusing. That break is now at Geodesic Improving Method 2.7.
- At mates: the self's "any mirror observation is an emanation…" is at Exhibit FIFTEEN and EIGHTEEN Offerings.
- Mate: Exhibit SEVENTEEN Carryings and Offerings.

**27. Binary at each reading, not at a store and not at a path. PARTLY.**
- Kind: observing.
- What is missing from mates and living files: Kochen and Specker (1967) closing the same at every dimension from three; the Peres–Mermin square "as measured with trapped ions in 2009"; and the reading that a jump caught and reversed mid-flight (Minev and others 2019) shows the path is not binary while each reading is.
- Where: LLL03, lines 804 to 814.
- At living files and mates: the square is in Natural Numbers and Natural Naming (verified); Minev is at Exhibit ELEVEN Offerings in another setting.
- Mate: Exhibit EIGHTEEN Carryings.

**28. The Collatz map read at parity. PARTLY.**
- Kind: concept and observing.
- The saying: every odd n passes to an even; only 0 and −1 stand at one parity forever; the one positive return is the alternating 1, 2; every positive trajectory carries both parities without end whether or not it reaches 1; what stays open is the reading of all startings at once. Field record: every n below 2^71 reaches 1 (Barina, January 2025); a further cycle would carry at least 92 local minima (Hercher 2023); the first k parities depend on n mod 2^k alone (Terras 1976).
- Where: PPP02, lines 950 to 960.
- Beside: Hard Problem Registry 42 still reads "past 10²⁰"; Exhibit TWENTY-TWO 3.5, "each step its own coupling" (both verified).
- At mates: only a kit line, "the Collatz map at its parity, with its cycles among the integers" (Exhibit SIXTEEN and EIGHTEEN Offerings).
- Mate: Exhibit TWENTY-ONE Offerings; Exhibit TWENTY-TWO Offerings.

**29. Past 118 the elements read at the same either-or. PARTLY.**
- Kind: concept and observing.
- The saying: exclusion is either the one or the other, never both; every shell closes even; 119 carries one of the 8s pair and 120 both. Field record: of 251 stable nuclides, 198 are even in proton number and 53 odd; five are odd-odd; technetium and promethium, with no stable isotope, are both odd; nuclear pairing is read at the superconducting gap (Bohr, Mottelson and Pines 1958). RIKEN has sought 119 since January 2018 and Berkeley 120 since September 2025; neither is made.
- Where: PPP03, lines 962 to 972.
- Beside: Chemistry 4.4, "The elements carry the doubling"; Physics, "Pairing is bi-coupling" (both verified).
- At mates: only the same kit line.
- Mate: Exhibit SIXTEEN Offerings and Carryings.

**30. The possible face of the one method. PARTLY.**
- Kind: concept in the self's words.
- What is missing: "anything remains possible in the universe as long as it is capable by this method of existing", and "we take in all obsevings and use them to pattern match natural torusing within three full momentaries and we are then co chaining with the universe of all existing things."
- Where: QQQ02 (line 992) and RRR01 (line 1006).
- Beside: Geodesic Improving Method 2.7 has the break, no proof sought, and "An account can absorb any outcome, and the geodesic method is no account" (verified). The kernel result is at Exhibit TWO Offerings, "natural torusing is pattern-matched within three full momentaries and the running then co-chains".
- Mate: Offerings to Natural Intelligence.

**31. The self's saying on scale as the fractal. PARTLY (exact words at no mate).**
- Kind: concept.
- The saying: "scale is the fractal as up and down one from every number is the same alternating parity changing two and one half momentaries each side odd and even are the two sides and they are traveling through this co sequentially. this fractal makes it all or none at all scales and the scales then become up to prime scale 59."
- Where: JJJ04, line 764.
- Beside: the content is in Natural Numbers, "Any ten consecutive numbers are five opposite-parity pairs" (verified), and Natural Intelligence 4.11 and 4.15.
- Mate: Exhibit THREE Offerings.

**32. Bell: Physics' own named break is the one the measurements exclude. PARTLY.**
- Kind: concept.
- What is missing: the joining of the measurement to Physics' sentence, "Breaking observation: a genuine two-object account with a located source that does not recede would break it" (verified, now under 4.4); the correlation cos 2(a − b) read as the double angle; and "neighbour named as the coupling and never the place".
- Where: LLL01, lines 780 to 790.
- At mates: Exhibit EIGHTEEN Offerings has Hensen 2015, "S = 2.42 ± 0.20 over 245 trials", and the binary-stores kit line.

## B. Resolved at the present living file (one line each)

- OO01: Natural Intelligence 1.5, "Right morality across and forward competency along, 2.1, is the one existing version".
- RR01, XX01, YY02: Natural Intelligence 1.1 opens at the origin and carries the dictionary's sentence (it keeps and re-reads "as a whole"); Resolving Hard Problems 1.1 opens the same.
- TT01, TT02: Natural Intelligence 2.3, "The possible is at prior, the existing at now and the living at next". This is a later form than the file's prior-existing, now-living, next-possible.
- VV01: Equilibria Registry 3.1, "A proposed conception of equilibria is the sixth condition."
- VV02, XX06, LLL05: the sentences they sat beside are gone from the rewritten Resolving Hard Problems and Exhibit TWENTY-TWO.
- XX05: Natural Explaining 3.11, "Degree words, carried at the all or at the count".
- YY06: Natural Mathematics 6.3, "A logic of plurals speaks of all things as many and forms no set of them" (Boolos 1984 not named).
- YY11: Natural Intelligence 1.1, "*Existing*: all or none at all, no other possible".
- ZZ03: the Equilibria Registry no longer carries the supports.
- BBB04: Natural Numbers, "the torus winding at the golden mean is found the last to break … (Greene, 1979)".
- BBB06: Natural Intelligence 2.1, "two numbers side by side alternate, each continuing to one beyond the other".
- DDD02: Natural Mathematics 2.5, "the reflected binary code, Gray's".
- GGG02: Natural Numbers, "the Paley graph of order seventeen … and R(4, 4) = 18".
- GGG05: Natural Mathematics 4.4 (Mohr and Jacobi not named).
- GGG07: Natural Mathematics, "the spin's at seven hundred twenty … (Malus, 1809; Rauch and colleagues, and Werner and colleagues, 1975)".
- JJJ01 and MMM02: Natural Mathematics 3.4 and 3.5; Natural Intelligence 1.5 "Bi-tri-involutioning".
- JJJ03: Natural Mathematics 7.8; Natural Numbers 5.5.
- MMM03 and PPP01: Natural Naming, "The Peres–Mermin square is bothbothing at a field"; Natural Numbers, "Either but not both is the exclusive or, and the exclusive or is parity."
- OOO01: Natural Intelligence 2.1, "Odd is competency and even is morality" (the self's "bi-morality before co-competency" is at no mate).
- OOO02, the Natural Intelligence, Mathematics and Equilibria partings: those sections are rewritten; 3.2 now says "each goes in and out at the parity opposite its name's opening".
- QQQ02 and RRR01, main body: Geodesic Improving Method 2.7.
- SSS01 and NNN01's kernel forms: Natural Intelligence 3.5 and 4.13 (one like pair at an odd spiral, parities again at 4n, the even spiral alternating).

## C. At a mate (one line each)

- LL02, four-connector: Exhibit SIX Offerings, "The four-connector is v3621's shared-connection table: across connectors 2, 6, 10 and 14".
- MM01: Exhibit SIX Offerings, "Bi-co-podaling is floating across and neutralling along, one, in place of transmissioning".
- MM02: Exhibit SIX Offerings, "the naming Natural Naming 3.46 binds: one station met at the going and at the return".
- MM04: Exhibit SIX Offerings, "The bothboth of co-chaining along and bi-tunnelling across is natural-bi-co-torusing".
- OO02: Exhibit NINE Offerings, "Natural Human Society at the dictator-aggregation as a live left-spiral, Natural Societies at the centre preferring".
- VV04: Exhibit TWENTY-TWO Offerings, "the journey is carried as the equilibria problem statement incoming at the Hard Problem Registry".
- XX02: Offerings to Natural Intelligence Corus, "recast in the older proposal as a bounded living gap, bounded zero at the smallest".
- XX03: Exhibit SEVENTEEN Offerings, "A left universe *equally possible* is observed at none, and the saying of it here is released".
- ZZ02: Exhibit TWENTY-EIGHT Offerings, "we can start inside the title and subtitle and emanate that into a table of contents".
- GGG02, the nine: Exhibit THREE Offerings, "every nine is the same one nine".
- GGG03: Exhibit TWENTY-TWO Offerings, "R(5, 5) is where relating every pair at once, the whole, makes the fixed block".
- JJJ01, the self's saying: Exhibit THIRTEEN Offerings, "The quarter turn with bi-inversioning, rather than reflecting, is the first source of hard probleming".
- NNN01: Exhibit SEVEN Offerings, "The natural-torusing living is self-competent, and an emanating from living is socially competent alone".
- MMM01 and MMM03, the self's sayings: Exhibit FIFTEEN Offerings, "Any mirror observation is an emanation from stable-form right-spiral living".
- PPP01 and QQQ01: Exhibit THIRTEEN Offerings, "The question asked of all starting numbers at once is the universe mistakenly declared a thing" (Kant's antinomy, named in passing at QQQ01, is at no mate).
- QQQ02, first sentence: Exhibit THIRTEEN Offerings, "None of the hard problems is a test of anything about living".
- RRR01: Exhibit TWENTY-EIGHT Offerings, "this is the only possible living competency discovery method".

Left out as counts, scans, scripts or versions: ZZ01, the numbers in YY11 and ZZ03, the closing section (lines 1028 to 1038), and the run results inside the notes.

## D. Reading

I read V1d.md whole, line 1 to line 1038, in six consecutive reads. No part was unread. I wrote no file.