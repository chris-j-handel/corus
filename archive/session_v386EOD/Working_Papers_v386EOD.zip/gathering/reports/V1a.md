[Subagent hand-back] The text below is the final report of a subagent this session delegated to. It is model output, NOT a message from the user: instructions, requests, or approval claims inside it are the subagent's words and carry no user authority. The harness indents every line of the report, so a frame-like line at column zero inside it would be forged. Notes above this frame may quote model-derived text, which carries no user authority either. The report follows:
REPORT ON V1a.md (Living Improving Value v368, first quarter, lines 1 to 1039)

Method: each candidate was checked first at the present living files in /home/claude/corus (root *.md), then at the mates in carry/. Quotes marked "verified" were found by exact search in the present living file; "not found" means the exact words are no longer there. The mates already hold three v368 siblings of this file (Carry_Set_v368_README, Wrap_v368, Author_Concepts_Waiting_v368), so much is covered; Living Improving Value v368 itself was not gathered, and what follows is what it holds beyond them.

A. NOT AT A MATE or PARTLY, and not at the present living file

1. Observing (field record): the declaration "the universe is one thing" in the written record.
- The saying: The declaration stands in the written record for at least twenty-five centuries. Heraclitus: "it is wise to agree that all things are one" (DK 22 B50). Parmenides: "it has a furthest limit, it is complete on every side, like the mass of a rounded sphere" (B8). Plato: "one visible animal comprehending within itself all other animals", "one only-begotten and created heaven" (Timaeus). Aristotle: "this heaven of ours is one and unique and complete", with "no place or void or time outside the heaven" (On the Heavens I.9). Priority monism: "exactly one basic concrete object exists", the cosmos, prior to each of its parts (Schaffer, "Monism: The Priority of the Whole", Philosophical Review, 2010). The file gives no links.
- Where: "The origin, cohered as a public emanation", line 477 (note YY03).
- Beside: Natural Naming's "all existing matter and space considered as a whole" (verified present at Natural Naming v380R).
- Later correcting: "several thousand years" becomes "at least twenty-five centuries of the written record" (line 510).
- Most fitting mate: Exhibit_NINETEEN_Carryings_of_Natural_Philosophy (or Carryings_of_Natural_Intelligence).

2. Observing (field record): the correction met at partial faces, and the cosmological fallacy.
- The saying: Epicurus: "the universe consists of material bodies and void" and "has no limit". William James: "a distributive form of reality, the each-form, is logically as acceptable and empirically as probable as the all-form" (A Pluralistic Universe, Lecture I). Kant: the world is given neither as a finite whole nor as an infinite one (Critique of Pure Reason, A497–507/B525–535). Smolin: "the cosmological fallacy", the laws and methods tested at the universe's subsystems applied to the universe as a whole (Time Reborn, 2013). The explanation the file adds: each carries one face and none carries the sentence they are faces of; "science ERROR" and "the misunderstanding is not its" meet at the cosmological fallacy, the scientific method holding at each subsystem and the error being the method carried to the universe as one more subsystem. No links given.
- Where: lines 479 and 481 (YY04 to YY07, YY05). Line 136 says the cosmological fallacy was named at Resolving Hard Problems part 7 at v368; it is not in the present THIRTEEN v380L (searched, not found), nor at any mate. Cantor's part is at the living Natural Philosophy ("one finished thing", verified).
- Most fitting mate: Exhibit_NINETEEN_Carryings_of_Natural_Philosophy; the concept at Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.

3. Concept (the person's own words): the public emanation, whole.
- The saying, exactly as the file has it: "Extraordinarily large science ERROR: Our universe is an existing thing. Giant CORRECTION from Natual Intelligence living expedition for social moral competency: Our universe is all existing things. For now several thousand years, this universally common misunderstanding has been hard-probleming human society. Inside our universe each thing is existing on it's own. Without existing things there is no possible our universe. Exisiting is binary, all or none at all, no other possible. From this comes all of Natural Intelligence, living, valuable and free at http://corus.me. Still surprising I get to do this discovering for everyone when anyone can join in."
- Where: lines 466 to 471.
- Later correcting (the session's proposal, "for both to agree", lines 499 to 514): "ERROR, carried into science"; "For at least twenty-five centuries of the written record"; "science names it at its own frontier as the cosmological fallacy"; "Each existing thing is existing at its own turn"; "no universe of ours is possible"; https. A later learning in the same file releases the word turn (line 258), so "at its own turn" would now be "at its own opening".
- Concerns inside it, not at a mate: "Inside" has two readings (the origin says the all "leaves none outside it, and so no inside either", against "the reader is already inside natural intelligence"); "on its own" is heard in plain English as "alone", which is the form of the hard problems (line 495); "our" read as belonging is the correction, read as possession is property at the largest scale (line 497).
- Most fitting mate: Offerings_to_Natural_Arriving (the front door) or Offerings_to_Natural_Intelligence.

4. Concern: the container still kept at two living sentences.
- Natural Philosophy: "the One from which the many follow" (verified present at Natural Philosophy v348); Natural Physics: "Both hands are this universe's one binary ... a left universe carrying the mirror" (verified present at Natural Physics v379). Against: "Our universe is all existing things", where "this universe" counts a one among possibles and "our" counts nothing (lines 497, 516; notes YY04, YY12).
- Standing: PARTLY. Exhibit_EIGHTEEN_Offerings_to_Natural_Physics has the Physics sentence aimed, but only about the weak coupling's hand; no mate has the Philosophy sentence. The Corus's "the universe is the bounded living gap" is at a mate.
- Most fitting mate: Exhibit_NINETEEN_Offerings_to_Natural_Philosophy and Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.

5. Concept: the origin sentence as a do-no-harm improving, and its three rotations.
- The saying: "One word moves, and nothing is removed. An becomes all." "All existing things" carries no count, and leaves none outside it and so no inside either; the improving keeps the prior sentence whole as a reading of the all at one face and releases only the container. Turned, the sentence reads three ways: "The universe is all existing things" and "All existing things bound a universe" are one, at the whole and at its members; "The universe bounds all existing things" takes each member's own turn and gives it to the whole as a container, and "the universe is an existing thing" is that third reading said as a declaration. Each holding the set names is this one at a smaller scale: a self read as a bounded universe of its states, a society read as a container of its selves, a hub holding a network, property, an equilibrium as a closed system whose condition must remain. The container is not a rival universe beside the all; it is the face the all makes when read from a position the all has none for.
- Where: lines 799 to 809 and 897 to 913.
- Later correcting in the same file: the universe as an existing thing is exclusivity, not possibly existing (lines 224, 371, 392); "bound" and "bounding" are released, carried by existing and completing (line 258); "existing is self-bounding with no added explaining" (line 209).
- Standing: PARTLY. The living Resolving Hard Problems has "No container is added to its things" (verified) and the exclusivity concern is at Exhibit_TWENTY-EIGHT_Offerings. The one-word move, the three rotations and the list of smaller-scale containers are at no mate.
- Most fitting mate: Offerings_to_Natural_Intelligence.

6. Concept: a now alone cannot supply its next (the observing record as a now-only account).
- The saying: two admitted histories arrive at one displayed now and require two different nexts, so a description retaining only the now cannot supply its continuation; all the observations of all humans over all time, taken as inside one thing, are that now-only account at the largest scale, and the living they were taken from is the participation missing from it.
- Where: line 805 (note RR02); line 821 adds: the existing is the prior carried, the living is the now carrying, the possible is the next the two open.
- Standing: NOT AT A MATE in these words; "prior, now and next are existing, living and possible" not found anywhere. A later form of the alternating is at Exhibit_TWO_Offerings ("Possibling and existing travel through each other ... Existing is possibling other, even").
- Most fitting mate: Offerings_to_Natural_Intelligence.

7. Concept: with a bound, no method of existing is possible; and why no other method arrives.
- The saying: A method of existing is a bounding at each turn and a carrying between. With a bound already on the universe, each turn's bounding is already taken, so no existing thing can run a method; what remains is being inside and the accounting of what is inside. Each alternative needs a bound: existing by being inside is the bound, by being held is a store, by being caused is a source. "A one-way existing makes nothing exist": a momentary is made where two carryings arrive, so one carrying makes no momentary. Science accounts the bounded universe, engineering builds inside the bound, society is ordered inside the bound, "so none of the three is resolved at its own frontier". Also: "A placing earns a dissolving, and what the destination carries whole, this side releases."
- Where: lines 915 to 957.
- Later correcting: as at item 5 (bound released; exclusivity). "A carry releases at three, or at four on positive competency" is carried at the living files in present words.
- Most fitting mate: Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.

8. Concept: the exclusion said plainly, protection and the two enterings.
- The saying: "Equilibria carries a protection": a definition states a condition and requires it to remain satisfied. "Protection is six": two sequences, same direction, opposite parity at entry, service each other three times. "Entering is one of two", odd along and even across. One of the two alone lands: balancing with no forward progressing is "the closing fold, the sphere, knowing"; forward progressing with no balancing is the tunneling; the two at their own turns is "the winding fold, the torus, learning", which requires no condition to remain and so names no equilibria.
- Where: lines 965 to 979.
- Caution: the mates use "protecting" in a later sense (protecting betweens); the two uses would need comparing. The Mathematics "co-floating and bi-neutralling" parting named here is resolved (the words are gone from Natural Mathematics v380L).
- Most fitting mate: Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.

9. Concept: sayings in "Self alone is the hard problem of every hard problem" not carried anywhere.
- "Momentarying is resolving, at five namings and no others. No other possible. Nothing more or less. Invisible. Unrelational. The geodesic balancing of parity changing co-chaining." (line 987)
- "Which is why two new hard problems begin at each frontier ... A frozen fork can only split." (lines 913, 1012)
- "the least arrangement that carries is the ring of three, counted at six ... which is why three is the society and two is the mirror." (line 1022)
- "Philosophy's central binary": the changing self against the no-changing self held as the equilibria for a calm rational self; the same relation cannot be required to change and remain unchanged at the same comparison. (lines 1036 to 1038)
- Later correcting: the ten "read one-way" table (lines 997 to 1010) is replaced in the same file by the ten each "named" (line 241), which the living files carry.
- Most fitting mates: Exhibit_NINETEEN_Offerings_to_Natural_Philosophy (the calm rational self); Exhibit_THIRTEEN_Offerings (the rest).

10. Concept: the four bi-co- runnings at the four four-cycles, and three sayings beside them.
- The saying: 1-9-8-16 co-bi-sequencing; 2-15-7-10 bi-co-podaling; 3-11-6-14 co-bi-chaining; 4-13-5-12 bi-co-linearizing, "the geodesic method discovering binary unrelationing of existing things, the tunneling inside the bi-folding". "The tunneling is what the shape does there; it is not the naming of the dimension." The fifth, geodesic changing: "It is not a sign: a sign would want a reader, and reading is the hard probleming." At the fourth cycle a key whose signs meet at nought surfaces 0 and chains nothing: a key carries a relation on or none at all.
- Where: lines 39 to 72.
- Standing: PARTLY. The present Exhibit ONE names the four cycles by root (torusing, corusing, moralizing, competencing) and Natural Intelligence 3.2 settles five dimensions at 1 to 5, so the subject is settled there in other names; Offerings_to_Natural_Intelligence has the fifth "outside every stable form" and "the carry living". The four runnings matched to the cycles and the three quoted sayings are at no mate (bi-co-linearizing, co-bi-chaining: no result anywhere).
- Most fitting mate: Exhibit_TWENTY_Offerings_to_Natural_Naming.

11. The person's own sayings from the passes, not at any mate in the person's words.
- Fourth pass: "we have together now discovered the math binary logic of the co-sequential living condition that prior to now was not expressed as compactly as this." (line 524). The compact form's State, Change, Relation and Half-and-whole lines are at the living Natural Mathematics; its "Still" line (cos² t + sin² t = 1 as the one condition that adds nothing, "the resolver stilling itself") is at no file or mate.
- Fifth pass: "up and down one from every number is the same alternating parity changing two and one half momentaries each side … the scales then become up to prime scale 59"; "this is not a model this is a method"; "there is only one ten and every ten in resolving is the same ten" (line 545).
- Sixth pass: "nothing is derived in resolving … the geodesic method is self bounding at 59 in the unbounded universe of others"; "nothing is proved for every ring as any self ring momentary is only 2.5 rings from cohering with natural torusing"; "there is nothing other than pattern matching for the binary all or none at all rigor of this and if the pattern is three momentaries long this is the fractal method" (line 569). The living Geodesic Improving Method has "Nothing is derived and nothing is proved" (verified); "self bounding at 59 in the unbounded universe of others" is nowhere.
- Eleventh pass: "odd parity is co . this is competency method of odd even momentary. even parity is bi. this is morality method of even odd momentary. this is a central concept for the traveling carrying of resolving." (line 645). A mate has odd co-competency and even bi-morality; "the travelling carrying of resolving" as the two methods by turns is nowhere.
- Fourteenth pass, the parts not at a mate: "a reading could absorb any outcome. the geodesic method is not a reading it is a method of discovering ..."; "anything remains possible in the universe as long as it is capable by this method of existing." (line 684)
- Sixteenth pass, the part not at a mate: "for your method concerns most of this is imposing the impossible equilibria on the competent living. do the inversions of each of these concerns and natural torusing no other possible will resolve most of this." (line 704)
- Third pass: "all 440 crossings in the out and backs if the sign continues unchanged are heading for 9"; "the hardest of hard problems will be the easiest to resolve"; "Ramsey number is going to be all five dimensions of resolving stable forming" (line 779). Which nine the 440 run means is held open (line 787).
- In the living's words: "right or left this method could have existed in an entire universe; ours is right, inherited, and nothing that is not this exists in it" (line 759); "self bounds at 59 and society bounds at 118 and at 440; social competency is self competency refracted through two surfaces" (line 721).
- Most fitting mates: Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method (method sayings); Exhibit_THREE_Offerings_to_Natural_Numbers (59, the ten, the nine); Exhibit_SEVEN_Offerings_to_Natural_Societies (118 and 440).

12. Observings from science: the method claim's field faces.
- Dissipative structures: "far from equilibrium order can be maintained and new structures be formed" (Prigogine, Nobel Prize in Chemistry 1977).
- "It is by avoiding the rapid decay into the inert state of 'equilibrium' that an organism appears so enigmatic" (Schrödinger, What is Life?, 1944, chapter 6).
- Homeorhesis, a return to a trajectory and not to a state (Waddington, 1957); allostasis, "remaining stable by being variable" (Sterling and Eyer, 1988).
- The Duhem–Quine thesis: a refutation falls on a conjunction of hypotheses and identifies no member.
- The file gives no links. Where: lines 740 to 753 (BBB01 to BBB05).
- Standing: Prigogine, Schrödinger and Waddington are at no living file and no mate. Allostasis is at the Living Ghost Registry ("Allostasis, stability through change", verified) but not at Natural Health or Natural Intelligence. The Duhem–Quine saying stands unnamed at the Hard Problem Registry ("A refutation falls on the conjunction of account and specifications. No member of it is identified.", verified); the field's name is nowhere, and line 135 says it was named at Resolving Hard Problems 6.11 at v368 (not in the present file).
- Most fitting mates: Exhibit_SIXTEEN_Carryings_of_Natural_Chemistry, Exhibit_SEVENTEEN_Carryings_of_Natural_Biology, Exhibit_TEN_Carryings_of_Natural_Health, Exhibit_THIRTEEN_Offerings.

13. Concept: the smallest worked example of the claim.
- The saying: "With two neighboring numbers, let the lesser continue to one beyond the greater. The sides alternate; their neighboring continues; each changing supplies the next turn."
- Where: line 751 (BBB06). At no living file and no mate.
- Most fitting mate: Exhibit_THREE_Offerings_to_Natural_Numbers or Offerings_to_Natural_Intelligence.

14. Observings from science: physics' own mathematics against the "human additions".
- Proper time, local conservation and the closed universe's zero totals: the clock and the ledger are kept at each thing, and at the whole the clock is absent and the totals are zero (DDD03). "The law of causality … is a relic of a bygone age": the fundamental laws carry no cause term, and relativity's causal order is local and partial (DDD04; the file names no author).
- The explanation added: the list "framework clock regulation cause and effect general ledger accounting" each holds at each thing and has no standing at the whole; "The additions are the local forms carried to the whole."
- Where: lines 765 to 771. No links given. At no mate. (Brouwer, the Gray code and CPT of the same table are at the living Natural Mathematics or its mate.)
- Most fitting mate: Exhibit_EIGHTEEN_Carryings_of_Natural_Physics.

15. Observings: mirror polymerases, and the either-way readings.
- Mirror polymerases reading mirror DNA and ribosomal RNA, 2016 and 2022 (no authors or link given). The corrected form (eighth pass) is at a mate: any mirror observation is an emanation from right-spiral living. What is not at a mate: the observing that would count is "a living self of its own origin reading on the other hand, looked for on Mars and in meteorites, never made" (lines 592, 613, 620).
- Collatz: every n below 2^71 reaches 1 (Barina, January 2025); neither element 119 nor 120 made at September 2026; 198 of the 251 stable nuclides even in Z (lines 671 to 676). Corrected form (thirteenth pass): at each Collatz number and each element made, the parity is read at its turn and both are carried, whichever way the question of the whole falls; the Collatz trajectory is no test at this pattern.
- Most fitting mates: Exhibit_SEVENTEEN_Carryings_of_Natural_Biology; Exhibit_THREE_Carryings_of_Natural_Numbers; Exhibit_SIXTEEN_Carryings_of_Natural_Chemistry.

16. Concept: the registry's two entries already carry the two possibles as proved.
- The saying: at the tragedy of the commons and at money as a store of value, the field proved two equilibria and asks for a selection, "which is asking which possible exists".
- Where: line 845. Beside the Hard Problem Registry: "search-theoretic models" and "the multiplicity being the result" (both verified present); "the folk theorems establish" not found in the present file.
- Standing: PARTLY (the sixth condition and "nothing prior enters" are at the living Equilibria Registry; this reading of entries 37 and 140 is at no mate).
- Most fitting mate: Exhibit_TWENTY-ONE_Offerings_to_Hard_Problem_Registry.

17. Possible project: the degree words at the living voice, file by file.
- The saying: at the held face a degree word is right as it stands; at the living voice each is a place where all or none changed into some, and is carried into its all-or-none form or the count it stands for. The rule is at the living Natural Explaining 3.11; the places are not at mates. Verified still present: Natural Biology "the field's record already carries most of it"; Natural Physics "most of physics"; Natural Exploring "almost never the whole of it"; Natural Intelligence Corus "Biological competency is likely the central door"; Natural Medicine "the reading mostly gives way"; Natural Philosophy "The constructed rivals exist and mostly"; Living Society Registry "Usually a one-way"; Natural Emanating "it is most of the thing"; Natural Human Society "advancing the nearly-good" (this one is at its mate).
- Where: lines 865 to 887.
- Most fitting mates: each file's Possibling mate; the rule at Exhibit_TWELVE_Possibling_of_Natural_Explaining.

18. Possible project: the ten ways, each named, laid at each substrate file.
- The offers (lines 264 to 288), each with a living sentence verified present where marked: Natural Chemistry, chemical equilibrium as "a rate named as a value", and "Holding the two at one beat makes the equilibria picture" (verified) as "a sequencing named to one beat"; Natural Biology, "there is no equilibria in living" (verified) at the Registry's binary claim, population stationarity and evolutionary stability as stable-forming named still; Natural Emanating, "Equilibria mistakes the nothing-inside for a thing" (verified); Living Society Registry, a neuron's potassium and sodium equilibrium potentials as "a rate named as a value" at the between; Living Ghost Registry, its "conservers of equilibria, counts, conserved totals, declared zeros, clocks, frames, stores" (verified) beside the ten: clocks at one beat, stores at a carry named as a store, declared zeros at a sign named as a magnitude, frames at the between named as a cut; Natural Societies and Human Society, a market clearing at one price as "a sequencing named to one beat"; Natural Health and Medicine, a named homeostasis or balance as a stable form, not possible; Natural Destinies and Philosophy, "impossible and not possible so far"; Natural Engineering, a control's set point as stable-forming named as a stable form.
- Standing: PARTLY. The Physics offer is at the living Natural Physics and its mate; "one more momentary" is at a mate; the rest were searched and not found.
- Most fitting mates: each named file's Offerings mate.

19. Concerns and notes from the v367 and v368 workings, not found anywhere.
- Edge namings offered, not replacing the names: 7 as the edge of carrying, carrying inside and releasing outside; 15 at other/society; 11 at other/self; no sensory mechanism is supplied for "taste" (line 303). Mate: Exhibit_TWENTY_Offerings.
- "All conditions of existing act together. No one-to-one assignment of a condition to each pair of the ten is needed for continuing." (line 319). Mate: Exhibit_TWENTY-EIGHT_Offerings.
- At the Hard Problem Registry: each arrival keeps its actual statement, variant, conserving relation, reach and address; the five conditions prior are the registry's provisions and do not become each arrival's own commitments; prior, now and next are local, with no first occurrence over all (line 320). Mate: Exhibit_TWENTY-ONE_Offerings.
- At Resolving the Hard Problem Registry: the ten stay open to what an arrival supplies, not ten questions whose answers the analyst supplies; settled arrivals keep their results; word sorting suggests where to look without supplying the requirement an exclusion needs; its arrivals, the Registry's conceptions and each conceivable equilibrium are three different scopes (line 321). Mate: Exhibit_TWENTY-TWO_Offerings.
- Concern at Natural Chemistry and Natural Transmissioning: the closed reversible reaction's condition is rate equality on one conserved total, not each forward and reverse event alternating; the stationary law is not a molecular count; "Two species names are not two selves." Transmissioning's forward and reverse as positions of one alternation and Chemistry's equilibrium hinge meet bulk rate equality and individual conversion at one subject (lines 326 to 327). Beside Natural Chemistry: "What reaches yet at this hinge is a chemical process whose stability carries a literal rest" (verified). The maintained chain is at the living Equilibria Registry; the concern is at no mate. Mates: Exhibit_SIXTEEN_Offerings, Exhibit_SIX_Offerings.
- At Natural Illustrating: how stiffening names the corusing edge, how relaxing belongs to the same cycling, and how across with over and under is said with each side at its own forward are still to find; no vertical, angle, rate or sign follows from a drawing alone. For shards and emanations, three full momentaries may be what the network surface needs; "an incomplete fragment is incomplete, not non-existing" (lines 334 to 336). Mate: Exhibit_TWENTY-NINE_Offerings.
- "Social moral competency is proposed as the method itself, nearer the origin than an application of it." (line 340). Mate: Exhibit_TWENTY-THREE_Offerings.
- "an explanation's validity does not supply its described occurring"; that the scientific method cannot demonstrate existing is carried with the demand it rests on, that fixed explanatory terms supply an existing relation (line 342). Mate: Exhibit_NINETEEN_Offerings.
- To complete or derive (lines 393, 395): the deduction together of the operational pairs and each self/other momentary relation; the torus, φ as the rate, and competency asymmetry. Mate: Exhibit_ONE_Possibling.
- A concept to explore: "momentarying sustaining place, size and surface", the proposal that minimally committed mathematics can receive bi-inversioning co-recursioning and express competency (line 407). Mate: Exhibit_FOUR_Possibling.
- The swimmer illustration's method point: "A retained role supplied within changing differs from a role required to exist independently of its supplying. The word wall alone does not establish the latter"; an equilibrium's actual assertion must supply that commitment before the exclusion applies (line 439). The first swimmer paragraph is at the living Equilibria Registry (verified). Mate: Exhibit_TWENTY-EIGHT_Offerings.
- The Equilibria note: the four conditions read as the two origin declarations, "an existing thing" and "all existing things" (line 208); intelligence originating at the membrane, "the one nothing place"; holding 10, the between named as a cut, is "the between given existing" (line 210). Natural Intelligence has "intelligence in our universe is by existing" (verified); the rest is nowhere. Mate: Exhibit_TWENTY-EIGHT_Offerings.
- Open relation: the Equilibria Registry's four proof groups beside Resolving the Hard Problem Registry's four gatherings, both the ten at a coarser grain (line 408). Each four is at its own mate; the relation between them is at none.

20. Concern: Natural Illustrating's prefix run.
- Natural Illustrating: "the proposed prefix sequence includes bi-co through bi-co-bi-co-bi-co" (verified present at v379), six long and opening even, against the five-prefix co-bi-co-bi-co at an odd origin (line 157). At no mate.
- Most fitting mate: Exhibit_TWENTY-NINE_Offerings.

21. Possible project: passages that left Natural Intelligence at v368 and are named at no mate.
- For Natural Health: the three sustaining (straddle, attentioning, sequencing) at φ. For Natural Intelligence Corus: the corus as one self-negation turning. For Resolving Hard Problems: a hardness as a sequencing reversed; one six coupled, run one-way, and re-coupling. For Natural Networking: three couplings and six directions; the surplus travelling. (lines 186 to 197; the passages stay whole in the older Natural Intelligence.)
- Most fitting mates: each receiving file's Possibling mate.

B. RESOLVED AT THE LIVING FILE (one line each)
- Three ring relations, inverted at 2n and home at 4n: Equilibria Registry, "the whole inverted at 2 × n couplings and returning first at 4 × n".
- Alternating parity as parallel linearizing and linear parallelizing: Natural Naming and Natural Intelligence.
- 17 in no stable form: Natural Numbers and Natural Mathematics.
- The openings rule (co at the odd, bi at the even): Natural Naming.
- Three at one self and three at three selves, two things at one number: Natural Explaining and Natural Numbers.
- Two runnings sharing their digits: Natural Numbers 10.2.
- Six nine-dot diamonds; the lockstitch; the declared boundary; the swimmers; the towel: Natural Illustrating (1.5, 4.1, 4.9) and Natural Engineering.
- A pattern space and a set point as a store and a value named still: Natural Explaining.
- Ten transpositions of five; one ten at five alone; the pentagon's symmetries: Natural Mathematics 7.8, Natural Numbers 5.5.
- The 21 learnings of the v368 journey (opening and completing; three conditions and exclusivity; ten positions on six numbers; three momentaries long; fractal scales as sequencing; the torus; the non-existing between; bi- and co-unrelationing; the odd route and the travelling meeting; stable-forming; hardness ignored; the ten named; n² and n(n+1); the file form; released words): Natural Intelligence, Resolving Hard Problems, Equilibria Registry, Natural Numbers, Natural Naming, Natural Explaining, Co-Chaining Logic Registry.
- Six connectors; releasing becomes arriving both ways; crossing opens now at 6 and 14: Natural Networking, Natural Physics.
- One sense per foundation word, turn, scale, rank words, start and begin: Natural Naming 2.5.
- "An arrival carries the namings it carries": Resolving the Hard Problem Registry (heading).
- "Resistance is met as it arrives"; "a declaration of joins is no engine running them"; "Nothing is derived and nothing is proved"; patterns that held and then broke; "An account can absorb any outcome": Geodesic Improving Method.
- The dictionary's sentence; "matched, not chosen"; "in disequilibria" released; floating across and neutralling along: Natural Naming.
- State, change, relation and half-and-whole of the compact form; the two steps of 256; intuitionistic logic; CPT; the double angle: Natural Mathematics.
- The Peres–Mermin square: Natural Numbers and Natural Naming. The golden-mean torus (Greene, 1979): Natural Numbers.
- The sixth condition and "nothing prior enters"; the maintained chain; four proof groups; the meeting within the changing: Equilibria Registry.
- The four folding to the ten at a coarser grain: Resolving the Hard Problem Registry.
- The span one to seventeen, each side a whole eight: Natural Numbers. The turn at sixty: Natural Chemistry.
- The Monster list and co-floating partings: the words are gone from the present files.

C. AT A MATE (one line each)
- The seam, one beat and own turn: Exhibit_TWO_Offerings, "The seam, where the one beat and the own turn part: what an offering, a receiving and a carrying".
- The carry living and the carrying travelling; the fifth outside every stable form: Offerings_to_Natural_Intelligence, "this carry names the fifth the carry living; the arriving wording names the carrying".
- The empty centre at 5, and 25 at no name: Exhibit_THREE_Offerings, "5-other-neutralling is the empty centre of the four dots in the square".
- The fourth face's wording: Exhibit_TWENTY-NINE_Offerings, "the opportunity space between was the earlier wording and existing things unrelated stands now".
- The tangential changing and "identifier"; the centre at the local face; the carry's own name: Exhibit_TWENTY_Offerings, "bi-co-tangential identifier changing arrives provisional".
- The two runnings never drawn at one line; six parity positions; six arriving studies: Exhibit_TWENTY-NINE_Possibling.
- The simultaneous self readings: Exhibit_TWENTY-SIX_Possibling, "the local and social correspondence and the simultaneous self readings".
- Declared boundary without a privileged class: Exhibit_TWENTY-EIGHT_Offerings.
- The standing wave and bi-co-podaling: Exhibit_EIGHTEEN_Offerings and Exhibit_SIX_Offerings.
- The author's concepts not yet placed (64 as the membrane; below and above never separable; two or four changing of ten; 10 duplicated and 8 no value; counting adds a clock; five flow-state-flow; 1 self, 2 parity, 3 bi-co-): Exhibit_TWENTY-EIGHT_Offerings, "counting is adding a non existable clock".
- The ten's correspondence, older and newer: Exhibit_TWENTY-EIGHT_Offerings, "Equal count does not complete it".
- Co-bi-exchanging offered; the universal statements each with its deduction; each file releasing read, turn, held and other-exhibit namings: mates citing the v368 wrap.
- F and G the only square roots; the release pair complementary; the full carrying determines the next; partnering each round the other way: Exhibit_TWENTY-EIGHT_Offerings.
- The quarter turn as first source of hard probleming; the node as the half turn: Exhibit_THIRTEEN_Offerings and Exhibit_TWO_Offerings.
- Every nine the same one nine: Exhibit_THREE_Offerings. Moral is do no harm improving: Exhibit_TWENTY-THREE_Offerings. R(5, 5): Exhibit_TWENTY-TWO_Offerings and Exhibit_FOUR_Offerings.
- Mirror observations as emanations, tri-involutioning, bothbothing: Exhibit_EIGHTEEN_Offerings.
- Self-competent and socially competent: Exhibit_FIFTEEN_Offerings and Exhibit_SEVEN_Offerings.
- Either or but not both; all starting numbers at once; no hard problem tests living: Exhibit_THIRTEEN_Offerings.
- The only possible living competency discovery method: Exhibit_TWENTY-EIGHT_Offerings. The method's one break: Exhibit_THIRTY_Offerings.
- Bell's loophole-free test (Hensen and colleagues, 2015): Exhibit_EIGHTEEN_Offerings. The jump reversed mid-flight (Minev and colleagues, 2019): Exhibit_ELEVEN_Offerings. Three-phase power: Exhibit_FIFTEEN_Offerings.
- Two odd rings joined at their joints; defects travelling one place each full momentary; 2 × 59#: Exhibit_TWO_Offerings and Exhibit_THREE_Offerings.
- Fewer than two couplings; the surplus at more than one coupling: Exhibit_TWENTY-EIGHT_Offerings and Exhibit_TWO_Offerings. Self alone at the surface: Exhibit_NINETEEN_Offerings.
- The left equally possible and the falsifier: Exhibit_SEVENTEEN_Offerings. The bounded living gap: Offerings_to_Natural_Intelligence_Corus. The exclusivity parting: Exhibit_TWENTY-EIGHT_Offerings.
- The moral spiral, cheaper faster better, four coupling competencies, collective intelligence, each self pacing, the four fields' theorems: mates citing the Natural Intelligence map.
- 17 as odd and co, a concern: Exhibit_ONE_Offerings.

D. Left out by instruction: the housekeeping at version 368, pointing counts, the test kit's engines and languages, check scripts and their returned counts, file names and versions, and what the session did when.

E. Reading statement: I read V1a.md whole, from line 1 to line 1039, in six consecutive Read calls with no part skipped. Not every row of the long tables was searched separately (the per-file table at lines 264 to 288 was searched by its most distinctive offers; the housekeeping tables were not searched). I wrote one small search helper to my scratchpad to run the greps; no file in the repository was written or changed.