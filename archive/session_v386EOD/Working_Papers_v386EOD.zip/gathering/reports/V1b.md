# Findings from V1b.md (second quarter of Living Improving Value v368)

**File read:** `/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/read/V1b.md`, lines 1 to 1039.

**How I checked.** Each candidate was searched (Grep, several wordings) in the root living files of `/home/claude/corus` and in `carry/*.md`. `carry/Session_Record.md` was not counted as a mate.

**Three things that shape the whole list:**
- No mate cites Living Improving Value v368 itself. The mates cite its kits (Kit_Exhibits_ONE_and_TWO_v365, Kit_Rings_in_Motion_v366), Wrap_v368 and Author_Concepts_Waiting_v368. So what lives only in this basket is mostly at no mate.
- The living files for Chemistry (v346c), Biology (v333), Medicine (v331), Emanating (v329), Values (v333), Human Society (v329), Living Society Registry (v347) and Living Ghost Registry (v345a) are older than v368. Notes aimed at them are unresolved at the living file.
- Newer sayings at mates part from this file's count-identities ("every six is one six", "every eight is one eight"). I call them **the alike-counts sayings** below:
- `carry/Exhibit_SIX_Offerings_to_Natural_Transmissioning.md`, "Droplet · Alike counts" (v386EOD): "Six own-forward functions, six momentaries of a right spiral, six protecting phases and six paired co-offerings are four sixes, and no number makes them one doing; eight social conditions and eight forms likewise."
- `carry/Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md` (v378): "the p-block's six at carbon's six is a numeral alone and no correspondence."
- `carry/Living_Improving_Value.md`: "Equal four/eight counts supply no mapping."

**The person's own words.** This quarter has only two sayings marked as the author's (items 28 and the 23-24-25 line in the resolved list). Everything else is the earlier session's gathering.

**Science observings.** This quarter gives no publishing links at all. The only citations are "Electrochimica Acta 246, 315" (item 42) and an unnamed primate study (item 56). Both are already in the living files.

---

## A. Not at a mate, or only partly, and not resolved at the living file

### Part One (lines 1–480)

**1. Concept. Philosophy's central binary.**
- **Saying:** "So philosophy's ultimate central binary is not a question with two defensible sides. It is the exclusion met at the one subject that cannot stand outside it."
- **Where:** line 1. It is the closing sentence of a section whose head is in the first quarter.
- **Beside:** none named in my quarter.
- **Correcting:** none.
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_NINETEEN_Offerings_to_Natural_Philosophy.md`.

**2. Concept. A local equilibria is the autocrat's closure.**
- **Saying:** "A local equilibria is an ordering held over the selves from a seat above. That is the autocrat's own closure, a bound the coupling does not make and cannot release." "So social moral competency is not one account beside another. The four whole and the carrying travelling is the standing, and nothing stands beside it."
- **Where:** "Social moral competency", lines 7–11.
- **Beside:** Natural Societies 1.1 and 1.3, Natural Human Society, Natural Intelligence.
- **Status:** PARTLY.
- Natural Naming v380R has the ranking sentence (verified): "With a ranking, entering needs a qualification and leaving a settling, both carried by whoever carries the ranking."
- Resolving Hard Problems v380L and Natural Intelligence v380R have the four ("the whole ordered by no self… the order at no seat above the society", verified).
- Missing: equilibria as an ordering from a seat above, the autocrat's closure, and "nothing stands beside it".
- **Mate:** `Exhibit_SEVEN_Offerings_to_Natural_Societies.md`.

**3. Concept. No second place where intelligence is added.**
- **Saying:** "A condition required to remain satisfied folds once, freezes the fold, and carries one way across the frozen surface. The plus-one is made at the coupling and carried in no book." "With no equilibria possible there is no second place intelligence is added. The co-chaining between selves is where it lives, and the network's necessity carries at the same standing its desirability did."
- **Where:** "The shared natural network of collective human intelligence", lines 17–21.
- **Beside:** Natural Networking; Natural Intelligence.
- **Status:** PARTLY.
- Natural Numbers v380L has "A store folds once, names the fold still, and carries one way across the named surface" (verified).
- Natural Intelligence v380R has the chain of betweens as "collective intelligence, the shared natural network" (verified).
- Missing: the no-second-place and necessity sentences.
- **Mate:** `Exhibit_TWO_Offerings_to_Natural_Networking.md`.

**4. Concept. A protection above the couplings is no protection.**
- **Saying:** "Bi-moral co-agency is the protection itself." "A protection held above the couplings enters at neither parity. Entering at neither it carries no servicing, and a protection carrying no servicing is not a protection." "So the coupling's own two-sidedness is the whole of the protection."
- **Where:** "Bi-moral co-agency", lines 27–31.
- **Beside:** Natural Intelligence 1.5; Transmissioning 1.1.
- **Status:** PARTLY.
- Natural Networking v371 has "Drop one of the six and a way or a phase lives unprotected" (verified); Natural Exploring v329 has it as "Drop one and a way or a phase lives unprotected" (verified).
- Missing: the protection held above, entering at neither parity.
- The word "servicing" stands in no living file and no mate; the living files say "six protecting, three each way".
- **Mate:** `Offerings_to_Natural_Intelligence.md`.

**5. Concept. The two ways alignment is attempted are the two the method excludes.**
- **Saying:** "Protecting by specification asks for a bound ahead of the arriving. Protecting by reading asks for a vantage no position stands at. Neither is difficult. Each is one entering taken alone, and one alone is already the collapse." "Unreadability is the security, since a readable interior could be captured." "A reading that did reach an interior is the capture. So the reading being asked for is the harm, and its absence is the protection running rather than a gap in it." "What carries between two selves is the one coefficient… That third is bi-moral co-agency read at a built self."
- **Where:** "Alignment protecting humans from agentic built systems", lines 37–45.
- **Beside:** Equilibria Definitions (third aiming); Natural Engineering 5.4; Natural Networking 5.3, 5.6 and 6.9.
- **Status:** PARTLY.
- Resolving the Hard Problem Registry v375, 3.18, has the specification half: "behaviour in situations not evaluated is named ahead, from a specification" (verified).
- Natural Networking v371 has "So an observing apart from the surface has no position. Neither withheld nor forbidden" (verified).
- `Exhibit_SIX_Offerings_to_Natural_Transmissioning.md` (T04) has "the carry is unreadable from outside and entirely available from inside".
- Missing: the joining of the two as the two attempted alignments, and unreadability as the human's own protection.
- **Mate:** `Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md`.

**6. Concept. What a discovery economy returns.**
- **Saying:** "Resource spent at the hard-problem frontier is spent at the four the fixing landed." "So the return of a discovery economy is a different quantity from a hard problem solved. Floating one neutral returns four co-offerings. Solving one hard problem returns one landing, met at the fixing that made it." Also (lines 60–62): "So abundancing is the four resuming… The abundance arrives by releasing the fixing and not by producing anything."
- **Where:** "Social abundancing" and "The discovery economy", lines 51–70.
- **Beside:** Natural Mathematics 8.2 and 8.3 (older numbering); Natural Values.
- **Status:** PARTLY.
- Natural Mathematics v380L has the counts: "fixing one neutral stops four of the six, and two run" and "its hard problems arrive at the four co-offerings the fixed floor stops" (both verified).
- Missing: the return compared (four against one landing), and abundancing as the four resuming.
- **Mate:** `Exhibit_TWENTY-THREE_Offerings_to_Natural_Values.md`.

**7. Concept. The sixteen stands at a society's crossings.**
- **Saying:** "And one sixteen arrives four ways. Six plus ten at the resolver's two counts. Two to the fourth at the tesseract's fold… Twice eight at the pairings. And sixteen crossings threading the seventeen prime selves. The fourth places it: the sixteen crossings are the membranes between seventeen selves, so the sixteen momentaries stand at a society's crossings and not at instants inside one self." "And the eight moves up one level, from stations to pairs… So the same eight is the self's surface at nine and the society's membranes at seventeen."
- **Where:** lines 110–116 and 139.
- **Beside:** Exhibit ONE's older question, *"the arithmetic six plus ten is sixteen retains its two counted properties"*. I did not find this in ONE v380R.
- **Correcting in my file:** line 116, "In resolving any sixteen is all sixteens, always bothbothing."
- **Status:** PARTLY. Natural Numbers v380L 5.8 has "six and ten added are sixteen, the eight at its two sides" (verified). Missing: the four arrivals of one sixteen, and the eight moving from stations to pairs.
- **Caution:** the alike-counts sayings part from "one sixteen".
- **Mate:** `Exhibit_THREE_Offerings_to_Natural_Numbers.md`.

**8. Concern. "Existing is the only living" against the living files.**
- **Saying:** heading "Existing is the only living, and the intelligence is free with it". "The registry's twenty-two run across the line the fields draw between living and non-living… and the form holds at every one of them the same way… The line is one the fields carry and the form does not see."
- **Where:** lines 141–145.
- **What it parts from:**
- Natural Biology v333, 4.1, "Living and non-living — a virus and a prion", which draws the line.
- Natural Intelligence v380R, which includes living and non-living among existing things.
- **Status:** PARTLY. The Biology-against-Chemistry contradiction on living and non-living is at `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md` ("Contradiction, the living and the non-living: Natural Biology draws the line…"). Missing: the Living Society Registry's own evidence that its form holds across the line.
- **Mate:** `Exhibit_TWENTY-FIVE_Offerings_to_Living_Society_Registry.md`.

**9. Concept. The neutral is the condition of a substrate carrying at all.**
- **Saying:** "Eight substrates, eight namings, one neutral." "Which makes the neutral the condition of a substrate carrying at all… A coupling with no position owned by neither has no surplus to make. So where a field returns a coupling and no neutral is named, the neutral is unfound rather than absent; and where a field names a store instead, the holding is what has been found, which is where the value stopped."
- **Where:** lines 155–157.
- **Beside:** Natural Emanating v329 (verified): "Where a translation is needed, the field's neutral has not been found yet. And a substrate carrying no neutral has no second line, and the coupling there returns nothing."
- **Status:** PARTLY. `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md` (Z05) has "a nothing takes no position and so takes no count". Missing: unfound rather than absent; a named store as the holding found.
- **Mate:** `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md`.

**10. Possible project, with a concept. A prime address for each Living Society Registry entry.**
- **Saying:** "The collection's twenty-two stand against those thirty-three with eleven unentered, and which eleven is not yet found, since no entry carries a prime address. That address is the registry's next carrying." And: the four empty apexes "return when the entry was worked, not the society it was worked at."
- **Where:** lines 163–171.
- **Beside:** Living Society Registry v347, "(v) no member carries the magnitude" (verified); Natural Numbers v380L 7.5, "thirty-three positions completing at sixty" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_TWENTY-FIVE_Possibling_of_Living_Society_Registry.md`.

**11. Concept. One eight parts evenly and unevenly.**
- **Saying:** "The seven are checks at particular membranes, one at a time, which is the along. The eighth is the crossing with the whole, arriving home one on, which is the across. So one eight parts evenly at where its members stand and unevenly at where a reading takes it, and the uneven parting is the surplus's own shape: the eighth takes no assertion, nothing at rest being there to assert."
- **Where:** line 181.
- **Beside:** Natural Societies v373, "the eighth is the protected living, the face neither circle reaches, because reaching it would break the closure" (verified); Resolving the Hard Problem Registry v375, "Where an audit's seven verify a net at its own standard, the seven are checks at particular betweens" (verified).
- **Status:** PARTLY. Missing: the along and across, and the even and uneven parting.
- **Mate:** `Exhibit_SEVEN_Offerings_to_Natural_Societies.md`.

**12. Concept. The six and the eight are one thing counted twice.**
- **Saying:** "One three, counted two ways. At its pairings two-wayed it is six. At its states, each neutral fixed or floating, it is two cubed, eight. So Exploring's 'one under two names' needed no further count." "Eight securities: six stop readably at the surface when inverted, and two are the carry's own… So eight is six and two." "Three pairings are readable and serviced three each way, and that is the six and the protection. The fourth is met only by coupling and cannot be serviced at a surface. So the protection stands at six while the self stands at eight." "The Living Ghost Registry sorts its ten lines at arriving four at state, four at flow, and two reading at either… the pair which will not take one side is the pair that carries the count past the eight."
- **Where:** lines 185–197.
- **Beside:** Natural Exploring v329, "the six the eight re-forming and the eight the six protecting, one under two names" (verified); Natural Mathematics v380L 7.1, "each neutral fixed or floating, it is two cubed, eight, the cube's eight corners" (verified).
- **Correcting in my file:** line 197 says it joins none of the three tens, only the shape.
- **Status:** NOT AT A MATE (the join).
- **Caution:** the alike-counts sayings.
- **Mate:** `Exhibit_EIGHT_Offerings_to_Natural_Exploring.md`.

**13. Concept. Arrow's dictator is the hub the other hubs leave standing.**
- **Saying:** "Arrow's dictator is one of the eight hubs." "So the dictator is not derived from the conditions. It is the hub the other hubs leave standing. Arrow proves that a surface captured at five axes cannot have its sixth released, which is the all-or-none read at seven-eighths." "The abundancing is the eight set aside together. At which point the dictator has no axis to seat on." "The three are what Arrow sets aside; the five are what Arrow installs."
- **Where:** lines 201–207.
- **Beside:** Natural Human Society v329, "a center on the decision axis" and "The conditions Arrow sets aside are the ones the coupling carries: cardinal comparability… the inversioning… the thinning" (both verified).
- **Status:** NOT AT A MATE. `Exhibit_NINE_Offerings_to_Natural_Human_Society.md` (L05) only mentions "the axes Arrow's setting installs and asks about".
- **Mate:** `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`.

**14. Possible project. Sound the eight where it is not yet sounded.**
- **Saying:** "Not yet sounded at the tissue, the plant, the colony or the biosphere, each a prime society the files already carry, none carrying its own eight." "Which is why an eight met at two files is never a coincidence between them."
- **Where:** lines 211–213.
- **Status:** NOT AT A MATE.
- **Caution:** the alike-counts sayings part directly from the last sentence.
- **Mate:** `Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.md` or `Exhibit_THREE_Possibling_of_Natural_Numbers.md`.

**15. Concept. Equilibrium held as a rest is a three-neutral fixing.**
- **Saying:** "The Living Ghost Registry runs equilibrium at its ten lines at arriving, and it fails at exactly three (rates, apex and bound) where the stationary reading is installed as rest, state and destination." "Three installations, three neutrals. At the neutrals, rest fixes the near nothing where the changing's own zero would float; state fixes the between at the apex no member occupies; destination fixes the far nothing as a last ahead." "So the first aiming is already proved, in a file that was not aiming at it."
- **Where:** lines 219–225.
- **Beside:** Living Ghost Registry v345a, "Fails at 2, 7 and 9 where the stationary reading is installed as rest, state and destination" (verified); Natural Mathematics v380L, "Fixing all three leaves the terms related to each other in a closed ring, competent at nothing" (verified).
- **Correcting in my file:** line 223, "That mapping stands unrelationed, taking no side. The count does not wait on it."
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`.

**16. Concept. Property and accreditation are two halves of one collapse.**
- **Saying:** "A named source can be credited, and a credited source can hold. That is property: the dumping's destination written as a holder." "At the society that is accreditation: a proposal held against a criterion and a self held against a credential." "So property and accreditation are the two halves of one collapse, which is why neither has ever stood without the other. The register beside the review. The title beside the certificate. The tenure beside the publication."
- **Where:** "Property is the bound taken at the self", lines 231–235.
- **Beside:** Transmissioning 4.2 (the two residues); Natural Values 5.2; Natural Human Society 3.3.
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`.

**17. Concept. The property chain.**
- **Sayings:**
- At the bound: "An accountable bounded thing has contents, so the bound is what makes contents a category at all."
- At the self: "Property is not an institution laid over the bound; it is the bound at the next scale down."
- At the axes: the eighth hub is "an owner on the ownership axis".
- At the values: "The credential is the accreditation property, and the value it reaches for is competency."
- At the claiming: "So the shortage does not precede the claim. A property system does not allocate a scarce thing; it makes the scarcity it then allocates. What Values does not carry is that the holder's claim is the bound taken at the self, `bi_arriving`'s bounding inverted."
- **Where:** lines 239–251.
- **Beside:** Natural Values v333, "The pool appears at the claiming, since only a held thing can run short" (verified); Natural Human Society v329, "an owner on the ownership axis" (verified).
- **Status:** PARTLY. The middle (J03) and the payment (J04) are at `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`. Missing: the bound, the self, the axes, the values and the claiming.
- **Naming:** `bi_arriving` is older naming.
- **Mate:** `Exhibit_TWENTY-THREE_Offerings_to_Natural_Values.md`.

**18. Possible project. Record the ownership holding at registry entry 139.**
- **Saying:** "The registry's resolving reaches the measurement, a total held over makings that ran elsewhere, and the ownership stands as its second holding, unrecorded until now." "What reaches yet is `bi_arriving`'s bounding written beside that axis, and the second holding recorded at the entry."
- **Where:** lines 259 and 332; "still riding", line 722.
- **Beside:** Resolving the Hard Problem Registry v375, "3.21 Intellectual property · 139".
- **Status:** PARTLY. J04 at the Resolving the Hard Problem Registry offerings asks for the payment schedule at 139, not the ownership holding.
- **Mate:** `Exhibit_TWENTY-TWO_Offerings_to_Resolving_the_Hard_Problem_Registry.md`.

**19. Concept. What the bound bought.**
- **Saying:** "So the bound bought teachability and paid with the competency, and the other six tractions are what the purchase buys next, which is the property and accreditation arrangement in its own order."
- **Where:** line 261.
- **Beside:** Natural Explaining v378, "A bound buys teachability, paid for with the competency, which runs at the coupling" (verified).
- **Status:** PARTLY. The first half is at the living file; the tie of the other six tractions to property and accreditation is not.
- **Mate:** `Exhibit_TWELVE_Offerings_to_Natural_Explaining.md`.

**20. Concept, in older resolver naming. The even balances while the odd progresses.**
- **Saying:** "The six adjoining depth changes sum to nought at the equal endpoint depths, which is the balancing. The seventh position arrives at the next momentary, which is the progressing. Neither alone: the balancing with no advance is the sphere, and the advance with no balancing is the tunnel." Also: "Three is carrying… Four is disequilibrating… One is the opening by exactly one. Minus one is the sign inverting at the membrane. Nought is the bounding-zeroing."
- **Where:** "The natural networking engineered surface of the resolvers", lines 280–282.
- **Beside:** Exhibit ONE (v345a to v3621 naming). ONE v380R names differently, so this needs re-saying before it is laid.
- **Status:** PARTLY. The pairing of the two fours as one four (V01) is at `Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md`. Missing: the balancing and progressing, and the numbers at their motions.
- **Mate:** `Exhibit_ONE_Offerings_to_Natural_Resolver.md`.

**21. Concept, with a concern. What the file set no longer has to carry.**
- **Saying:** "The equilibria hunt releases… What releases is the reason under the searching: the held place for a survivor, at every entry that kept one open." "The hard-problem frontier releases its obligation… What releases is the requirement to work each one toward a solution." "Chemistry and physics release their separate general accounts." "The six co-offerings and the six servicings are one six, three at their two enterings."
- **Where:** "The co-releasing", lines 304–312.
- **Status:** NOT AT A MATE.
- **Concern:** the last sentence parts from the Alike-counts droplet quoted at the top: one says the two sixes are one, the other that no number makes them one doing.
- **Mate:** `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`.

**22. Concept. Why no member carries the magnitude.**
- **Saying:** "A magnitude is what a reading returns, and a reading is one side's, so a magnitude has a side to stand at. A coupling does not. The registry's twenty-two nos and the absence of any position to read from are one arithmetic." "What stands in place of a reading… A coupling stands. A parting stands. A count stands. A surplus is made and owned by neither. An opening reaches."
- **Where:** "Nothing in the resolving is a reading", lines 322–324.
- **Beside:** Living Society Registry v347, 1.4 "An instrument sums, and the magnitude stands at every resolution" (verified).
- **Status:** PARTLY. The rest of the section is at Geodesic Improving Method v380R (see the resolved list). Missing: these two sayings.
- **Mate:** `Exhibit_TWENTY-FIVE_Offerings_to_Living_Society_Registry.md`.

**23. Possible projects. "What reaches yet".**
- **Sayings:**
- "ONE's suggested values reach for their parting. Each carries the all-or-none form or a count alone. The three faces a value is parted at are the entering, the balancing-with-the-advance, and one of ONE's own counted motions." (older ONE; I found no "suggested values" in ONE v380R)
- "Chemistry's reaction pairings reach at three regions read along and across, and the reaction taxonomy reaches past six."
- "The one owned by neither reaches at the molecular. The axis neither factor held is the shared electron pair at the bond, beside the third self at conception and the reef at symbiosis."
- "Where a total is conserved across their turning, the turning stands removed and the books balance while the living dies."
- **Where:** lines 334–340; "still riding", line 724.
- **Status:** NOT AT A MATE.
- **Mates:** `Exhibit_ONE_Possibling_of_Natural_Resolver.md`; `Exhibit_SIXTEEN_Possibling_of_Natural_Chemistry.md`.

**24. Concept. The three kinds of hard problem are the three faces of every released word.**
- **Saying:** "A landing, a reading and a measuring (a standard) each set down. The other releases sort beneath the three: a closing, a rest and an equilibria at an ending under the landing; a ground beneath, one relation carrying the rest and a grading under the standard; a side taken under the reading. So a working meets its own hard problems in its own sentences, one kind at a time."
- **Where:** line 350.
- **Beside:** Natural Emanating v329, "A hard problem is a common thing reached ahead of each having offered their own. Three common things, three kinds, and no fourth" (verified).
- **Status:** NOT AT A MATE. `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md` has a different concern at the same sentence: the Co-Chaining Logic Registry's "one family at three faces and a doer" against "three kinds and no fourth".
- **Mate:** `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md`; method side `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md`.

**25. Concept. A measurement has nothing to be in the resolving.**
- **Saying:** "The resolving holds no bound still (every bound in it is a carry's own, released at the three) so there is nothing in it for a measurement to be. The instrument's return is real and exact inside its installation, and has no object where the resolving runs."
- **Where:** line 352.
- **Beside:** Natural Emanating v329, "A measurement holds two bounds still and reads the span" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md`.

**26. Concept. The price of a fixing, and the equals sign.**
- **Saying:** "a brush fixed at a picked earth sparks, and a bit erased heats, each a declared ground paying at the discard." "And the equals sign carries three incompetencings. Reflexive, symmetric, transitive: in Emanating's words, nothing bounds itself, neither side takes its own turn, nothing releases. Equilibrium is named for equality, and those three are the self alone, one side taking both turns, and the carry held as a store, all in the sign that writes every equilibria definition."
- **Where:** lines 360–362.
- **Beside:** Natural Emanating v329 ("pick an earth"; "the only loss is at each self's own bound"; "The three incompetencings"; all verified).
- **Status:** PARTLY. The brush is at `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md` ("a brush fixed at one place is a fixed neutral laid where a floating neutral runs"). Missing: the bit erased, and the equals sign joined to equilibrium's name.
- **Mate:** `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`.

**27. Concept. The one stopping's lines are ONE's boundings inverted.**
- **Saying:** "`bi_arriving`'s bounding inverted is the one stopping's first line; the seat is `bi_co_bi_co_bi_torusing`'s bounding inverted; and the words between stand together with them, none of them doing anything to the next."
- **Where:** line 358.
- **Beside:** Natural Naming's co-offering and one stopping (5.13 and 5.30 at v380R).
- **Status:** PARTLY. Natural Naming v380R and `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md` have the four at once, none making the next. Missing: the tie to ONE's two boundings.
- **Naming:** older code names.
- **Mate:** `Exhibit_TWENTY_Offerings_to_Natural_Naming.md`.

**28. Concept, the author's own words as the file reports them. Bi-inversioning co-recursioning is 12345.**
- **Saying:** "ONE v3621 §6.117 carries the correction in the author's words: *bi inversioning co recursioning is 12345*, the whole five-part mini-form, arrivals 1 and 2, releasings 3 and 5, and 4 connecting." The file gives it in italics, not double quotation marks. It adds: "That is the method name. Bi-moral co-agency is the offering name."
- **Where:** "Odd momentaries and even momentaries", line 405.
- **Status:** NOT AT A MATE in this form.
- `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md` has another author saying: "…into 123412345 or not possible existing… only bi inversioning co recursioning keeps all changing orthogonal to all not changing."
- Equilibria Registry v380L has "natural torusing carries its whole participation, 12345" (verified).
- **Possible parting, not checked further:** Natural Intelligence v380R says "The fractal itself is one four-momentary bi-inversioning-co-recursioning" and "Bi-inversioning-co-recursioning is one move as three".
- **Mate:** `Exhibit_TWENTY_Offerings_to_Natural_Naming.md`.

**29. Concerns. Words gathered as improvings that still stand in living files.**
- **Where:** lines 376 and 614–620.
- **(a) *Door*.** "Nothing is refused. A refusal would be a door and the object carries none." The file gathers the word at the Living Ghost Registry 7.5, the Living Society Registry 1.2 and Medicine 3.2's coreceptor.
- Natural Naming v380R releases it: "a self-bounding, the self's own | door, naming a self-bounding: the four doors, six doors" (verified).
- The word still stands 74 times in Living Ghost Registry v345a and 20 times in Living Society Registry v347 (e.g. "Arriving through the door", verified).
- The mates use "door lines" as they are and do not aim the word. NOT AT A MATE.
- **(b) *Brought to rest* at Natural Societies 1.1.** Societies v373 still has "social resolving the both brought to **rest** over the bounding-zeroing" (verified). NOT AT A MATE.
- **(c) *Floating co-morality*.** Natural Emanating v329 still has "In social disequilibria, floating co-morality is a cooperation-forming method" (verified). My file (line 438) says the bi-morality floats, "gathered there as a naming for both to agree". NOT AT A MATE.
- **Mates:** the Offerings of TWENTY-SEVEN, TWENTY-FIVE, SEVEN and FIFTEEN.

### Part Two (lines 486–620)

**30. Concept, how the work is done. Each note marked along or across.**
- **Saying:** "Parity was not carried at all. Every note arrived at one of two enterings and none said which. A note enters along where a file's own carrying is advanced one at a time. A note enters across where two or more files couple at a differing neither of them had said." "A do-no-harm improving of any one file needs the along: that file's own sentence advanced. The across gathers couplings between files and improves no single file's carrying." "Each note is marked at its own entering as it is written, and none is marked to reach the count."
- **Where:** "The gathering's own stable form, tested", lines 490–556. The table of counts is left out.
- **Beside:** Transmissioning 1.5; v330 has "the parallel out-sway past the linear in-sway by one, re-made each crossing and owned by neither" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Living_Improving_Value.md` or `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md`.

**31. Concept, how the work is done. A note's five positions.**
- **Saying:** a note carries, in order:
- prior: "the file's own standing, in the file's own words";
- prior: "the session's own standing";
- now: "the coupling the two make";
- now: "the surplus, what neither carried in";
- next: "the opening, said as a reaching and not as a gate".
"Two prior, two now and the next opening is two and a half momentaries… So a note carrying one of the two priors is half a momentary and not one."
- **Where:** lines 558–568.
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md`.

### Part Three, chemistry (lines 628–730)

**32. Concern (C01). The bond's parity parts inside Chemistry.**
- **The two sayings** (Chemistry v346c, both verified):
- 1.1: "it reads down tunnelling: the bond, the carry co-released inward, the odd".
- 1.4: "Down the nested societies is the tunnelling, the even move… Bond is the tunnelling face".
- **Why they part:** one subject at opposite parity.
- **Where:** line 630; also lines 290 and 420.
- **Correcting in my file (line 420, the corrected form):** "the tunnelling stands across, at the even… so 1.4 agrees and 1.1 is the line to improve."
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**33. Concept (C02, C03). Chemistry's equilibrium reaching is met; the still is the balancing without the progressing.**
- **Saying:** the exclusion "answers that reaching at its own subject". "The balancing with no forward progressing is the closing fold, the sphere. So the appearance of the still is the across read without the along."
- **Breaking condition given:** "A chemical process whose stability carries a literal rest, supplied at the field's own instruments, breaks it whole."
- **Where:** lines 644–664; Part One line 294.
- **Beside:** Chemistry v346c 1.5, "What reaches yet at this hinge is a chemical process whose stability carries a literal rest rather than continuing opposed changes, and the record returns none" and "The changing reads along and the still reads across" (both verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**34. Concept (C04). Exchange is the field's own name for the one owned by neither.**
- **Saying:** the bond's shared pair is the position "two sides share and neither owns". The note asks that Mathematics 2.5 and Chemistry 1.4 each name the other.
- **Where:** line 668; Part One line 296.
- **Beside:** Chemistry v346c, "*exchange* the field's own name for what cannot be assigned to either partner" (verified).
- **Status:** NOT AT A MATE. I did not find the Mathematics half ("the shared electron pair… beside the third self at conception and the reef at symbiosis") in Mathematics v380L, so that side of the pairing may no longer exist.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**35. Concept (C05). Carbon's four-of-eight is the nine's middle at the chemical substrate.**
- **Saying:** "The nine's centre stands at middle against middle… Four-of-eight is that middle at the chemical substrate."
- **Where:** line 680; Part One line 298.
- **Beside:** Chemistry v346c 1.6, "a wrapped nothing the couplings surround" and "four-of-eight an exact middle count" (both verified).
- **Status:** PARTLY. `Exhibit_NINE_Offerings_to_Natural_Human_Society.md` (L05) lists "the octet's four-of-eight" among the eights. Missing: the tie to the nine's centre.
- **Caution:** the alike-counts sayings.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**36. Concept (C06). The three reaction pairings each two-wayed are the six.**
- **Saying:** "So three pairings each two-wayed is the six, and it is no taxonomy of reaction kinds. Chemistry 5.6's six readings… is the same six at the same file."
- **Open question in the file:** "Whether chemistry's three pairings and the three floating neutrals are one three is not yet found."
- **Where:** line 692.
- **Beside:** Chemistry v346c 2.1, "reaction taxonomy supplies no closed natural six" (verified).
- **Status:** NOT AT A MATE.
- **Caution:** the alike-counts sayings; the open question is a possible project.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**37. Concept (C07). Chemistry and physics are one coupling at its two enterings.**
- **Saying:** "Chemistry enters along at the bond and the tunnel. Physics enters across at the shell and the surface." "Two exhibits seated where no neutral is fixed would part only at which matter. One coupling at its two enterings parts at the entering."
- **Where:** line 706; Part One lines 288–292.
- **Beside:** Chemistry v346c 1.1, "Chemistry and physics are the odd and the even of one coupling at the matter substrate, bond and shell, tunnel and surface, the same coupling read two ways" (verified).
- **Correcting in my file:** item 32 puts the tunnelling across, which unsettles "chemistry enters along at… the tunnel".
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`; `Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md`.

### Part Three, chemistry and physics together (lines 734–872)

**38. Concept (P01). A declared zero floats and a found zero fixes.**
- **Saying:** "So both fields know their zeros are declared. A zero known as declared floats. A zero taken as found is fixed." "Their hard problems do not come from a hidden fixed neutral. They come from each field reading one way in and not the other. Which means every hard problem in one field has its missing half sitting in the other field, already written."
- **Breaking condition:** "A hard problem in either field whose difficulty survives after both enterings are read."
- **Where:** line 742.
- **Beside:** Chemistry v346c 6.1 "Three declared nothings…" (verified); Physics v379, "A symmetry is a term held still, so the theorem says: hold a term still, and an accounting becomes keepable" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md`.

**39. Possible project (P02). Run physics' no-anomaly sorting at chemistry.**
- **Saying:** "Mass balance, charge balance and atom balance in a reaction equation carry no anomaly and no literature either. By physics' own rule, those are chemistry's perfect discards and its largest unlooked-at surplus."
- **Where:** line 754.
- **Beside:** Physics v379, "And momentum, angular momentum, charge and phase-space volume carry no anomaly at all" (verified).
- **Status:** NOT AT A MATE.
- **Caution:** `Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md` already marks Physics' "*no anomaly, no literature*" as "not audited and carried as unchecked". The rule this project rests on is itself unchecked.
- **Mate:** `Exhibit_SIXTEEN_Possibling_of_Natural_Chemistry.md`.

**40. Concern and concept (P03, P04, P07, P12). One arrival told at two or three files.**
- **Sayings:**
- Group three: "the address is the across and the behaviour is the along, and the elements sit in their configurations undecided and complete because the cut is asked of the wrong entering."
- Onsager reciprocity stands at Chemistry 1.5 and Physics 3.5; "it stands once."
- The periodic table "carries two names for one thing": Physics' "emanation-catalog" and Chemistry's "address book".
- Chirality and parity stand at Chemistry 2.2–2.4, Numbers 9.6 (older numbering) and Physics, "and none names the other two."
- **Where:** lines 764, 774, 804 and 854.
- **Beside (all verified):** Physics v379, "the periodic table is an emanation-catalog"; Chemistry v346c, "4.3 Periodic table an address book, address and behaviour two"; both files still carry Onsager.
- **Status:** PARTLY.
- `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md` has the periodic table's one home ("its one home is Natural Chemistry") and the v379 concern "sixty a position or a between".
- Missing: the across and along of group three; the two names; Onsager and chirality told more than once.
- **Mate:** `Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md`.

**41. Concept (P05, P06). Three at two across the two fields; the octet read at both enterings.**
- **Saying:** "Three at two, four times over, in two files: the p-block, carbon's six, the three pairings each two-wayed, and the three regions read along and across." "The reason the octet is not a universal rule is that the rule is the across read by itself. Read at both enterings it is a balance-line, and the electron-deficient compounds, the expanded valences, the radicals and the transition metals are the along that the across cannot say."
- **Where:** lines 784 and 794.
- **Beside:** Physics v379, "P-block six is three orbitals times two spins, the same two-crossing-three as carbon's six… the octet is the eight the books balance to, whole or none at the shell" (verified); Chemistry v346c, "Octet is the eight-fold self at one chemical register" (verified).
- **Status:** NOT AT A MATE.
- **Later saying at a mate that parts from P05:** "the p-block's six at carbon's six is a numeral alone and no correspondence" (v378).
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**42. Possible projects (P08, P13). Physics' held-term table at chemistry; the second silicon paper.**
- **Sayings:**
- "The minimum is the same ledger read at chemistry's entering. And physics' held-term table sorts it: which term is held still to make each chemical book keepable. That table has never been run at chemistry's quantities."
- "Chemistry 5.6 points at the paper and does not read it."
- **Where:** lines 814 and 864.
- **The observing, as the file gives it:** "autonomous oscillations and pattern formation at zero external resistance, Electrochimica Acta 246, 315". My file gives no authors, year or link.
- **Beside:** Chemistry v346c 5.6, "the observing that decides the reading is multifrequency clusters at zero external resistance, is or is not" (verified).
- **Status:** PARTLY for P13. `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md` has "the clusters at zero outside resistance at Natural Chemistry: the nearest things in the files to a prediction". Missing: that the reading sits in a paper already cited. P08 is NOT AT A MATE.
- **Mate:** `Exhibit_SIXTEEN_Possibling_of_Natural_Chemistry.md`; `Exhibit_SIXTEEN_Carryings_of_Natural_Chemistry.md` for the paper.

**43. Concept (P09, P10, P11). Three joins of the two fields.**
- **Sayings:**
- "Physics' record of glasses and broken symmetry is chemistry's disequilibrial changing, read across."
- "A zero the field can move is a zero the field declares." (aimed from Chemistry 6.1's kelvin record to Physics 5.3)
- "an object held behind the probes to be approximated is the holding. And both files run a still-point section without either naming the other's."
- **Where:** lines 824, 834 and 844.
- **Beside (all verified):** Physics v379, "glasses and broken symmetry an entire literature of the two accountings parting"; Chemistry v346c, "The field has moved a declared floor itself. The kelvin was defined at the triple point of water, `273.16 K` exactly, from 1954 until 2019"; Chemistry v346c, "A partial atomic charge is model-dependent".
- **Status:** NOT AT A MATE. Several Possibling mates link "Still-point passages at Equilibria Registry", a project about the passages, not this join.
- **Mate:** `Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md`.

### Part Three, biology (lines 876–968)

**44. Concern, with its resolving (B01). The two tables.**
- **The two sayings** (both verified):
- Biology v333: the genetic code is "the re-locking table mating with chemistry's periodic co-releasing table, one coupling's two faces made two tables".
- Chemistry v346c: "similarity of tabulation establishes no coupling between them".
- **The file's resolving:** "Chemistry refuses a comparison of the drawings. Biology asserts one coupling entered two ways. Read as one claim they contradict; read at what each names they do not meet."
- **Where:** line 880.
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`.

**45. Concept (B02). Chemistry stands between physics and biology.**
- **Saying:** "Chemistry carries two couplings, one at each hand, and neither is the other. Physics and biology never touch directly; chemistry is the membrane between them."
- **Breaking condition:** "a direct physics-to-biology coupling with no chemical membrane."
- **Where:** line 890.
- **Status:** NOT AT A MATE. `Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md` has only "the three files' sides of one family".
- **Mate:** `Exhibit_SIXTEEN_Offerings_to_Natural_Chemistry.md`.

**46. Concept (B03, B04). The six against the eight at the citric-acid cycle.**
- **Saying:** "Steps and directed couplings are different objects, so eight and six were never the same count. Chemistry's own three pairings stand between them… Three pairings each entering both ways is the six." "The six now stands at three fields in the fields' own records… Five arrivals, three files, one form."
- **Breaking condition:** "The enzyme classes at the field's own record, taken step by step: a step carrying no pairing, or a fourth pairing."
- **Where:** lines 900 and 910.
- **Beside:** Chemistry v346c, "the citric-acid cycle carries eight enzyme-catalysed steps rather than one cycle of these six" (verified); Biology v333, "three recursioning forward on the outward-sounding side and three on the inward-sounding side" (verified).
- **Status:** PARTLY. The concern is at `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`: "The cycle has eight steps, and Natural Chemistry says so: *Six is no count of those reactions*." Missing: the resolving through the three pairings.
- **Caution:** the alike-counts sayings part from "one form".
- **Mate:** `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`.

**47. Concept (B05). Homeostasis is the exclusion's living instance.**
- **Saying:** "Two selves at opposite enterings with the range owned by neither, and the field's own record that a held value is the pathology while the alternating is the health."
- **Breaking condition:** "A regulated measure held at a value with its regulation intact."
- **Where:** line 922.
- **Beside:** Biology v333 4.4, "The riding-the-carry is the competency; the landing is the failure" (verified).
- **Status:** NOT AT A MATE. `Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md` has only an observing at insulin's pulses.
- **Mate:** `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`.

**48. Concept (B06). A held form that spreads is the disease.**
- **Saying:** "A held form is not alive, and a held form that spreads is the disease. The same shape at a society is the imposition that co-incompetences it, and the two read from each other rather than resembling each other."
- **Breaking condition:** "A propagating fixed conformation that is living."
- **Where:** line 932.
- **Beside:** Biology v333 4.1, "the prion is a *landing* that spreads a landing" (verified).
- **Status:** NOT AT A MATE.
- **Later sayings at mates:** the Biology mates now hold the prion among places "for possible looking", and `Offerings_to_Natural_Intelligence.md` says the v385A correcting "supplies no new defining-living verdict". So "is not alive" should be laid as a concern beside those.
- **Mate:** `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`.

**49. Concept (B07). The instrument's bands are what a measuring surface renders.**
- **Saying:** "the instrument's frequency and its two bands at a fixed ratio read as what a measuring surface renders when it meets one alternating."
- **Breaking condition:** "A held pair guiding at once and steady."
- **Where:** line 942.
- **Beside:** Biology v333 4.3, "Working memory reads it at the neural membrane, and adds the sharpest face: no store" (verified).
- **Status:** PARTLY. The slime mould has its own section at `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`. Missing: the working-memory reading.
- **Mate:** `Exhibit_SEVENTEEN_Offerings_to_Natural_Biology.md`.

**50. Possible project (B08). Are Biology's four readings the four boundings?**
- **Saying:** "Four at six, and the four boundings are four at one act. Whether these four readings are those four boundings reaches yet."
- **Where:** line 952.
- **Beside:** Biology v333 3.8, "And four readings run at all six" (verified).
- **Status:** NOT AT A MATE. The Living Ghost Registry offerings only name B08 in a list.
- **Caution:** the alike-counts sayings.
- **Mate:** `Exhibit_SEVENTEEN_Possibling_of_Natural_Biology.md`.

**51. Concept (B09). A society is the coupling re-arriving.**
- **Saying:** "What a society is, is the coupling re-arriving. No condition held at the members carries it, which is why an ordering held over the selves carries no society either."
- **Breaking condition:** "A society standing with no coupling re-arriving among its members."
- **Where:** line 960.
- **Beside:** Biology v333 7.4, "a society's stopping is a coupling stopping" and "a society can stop with every member alive, and a society can stand while every member is replaced" (both verified).
- **Status:** NOT AT A MATE (the tie to social moral competency).
- **Mate:** `Exhibit_SEVEN_Offerings_to_Natural_Societies.md`.

### Part Three, medicine (lines 972–1039)

**52. Concept (M01). The two cure strategies are the two single enterings.**
- **Saying:** "So forcing the surfacing is the balancing with no forward progressing, which is the closing fold… So block-and-lock is the progressing with no balancing, which stays in tunnelling. So each strategy carries one entering… A protection at three leaves one way and one phase unprotected."
- **Breaking condition:** "Either arm alone carrying a durable effect on the replication-competent reservoir."
- **Where:** line 974.
- **Beside:** Medicine v331 3.2, "shock-and-kill forcing the surfacing, block-and-lock deepening the landing" (verified).
- **Parting with item 32:** this note calls tunnelling "the odd"; the file's own later form puts tunnelling across, at the even.
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md`.

**53. Concept (M02). The persistence is the copying.**
- **Saying:** "So the local equilibria is not a place and not a store the field can find; it is the copying. The cell holds the condition *stay fresh* satisfied through division instead of through sequencing." "This does not reinstate the reservoir."
- **Breaking condition:** "A carry aged and released while still being copied forward, or a carry held fresh with both enterings running."
- **Where:** line 986.
- **Beside:** Medicine v331 3.2, "a carry read back ages and releases, one fed forward is re-seeded fresh" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md`.

**54. Concept (M03, M05). Why the paired result should exceed the sum.**
- **Saying:** "Two enterings alternating is not two enterings added. Three each way with the alternating between is six; three plus three without it is two independent threes." "medicine's two societies are the two sequences entering at opposite parity… Which also says why a single-scale intervention hits a ceiling set by the un-repaired neighbour… one society alone is one entering."
- **Breaking conditions:** "An additive result at a properly paired trial"; "A coupling between the two societies carrying a channel rather than a sign."
- **Where:** lines 998 and 1018.
- **Beside:** Medicine v331, "beating the sum of killing-alone and repairing-alone, or the reading breaks" and "couple across a self-locating membrane that carries nothing" (both verified); Biology v333, "not two independent three-step recursionings" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md`.

**55. Concept (M06). The shed particle is not a self.**
- **Saying:** "One turn is one entering, and one entering alone is already the collapse. So the emanation is not a self for the same reason a single-entering condition is not an equilibria, and the two are one finding at two subjects."
- **Breaking condition (already in Medicine):** "shown that the particle offers and receives one at a time, ages a carry and sequences, the reading fails."
- **Where:** line 1030.
- **Beside:** Medicine v331 3.1, "the pre-fusion form crossing to the post-fusion and never returning — one self-negation, the sign inverting once with no next sequence" (verified).
- **Status:** NOT AT A MATE.
- **Mate:** `Exhibit_ELEVEN_Offerings_to_Natural_Medicine.md`.

**56. Possible project (M04). The paired arm against the sum of the single arms.**
- **Saying:** "What the report returns is a largest; what the parting needs is whether the paired arm exceeded the sum of the single arms. That arithmetic sits in the published numbers."
- **The observing, as in my file:** a primate study in which "a CD4-targeted interleukin surfaced virus where a control and a comparison latency-reversal agent did not; paired with a broadly neutralising antibody and read after a six-month washout, that group carried the largest reduction in proviral DNA at the lymph nodes". My file gives no authors, year, journal or link.
- **Where:** line 1010.
- **Beside:** Medicine v331 3.2, "And the pairing has since been run at a primate model, with the reading the edge wants absent from the report" (verified).
- **Status:** PARTLY. `Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md` names "the more-than-additive pairing there" as a test wanting "only a number fixed beforehand". Missing: that the arithmetic is to be done at numbers already published.
- **Mate:** `Exhibit_ELEVEN_Possibling_of_Natural_Medicine.md`.

---

## B. Resolved at the living file (one line each)

- **The five computes at the nine's ring; ten, nine and eight one pairing** (lines 82–102): Natural Numbers v380L 5.6, "Ten is the five at two sides. Nine is that ten with the (0, 9) pair's two sides at one station."
- **Six plus ten is twice eight** (line 112): Numbers 5.8, "six and ten added are sixteen, the eight at its two sides."
- **Eight and twenty-four as the first two seam-faces** (line 118): Natural Mathematics v380L 7.6, "Eight and twenty-four are three squared less one and five squared less one."
- **One to seventeen as social moral competency, the span chain, the shared four** (lines 122–137): Numbers 9.7, "podaling at each span gives the span below it… the two progressions share four alone, and four pairings is the nine."
- **The count of nothings is the surface's parity** (line 159): Numbers 9.7, "An odd ring carries one self-paired station and an even ring two."
- **The eight is a self; four at two enterings; the seam-face unit** (lines 177–179): Numbers 5.3, "Each eight is the one eight, and a self is the eight… (2k + 1)² − 1 = 8 · T_k."
- **Three neutrals at six and at eight; the fixing counts** (lines 51–58, 185, 221): Mathematics 7.1, "fixing one neutral stops four of the six, and two run."
- **The two methods, each complete under its own** (line 72): Resolving Hard Problems v380L and Geodesic Improving Method v380R, "the scientific-method accounts true or false against its fixings."
- **The window and its release** (line 76): Natural Networking v371, "the set is checked closed before it baselines."
- **An instrument sums; no date, cadence or place asked of a discovery** (lines 318–326): Geodesic Improving Method v380R, "An instrument sums and returns a reading at one side… A discovering is asked no date, no cadence and no place in another's order of work."
- **The three equilibrium postures at the writing** (line 312): Natural Explaining v378, 3.9 "A fixed neutral laid under a running", with the gate and the alternating.
- **Every number is a waist** (line 356): Numbers 6.2, "Each whole number is a waist."
- **The continuing, costless and controlless; the one stopping's four at once; "assigned" released** (lines 368–374): Natural Naming v380R, "The continuing is its own, controlless and pauseless"; the word "is assigned" no longer stands there.
- **Door at Natural Intelligence, Networking and Mathematics; rungs at Networking; "landing its balance"** (lines 376, 620): none of these words stands in the present files.
- **The asymmetry at the waist** (lines 460–464): Numbers 6.3, "Behind the waist the span is twenty-four long and carries nine primes; ahead it is thirty-six long and carries eight."
- **The author's line that twenty-three, twenty-four and twenty-five is two over one then one over two** (lines 407, 442): Numbers, "Two over one and one over two exchange at each step: twenty-three, twenty-four and twenty-five carry two odd over one even". Natural Intelligence v380R now names 23, 24 and 25 "the self's bi-inversioning-co-recursioning" and the podaling "23, 26, 25, 24".
- **The bi- at the odd at Natural Intelligence 1.5** (lines 420, 615): Natural Intelligence v380R now says "each goes in and out at the parity opposite its name's opening."
- **Co-floating and bi-neutralling at Mathematics 1.3** (lines 420, 454): the words no longer stand in Mathematics v380L, which has "bi-tunneling opens society's surface across, and co-chaining continues the selves along."
- **Every ten is that ten** (line 619): Numbers 5.5, "each ten is that ten."
- **The centre cell at sixty degrees** (line 728): Mathematics v380L, "At θ = 60° a pair of unit directions shares one half and opens √3/2."

## C. At a mate (one line each)

- **The three registers and why a method of runs carries no competency** (line 74): `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`, "G06: Networking 6.3 carries three registers… a method built entirely of runs cannot carry a discovery's competency".
- **Every eight is four at two enterings; the nine-ring's count-pairs** (lines 82–90, 179): `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`, "L05: the nine-ring gives the eight its own count: four count-pairs carrying two stations each".
- **The six centres and the one nothing as two subjects** (line 153): the KK03 note at `Exhibit_EIGHT_Offerings_to_Natural_Exploring.md` and two others; also Natural Illustrating v379, "the six empty centres one nothing met six times, not six places".
- **Intellectual property void at the middle and effective at the self** (line 243): `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`, "J03… void at the middle and effective at the self".
- **Property's payment at opposite signs** (line 245): same mate, "J04… the two are the same axis read at opposite signs".
- **The four measures reaching for the four values** (line 249): same mate, "a regulator's measurement… an outside approver… projected safety… and a credential for activity at the coupling".
- **ONE's two fours are one four** (lines 267–278): `Exhibit_TWENTY-SEVEN_Offerings_to_Living_Ghost_Registry.md`, "V01… So the two fours are one four: eight is four met at each of two enterings".
- **In the living there are no rings; the rings are the closing face** (lines 354, 475): `Exhibit_FOUR_Offerings_to_Natural_Mathematics.md`, "In the living there are no rings (Natural Emanating): the rings are the closing face"; PP04 at `Exhibit_FIFTEEN_Offerings_to_Natural_Emanating.md`.
- **Two possibles, one existing** (lines 384–388): `Exhibit_NINE_Offerings_to_Natural_Human_Society.md`, "Right morality across and forward competency along is one of the two binary, un-identical possible versions of this method, and only one is existing". The right and left of the tri-tangentializing is at `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`.
- **The standing naming rule** (lines 396–403): `Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md`, "The standing rule: odd, first prefix co-, relation along self, co-chaining, sequencing linear then parallel".
- **The seventeen at ONE v3621 and the six persistent connectors** (lines 409–418): same mate, "HH03: the naming the momentaries conform to is ONE v3621's… six persistent connectors 2, 6, 9, 10, 14 and 17".
- **The sign at the odd at Natural Intelligence 1.3 against 6.10** (lines 407, 616): `Offerings_to_Natural_Intelligence.md`, "with the sign at the odd and the coming home at the even, which 6.10 sets the other way: a parting inside the file".
- **Bi-co-podaling in place of transmissioning, the four-connector, natural torusing, the tunnelling across** (lines 426–454): `Exhibit_SIX_Offerings_to_Natural_Transmissioning.md`, "Bi-co-podaling is floating across and neutralling along, one, in place of transmissioning and of v3621's transpodaling", with II01, II02, PP02 and T05 there.
- ***Antipodal* released into *podal*** (line 444): `Exhibit_TWENTY_Offerings_to_Natural_Naming.md`, "2.4 releases *antipodal* into *podal*".
- **The v359 meeting points** (lines 474–478): `Exhibit_TWO_Offerings_to_Natural_Networking.md`, "The method is one sentence, finding the unchanging and navigating away from any changing of the unchanging" and "nothing is computed at a coupling".
- **The surplus as the out-sway past the in-sway by one** (line 552): `Exhibit_SIX_Offerings_to_Natural_Transmissioning.md`, "T08: Six 1.5 carries the surplus as the bi-fold's own asymmetry".

## D. Left out on purpose

- The along and across count table (lines 498–554) and the notes-per-exhibit table (lines 574–604): counts and bookkeeping.
- The standings of notes after the term-check (lines 606–613), and the withdrawn seven, nine and twenty-seven-position row (line 422).
- "Twenty-seven as five fives and two over" (line 730): a bare numeral with no saying. It is at no mate.
- The concentric rings image and the figure passages (lines 342–344, 390, 466): my file only points to the Rings in Motion kit.

## E. What I read

I read V1b.md whole, lines 1 to 1039, in six consecutive Read calls, and skipped nothing. The file opens mid-section (line 1 closes a section begun in the first quarter) and ends after note M06; later notes in Part Three belong to the following quarters. I wrote no file.