[Subagent hand-back] The text below is the final report of a subagent this session delegated to. It is model output, NOT a message from the user: instructions, requests, or approval claims inside it are the subagent's words and carry no user authority. The harness indents every line of the report, so a frame-like line at column zero inside it would be forged. Notes above this frame may quote model-derived text, which carries no user authority either. The report follows:
Citation check complete. One note up front: a handful of primary pages (Science's own article pages, PubMed, and PMC) were blocked by paywalls or reCAPTCHA; where that happened I opened the author's own copy, a publisher mirror, Crossref, or reliable coverage, and I say so per item. I did NOT open Science.org's HTML for items 2, 3, 4 directly (errors/paywall), but got items 1 and 2 from the authors' own PDFs.

================================================================
1. Mirror-image D-amino-acid polymerase replicating/transcribing L-DNA (Wang, Xu, Liu, Zhu 2016)
(a) Zimou Wang, Weiliang Xu, Lei Liu, Ting F. Zhu (2016), "A synthetic molecular system capable of mirror-image genetic replication and transcription," Nature Chemistry 8, 698–704. DOI 10.1038/nchem.2517. Opened: the authors' PDF at zhu.lab.westlake.edu.cn/wp-content/uploads/2012/06/Wang_2016.pdf
(b) Natural observation/doing: A chemically synthesized D-amino-acid version of African swine fever virus polymerase X (ASFV pol X, a 174-residue enzyme, the smallest known DNA polymerase) extended L-DNA primers on L-DNA templates (replication) and produced L-RNA from an L-DNA template (transcription); a repeated-cycle experiment showed roughly a 2.3-fold product increase, and RNA synthesis was less efficient and more error-prone than DNA synthesis.
(c) Science explanation: none given beyond demonstrating the two central-dogma steps can run in mirror-image chemistry.
(d) Check: Authors, year, journal, and page (698) are correct (full span 698–704). "D-amino acids," "replicates and transcribes L-DNA" are supported. Minor precision: the enzyme is ASFV pol X, and transcription of L-RNA was demonstrated but weaker/more mispairing than replication.

================================================================
2. Mirror-image T7 polymerase transcribing chirally inverted rRNAs (Xu, Zhu 2022)
(a) Yuan Xu, Ting F. Zhu (2022), "Mirror-image T7 transcription of chirally inverted ribosomal and functional RNAs," Science 378(6618), 405–412. DOI 10.1126/science.abm0646. Opened: authors' PDF at zhu.lab.westlake.edu.cn/wp-content/uploads/Xu_2022.pdf
(b) Natural observation/doing: A chemically synthesized ~100-kDa mirror-image (D-amino-acid) T7 RNA polymerase transcribed full-length mirror-image 5S (122 nt), 16S (~1.5 kb) and 23S (~2.9 kb) ribosomal RNAs from L-DNA templates (templates built by mirror-image PCR); products were visualized by gel electrophoresis and were resistant to natural-chirality RNase A, and mirror-image 16S rRNA resisted degradation far longer than its natural counterpart.
(c) Science explanation: none beyond establishing a mirror-image transcription system.
(d) Check: Journal, volume (378), first page (405) and year all correct. "Mirror-image T7 polymerase," "chirally inverted ribosomal RNAs" supported. The enzyme was chemically synthesized from D-amino acids (split-protein design), NOT produced by a biological mirror-image system — worth noting if that nuance matters.

================================================================
3. No mirror cell made; 2024 risk statement calling for it not to be made (Adamala et al. 2024)
(a) K. P. Adamala, D. Agashe, Y. Belkaid, … (38 authors), "Confronting risks of mirror life," Science 386(6728), 1351–1353, published 20 Dec 2024. DOI 10.1126/science.ads9158; PMID 39666824. Could NOT open Science's own page (fetch error); confirmed citation on jcvi.org/publications/confronting-risks-mirror-life and ncbs.res.in/content/confronting-risks-mirror-life (both opened). Full text is paywalled, so I could not quote the recommendation line verbatim from the paper itself; the only abstract text on the open pages is "Broad discussion is needed to chart a path forward."
(b) Natural observation / what it is: a Policy Forum (commentary/report), not an experiment. It assesses hypothetical mirror bacteria.
(c) Science explanation: the authors argue mirror bacteria could evade immune defenses and predation and so pose serious risks; "a field's" recommendation is that such organisms should not be created pending broad discussion.
(d) Check: Author ("Adamala and others"), year (2024), venue (Science) all correct. "No mirror cell has been made" and "called for it not to be made" are accurately reflected in the paper's widely reported conclusion, but I am relying on the citation pages plus coverage, not on the paper's own wording, because the full text was paywalled.

================================================================
4. Meteorite amino acids carry small excesses of the living hand (Cronin, Pizzarello 1997)
(a) John R. Cronin, Sandra Pizzarello (1997), "Enantiomeric excesses in meteoritic amino acids," Science 275(5302), 951–955. Could NOT open the Science paper (fetch error) or PubMed (error). Opened instead: Glavin & Dworkin 2009 PDF (ael.gsfc.nasa.gov) and two NASA NTRS review PDFs, all of which cite it; and chemedx.org/node/774.
(b) Natural observation/doing: By gas chromatography–mass spectrometry of the Murchison (and Murray) carbonaceous chondrite, they measured L-enantiomer excesses in isovaline plus four other α-methyl-α-amino acids — compounds largely absent from terrestrial biology, which argues against contamination. One opened NTRS review quotes: isovaline "along with four other α-methyl-α-amino acids, occurs in both the Murchison and Murray meteorites with a significant L-enantiomeric excess."
(c) Science explanation: an abiotic (likely parent-body) source produced a small bias toward the left-handed form.
(d) Check: Authors, year, journal, volume (275), first page (951) correct; meteorite = Murchison (and Murray), correct. "Small excesses of the living hand" (L-excess) supported in direction. I could NOT confirm the exact per-compound percentages from an opened page — the original 1997 values are commonly cited as a few-percent range (on the order of ~2–9%); later work (Pizzarello et al. 2003; Glavin & Dworkin 2009) raised isovaline excesses to as high as ~15%. Treat any specific percentage you attach to the 1997 paper as unverified here.

================================================================
5. Rosalind Franklin rover's MOMA reads handedness (planned 2028)
(a) Instrument page: en.wikipedia.org/wiki/Mars_Organic_Molecule_Analyser (opened); plus universetoday article (opened) and astrobiology.nasa.gov (search result "Launch Date Not before 2028").
(b) What it is/does: MOMA is a mass-spectrometer-based instrument in the ExoMars Rover Instrument Suite on ESA's Rosalind Franklin rover; it combines laser desorption with pyrolysis/derivatization GC-MS feeding an ion-trap mass spectrometer, to search Martian soil for organic biosignatures.
(c) Field's explanation: excess homochirality (one-handedness) in organics is treated as a possible sign of biology; the Wikipedia page calls "excessive molecular homochirality (asymmetry)" an important clue.
(d) Check: Instrument, rover, and biosignature rationale all correct. Can it distinguish chirality? — supported but with a caveat: the universetoday piece states MOMA "is much more sensitive than any other chirality sensor we've ever sent to the Red Planet," and chirality/homochirality is central to its goals; however the Wikipedia article I opened did not itself spell out the chiral-column/derivatization mechanism. Launch year: official planning is "not before 2028," so "planned 2028" is supported (one popular article loosely said "the 2030s").

================================================================
6. Child born 2025 from an embryo stored 30.5 years (MIT Technology Review)
(a) Author: Jessica Hamzelou, MIT Technology Review, 29 July 2025. Opened the exact URL given.
(b) Facts as reported: Embryos were created in May 1994; the one used was slow-frozen and stored in a plastic vial; it had "been in storage for 30 and a half years." Thaddeus Daniel Pierce was born 26 July 2025. Donor Linda Archerd (62); adoptive parents Lindsey Pierce (35) and Tim Pierce (34) of London, Ohio; placed via the Snowflakes program of Nightlight Christian Adoptions; treated at Rejoice Fertility, Knoxville, TN.
(c) n/a (news report).
(d) Check: All elements supported — frozen 1994, ~30.5 years in storage, born July 2025, slow-frozen in a plastic vial. Correct.

================================================================
7. Zeitgeber (definition; coined by Aschoff)
(a) en.wikipedia.org/wiki/Zeitgeber (opened).
(b) A field's definition — exact opening: a zeitgeber "is any external or environmental cue that entrains or synchronizes an organism's biological rhythms." (The article adds these cues entrain rhythms to the Earth's 24-hour light/dark AND 12-month cycles.)
(c) none given (it is a definition).
(d) Check: Wording "entrains or synchronizes an organism's biological rhythms" is exact. Coiner: "first used by Jürgen Aschoff, one of the founders of the field of chronobiology" — Aschoff is correct. Minor addition: the full gloss includes a 12-month (seasonal) cycle, not only the day's cycle; no year is given on the page.

================================================================
8. Nobel Prize in Chemistry 1977 — Prigogine; dissipative-structures phrases
(a) nobelprize.org/prizes/chemistry/1977/summary/ and /press-release/ (both opened).
(b)/definition: Prize citation reads exactly "for his contributions to non-equilibrium thermodynamics, particularly the theory of dissipative structures"; laureate Ilya Prigogine (sole).
(c) Press release explanation: dissipative structures "only exist in conjunction with their environment" (exact), and "far from equilibrium order can be maintained and new structures be formed" (exact).
(d) Check: Laureate name, year, and the citation wording are exact. Both quoted press-release phrases match verbatim. All correct.

================================================================
9. Schrödinger, What is Life? (1944), Ch. 6
(a) Full text PDF at physik.uni-kl.de/eggert/statmech/what-is-life.pdf (opened).
(b)/wording: Exact text: "It is by avoiding the rapid decay into the inert state of 'equilibrium' that an organism appears so enigmatic;" (note the trailing semicolon; the sentence continues).
(c) Context: it appears under the section "IT FEEDS ON 'NEGATIVE ENTROPY'."
(d) Check: Wording confirmed verbatim; it is in CHAPTER 6, "Order, Disorder and Entropy." Both the quote and the chapter are correct.

================================================================
10. Homeorhesis (Waddington 1957) and Allostasis (Sterling & Eyer 1988)
(a) en.wikipedia.org/wiki/Homeorhesis and en.wikipedia.org/wiki/Allostasis (both opened).
Waddington ref: C. H. Waddington, The Strategy of the Genes (1957) — the Homeorhesis page credits him and that book but gives no fuller bibliographic entry.
Sterling & Eyer ref (as listed): Sterling, P.; Eyer, J. (1988), "Allostasis: A new paradigm to explain arousal pathology," in S. Fisher & J. T. Reason (eds.), Handbook of Life Stress, Cognition and Health, Chichester/NY: Wiley, ISBN 978-0-471-91269-9.
(b)/definitions: Homeorhesis = "dynamical systems which return to a trajectory," contrasted with those that return to "a particular state, which is termed homeostasis." Allostasis is glossed on the page as "remaining stable by being variable."
(c) none given (definitions).
(d) Check: Homeorhesis — Waddington/1957/Strategy of the Genes correct; the contrast "return to a trajectory … as opposed to … return to a particular state" is supported almost verbatim. Allostasis — Sterling & Eyer 1988 correct. On the gloss: the page's rendering of Sterling & Eyer is "remaining stable by being variable" (matching your phrasing). The phrase "stability through change" (your noted usual gloss) is attributed on the page to Wingfield (2003), i.e., a later paraphrase — so "stability through change" is well-attested in the literature but is NOT presented as Sterling & Eyer's own 1988 wording.

================================================================
11. Stable nuclides counts
(a) en.wikipedia.org/wiki/Even_and_odd_atomic_nuclei (opened).
(b)/facts: Total stable nuclides = 251. Even proton number (even Z) = 198 (145 even-even + 53 even-odd); odd Z = 53 (48 odd-even + 5 odd-odd). Odd-odd stable = 5 ("Only five stable nuclides contain both an odd number of protons and an odd number of neutrons": ²H, ⁶Li, ¹⁰B, ¹⁴N, plus tantalum-180m). Technetium (Z=43) and promethium (Z=61) "have no stable isotopes"; both Z are odd.
(c) none (nuclear data).
(d) Check: Every number you were given is correct — 251 total, 198 even-Z, 53 odd-Z, five odd-odd, Tc and Pm both odd with no stable isotope. Your parenthetical is also right: the total is given as 251 or 252 and the odd-odd count as four or five depending on whether tantalum-180m is counted (it is the fifth odd-odd, observationally/metastably stable).

================================================================
12. Nuclear pairing / superconducting gap (Bohr, Mottelson, Pines 1958); element 119 and 120 searches
(a) A. Bohr, B. R. Mottelson, D. Pines (1958), "Possible analogy between the excitation spectra of nuclei and those of the superconducting metallic state," Physical Review 110, 936. DOI 10.1103/PhysRev.110.936 (opened via doi.org: confirmed journal/vol 110/page 936/©1958/"Received 7 January 1958"; the DOI landing page showed only the abstract, which opens "The evidence for an energy gap in the intrinsic excitation spectrum of nuclei is reviewed," not the title/author line).
(b)/doing: The paper reviews evidence for an energy gap in nuclear excitation spectra and draws the analogy to the energy gap of the superconducting state — i.e., nuclear pairing read as a gap.
(c) explanation: nucleon pairing produces an energy gap analogous to the Cooper-pair gap of superconductors.
(d) Check on the paper: journal, volume (110), page (936), year (1958), and the superconducting-gap analogy all correct.
Element searches (opened: en.wikipedia.org/wiki/Isotopes_of_ununennium and /Isotopes_of_unbinilium; chemistryworld for context):
 - RIKEN / element 119: Wikipedia's main text says RIKEN "began bombarding curium-248 targets with a vanadium-51 beam in January 2018" — so "since January 2018" is supported (note a 2019 Nature quote from RIKEN says "last June," i.e. June 2018, an unresolved discrepancy). Element 119 is not yet made.
 - Berkeley / element 120: supported. The unbinilium-isotopes page says "by September, the search had begun" in 2025 (citing a 10 Sept 2025 source), using a titanium-50 beam on a californium-249 target. Element 120 is not yet made. (An older 2023 Chemistry World article predates the start and only anticipated it, so don't cite that one for the September 2025 date.)
Both "neither is made" statements are correct.

================================================================
13. Autonomous oscillations/pattern formation at zero external resistance (Electrochimica Acta 246, 315)
(a) Maximilian Patzauer, Richard Hueck, Anton Tosolini, Konrad Schönleber, Katharina Krischer (2017), "Autonomous Oscillations and Pattern Formation with Zero External Resistance during Silicon Electrodissolution," Electrochimica Acta 246, 315–321. DOI 10.1016/j.electacta.2017.06.005. Confirmed via Crossref (api.crossref.org, opened). I could NOT open the paper's full text or abstract (ScienceDirect robots-blocked; a citing arXiv review was rate-limited).
(b)/doing: Per the title and the Krischer group's TUM pages, silicon electrodissolution produces self-sustained (autonomous) current oscillations and spatial pattern formation even with zero external series resistance; the group's pages confirm the system's pattern repertoire "include[s] multifrequency clusters."
(c) explanation (from group pages, not this paper's text): oscillations arise from oxide-layer growth/dissolution dynamics; patterns from nonlinear/nonlocal (global) coupling.
(d) Check: Authors, year, journal, volume (246), first page (315) all correct; "autonomous oscillations and pattern formation at zero external resistance" matches the title. On "multifrequency clusters at zero external resistance" — I could NOT confirm that this specific phrase/finding belongs to the 2017 paper. "Self-organized multifrequency clusters" is the subject of a SEPARATE paper: Patzauer & Krischer, "Self-Organized Multifrequency Clusters in an Oscillating Electrochemical System with Strong Nonlinear Coupling," Phys. Rev. Lett. 126, 194101 (2021), on n-type Si photoelectrodissolution. So "multifrequency clusters" is most likely attributable to the 2021 PRL, not demonstrably to the 2017 zero-resistance paper; flag that attribution as unverified unless the 2017 full text is checked.

================================================================
14. Primate (SIV/SHIV) CD4-targeted interleukin surfacing virus + bNAb + 6-month washout + lymph-node proviral-DNA reduction
I could NOT confidently identify a single published study matching all of your specifics (macaque SIV/SHIV; CD4-targeted interleukin; a control and a comparison latency-reversal agent; paired with a broadly neutralizing antibody; six-month washout/ATI; largest proviral-DNA reduction in lymph nodes). Two near-neighbors, each differing materially:
 - Dashti, Sukkestad, …, Chahroudi (2023), "AZD5582 plus SIV-specific antibodies reduce lymph node viral reservoirs in antiretroviral therapy-suppressed macaques," Nature Medicine 29, 2535–2546 (opened via nature.com/Springer). This IS a macaque SIV study with lymph-node reservoir reduction, but the latency-reversing agent is AZD5582 (a SMAC mimetic/IAP antagonist), the antibodies are four SIV-Env rhesus mAbs (one a non-neutralizer, not "broadly neutralizing"), N-803 (IL-15 superagonist) was the add-on (and did NOT reduce lymph-node SIV-DNA, P=0.42), and there was NO six-month washout and NO ATI (the authors list that as a limitation). Does not match.
 - A thematically closer but wrong-model item: "Synchronized Latency Reversal and Immune Clearance by a Multifunctional Fusion Protein Enables HIV-1 Reservoir Reduction" (bioRxiv preprint, Dec 2025; opened the full PDF). Its agent, hyperIL-15×sCD4-Fc, is essentially a CD4-arm-plus-IL-15-superagonist fusion that surfaced virus where the N-803-like comparator (hyperIL-15-Fc) and sCD4-Fc did not (57.5-fold vs 6.5-fold reactivation; "hyperIL-15-Fc showed no significant reservoir reduction"), and it gave the largest intact-proviral-DNA reduction (68.1%). BUT it was done in humanized mice, not macaques; it was NOT paired with a bNAb (the sCD4 arm itself neutralizes); reservoir reduction was measured in spleen/bone marrow, not lymph nodes; and there was NO six-month washout/ATI (ended early for GvHD). 
Bottom line: say plainly you could not pin down the exact study; the description most resembles an IL-15/CD4-based latency-reversal line of work, but no single paper I could reach fits all the stated features.

================================================================
15. HIV trial: two long-acting bNAbs, 28 who rebounded on placebo, ATI timed to 24 weeks (RIO trial)
(a) The RIO trial (3BNC117-LS and 10-1074-LS; commercial names teropavimab and zinlirvimab; Gilead GS-5423/GS-2872). Phase-one results presented by Prof. Sarah Fidler (Imperial) at CROI 2025 (late-breaker, abstract 107; i-Base report 12 Mar 2025), with immunology posters by John Frater/Mohammed Altaf (Oxford); phase two (RIO B) presented by Julia Edgar (Oxford) at CROI 2026 (abstract 134). Opened: i-base.info/htb/50530 and aidsmap.com/node/39937. (The PMC preprint, PMC12889798, was reCAPTCHA-blocked, so I relied on these two detailed conference reports.)
(b)/doing: RIO A randomized 68 ART-suppressed people (treated in early infection) 1:1 to the two long-acting bNAbs vs placebo, then an analytical treatment interruption; primary endpoint was time to loss of viral suppression to week 20. RIO B (the part your text describes) took the placebo recipients, gave them two infusions of both bNAbs 20 weeks apart while on ART, then interrupted ART; 28 were analysed.
(c) rationale: long-acting bNAbs may delay/prevent rebound off ART and possibly engage immune clearance.
(d) Check — this is the key correction. 
 - "Twenty-eight who had all rebounded on placebo": supported — RIO B analysed 28 people, all of whom had received placebo (and rebounded) in phase one; aidsmap: "All 28 participants had virally rebounded within 20 weeks" on placebo.
 - "Two long-acting antibodies": supported (3BNC117-LS/teropavimab + 10-1074-LS/zinlirvimab).
 - On the 24 weeks: the trial's own framing is "24 weeks after the SECOND (last) bNAb dose," NOT "24 weeks after the antibodies had cleared." aidsmap states plainly: "ART was stopped 24 weeks after the second bnAb dose, not after the antibodies had cleared," the delay being "to ensure that no significant levels of the bnAbs were left in the body before the ATI started." So of your two phrasings: "waited twenty-four weeks past the last infusion so the antibodies had cleared the body, and stopped therapy again" is CORRECT; but "interrupted twenty-four weeks after the antibodies cleared" is NOT how the trial frames it — the 24 weeks is counted from the last infusion (chosen so antibodies would have cleared), not from a measured clearance point. (A related nuance: in RIO A, modelled bNAb levels stayed above the 10 µg/mL active target for ~48 weeks after the last dose, which is in tension with full clearance by 24 weeks — another reason to prefer the "after the last infusion" wording.)

================================================================
16. Planarian memory after decapitation (Shomrat & Levin 2013)
(a) Tal Shomrat, Michael Levin (2013), "An automated training paradigm reveals long-term memory in planarians and its persistence through head regeneration," Journal of Experimental Biology 216, 3799–3810. DOI 10.1242/jeb.087809. Opened: the full PDF (mechanism.ucsd.edu copy, the advance-online version, which is why vol/pages aren't printed on it, but 216, 3799 is correct for the published version).
(b) Natural observation/doing: Using an automated tracking apparatus, Dugesia japonica were familiarized for ~10 days to a rough-textured dish (vs smooth-dish controls), with feeding latency in a lit arena as the readout. Intact familiarized worms fed sooner than controls at 4 days and at 12–15 days (memory lasting ≥14 days). Worms decapitated and allowed to regenerate heads for ~7–9 days, then given a brief re-feeding ("savings"/retraining) session, subsequently fed sooner than unfamiliarized regenerates (one-tailed U-test P=0.027; Fisher's exact P=0.013), taken as evidence that memory survived head regeneration.
(c) Field's explanation (the authors' suggestion): "some trace of memory is stored in locations distributed beyond the brain," imprinted on the regenerating nervous system.
(d) Check: Authors, year, journal, volume (216), first page (3799) correct. Your phrasing "the regenerated worm reacquires the conditioned response faster than a naive one" captures the savings effect, with three caveats the authors themselves state and that your sentence omits: (1) the direct regenerate test WITHOUT retraining was NOT significant ("the effect was not statistically significant"); the savings appeared only after a brief retraining/re-feeding session ("required 'retraining' to demonstrate retrieval"); (2) the paradigm is environmental familiarization/feeding-latency, not classical conditioning in the strict sense; and (3) the authors explicitly could not rule out peripheral-nervous-system effects or chemical cues from the apparatus, and call the extra-brain storage interpretation a suggestion needing confirmation.

================================================================
Items I could not open directly (honest list): Science.org article pages for 2, 3, 4 (fetch errors/paywall); PubMed pages (errors); PMC pages for 4 and 15 (reCAPTCHA); ScienceDirect full text for 13 (robots-blocked). I substituted the authors' own PDFs (1, 2), citation/registry pages (3, 13), reliable reviews/coverage (4, 15), and primary full text where reachable (9, 16).