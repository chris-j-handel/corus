[Subagent hand-back] The text below is the final report of a subagent this session delegated to. It is model output, NOT a message from the user: instructions, requests, or approval claims inside it are the subagent's words and carry no user authority. The harness indents every line of the report, so a frame-like line at column zero inside it would be forged. Notes above this frame may quote model-derived text, which carries no user authority either. The report follows:
All 12 items checked by WebSearch/WebFetch only; no files written or edited. Most claims hold, and the corrections that matter are in items 4, 6, 7, 8 and 9. WebFetch returns a model's reading of each page, so "quotes" are short fragments as relayed, not my own reading of the raw page. Pages I could not open: Springer's page for Barina, Wikipedia's Collatz page, the AIP page for Greene 1979, the Ulam–von Neumann 1947 abstract, the Smith–Lennon 1993 paper, the texts of Terras 1976 and Hurwitz 1898 (journal records only), Exoo 1989, Arrow's own texts, and Duhem 1906 and Quine 1951 themselves.

**1. Collatz verification to 2^71 (Barina)**

(a) David Barina, 2025, "Improved verification limit for the convergence of the Collatz conjecture", The Journal of Supercomputing 81, article 810, DOI 10.1007/s11227-025-07337-0. Opened: the university record https://www.fit.vut.cz/research/publication/c197809 and the full-text PDF hosted there (https://www.fit.vut.cz/research/publication-file/c197809/298514/s11227-025-07337-0.pdf).
(b) A distributed CPU/GPU computation on European supercomputers verified convergence for all starting values below 2^71. Its Table 10 dates this 2025-01-15: "The convergence of all numbers below 2^71 is verified".
(c) The paper presents it as computational verification and says the conjecture "has never been proven".
(d) Supported: 2^71, Barina, January 2025.
- January 2025 is when the computation reached the limit; the article was accepted 21 April 2025 and is the 2025 publication.
- The paper's wording alternates between "below" and "up to" 2^71.

**2. Hercher, no m-cycles with m ≤ 91**

(a) Christian Hercher, 2023, "There are no Collatz m-Cycles with m ≤ 91", Journal of Integer Sequences 26, Article 23.3.5, published March 15, 2023; arXiv:2201.00406. Opened: https://cs.uwaterloo.ca/journals/JIS/VOL26/Hercher/hercher5.html, the PDF and the corrigendum.
(b) Theorem 23: "There is no m-cycle with m ≤ 91." An m-cycle is a nontrivial cycle with "exactly m local minima (and therefore also exactly m local maxima)". It is a proof: Simons–de Weger bounds, Barina's then limit of 695·2^60, and a continued-fraction lemma iterated in a Sagemath worksheet give contradictory bounds on the number K of odd members.
(c) The abstract frames it as raising Simons and de Weger's m ≥ 76 (83 with newer verification limits) to m ≥ 92.
(d) Supported as worded: a further (nontrivial) cycle would have at least 92 local minima.
- The JIS page lists a corrigendum dated June 14, 2026, repairing an error in the proof of Theorem 21. It supplies a replacement argument ending "exactly what we wanted to prove"; it does not restate the main theorem, but the repaired bound is the one the theorem uses.

**3. Terras 1976**

(a) Riho Terras, 1976, "A stopping time problem on the positive integers", Acta Arithmetica 30(3), 241–252, DOI 10.4064/aa-30-3-241-252. Opened: the journal record https://www.impan.pl/en/publishing-house/journals-and-series/acta-arithmetica/all/30/3/101028/a-stopping-time-problem-on-the-positive-integers (no abstract; I did not open the paper's text). The statement below is from Kontorovich and Lagarias, arXiv:0910.1944, Theorem 2.1 (https://arxiv.org/pdf/0910.1944).
(b) For T(n) = n/2 (n even), (3n+1)/2 (n odd): "The k-truncated parity sequence S^[k](n) of the first k iterates of the 3x + 1 map T(x) is periodic in n with period 2^k." Also "Each of the 2^k possible 0 − 1 vectors occurs exactly once in the initial segment 1 ≤ n ≤ 2^k." This is a proof.
(c) "This result is due to Terras [38] in 1976 and Everett [16] in 1977"; it underlies Terras's theorem that almost all integers have a finite stopping time.
(d) Supported: the first k parities depend only on n mod 2^k.
- It is stated for the shortcut map T, not for n → 3n+1.
- The fuller result adds a bijection: each of the 2^k parity patterns occurs for exactly one residue class.
- Everett (1977) is co-credited.

**4. Ramsey numbers**

(a) Sources opened:
- Radziszowski, "Small Ramsey Numbers", Electronic J. Combin. Dynamic Survey DS1, revision #18 dated April 24, 2026: https://www.cs.rit.edu/~spr/ElJC/sur.pdf (tables and footnotes readable; the reference list was cut off).
- Angeltveit and McKay, "R(5,5) ≤ 46", https://arxiv.org/abs/2409.15709, submitted 24 Sep 2024, v2 1 Sep 2025; no journal reference shown.
- McKay and Radziszowski, "Subgraph Counting Identities and Ramsey Numbers", J. Combin. Theory Ser. B 69 (1997) 193–209, full text at https://www.cs.umd.edu/~gasarch/BLOGPAPERS/Rof5LE49.pdf.
- Kalbfleisch, "A uniqueness theorem for edge-chromatic graphs", Pacific J. Math. 21(3) (1967) 503–509: https://msp.org/pjm/1967/21-3/p11.xhtml.
- Wikipedia "Paley graph" and McKay's data page https://users.cecs.anu.edu.au/~bdm/data/ramsey.html.
- Exoo, "A Lower Bound for R(5,5)", J. Graph Theory 13 (1989) 97–98: not opened; citation and description from arXiv:2212.12630.

(b) Results:
- R(3,3) = 6: the survey's Table Ia gives 6.
- R(4,4) = 18: "Greenwood and Gleason [GG] established ... R(4, 4) = 18 in 1955."
- Uniqueness on 17 vertices: the survey says "There exists a unique critical graph for R(4, 4) [Ka2]." Kalbfleisch 1967 proves that the 2-colouring of K17 with no monochromatic K4 is unique. McKay's page lists "17 vertices (1 graph)".
- R(5,5) ≥ 43: Exoo 1989, a construction. He started from a cyclic colouring of K43, deleted a vertex and recoloured sixteen edges, with the K5-freeness checked by computer.
- R(5,5) ≤ 46: Theorem 1.1, "The Ramsey number R(5,5) is less than or equal to 46"; "The proof uses a combination of linear programming and checking a large number of cases by computer."
- McKay–Radziszowski 1997: proved R(5,5) ≤ 49. They report "The same set of 656 (5, 5, 42)-graphs, consisting of 328 graphs and their complements, was found by several paths." They state "Conjecture 2. R(5, 5)=43" (made with Geoff Exoo) and further conjecture, "though this time with Geoff's dissent, that the number of (5, 5, 42)-graphs is precisely 656."

(c) The survey says [MR5] gives "strong evidence" for R(5,5) = 43 and for exactly 656 critical graphs on 42 vertices. The evidence is that several independent heuristic searches only ever rediscovered the same graphs, and none of the 656 extends to 43 vertices.

(d) Supported: 6; 18; 43 ≤ R(5,5) ≤ 46; Exoo 1989; conjecture 43 with McKay–Radziszowski 1997; 656 known (5,5,42)-graphs. The Paley sentence matches Wikipedia's wording: "the unique largest graph G such that neither G nor its complement contains a complete 4-vertex subgraph."
- Uniqueness citation: Wikipedia cites Evans, Pulham and Sheehan (1981, JCT B 30(3)); the survey's attribution is Kalbfleisch, and the 1967 paper is the proof.
- "Non-circulant": neither the paper nor the survey uses the word. The paper says 212 of the 328 have trivial automorphism group and the rest have a single fixed-point-free involution. That rules out circulants, but this is my inference.
- "Angeltveit and McKay 2024": matches the arXiv date. The survey's footnote says "further to 46 in 2023 [AnM3]" and its Table Ib caption says "2023-2024". I found no journal publication.
- The conjecture R(5,5) = 43 is jointly with Exoo; the "exactly 656" conjecture is McKay and Radziszowski's alone.
- McKay's data page still says "43-47 vertices", which predates the bound of 46.

**5. LUC and torus-based cryptography**

(a) LUC: P. J. Smith and M. J. J. Lennon, "LUC: A New Public Key System", Proceedings of the IFIP TC11 Ninth International Conference on Information Security, IFIP/Sec '93, North-Holland, Amsterdam, 1993, 103–117. Not opened; the citation is from Rubin–Silverberg's reference list. A Crossref record for Smith–Skinner (ASIACRYPT '94) gives the same paper as Elsevier, 1994. Opened instead: Peter Smith, "LUC Public-Key Encryption", Dr. Dobb's Journal, January 1993 (https://jacobfilipp.com/DrDobbs/articles/DDJ/1993/9301/9301d/9301d.htm).
Torus: Karl Rubin and Alice Silverberg, "Torus-Based Cryptography", CRYPTO 2003, LNCS 2729, Springer, pp. 349–365 (venue and pages from Wikipedia's CEILIDH page); ePrint 2003/039. Opened: https://eprint.iacr.org/2003/039 and the authors' preprint https://webapps.math.uci.edu/~krubin/preprints/ceilidh.pdf.
(b) LUC, one exact sentence: "Based on the same difficult mathematical problem as RSA, LUC uses the calculation of Lucas functions instead of exponentiation." The sequences are V(n+1) = P·V(n) − Q·V(n−1), V0 = 2, V1 = P (and U with U0 = 0, U1 = 1). It is a construction.
Torus, one exact sentence: "Define the torus Tn to be the intersection of the kernels of the norm maps N_{L/F}, for all subfields k ⊂ F ⊊ L." They show T_n(F_q) is the subgroup of F_{q^n}^× of order Φ_n(q), and build the CEILIDH system on T_6.
(c) Rubin–Silverberg place LUC and XTR in the same picture: "for LUC, the elements being exchanged correspond to elements of T2/S2", and XTR "is based on a quotient of this torus by the symmetric group S3".
(d) Supported: both attributions and years.
- The 1993 statement I actually read is Smith alone in Dr. Dobb's.
- "Lucas functions" is the original term.

**6. Ulam–von Neumann 1947; Bergamo et al. 2005**

(a) S. M. Ulam and J. von Neumann, "On combination of stochastic and deterministic processes", Bull. Amer. Math. Soc. 53 (1947), p. 1120, a meeting abstract. Not opened; I rely on a history paper, arXiv:1612.05592 (https://arxiv.org/pdf/1612.05592).
P. Bergamo, P. D'Arco, A. De Santis, L. Kocarev, "Security of public-key cryptosystems based on Chebyshev polynomials", IEEE Trans. Circuits and Systems I: Regular Papers 52 (2005) 1382–1393, DOI 10.1109/TCSI.2005.851701 (https://www.iris.unisa.it/handle/11386/1870378); arXiv cs/0411030 opened, including the PDF.
(b) Ulam–von Neumann: per the history paper, the note (about "one fifth of a page") suggested iterating f(x) = 4x(1−x) to obtain numbers with various distributions, and "contains only the remark that g can be used as a generator a random numbers".
Bergamo et al.: an attack on the Kocarev–Tasev Chebyshev public-key system over real numbers in [−1, 1]. Using T_n(x) = cos(n·arccos x), the adversary computes an equivalent exponent r′ with T_r′(x) = T_r(x) and recovers the plaintext: "We describe an attack which permits to recover the corresponding plaintext from a given ciphertext." It is a cryptanalytic proof with worked examples, and it extends to a Diffie–Hellman-like key agreement and an authentication scheme of the same design.
(c) The history paper notes von Neumann later judged the map unusable in practice for this purpose. Bergamo et al. say "the security of chaos-based cryptosystems defined over real numbers is not well understood".
(d) Supported: 1947, Ulam and von Neumann, x → 4x(1−x), random numbers; Bergamo, D'Arco, De Santis, Kocarev, 2005, journal and title.
- "Doubling map" is wrong: 4x(1−x) is the logistic map at parameter 4. The doubling map is x → 2x mod 1; the history paper uses "doubling" only for the binary-digit map α → 2α mod 1.
- "Chaos-based ciphers ... have been broken" is broader than the paper. It breaks the Chebyshev public-key scheme over the reals and its siblings; earlier chaos-cipher breaks are cited only as background.
- Issue number 7 for the IEEE paper came from the fetch model's memory, not the page.

**7. Arrow's theorem**

(a) K. J. Arrow, 1950, "A Difficulty in the Concept of Social Welfare", Journal of Political Economy 58: 328–346; Arrow, 1951 (2nd ed. 1963), Social Choice and Individual Values, Wiley. Neither opened. Statement from Morreau, "Arrow's Theorem", Stanford Encyclopedia of Philosophy (2014, revised Dec 7, 2025): https://plato.stanford.edu/entries/arrows-theorem/.
(b) SEP: "Suppose there are more than two alternatives. Then no social welfare function satisfies U, SO, WP, D, and I." It is a proof. The conditions, for finitely many people:
- U, Unrestricted Domain: "The domain of f includes every list ⟨R1, …, Rn⟩ of n weak orderings of X."
- SO, Social Ordering: for any profile in the domain, the output "is a weak ordering of X".
- WP, Weak Pareto: "if for all i, x P_i y, then x P y."
- D, Nondictatorship: "f has no dictator."
- I, Independence of Irrelevant Alternatives: if two profiles agree on {x, y}, the two social orderings agree on {x, y}.
(c) SEP calls these the "canonical form into which they have settled", after Arrow restated the conditions in the 1963 second edition.
(d) Supported: the four named conditions and three or more alternatives.
- Missing from the claim: Social Ordering (the output must be a complete, transitive ordering) and finitely many individuals. Arrow built the first into the definition of a social welfare function.
- Attributing this four-condition form to "Arrow 1950/1951" is loose. Per lecture slides quoting the 1950 paper (Endriss, Amsterdam), the original conditions were a domain condition, a positive-association condition, independence, "citizens' sovereignty" (not imposed) and non-dictatorship, with no Pareto condition.
- Blau (Econometrica 25(2), 1957, 302–313) showed the original statement "is in fact false in general"; the corrected version is the one the field now states.

**8. Hurwitz 1898**

(a) A. Hurwitz, 1898, "Über die Composition der quadratischen Formen von beliebig vielen Variabeln", Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen, Math.-Phys. Klasse, 309–316. Record opened at https://eudml.org/doc/58420 (which spells the title "Ueber ... belibig vielen Variablen"); the paper itself not read. Statement from J. Baez, "The Octonions" (arXiv:math/0105155; https://math.ucr.edu/home/baez/octonions/node2.html).
(b) Baez, Theorem 1: "R, C, H, and O are the only normed division algebras", with "The first theorem goes back to an 1898 paper by Hurwitz." A normed division algebra satisfies ‖ab‖ = ‖a‖‖b‖. The dimensions 1, 2, 4, 8 are those of the four algebras. It is a proof.
(c) Baez on Cayley–Dickson doubling: "First we lose the fact that every element is its own conjugate, then we lose commutativity, then we lose associativity", and "finally we lose the division algebra property."
(d) Supported: dimensions 1, 2, 4, 8; Hurwitz 1898; commutativity lost at the quaternions; associativity lost at the octonions.
- "Ordering at the complex numbers" is not how the doubling account puts it; the first loss named is that every element is its own conjugate. Baez's introduction does call the complex numbers "not ordered, but algebraically complete", so the wording is defensible but is not the doubling statement.
- Do not confuse this with the separate theorem "All division algebras have dimension 1, 2, 4, or 8", which Baez credits to Kervaire and Bott–Milnor, 1958.

**9. Greene 1979**

(a) J. M. Greene, 1979, "A method for determining a stochastic transition", J. Math. Phys. 20, 1183–1201. Not opened (AIP and DOI fetches failed). I rely on Fox and Meiss, arXiv:1205.6143 (https://arxiv.org/pdf/1205.6143), Meiss, arXiv:0801.0883, and arXiv:math-ph/0407003. Two secondary sources (arXiv:0801.0883, arXiv:1604.06305) give the title as "A method for computing the stochastic transition"; I could not settle the title from the publisher.
(b) Greene studied invariant circles of the standard map "by approximating them with sequences of periodic orbits" and computing their residues (a stability index); the circle is taken to break when the residues stop staying bounded. Numerically this gave the critical parameter k ≈ 0.971635 for the golden-mean circle.
(c) "Another remarkable conjecture in [Gre79] is that the last invariant circle ... has the golden mean rotation number"; "There is strong numerical support for this conjecture."
(d) Supported: Greene 1979, J. Math. Phys. 20, 1183, golden mean, last to break.
- "Is found the last to break" overstates it: this is numerical evidence and a conjecture, for one map (the Chirikov standard map), at k ≈ 0.9716.
- The doing is numerical computation via the residue criterion, not a proof. Meiss notes parts of Greene's observations were later proven by others.

**10. Merriam-Webster, "recursion"**

(a) Merriam-Webster.com Dictionary, "recursion": https://www.merriam-webster.com/dictionary/recursion (opened).
(b) Etymology line as relayed: borrowed from Late Latin recursiōn-, recursiō "return," from Latin recurrere "to run back, return" + -tiōn-, -tiō, suffix of verbal action — more at recur. First Known Use: "1790, in the meaning defined at sense 1".
(c) None given.
(d) Supported: the gloss "to run back, return" for Latin recurrere is exact.
- The claim skips a step: the English word is borrowed from Late Latin recursio "return", which is in turn from recurrere.

**11. Hensen et al. 2015**

(a) B. Hensen, H. Bernien, A. E. Dréau, A. Reiserer and others (R. Hanson's group), 2015, "Loophole-free Bell inequality violation using electron spins separated by 1.3 kilometres", Nature, DOI 10.1038/nature15759. Opened: the repository record with the Nature abstract (https://upcommons.upc.edu/entities/publication/ce19b603-9062-44a2-9539-818fdd906e30) and arXiv:1508.05949.
(b) An experiment: "We performed 245 trials that tested the CHSH–Bell inequality S ≤ 2 and found S = 2.42 ± 0.20", with a null-hypothesis probability "of at most P = 0.039" for a local-realist model.
(c) The authors present it as closing the detection and locality loopholes together.
(d) Supported: S = 2.42 ± 0.20 and 245 trials, in both versions.
- Volume and pages "526, 682" were not shown on any page I opened; only the DOI was.
- Worth carrying alongside: P = 0.039.
- The arXiv title differs ("Experimental loophole-free violation of a Bell inequality using entangled electron spins separated by 1.3 km").

**12. Duhem–Quine thesis**

(a) P. Duhem, La théorie physique: son objet et sa structure, 1906; 2nd ed. 1914; trans. P. Wiener, The Aim and Structure of Physical Theory, Princeton, 1954. W. V. O. Quine, 1951, "Two Dogmas of Empiricism" (Philosophical Review 60; reprinted in From a Logical Point of View, pp. 20–46). Neither opened. Opened: SEP "Pierre Duhem" by Ariew (2007, revised Feb 13, 2026), https://plato.stanford.edu/entries/duhem/, and SEP "Underdetermination of Scientific Theory" by Stanford (2009, revised Apr 4, 2023), https://plato.stanford.edu/entries/scientific-underdetermination/.
(b) Best-attested statement, Duhem as quoted in SEP: "there is at least one error; but where the error lies is just what the experiment does not tell us" (1914, 281; 1954, 185). Also "the experiment does not designate which one should be changed" (1954, 187). SEP's gloss of holism: hypotheses "can only be subjected to empirical testing in groups or collections, never in isolation." It is a philosophical argument.
(c) Ariew splits Duhem's thesis into non-separability and non-falsifiability, and notes Quine's version is stronger: "any statement can be held true come what may, if we make drastic enough adjustments elsewhere in the system".
(d) Supported: the claim as worded is Duhem's thesis almost verbatim.
- SEP cites Duhem by the 1914 edition and 1954 translation, not 1906 pages; 1906 is the first edition and fine as the date of the work.
- Per Ariew, Duhem restricted the thesis to physics and did not take Quine's further step, so "Duhem–Quine" joins two different theses.
- The mainstream journal citation for Quine (Philosophical Review 60, 1951) is from my own knowledge; SEP lists the reprint.