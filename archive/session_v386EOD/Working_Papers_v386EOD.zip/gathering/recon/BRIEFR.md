# Brief for a reconciling reader

A file set called natural intelligence has paragraphs (droplets, concerns, possible projects) placed today from an older session report. The same report's observings from science were afterwards opened at their publishings, and many were corrected. Your work: find each place a placed paragraph states a fact of science that parts from what the publishing has, and give the smallest mend.

Your input file has two parts. PART ONE: the placed paragraphs, each with an id. PART TWO: the observings as the publishings have them (OBSERVATION, EXPLANATION), with CHANGED saying what the older report had wrong.

Do not edit any file in `/home/claude/corus`. No web search is needed: PART TWO is the ground. You write exactly one file, your report.

## What to look for

For each paragraph of PART ONE, read each scientific fact in it (a number, a species, a time, what was done, what was found) and find the observing of PART TWO it rests on. Report a MEND only if PART TWO shows the paragraph's fact is otherwise: the CHANGED line names it wrong, or the OBSERVATION has a different number, species, time or finding. Typical cases: a number the page has otherwise; a finding the page gives to another study; a thing the older report gave as observed and the page does not have; an explanation the writers give only as a suggestion, said in the paragraph as found.

Do not mend: the paragraph's own reading in the file set's naming (selves, societies, coupling, parity, the between, carrying) — that is the paragraph's subject and not yours to change; a fact PART TWO confirms; a fact PART TWO does not cover at all (leave it; list it under UNCOVERED if it is a specific number or finding); a fact PART TWO marks "as the field's account has it" without contradicting it.

## How to write a mend

OLD must be an exact, contiguous substring of the paragraph's TEXT, long enough to be unique in it. NEW replaces it: the smallest change that makes the fact agree with the publishing, in the paragraph's own plain voice, keeping its sentence shape. If the fact cannot be mended in a few words, NEW may drop the clause. Do not use these words in NEW: every, when, where, there, because, since, so, would, until, wait, hold, held, keep, kept, stand, start, begin, return, memory, surplus, membrane, door, neighbour, inside, outside, run, take, half, count, sign, turn, mirror, reflection, meet, met, not yet, so far, discovery, technology, travel, observer.

## The report file

```
### MEND
ID: <paragraph id, e.g. B05.22>
OLD: <exact substring>
NEW: <replacement>
WHY: <the observing id and what its page has, one sentence>
```

one block for each mend. Then:

```
## UNCOVERED
- <paragraph id>: <a specific number or finding in it that no observing of PART TWO covers>
## AGREEING
<the ids of the paragraphs in which you found nothing to mend>
```

Then return, as your final message, only: the path of your report and the number of mends.
