### MEND
ID: B05.9
OLD: ibuprofen in the liver
NEW: ibuprofen in the body
WHY: B05.54: the page read has the (R) hand's one-way inversion "in the body" and does not name the organ of the inversion; its CHANGED line says the liver placing was reworded.

### MEND
ID: B05.14
OLD: a thousand to a million times
NEW: about a thousand times
WHY: B05.41: the review read (Kahlweit, 1981) has the two micellar relaxation processes "about three orders of magnitude apart"; the microsecond and millisecond-to-second figures giving the wider range were not found at it.

### MEND
ID: B05.10
OLD: a cell's own mitochondria given back
NEW: a body's own mitochondria given back
WHY: B05.58: the paper's title and summary have autologous mitochondria injected into the heart muscle, the patient's own from another muscle as the field's account has it, and not the receiving cell's own.

### MEND
ID: B05.7
OLD: and the field names the same form an inverse agonist
NEW: and one report of the field names the same form an inverse agonist, a later report naming it neutral
WHY: B05.51: Wang and colleagues (2001) have naloxone and naltrexone showing inverse agonistic effects after morphine pretreatment, and Divin and colleagues (2009) have the same antagonists "indistinguishable" in the opioid-naive or dependent state and acting as neutral antagonists; the paragraph agrees with the first publishing and gives it as the field's whole naming.

### MEND
ID: B05.19
OLD: Fewer suicides, at trials and at trace amounts in drinking water
NEW: Fewer suicides, at one review of trials with a later review inconclusive, and at trace amounts in drinking water
WHY: B05.61: Cipriani and colleagues (2013, 48 trials) have fewer suicides with lithium, odds ratio 0.13, and Nabi and colleagues (2022, 12 trials) have 0.41 (0.03 to 2.49) and call the evidence "inconclusive"; the paragraph agrees with the first publishing alone.

## UNCOVERED
- B05.13: with a fast between all particles are still below a density and then all open together; B05.42 has only gradual or sudden synchronizing set by the rate of exchange, as the field's account, the paper read at the opening of its abstract.
- B05.13: stirring a crystallizing vessel given as a fast between of the same kind; no observing covers it.
- B05.15: crystals of two hands ground continuously coming to one hand, and fragments joining crystals of their own hand alone; no observing covers them (B05.53 has only thalidomide's enrichment in solution on stirring).
- B05.16: the row's pattern of still and oscillating droplets alternating one by one, and the still droplet oscillating again on a change of spacing or size; B05.42 has only that the patterns depend on size, spacing and the species crossing, as the field's account, the two droplet papers not opened.
- B05.19: lithium's form near sodium's and magnesium's, and its arriving at the passages of sodium and magnesium; B05.60 has only "Lithium's mechanism of action is not known" and a list of proposed targets.

## AGREEING
B05.1, B05.2, B05.3, B05.4, B05.5, B05.6, B05.8, B05.11, B05.12, B05.13, B05.15, B05.16, B05.17, B05.18
