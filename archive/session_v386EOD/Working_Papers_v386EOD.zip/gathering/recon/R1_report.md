### MEND
ID: B04.4
OLD: replaced within days
NEW: replaced within days to weeks
WHY: B04.50 has, as the field's account (Crick, 1984, title alone read), the molecules of synapses replaced within days to weeks, a wider time than the paragraph's days.

### MEND
ID: B04.4
OLD: share cells
NEW: share more cells
WHY: B04.49 (Cai and colleagues, 2016) has the ensembles of two contexts learned within a day overlapping more than those a week apart, and no absence of shared cells at a week.

### MEND
ID: B04.4
OLD: each recalling the other
NEW: fear learned at one passing to the other
WHY: B04.49's CHANGED line has Cai's abstract giving a transfer of fear from one context to the other within a day and not across a week, and no recalling of each by the other.

### MEND
ID: B04.5
OLD: one sperm's fusing, and further sperm fuse at none; with
NEW: one sperm's fusing; with
WHY: B04.17's CHANGED line says "further sperm fuse at none" was left out as not stated on either page read (Jaffe, 1976; Jaffe, 2018).

### MEND
ID: B04.7
OLD: a pendulum's beam
NEW: a pendulum's board
WHY: B04.70 has Huygens's two clocks on one board suspended on the backs of two chairs, and Pantaleone's metronomes on a light wooden board, and no beam.

### MEND
ID: B04.8
OLD: being largely unexplained
NEW: needing, at the classic model of early splitting, tightly controlled splitting forces and a preventing of re-joining
WHY: B04.16's CHANGED line says "largely unexplained" was not in the abstract of Jin, Han and Zenker, 2024, which has for twins of two chorions after a single blastocyst transfer the classic model needing tightly controlled splitting forces and a preventing of re-joining.

### MEND
ID: B04.9
OLD: one train of 15-millisecond pulses at 20 hertz
NEW: a train of 15-millisecond pulses at 20 hertz, given in two 3-minute epochs of a 12-minute session
WHY: B04.48 (Liu and colleagues, 2012, full text) has the light across a 12-minute session of four 3-minute epochs, off, on, off, on, two lit epochs and not one train.

## UNCOVERED
- B04.1: in rings of heart tissue a wave circulating past a one-way block continuing after the block has passed, and ending at the circuit interrupted or at one shock arriving at each cell at once (B04.13 and B04.47 have heart cells and aggregates coming into step, and no ring or circulating wave).
- B04.1: old progenitor cells restored at one circulation shared with a young animal.
- B04.3: a cool gas removing the lines it gives out hot.
- B04.4: an engram's active cells differing from day to day with about a fifth continuing.
- B04.5: the depolarizing "within seconds" at starfish and frog eggs (B04.17 has "within a few seconds" at sea urchin eggs alone, from the 1976 paper; the 2018 commentary has the starfish and frog eggs depolarizing with no time given).
- B04.6: a plant's starch used through the night to its end near dawn (B04.26 has starch granule growth rings alone, and nothing of it was compared).
- B04.6: vent mussels at the tide's period.
- B04.6: a rock bacterium living on hydrogen from radiolysis.
- B04.7: a palm in a seed through two thousand years.
- B04.10: paired light clicking kilometres apart (B04.76 has Mermin's device and its realization in two spin-1/2 particles, with no distance and no light).
- B04.11: the matching of paired clicks following the cosine of twice the angle between the two settings (B04.75 has cos²θ for one photon at one polarizer; B04.76 gives no formula of the angle).
- B04.11: the three-setting form, a third of a rotation apart, showing the doubled angle alone (B04.76 has that form at spin-1/2 particles and Stern–Gerlach devices at ±120°, the same colour one time in four, with no reading of the angle as doubled).

## AGREEING
B04.1, B04.2, B04.3, B04.6, B04.10, B04.11
