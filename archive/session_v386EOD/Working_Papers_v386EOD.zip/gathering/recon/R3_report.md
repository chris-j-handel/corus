### MEND
ID: B05.20
OLD: The weeks ahead of an antidepressant's relief, with its target coupled within hours, are read
NEW: The weeks ahead of an antidepressant's relief are read
WHY: B05.63's CHANGED line says reuptake block "within hours" was not found at the page read, which has only "a delayed onset of action of at least a week" and three to six weeks for new neurons to mature.

### MEND
ID: B05.23
OLD: receding to its last member, and the pieces are then at the cells' own proteins at once
NEW: receding in overdose, and the pieces are then at the cells' own proteins
WHY: B05.71's review has glutathione depleted in overdose with a fall of about 70% proposed as the limit past which the binding comes, and adducts found at one hour putting even that limit in dispute, which parts from a binding that comes only at the last member and all at once.

### MEND
ID: B05.26
OLD: the difference lies in the body's own cells' changing
NEW: the difference lies in part in the body's own cells' changing
WHY: B05.76's Foxman abstract has the rhinovirus replicating better at nasal temperature "in part" through the infected cells' weaker antiviral defence, and in the deficient cells the temperature difference was partly removed, the CHANGED line saying "not gone".

## UNCOVERED
- B05.22: the plaque being at about the brain cells' own scale, and microglia being unable to ingest it (B05.67 has microglia changing form and colocalising more with amyloid-β; B05.55's incomplete engulfing is of long fibres by macrophages).
- B05.26: a few degrees killing few microbes (B05.76 has survival at fever-level temperature and the rhinovirus replicating better at 33–35 °C, and no measure of microbes killed by heat).
- B05.27: nausea with the GLP-1 medicine (B05.78 and B05.79 give no adverse effects).
- B05.28: the slowing and wobble ahead of a crossing (no observing of PART TWO has it).
- B05.33: sleep in each animal with a nervous system, a jellyfish among them; chronic pain continuing with no tissue damage; cancer coming back after years of remission; few new classes of antibiotics found.
- B05.35: ultrafine particles below the cell's scale reported to harm; microglia ingesting plaques incompletely.
- B05.38: both hands opening and releasing ahead of the first crystal in a stirred solution (B05.53's stirring is of thalidomide's enrichment, another finding); cellulose, chitin, coal and limestone as molecules living societies emanate.
## AGREEING
B05.21, B05.22, B05.24, B05.25, B05.27, B05.28, B05.29, B05.30, B05.31, B05.32, B05.33, B05.34, B05.35, B05.36, B05.37, B05.38
