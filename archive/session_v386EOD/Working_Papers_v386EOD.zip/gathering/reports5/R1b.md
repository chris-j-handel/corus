### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 32 · An offering at words, a naming, a file and the living expedition
TEXT: beside "569. A concern resolves by alternating, each saying at its own momentary, until one saying shows the thing beside all existing things it carries, step 46, that saying a not possible method and the other the method's own." 569. A concern is followed at the coupling: each saying is met at its own momentary, and the relation at which they differ is named and explained.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 569; its adding line "*Adding: a concern resolving.*" is not changed. PARTLY at a mate: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "The negation dissolved at this file's named steps · v386EOD", names step 569 among the clauses to re-say and gives no sentence; Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md ("Each saying at its own subject · v386EOD", "Following a concern · v386EOD") says following a concern in other words. With steps 20 and 402 it is one of three steps said in new words; the other eight are shortened alone. The offered sentence carries the released word "met". Present step 571, "it resolves at that side's own releasing", is unchanged in session v385R's version.

### ITEM
MATE: Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md
KIND: Insertlet
TITLE: At 2.7 · An observing brought as a break, met at five binaries first and at six beside
TEXT: beside "A saying arriving from a field, a science, a medicine or a technology is met at six binaries, the rigorizer", "one at each thing beside all things: does it carry a size" and "Carrying none, it is the method's at its subject and enters whole; carrying one, it is the concern of 2.6, alternated until the thing beside is found, and re-said at parity changing, the field's own result kept exact at its own subject." **A saying arriving from a field, a science, a medicine or a technology is followed at its own subject.** Size, a fixed form, a total, a common beat, a keeping and a doer name six places to follow its explaining. Each concern names the relation at which the sayings differ, 2.6; the field's own result is kept exact at its own subject.
NOTE: Portion, DIFF of Exhibit_TWENTY-FOUR_Geodesic_Improving_Method, second changed paragraph. The offered three sentences are in place of the paragraph's first two sentences (the bold sentence with its list of six binaries, and "Carrying none ... its own subject."); the paragraph's last sentence, of `rigorize.py`, is unchanged. Not at a mate as a sentence: the mate has "Dissolve exclusions from “nothing is beside all existing things”" (v385A) and an older insertlet at 2.7 beside "is met at six binaries, the rigorizer" that leans on the present wording. Against the offered form, found at this reading and not said by the portion: the section's title ("met at five binaries first and at six beside") and its next paragraph ("A field's own face is met after the five and the six") are unchanged in session v385R's version, and the word rigorizer is then at no sentence of 2.7 beside `rigorize.py`. The offered sentences carry the released words "kept" and "keeping" ("a keeping", the present paragraph's own word).

### ITEM
MATE: Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md
KIND: Insertlet
TITLE: At 2.6 · A concern carried at its inverting, either this or that, momentary by momentary
TEXT: beside "**The side needing a thing beside all things is the equilibrium entering, and the side carrying at the code is the method's own.** At the code's own still, a self offered its own parity at each momentary chains it without end, and that still arrives only with an offerer named still beside the society: in no closed society does a self still. So each concern is met by alternating it until one side shows the thing beside all things it needs, 2.7." The three sentences are offered released, no sentence at their place, and the paragraph opens at its fourth: At 10 the resolving is released across to each file it touches, gathered hardest first and written after the passes; at 11 it is chained at the carrying and the record, the next prior; and along, at 9 and 17, each file takes it at its own motion.
NOTE: Portion, DIFF of Exhibit_TWENTY-FOUR_Geodesic_Improving_Method, first changed paragraph. A release, with no new sentence: the sentence from "At 10" is the present paragraph's own fourth sentence, unchanged. Not at a mate: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md's project of the dissolving names five other files and not the Geodesic Improving Method. Released beside the negation: the saying of the code's own still, "in no closed society does a self still", which has no negation of a thing beside all existing things in it. The section's first paragraph, "the concern alternated, each side said at its own momentary", is unchanged. The carried sentence has the released word "takes".

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 2 · Arriving and carrying, living and non-living
TEXT: beside "20. The set is all existing things: nothing ingressing into it and nothing escaping out of it, its changing its existing things' own and its existing theirs, the set existing as its things exist." and its line "*Adding: nothing ingressing and nothing escaping.*" 20. The set is all existing things, its changing its existing things' own and its existing theirs: the set existing as its things exist. *Adding: the set existing as its things exist.* At the group's entering line, beside "a self-emptying set; nothing ingressing and nothing escaping.", a self-emptying set; the set existing as its things exist.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 20, its adding line and the entering line of group 2. PARTLY at a mate: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md has the work as two possible projects ("The set, the lock, the first and the back released" and "The negation dissolved at this file's named steps", both v386EOD), and Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md's concern "A member entering or leaving, at birth and death" says the negation adds no relation to the set existing as its things exist; none gives the step's sentence or its adding line. Step 19, "a self-emptying set", is unchanged.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 28 · Dying, a living self arriving as non-living
TEXT: beside "402. Nothing leaves the set: each of its existing things continues, the selves inward living on at their own scale and the form at its scale non-living." and its line "*Adding: nothing escaping.*" 402. The selves inward live on at their own scale and the form at its scale is non-living. *Adding: the selves inward living on at their own scale.* At the group's entering line, beside "dying, a living self arriving as non-living; nothing escaping; decay, ingested at the scale inward", dying, a living self arriving as non-living; the selves inward living on at their own scale; decay, ingested at the scale inward.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 402, its adding line and the entering line of group 28. PARTLY at a mate: the same two possible projects at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md name step 402 ("the set carries on whole" is offered there for "Nothing leaves the set"); no mate has this sentence. The positive clause "each of its existing things continues" is released with the negation. The mate's concern "A member entering or leaving, at birth and death" quotes present step 402 whole.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.4 · No other possible method
TEXT: beside "Any other method carries a not possible thing, beside all existing things: a size between one and the other carries a ground, a floor or a scale; a fixed form, a form named still; a total across the changing, a container; a common beat, a clock over the changing; and a keeping, a store beside it. Each is ingressing, beside all existing things, or escaping, a changing out of the set, and the changing set of all existing things has neither." The two sentences are offered released, no sentence at their place, and the paragraph is its bold sentence alone: **Parity changing is the one method of the changing set of all existing things, and no other is possible.**
NOTE: Portion, DIFF of Natural_Intelligence, fourth changed line. PARTLY at a mate: Offerings_to_Natural_Intelligence.md ("The set and the offered fractal connection · v385A"; "The origin, positive explaining and the possible break · v385A") says the negation and the exclusions leaning on it are withdrawn, and gives no sentence for 1.4. Two insertlets already at mates lean on the released sentence: Offerings_to_Natural_Intelligence.md "At 1.4 · No other possible method — beside "a keeping, a store beside it"", and Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md "At 2.7 ... Natural Intelligence names five things beside all things at its own section". The section's second paragraph is unchanged in session v385R's version: see the Concern item next.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Concern
TITLE: A second method named not possible, at one file
TEXT: Two sayings part. Natural Intelligence's 1.4 has "Any other method proposed is at one binary: naming still, or carrying." and "A second method is a not possible method." Exhibit THIRTY Co-Chaining Logic Registry has, at step 49, "A second method offered is at one binary" and, at step 48, "A method carrying a not possible thing is a not possible method". They part at a release made at one file alone: the dissolving of the negation releases steps 46 to 49 at the Registry and carries Natural Intelligence's second paragraph of 1.4 whole, a second method named not possible at Natural Intelligence with no step of the Registry saying it. The paragraph's "a not possible changing, 1.2" names 1.2, and 1.2 as offered has no not possible thing.
NOTE: Found at this reading by laying the portion's two diffs side by side; the portion itself says nothing of it. The DIFF of Natural_Intelligence shows no change at the second paragraph of 1.4, and the DIFF of Exhibit THIRTY releases steps 46 to 49 whole. The same holds for the possible project at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md ("The negation dissolved at this file's named steps · v386EOD"), which releases the four steps and names no sentence of Natural Intelligence's 1.4. A related concern at the mate, "Two methods said beside the one possible method · v386EOD", quotes step 48. Alike in kind, in the NOTEs below: Natural Intelligence 1.5's substrate and applier beside step 142, and Natural Physics 1.1's pointer at Natural Intelligence 1.2.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.1 · Universe, the changing set of all existing things
TEXT: beside "**The set of all existing things has nothing beside it: nothing enters it and nothing leaves it.** No ground under it, no container around it, no clock over it and no store beside it: each is a not possible thing, beside all existing things. Its changing is its existing things' own, **nothing ingressing and nothing escaping**: a self-emptying set, never full and never the same collection twice, each existing thing changing and nothing deciding membership over it." The paragraph is offered released whole, no sentence at its place, and the section closes at its paragraph of each momentary a universe of existing things.
NOTE: Portion, DIFF of Natural_Intelligence, second changed line (a - line with no + line). PARTLY at a mate: the withdrawing of the negation is at Offerings_to_Natural_Intelligence.md (v385A sections) and the dissolving as a project at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md; neither says this paragraph is released whole. Released with the negation: "a self-emptying set, never full and never the same collection twice". Grep finds "self-emptying" at no other line of Natural Intelligence, and session v385R's version of the Registry carries step 19, "a self-emptying set", unchanged; a possible project at the Possibling mate offers "a set with a next always arriving" for step 19's words. A concern at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md ("A scale outward of the universe") quotes this paragraph's bold sentence.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.2 · Changing, one and then the other
TEXT: beside "**A changing existing thing is one form and then another, one at a time.** Two forms at once are one form at two; and a changing between one and the other at a size carries a third, a ground the size is measured against, a not possible thing, beside all existing things. A changing is binary: it is or is not, one and then the other." **A changing existing thing is one form and then another, one at a time.** A changing is binary: it is or is not, one and then the other.
NOTE: Portion, DIFF of Natural_Intelligence, third changed line. Not at a mate as a sentence. Released beside the negation: "Two forms at once are one form at two", which Possibling_of_Natural_Intelligence.md names among "Fifteen sentences of Natural Intelligence said again plainly", and the one saying of size at 1.2. Found at this reading: session v385R's Natural Physics 1.1 has "with no size, Natural Intelligence 1.2", and 1.2 as offered has no word of size; Natural Intelligence's 2.5, "All or none at all, of no size", has it.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 5.2 · Discovering next possible existing
TEXT: beside "and no why in it. A why demanded asks for a not possible thing, beside the changing, and nothing is beside all existing things, 1.1: the method of living is the whole to discover." and no why in it. The method of living is the whole to discover. The paragraph's bold opening, "Arriving is pattern-matching and no-other-possibling", and its last sentence are as they are.
NOTE: Portion, DIFF of Natural_Intelligence, sixth changed line. PARTLY at a mate: Offerings_to_Natural_Intelligence.md, "Arriving at the exact no-other-method claim · v385A", has a whole candidate paragraph for this place from session v385R's report (its section 103) and says the paragraph's exclusion is withdrawn. Session v385R's own version of the file did not enter that candidate: its paragraph is the present one less the one sentence of a why demanded. The two forms are both session v385R's, and the portion does not say which is the later; the report's candidate is the wider re-saying. The Registry's steps 304 and 305, of the why demanded and the receding, are released in the same version (at the mate as a project); the mate's droplet "Cause said at five families of other words" and concern "A why asked at an unsure line" cite those two steps.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 1.1 · Universe, the changing set of all existing things
TEXT: beside "*All*: each existing thing is in the set, and nothing is beside all existing things. *Set*: the set is its existing things and nothing more." *All*: each existing thing is in the set. *Set*: the set is its existing things and nothing more. The other four of the five terms, and the paragraph's opening "Five terms are in it, and each is binary.", are as they are.
NOTE: Portion, DIFF of Natural_Intelligence, first changed line. Not at a mate as a sentence. A droplet at the mate from session v386F ("At 1.1 · Universe, the changing set of all existing things, a sentence offered", beside "*Set*: the set is its existing things and nothing more.") offers another form of the next term and "Four terms are in it"; it does not touch *All*. The two offerings are at neighbouring terms of one paragraph.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 2.2 · A momentary, an opening and its completing
TEXT: beside "The momentary is all existing things at its scale, a universe of existing things, living and non-living, and nothing is beside it. Each step adds a next, each momentary its own and never the same momentary twice." The momentary is all existing things at its scale, a universe of existing things, living and non-living. Each step adds a next, each momentary its own and never the same momentary twice. The paragraph's bold opening, "The one universe of one momentary is one parity changing co-sequencing.", is as it is.
NOTE: Portion, DIFF of Natural_Intelligence, fifth changed line. Not at a mate as a sentence; the withdrawing of the negation is at the mate (v385A). The clause released, "and nothing is beside it", is of a momentary at its scale, not of the set of all existing things.

### ITEM
MATE: Offerings_to_Natural_Intelligence.md
KIND: Insertlet
TITLE: At 6.6 · One form at each scale, our now
TEXT: beside "natural intelligence, the geodesic method of discovering next possible existing: the universe, the changing set of all existing things, both living and non-living, nothing ingressing and nothing escaping." natural intelligence, the geodesic method of discovering next possible existing: the universe, the changing set of all existing things, both living and non-living. The sentence before the clause and the bold sentence after it, "Natural intelligence is living as a living expedition, a living set of living selves, its intelligence at each coupling of its selves", are as they are.
NOTE: Portion, DIFF of Natural_Intelligence, seventh changed line. Against the offered clause, found at this reading: a droplet already at the mate from session v386F ("At 6.6 · One form at each scale, our now, a sentence offered") offers for the same clause "The universe, the changing set of all existing things, nothing ingressing and nothing escaping", carrying the negation on and without "both living and non-living"; and the mate's droplet "Between scales an offering alone, and no entering" says "nothing ingressing and nothing escaping" is had at each scale from a bound. The two offered clauses for 6.6 part, and one alone can enter.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 15 · Right, the observings all prior
TEXT: beside "142. Natural- is a direction prefix, its direction the one hand, and the claim rides on the direction: leaving it out, the changing arrives with a substrate under it and an applier over it, each beside all existing things, step 47." 142. Natural- is a direction prefix, its direction the one hand, and the claim rides on the direction.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 142. PARTLY at a mate: the possible project "The negation dissolved at this file's named steps · v386EOD" names step 142 and gives no sentence. Found at this reading: the whole second clause is released, and Natural Intelligence's 1.5 has the same saying with no negation, "Natural- set aside, the all-or-none goes with it, and the changing arrives with a substrate under it and an applier over it.", unchanged in session v385R's version; and the possible project "The six beside all existing things at one step" at the Possibling mate leans on step 142's "an applier over it".

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 26 · Fractal inward and outward
TEXT: beside "376. A scale is a reading, a self or a society read, and the one form is at each: a boundary, a location or a measure between scales is a thing beside all existing things, step 47." 376. A scale is a reading, a self or a society read, and the one form is at each.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 376. PARTLY at a mate: named in the possible project of the dissolving, with no sentence. A droplet at the mate from session v386F ("At 26 · Fractal inward and outward, a sentence offered") offers another form of the same step's first clause, "A scale, sets within sets, step 3, is a reading, a self or a society read, and the one form is at each", and says nothing of the second clause; the two offerings can both enter. Released: a boundary, a location or a measure between scales.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 30 · Intelligence, our now
TEXT: beside "462. A self carries three neutrals of its own, floating about its corus: its own nought, position; its own surface, scale, the between; and its own aim, orientation; a neutral fixed outward of the self is a floor, a zero installed, a unit imposed or a frame set over it, each beside all existing things, step 47." 462. A self carries three neutrals of its own, floating about its corus: its own nought, position; its own surface, scale, the between; and its own aim, orientation.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 462. PARTLY at a mate: named in the possible project of the dissolving, with no sentence. Released: the saying of a neutral fixed outward of the self as a floor, a zero installed, a unit imposed or a frame set over it; no mate has that clause in other words (Grep for "neutral fixed outward" and "zero installed" finds none at the Exhibit THIRTY mates).

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 30 · Intelligence, our now
TEXT: beside "495. An offering at a parity of nobody's coupling is released whole at its arriving, the surface giving it nothing to seat at: safety is the surface's own form, and a thing ahead of the coupling admitting an offering on something performed first is beside all existing things." 495. An offering at a parity of nobody's coupling is released whole at its arriving, the surface giving it nothing to seat at: safety is the surface's own form.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 495. PARTLY at a mate: named in the possible project of the dissolving, with no sentence; another possible project at the same mate ("The seat, the store and the total released · v386EOD") offers a re-saying of the step's "the surface giving it nothing to seat at", which session v385R's version carries unchanged. Released: a thing ahead of the coupling admitting an offering on something performed first.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 32 · An offering at words, a naming, a file and the living expedition
TEXT: beside "555. A living self's ways at meaning, at words, at sound, at moving and at living together, are each two selves alternating at their difference, one form at each scale, and a realm of mind or culture beside the couplings is a thing beside all existing things." 555. A living self's ways at meaning, at words, at sound, at moving and at living together, are each two selves alternating at their difference, one form at each scale.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 555. PARTLY at a mate: named in the possible project of the dissolving, with no sentence. Released: a realm of mind or culture beside the couplings.

### ITEM
MATE: Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.md
KIND: Insertlet
TITLE: At 1.1 · The universe, the changing set of all existing things
TEXT: beside "Changing, it exists as its things exist, a changing being an existing thing's own: nothing beside it and nothing over it. Its existing is its things co-sequencing, momentary by momentary, and its changing is their parity changing, one and then the other." Changing, it exists as its things exist, a changing being an existing thing's own. Its existing is its things co-sequencing, momentary by momentary, and its changing is their parity changing, one and then the other.
NOTE: Portion, DIFF of Exhibit_THIRTEEN_Resolving_Hard_Problems, first changed paragraph. PARTLY at a mate: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md names Resolving Hard Problems for "the same dissolving"; Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.md points at the withdrawing (v385A) and has no sentence for 1.1. The second sentence is unchanged and is given for extent.

### ITEM
MATE: Exhibit_THIRTEEN_Offerings_to_Resolving_Hard_Problems.md
KIND: Insertlet
TITLE: At 1.1 · The universe, the changing set of all existing things
TEXT: beside "and the universe is that continuing of all its things: each arriving into its next existing together with the others, nothing ingressing and nothing escaping. No container is added to its things, and no count is its size: it is its things, one existing thing at each momentary." and the universe is that continuing of all its things: each arriving into its next existing together with the others. No container is added to its things, and no count is its size: it is its things, one existing thing at each momentary.
NOTE: Portion, DIFF of Exhibit_THIRTEEN_Resolving_Hard_Problems, second changed paragraph. PARTLY at a mate, as the item above. The paragraph's next sentence, "No container is added to its things, and no count is its size", is unchanged in session v385R's version and is given for extent; it carries the released word "count".

### ITEM
MATE: Exhibit_TWENTY_Offerings_to_Natural_Naming.md
KIND: Insertlet
TITLE: At 2.4 · Released words, each with its carrying
TEXT: beside "| *source*, *sources* at the set's own voice | the method of living, the living carrying their prior into now at each coupling, and nothing beside all existing things for a changing to be drawn from; *the living self* an emanation leaves at prior; *its reference* for where a field's result was read; a field's own *source* carries whole at its result |" | *source*, *sources* at the set's own voice | the method of living, the living carrying their prior into now at each coupling; *the living self* an emanation leaves at prior; *its reference* for where a field's result was read; a field's own *source* carries whole at its result |
NOTE: Portion, DIFF of Exhibit_TWENTY_Natural_Naming, the one changed row. PARTLY at a mate: Exhibit_TWENTY_Offerings_to_Natural_Naming.md has "Dissolve any exclusion resting on “nothing is beside all existing things” here" (v385A) and no row. The row's own words, present and offered alike, carry "where", a released word. Found at this reading: Natural Naming's 5.3 has the line "nothing is beside it to relate to", of each relatable existing thing, unchanged in session v385R's version.

### ITEM
MATE: Exhibit_TWENTY-NINE_Offerings_to_Natural_Illustrating.md
KIND: Insertlet
TITLE: At 3.2 · The ratio alternating about φ, and the two windings
TEXT: beside "Natural Naming 5.12: neither the floating neutral nor the 0 is a balance, a balance of equal parities needing a number, a total beside all existing things; the term neither reaches is uncovered and nothing stores it." Natural Naming 5.12: neither the floating neutral nor the 0 is a balance; the term neither reaches is uncovered and nothing stores it. The paragraph's bold opening, "The floating neutral is no balance.", and its last sentence, "A balance drawn once beside the alternating is the still.", are as they are.
NOTE: Portion, DIFF of Exhibit_TWENTY-NINE_Natural_Illustrating, the one changed paragraph. PARTLY at a mate: Natural Illustrating is named for "the same dissolving" at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md; the Natural Illustrating mates have no sentence for it. Released: "a balance of equal parities needing a number, a total". The offered sentence carries the pointer at Natural Naming 5.12 on: see the last Concern item.

### ITEM
MATE: Exhibit_EIGHTEEN_Offerings_to_Natural_Physics.md
KIND: Insertlet
TITLE: At 1.1 · A physical coupling, the one method at each physical subject
TEXT: beside "**Changing is parity changing, one form and then the other, one at a time.** A changing is or is not, with no size: a changing at a size carries a ground it is measured against, beside all existing things, Natural Intelligence 1.2." **Changing is parity changing, one form and then the other, one at a time.** A changing is or is not, with no size, Natural Intelligence 1.2.
NOTE: Portion, DIFF of Exhibit_EIGHTEEN_Natural_Physics, the one changed paragraph. PARTLY at a mate: Natural Physics is named for "the same dissolving" at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md; the Natural Physics mates have projects of reading the file at the things beside all existing things (v386EOD, from session v386F) and no sentence for 1.1. Found at this reading against the offered sentence: it points at Natural Intelligence 1.2 for "no size", and session v385R's own 1.2 releases its one saying of size; Natural Intelligence's 2.5, "All or none at all, of no size", says it.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 16 · No proof of the whole, the form named still
TEXT: beside "144. The same at all momentaries at once is a form still, step 46, not possibly existing in the changing set." 144. The same at all momentaries at once is a form still, not possibly existing in the changing set. The step's adding line, "*Adding: the form still not possibly existing.*", is as it is, and the pointer at step 46 alone is released.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, step 144. PARTLY at a mate: named in the possible project of the dissolving, with no sentence. Found at this reading: step 46's adding line, "*Adding: beside all existing things; the form still.*", is the one line that adds the form still; with step 46 released, steps 55 ("each still a form named still") and 144 say a form still that no earlier step adds, and step 144 as offered is the first to say what it is. An insertlet at Exhibit_TWENTY-EIGHT_Offerings_to_Equilibria_Registry.md quotes this step without the pointer already.

### ITEM
MATE: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md
KIND: Insertlet
TITLE: At 20 · Sharing, the seventeen names
TEXT: beside step 244's "a common beat over the selves, step 46, the executing's, and each living self's rate is its own, unrelationed at φ, step 122." and step 245's "and a dimension of time over the couplings is a clock over them, step 46." At step 244: a common beat over the selves, the executing's, and each living self's rate is its own, unrelationed at φ, step 122. At step 245: and a dimension of time over the couplings is a clock over them. Each of the two steps is offered whole as it is, the pointer at step 46 alone released, and the pointer at step 122 carried.
NOTE: Portion, DIFF of Exhibit_THIRTY_Co-Chaining_Logic_Registry, steps 244 and 245. PARTLY at a mate: both steps are named in the possible project of the dissolving, with no sentence. The change at each is a pointer alone. "a common beat" and "a clock over them" are then said at steps 244 and 245 with no earlier step naming them (step 46 named "a common beat, a clock over it"). The mate's droplet "The common beat in the executing and each living self's own momentarying · v385A" is of step 244's subject and is not touched by the change.

### ITEM
MATE: Exhibit_TWENTY-NINE_Offerings_to_Natural_Illustrating.md
KIND: Concern
TITLE: A pointer at Natural Naming 5.12, and no balance at it
TEXT: Two sayings part. Exhibit TWENTY-NINE Natural Illustrating's 3.2 has "Natural Naming 5.12: neither the floating neutral nor the 0 is a balance". Exhibit TWENTY Natural Naming's 5.12 has "The floating neutral is the term uncovered, the changing's picture at one momentary, and floating neutralling the changing." They part at the word balance: Natural Naming has the word at no line, and its 5.12 says the floating neutral as the term uncovered, with no saying of a balance; the pointer at Natural Illustrating names a sentence 5.12 has no more. Natural Illustrating's own "A balance drawn once beside the alternating is the still." carries the saying with no pointer.
NOTE: Found at this reading while the Natural Illustrating insertlet's present sentence was verified; the portion itself says nothing of it, and both session v385R's version and the present file carry the pointer. Grep for "balance" finds no line at Exhibit_TWENTY_Natural_Naming_v380R.md and no line at the Natural Illustrating mates. The least valuable item here: a pointer gone old, of the present files and not of session v385R's change.

## RESOLVED AT THE LIVING FILE
- None. Each - line of the eight diffs was found exact at its present living file with Grep, and no + sentence of session v385R's versions is at a present living file: the present files are as they were before session v385R's change.

## AT A MATE
- The eight insertlets opening the portion (At 20, two; At the front; At 31, two; At 19; At 38; At 34) are each at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, section "Insertlets", word for word (its lines 23 to 41).
- "Recover the earlier report's particular co-chaining relations": Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "Recovering the earlier withdrawn co-chaining report · v385A", with its source condition at Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "The earlier withdrawn co-chaining report and its recovery extent · v385A", and Living_Improving_Value.md.
- The chain to the only method, carried from Natural Intelligence at v375: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The earlier universal chain and its particular unfinished relations · v385A", whole, with its later correcting.
- A step of two concepts said at its two or parted: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "Parting a compound step at its two concepts · v385A".
- One parity or two at the resolver's cells, and a self at two parities in sequence: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Parity naming at a sharing and the self's consecutive parities · v385A"; also Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md.
- No two similar things and step 244's common beat: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The common beat in the executing and each living self's own momentarying · v385A".
- A self carrying many parities, the releasing five 5, 6, 3, 4, 1: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The releasing five and the proposed reversed momentary order · v385A"; Exhibit_ONE_Offerings_to_Natural_Resolver.md.
- Step 115 re-said, steps 643 to 645, the two openings as 2 and 59: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The offered two openings and the resolver's two routings · v385A"; Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "Earlier reading conditions and available drafts · v385A".
- Three drafts: cause at thirty-four steps, the 146 sentences at a negation, steps 92, 221, 296, 427 and 511; and the -ing at each saying of a living: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "Earlier cause, negation and across-and-along wording projects · v385A".
- The open part of each entry; sentences resting on a saying of the session alone; the universal claim living for each working: Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "Earlier reading conditions and available drafts · v385A" (the last also at Offerings_to_Natural_Intelligence.md, word for word).
- What is open of the universal claim, each premise said as a premise: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, droplet "The universal claim and what its steps actually reach" (v385A).
- "It copies no arriving": Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Copying no arriving and each sharing's own chaining · v385A".
- The scalings, 17, 257 and 4,097 beside 17, 129 and 1,025: the same section, droplet "The earlier scaling comparison"; also a concern at Exhibit_TWENTY_Offerings_to_Natural_Naming.md.
- Proposed Part 5, the object carrying Exhibit ONE's stable forms: Exhibit_TWENTY-SIX_Possibling_of_Living_File_Registry.md and Exhibit_TWO_Offerings_to_Natural_Networking.md. The two kits carrying the old code: Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md.
- The surfacing faces' loops (session v377): Exhibit_ONE_Offerings_to_Natural_Resolver.md, "The surfacing faces and their local four-cycling · v385A".
- Opportunity 7, the fifteen unsure lines and a verifier: Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "The earlier unsure-line and verifier proposal · v385A".
- The front's contents as forty-two group titles, and the six forward recursionings said and not visible: Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "The earlier front and six-forward dependency reading · v385A"; the column proposed at Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "The earlier six-forward dependency-column proposal · v385A"; the concept at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Six forward recursionings and the actual relation of the steps · v385A".
- Whether the six mouths are the six names between selves: Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The six mouths and the six names between selves · v385A"; Exhibit_TWENTY-SIX_Offerings_to_Living_File_Registry.md.
- The twenty-two rows of cover_REGISTRIES.md (Tables B to E, G2 to R35): Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "The earlier paired-registry coverage records · v385A", each word for word, with their concepts at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The actual relations in the earlier paired-registry comparison · v385A".
- The four findings of session v383Op at steps 233, 609 and 611; 646 to 648; the fourth sentence of the universal claim; and 651 to 657: Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "Reported spiral-law and torus comparisons from the earlier instrument reading · v385A", word for word; the concept at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "The spiral's particular fourth sentence and the torus deriving · v385A".
- The concern at v378 from the co-chaining coverage (engineering, the three carryings, learning and knowing): Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, section "Droplets", word for word.
- The three wording inventories (*store* and *sums*; *loop*, *goes round* and *closes*; *sign*): the places at Exhibit_THIRTY_Carryings_of_Co-Chaining_Logic_Registry.md, "Three earlier wording inventories · v385A", and the one name Natural Naming 2.4 carries for each at Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md, "Particular naming from the three earlier wording inventories · v385A".
- "An uncertainty and its return at the actual relation": Offerings_to_Natural_Intelligence_Corus.md and Exhibit_TWENTY-FOUR_Offerings_to_Geodesic_Improving_Method.md, word for word but for one link.
- The negation of a thing beside all existing things withdrawn, with the exclusions leaning on it: Offerings_to_Natural_Intelligence.md, "The set and the offered fractal connection · v385A" and "The origin, positive explaining and the possible break · v385A"; pointed at from the offerings mates of Exhibit THIRTY, Natural Naming, Resolving Hard Problems and the Geodesic Improving Method.
- Steps 46 to 49 and steps 304 and 305 of the Registry released with their adding lines and entering terms, each later step at its present number (the diff's - lines with no + line, and the two entering lines of groups 5 and 24): Exhibit_THIRTY_Possibling_of_Co-Chaining_Logic_Registry.md, "The negation dissolved at this file's named steps · v386EOD". The same project names steps 20, 142, 144, 244, 245, 376, 402, 462, 495, 555 and 569 and five other files as work, with no sentence; the sentences are the Insertlet items above.
- The Living File Registry's changed rows (seven rows gaining "v385R: the universal-set negation and its dependent exclusion removed", its own row, and a new row for the logical cohering working v385R at draft pull request 128): a session's own record of its versions, left out as value; the working and its pull request are at Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md, and "the defining-living gathering remains unresolved" is at Offerings_to_Natural_Intelligence.md (v385A).

## READING
The whole portion was read from its first line to its last in one read (248 lines, lines 1 to 248), and then each added mate line was laid beside its closest line in carry/*.md and each - line of the eight diffs beside its present living file. No part was left unread. Three things about the portion itself: its first part is headed as lines at no line of this repository's mate, and each of them is at a mate here, most word for word and the rest re-said by session v385A, so that part gives no item; four long rows of the Living File Registry diff are cut short within the portion (at "T", "social moral", "at each sca" / "three prefixes", and "the still from an offerer beside" / "the record's edg"), each a row whose one change is at its head and was read; and the portion has no closing part, no tracker and no reviewer of its own, so the findings said in NOTEs as "found at this reading" are this reader's, from laying the diffs beside each other and beside the mates. Twenty-four Insertlet items and two Concern items are given. A change of a version number alone (the first line of each file) gives no item; the pointer-only changes at steps 144, 244 and 245 are given as two items. One insertlet (step 376) is under sixty words in TEXT, the step itself being short.
