import re,glob,os,collections,sys,json
DRY=len(sys.argv)<2
def sents(p):
    return [x for x in re.split(r'(?<=[.])\s+(?=[A-Z\[“"*])',p) if x.strip()]
DROP=[re.compile(r'^A sentence (that report offers|that session offers|offered) for a living file is a droplet in its dropper\'s words, beside the living sentence it is aimed at\.$'),
      re.compile(r'^Each may change or never be made\.$')]
kept=collections.Counter(); rec=[]; nfiles=0; removed_whole=0; shortened=0
for f in sorted(glob.glob('carry/*.md')):
    t=open(f,encoding='utf-8').read(); secs=re.split(r'(?m)^(?=## )',t); ch=False
    for i,s in enumerate(secs):
        h=s.split('\n',1)[0]
        if not h.startswith('## ') or 'v386EOD' not in h: continue
        parts=s.split('\n\n')
        idx=[k for k in range(1,len(parts)) if parts[k].strip()]
        if not idx: continue
        k=idx[0]; p=parts[k]
        if not p.startswith('Each '): continue
        ss=sents(p.strip())
        first=ss[0]; keep=[]
        if not re.match(r'^Each (concept here )?is from ',first): continue
        if first.startswith('Each is a saying'): keep.append(first); src=''
        else:
            src=first
            # a tail of the first sentence after ';' that is no source or reading
            m=re.search(r';\s+(.*)$',first)
            if m:
                tail=m.group(1)
                if not (tail.startswith('a thing the living files or a mate say already') or tail.startswith("the page's naming is of that month")):
                    keep.append(tail[0].upper()+tail[1:])
        body=s
        for x in ss[1:]:
            if any(d.match(x) for d in DROP):
                if x.startswith('A sentence'):
                    bad=[q for q in parts[k+1:] if ', a sentence offered.**' in q and "dropper's words" not in q]
                    if bad: keep.append('A sentence offered for a living file is a droplet in its dropper\'s words, beside the living sentence it is aimed at.')
                else:
                    bad=[q for q in parts[k+1:] if q.startswith('**Possible project') and 'It may change or never be made.' not in q]
                    if bad: keep.append(x)
                continue
            keep.append(x)
        new=' '.join(keep)
        new=new.replace('are at the carrying mates, each said','are at the carryings, each said').replace('Its publishing was opened at this gathering, and the two lines say','The two lines say').replace('at the carrying mates of Natural Chemistry','at the carryings of Natural Chemistry')
        assert 'mate' not in new and 'this gathering' not in new,new
        for x in keep: kept[re.sub(r'\d+','N',x)[:300]]+=1
        rec.append((os.path.basename(f),h[3:],p.strip()))
        if new: parts[k]=new; shortened+=1
        else: del parts[k]; removed_whole+=1
        secs[i]='\n\n'.join(parts); ch=True
    if ch:
        nfiles+=1
        if not DRY: open(f,'w',encoding='utf-8').write(''.join(secs))
print('openings',len(rec),'files',nfiles,'removed whole',removed_whole,'shortened',shortened)
if DRY:
    for k,v in kept.most_common(): print(v,'|',k)
else: json.dump(rec,open('/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/redo/openings.json','w'))
