import subprocess,re,collections,json,os
B='a81ea75'
def sh(*a): return subprocess.run(a,capture_output=True,text=True).stdout
commits=sh('git','log','--reverse','--format=%h','%s..HEAD'%B).split()
def paras(rev,f):
    t=sh('git','show',f'{rev}:{f}')
    return [' '.join(p.split()) for p in t.split('\n\n') if p.strip()]
files=[l for l in sh('git','ls-tree','-r','--name-only',B,'carry/').split('\n') if l.endswith('.md')]
base={f:collections.Counter(paras(B,f)) for f in files}
prev={f:collections.Counter(paras(B,f)) for f in files}
out=[]; per=collections.OrderedDict()
parent=B
for c in commits:
    changed=[l for l in sh('git','diff','--name-only',parent,c,'--','carry/').split('\n') if l.endswith('.md') and l in base]
    n=0; w=0
    for f in changed:
        cur=collections.Counter(paras(c,f))
        gone=prev[f]-cur
        for p,k in gone.items():
            kb=min(k,base[f][p])  # only text that was there before the session
            if kb>0 and (base[f][p]-0)>0:
                # still count only if base copies exceed what remains
                remain=cur[p]
                lost=min(k, max(0,base[f][p]-remain)) if base[f][p]>remain else 0
                if lost>0 and not p.startswith('Exhibit') :
                    n+=lost; w+=lost*len(p.split()); out.append((c,f,p))
        prev[f]=cur
    per[c]=(n,w,sh('git','log','-1','--format=%s',c).strip()[:95])
    parent=c
tot=0
for c,(n,w,s) in per.items():
    if n: print(f"{c} {n:5} paragraphs {w:7} words | {s}"); tot+=n
print('total pre-session paragraphs no longer word for word:',tot)
json.dump(out,open('/tmp/claude-0/-home-claude-corus/06e65369-2e2c-5dea-810b-8c2910827df6/scratchpad/redo/gone.json','w'))
byf=collections.Counter(f for c,f,p in out)
print(len(byf),'files; top:',byf.most_common(8))
