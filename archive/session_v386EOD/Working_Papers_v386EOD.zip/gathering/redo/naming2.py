import re,glob,os,sys
DRY=len(sys.argv)<2
HAND=[
("**Concern · Guiding, at two mates.** Two sayings part. This mate has","**Concern · Guiding, at two files' offerings.** Two sayings part. These offerings have"),
("the two sayings are at one place at neither mate.","the two sayings are at one place at neither file's offerings."),
("A reader found the carrying naming both the whole and one mate.","A reader found the carrying naming both the whole and one of its three files."),
("The carrying named one file beside mates at each file","The carrying named one file, beside three files at each living file"),
("The carry at `carry/` has mates at each living file, each a file of its own","The carry at `carry/` has offerings, possibling and carryings at each living file, each a file of its own"),
("They part at the voice of an offerings mate: a mate of droplets carries as many voices as droppers","They part at the voice of a file's offerings: offerings of droplets carry as many voices as droppers"),
("a carryings mate listing them is a record of the releasing","carryings listing them are a record of the releasing"),
("**Droplet · The mates as a motion's second part.**","**Droplet · The offerings and the carryings as a motion's second part.**"),
("With mates at each living file, the second part is at the mates: the offerings release","With offerings and carryings at each living file, the second part is at them: the offerings release"),
("naming its resting at no carryings mate is unfinished","naming its resting at no carryings is unfinished"),
("At this file and its mates the one word offering names five things. A mate file, the offerings. A thing in that mate, a droplet or an insertlet.","At this file and at its offerings, possibling and carryings the one word offering names five things. One of those three files, the offerings. A thing in that file, a droplet or an insertlet."),
("with offering at each thing in the mate they part","with offering at each thing in the offerings they part"),
("`incoming/` is the entrance and `carry/` is the mates.","`incoming/` is the entrance and `carry/` is the offerings, possibling and carryings of each living file."),
("and value followed into its mate, a report delivered","and value followed into the offerings, possibling or carryings of its file, a report delivered"),
("## A name for the three mates' folder","## A name for the folder of the offerings, possibling and carryings"),
("and the folder of the three mates is `carry/`.","and the folder of each living file's offerings, possibling and carryings is `carry/`."),
("## A direction from each living file to its mates","## A direction from each living file to its offerings, possibling and carryings"),
("a direct link to its three mates;","a direct link to its offerings, its possibling and its carryings;"),
("The file's mates name each pass.","The file's offerings, possibling and carryings name each pass."),
("and at this file's mate, and chirality","and at this file's offerings, and chirality"),
("Aimed at 1.3, each mate is whole at its address","Aimed at 1.3, each file of offerings, possibling and carryings is whole at its address"),
("the correcting is placed at that droplet's own mate.","the correcting is placed at the offerings that droplet is at."),
("visible at no one subject's mate; a repeated droplet as available at its mate;","visible at no one subject's offerings, possibling or carryings; a repeated droplet as available at its file's offerings;"),
("a place named at Exhibit ONE Natural Resolver's mates.","a place named at Exhibit ONE Natural Resolver's offerings, possibling or carryings."),
("one naming, and a mate's line the other way","one naming, and a line of these offerings the other way"),
("The mate's line is the earlier","The line of these offerings is the earlier"),
("names neither the working base nor those mates,","names neither the working base nor those offerings,"),
("at a concern at a mate already, the further relation this reading adds is brought and its mate named;","at a concern at a file's offerings already, the further relation this reading adds is brought and those offerings named;"),
]
def rules(K):
    this={'O':('these offerings','These offerings','have',"these offerings'","These offerings'",'those offerings'),
          'C':('these carryings','These carryings','have',"these carryings'","These carryings'",'those carryings'),
          'P':('this possibling','This possibling','has',"this possibling's","This possibling's",'that possibling'),
          'L':('this file','This file','has',"this file's","This file's",'that file')}[K]
    return [
    (r"\[the offering mate\]","[the offerings]"),(r"\[its offering mate\]","[its offerings]"),(r"\[the same mate\]","[the same offerings]"),
    (r"this file's offering mate has","this file's offerings have"),(r"This file's offering mate has","This file's offerings have"),
    (r"\b([Tt])his file's offering mate\b",r"\1his file's offerings"),(r"this file's possibling mate","this file's possibling"),(r"this file's carrying mate","this file's carryings"),
    (r"this file's mates\b","this file's offerings, possibling and carryings"),
    (r"its own offering mate\b","its own offerings"),(r"its offering mate\b","its offerings"),(r"that file's offering mate\b","that file's offerings"),
    (r"a living file's offering mate\b","a living file's offerings"),(r"the Medicine offering mate\b","the offerings to Natural Medicine"),
    (r"an offering mate\b","a living file's offerings"),(r"the offering mates'","the offerings'"),(r"the offering mates\b","the offerings"),
    (r"the offering mate has\b","the offerings have"),(r"the offering mate\b","the offerings"),
    (r"each living file's carrying mate\b","each living file's carryings"),(r"a carrying mate\b","a living file's carryings"),
    (r"the [Cc]arryings mate\b","the carryings"),(r"its carryings mate\b","its carryings"),(r"the carrying mates\b","the carryings"),(r"the carrying mate\b","the carryings"),
    (r"a possibling mate\b","a living file's possibling"),
    (r"at this mate has\b","at "+this[0]+" has"),
    (r"This mate has\b",this[1]+" "+this[2]),(r"this mate has\b",this[0]+" "+this[2]),
    (r"This mate's\b",this[4]),(r"this mate's\b",this[3]),(r"This mate\b",this[1]),(r"this mate\b",this[0]),(r"that mate\b",this[5]),
    (r"the mate's\b",this[3].replace('these','the').replace('this','the')),
    (r"(\w[\w ]*?)'s? mates carry (its|their) side",lambda m: m.group(0).replace(' mates carry ',' offerings, possibling and carryings carry ')),
    (r"The mates have\b","The offerings, possibling and carryings have"),(r"the mates have\b","the offerings, possibling and carryings have"),
    (r"its three mates\b","its offerings, its possibling and its carryings"),
    (r"offering, possibling and carrying mates\b","offerings, possibling and carryings"),
    (r"their mates\b","their offerings, possibling and carryings"),(r"its mates\b","its offerings, possibling and carryings"),
    (r"(at|to|in) the mates\b",r"\1 the offerings, possibling and carryings"),
    ]
pat=re.compile(r'\b[Mm]ates?\b'); log=[]; left=[]
for f in sorted(glob.glob('carry/*.md')):
    b=os.path.basename(f); K='O' if 'Offerings' in b else 'C' if 'Carryings' in b else 'P' if 'Possibling' in b else 'L'
    t=open(f,encoding='utf-8').read(); paras=t.split('\n\n'); cur=''; ch=False
    for i,p in enumerate(paras):
        if p.startswith('## '): cur=p.split('\n',1)[0]
        if not pat.search(p): continue
        if not (('v386EOD' in cur) or p.rstrip().endswith('— v386EOD')): continue
        q=p
        for a,bb in HAND: q=q.replace(a,bb)
        for r,rep in rules(K): q=re.sub(r,rep,q)
        if q!=p:
            for m in pat.finditer(p):
                s=p[max(0,m.start()-70):m.end()+50].replace('\n',' ')
                log.append((b[:38],s))
            paras[i]=q; ch=True
        for m in pat.finditer(q):
            left.append((b[:45],q[max(0,m.start()-110):m.end()+70].replace('\n',' ')))
    if ch and not DRY: open(f,'w',encoding='utf-8').write('\n\n'.join(paras))
print('changed places',len(log),'left',len(left))
for b,s in left: print('LEFT',b,'|',s)
