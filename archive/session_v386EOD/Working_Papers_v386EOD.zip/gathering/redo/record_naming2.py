import re,sys
DRY=len(sys.argv)<2
NUM=r"(two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty(?:-\w+)?|thirty(?:-\w+)?|forty(?:-\w+)?|fifty(?:-\w+)?|sixty(?:-\w+)?|seventy(?:-\w+)?|Four|Thirteen|Fifteen|fifteen remaining|Four further|Thirteen further|four further|thirteen further|fifteen remaining)"
RULES=[
(r"and each offering mate's older Droplets section read by two readings","and the older Droplets section of each file of offerings read by two readings"),
(r"\*\*Each offering mate's older Droplets section, read by two readings\.\*\*","**The older Droplets section of each file of offerings, read by two readings.**"),
(r"The thirty-three offering mates' older Droplets sections","The older Droplets sections of the thirty-three files of offerings"),
(r"the thirty-three offering mates' older Droplets sections","the older Droplets sections of the thirty-three files of offerings"),
(r"each mate's older Insertlets section, and the older sections of the possibling and carrying mates","the older Insertlets section of each file of offerings, and the older sections of the files of possibling and of carryings"),
(r"\| Placed \| Mate \|","| Placed | File in `carry/` |"),(r"\| Mates \|","| Files in `carry/` |"),(r"\| Mate \|","| Offerings |"),
(r"\| At the mates \| Not at the mates \|","| At the files in `carry/` | Not at the files in `carry/` |"),
(r"\*Said whole at a mate\*","*Said whole at a file in `carry/`*"),
(r"Its mate additions","Its additions at its own copy of the offerings"),
(NUM+r" offering mates'",r"\1 files of offerings'"),(NUM+r" offering mates\b",r"\1 files of offerings"),
(NUM+r" possibling mates\b",r"\1 files of possibling"),(NUM+r" carrying mates\b",r"\1 files of carryings"),
(r"offering and possibling mates\b","files of offerings and of possibling"),(r"possibling and carrying mates\b","files of possibling and of carryings"),
(r"the offering mates of\b","the offerings to"),(r"the offering mate of\b","the offerings to"),(r"the carrying mates of\b","the carryings of"),(r"the carrying mate of\b","the carryings of"),
(r"offering mates\b","files of offerings"),(r"an offering mate\b","a file of offerings"),(r"offering mate\b","offerings"),
(r"the carrying mates\b","the carryings"),(r"a carrying mate\b","a file of carryings"),(r"carrying mates\b","files of carryings"),(r"carrying mate\b","carryings"),
(r"a possibling mate\b","a file of possibling"),(r"possibling mates\b","files of possibling"),(r"possibling mate\b","possibling"),
(NUM+r" mates'",r"\1 files'"),(NUM+r" mates\b",r"\1 files in `carry/`"),
(r"[Oo]ne mate's older","one file's older"),
(r"This mate, ","The same offerings, "),(r"at one mate, parting","at one file of offerings, parting"),(r"this mate's","the same offerings'"),(r"this mate\b","the same offerings"),(r"the same mate's","the same offerings'"),(r"the same mate\b","the same offerings"),
(r"that mate\b","those offerings"),(r"the mate's","the offerings'"),(r"another mate\b","another file in `carry/`"),
(r"its subject's mate\b","its subject's files in `carry/`"),(r"its mates\b","its files in `carry/`"),(r"its mate\b","its file in `carry/`"),
(r"Each mate as it was","Each file as it was"),(r"each mate as it was","each file as it was"),(r"[Tt]he mate as it was",lambda m:m.group(0)[0]+"he file as it was"),
(r"each mate\b","each file in `carry/`"),
(r"the mates' own","the files in `carry/`, their own"),(r"the mates\b","the files in `carry/`"),(r"The mates\b","The files in `carry/`"),
(r"\bno mate\b","no file in `carry/`"),(r"\ba mate\b","a file in `carry/`"),(r"at the mate of","at the offerings to"),
(r"\bat which mates\b","at which files in `carry/`"),(r"\bwhat its mate already","what its file in `carry/` already"),
(r"\bmates carry\b","files in `carry/` carry"),
]
def nat(t):
    # leave link targets alone
    parts=re.split(r'(\]\([^)]*\))',t)
    for i in range(0,len(parts),2):
        for a,b in RULES: parts[i]=re.sub(a,b,parts[i])
    return ''.join(parts)
def left(t):
    t2=re.sub(r'\]\([^)]*\)',']()',t); return [t2[max(0,m.start()-90):m.end()+50].replace('\n',' ') for m in re.finditer(r'\b[Mm]ates?\b',t2)]
if __name__=='__main__':
    L=[]
    for f in ['incoming/v386EOD/Session_Record_v386EOD.md','incoming/v386EOD/README.md']:
        t=open(f,encoding='utf-8').read(); n=nat(t); L+=[(f[-28:],x) for x in left(n)]
        if not DRY: open(f,'w',encoding='utf-8').write(n)
    R='carry/Exhibit_TWENTY-SIX_Carryings_of_Living_File_Registry.md'; t=open(R,encoding='utf-8').read()
    i=t.index('## Incoming still to gather and aim'); j=t.index('\n## ',i+5); n=nat(t[i:j]); L+=[('TABLE',x) for x in left(n)]
    if not DRY: open(R,'w',encoding='utf-8').write(t[:i]+n+t[j:])
    f='carry/Living_Improving_Value.md'; ls=open(f,encoding='utf-8').read().split('\n')
    for k,l in enumerate(ls):
        if 'Session_Record_v386EOD' in l: ls[k]=nat(l).replace("[the Registry's record]","[the session's record]"); L+=[('LIV',x) for x in left(ls[k])]
    if not DRY: open(f,'w',encoding='utf-8').write('\n'.join(ls))
    print(len(L))
    for a,b in L: print(a,'|',b)
