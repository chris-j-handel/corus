
### A crystal's surface exchanging with its solution

**The file's sentence**, at Still-point veins, each answering with the sway: "Solubility, ions leaving and rejoining, Ostwald ripening showing exchange at crystals". The sentence names no observation.

- *Natural observation*: salt crystals are shaken in a solution carrying marked lead, and marked lead is found on the solid. The interchange was found "restricted to the uppermost molecular layer of the crystal". Reported by [Hevesy's Nobel lecture](https://nobelprize.org/uploads/2018/06/hevesy-lecture.pdf), which gives lead sulphate shaken in its own saturated solution as the doing, and gives no depth measured at lead sulphate itself.
- *Science explanation*: "a constant kinetic exchange" between the solution and the surface of the solid; an equilibrium named dynamic.

### Steps winding as a spiral on a growing crystal

**The file's sentence**, at Chirality, two faces of one coupling and handedness sign-only: "Along, the separating is taken one beat at a time and appears as a spiral".

- *Natural observation*: on faces of grown crystals, steps wind as a spiral round a point: on beryl, steps under twenty ångströms in height; on silicon carbide, steps of the height of one layer. On cadmium iodide growing from its solution, spirals of higher steps are seen advancing. Each reported by [Woodruff's commentary of 2015](https://pmc.ncbi.nlm.nih.gov/articles/PMC4360084).
- *Science explanation*: a screw fault leaves at the face a step that growing never closes; in the commentary's words, "laying a carpet up a spiral staircase".

### A crystal's hand: both hands undisturbed, one hand stirred, one hand ground

**The file's sentence**, at A parity-violating lean, and a bounding-zeroing refusing to sit: "from a stochastic imbalance amplified by the crystals' own dissolving and re-forming". The sentence has a science explanation inside its saying of the observation; the two lines here part them.

- *Natural observation*: each crystal of sodium chlorate turns polarised light, one way or the other. From an undisturbed solution crystals of both hands arrive, about as many of each. From a stirred solution almost all the crystals of a batch are of one hand, and the hand differs from batch to batch ([Kondepudi, Kaufman and Singh, 1990](https://doi.org/10.1126/science.250.4983.975), reported by [Viedma](https://arxiv.org/abs/cond-mat/0407479)). On video, the first crystal the stirrer strikes is followed by a great many new ones (reported by [Dunitz and Bernstein, 1995](https://doi.org/10.1021/ar00052a005)).
- *Natural observation*: crystals of both hands in equal weight are ground with glass balls under their own saturated solution, in a closed flask at one temperature. They come all to one hand and none of the other, and the hand differs from flask to flask. Stirred with no glass balls, the mixture remains as it was ([Viedma, 2005](https://arxiv.org/abs/cond-mat/0407479), read at its preprint).
- *Science explanation*: the dissolved salt has no hand, and pieces struck from the first crystal each grow in its hand; small crystals dissolve as large ones grow, and a chance leaning is amplified.

**Laid beside.** The concept these are beside, the crystal a stable form and the society at its surface living, is at [Offerings to Co-Chaining Logic Registry](Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md#living-as-a-stable-changing-form-at-the-observations--v386eod).

### A candle's flame in orbit

**The files' sentences.** This file, at A natural energy engine, cycling and the surplus kept, the ledger beside it: "combustion a rapidly propagating reaction network and metabolism many bounded reaction cycles coupled and renewing their participants". Natural Biology, at Living is metabolic beating — the cell as the engine: "Combustion lands (fire, ash, the surplus lost as heat, the reaction dead)".

- *Natural observation*: candles lit in orbit, in a perforated box inside a sealed glovebox. At lighting the flame is a bright yellow sphere. It becomes blue and nearly a half-sphere, further off its wick than a candle's sooty yellow flame on Earth. Each flame went out, and before going out each moved back and forth along the candle's axis, more and more ([Dietrich, Ross and T'ien, Candle Flames in Microgravity](https://ntrs.nasa.gov/api/citations/19960008390/downloads/19960008390.pdf), of the shuttle flight of June 1992).
- *Science explanation*: on Earth rising hot gas shapes the flame and carries soot to its tip, and in orbit that flow is absent; the flames went out as the sealed volume's oxygen was depleted.

**Laid beside.** In orbit the flame's form is of the things around it: a sphere at lighting, then nearly a half-sphere, and then none. The concept, a flame a society of molecules stable forming, is at [Offerings to Co-Chaining Logic Registry](Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md#living-as-a-stable-changing-form-at-the-observations--v386eod).
