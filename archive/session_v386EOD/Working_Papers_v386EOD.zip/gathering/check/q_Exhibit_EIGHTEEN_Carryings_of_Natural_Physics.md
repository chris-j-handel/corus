
### Fine particles in water, from rock as from pollen

**The files' sentence.** The Co-Chaining Logic Registry, at Living and non-living at a scale, of a carrying of none: "one parity arriving, colliding, passed on as it is and chained".

- *Natural observation*: under the microscope, fine particles in water are "very evidently in motion": particles from pollen, from plants dried a century, and alike particles bruised or ground from window glass, from each mineral of granite, from lava and from meteorites. Of larger particles in old specimens, motions much less manifest and in some cases not observable are reported. None was obtained from oil, resin, wax and sulphur, from metals not ground fine enough, and from bodies that dissolve in water ([Brown, 1828](https://www.rpgroup.caltech.edu/marseillePBoC2024/assets/pdfs/Brown1828.pdf)).
- *Science explanation*: at that publishing, the motion "belonged to the particle itself". Later: the water's unseen molecules striking the particle.

**Laid beside.** At that grain motion is found in particles from rock as from pollen. By the Registry's sentence the later explanation is a non-living thing colliding and passing on the parity arriving.
