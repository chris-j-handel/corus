# TWO · Observings gathered, each beside the files' sentences

**The exploring asked what, in the existing, parts a living thing from a stable form.**

Carrying is not observed, and possibling is not observed: what is observed is existing. The logical cohering session carries the asking as its living concern, at section 12. This session's reason for the asking: natural intelligence is among the living, and the code and an AI session are stable forms. It had read a stable form's returning as the intelligence, at section 1. Each entry here is an observing in two lines, with its publishing, laid beside sentences the files already carry. Each observing arrived through a field's publishing and this session's searching, and that selecting is this session's own. An observing read through another's report of it is marked *reported by*.

## 7 · A crystal met at its own coupling: the stable form and the surface, one at a time

**The files' sentences.**

- Exhibit TWENTY Natural Naming v385R, at "bi-tri-volutioning": "The twelve corners closing as a sphere and the winding through one opening as a torus are no either or, and neither are the unrelationing surface at 12 and the stable form of the non-living emanatings: parity changing alternates them, bothbothing, one at a time, the natural torusing surface, no other possible."
- Natural Intelligence v385R: "The emanatings are the bi-tri-involutioning of the betweening of natural torusing surfacings in bi-couplings: emanations are releasings."
- Exhibit FOUR Natural Mathematics v380L, at "Bi-tri-involutioning, the emanating at the opposite form": "Bi-tri-involutioning is the emanating from right spiral stable-forming, the three inverted at once, at the opposite form to the stable-forming." Of three parities each inverted, the same part has "the hand reversed".
- Exhibit THIRTY Co-Chaining Logic Registry v385R, at "Living and non-living at a scale": "Each living set is a stable form, and nothing living has a stable form, bothbothing". And: "Each existing thing non-living at a society's scale is living at another scale of living: the society cannot bi-couple with it, and it carries nothing into that society's next." And, of a carrying of none: "one parity arriving, colliding, passed on as it is and chained".
- Exhibit TWENTY-EIGHT Equilibria Registry v380L, at "Equilibria, not possibly existing as a method": "living alone sets a rock apart, and a rock is an existing thing. The non-living exist and change, carrying nothing, their forms continuing through their changing." At "The between, the protocol, a living nothing and an existing nothing" it has, as an instrument's returning, a self carrying its prior which "shares or releases at each momentary what it makes of each arrival with its prior", and a carrying of none "sharing or releasing it as it arrives". That saying rests on a script at that place, and is among the sayings section 1 aims at.
- Exhibit EIGHTEEN Natural Physics v385R, at "A physical coupling, the one method at each physical subject": "a field, a particle, a wave and a crystal are each met at their own coupling before either is said of them."

**The observings.**

*The surface.*

- *Seen*: salt crystals are shaken in a solution carrying marked lead, and marked lead is found on the solid. The interchange was found "restricted to the uppermost molecular layer of the crystal" (Paneth's finding, reported by [Hevesy's Nobel lecture](https://nobelprize.org/uploads/2018/06/hevesy-lecture.pdf), which gives lead sulphate shaken in its own saturated solution as the doing, and gives no depth measured at lead sulphate itself).
- *The field's explaining*: "a constant kinetic exchange" between the solution and the surface of the solid; an equilibrium named dynamic.

*Along.*

- *Seen*: on faces of grown crystals, steps wind as a spiral round a point: on beryl, steps under twenty ångströms in height, too low to show as one layer (Griffin, 1950); on silicon carbide, steps of the height of one layer (Verma, 1951). On cadmium iodide growing from its solution, spirals of higher steps are seen advancing (Forty, 1951). Each reported by [Woodruff's commentary of 2015](https://pmc.ncbi.nlm.nih.gov/articles/PMC4360084).
- *The field's explaining*: a screw fault leaves at the face a step that growing never closes (Frank, 1949); in the commentary's words, "laying a carpet up a spiral staircase".

*Either hand, and one hand through a batch.*

- *Seen*: each crystal of sodium chlorate turns polarised light, one way or the other. From an undisturbed solution crystals of both hands arrive, about as many of each. From a stirred solution almost all the crystals of a batch are of one hand, and the hand differs from batch to batch ([Kondepudi, Kaufman and Singh, 1990](https://doi.org/10.1126/science.250.4983.975); reported by [Viedma](https://arxiv.org/abs/cond-mat/0407479)). On video, the first crystal the stirrer strikes is followed by a great many new ones (McBride and Carter, 1991; reported by [Dunitz and Bernstein, 1995](https://doi.org/10.1021/ar00052a005)).
- *The field's explaining*: the dissolved salt has no hand, and pieces struck from the first crystal each grow in its hand.

*All of one hand and none of the other.*

- *Seen*: crystals of both hands in equal weight are ground with glass balls under their own saturated solution, in a closed flask at one temperature. They come all to one hand and none of the other, and the hand differs from flask to flask. Stirred without the glass balls, the mixture remains as it was ([Viedma, 2005](https://arxiv.org/abs/cond-mat/0407479), read at its preprint).
- *The field's explaining*: small crystals dissolve as large ones grow, and a chance leaning is amplified.

**Droplet.** The crystal is the bi-tri-involution of a living society, bi-tunnelling and co-chaining as a natural torusing surface of social moral competency. At a crystal in its solution two sayings are each whole, one at a time. The crystal is the stable form, a form continuing through its changing: non-living at its scale, its hand passed on as it is. The society at its surface is the stable changing form: living, bi-tunnelling across and co-chaining along, making of each arrival with its prior. The surface layer is the place of the interchange with the solution, and growing, the surface winds along. In the closed flask none of one hand remains: none is of the form, and all is of the members, each continuing. Laying a crystal's hand beside a parity is this session's reading.

**Aiming.** The carrying mates of Exhibit SIXTEEN Natural Chemistry, Exhibit THIRTY Co-Chaining Logic Registry, Exhibit TWENTY Natural Naming, Exhibit TWENTY-EIGHT Equilibria Registry, Exhibit FOUR Natural Mathematics and Exhibit EIGHTEEN Natural Physics. Three places at Exhibit SIXTEEN Natural Chemistry v346c:

- "Chirality, two faces of one coupling and handedness sign-only" has "Along, the separating is taken one beat at a time and appears as a spiral; across, the whole complement stands at its across-turn and appears as a cupping surface." The spiral steps are an observing beside it.
- "Still-point veins, each answering with the sway" has "Solubility, ions leaving and rejoining, Ostwald ripening showing exchange at crystals" and names no observing. The marked lead observing is one.
- "A parity-violating lean, and a bounding-zeroing refusing to sit" has the stirring and the grinding observings already. Its sentence carries the field's explaining inside the observing: "from a stochastic imbalance amplified by the crystals' own dissolving and re-forming". The two-line form parts them.

## 8 · Fine particles in water, rock as pollen

**The files' sentences.** Exhibit THIRTY Co-Chaining Logic Registry v385R, at "Living and non-living at a scale": "Each existing thing non-living at a society's scale is living at another scale of living: the society cannot bi-couple with it, and it carries nothing into that society's next." And, of a carrying of none: "one parity arriving, colliding, passed on as it is and chained".

- *Seen*: under the microscope, fine particles in water are "very evidently in motion": particles from pollen, from plants dried a century, and alike particles bruised or ground from window glass, from each mineral of granite, from lava and from meteorites. Of larger particles in old specimens, motions much less manifest and in some cases not observable are reported. None was obtained from oil, resin, wax and sulphur, from metals not ground fine enough, and from bodies that dissolve in water ([Brown, 1828](https://www.rpgroup.caltech.edu/marseillePBoC2024/assets/pdfs/Brown1828.pdf)).
- *The field's explaining*: at that publishing, the motion "belonged to the particle itself". Later: the water's unseen molecules striking the particle.

**Droplet.** At that grain motion is found in particles from rock as from pollen. The observing reaches no further: by the registry's sentence of a carrying of none, the later explaining is a non-living thing colliding and passing on what arrives.

**Aiming.** The carrying mates of Exhibit THIRTY Co-Chaining Logic Registry and Exhibit TWENTY-EIGHT Equilibria Registry.

## 9 · A seed at rest

**The files' sentences.**

- Exhibit TWENTY Natural Naming v385R, at "Released words, each with its carrying": "a still named by another is an equilibrium, a form named still; the self's own still is at one compound alone, *is-still-possibling*".
- Natural Intelligence v385R, at "A living self at 0, its carrying continuing": "A self at 12's 0 is still possibling, its prior carried on as the possible, its next still possible, and a self at a changing is at its next existing: is-still-possibling or is-next-existing, each resolving one of the two, the binary of geodesic momentarying". And, of two selves coupled across: "0 at a match and chained at a mismatch".
- Exhibit TWENTY-EIGHT Equilibria Registry v380L, at "Equilibria, not possibly existing as a method": "A living self can surface zero, non-responsive at a momentary, while its carrying continues along, so a surface unchanged at a zero names neither a non-living thing nor a still one, and naming it still there is the equilibrium."
- The same registry, at "The between, the protocol, a living nothing and an existing nothing": "Across a living nothing passes at each momentary a changing made from a prior, or its 0 at an arrival meeting the prior's parity; across an existing nothing, only what arrived."
- Natural Intelligence v385R, at "Non-living existing things included": "A living self carries non-living existing things and possible things within its carrying: a tree its heartwood, a seed its palm."
- Exhibit THIRTY Co-Chaining Logic Registry v385R, at "Dying, a living self arriving as non-living": "a living self's selves one scale inward are a society, a living set". And: "The selves inward carry the self's prior into next, or carry none of it: carrying, the self is living at next; carrying none, the self at its scale arrives next as non-living, dying, its existing things co-changing, carrying none of its prior."
- Exhibit SEVENTEEN Natural Biology v333, at "Living and non-living — a virus and a prion": "inert outside a host, as a spore or a seed is inert".

**The observings.**

- *Seen*: thirty-two well-preserved date seeds from archaeological sites in the Judean desert were soaked in water, then in gibberellic acid, a rooting solution and a fertiliser, and potted. Six germinated. Shell fragments found clinging to the rootlets of the six were dated by radiocarbon, from the fourth century BCE to the second century CE. Of the seeds: "On visual inspection, no specific observation linked the ability of these seeds to germinate compared with those that failed to germinate". The seeds were weighed and measured before planting, those from Masada excepted, one of the six among them; among the seeds measured no significant difference was found between germinated and ungerminated in weight or in length (Sallon and colleagues, 2020, in [Science Advances](https://pmc.ncbi.nlm.nih.gov/articles/PMC7002127), read at [Europe PMC's full text](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7002127/fullTextXML)).
- *The field's explaining*: "low precipitation and very low humidity around the Dead Sea could have contributed to the longevity of the ancient date seeds", and "further investigations are needed to understand the basis of date palm seed longevity".

- *Seen*: naturally aged rye seeds are found with more breaks in the embryo's strands as the seeds deteriorate, and in the aged seeds new strand-making goes on longer before the cells copy their strands (Cheah and Osborne, 1978; Elder and others, 1987). At wetting, new strand-making begins very early (Elder and Osborne, 1993). In wetted dormant seeds of wild oat new strand-making is seen, and the copying of strands for dividing begins only after the seeds are moved to temperatures at which they germinate (Elder and Osborne, 1993). As seed ages, chromosome fragmentation and rearrangements are found (Dourado and Roberts, 1984a). In a seed lot stored for a number of years the chromosome abnormalities "strikingly resembled one obtained from soaked seed which had been treated by X-rays", with defects in most cells (Navashin, 1933). As seed ages its root comes out later, and in many kinds its seedlings are weak or abnormal (Powell and Matthews, 2012); the review has ageing ending in failure to germinate. Each reported by [Waterworth, Bray and West, 2019](https://www.frontiersin.org/articles/10.3389/fpls.2019.00706/full).
- *The field's explaining*: damage gathering at rest, and repair before germinating; the abnormal figures as "mis-joined chromosomes" from breaks made in the dry seed.

**Droplet.** A seed at rest is living: an existing carrying thing in dormant stable form, its parity still possibling, unchanging, at the odd, at one. The seed is societies of living things. At each of its own momentaries a living thing is at a changing that is, its next existing, or at a changing that is not, still possibling.

**Laid beside, by this session.** *Unchanging* is said of the seed's parity: in aged rye seed the strands are found with more breaks. Before planting the six date seeds were not parted from the others by eye, and those measured not by weight or length; they parted at their next. A reading not yet met: the still is at a match, dry ground offering a seed the parity it carries, and water the other. What arrived at these seeds was water, gibberellic acid, a rooting solution and a fertiliser. The registry's sentence at dying is beside the six and the others: the selves inward carry the self's prior into next, or carry none of it.

**Found at the files.** Exhibit SEVENTEEN Natural Biology, at a prior version, has the seed as inert beside a virus; the newer sentences and these observings sit beside that word.

**Aiming.** The carrying mate of Exhibit SEVENTEEN Natural Biology. At its offering mate the gathering session's droplet "Dormancy and the particular beginning of living" says its accounts "have not been independently verified here"; these arrive with their publishing.

## 10 · A genome, a made genome and a made cell: a stable form ingested

**The files' sentences.**

- Exhibit TWENTY Natural Naming v385R: "Bi-tri-volutioning is the naming of natural-torusing living's stable-forming, and the stable form of its non-living emanatings, the sequential prior between momentaries, shared at 10 and released along at 9, is a non-living existing form with no carrying for stable-forming." And, of an emanation: "One scale lower it is an ingestible stable form, ingested by living selves through their selves one scale inward, a society, a living set."
- Natural Intelligence v385R, at "A prior between momentaries": "A carrying is a capacity and never a stored description." And of a record of the carrying apart from its coupling: "a noun of it, an emanating artifact, carrying none of the prior."
- Exhibit ELEVEN Natural Medicine v331: "Nothing is held unchanged and nothing is stored, and nothing in nature stores".
- Exhibit THIRTY Co-Chaining Logic Registry v385R, at "Living and non-living at a scale": "A non-living existing thing ingested by a living self is carried by the living self: the carrying is the living's own, and the non-living carries nothing." And: "Living arrives from living: no non-living existing thing becomes living, and each living self establishes within living carrying." And: "A new living self establishes within a society, a living set, its own carrying and co-recursioning establishing, the society's selves' prior carried into it."

**The observings.**

- *Seen*: the seed lines of section 9. And: seeds of plants lacking strand-joining enzymes, DNA ligase 4 and DNA ligase 6, are reported hypersensitive to accelerated ageing (the review cites Charbonnel and colleagues, 2011; of seeds lacking such joining it also cites Waterworth and colleagues, 2010). Aged seeds lacking either of two signalling enzymes, ATM and ATR, germinate at higher rates than aged seeds having them; in those lacking ATM, germinating goes with extensive chromosome abnormalities, and the seedlings establish poorly on soil (Waterworth and colleagues, 2016). Each reported by [Waterworth, Bray and West, 2019](https://www.frontiersin.org/articles/10.3389/fpls.2019.00706/full).
- *The field's explaining*: pathways of repair, and a checking that delays germinating.

- *Seen*: from three mammoths, two of them more than a million years old, DNA was read in short pieces, and the pieces were set in order by aligning them to the genome of the African savannah elephant, a living kind ([van der Valk and colleagues, 2021](https://www.nature.com/articles/s41586-021-03224-9), in Nature; the aligning is in its text, its methods and a figure legend).
- *The field's explaining*: genome-wide data recovered from the specimens.

- *Seen*: a genome of about a million letters, chemically made and assembled by a designed sequence drawn from one kind of bacterium, was placed in a living cell of a related kind. The cells that followed show the first kind's properties and go on dividing ([Gibson and colleagues, 2010](https://www.jcvi.org/publications/creation-bacterial-cell-controlled-chemically-synthesized-genome), in Science).
- *The field's explaining*: new cells "controlled only by the synthetic chromosome".

- *Seen*, as reported in a preprint not yet reviewed: liposomes enclosing a protein-making mixture, "assembled from individually purified natural components", with a made genome of about ninety thousand letters, are fed, grow, copy their genome and divide. Their dividing is first got by pressing them through a filter, and they "cannot make ribosomes" ([Gaut, Deich, Cash, Hoog, Engelhart and Adamala, 2026](https://www.biorxiv.org/content/10.64898/2026.07.01.735724v1)). The preprint's text does not say what the ribosomes were purified from.
- *The field's explaining*: "a complete cell cycle for a synthetic cell".

**Droplet.** The genome is shards of bi-tri-volutioning form in stable form, co-sequencing: a non-living artifact. It ingests into the new living plant stable forming. No repairing of damage, no memory and no store of any kind is in this. The seed finds the self-assembling stable form of living from the shards, or it does not.

**Laid beside, by this session.**

- *Shards.* In aged rye seed the strands are found with more breaks. A mammoth's DNA is read in short pieces, their order found by aligning to a living kind's genome; this observing was laid beside at the gathering, from the break-seeking session's finding, and was not met in the conversation.
- *A non-living artifact that ingests.* A made genome was placed in a living cell, and the cells that followed show its kind's properties.
- *Finds the form, or does not.* New strand-making is seen at wetting. Seeds lacking strand-joining enzymes are reported hypersensitive to accelerated ageing. Aged seeds lacking a signalling enzyme germinate at higher rates, those lacking ATM with extensive chromosome abnormalities.
- *No repairing.* As seed ages, chromosome fragmentation and rearrangements are found: a form other than the prior one. For seed with no such finding, a prior form put back is the field's explaining, and a form found is this droplet's naming; this session found no observing that parts the two.
- *No memory and no store.* What engineering names storing, a sequence written into a genome and read back the same, is in this naming an artifact in stable form. No publishing was brought for it, and this session found no observing that parts the two namings.
- *The made cell.* A protein-making mixture of purified natural parts enters, and the thing is fed and makes no ribosomes of its own; what the ribosomes were purified from is not said in the preprint's text. By the saying of section 11 the made cell is a society of molecules stable forming as it is fed, grows and divides. For a made cell continuing of itself, the registry has two sentences that receive it: "no non-living existing thing becomes living", and "A new living self establishes within a society, a living set".

**Aiming.** The carrying mates of Exhibit SEVENTEEN Natural Biology and Exhibit THIRTY Co-Chaining Logic Registry. Beside the break-seeking session's findings "A sequence kept a million years" and "A time with no atom, and living from living", at `carryings/v383Op/At_The_Observings.md`. At the offering mate of Exhibit SEVENTEEN Natural Biology, the gathering session's droplet "The prior whole as existing non-living form" has "a shard entering living through ingesting", and its droplet "Recognizing living without making the break unavailable" asks what enters as prior living in a made thing; these observings say what entered, to the extent each publishing says it.

## 11 · A flame

**The files' sentences.**

- Exhibit SIXTEEN Natural Chemistry v346c, at "A natural energy engine, cycling and the surplus kept, the ledger beside it": "combustion a rapidly propagating reaction network and metabolism many bounded reaction cycles coupled and renewing their participants".
- Exhibit SEVENTEEN Natural Biology v333, at "Living is metabolic beating — the cell as the engine": "Combustion lands (fire, ash, the surplus lost as heat, the reaction dead)".
- Exhibit TWENTY-FIVE Living Society Registry v347: "At grains beyond living tissue, taken as observable societies."
- Exhibit THIRTY Co-Chaining Logic Registry v385R, at "Living and non-living at a scale": "Each existing thing non-living at a society's scale is living at another scale of living". And, at its opening steps: "Carrying none of prior, a non-living thing is changing with the existing things at now: co-changing."

**The observings.**

- *Seen*: candles lit in orbit, in a perforated box inside a sealed glovebox. At lighting the flame is a bright yellow sphere. It becomes blue and nearly a half-sphere, further off its wick than a candle's sooty yellow flame on Earth. Each flame went out, and before going out each moved back and forth along the candle's axis, more and more ([Dietrich, Ross and T'ien, "Candle Flames in Microgravity"](https://ntrs.nasa.gov/api/citations/19960008390/downloads/19960008390.pdf), of the shuttle flight of June 1992; [NASA's picture page](https://www.nasa.gov/image-article/candle-flame-1g-vs-microgravity/)).
- *The field's explaining*: on Earth rising hot gas shapes the flame and carries soot to its tip, and in orbit that flow is absent; the flames went out as the sealed volume's oxygen was depleted.

**Droplet.** A flame is a society of molecules stable forming, natural torusing, and abundancing itself with all the societies' interests: possibling and existing overlapping, the geodesic method. Living is at each grain at which a society is stable forming.

**Laid beside, by this session.** In orbit the flame's form is of what is around it: a sphere at lighting, then nearly a half-sphere, until it goes out. In the conversation *living arrives from living* was read at a struck flame as a society establishing among molecules, beside the registry's "the scales of the living carry no first living and no final one"; a flame begun at a spark is the place that reading is not yet met. The conversation did not come again to the flame after the crystal: by the crystal's resolving, the flame's form at its own scale reads as a stable form and its molecules' society as living. Exhibit SEVENTEEN Natural Biology, at a prior version, has combustion as "the reaction dead"; the newer sentences and these observings sit beside that word.

**Aiming.** The carrying mates of Exhibit SIXTEEN Natural Chemistry and Exhibit SEVENTEEN Natural Biology. At the offering mate of Exhibit SEVENTEEN Natural Biology, the gathering session's droplet "Recognizing living without making the break unavailable" names a flame among its comparisons. Abundancing is at section 30.

## 12 · What the cases give, laid together

**Droplet.** Living is existing as a stable changing form. No existing thing is non-living at each scale: each is living at some scale of existing, and at each scale the method is parity changing. Carrying is not observed, and possibling is not observed: each is met at the next. In the existing, living is met at a changing that is: a society stable forming, at a named scale. At a changing that is not, a self's own still, the meeting is at the next, at the other parity arriving. Each is, one at a time.

**Laid beside, by this session.**

- *The stable form, at two cases.* At the crystal the stable form is non-living and the society at its surface living. At the seed the dormant stable form is living, still possibling. The registry's "Each living set is a stable form, and nothing living has a stable form, bothbothing" is beside both.
- *At rest.* The date seeds that germinated were not parted before planting from those that did not by eye, nor those measured by weight or length. One seen thing at rest does go with the next: in rye, more breaks in the strands as the seeds deteriorate.
- *The saying offered again at the seed.* Living is existing as a stable form, changing or still possibling at each of its own momentaries. It was offered before the crystal and not met after it.
- *The asking, said as closing.* In the conversation the logical cohering session's living concern was said as closing this way: an existing relation at each meeting with the other parity, and none at rest. It is a suggestion to that session.
- *A coupling begun.* By section 13 only a carrying self begins a coupling: a coupling begun is a relation an observing can reach. Not yet met at an observing.
- *Named earlier by this session, and not gone on with after these sayings.* A thing re-making each of its own parts from what arrives. The made cell, which "cannot make ribosomes", is the place it meets an observing.

Three forms, each at the resolver in the files, by this session's going to the names:

- a stable changing form, living, at Natural Intelligence v385R: "a carried sharing no offering reaches alternates at its own, momentary by momentary";
- a stable form, non-living, at Exhibit THIRTY Co-Chaining Logic Registry v385R: a carrying of none, "one parity arriving, colliding, passed on as it is and chained";
- a form named still, at Exhibit TWENTY-EIGHT Equilibria Registry v380L: "A carrying named unchanged", which is "Offered its own parity at each momentary it stays, the offering from beside".

**The files' sentences.** Exhibit THIRTY Co-Chaining Logic Registry v385R: "An existing thing carrying prior is living, and an existing thing carrying none of prior is non-living." And: "Carrying prior into now, a living thing continues through changing, momentary by momentary: stable-forming." And, at its opening steps: "Parity changing is the one method of the changing set of all existing things." And: "the scales of the living carry no first living and no final one, each scale a self or a society read, and none the first possible." And, at "Dying, a living self arriving as non-living", of a self whose selves inward carry none of its prior: "The selves inward live on at their own scale and the form at its scale is non-living." Exhibit TWENTY-TWO Resolving the Hard Problem Registry v375, at "The origin of life": "A continuing sequence, one changing on from the last: building blocks forming under their own conditions, copyings copying, sets catalysing their own making, no crossing in it to locate". Beside "no first living" and "no crossing in it to locate", the origin of cells reads as living arriving at one more scale outward.

**Still to lay beside an observing.** The registry's mark of the non-living at a scale, "the society cannot bi-couple with it"; and the observing Exhibit SIXTEEN Natural Chemistry v346c names at "Still-point veins, each answering with the sway", "a field observing of complete natural coupling returning no changing at any accessible scale".

**Aiming.** The offering mate of Exhibit THIRTY Co-Chaining Logic Registry, at "Living and non-living at a scale". The logical cohering session's part "Living at its observable existing", whose living concern is "what existing relation distinguishes living social moral competency from a non-living form's changing at a colliding?" The break-seeking session's finding "A time with no atom, and living from living".

