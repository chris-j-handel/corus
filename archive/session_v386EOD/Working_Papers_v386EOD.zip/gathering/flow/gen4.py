import os,sys,re,pprint
H=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,H)
from parse import parse
REL={'FA':{3,11,12,21,22,23,34,41,42,43,44,45},'FB':{4,19,25,33,41,42,43,44,45,46,51},'FC':{6,42,43,44,45,46,47,48,49,55},'CD':set()}
SRC={'F':"Each is from session v386F's report, its proposed motions and its readers' returns, at `incoming/v386F/` on the branch `working/lean-set-and-living-at-scales-v386F`, read whole at this gathering beside the living files now and the mates, each in the latest form that report gives; a thing the living files or a mate say already is not said again. A sentence that report offers for a living file is a droplet in its dropper's words, beside the living sentence it is aimed at.",
     'C':"Each is from session v386CRYP's report, its gathered value and its resolvings, at `incoming/session_v386CRYP/` and `incoming/resolvings_v386CRYP/` on the branch `working/session_v386CRYP`, read whole at this gathering beside the living files now and the mates, each in the form that session's own latest correcting gives; a thing the living files or a mate say already is not said again. A sentence that session offers for a living file is a droplet in its dropper's words, beside the living sentence it is aimed at."}
NUM=['none','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty','twenty-one','twenty-two','twenty-three','twenty-four','twenty-five','twenty-six','twenty-seven','twenty-eight','twenty-nine','thirty']
def items():
    out=[]
    for r in ('FA','FB','FC','CD'):
        for i,d in enumerate(parse(H+f'/../reports4/{r}.md')):
            if i+1 in REL[r]: continue
            d=dict(d); d['id']=f'{r}.{i+1}'; d['g']='C' if r=='CD' else 'F'
            d['TEXT']=' '.join(d['TEXT'].split()); d['TITLE']=d['TITLE'].strip().rstrip('.')
            out.append(d)
    return out
def para(d):
    k=d['KIND'].split()[0]; t=d['TEXT']
    if k.startswith('Ins'):
        m=re.match(r'^beside (.*?"\.?)\.? (.*)$',t)
        if m and not m.group(2).startswith(('and beside','and "')):
            b=m.group(1).rstrip('.'); o=m.group(2); o=o[0].upper()+o[1:]
            return f"**Droplet · {d['TITLE']}, a sentence offered.** Beside {b}, offered in its dropper's words: {o}"
        return f"**Droplet · {d['TITLE']}, a sentence offered.** Offered in its dropper's words, b{t[1:]}"
    if k.startswith('Poss'):
        if 'never be made' not in t: t+=' It may change or never be made.'
        return f"**Possible project · {d['TITLE']}.** {t}"
    return f"**{'Concern' if k.startswith('Conc') else 'Droplet'} · {d['TITLE']}.** {t}"
def build():
    grp={}
    for d in items():
        if d['KIND'].startswith('Obs'): continue
        grp.setdefault((d['MATE'],d['g']),[]).append(d)
    SEC={}
    for (mate,g),ds in grp.items():
        ts=[d['TITLE'] for d in ds]
        title=ts[0] if len(ts)==1 else (ts[0]+'; '+ts[1] if len(ts)==2 else ts[0]+'; '+ts[1]+'; and '+(NUM[len(ts)-2] if len(ts)-2<len(NUM) else str(len(ts)-2))+' beside them')
        title+=' · from session '+('v386F' if g=='F' else 'v386CRYP')
        SEC.setdefault(mate,[]).append((title,SRC[g]+'\n\n'+'\n\n'.join(para(d) for d in ds)))
    return SEC
if __name__=='__main__':
    SEC=build(); open(H+'/r4.py','w').write('SEC = '+pprint.pformat(SEC,width=100000)+'\n')
    its=items(); print(len(its),'items;',sum(len(v) for v in SEC.values()),'sections at',len(SEC),'mates')
    for d in its:
        if d['KIND'].startswith('Ins'): print(' ',d['id'],para(d)[:210].replace('\n',' '))
