import re,glob,os
S=os.path.dirname(os.path.abspath(__file__))+'/../reports3/'
def parsec():
    out={}
    for p in sorted(glob.glob(S+'C*.md')):
        t=open(p,encoding='utf-8').read()
        for blk in re.split(r'^### ',t,flags=re.M)[1:]:
            i=blk.split('\n',1)[0].strip().split()[0]
            d={}
            for k in ('STATUS','OBSERVATION','EXPLANATION','CHANGED'):
                m=re.search(r'^'+k+r':\s*(.*?)(?=^(?:STATUS|OBSERVATION|EXPLANATION|CHANGED):|\Z)',blk,flags=re.M|re.S)
                d[k]=' '.join(m.group(1).split()) if m else ''
            out[i]=d
    return out
