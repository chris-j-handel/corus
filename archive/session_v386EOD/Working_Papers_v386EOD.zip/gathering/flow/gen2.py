import glob,os,sys,re,pprint
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from parse import parse
D={
 'cov378':"the readings of Exhibit THIRTY Co-Chaining Logic Registry's coverage at version 378, at `carryings/co_chaining_coverage_v378/`",
 'map376':"the map of the co-chaining at version 376, at `carryings/co_chaining_map_v376/`",
 'coh377':"the workings of versions 376 to 379 on the ten and the six cohering, Exhibit ONE's prefixes, the Equilibria Registry and rings as spirals, at `carryings/`",
 'v374':"the report of session v374 on genome doubling and its second part, with the workings on illustrating and on physics for the other files beside it, at `carryings/`",
 'gim381':"the proposed Geodesic Improving Method of session v381R and its four readings for harm, at `carryings/geodesic_improving_method_v381R_proposed/`",
 'phys377':"the proposed Natural Physics of version 377, at `carryings/natural_physics_v377/`",
 'res373':"the resettling of version 373, its released Natural Intelligence, its map and Exhibit ONE at its stable forms, at `carryings/resettling_v373/`",
 'rev376':"the two reviews of Natural Physics at version 376, of its improving and of its observings, at `carryings/review_natural_physics_improving_v376/` and `carryings/review_physics_observings_v376/`",
 'rev0930':"the review of Natural Networking and Natural Engineering of 30 September 2026, at `carryings/review_networking_engineering_2026-09-30/`",
 'v380A':"session v380A's carrying, at `carryings/v380A/`",
 'v380L':"session v380L's carrying, at `carryings/v380L/`",
 'v380R':"session v380R's carrying, at `carryings/v380R/`",
 'v381F':"session v381F's carrying, at `carryings/v381F/`",
 'v381R':"session v381R's carrying, at `carryings/v381R/`",
 'v382F':"session v382F's carrying, at `carryings/v382F/`",
 'v383Op':"session v383Op's first report, at `carryings/v383Op/`",
 'v385A':"session v385A's comparisons, at `incoming/v385A/`",
 'v385R':"session v385R's report, its sections 1 to 105, at pull request 128",
 'v386RR':"session v386RR's report and transcript, at the branch `working/closing-droplets-v386RR`",
}
G={'B01':'cov378','B02':'map376','B03':'coh377','B04':'v374','B05':'v374','B06':'gim381','B07':'phys377','B08':'res373','B09':'res373','B10':'rev376','B11':'rev0930','B12':'v380A','B13':'v380A','B14':'v380L','B15':'v380L','B16':'v380L','B17':'v380R','B18':'v380R','B19':'v381F','B20':'v381F','B21':'v381R','B22':'v382F','B23':'v383Op','B24':'v385A','B25':'v385R','B26':'v385R','B27':'v385R','B28':'v385R','B29':'v386RR'}
RELEASE={'B17.2'}
ED={
 'B04.5':[("the surface potential inverts within seconds","the surface potential depolarizes within seconds")],
 'B04.4':[("Two societies forming hours apart share cells","Two societies forming within a day share cells")],
 'B04.9':[("arriving alike at each labelled cell of both sides","arriving alike at each labelled cell lit")],
 'B05.24':[("Discovery that watches the receiving society change","A seeking that watches the receiving society change"),("Discovery succeeds at","The seeking succeeds at")],
 'B07.3':[("The observer apart is in the coupling","The one observing, named apart, is in the coupling")],
 'B13.6':[("its parts travel","its parts move")],
 'B16.11':[('a technology "applied','a *technology* "applied')],
 'B19.2':[("the stored 9.81 a keeping","the stored 9.81 *a keeping*")],
 'B23.6':[("A sentence naming a keeping,","A sentence naming *a keeping*,"),("The kit's words for a keeping have","The kit's words for *a keeping* have")],
 'B28.7':[("can travel through each other","can pass through each other"),("existing traveling through still possibling","existing passing through still possibling")],
}
TI={'B05.24':"Three firsts at the seeking of drugs failing",'B18.8':"Further places of a released word at the Registry's steps"}
KI={'B18.8':'Droplet'}
TX={'B18.8':"Beside the concern at this mate of released words at the Registry's own voice: the word Natural Naming's 2.4 releases for two arriving at one name is at the Registry's steps 386 and 649 too, and step 308 has \"a rest of two beats at a spiral\", *rest* among the words Natural Naming's 2.3 has at landing."}
NUM=['none','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty','twenty-one','twenty-two','twenty-three','twenty-four','twenty-five','twenty-six','twenty-seven','twenty-eight','twenty-nine','thirty','thirty-one','thirty-two','thirty-three','thirty-four','thirty-five']
OBSNOTE=" The observings each is beside are at the carrying mates, each said as its publishing read has it; at a figure parting between a droplet and its observing, the observing carries."
def items():
    out=[]
    for p in sorted(glob.glob(os.path.dirname(os.path.abspath(__file__))+'/../reports2/B*.md')):
        b=os.path.basename(p)[:3]
        for i,d in enumerate(parse(p)):
            k=f'{b}.{i+1}'; d=dict(d); d['id']=k; d['g']=G[b]
            if k in TI: d['TITLE']=TI[k]
            if k in KI: d['KIND']=KI[k]
            if k in TX: d['TEXT']=TX[k]
            for a,z in ED.get(k,[]):
                assert a in d['TEXT'],(k,a); d['TEXT']=d['TEXT'].replace(a,z)
            d['TEXT']=' '.join(d['TEXT'].split()); d['TITLE']=d['TITLE'].strip().rstrip('.')
            out.append(d)
    return out
def build():
    SEC={}; grp={}
    for d in items():
        if d['KIND'].startswith('Obs') or d['id'] in RELEASE: continue
        grp.setdefault((d['MATE'],d['g']),[]).append(d)
    for (mate,g),ds in grp.items():
        ts=[d['TITLE'] for d in ds]
        if len(ts)==1: title=ts[0]
        elif len(ts)==2: title=ts[0]+'; '+ts[1]
        else: title=ts[0]+'; '+ts[1]+'; and '+NUM[len(ts)-2]+' beside them'
        src="Each is from "+D[g]+", read whole at this gathering beside the living files now and the mates, and said in the naming now; a thing the living files or a mate say already is not said again."
        if g=='v374': src+=OBSNOTE
        ps=[]
        for d in ds:
            k=d['KIND'].split()[0]
            if k.startswith('Poss'):
                t=d['TEXT']
                if 'never be made' not in t: t+=' It may change or never be made.'
                ps.append(f"**Possible project · {d['TITLE']}.** {t}")
            else:
                ps.append(f"**{'Concern' if k.startswith('Conc') else 'Droplet'} · {d['TITLE']}.** {d['TEXT']}")
        SEC.setdefault(mate,[]).append((title,src+'\n\n'+'\n\n'.join(ps)))
    return SEC
if __name__=='__main__':
    SEC=build()
    open(os.path.dirname(os.path.abspath(__file__))+'/r2a.py','w').write('SEC = '+pprint.pformat(SEC,width=100000)+'\n')
    n=sum(len(v) for v in SEC.values()); print('mates',len(SEC),'sections',n)
    for m,v in SEC.items():
        for t,b in v: print(len(b.split('\n\n'))-1, m.split('_',2)[-1][:38].ljust(38), t[:150])
