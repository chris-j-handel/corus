import re,subprocess,glob,os
R='/home/claude/corus/'; C=R+'carry/'
norm=lambda s: re.sub(r'\s+',' ',re.sub(r'[*_`]','',s)).strip()
living={f:norm(open(f,encoding='utf-8').read()) for f in glob.glob(R+'*.md')}
carryhead={}
def slug(h):
    h=h.strip().lower(); h=re.sub(r'[^\w\- ]','',h); return h.replace(' ','-')
anch={}
def anchors(p):
    if p not in anch:
        anch[p]={slug(l[l.index(' ')+1:]) for l in open(p,encoding='utf-8') if re.match(r'#{1,6} ',l)}
    return anch[p]
d=subprocess.run(['git','-C',R,'diff','-U0','--','carry'],capture_output=True,text=True).stdout
cur=None; bad=0
REL=r"\b(every|when|whenever|where|wherever|there|because|since|would|until|await\w*|wait\w*|holds?|held|holding|keeps?|kept|keeping|stands?|stood|standing|starts?|begins?|began|returns?|returned|memory|remember\w*|surplus|membranes?|doors?|neighbours?|travel\w*|inside|outside|discovery|technology|runs?|running|takes?|taken|taking|took|half|halves|mirror|reflection|not yet|so far|observers?|met|meets?|meeting|counts?|counted|counting|signs?|turns?|turning|so)\b"
for line in d.split('\n'):
    if line.startswith('+++ b/'): cur=line[6:]; continue
    if not line.startswith('+') or line.startswith('+++'): continue
    t=line[1:]
    # links
    for m in re.finditer(r'\]\(([^)\s]+)\)',t):
        tg=m.group(1)
        if tg.startswith('http'): continue
        fn,_,an=tg.partition('#'); p=os.path.normpath(os.path.join(R,os.path.dirname(cur),fn)) if fn else R+cur
        if not os.path.exists(p): print('LINK no file',cur,tg); bad+=1; continue
        if an and an not in anchors(p): print('LINK no anchor',cur,tg); bad+=1
    # quotes
    for m in re.finditer(r'"([^"]{12,})"',t):
        for part in re.split(r'…|\.\.\.',m.group(1)):
            q=norm(part).strip(' ,.;:')
            if len(q)<12: continue
            if not any(q in v for v in living.values()):
                inc=subprocess.run(['grep','-rlF','--',part.strip(' ,.;:')[:60],C],capture_output=True,text=True).stdout.strip().split('\n')
                inc=[os.path.basename(x) for x in inc if x and os.path.basename(x)!=os.path.basename(cur)]
                print('QUOTE not living',cur.split('/')[-1][:40],'|',q[:90],'| mates:',inc[:2]); bad+=1
    # released words outside quotes, italics, links, headings
    u=re.sub(r'"[^"]*"','',t); u=re.sub(r'\*[^*\n]+\*','',re.sub(r'\*\*[^*\n]+\*\*','',u)); u=re.sub(r'\]\([^)]*\)','',u); u=re.sub(r'`[^`]*`','',u)
    ws=sorted(set(x.group(0).lower() for x in re.finditer(REL,u,re.I)))
    if ws: print('WORD',cur.split('/')[-1][:34],ws,'|',t[:70]); bad+=1
print('flags',bad)
