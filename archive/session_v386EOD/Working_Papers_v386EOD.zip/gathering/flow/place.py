import re,sys,importlib.util,os
S=os.path.dirname(os.path.abspath(__file__)); C='/home/claude/corus/carry/'
name=sys.argv[1]
spec=importlib.util.spec_from_file_location('m',S+'/'+name+'.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
rd=lambda f: open(C+f,encoding='utf-8').read()
def wr(f,t):
    h,rest=t.split('\n',1)
    if 'v386EOD' not in h:
        h=re.sub(r' · (laid|improved|gathered) at .*$',' · improved at v386EOD',h) if re.search(r' · (laid|improved|gathered) at ',h) else re.sub(r'· v\w+$','· v386EOD',h)
    open(C+f,'w',encoding='utf-8').write(h+'\n'+rest)
OBS="## Observings from science, each beside this file's sentences · v386EOD"
n=0
for f,secs in getattr(m,'SEC',{}).items():
    t=rd(f)
    for title,body in secs:
        head='## '+title+' · v386EOD'
        assert '\n'+head+'\n' not in t,(f,title)
        t=t.rstrip('\n')+'\n\n'+head+'\n\n'+body.strip('\n')+'\n'; n+=1
    wr(f,t)
for f,es in getattr(m,'OBS',{}).items():
    t=rd(f); block='\n\n'.join('### '+nm+'\n\n'+b.strip('\n') for nm,b in es)
    if '\n'+OBS in t:
        i=t.index('\n'+OBS); j=t.find('\n## ',i+5); j=len(t) if j<0 else j
        t=t[:j].rstrip('\n')+'\n\n'+block+'\n'+t[j:]
    else:
        t=t.rstrip('\n')+'\n\n'+OBS+'\n\n'+block+'\n'
    wr(f,t); n+=len(es)
print('placed',n)
