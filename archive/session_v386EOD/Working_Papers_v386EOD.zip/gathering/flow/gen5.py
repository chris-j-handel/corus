import os,sys,re,pprint
H=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,H)
from parse import parse
TAIL=", read whole at this gathering beside the living files now and the mates; a thing the living files or a mate say already is not said again. A sentence offered for a living file is a droplet in its dropper's words, beside the living sentence it is aimed at."
G={'R1a':'R','R1b':'R','R2a':'P','R2b':'P','R3a':'E','R3b':'M'}
SRC={'R':"Each is from session v385R's own branch, `working/logical-cohering-v385R`: its additions at the offering mate of the Co-Chaining Logic Registry there, and its changed versions of eight living files, laid line by line beside the living files now"+TAIL,
 'P':"Each is from the comments on pull requests 123, 125, 126, 127, 128, 133 and 135, at which sessions answered each other, each comment read in its sequence with the latest correcting carried"+TAIL,
 'E':"Each is from material on other branches read by no earlier reading: session v382F's mended Natural Intelligence at `working/natural-intelligence-mends-v382F`, session v374's earlier report on chemistry's societies at `working/chemistry-societies-v374`, and earlier versions of session v381F's and session v383Op's files"+TAIL,
 'M':"Each is from the unmerged motion of Natural Physics at version 377, at the branch `working/physics-motion-v377`: its carrying of that file as it was and its released readings"+TAIL}
SUF={'R':"from session v385R's branch",'P':"from the pull requests' comments",'E':"from other branches' earlier versions and mends",'M':"from the physics motion of version 377"}
NUM=['none','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty']
def items():
    out=[]
    for r in G:
        for i,d in enumerate(parse(H+f'/../reports5/{r}.md')):
            d=dict(d); d['id']=f'{r}.{i+1}'; d['g']=G[r]; d['TEXT']=' '.join(d['TEXT'].split()); d['TITLE']=d['TITLE'].strip().rstrip('.'); out.append(d)
    return out
def para(d):
    k=d['KIND'].split()[0]; t=d['TEXT']
    if k.startswith('Ins'):
        m=re.match(r'^beside (.*?"\.?)\.? (.*)$',t)
        if m and not m.group(2).startswith(('and beside','and "','and its','and step')):
            b=m.group(1); o=m.group(2); o=o[0].upper()+o[1:]
            return f"**Droplet · {d['TITLE']}, a sentence offered.** Beside {b.rstrip('.')}, offered: {o}"
        return f"**Droplet · {d['TITLE']}, a sentence offered.** Offered b{t[1:]}"
    if k.startswith('Poss'):
        if 'never be made' not in t: t+=' It may change or never be made.'
        return f"**Possible project · {d['TITLE']}.** {t}"
    return f"**{'Concern' if k.startswith('Conc') else 'Droplet'} · {d['TITLE']}.** {t}"
def build():
    grp={}
    for d in items(): grp.setdefault((d['MATE'],d['g']),[]).append(d)
    SEC={}
    for (mate,g),ds in grp.items():
        ts=[d['TITLE'] for d in ds]
        title=ts[0] if len(ts)==1 else (ts[0]+'; '+ts[1] if len(ts)==2 else ts[0]+'; '+ts[1]+'; and '+NUM[len(ts)-2]+' beside them')
        SEC.setdefault(mate,[]).append((title+' · '+SUF[g],SRC[g]+'\n\n'+'\n\n'.join(para(d) for d in ds)))
    return SEC
if __name__=='__main__':
    SEC=build(); open(H+'/r5.py','w').write('SEC = '+pprint.pformat(SEC,width=100000)+'\n')
    its=items(); print(len(its),'items;',sum(len(v) for v in SEC.values()),'sections at',len(SEC),'mates')
    bad=[d['id'] for d in its if not os.path.exists('/home/claude/corus/carry/'+d['MATE'])]; print('missing mates',bad)
    for d in its:
        if d['KIND'].startswith('Ins'): print(' ',d['id'],para(d)[:150].replace('\n',' '),'...',re.sub(r'^.*?offered:? ','',para(d))[:110] if 'offered:' in para(d) else 'FALLBACK')
