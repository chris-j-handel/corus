import re,glob,os,sys,json
S=os.path.dirname(os.path.abspath(__file__))+'/../reports2/'
def parse(path):
    t=open(path,encoding='utf-8').read()
    items=[]
    for blk in re.split(r'^### ITEM.*$',t,flags=re.M)[1:]:
        blk=re.split(r'^## (RESOLVED|AT A MATE|READING)',blk,flags=re.M)[0]
        d={}
        for k in ('MATE','KIND','TITLE','TEXT','NOTE'):
            m=re.search(r'^'+k+r':\s*(.*?)(?=^\s*(?:MATE|KIND|TITLE|TEXT|NOTE):|\Z)',blk,flags=re.M|re.S)
            d[k]=m.group(1).strip() if m else ''
        items.append(d)
    return items
if __name__=='__main__':
    tot=0
    for p in sorted(glob.glob(S+'B*.md')):
        it=parse(p); tot+=len(it)
        kinds={}
        for d in it: kinds[d['KIND'].split()[0] if d['KIND'] else '?']=kinds.get(d['KIND'].split()[0] if d['KIND'] else '?',0)+1
        print(os.path.basename(p),len(it),len(open(p).read().split()),kinds)
    print('total',tot)
