import os,sys,re,pprint
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from gen2 import items
from parsec import parsec
C=parsec()
TI={'B04.17':"An egg's potential depolarizing at one sperm",'B04.18':"Calcium oscillations and Juno at mouse eggs",'B04.72':"Light freeing electrons above a least frequency, and a pattern at feeble light"}
INTRO="Each is from an earlier session's report read whole at this gathering. Its publishing was opened at this gathering, and the two lines say what the page read has: a part said *as the field's account has it* was reached at no page read, and a publishing not opened is said so."
def fix(s):
    s=s.strip(); s=s[0].upper()+s[1:]
    if s[-1] not in '.!?"”': s+='.'
    elif s[-1] in '"”' : s+='.'
    return s
SEC={}; n=0
for d in items():
    if not d['KIND'].startswith('Obs'): continue
    c=C[d['id']]; t=TI.get(d['id'],d['TITLE'])
    o=fix(c['OBSERVATION']); e=fix(c['EXPLANATION'])
    if c['STATUS'].startswith('NOT'):
        e+=" No page of this publishing opened at this gathering; the two lines are as session v374's report has them."
    SEC.setdefault(d['MATE'],[]).append(f"### {t}\n\n- *Natural observation*: {o}\n- *Science explanation*: {e}"); n+=1
out={m:[("Observings from science, each said as its publishing read has it",INTRO+'\n\n'+'\n\n'.join(v))] for m,v in SEC.items()}
open(os.path.dirname(os.path.abspath(__file__))+'/r2b.py','w').write('SEC = '+pprint.pformat(out,width=1000000)+'\n')
print(n,{m.split('_',2)[-1][:-3]:len(v) for m,v in SEC.items()})
# heading collisions
for m,v in SEC.items():
    t=open('/home/claude/corus/carry/'+m,encoding='utf-8').read()
    hs=[x.split('\n')[0] for x in v]
    for h in hs:
        if '\n'+h+'\n' in t or hs.count(h)>1: print('DUP',m,h)
