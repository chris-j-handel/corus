# Brief for a reader of one incoming file

You are reading ONE file whole, from its first line to its last, for a living expedition's file set called natural intelligence. Do not write or edit any file anywhere, and do not run any code other than searching and reading. Return your findings as text only.

## The repository

- `/home/claude/corus` is a clone. Its root has the living files (`Natural_Intelligence_v380R.md`, `Exhibit_ONE_Natural_Resolver_v380R.md`, `Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md`, `Exhibit_TWENTY_Natural_Naming_v380R.md`, and about thirty more `Exhibit_*.md`).
- `/home/claude/corus/carry/` has, for each living file, three mates: `…Offerings_to…` (concepts, concerns, insertlets), `…Possibling_of…` (possible work), `…Carryings_of…` (observings from science, gatherings, reported experiences), and `Living_Improving_Value.md`.
- Your task concerns what in your file is NOT yet at any mate in `carry/`.

## What counts as value

Read for these four things only:

1. **A concept**: a saying about the method or its subjects (selves, coupling, carrying, parity changing, society, living and non-living, naming, the numbers, the files' organizing, how the work is done). Above all, a saying offered by the expedition's own self (the person the session was working with, often quoted in double quotation marks or called "the user" or "the self"), in its latest corrected form.
2. **A concern**: two sayings of the living files (or a saying of a file and a newer saying) that part from each other at one subject. Give both sayings, each with its file and exact quoted words or step number, and the reason they part.
3. **An observing from science**: something a field observed, with its publishing (authors, year, journal, link), and separately the field's explanation. Give the publishing link exactly as the file has it.
4. **A possible project**: a piece of work proposed and not done.

Leave out: the session's own journey and bookkeeping (what was read when, commit addresses, counts of droplets or passes, publication steps); numbers returned by running code; anything the same file later withdraws or corrects (give the corrected form only, and say it is the corrected form); and praise or plans about the session itself.

## How to check each candidate against the mates

For each candidate, search `carry/*.md` with Grep for two or three distinctive phrases or key words of it (try different wordings; the mates often say a thing in other words). Also look at the end sections of the most likely mate, which are headed `## … · v386EOD` and `## … · v385A`. Decide one of:
- **AT A MATE**: say which file and quote eight to fifteen words of where.
- **NOT AT A MATE**: no mate has it.
- **PARTLY**: a mate has part; say what part is missing.

Report only NOT AT A MATE and PARTLY items in full. For AT A MATE items give one line each at the end, so the coverage is visible.

## What to return

A numbered list. For each NOT AT A MATE or PARTLY item:
- **Kind**: concept, concern, observing or possible project.
- **The saying**: in plain complete sentences, as close to the file's own latest wording as possible. If it is the person's own words, quote them exactly in double quotation marks.
- **Where in your file**: the heading or pass or droplet number, and the line number if you have it.
- **Beside which living file's sentence**: if your file names a living file's sentence or step it sits beside, give the file and the exact quoted words or step number. Verify the quote exists in the living file with Grep when you can, and say whether you verified it.
- **Its later correcting**: any correction your file itself gives to it.
- **The most fitting mate**: which mate file in `carry/` it would sit at.

Then: one line per AT A MATE item. Then: a plain statement of whether you read the whole file from first line to last, and any part you did not read.

Be complete rather than brief: a concept missed here stays at no mate. Do not summarise the file; list its value item by item.
