# Brief for a reader of one incoming portion

You are reading ONE portion whole, from its first line to its last, for a living expedition's file set called natural intelligence. Do not edit any file in `/home/claude/corus`. Do not run code other than searching and reading. You write exactly one file, your report, at the path your task names.

## The repository

- `/home/claude/corus` is a clone. Its root has the living files (`Natural_Intelligence_v380R.md`, `Exhibit_ONE_Natural_Resolver_v380R.md`, `Exhibit_THIRTY_Co-Chaining_Logic_Registry_v380L.md`, `Exhibit_TWENTY_Natural_Naming_v380R.md`, and about thirty more `Exhibit_*.md`).
- `/home/claude/corus/carry/` has, for each living file, three mates: `…Offerings_to…` (concepts, concerns, insertlets), `…Possibling_of…` (possible work that may never be made), `…Carryings_of…` (observings from science, gatherings, reported experiences), and `Living_Improving_Value.md`. `carry/Session_Record.md` is not a mate.
- Your portion is older working material. Earlier gatherings already placed much of its value at the mates, often in other words, and the living files have moved on since. Your task is to find what in your portion is value and is at NEITHER the present living files NOR any mate.

## What counts as value

1. **A concept**: a saying about the method or its subjects (selves, coupling, carrying, parity changing, society, living and non-living, naming, the numbers, the files' organizing, how the work is done).
2. **A concern**: two sayings of the living files (or a living file's saying and a newer saying) that part from each other at one subject.
3. **An observing from science**: something a field observed, with its publishing (authors, year, journal, link as the portion has it), and separately the field's explanation.
4. **A possible project**: a piece of work proposed and not done, still possible at the present files.

Not value, leave out: a session's own journey and bookkeeping (what was read when, commits, counts of droplets, passes, checks, publication steps); numbers returned by running code; anything the portion itself later withdraws or corrects (use the corrected form); wording changes already made in the present living files; a proposed sentence for a living file whose present text already says it; praise or plans about the session itself; and the exact words of the person or of a session where the concept is already at a mate or a living file (no one's words are kept: only the concept counts).

## How to check each candidate

1. Check the present living file of its subject with Grep (two or three wordings). If the living file says it, or the sentence it corrects is gone, it is RESOLVED: one line at the end.
2. Check `carry/*.md` with Grep (two or three wordings; the mates often say a thing in other words). Look at the end sections of the likeliest mate, headed `## … · v386EOD` and `## … · v385A`; many were added today. If a mate has the concept, it is AT A MATE: one line at the end.
3. Only what is at neither is an ITEM. If a mate has part, the ITEM is the missing part alone.

Be strict: a candidate that is only a re-wording of something a mate or a living file says is not an item. Be complete: a concept at neither place that you do not report stays at no file.

## How to write each ITEM

Write each item as the paragraph that would sit at the mate, in the living files' present naming and plain voice:

- Plain declarative sentences. No "I", no "the session found", no narration of the source, no advice, no warning, no recommendation, no promise of later work.
- Quote only living files' own sentences, exactly, in double quotation marks, each verified with Grep in the present living file (say in NOTE if one could not be verified, and then do not put it in quotation marks). Never quote the person's or a session's words.
- Name files by whole names (Natural Intelligence, Exhibit THIRTY Co-Chaining Logic Registry, Natural Naming), never by abbreviations.
- Do not use these words in your own sentences (they are released at Natural Naming; the word in brackets carries it): every (each), when, where, there, because, since, so, would, until, wait, hold, held (named still), keep, kept (carry), stand, start, begin (open), return, memory, surplus (abundancing), membrane (the between), door, neighbour, inside, outside (inward, outward, within), run, take, half, count (number), sign (parity), turn, mirror, reflection, meet, met (couple, at), not yet, so far.
- A concern is written: `Two sayings part. <File> has "…". <File> has "…". They part at <the one subject>: <the reason in one or two sentences>.`
- A possible project is written as what the work is, in one to three sentences.
- An observing is written as two lines: `Natural observation: <what was observed, by what doing> (<publishing as the portion gives it>).` and `Science explanation: <the field's explanation, apart>.` If the portion gives no publishing, say so in NOTE.
- Sixty to one hundred and fifty words for each TEXT.

Three examples of the voice:

> At one sharing, none chained with − offered, and + carried with − offered, each give − shared and − chained. One result alike names no one prior.

> Two sayings part. This file's 4.3 has "Next as prior inverted is the living step." Natural Intelligence has "A lone self changing by itself, offered nothing or its own competency alone, does not continue living through three consecutive momentaries". They part at the one inversion alone named the living step with no such bound beside it: the momentary the term names is said at 4.3.

> A whole text read, one relation followed, a whole record of a file's sections, and a resolving offered are four records. A whole record of sections carries each section's relation and establishes no saying in it; a concern can be within it unresolved.

## The report file

Write your report as plain text to the path your task names, in exactly this form, one block for each item, most valuable first:

```
### ITEM
MATE: <exact file name in carry/, e.g. Exhibit_THIRTY_Offerings_to_Co-Chaining_Logic_Registry.md>
KIND: <Droplet | Concern | Possible project | Observing>
TITLE: <three to ten words naming the concept, none of the words listed above>
TEXT: <the paragraph, on one line>
NOTE: <where in your portion (file and heading or line); what a mate already has, if PARTLY; any later correcting; anything unverified>
```

A Droplet or a Concern goes to an Offerings mate; a Possible project to a Possibling mate; an Observing to a Carryings mate. Use the mate of the item's own subject.

After the items, three sections:

```
## RESOLVED AT THE LIVING FILE
- <one line each>
## AT A MATE
- <one line each, with the mate's file name>
## READING
<whether you read the whole portion from its first line to its last, in how many reads, and any part not read>
```

Then return, as your final message, only: the path of the report, the number of items, and one sentence on what the portion mostly was.
