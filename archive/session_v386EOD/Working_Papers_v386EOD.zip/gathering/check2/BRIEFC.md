# Brief for a checking reader of field publishings

You are checking a batch of observings from science for a file set called natural intelligence. Each observing in your batch file is two lines, "Natural observation: … (publishing)" and "Science explanation: …", written from an older session report whose reader mostly did not open the publishings. Your work is to open each publishing and say what it itself has.

Do not edit any file in `/home/claude/corus`. You write exactly one file, your report, at the path your task names.

## For each observing

1. Find the publishing with WebSearch and open it with WebFetch (the publisher's page, PubMed, PMC, arXiv, bioRxiv, or the journal abstract; an encyclopedia page only if no primary page opens). At most four searches or fetches for one observing; if nothing opens, say so and go on.
2. Compare each claim of the two lines with what you read: the numbers, the species, the year, the journal, the authors, what was done, what the writers themselves say explains it. Many claims in older reports were found wrong in small ways (a number, a year, a term the paper does not use, a finding belonging to another paper, an explanation the writers only suggest).
3. Rewrite the two lines as the publishing has them: only what you read. Keep each fact you could confirm; correct each you found otherwise; for a fact you could not reach, keep it only with the words "as the field's account has it" or leave it out. Give the publishing in full (authors or first author and colleagues, year, journal, volume and pages if seen) and the link you opened.

## Voice of the two lines

Plain declarative sentences, past or present, no "I", no advice, no warning, no narration of your checking. Do not use these words in your own sentences: every (use each), when, where, there, because, since, so, would, until, wait, hold, held, keep, kept, stand, start, begin (use open), return, memory, surplus, membrane, door, neighbour, inside, outside (use within, inward, outward), run, take, half, count (use number), sign, turn, mirror, reflection, meet, met, not yet, so far, discovery, technology, travel, observer. A paper's own words may be given exactly inside double quotation marks, and then any word is allowed inside the quotation. Do not use square brackets followed by round brackets except in the one link.

## The report file

Plain text, one block for each observing in your batch, in the batch's order, in exactly this form:

```
### <the id, e.g. B04.12>
STATUS: <CONFIRMED | CORRECTED | NOT OPENED>
OBSERVATION: <the natural observation, one line, ending with the publishing in round brackets as a markdown link: ([Authors, year, Journal volume, pages](url), read at its abstract | its full text | an encyclopedia's page)>
EXPLANATION: <the field's explanation, one line; "none is given beside the observing" if the publishing gives none>
CHANGED: <what you corrected and why, one or two sentences; "nothing" if confirmed; for NOT OPENED, what you tried>
```

CONFIRMED: opened, and every claim you could compare agrees. CORRECTED: opened, and something was changed. NOT OPENED: no page of the publishing or of a field's account could be opened; then OBSERVATION and EXPLANATION repeat the batch's lines unchanged, without a link.

Where one observing names several publishings, open as many as the four fetches allow, the first-named first, and say in the round brackets of each how it was read ("not opened" for one you did not reach).

Then return, as your final message, only: the path of your report, and the numbers CONFIRMED, CORRECTED and NOT OPENED.
